<?php
//验证类
defined('BASEPATH') OR exit('No direct script access allowed');

trait validation_helper
{
    /**
     * 验证传递的值是否为空
     * @param $str   //要验证的字符串 以,分割 例如: 'limit,offset,page'
     * @param $arr   //验证数组 array()
     * @return bool
     */
    public static function required($str,$param){
        if (!is_array($param)) $param =array($param);
        $str = explode(',',$str);
        foreach ($str as $key=>$val){
            if(!isset($param[$val])) return false;
        }
        return true;
    }

    /**
     * 验证邮箱验证码
     * @param $str
     * @param string $key
     * @return bool
     */
    public static function valid_email_sms($str, $key = '')
    {
        $CI =& get_instance();
        $CI->load->service('Mail_check_service');
        $res = $CI->Mail_check_service->check_code($key,$str);
        if($res) return true;
        return false;
    }

}