<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * ga链接
 * @param string $name 账号
 * @param string $secret ga
 * eg:
 * qrcode("bitp2p:".$this->user['email'],$data['ga']);
 */
if (! function_exists('qrcode'))
{
	function qrcode($name, $secret)
	{
		$CI = &get_instance();
		$CI->load->helper('url');
	    $urlencoded = urlencode('otpauth://totp/' . $name . '?secret=' . $secret . '&issuer=SUANLIBAO.COM');
	    return base_url('qrcode') . '?text=' . $urlencoded . '';
	}
}