<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * [xlink 接口封装函数]
 * @param  string  $code   XLINK SQL 编码
 * @param  array   $param  参数
 * @param  boolean|integer $line   返回第几行，如果全部返回则为false
 * @param  boolean|integer $cloumn 返回第几行的第几列，只有设置了$line才有效
 * @return mixed          返回的结果值
 */
function xlink($code="",$param=array(),$line=false,$cloumn=false)
{
	static $fp,$cfg;
	
	if($cfg===null)
	{
		$CI =& get_instance();
		$cfg=$CI->config->item('xlink');
	}
	if(!$fp)
	{

		@$fp=fsockopen($cfg['server'],$cfg['port'],$errorno,$error_str,5);
		if(!$fp)
		{
			log_message('error','db:无法连接服务器');
			show_error('db:无法连接服务器',500);
		}
	}
    if (is_string($param)) {
        $param = array($param);
    }
	$query=array('code'=>$code,'params'=>array_values($param));
	fwrite($fp,json_encode($query).'/*END*/');

	stream_set_blocking($fp, true);
	stream_set_timeout($fp, 30);
	$response=fread($fp,8192);
	while(strpos($response,'/*END*/')===false)
	{
		$response.=fread($fp,8192);
	}
	$response=substr($response,0,-7);
	$data=json_decode($response,true);



	if($data['result']==false)
	{
		//print_r($data);
		log_message('error','db:'.$data['message']."($code)".serialize($param));
		show_error('db:'.$data['message']."($code)",500);
	}
	if($data['code']!=$code)
	{
		log_message('error',"db:返回编码不一致\trequest code:$code\tresponse code:{$data['code']}");
		show_error('db:返回编码不一致',500);
	}

	$data=$data['data'];

	$op=(int)substr($code,3,1);
	if($op===1 || $op===5)
	{
		$list=$data;
		if($line!==false)
		{
			if(!isset($list[$line]))
			{
				$data= array();
			}
			else
			{
				$arr=$list[$line];
				if($cloumn!==false)
				{
					$arr=array_values($arr);
					if(isset($arr[$cloumn]))
					{
						$data= $arr[$cloumn];
					}
					else
					{
						$data= null;
					}
				}
				else
				{
					$data= $arr;
				}
			}
		}
		else
		{
			$data= $list;
		}
	}
	elseif($op===2)
	{
		return $data[0]['insertId'];
	}
	elseif($op===3 || $op===4)
	{
		return $data[0]['affectedRows'];
	}
	else
	{
		$data=$query;
	}

	return $data;
}


/* End of file xlink_tcp_help.php */
/* Location: ./application/helpers/xlink_tcp_help.php */