<?php

/**
 * 阿里oss
 * @author      mozarlee
 * @time        2017-03-03 11:18:27
 * @created by  Sublime Text 3
 */
namespace App\Helpers;

use OSS\OssClient;
use OSS\OssException;
use OSS\Http\RequestCore;
use OSS\Http\ResponseCore;

class oss_helper
{
    private $access_id; // OSS获得的AccessKeyId>
    private $access_secret; // OSS获得的AccessKeySecret

    private $end_point = 'oss-cn-hangzhou.aliyuncs.com'; // 选定的OSS数据中心访问域名，例如oss-cn-hangzhou.aliyuncs.com> 私有
    // private $end_point = 'oss-cn-hangzhou.aliyuncs.com'; // 选定的OSS数据中心访问域名，例如oss-cn-hangzhou.aliyuncs.com> 私有
    private $bucket = 'panda-exchange'; // 共有
    private $private_bucket = 'panda-exchange'; // 私有
    // private $bucket = 'chengxin'; // 私有

    private $public_end_point = 'oss-cn-hangzhou.aliyuncs.com'; // 选定的OSS数据中心访问域名，例如oss-cn-hangzhou.aliyuncs.com> 公共读
    private $public_bucket = 'panda-exchange';// 公共读
    // private $public_bucket = 'chengxin-public';// 公共读

    function __construct()
    {
        $ossconfig = ossconfig();

        $this->access_id = $ossconfig['AppKey'];
        $this->access_secret = $ossconfig['AppSecretKey'];
        $this->end_point = $ossconfig['Endpoint'];
        $this->bucket = $ossconfig['Bucket'];
        $this->signed_bucket = $ossconfig['Signed_Bucket'];

        // 初始化私有
        $this->oss_client = new OssClient($this->access_id, $this->access_secret, $this->end_point);
        // 初始化公共读
        $this->public_oss_client = new OssClient($this->access_id, $this->access_secret, $this->public_end_point);
    }

    /**
     * 上传图片
     * @return [type] [description]
     */
    public function upload($name,$tmp_name,$type,$is_https=false)
    {
        $upload = array(
            'name' => $name,
            'realPath' => $tmp_name,
            'entension' => $type,
            'is_https' => $is_https,
        );
        // $url = $this->uploadFilePublic($upload);
        $url = $this->uploadFilePrivate($upload);
        return $url;
    }

    public function signe_upload($name,$tmp_name,$type)
    {
        $ossClient = new OssClient($this->access_id,$this->access_secret,$this->end_point); //私有图片
        $file = array(
            'name' => $name,
            'realPath' => $tmp_name,
            'entension' => $type
        );
        $options = array('Content-Type' => 'image/jpeg'); 
        // $url = $this->getSignedUrlForPuttingObject($ossClient,$this->signed_bucket,$file);
        $url = $this->getSignedUrlForPuttingObjectFromFile($ossClient,$this->signed_bucket,$file,$options);
        return $url;
    }

    /**
     * 上传公共读
     * @return [type] [description]
     */
    public function uploadFilePublic($file){
        // 上传公共读
        $img_name = time().mt_rand(1,20000).md5(time()).md5(sha1(time().$file['name'].'.'.$file['entension'])).'.'.'jpg';
        $object = 'chengxin_rz/'.$img_name;

        try{
            // 本地的example.jpg上传到指定$public_bucket, 命名为$object
            $res = $this->public_oss_client->uploadFile($this->public_bucket, $object, $file['realPath']);
            if( isset($res['info']['http_code']) && $res['info']['http_code'] == 200 ){
                return $res['info']['url'];
            }
        } catch(OssException $e) {
            // printf(__FUNCTION__ . ": FAILED\n");
            // printf($e->getMessage() . "\n");
            return null;
        }
    }

    /**
     * 生成GetObject的签名url,主要用于私有权限下的读访问控制
     *
     * @param $ossClient OssClient OssClient实例
     * @param $bucket string 存储空间名称
     * @return null
     */
    public function getSignedUrlForGettingObject($object)
    {
        $ossClient = new OssClient($this->access_id,$this->access_secret,$this->end_point); //私有图片
        $timeout = 3600;
        try {
            $signedUrl = $ossClient->signUrl($this->signed_bucket, $object, $timeout);
        } catch (OssException $e) {
            printf(__FUNCTION__ . ": FAILED\n");
            printf($e->getMessage() . "\n");
            return null;
        }
        return $signedUrl;
    }


    /**
     * 生成PutObject的签名url,主要用于私有权限下的写访问控制
     *
     * @param OssClient $ossClient OssClient实例
     * @param string $bucket 存储空间名称
     * @return null
     * @throws OssException
     */
    function getSignedUrlForPuttingObject($ossClient,$bucket,$file)
    {
        // var_dump($ossClient);die;
        $img_name = time().mt_rand(1,20000).md5($file['name']).'.jpg';
        $object = $img_name;
        $timeout = 3600;
        $options = NULL;
        try {
            $signedUrl = $ossClient->signUrl($bucket, $object, $timeout, "PUT");
        } catch (OssException $e) {
            echo 111;die;
            printf(__FUNCTION__ . ": FAILED\n");
            printf($e->getMessage() . "\n");
            return;
        }
        $content = file_get_contents(__FILE__);
        $request = new RequestCore($signedUrl);
        $request->set_method('PUT');
        $request->add_header('Content-Type', '');
        $request->add_header('Content-Length', strlen($content));
        $request->set_body($content);
        $request->send_request();
        $res = new ResponseCore($request->get_response_header(),
        $request->get_response_body(), $request->get_response_code());
        // var_dump($res);die;
    }


    /**
     * 上传私有
     * @param  [type] $file [description]
     * @return [type]       [description]
     */
    public function uploadFilePrivate($file){
        // 上传私有
        $img_name = time().mt_rand(1,20000).md5($file['name']).'.png';
        $object = 'chengxin_rz/'.$img_name;

        try{
            // 本地的example.jpg上传到指定$public_bucket, 命名为$object
            $res = $this->oss_client->uploadFile($this->bucket, $object, $file['realPath']);
            if( isset($res['info']['http_code']) && $res['info']['http_code'] == 200 ){
                if($file['is_https']) {
                    $arr = explode('://', $res['info']['url']);
                    if($arr[0]=='https')
                    {
                        return $res['info']['url'];
                    }
                    if($arr[0] == 'http')
                    {
                        return 'https://'.$arr[1];
                    }
                }else{
                    return $res['info']['url'];
                }
            }
        } catch(OssException $e) {
            // printf(__FUNCTION__ . ": FAILED\n");
            // printf($e->getMessage() . "\n");
            return null;
        }
    }

    public function uploadCsvFile($filePath,$postsix='.csv',$is_https){
        // echo $filePath;
        // echo $postsix;die;
        $csv_name = time().mt_rand(1,20000).md5($filePath).$postsix;
        $object = 'csv/'.$csv_name;
        try{
            // 本地的example.jpg上传到指定$public_bucket, 命名为$object
            $res = $this->oss_client->uploadFile($this->bucket, $object, $filePath);
            if( isset($res['info']['http_code']) && $res['info']['http_code'] == 200 ){
                if($is_https) {
                    $arr = explode('://', $res['info']['url']);
                    if($arr[0]=='https')
                    {
                        return $res['info']['url'];
                    }
                    if($arr[0] == 'http')
                    {
                        return 'https://'.$arr[1];
                    }
                }else{
                    return $res['info']['url'];
                }
            }
        } catch(OssException $e) {
            return null;
        }

    }



    public function uploadLiFile($filePath,$postsix='.csv',$is_https){
        // echo $filePath;
        // echo $postsix;die;
        $csv_name = time().mt_rand(1,20000).md5($filePath).$postsix;
        $object = 'csv/'.$csv_name;
        try{
            // 本地的example.jpg上传到指定$public_bucket, 命名为$object
            $res = $this->oss_client->uploadFile($this->bucket, $object, $filePath);
            if( isset($res['info']['http_code']) && $res['info']['http_code'] == 200 ){
                if($is_https) {
                    $arr = explode('://', $res['info']['url']);
                    if($arr[0]=='https')
                    {
                        return $res['info']['url'];
                    }
                    if($arr[0] == 'http')
                    {
                        return 'https://'.$arr[1];
                    }
                }else{
                    return $res['info']['url'];
                }
            }
        } catch(OssException $e) {
            return null;
        }

    }

    public function aaa($filename){

        $bucket = Common::getBucketName();
        $ossClient = Common::getOssClient();
        if (is_null($ossClient)) exit(1);

        var_dump($bucket);
        var_dump($ossClient);die;

        $signedUrl = $ossClient->signUrl($bucket, "a.file", "3600", "GET");
        return Common::println($signedUrl);








    }


    /**
     * 生成PutObject的签名url,主要用于私有权限下的写访问控制， 用户可以利用生成的signedUrl
     * 从文件上传文件
     *
     * @param OssClient $ossClient OssClient实例
     * @param string $bucket 存储空间名称
     * @throws OssException
     */
    function getSignedUrlForPuttingObjectFromFile($ossClient,$bucket,$file,$options)
    {
        // $file = __FILE__;
        $img_name = time().mt_rand(1,20000).md5($file['name']).'.jpg';
        $object = $img_name;
        $timeout = 3600;
        try {
            $signedUrl = $ossClient->signUrl($bucket, $object, $timeout, "PUT", $options);
        } catch (OssException $e) {
            printf(__FUNCTION__ . ": FAILED\n");
            printf($e->getMessage() . "\n");
            return;
        }
        $request = new RequestCore($signedUrl);
        $request->set_method('PUT');
        $request->add_header('Content-Type', 'image/jpeg');
        $request->set_read_file($file['realPath']);
        // $request->set_read_stream_size(filesize($file));
        $request->send_request();
        $res = new ResponseCore($request->get_response_header(),
            $request->get_response_body(), $request->get_response_code());
        $result = $res->header;
        return $result['info']['url'];
    }


    public function aaa1($filename,$tmp_name){
        // 存储空间名称
        $bucket= $this->bucket;
        // 文件名称
        $object = $filename;
        // <yourLocalFile>由本地文件路径加文件名包括后缀组成，例如/users/local/myfile.txt
        $filePath = $tmp_name;

        try{
            $ossClient = new OssClient($this->access_id, $this->access_secret, $this->end_point);
            $url = $ossClient->uploadFile($bucket, $object, $filePath);
        } catch(OssException $e) {
            printf(__FUNCTION__ . ": FAILED\n");
            printf($e->getMessage() . "\n");
            return;
        }

        return $url;
    }



}
