<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * [xlink 接口封装函数]
 * @param  string  $code   XLINK SQL 编码
 * @param  array   $param  参数
 * @param  boolean|integer $line   返回第几行，如果全部返回则为false
 * @param  boolean|integer $cloumn 返回第几行的第几列，只有设置了$line才有效
 * @return mixed          返回的结果值
 */
function xlink($code="",$param=array(),$line=false,$cloumn=false)
{
	// echo $code;die;
	static $sql_code_list=null;
	$CI =& get_instance();
	if($sql_code_list===null)
	{
		$CI->config->load("sqlcode",TRUE);
		$sql_code_list=$CI->config->item('sqlcode');
	}
	$sql=$sql_code_list[$code];


	if(is_array($param) && sizeof($param)>0)
	{
		$k=1;
		$one_and_one=strpos($sql,'1=1');
		foreach($param as $_param)
		{
			if($one_and_one!==false && $_param===null)
			{
				$sql=preg_replace("~((and|or)\s*)*(\w+\.)?\`\w*\`\s*(([=><!]+)|((\s*not\s*)?like)|((\s*not\s*)?in))\s*\[\:$k\]~i",' ',$sql);
			}
			else
			{
				$sql=str_replace("[:$k]",$CI->db->escape($_param),$sql);
			}
			
			$k++;			
		}
	}
	elseif(is_string($param) && strlen($param)>0)
	{
		$sql=str_replace("[:1]",$CI->db->escape($param),$sql);
	}
	$query=$CI->db->query($sql);
	$op=(int)substr($code,3,1);

	// var_dump($op);die;

	// 1:select 2:insert 3:update 4:delete 5:else
	if($op===1 || $op===5)
	{
		$list=$query->result_array();
		if($line!==false)
		{
			if(!isset($list[$line]))
			{
				$data= array();
			}
			else
			{
				$arr=$list[$line];
				if($cloumn!==false)
				{
					$arr=array_values($arr);
					if(isset($arr[$cloumn]))
					{
						$data= $arr[$cloumn];
					}
					else
					{
						$data= null;
					}
				}
				else
				{
					$data= $arr;
				}
			}
		}
		else
		{
			$data= $list;
		}
	}
	elseif($op===2)
	{
		$data= $CI->db->insert_id();
	}
	elseif($op===3 || $op===4)
	{
		$data= $CI->db->affected_rows();
	}
	else
	{
		$data=$query;
	}
	if(strtoupper(substr($sql,0,4))=='CALL')
	{
		$query->free_result();#如果存储过程，则释放查询
	}
	return $data;
}

/* End of file xlink_db_help.php */
/* Location: ./application/helpers/xlink_db_help.php */
