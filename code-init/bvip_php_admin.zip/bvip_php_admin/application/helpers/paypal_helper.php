<?php
/**
 * Created by PhpStorm.
 * User: 63039
 * Date: 2018/2/3
 * Time: 18:05
 */

defined('BASEPATH') OR exit('No direct script access allowed');
use \PayPal\Api\Payer;
use \PayPal\Api\Item;
use \PayPal\Api\ItemList;
use \PayPal\Api\Details;
use \PayPal\Api\Amount;
use \PayPal\Api\Transaction;
use \PayPal\Api\RedirectUrls;
use \PayPal\Api\Payment;
use \PayPal\Exception\PayPalConnectionException;
use \PayPal\api\MerchantPreferences;

class paypal_helper extends CI_Controller{

    const CLIENT_ID = CLIENT_ID;
    const PAL_SECRET = PAY_SECRET;
    const PAY_TYPE = PAY_TYPE;
    //public static $apiContext ;

    /*
     * @param $price  int 价格
     * @param $order_no string 订单号
     * @param $product_name     string  产品名
     * return  url
     */
    public static function doPaypal($price,$order_no,$product_name,$domain,$status=false)
    {
        $apiContext = new \PayPal\Rest\ApiContext(
            new \PayPal\Auth\OAuthTokenCredential(
                self::CLIENT_ID,     // ClientID
                self::PAL_SECRET     // ClientSecret
            )
        );

        $shipping = 0; //运费
        $desc = 'paypal支付';//支付描述内容
        $total = $price + $shipping;

        $payer = new Payer();
        $payer->setPaymentMethod('paypal');

        $item = new Item();
        $item->setName($product_name)
            ->setCurrency(self::PAY_TYPE)
            ->setQuantity(1)
            ->setPrice($price);

        $itemList = new ItemList();
        $itemList->setItems([$item]);

        $details = new Details();
        $details->setShipping($shipping)
            ->setSubtotal($price);

        $amount = new Amount();
        $amount->setCurrency(self::PAY_TYPE)
            ->setTotal($total)
            ->setDetails($details);

        $transaction = new Transaction();
        $transaction->setAmount($amount)
            ->setItemList($itemList)
            ->setDescription($desc)
            ->setInvoiceNumber($order_no);

        $redirectUrls = new RedirectUrls();

        if($status){
            $redirectUrls->setReturnUrl($domain.'pay_return/return_transfer_url?success=true')
                ->setCancelUrl($domain.'pay_return/return_transfer_url?success=false');
        }else{
            $redirectUrls->setReturnUrl($domain.'pay_return/return_url?success=true')
                ->setCancelUrl($domain.'pay_return/return_url?success=false');
        }


        $payment = new Payment();
        $payment->setIntent('sale')
            ->setPayer($payer)
            ->setTransactions(array($transaction))
            ->setRedirectUrls($redirectUrls);
           // ->setRedirectUrls($merchantPreferences);

        try {
            $payment->create($apiContext);
        } catch (PayPalConnectionException $e) {
            echo $e->getData();
            die();
        }

        $approvalUrl = $payment->getApprovalLink();
        return $approvalUrl;
    }

}