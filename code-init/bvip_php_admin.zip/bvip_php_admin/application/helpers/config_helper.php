<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 短信限制开关
 *
 *
 * @access	public
 * @param	type	name
 * @return	type	
 */
 
if (! function_exists('sms_limit_swith'))
{
	function sms_limit_swith()
	{
		$CI = &get_instance();
		$CI->load->config('sms',true);
		$limit_turn = $CI->config->item('limit_turn','sms');
		if($limit_turn == "on")
		{
			//开
			return true;
		}
		return false;
	}
}

/*
 * 生成订单号
 * @author zc
 * return string
 */

if (! function_exists('get_orderno'))
{
function get_orderno(){
    $order_no = date('YmdHis').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 4);
    return $order_no;
}
}