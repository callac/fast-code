<?php
/**
 * Created by PhpStorm.
 * User: 63039
 * Date: 2018/4/23
 * Time: 19:56
 */

// +----------------------------------------------------------------------
// | JuhePHP [ NO ZUO NO DIE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2010-2015 http://juhe.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: Juhedata <info@juhe.cn-->
// +----------------------------------------------------------------------

//----------------------------------
// 汇率调用示例代码 － 聚合数据
// 在线接口文档：http://www.juhe.cn/docs/80
//----------------------------------

header('Content-type:text/html;charset=utf-8');
class juhe_helper extends CI_Controller
{
    //配置您申请的appkey
    private static $appkey = 'a4839ab40f4e56b2e59b60f7cd6e35bb';
    public static function xx($balance){
        get_site_info();
    }

    //************1.常用汇率查询************
    public static function juhe_often(){

        $url = "http://op.juhe.cn/onebox/exchange/query";
        $params = array(
            "key" => self::$appkey,//应用APPKEY(应用详细页查询)
        );
        $paramstring = http_build_query($params);
        $content = self::juhecurl($url,$paramstring);
        $result = json_decode($content,true);
        if($result){
            if($result['error_code']=='0'){
                print_r($result);
            }else{
                echo $result['error_code'].":".$result['reason'];
            }
        }else{
            echo "请求失败";
        }
//**************************************************









    }

    //************2.货币列表************
    public static function juhe_list(){
        $url = "http://op.juhe.cn/onebox/exchange/list";
        $params = array(
            "key" => self::$appkey,//应用APPKEY(应用详细页查询)
        );
        $paramstring = http_build_query($params);
        $content = self::juhecurl($url,$paramstring);
        $result = json_decode($content,true);
        if($result){
            if($result['error_code']=='0'){
                print_r($result);
            }else{
                echo $result['error_code'].":".$result['reason'];
            }
        }else{
            echo "请求失败";
        }
    }

    /*
     * 实时汇率查询换算
     * @pram  float     转换金额
     * @pram  string    转换汇率前的货币代码
     * @pram  string 	转换汇率成的货币代码
     * return  $balance
     * */
    public static function juhe_from_to($balance ,$from,$key){
        if(!$balance || !is_numeric($balance)) return false;
        if($from == $key) {
            $data['currencyT_Name'] ='元';
            $data['balance'] = 1;
            return $data;
        }
        $url = "http://op.juhe.cn/onebox/exchange/currency";
        $params = array(
            "from" => $from,//转换汇率前的货币代码
            "to" => $key,//转换汇率成的货币代码
            "key" => self::$appkey,//应用APPKEY(应用详细页查询)
        );
        $paramstring = http_build_query($params);
        $content = self::juhecurl($url,$paramstring);
        $result = json_decode($content,true);
        if($result){
            if($result['error_code']=='0'){
                //成功
                $result = $result['result'][0];
                $exchange = $result['exchange']; //汇率
                if(!$exchange) return false;
                $balance =  round($balance*$exchange,2);
                $data['currencyT_Name'] =$result['currencyF_Name'];
                $data['balance'] = $balance;
                return $data;
            }else{
                //失败
                return false;
            }
        }else{
            return false;
        }
    }

    /**
     * 请求接口返回内容
     * @param  string $url [请求的URL地址]
     * @param  string $params [请求的参数]
     * @param  int $ipost [是否采用POST形式]
     * @return  string
     */
    public static function  juhecurl($url,$params=false,$ispost=0){
        $httpInfo = array();
        $ch = curl_init();

        curl_setopt( $ch, CURLOPT_HTTP_VERSION , CURL_HTTP_VERSION_1_1 );
        curl_setopt( $ch, CURLOPT_USERAGENT , 'JuheData' );
        curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT , 60 );
        curl_setopt( $ch, CURLOPT_TIMEOUT , 60);
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER , true );
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        if( $ispost )
        {
            curl_setopt( $ch , CURLOPT_POST , true );
            curl_setopt( $ch , CURLOPT_POSTFIELDS , $params );
            curl_setopt( $ch , CURLOPT_URL , $url );
        }
        else
        {
            if($params){
                curl_setopt( $ch , CURLOPT_URL , $url.'?'.$params );
            }else{
                curl_setopt( $ch , CURLOPT_URL , $url);
            }
        }
        $response = curl_exec( $ch );
        if ($response === FALSE) {
            //echo "cURL Error: " . curl_error($ch);
            return false;
        }
        $httpCode = curl_getinfo( $ch , CURLINFO_HTTP_CODE );
        $httpInfo = array_merge( $httpInfo , curl_getinfo( $ch ) );
        curl_close( $ch );
        return $response;
    }
}







