<?php
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class excel_helper extends CI_Controller
{

    /**
     * 获取列表
     * @param array  $title    excel标题
     * @param array  $content  excel内容
     * @param string  $type    excel类型
     * @return string
     */
    public static function print_excel($title,$content,$type)
    {
        foreach ($content as $val){
            if( count($val) !=count($title))return false;
            break;
        }
        try {
            $spreadsheet = new Spreadsheet();
            $arrayData[0] = $title;
            $arrayData = array_merge($arrayData,$content);
            $spreadsheet->getActiveSheet() ->fromArray(
                $arrayData,  // The data to set
                '',        // Array values with this value will not be set
                'A1',         // Top left coordinate of the worksheet range where
                 \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING
            //    we want to set these values (default is A1)
            );

            $writer = new Xlsx($spreadsheet);
            // $excel_name = '/application/cache/excel/'.$type.'_'.date('YmdHis',time()).'.xlsx';
            $excel_name = APPPATH.'cache/excel/'.$type.'_'.date('Ymd',time()).'.xlsx';
            $writer->save($excel_name);
            return $excel_name;
        } catch(\PhpOffice\PhpSpreadsheet\Reader\Exception $e) {
            die('Error loading file: '.$e->getMessage());
        }

    }
}
