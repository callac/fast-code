<?php
/* *
 * 类名：ChuanglanSmsApi
 * 功能：创蓝接口请求类
 * 详细：构造创蓝短信接口请求，获取远程HTTP数据
 * 版本：1.3
 * 日期：2016-07-16
 * 说明：
 * 以下代码只是为了方便客户测试而提供的样例代码，客户可以根据自己网站的需要，按照技术文档自行编写,并非一定要使用该代码。
 * 该代码仅供学习和研究创蓝接口使用，只是提供一个参考。
 */
header("Content-type:text/html; charset=UTF-8");

class sms_helper {

	//创蓝发送短信接口URL, 如无必要，该参数可不用修改
	const API_SEND_URL='http://smssh1.253.com/msg/send/json';

	//创蓝发送变量短信接口URL, 如无必要，该参数可不用修改
	const API_VARIABLE_URL='http://smssh1.253.com/msg/balance/json';

	const API_ACCOUNT='N206300_N7156705';//创蓝账号 替换成你自己的账号

	const API_PASSWORD='r4ODYboRE5f63b';//创蓝密码 替换成你自己的密码

	/**
	 * 发送短信
	 *
	 * @param string $mobile 		手机号码
	 * @param string $msg 			短信内容
	 * @param string $needstatus 	是否需要状态报告
	 */
	public static function sendSMS( $mobile, $replacement,$site_id,$uniqueid = 'general', $needstatus = 'true') {
		global $chuanglan_config;

        $CI =& get_instance();
        $CI->load->library('email');
        $CI->load->model('Mail_queue_model');
        $CI->load->model('Mail_tpl_model');
        $tpl = $CI->Mail_tpl_model->get($uniqueid,$site_id);
        if(!$tpl){
            return false;
        }
        $content = $tpl['content'];
        foreach ($replacement as $search => $replace) {
            $content = str_replace("{" . $search . "}", $replace, $content);
        }

        $title = $tpl['title'];
        foreach ($replacement as $search => $replace) {
            $title = str_replace("{" . $search . "}", $replace, $title);
        }
		
		//创蓝接口参数
		$postArr = array (
			'account'  =>  self::API_ACCOUNT,
			'password' => self::API_PASSWORD,
			'msg' => urlencode($content),
			'phone' => $mobile,
			'report' => $needstatus
        );

        // var_dump($postArr);die;
		
		$result = self::curlPost( self::API_SEND_URL , $postArr);
		// return false;
		return $result;
	}
	
	/**
	 * 发送变量短信
	 *
	 * @param string $msg 			短信内容
	 * @param string $params 	最多不能超过1000个参数组
	 */
	public function sendVariableSMS( $msg, $params) {
		global $chuanglan_config;
		
		//创蓝接口参数
		$postArr = array (
			'account'  =>  self::API_ACCOUNT,
			'password' => self::API_PASSWORD,
			'msg' => urlencode($msg),
			'phone' => $mobile,
			'report' => $needstatus
        );
		
		$result = $this->curlPost( self::API_VARIABLE_URL , $postArr);
		return $result;
	}
	
	
	/**
	 * 查询额度
	 *
	 *  查询地址
	 */
	public function queryBalance() {
		global $chuanglan_config;
		
		//查询参数
		$postArr = array ( 
		    'account' => $chuanglan_config['api_account'],
		    'password' => $chuanglan_config['api_password'],
		);
		$result = $this->curlPost($chuanglan_config['api_balance_query_url'], $postArr);
		return $result;
	}

	/**
	 * 通过CURL发送HTTP请求
	 * @param string $url  //请求URL
	 * @param array $postFields //请求参数 
	 * @return mixed
	 */
	private static function curlPost($url,$postFields){
		$postFields = json_encode($postFields);
		$ch = curl_init ();
		curl_setopt( $ch, CURLOPT_URL, $url ); 
		curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json; charset=utf-8'
			)
		);
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt( $ch, CURLOPT_POST, 1 );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt( $ch, CURLOPT_TIMEOUT,1); 
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0);
		$ret = curl_exec ( $ch );
        if (false == $ret) {
            $result = curl_error(  $ch);
        } else {
            $rsp = curl_getinfo( $ch, CURLINFO_HTTP_CODE);
            if (200 != $rsp) {
                $result = "请求状态 ". $rsp . " " . curl_error($ch);
            } else {
                $result = $ret;
            }
        }
		curl_close ( $ch );
		return $result;
	}
}
?>
