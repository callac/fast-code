<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CODE 编码规则
 * 第1-3位 模块  100 系统配置 101 用户 102 
 * 第 4 位 1:SELECT 2:insert 3:update 4:delete 5:else
 * 第5-6位 顺序编码
 */

$config['100100']="SELECT SUM(A.paid_amount) as total_paid_amount,B.hash_total,B.id,B.`reckon_amount`,B.`payable_time`,B.`compute_time`,B.`mine_amount`,B.`electricity_fees`,B.`mine_user`,B.`mine_time`,B.`apportion_time`,B.`audit_user`,B.`audit_time`,B.`distribution_user`,B.`distribution_time`,B.`status`,B.`btc_price`,B.`product_hash_type`,B.`bdc_message_id`,B.`site_id`,B.`procedure_fee`,B.`assign_type`,B.`trust_fee`
FROM `b_user_hash_income_details` A
LEFT JOIN b_user_hash_income B
ON A.hash_income_id=B.id
WHERE 1=1 
AND B.`assign_type` = [:3]
AND B.`product_hash_type` = [:4] 
GROUP BY A.hash_income_id
ORDER BY B.id DESC LIMIT [:2],[:1]";

$config['100101']="SELECT COUNT(*) FROM `b_user_hash_income` WHERE `assign_type` = [:1] AND `product_hash_type` = [:2]";#算力每日收益总表 统计条数 hash_income_count
$config['100102']="SELECT * FROM `b_user_hash_income` WHERE  `id` = [:1] ";#算力每日收益总表 获取单条记录 get_data_by_id
$config['100300']="UPDATE `b_user_hash_income` SET `mine_amount`=[:3],`mine_user`=[:4],`mine_time`=[:5],`status`=[:6],`btc_price`=[:2] WHERE  `id` = [:1] AND `status` = 0 ";#算力每日收益总表 修改 update_hash_income
$config['100301']="UPDATE `b_user_hash_income` SET `electricity_fees`=[:3],`trust_fee`=[:4],`procedure_fee`=[:5],`status`=[:2],`apportion_time`=[:6] WHERE  `id` = [:1]";#算力每日收益总表 修改 update_hash_income
$config['100302']="UPDATE `b_user_hash_income` SET `audit_user`=[:2],`audit_time`=[:3],`status`=[:4] WHERE `id` = [:1]";#算力每日收益总表 修改 check_access
$config['100303']="UPDATE `b_user_hash_income` SET `status`=[:2] WHERE  `id` = [:1] ";#算力每日收益总表 修改 change_status
$config['100304']="UPDATE `b_user_hash_income` SET `distribution_user`=[:2],`distribution_time`=[:3],`status`=[:4] WHERE `id` = [:1]";#算力每日收益总表 修改 check_access

//b_user_hash_income_details
$config['101100']="SELECT a.*,b.`assign_id`,b.`product_id` FROM `b_user_hash_income_details` a,`b_order_hash` b WHERE 1=1 AND  a.`hash_income_id` = [:1] AND a.`order_hash_id` = b.`id`";
$config['101300']="UPDATE `b_user_hash_income_details` SET `payable_amount`=[:2],`electric_fee`=[:3],`trust_fee`=[:4],`procedure_fee`=[:5] WHERE  `id` = [:1] ";#算力每日收益总表 修改 update_info
$config['101301']="UPDATE `b_user_hash_income_details` SET `status`=[:2] WHERE `hash_income_id` = [:1] ";#算力每日收益总表 修改 check_access
$config['101302']="UPDATE `b_user_hash_income_details` SET `status`=[:2],`paid_amount`=[:3],`paid_time`=[:4] WHERE `id` = [:1] ";#算力每日收益总表 修改 check_access

//b_product_hash
$config['102100']="SELECT a.*,b.`hash`FROM `b_product_hash` a,`b_product_hash_base` b WHERE  1=1 AND a.`id` = [:1] AND `site_id`=[:2] AND a.`product_base_id` = b.`id`";
//b_transfer_product_hash
$config['103100']="SELECT a.*,b.`hash` FROM `b_transfer_product_hash` a,`b_product_hash_base` b WHERE  1=1 AND a.`id` = [:1] AND `site_id`=[:2] AND a.`product_base_id` = b.`id`";
//b_user_ext
$config['104300']="UPDATE `b_user_ext` SET `coin_account` = `coin_account` + [:2] WHERE  `user_id` = [:1] AND `type` = [:3] ";#算力每日收益总表 修改 check_access
//b_order_hash
$config['105300']="UPDATE `b_order_hash` SET `realized_income_value` = `realized_income_value` + [:2] WHERE  `id` = [:1] ";#算力每日收益总表 修改 check_access
$config['105301']="UPDATE `b_order_hash` SET `status`=4 WHERE  1=1 AND `product_id`=[:1] AND `assign_id`=0 ";

//b_coin_balance
$config['106100']="SELECT FROM_UNIXTIME(mine_time ,'%Y-%m-%d') as time ,SUM(total_balance) as total_balance,hash_type FROM `b_coin_balance`  GROUP BY time,hash_type";
$config['106101']="SELECT *,FROM_UNIXTIME(mine_time ,'%Y-%m-%d') as time FROM `b_coin_balance` WHERE 1=1 AND `mine_time`>[:1] AND `mine_time` <[:2] ";
$config['106102']="SELECT `id`,`electricity_fees`,`trust_fee`,`procedure_fee`,`assign_type`,`product_hash_type`,FROM_UNIXTIME(payable_time ,'%Y-%m-%d') as time FROM `b_user_hash_income` a WHERE 1=1 AND `payable_time`>[:1] AND `payable_time` <[:2] AND product_hash_type=[:3]";
$config['106103']="SELECT SUM(paid_amount) as paid_amount FROM `b_user_hash_income_details` WHERE `hash_income_id`=[:1] ";
$config['106104']="SELECT * FROM `b_block_address` WHERE `hash_type`=[:1] ";

$config['106200']="INSERT INTO `b_coin_balance`(`total_balance`,`cold_balance`,`hot_balance`,`block_balance`,`slb_balance`,`buy_balance`,`mine_time`,`hash_type`,`create_time`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])";#公司账户币余额 添加 add
$config['106300']="UPDATE `b_coin_balance` SET `total_balance`=[:2],`cold_balance`=[:4],`hot_balance`=[:3],`block_balance`=[:5],`slb_balance`=[:6],`buy_balance`=[:7]  WHERE  `id` = [:1] ";#公司账户币余额 修改 update
//b_paid_income
$config['107100']="SELECT *,FROM_UNIXTIME(mine_time ,'%Y-%m-%d') as time FROM `b_paid_income` WHERE 1=1 AND `mine_time`>[:1] AND `mine_time` <[:2] ";
$config['107101']="SELECT *,FROM_UNIXTIME(mine_time ,'%Y-%m-%d') as time FROM `b_paid_income` WHERE 1=1 AND `hash_type`=[:1] ORDER BY mine_time desc LIMIT 1 ";
$config['107200']="INSERT INTO `b_paid_income`(`total_income`,`paid_income`,`withdraw_btc`,`trust_fee`,`procedure_fee`,`electric_fee`,`mine_time`,`hash_type`,`create_time`,`assign_type`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])";#派发收益总表 添加 add

$config['107300']="UPDATE `b_paid_income` SET `total_income`=[:2],`paid_income`=[:3],`withdraw_btc`=[:4],`trust_fee`=[:5],`procedure_fee`=[:6],`electric_fee`=[:7] WHERE  `id` = [:1] ";#派发收益总表 修改 update
//b_account_btc_withdraw_log
$config['108100']="SELECT SUM(`amount` - `fee`) as amount FROM `b_account_btc_withdraw_log` WHERE 1=1 AND `product_hash_type`=[:3] AND `pay_time`>[:1] AND `pay_time`<[:2]";

//b_paid_explain
$config['109100']="SELECT *,FROM_UNIXTIME(mine_time ,'%Y-%m-%d') as time FROM `b_paid_explain` WHERE 1=1 AND `mine_time`>[:1] AND `mine_time` <[:2] ";
$config['109101']="SELECT *,FROM_UNIXTIME(mine_time ,'%Y-%m-%d') as time FROM `b_paid_explain` WHERE `id`=[:1]";
$config['109200']="INSERT INTO `b_paid_explain`(`coin_explain`,`btc_explain`,`eth_explain`,`ltc_explain`,`mine_time`,`create_time`) VALUES([:1],[:2],[:3],[:4],[:5],[:6])";#每日报表说明表 添加 add
$config['109300']="UPDATE `b_paid_explain` SET `coin_explain`=[:2],`btc_explain`=[:3],`eth_explain`=[:4],`ltc_explain`=[:5] WHERE 1=1 AND `id` = [:1]";


//短信模板

$config['202188'] = 'select * from `b_mail_tpl` WHERE 1=1 AND `uniqueid`=[:1] AND `site_id`=[:2] LIMIT 0,1';
/**
 * 个人中心
 */

//张鹏飞
//产品信息 201
$config['201101'] = 'select a.`id`,a.`name` as product_name,a.`unit`,a.`amount`,a.`buyed_amount`,a.`one_amount_value`,a.is_top,a.is_loan,a.status,a.income_start_time,a.income_start_time,b.name as product_type_name from `b_product_hash` as a LEFT JOIN `b_product_hash_type` as b ON a.`product_hash_type` = b.`id`  WHERE 1=1 AND a.`site_id` = [:3]  ORDER BY `status` ASC LIMIT [:1],[:2]'; //产品列表
$config['201102'] = 'select count(*) from `b_product_hash` WHERE 1=1 AND  `site_id`=[:1] ';
$config['202103'] = 'select * from `b_product_hash` WHERE 1=1 AND  `id`=[:1] AND `site_id`=[:2]'; //产品详情
$config['202105'] = 'select `name`,`id`,`site_id` from `b_product_hash_type` WHERE 1=1 AND `site_id`=[:1]'; //产品分类
$config['201401'] = 'DELETE FROM runoob_tbl WHERE  1=1 AND `runoob_id`=[:]';
$config['203201'] = 'INSERT INTO `b_product_hash`(`name`,`product_hash_type`,`unit`,`amount`,`one_amount_value`,`buy_min_amount`,`powerRate`,`maintenance`,`income_start_time`,`income_end_time`,`sell_start_time`,`sell_end_time`,`income_start_mode`,`is_loan`,`is_top`,`status`,`site_id`,`description`,`product_base_id`,`create_time`,`contract_ids`,`contract_host_ids`,`miningPower`,`miningModel`,`assign_type`,`birth_time`,`minepoolFee`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19],[:20],[:21],[:22],[:23],[:24],[:25],[:26],[:27])';//
$config['203301'] = 'UPDATE `b_product_hash` SET `name`=[:2],`product_hash_type`=[:3],`unit`=[:4],`amount`=[:5],`one_amount_value`=[:6],`buy_min_amount`=[:7],`powerRate`=[:8],`maintenance`=[:9],`income_start_time`=[:10],`income_end_time`=[:11],`sell_start_time`=[:12],`sell_end_time`=[:13],`income_start_mode`=[:14],`is_loan`=[:15],`is_top`=[:16],`status`=[:17],`site_id`=[:18],`description`=[:19],`contract_ids`=[:20],`contract_host_ids`=[:21],`miningPower`=[:22],`miningModel`=[:23],`assign_type`=[:24],`minepoolFee`=[:25] where `id`=[:1]';//
$config['201304'] = 'update `b_product_hash` SET `status`=[:2] where `id`=[:1]';
$config['202114'] = 'select a.*,b.product_img,b.hash,c.three_stage_fee,c.six_stage_fee,c.twelve_stage_fee,c.type as loan_type,c.installment_proportion,c.overdue_fee from `b_product_hash` as a LEFT JOIN `b_product_hash_base` as b ON a.product_base_id = b.id LEFT JOIN `product_loan` as c ON a.id = c.product_id  WHERE 1=1 AND a.`id`=[:1]';
$config['203209'] = 'INSERT INTO `b_product_hash_base`(`hash`,`modify_time`,`batch_area`,`producer`,`site_id`,`product_img`) VALUES([:1],[:2],[:3],[:4],[:5],[:6])';//
$config['201308'] = 'update `b_product_hash_base` SET `hash`=[:2],`batch_area` = [:3],`producer`=[:4],`product_img`=[:5] where `id`=[:1]';
$config['200116'] = 'SELECT SUM(a.buy_amount*c.hash) FROM `b_order_hash` as a LEFT JOIN `b_product_hash` as b ON a.product_id=b.id LEFT JOIN `b_product_hash_base` as c ON b.product_base_id=c.id WHERE 1=1  AND a.`assign_id` =0  AND a.`pay_success_time`>[:1] AND  a.`pay_success_time` <[:2]  AND a.`status` in(2,5,6,7,8) GROUP BY a.id  ';
$config['200118'] = 'SELECT SUM(a.buy_amount*c.hash) FROM `b_order_hash` as a LEFT JOIN `b_product_hash` as b ON a.product_id=b.id LEFT JOIN `b_product_hash_base` as c ON b.product_base_id=c.id WHERE 1=1  AND a.`assign_id` =0   AND a.`status` in(2,5,6,7,8)    ';





//b_site_domin
$config['202101'] = 'select b_site_domain.name as domain,b_site.privilages,b_site_domain.site_id,b_site.name,b_site.logo,b_site.logo_a,b_site.style,b_site.language,b_site.is_close from `b_site_domain`,`b_site` WHERE  1=1 AND b_site_domain.`name`=[:1] and b_site_domain.`site_id` = b_site.id'; //get_data_by_user_id
$config['202102'] = 'select `name` from b_site_domain WHERE 1=1 AND `site_id`=[:1]';
$config['202104'] = 'select *  from b_site_domain WHERE 1=1 ';
$config['202113'] = 'select `id`,`name`,`site_name`  from b_site_domain WHERE 1=1 AND `site_id`=[:1]' ;
$config['202106'] = 'select a.*,a.name as site_name,c.username,c.truename as domain_user,c.email,c.mobile as domain_userphone from `b_site` as a  LEFT JOIN  `b_site_admin` as c  ON a.`id` = c.`site_id` WHERE 1=1 AND a.`name`=[:3] order by a.id ASC LIMIT [:1],[:2]';
$config['202107'] = 'select count(*)  from `b_site` WHERE 1=1 AND `name`=[:1]';
$config['202108'] = 'select *  from `b_site_roles`';
$config['202109'] = 'select `name`,`id` from `b_site`';
$config['202131'] = 'select `name`,`id` from `b_site` where id = [:1]';
$config['202110'] = 'select *  from `b_site_admin` WHERE 1=1 AND `username` = [:1]';

$config['202123'] = 'select a.*,a.name as site_name,c.username,c.truename as domain_user,c.email,c.mobile as domain_userphone from `b_site` as a  LEFT JOIN  `b_site_admin` as c  ON a.`id` = c.`site_id` WHERE 1=1 AND a.`name`=[:3] and a.`id`=[:4]  LIMIT [:1],[:2]';

$config['203202'] = 'INSERT INTO `b_site`(`name`,`title`,`logo`,`icon`,`style`,`language`,`privilages`,`remark`,`asset_type`,`symbol_type`,`service_email`,`service_js`,`tongji_js`,`ios_url`,`android_url`,`qq`,`udesk_js`,`udesk_key`,`identity_method`,`recommend_code_force`,`default_register_method`,`seo_title`,`seo_keywords`,`seo_content`,`otc_asset`,`otc_currency`,`settlement_percent`,`ts_status`,`ws_status`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19],[:20],[:21],[:22],[:23],[:24],[:25],[:26],[:27],[:28],[:29])';//
$config['203203'] = 'INSERT INTO `b_site_domain`(`name`,`site_name`,`site_id`) VALUES([:1],[:2],[:3])';//
$config['203204'] = 'INSERT INTO `b_site_admin`(`site_id`,`username`,`truename`,`password`,`email`,`mobile`) VALUES([:1],[:2],[:3],[:4],[:5],[:6])';//
$config['201201'] = 'update `b_site` set `name`=[:2],`title`=[:3],`logo`=[:4],`icon`=[:5],`style`=[:6],`language`=[:7],`privilages`=[:8],`remark`=[:9],`asset_type`=[:10],`symbol_type`=[:11],`service_email`=[:12],`service_js`=[:13],`tongji_js`=[:14],`ios_url`=[:15],`android_url`=[:16],`qq`=[:17],`udesk_js`=[:18],`udesk_key`=[:19],`identity_method`=[:20],`recommend_code_force`=[:21],`default_register_method`=[:22],`seo_title`=[:23],`seo_keywords`=[:24],`seo_content`=[:25],`otc_asset`=[:26],`otc_currency`=[:27],`settlement_percent`=[:28],`ts_status`=[:29],`ws_status`=[:30] where `id`=[:1]';
$config['201202'] = 'update `b_site_domain` set `name`=[:2],`site_name`=[:3] where `id`=[:1]';
$config['201203'] = 'update `b_site_admin` set `username`=[:2],`truename`=[:3],`password`=[:4],`email`=[:5],`mobile`=[:6] where `site_id`=[:1]';
$config['201403'] = 'delete FROM `b_site_domain` where `id` = [:1]';
$config['201407'] = 'delete FROM `b_site_domain` where 1=1 AND `site_id` = [:1]';
$config['201413'] = 'delete FROM `b_site` where 1=1 AND `id` = [:1]';
$config['201414'] = 'delete FROM `b_site_admin` where 1=1 AND `site_id` = [:1]';
$config['201313'] = 'update `b_site` set `is_close`=[:2] where `id`=[:1]';
$config['202130'] = 'select *  from `b_site_base` WHERE 1=1 AND `type` = [:1]';
$config['202134'] = 'select *  from `b_company_bank_message` WHERE 1=1 AND `site_id` = [:1]';
$config['201315'] = 'update `b_company_bank_message` set `subject`=[:2],`opening_bank`=[:3],`bankcard_number`=[:4] where 1=1 AND  `site_id`=[:1]';
$config['203212'] = 'INSERT INTO `b_company_bank_message`(`site_id`,`subject`,`opening_bank`,`bankcard_number`) VALUES([:1],[:2],[:3],[:4])';

//分期
$config['203211'] = 'INSERT INTO `product_loan`(`three_stage_fee`,`six_stage_fee`,`twelve_stage_fee`,`type`,`installment_proportion`,`overdue_fee`,`product_id`,`site_id`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';//
$config['201311'] = 'update `product_loan` set `three_stage_fee`=[:2],`six_stage_fee`=[:3],`twelve_stage_fee`=[:4],`type`=[:5],`installment_proportion`=[:6],`overdue_fee`=[:7],`site_id`=[:8] where `product_id`=[:1]';
$config['202133'] = 'select *  from `product_loan` WHERE 1=1 AND `product_id` = [:1] AND `site_id`=[:2]';


//用户user
$config['201111'] = 'select a.*,b.`bank`,b.`card_no`,invite_user.email as invite_email,invite_user.mobile as invite_mobile,d.name as site_name from `b_user` as a LEFT JOIN `b_unionpay_bind_card_log` as b ON a.id = b.user_id LEFT JOIN `b_user_invite` as c ON a.id = c.invite_id LEFT JOIN  `b_user` as invite_user  ON c.user_id=invite_user.id LEFT JOIN `b_site` as d ON  a.site_id=d.id  where 1=1 AND a.`id` = [:1]';
$config['201301'] = 'update `b_user` set forbid_login=[:2] where 1=1 AND `id`=[:1]';
$config['201302'] = 'update `b_user` set forbid_withdraw=[:2] where 1=1 AND `id`=[:1]';
$config['201303'] = 'update `b_user` set forbid_trade=[:2] where 1=1 AND `id`=[:1]';
$config['201316'] = 'update `b_user` set api_token=[:2] where 1=1 AND `id`=[:1]';
$config['201112'] = 'select `address`,`islock`   from `b_account_btc_bind_address` WHERE 1=1 AND `user_id`=[:1] AND `status`=0 ';
$config['201113'] = 'select `post_addr`,`is_default`   from `b_user_post_addr` WHERE 1=1 AND `user_id`=[:1] AND `status`=0 ';
$config['201114'] = 'select a.`coin_account`,a.`freeze_coin_withdraw_account`,b.`name` as type_name   from `b_user_ext` as a LEFT JOIN `b_product_hash_type` as b ON a.`type` = b.`id`  WHERE 1=1 AND a.`user_id`=[:1]';
$config['201115'] = 'select sum(a.`paid_amount`) as  paid_amount,b.`name` from `b_user_hash_income_details` as a  LEFT JOIN `b_product_hash_type` as b ON a.`product_hash_type` = b.`id` WHERE 1=1 AND a.`user_id`=[:1]  AND a.`status` = 2 GROUP BY `product_hash_type`' ;
$config['201116'] = 'select count(*) from `b_user` WHERE 1=1 AND `site_id`=[:1] AND `register_time`>=[:2] AND `register_time`<=[:3]';
$config['201314'] = 'update `b_user` set balance_account=balance_account+[:2] where 1=1 AND `id`=[:1]';
$config['201117'] = 'select `id`,`site_id` from `users` WHERE 1=1 AND `site_id`=[:1] ';
$config['201118'] = 'select `id`,`site_id` from `b_user` WHERE 1=1 AND `mobile`=[:1] ';
$config['201119'] = 'select `id`,`site_id` from `b_user` WHERE 1=1 AND `email`=[:1] ';

//订单
$config['203100'] = 'SELECT  a.`realized_income_value`,b.`powerRate`,b.`miningModel`,b.`maintenance`,b.`miningPower`,a.`income_start_time`,a.`income_end_time`,c.`title_buy`,a.`order_no`,a.`buy_amount`,b.`one_amount_value`,a.`pay_value`,a.`pay_start_time` FROM `b_order_hash` as a LEFT JOIN `b_product_hash` as b ON a.`product_id` = b.`id` LEFT JOIN `b_contract_tpl` as c ON b.`contract_ids` = c.`id`  WHERE 1=1 AND a.`id`=[:1]';
$config['203101'] = 'SELECT  a.`realized_income_value`,b.`powerRate`,b.`miningModel`,b.`maintenance`,b.`miningPower`,a.`income_start_time`,a.`income_end_time`,c.`title_buy`,a.`order_no`,a.`buy_amount`,b.`one_amount_value`,a.`pay_value`,a.`pay_start_time` FROM `b_order_hash` as a LEFT JOIN `b_transfer_product_hash` as b ON a.`product_id` = b.`id` LEFT JOIN `b_contract_tpl` as c ON b.`contract_ids` = c.`id`  WHERE 1=1 AND a.`id`=[:1]';
//$config['203100'] = 'SELECT b.MinePower,a.order_no,a.buy_amount,b.one_amount_value,a.pay_value,a.pay_start_time FROM `b_order_miner` as a  LEFT JOIN `b_miner` as b ON a.miner_id=b.id';

$config['203104'] = 'SELECT b.MinePower,a.order_no,a.buy_amount,b.one_amount_value,a.pay_value,a.pay_start_time FROM `b_order_miner` as a  LEFT JOIN `b_miner` as b ON a.miner_id=b.id where 1=1 AND a.`id`=[:1]';
$config['203102'] = 'SELECT count(*) as count,SUM(pay_value) as pay_value FROM `b_order_hash` WHERE `user_id`=[:1] AND 1=1 AND `status`=[:2]'; //待运行的订单统计
$config['203103'] = 'SELECT count(*) as count,SUM(pay_value) as pay_value  FROM `b_order_miner` WHERE `user_id`=[:1] AND 1=1 AND `status`=[:2]'; //确认收货的订单统计
//配置
$config['202111'] = 'select a.*,b.`name`   from `b_config` as a LEFT JOIN `b_site` as b ON a.site_id=b.id WHERE  1=1 AND a.`site_id`=[:3] LIMIT [:1],[:2]';
$config['202112'] = 'select count(*)   from `b_config` WHERE  1=1 AND `site_id`=[:1] ';
$config['202115'] = 'select *   from `b_config` WHERE  1=1 AND `varname`=[:1] AND `site_id`=[:2] ';
$config['201305'] = 'UPDATE `b_config` SET `varname`=[:2],`value`=[:3],`remark`=[:4],`site_id`=[:5] where 1=1 AND `id`=[:1]';

$config['203205'] = 'INSERT INTO `b_config`(`varname`,`value`,`remark`,`site_id`) VALUES([:1],[:2],[:3],[:4])';//
$config['201402'] = 'delete from  `b_config` where `id`=[:1]';

//消息
$config['203208'] = 'INSERT INTO `b_notification`(`msg_type_id`,`title`,`msg`,`site_id`,`created_at`,`user_id`) VALUES([:1],[:2],[:3],[:4],[:5],[:6])';
$config['202129'] = 'select msg_type_id,title,msg,site_id,created_at   from `b_notification` WHERE 1=1 AND `id`=[:1]';
$config['203210'] = 'INSERT INTO `b_notification_class`(`class_name`,`create_time`,`site_id`) VALUES([:1],[:2],[:3])';
$config['201309'] = 'UPDATE `b_notification_class` SET `class_name`=[:2],`site_id`=[:3] where 1=1 AND `id`=[:1]';
$config['201412'] = 'delete from  `b_notification_class` where `id`=[:1]';

//发送消息
$config['202209'] = 'insert into `b_user_msg` (`user_id`,`send_time`,`is_view`,`title`,`desc`,`text`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
$config['202210'] = 'insert into `b_notification` (`user_id`,`title`,`msg`,`msg_type_id`,`created_at`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';
$config['202212'] = 'insert into `b_notification` (`user_id`,`title`,`msg`,`msg_type_id`,`is_read`,`created_at`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
//新增admin操作记录表
$config['202213'] = 'insert into `admin_operation_logs` (`admin_id`,`user_id`,`operation_type`,`created_at`,`description`,`business_id`,`ip`,`detail`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
$config['202214'] = 'insert into `admin_operbank_logs` (`admin_id`,`m_bank_id`,`type`,`description`,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5])';

$config['402102'] = 'select * from `b_notification` WHERE 1=1 AND `id`=[:1]  AND `site_id`=[:2] order by created_at desc';

//账户
$config['202116'] = 'select a.*,b.name as site_name   from `b_product_hash_type` as a LEFT JOIN `b_site` as b ON a.site_id = b.id   WHERE 1=1 AND `site_id`=[:3] LIMIT  [:1],[:2]  ';
$config['202117'] = 'select count(*)   from `b_product_hash_type` WHERE  1=1 AND `site_id`=[:1]';
$config['201306'] = 'UPDATE `b_product_hash_type` SET `name`=[:2],`site_id`=[:3] where `id`=[:1]';
$config['203206'] = 'INSERT INTO `b_product_hash_type`(`name`,`created_time`,`site_id`) VALUES([:1],[:2],[:3])';//
$config['201408'] = 'delete from  `b_product_hash_type` where `id`=[:1]';


$config['202118'] = 'select a.*,b.site_id as site_name,b.true_name,b.user_name  from `b_logs` as a LEFT JOIN `b_admin` as b  ON a.`user_id`=b.`user_id` LEFT JOIN  `b_site` as c ON a.site_id=c.id WHERE  1=1 AND a.`site_id`=[:3] AND b.`user_name`=[:4] AND a.`ip`=[:5] AND a.`time` > [:6] AND a.`time` < [:7] ORDER BY a.`id` desc  LIMIT [:1],[:2]';
$config['202119'] = 'select count(*)   from `b_logs` as a LEFT JOIN `b_admin` as b  ON a.`user_id`=b.`user_id` WHERE  1=1 AND a.`site_id`=[:1] AND b.`user_name`=[:2] AND a.`ip`=[:3] AND a.`time` > [:4] AND a.`time` < [:5] ';
$config['201409'] = 'delete from  `b_logs` where `id`=[:1]';

$config['202120'] = 'select a.`type`,a.`id`,a.`title_buy`,a.`desc`,a.`content`,a.`modify_time`,a.`site_id`,a.`type`,b.name as site_name  from `b_contract_tpl` as a  LEFT JOIN  `b_site` as b ON a.site_id=b.id where 1=1 AND `site_id`=[:3] AND a.`status`=0 AND a.`type`=[:4] LIMIT [:1],[:2]';
$config['202121'] = 'select count(*)   from `b_contract_tpl` where 1=1 AND `site_id`=[:1] AND  `status`=0 AND `type`=[:2] ';
$config['202122'] = 'select a.`id`,a.`title_buy`,a.`desc`,a.`site_id`,a.`type`   from `b_contract_tpl` as a  LEFT JOIN `b_site` as b ON a.site_id = b.id where 1=1 AND `site_id`=[:1] AND a.`status`=0 ';

$config['201307'] = 'UPDATE `b_contract_tpl` SET `title_buy`=[:2],`desc`=[:3],`content`=[:4],`site_id`=[:5],`type`=[:6] where `id`=[:1]';
$config['203207'] = 'INSERT INTO `b_contract_tpl`(`title_buy`,`desc`,`content`,`modify_user`,`modify_time`,`site_id`,`type`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7])';//
$config['201410'] = 'delete from  `b_contract_tpl` where 1=1 AND `id`=[:1]';

//实名
$config['204112'] = "SELECT `user_id`,`status`,`truename`,`idcard`,`ret_msg` FROM `b_user_truename_valid_log` WHERE  1=1 AND `id`=[:1]";
$config['201312'] = 'UPDATE `b_user` SET `truename`=[:2],`idcard`=[:3],`user_verified`=[:4],`user_verified_fail_msg`=[:5] where `id`=[:1]';

//权限
$config['204101'] = "SELECT a.*,b.name as site_name FROM `b_admin`as a LEFT JOIN `b_site` as b ON a.site_id = b.id WHERE 1=1 AND a.`site_id`=[:3]  LIMIT [:1],[:2]";
$config['204131'] = "SELECT a.*,b.name as site_name,c.role_id FROM `b_admin`as a LEFT JOIN `b_site` as b ON a.site_id = b.id LEFT JOIN `b_admin_roles` as c ON a.user_id=c.user_id WHERE 1=1 AND a.`sadmin`=[:3] LIMIT [:1],[:2]";
$config['204130'] = "SELECT * FROM `b_admin` WHERE 1=1 AND `user_name` = [:1]";
$config['204102'] = "SELECT count(*) FROM `b_admin` WHERE  1=1  AND `site_id`=[:1] ";
$config['204132'] = "SELECT count(*) FROM `b_admin` WHERE  1=1  AND `sadmin`=[:1] ";
$config['204301'] = 'UPDATE `b_admin` SET `locked`=[:2] where 1=1 AND `user_id`=[:1]';
$config['204103'] = "SELECT * FROM `b_admin` WHERE 1=1 AND `user_id`=[:1]";
$config['204105'] = "SELECT `user_id`,`user_name`,`site_id` FROM `b_admin` where 1=1 AND `user_name`=[:1]";
$config['204201'] = 'INSERT INTO `b_admin`(`user_name`,`password`,`true_name`,`email`,`phone`,`mobile`,`site_id`,`sadmin`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
$config['402239'] = 'INSERT INTO `b_admin`(`user_name`,`password`,`true_name`,`email`,`phone`,`mobile`,`site_id`,`sadmin`,`admin_id`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';
$config['204200'] = 'INSERT INTO `b_admin`(`user_name`,`password`,`true_name`,`email`,`phone`,`mobile`,`site_id`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
$config['204302'] = 'UPDATE `b_admin` SET `user_name`=[:2],`true_name`=[:3],`email`=[:4],`phone`=[:5],`mobile`=[:6],`site_id`=[:7] where 1=1 AND `user_id`=[:1]';
$config['402240'] = 'UPDATE `b_admin` SET `user_name`=[:2],`true_name`=[:3],`email`=[:4],`phone`=[:5],`mobile`=[:6],`site_id`=[:7],`admin_id`=[:8] where 1=1 AND `user_id`=[:1]';
$config['204111'] = "SELECT a.`role_id`,b.`role_name` FROM `b_admin_roles` as a  LEFT JOIN `b_roles` as b  ON a.`role_id` = b.`role_id` WHERE 1=1 AND a.`user_id`=[:1] ";
$config['203126'] = 'select `id`,`priv_name`,`description` from `b_site_roles`  WHERE 1=1 AND  `pid`=[:1] ';
$config['204307'] = 'UPDATE `b_site_roles` SET `is_lock`=[:2] where  1=1 AND `priv_name`=[:1]';
$config['204308'] = 'UPDATE `b_site_roles` SET `is_lock`=0 ';

$config['204309'] = 'UPDATE `b_admin` SET `token`=[:2],`token_time`=[:3],`ip`=[:4] where 1=1 AND `user_id`=[:1]';
$config['204316'] = 'UPDATE `b_admin` SET `token`=[:2] where 1=1 AND `user_id`=[:1]';
$config['204310'] = 'UPDATE `b_admin` SET `password`=[:2],`update_password_time`=[:3] where 1=1 AND `user_id`=[:1]';


$config['204100'] = "SELECT * FROM `b_roles` WHERE 1=1 AND `role_id`=[:1]";
$config['204108'] = "SELECT * FROM `b_roles` WHERE 1=1 AND `role_name`=[:1] AND `site_id` =[:2]";
$config['204104'] = "SELECT `role_id`,`role_name` FROM `b_roles` ";

$config['204140'] = 'SELECT b.site_id,b.role_name,b.parent_id,d.icon,c.role_name as parent_name,d.name as site_name,`language`FROM `b_admin_roles` as a LEFT JOIN `b_roles` as b ON a.role_id = b.role_id LEFT JOIN `b_roles` as c ON b.`parent_id` = c.`role_id` LEFT JOIN `b_site` as d ON b.site_id=d.id  WHERE 1=1 AND a.`user_id`=[:1]';
$config['204114'] = "SELECT `role_id` FROM `b_admin_roles` where 1=1 AND `user_id`=[:1] ";
$config['204106'] = "SELECT a.role_id,a.role_name,a.description,a.locked,a.create_time,a.site_id,a.parent_id,b.role_name as parent_name,c.name as site_name FROM `b_roles` as a LEFT JOIN `b_roles` as b ON a.`parent_id`=b.`role_id` LEFT JOIN `b_site` as c ON a.site_id=c.id  WHERE 1=1 AND a.`parent_id` =[:3] LIMIT [:1],[:2]";
$config['204107'] = "SELECT count(*) FROM `b_roles` WHERE  1=1 AND `parent_id` =[:1]";
$config['204109'] = "SELECT a.role_id,a.role_name,a.description,a.locked,a.create_time,a.site_id,a.parent_id,b.role_name as parent_name,c.name as site_name FROM `b_roles` as a LEFT JOIN `b_roles` as b ON a.`parent_id`=b.`role_id` LEFT JOIN `b_site` as c ON a.site_id=c.id  WHERE 1=1 AND a.`parent_id` =[:3] AND a.`site_id`=[:4] LIMIT [:1],[:2]";
$config['204110'] = "SELECT count(*) FROM `b_roles` WHERE 1=1 AND `parent_id` =[:1] AND `site_id`=[:2]";
$config['204303'] = 'UPDATE `b_roles` SET `locked`=[:2] where 1=1 AND `role_id`=[:1]';
$config['204311'] = 'UPDATE `b_roles` SET `privilages`=[:2] where `role_id`=[:1]';

$config['204202'] = 'INSERT INTO `b_roles`(`role_name`,`privilages`,`description`) VALUES([:1],[:2],[:3])';
$config['204212'] = 'INSERT INTO `b_roles`(`role_name`,`privilages`,`site_id`,`create_time`,`sadmin`) VALUES([:1],[:2],[:3],[:4],[:5])';
$config['204304'] = 'UPDATE `b_roles` SET `role_name`=[:2],`privilages`=[:3],`description`=[:4] where 1=1 AND `role_id`=[:1]';
$config['204203'] = 'INSERT INTO `b_roles`(`role_name`,`description`,`site_id`,`parent_id`,`create_time`) VALUES([:1],[:2],[:3],[:4],[:5])';
$config['204305'] = 'UPDATE `b_roles` SET `role_name`=[:2],`description`=[:3],`parent_id`=[:4] where 1=1 AND `role_id`=[:1]';
$config['204306'] = 'UPDATE `b_roles` SET `privilages`=[:2] where  1=1 AND `role_id`=[:1]';
$config['204204'] = 'INSERT INTO `b_admin_roles`(`user_id`,`role_id`,`site_id`) VALUES([:1],[:2],[:3])';
$config['204314'] = 'UPDATE `b_roles` SET `site_id`=[:2] where  1=1 AND `role_id`=[:1]';
$config['204315'] = 'UPDATE `b_roles` SET `site_id`=[:2] where  1=1 AND `parent_id`=[:1]';

$config['201404'] = 'delete from  `b_admin_roles` where 1=1 AND `user_id`=[:1] ';
$config['201405'] = 'delete from  `b_admin_roles` where 1=1 AND `user_id`=[:1] ';
$config['201406'] = 'delete from  `b_admin` where  1=1 AND `user_id`=[:1] ';
$config['201417'] = 'delete from  `b_admin_roles` where  1=1 AND `role_id`=[:1] ';
$config['201418'] = 'delete from  `b_roles` where  1=1 AND `parent_id`=[:1] OR `role_id`=[:1] ';
$config['201419'] = 'delete from  `b_roles` where  1=1 AND `role_id`=[:1] ';
$config['204115'] = "SELECT a.role_id,a.role_name,a.description,a.locked,a.create_time,a.site_id,a.parent_id,a.sadmin,b.role_name as parent_name,c.name as site_name FROM `b_roles` as a LEFT JOIN `b_roles` as b ON a.`parent_id`=b.`role_id` LEFT JOIN `b_site` as c ON a.site_id=c.id  WHERE 1=1 AND a.`parent_id` !=0  LIMIT [:1],[:2]";
$config['204116'] = "SELECT count(*) FROM `b_roles` WHERE `parent_id` !=0";
$config['204117'] = "SELECT a.role_id,a.role_name,a.description,a.locked,a.create_time,a.site_id,a.parent_id,a.sadmin,b.role_name as parent_name,c.name as site_name FROM `b_roles` as a LEFT JOIN `b_roles` as b ON a.`parent_id`=b.`role_id` LEFT JOIN `b_site` as c ON a.site_id=c.id WHERE 1=1 AND  a.`parent_id` !=0 AND a.`site_id` = [:3]  LIMIT [:1],[:2]";
$config['204118'] = "SELECT count(*) FROM `b_roles` WHERE 1=1 AND `parent_id` != 0 AND `site_id` = [:1]";
$config['204135'] = "SELECT a.`role_id`,a.`role_name`,a.`site_id`,a.`parent_id`,b.name as site_name FROM `b_roles` as a LEFT JOIN `b_site` as b ON a.site_id=b.id WHERE  1=1 AND a.`site_id` =[:1] AND a.`parent_id`= 0 ";
$config['204136'] = "SELECT a.`role_id`,a.`role_name`,a.`site_id`,a.`parent_id`,b.name as site_name FROM `b_roles` as a LEFT JOIN `b_site` as b ON a.site_id=b.id WHERE  1=1 AND a.`site_id` =[:1] AND a.`parent_id`!= 0 ";
$config['204137'] = "SELECT `role_id`,`role_name`,`site_id`,`parent_id` FROM `b_roles` WHERE 1=1 AND `parent_id`=[:1]";
$config['204138'] = "SELECT `privilages` FROM `b_roles` WHERE `sadmin`=1 AND `site_id`=[:1]";


//资金变动记录
$config['202208'] = 'insert into `b_user_capital` (`create_time`,`user_id`,`type`,`description`,`amount`,`value`,`order_id`,`channel`,`trade_id`,`status`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11])';



//系统日志
$config['204206'] = 'INSERT INTO `b_logs`(`user_id`,`priv_id`,`desc`,`time`,`ip`,`site_id`) VALUES([:1],[:2],[:3],[:4],[:5],[:6])';

//充值待处理
$config['204119'] = "SELECT count(*) FROM `b_account_capital_racharge_log` WHERE 1=1 AND `site_id` =[:1] AND `status` in(0,1) AND `channel`=4 ";
//提币待处理
$config['204120'] = "SELECT count(*) FROM `b_account_btc_withdraw_log` WHERE 1=1 AND `site_id` =[:1] AND `status` in(0,1)";
//矿机代发货
$config['204121'] = "SELECT count(*) FROM `b_order_miner` WHERE 1=1 AND `site_id` =[:1] AND `status`=[:2] AND `updated_time`>=[:3] AND `updated_time` <=[:4]";
//获取托管
$config['204122'] = "SELECT count(*) FROM `b_deposit` WHERE 1=1 AND `site_id` =[:1] AND `updated_at`>=[:2]";
$config['204143'] = "SELECT count(*) FROM `b_deposit` WHERE 1=1 AND `site_id` =[:1] AND `status`=[:2]";


//新闻资讯类型
$config['204123'] = 'SELECT a.*,b.`name` as site_name from `b_news_class` as a LEFT JOIN `b_site` as b ON a.`site_id`=b.`id` WHERE 1=1 AND a.`site_id`=[:1] limit [:2],[:3]';
$config['204312'] = 'UPDATE `b_news_class` SET `name`=[:2],`remark`=[:3],`display_order`=[:4],`site_id`=[:5],`lang`=[:6] WHERE id=[:1]';
$config['204124'] = 'SELECT COUNT(*) from `b_news_class` WHERE 1=1 AND `site_id`=[:1]';
$config['201429'] = 'DELETE from `b_news_class` WHERE 1=1 AND `id`=[:1]';
$config['204207'] = 'INSERT INTO b_news_class (`name`,`remark`,`display_order`,site_id,`lang`) VALUES ([:1],[:2],[:3],[:4],[:5])';

//关于我们
$config['204125'] = 'SELECT a.*,b.name as site_name from `b_about`  as a LEFT JOIN  b_site as b ON a.site_id=b.id  WHERE 1=1 AND a.`site_id`=[:1] limit [:2],[:3]';
// $config['204312'] = 'UPDATE `b_news_class` SET `name`=[:2],`remark`=[:3],`display_order`=[:4],`site_id`=[:5] WHERE id=[:1]';
$config['204126'] = 'SELECT COUNT(*) from `b_about` WHERE 1=1 AND `site_id`=[:1]';
$config['204127'] = 'SELECT * from `b_about_us` WHERE 1=1 AND `site_id`=[:1] limit 0,3';

$config['201415'] = 'DELETE from `b_about_us` WHERE 1=1 AND `site_id`=[:1]';
$config['204208'] = 'INSERT INTO b_about_us (`center_block_title`,`center_block_content`,`center_block_image`,`dateline`,`site_id`,`bottom_block_image`,`bottom_block_word`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
$config['204209'] = 'INSERT INTO b_about (`banner_title`,`banner_content`,`banner_up_title`,`banner_up_resume`,`map_title`,`map_des`,`slogan`,`slogn_content`,`dateline`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';
$config['204313'] = 'UPDATE `b_about` SET `banner_title`=[:1],`banner_content`=[:2],`banner_up_title`=[:3],`banner_up_resume`=[:4],`map_title`=[:5],`map_des`=[:6],`slogan`=[:7],`slogn_content`=[:8],`site_id`=[:9] WHERE 1=1 AND `id`=[:10]';
$config['204128'] = 'SELECT * from `b_about` WHERE 1=1 AND `site_id`=[:1]';
$config['201416'] = 'DELETE from `b_about` WHERE 1=1 AND `site_id`=[:1]';


$config['201411'] = 'SELECT from `b_news_class` WHERE 1=1 AND `id`=[:1] ';
$config['204207'] = 'INSERT INTO b_news_class (`name`,`remark`,`display_order`,site_id) VALUES ([:1],[:2],[:3],[:4])';
//意见反馈
$config['301133'] = 'SELECT a.*,b.name as site_name FROM b_question as a LEFT JOIN b_site as b ON a.site_id=b.id WHERE 1=1 AND  a.`site_id`=[:1] order by create_time desc LIMIT [:2],[:3]';
$config['301134'] = 'SELECT COUNT(*) FROM b_question as a  WHERE 1=1 AND  a.`site_id`=[:1]';

//李津宇
//消息管理 301
$config['301101'] = 'select a.*,b.name as site_name from b_notification_class as a LEFT JOIN `b_site` as b  ON a.site_id = b.id where 1=1 AND a.`site_id` = [:1]'; //获取消息类型
//$config['301201'] = 'insert into b_notification (title,msg,msg_type_id,created_at,site_id) VALUES ([:1],[:2],[:3],[:4],[:5])'; //添加消息
$config['301102'] = 'select id,mobile from b_user WHERE  `id` = [:1] AND `site_id` = [:2]'; //获取用户名
//
$config['301103'] = 'select user_id,mobile,d.name as site_name,c.class_name,created_at,msg,is_read from b_notification as a LEFT JOIN b_user as b ON a.user_id=b.id LEFT JOIN b_notification_class as c ON a.msg_type_id=c.id LEFT JOIN b_site as d ON a.site_id=d.id WHERE a.site_id = [:1] limit [:2],[:3]';
$config['301104'] = 'select count(*) from b_notification as a  WHERE a.site_id = [:1]';

//托管
//获取托管列表
$config['301105'] = 'select a.`id`,`dep_name`,`dep_tel`,`bdc_name`,`dep_logistics`,`contract_name` from `b_deposit` as a LEFT JOIN `b_bdc_message` as b on a.`dep_bdc_id`=b.`id` WHERE a.`site_id`=[:1] limit [:2],[:3]';
$config['301106'] = 'select count(*) from `b_deposit` as a LEFT JOIN `b_bdc_message` as b on a.`dep_bdc_id`=b.`id` WHERE a.`site_id`=[:1]';
$config['301107'] = 'select `id`,`bdc_name` from `b_bdc_message` WHERE `site_id`=[:1]';
//新增托管信息
$config['301202'] = 'insert into b_deposit(dep_name,dep_tel,dep_logistics,created_at,dep_bdc_id,electric_charge,deposit_fee,process_fee,mine_pool,wallet_address,run_time,deposit_start_time,deposit_end_time,deposit_money,remark,contract_name,contract_copy_picture,site_id) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18])';
//托管修改--显示数据页面
$config['301108'] = 'select a.`id`,`dep_name`,`dep_tel`,`bdc_name`,`dep_logistics`,`contract_name`,`electric_charge`,`deposit_fee`,`process_fee`,`mine_pool`,`wallet_address`,`run_time`,`deposit_start_time`,`deposit_end_time`,`deposit_money`,`remark`,`contract_name`,`contract_copy_picture` from `b_deposit` as a LEFT JOIN `b_bdc_message` as b on a.`dep_bdc_id`=b.`id` WHERE a.id=[:1] AND a.`site_id`=[:2]';
//托管修改--保存数据
$config['301300'] = 'update b_deposit set dep_name=[:1],dep_tel=[:2],dep_logistics=[:3],remark=[:4],electric_charge=[:5],deposit_fee=[:6],process_fee=[:7],mine_pool=[:8],contract_name=[:9],wallet_address=[:10],run_time=[:11],deposit_start_time=[:12],deposit_end_time=[:13],deposit_money=[:14],contract_copy_picture=[:15],dep_bdc_id=[:16] where id=[:17]';
//托管--删除数据
$config['301400'] = 'delete from  b_deposit where id=[:1]';
//托管--获取累计托管
$config['301129'] = 'SELECT `dep_number` FROM `b_deposit` WHERE `user_id`=[:1]';

//邀请--列表
$config['301109'] = 'SELECT a.id AS my_user_id,a.mobile,a.email,a.invite_code,sum(d.invite_amount) AS investment_amount,c.NAME AS site_name,count(d.user_id) AS invite_num,sum(d.is_buy) AS investment_num FROM	`b_user` AS a LEFT JOIN `b_user_invite` AS b ON a.`id` = b.invite_id LEFT JOIN `b_site` AS c ON a.site_id = c.id LEFT JOIN `b_user_invite` AS d ON a.`id` = d.user_id WHERE	1=1 AND a.`site_id` = [:1] AND a.`email`=[:4] AND a.`mobile`=[:5] GROUP BY a.id ORDER BY a.id desc limit [:2],[:3]';
//邀请--总数
$config['301110'] = 'SELECT COUNT(*) from `b_user` WHERE  1=1 AND `site_id` =[:1] AND `email`=[:2] AND `mobile`=[:3]';
//邀请--详情
$config['301111'] = 'SELECT a.mobile,a.email,c.name as site_name,b.create_time,b.invite_amount,b.invite_code from b_user as a LEFT JOIN b_user_invite as b ON a.id=b.invite_id LEFT JOIN b_site as c ON a.site_id=c.id WHERE a.id in (SELECT b.invite_id from b_user as a LEFT JOIN b_user_invite as b ON a.id=b.user_id WHERE b.user_id=[:1]) ;';
//矿机--列表 //张哲  2018-05-08
$config['301112'] = 'SELECT a.id,a.name,b.name as product_type,c.name as site_name,a.amount,a.buyed_amount,a.amount-a.buyed_amount as surplus_num,a.one_amount_value,a.is_index_see,a.status,a.sell_start_time,a.sell_end_time FROM b_miner AS a LEFT JOIN b_product_hash_type AS b ON a.hash_type_id = b.id LEFT JOIN b_site AS c ON a.site_id = c.id WHERE a.site_id = [:1] LIMIT [:2],[:3] ';
//矿机--总数
$config['301113'] = 'SELECT COUNT(*) FROM b_miner AS a  WHERE a.site_id = [:1]';

//获取算力类型,新增和修改需要调用
$config['301114'] = 'SELECT id,name as hash_type FROM b_product_hash_type WHERE site_id=[:1]';

//矿机--售罄
$config['301302'] = 'UPDATE b_miner SET status=2 WHERE id=[:1] AND site_id=[:2]';
//网站配置--新闻咨询管理&产品公告管理--列表
$config['301115'] = 'SELECT a.id,a.resume,a.content,a.image,a.news_class_id,a.`lang`,b.name as class_name,a.title,a.dateline,a.site_id,c.name as site_name from b_news as a LEFT JOIN b_news_class as b ON a.news_class_id=b.id LEFT JOIN b_site as c ON  a.site_id=c.id WHERE 1=1 AND a.`news_class_id`=[:1] AND a.`site_id`=[:4] ORDER BY a.id desc  limit [:2],[:3]';
//网站配置--新闻咨询管理&产品公告管理--编辑
$config['301303'] = 'UPDATE b_news SET title=[:1],content=[:2],site_id=[:3],`news_class_id`=[:5],`resume`=[:6],`image`=[:7],`dateline`=[:8],`lang`=[:9] WHERE id=[:4]';
//网站配置--新闻咨询管理&产品公告管理--总数
$config['301116'] = 'SELECT COUNT(*) from b_news as a   WHERE 1=1 AND  a.`news_class_id`=[:1] AND a.`site_id`=[:2]';
//网站配置--新闻咨询管理&产品公告管理--删除
$config['301401'] = 'DELETE from b_news WHERE id=[:1] ';
//网站配置--新闻咨询管理&产品公告管理--新增
$config['301204'] = 'INSERT INTO b_news (title,content,dateline,site_id,`news_class_id`,`resume`,`image`,`lang`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
//BDC中心管理--编辑
$config['301304'] = 'UPDATE b_bdc_message SET bdc_name=[:1],content=[:2],site_id=[:3] WHERE id=[:4]';
//BDC中心管理--新增
$config['301205'] = 'INSERT INTO b_bdc_message (bdc_name,content,created_at,site_id) VALUES ([:1],[:2],[:3],[:4])';
//BDC中心管理--列表
$config['301117'] = 'SELECT a.site_id,a.content,a.id,a.bdc_name,b.name as site_name,a.created_at FROM b_bdc_message as a LEFT JOIN b_site as b ON a.site_id=b.id WHERE 1=1 AND  a.`site_id`=[:1] order by a.created_at desc LIMIT [:2],[:3]';
//BDC中心管理--总数
$config['301118'] = 'SELECT COUNT(*) FROM b_bdc_message as a  WHERE a.site_id=[:1]';
//BDC中心管理--删除
$config['301402'] = 'DELETE FROM b_bdc_message WHERE id=[:1] ';
//帮助中心管理--更新
$config['301305'] = 'UPDATE b_help SET help_class_id=[:1],title=[:2],content=[:3],site_id=[:4],`lang`=[:6] WHERE id=[:5]';

$config['301310'] = 'UPDATE b_agreement SET unique_id=[:1],title=[:2],content=[:3],modify_time=[:4],modify_user=[:5],site_id=[:6],`lang`=[:8] WHERE id=[:7]';

$config['301311'] = 'UPDATE b_about_image SET image=[:1],url=[:2],remark=[:3],site_id=[:4],`lang`=[:6] WHERE id=[:5]';
//帮助中心管理--新增
$config['301206'] = 'INSERT INTO b_help (help_class_id,title,content,dateline,site_id,`lang`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';
//基本设置--新增
$config['301210'] = 'INSERT INTO b_agreement (unique_id,title,content,modify_time,modify_user,site_id,`lang`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';

$config['301212'] = 'INSERT INTO b_about_image (image,url,remark,site_id,`lang`) VALUES ([:1],[:2],[:3],[:4],[:5])';
//帮助中心管理--列表
$config['301119'] = 'SELECT a.id,a.title,a.content,a.`lang`,c.name as site_name,b.`name` as class_name,a.site_id,b.id as help_class_id FROM b_help AS a LEFT JOIN b_help_class AS b ON a.help_class_id=b.id LEFT JOIN b_site AS c ON a.site_id=c.id WHERE 1=1 AND a.`site_id`=[:1] AND a.`help_class_id`=[:4] order by a.id desc LIMIT [:2],[:3]';
//
$config['301130'] = 'SELECT a.id,a.title,a.content,a.unique_id,a.`lang`,c.name as site_name,a.site_id FROM b_agreement AS a LEFT JOIN b_site AS c ON a.site_id=c.id WHERE 1=1 AND a.`site_id`=[:1] LIMIT [:2],[:3]';

$config['301132'] = 'SELECT a.id,a.image,a.remark,a.url,a.`lang`,c.name as site_name,a.site_id FROM b_about_image AS a LEFT JOIN b_site AS c ON a.site_id=c.id WHERE 1=1 AND a.`site_id`=[:1] LIMIT [:2],[:3]';

$config['301138'] = 'SELECT a.*,b.name FROM app_updateconfig AS a LEFT JOIN b_site AS c ON a.site_id=c.id WHERE 1=1 AND a.`site_id`=[:1] LIMIT [:2],[:3]';


//帮助中心管理--总数
$config['301120'] = 'SELECT COUNT(*) FROM b_help AS a  WHERE 1=1 AND  a.`site_id`=[:1] AND a.`help_class_id`=[:2]';

$config['301131'] = 'SELECT COUNT(*) FROM b_agreement AS a  WHERE 1=1 AND  a.`site_id`=[:1]';

$config['301135'] = 'SELECT COUNT(*) FROM b_about_image AS a  WHERE 1=1 AND  a.`site_id`=[:1]';
//帮助类型
$config['301140'] = 'SELECT `id`,`name` FROM `b_help_class`';
//帮助中心管理--删除
$config['301403'] = 'DELETE FROM b_help WHERE id=[:1]';

$config['301407'] = 'DELETE FROM b_agreement WHERE id=[:1]';

$config['301408'] = 'DELETE FROM b_about_image WHERE id=[:1]';
//版本管理--列表
$config['301121'] = 'SELECT a.site_id,a.id,device_id,version_number,b.name as site_name,download_url,created_at FROM b_app_version as a LEFT JOIN b_site as b ON a.site_id=b.id WHERE 1=1 AND  a.`site_id`=[:1] LIMIT [:2],[:3]';
//版本管理--总数
$config['301122'] = 'SELECT COUNT(*) FROM b_app_version as a  WHERE 1=1 AND  a.`site_id`=[:1]';
//版本管理--更新
$config['301306'] = 'UPDATE b_app_version SET device_id=[:1],version_number=[:2],download_url=[:3],site_id=[:4] WHERE id=[:5]';
$config['301211'] = 'INSERT INTO b_app_version (device_id,version_number,download_url,site_id,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5])';
//版本管理--删除
$config['301404'] = 'DELETE FROM b_app_version WHERE id=[:1] ';
//bdc--列表
$config['301123'] = 'SELECT `id`,`bdc_address`,`bdc_electric_type`,`created_at`,`bdc_building_scope`,`current_electrify_time`,`bdc_electrify_price`,`total_position`,`bdc_trust_fee`,`bdc_mining_pool`,`is_run` FROM `b_bdc_message` WHERE site_id=[:1] LIMIT [:2],[:3]';
//bdc--总数
$config['301124'] = 'SELECT COUNT(*) FROM `b_bdc_message` WHERE site_id=[:1]';
//bdc--更新
$config['301307'] = 'UPDATE b_bdc_message SET bdc_address=[:1],bdc_electric_type=[:2],created_at=[:3],bdc_building_scope=[:4],current_electrify_time=[:5],bdc_electrify_price=[:6],total_position=[:7],bdc_trust_fee=[:8],bdc_mining_pool=[:9],is_run=[:10] WHERE id=[:11] AND site_id=[:12]';
//bdc--新增
$config['301207'] = 'INSERT INTO b_bdc_message (bdc_address,bdc_electric_type,created_at,bdc_building_scope,current_electrify_time,bdc_electrify_price,total_position,bdc_trust_fee,bdc_mining_pool,is_run,site_id)VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11])';
//bdc--删除
$config['301405'] = 'DELETE FROM b_bdc_message WHERE id=[:1] ';
//合作伙伴&banner轮播图--列表
$config['301125'] = 'SELECT a.`id`,a.`site_id`,a.`position`,a.`image`,a.`title`,a.`url`,a.`url_type`,a.`endpoint`,a.`display_order`,a.`type`,a.`lang`,b.name as site_name FROM b_banner as a LEFT JOIN `b_site` as b ON a.site_id=b.id WHERE 1=1 AND  a.`position`=[:1] AND a.`site_id`=[:2] order by a.`id` desc LIMIT [:3],[:4] ';
//合作伙伴&banner轮播图--总数
$config['301126'] = 'SELECT count(a.`id`) FROM b_banner as a LEFT JOIN `b_site` as b ON a.site_id=b.id WHERE 1=1 AND  a.`position`=[:1] AND a.`site_id`=[:2]';
//banner 更新
$config['301308'] = 'UPDATE b_banner SET title=[:1],image=[:2],url=[:3],url_type=[:4],endpoint=[:5],`position`=[:6],display_order=[:7],`site_id`=[:9],`type`=[:10],`lang`=[:11] WHERE id=[:8]';
//banner 新增
$config['301208'] = 'INSERT INTO b_banner(`title`,`image`,`url`,`url_type`,`endpoint`,`position`,`display_order`,`site_id`,`type`,`lang`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';
//友情链接 更新
$config['301309'] = 'UPDATE b_banner SET title=[:1],url=[:2] WHERE id=[:3]';
//友情链接 新增
$config['301209'] = 'INSERT INTO b_banner(`title`,`url`,`site_id`) VALUES ([:1],[:2],[:3])';
//banner和友情链接--删除
$config['301406'] = 'DELETE FROM b_banner WHERE id=[:1] ';

//矿机详情 张哲 2018-05-08
$config['301127'] = 'SELECT a.id,a.name,b.id as hash_type_id,d.id as miner_type_id,a.amount,a.one_amount_value,a.single_limit_amount,a.is_index_see,a.MinerAddress,a.is_index_see,a.is_see,a.status,c.id as site_id,a.sell_start_time,a.sell_end_time,a.minerPicture,a.MInerBrief,a.DeliveryTime FROM b_miner AS a LEFT JOIN b_product_hash_type AS b ON a.hash_type_id = b.id LEFT JOIN b_site AS c ON a.site_id = c.id LEFT JOIN b_product_hash_base AS d ON a.miner_type_id = d.id WHERE a.id = [:1]';
    
//是否首页展示状态接口 张哲 2018-05-08
$config['301128'] = 'SELECT id,name FROM b_product_miner_base'; 

//矿机--新增 张哲 2018-05-09
$config['301203'] = 'INSERT INTO b_miner (hash_type_id,name,amount,one_amount_value,single_limit_amount,MinerAddress,is_index_see,is_see,MInerBrief,status,sell_start_time,sell_end_time,DeliveryTime,minerPicture,site_id,miner_type_id,`contract_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17])';

//$hash_type_id,$name,$amount,$one_amount_value,$single_limit_amount,$MinerAddress,$is_index_see,$is_see,$MInerBrief,$status,$sell_start_time,$sell_end_time,$DeliveryTime,$minerPicture,$site_id,$miner_type_id


//矿机--更新 张哲 2018-05-09
$config['301301'] = 'UPDATE b_miner SET hash_type_id=[:1],name=[:2],amount=[:3],one_amount_value=[:4],single_limit_amount=[:5],MinerAddress=[:6],is_index_see=[:7],is_see=[:8],MInerBrief=[:9],status=[:10],sell_start_time=[:11],sell_end_time=[:12],DeliveryTime=[:13],minerPicture=[:14],site_id=[:15],miner_type_id=[:16],`contract_id`=[:18] WHERE id=[:17]';
    /**
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText320
     * @version  1.0
     * @return   [return]
     */
    
    /**
     * @Author   张哲
     * @DateTime 2018-03-27
     */
    //用户资金充值记录表
 	$config['401100'] = 'select * from `b_account_capital_racharge_log` where site_id=[:3] order by id desc limit [:1],[:2]' ;
	//充值列表总数
	$config['401101'] = 'select count(*) from `b_account_capital_racharge_log`  where  site_id=[:1]';
	//充值详情
	$config['401102'] = 'SELECT a.user_id,a.site_id,a.response_id,a.amount,a.id,c.mobile,c.email,c.truename,c.balance_account,b.name,a.pay_time,a.channel,a.amount,a.bank_num,a.request_id,a.status FROM b_account_capital_racharge_log as a JOIN b_site as b ON a.site_id = b.id JOIN b_user c ON a.user_id = c.id WHERE a.id=[:1]';
	//充值审核
	$config['401301'] = 'update `b_account_capital_racharge_log` set status=[:2] where id=[:1]';


	/**
     * @Author   张哲
     * @DateTime 2018-03-28
     */
	//用户资金提现记录表
	$config['402103'] = 'select * from `b_account_capital_withdraw_log` where site_id=[:3] order by id desc limit [:1],[:2]' ;
	//提现列表总数
	$config['402104'] = 'select count(*) from `b_account_capital_withdraw_log`  where  site_id=[:1]';
	//提现详情
	// $config['402105'] = 'SELECT c.mobile,c.email,b.name,a.apply_time,a.withdraw_type,a.account,a.bank,a.amount,a.fee,a.order_number,a.status,d.record_no FROM b_account_capital_withdraw_log as a JOIN b_site as b ON a.site_id = b.id JOIN b_user c ON a.user_id = c.id JOIN b_security_hash d ON a.id = d.order_hash_id WHERE a.id=[:1] and d.security_hash_type = [:2]';

	$config['402105'] = 'SELECT a.id,a.serial_number,a.user_id,c.mobile,c.email,c.truename,b.name,a.apply_time,a.pay_time,a.withdraw_type,a.account,a.bank,a.amount,a.fee,a.order_number,a.status FROM b_account_capital_withdraw_log as a JOIN b_site as b ON a.site_id = b.id JOIN b_user c ON a.user_id = c.id WHERE a.id=[:1]';
	//提现审核
	$config['402300'] = 'update `b_account_capital_withdraw_log` set status=[:2] where id=[:1]';


	/**
     * @Author   张哲
     * @DateTime 2018-03-28
     */
    //用户资金明细记录表
 	$config['403106'] = 'select * from `b_user_capital` where site_id=[:3] order by id desc limit [:1],[:2]' ;
	//用户资金明细表总数
	$config['403107'] = 'select count(*) from `b_user_capital`  where  site_id=[:1]';

	/**
     * @Author   zuojun
     * @DateTime 2018年6月6日18:40:03
     */
	$config['403309'] = 'update `b_user` set `freeze_account`=`freeze_account`-[:2] where id=[:1]'; //再次审核通过后解冻资金
	$config['403310'] = 'update `b_user` set `freeze_account`=`freeze_account`-[:2],`balance_account`=`balance_account`+[:2] where id=[:1]'; //再次审核拒绝后解冻资金并还原余额

	$config['403201'] = 'INSERT INTO b_user_capital (user_id,create_time,type,description,value,order_id,remark,status) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';//添加提现记录
	$config['403202'] = 'INSERT INTO b_security_bulid_hash (user_id,order_hash_id,bulid_status,security_status) VALUES ([:1],[:2],[:3],[:4])';//添加提现记录
    //初次审核通过改变状态
    $config['403333'] = 'update `b_account_capital_racharge_log` set `status`=[:2] where id=[:1]';


	/**
     * @Author   张哲
     * @DateTime 2018-05-02
     */
	//提币详情
	$config['404108'] = 'SELECT a.id,a.user_id,b.name,c.mobile,c.email,c.truename,a.apply_time,a.product_hash_type,d.name as product_hash_type_name,a.amount,a.fee,a.status,a.site_id,a.btc_addr FROM b_account_btc_withdraw_log as a JOIN b_site as b ON a.site_id = b.id JOIN b_user c ON a.user_id = c.id JOIN b_product_hash_type d ON a.product_hash_type = d.id WHERE a.id=[:1]';

	//提币审核
	$config['404304'] = 'UPDATE `b_account_btc_withdraw_log` SET `status`=[:2] where `id`=[:1]';
	//确认审核
	$config['404303'] = 'UPDATE `b_account_btc_withdraw_log` SET `status`=[:2] where `id`=[:1]';

	//解冻提币冻结的币资产
	$config['404305'] = 'update `b_user_ext` set `freeze_coin_withdraw_account`=`freeze_coin_withdraw_account`-[:1] where user_id=[:3] and type=[:2]'; //再次审核通过后解冻币资产
	$config['404306'] = 'update `b_user_ext` set `freeze_coin_withdraw_account`=`freeze_coin_withdraw_account`-[:1],`coin_account`=`coin_account`+[:1] where user_id=[:3] and type=[:2] and site_id=[:4]'; //审核拒绝后解冻资产和还原可用余额

	$config['404201'] = 'INSERT INTO b_user_capital (user_id,create_time,type,description,btc_amount,order_id,remark,status) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';//添加提现记录

	$config['404202'] = 'INSERT INTO b_security_bulid_hash (user_id,order_hash_id,bulid_status,security_status) VALUES ([:1],[:2],[:3],[:4])';//添加提现记录

	//派发币过程中改回录入收益状态  张哲  2018-05-22
	$config['404302'] = 'UPDATE `b_user_hash_income` SET `status`=[:2] where `id`=[:1]';

	/**
     * @Author   张哲
     * @DateTime 2018-05-09
     */
	//托管审核
	$config['405304'] = 'UPDATE `b_deposit` SET `status`=[:2],`remark`=[:3] where `id`=[:1]';
	//托管管理详情
	$config['405109'] = 'SELECT a.id,a.dep_tel,a.dep_name,b.name as site_name,a.created_at,a.dep_type,a.dep_miner_type,a.dep_number,d.bdc_name,a.contract_name,a.electric_charge,a.deposit_fee,a.deposit_money,a.dep_logistics,a.process_fee,a.remark,a.contract_copy_picture,a.status FROM b_deposit as a JOIN b_site as b ON a.site_id = b.id JOIN b_bdc_message d ON d.id=a.dep_bdc_id WHERE a.id=[:1]';

	/**
     * @Author   张哲
     * @DateTime 2018-05-27
     */
	//实名详情
	$config['406110'] = 'SELECT a.id,a.add_time,a.truename,a.idcard,a.res_time,a.status,a.site_id,c.mobile,b.name as site_name FROM b_user_truename_valid_log as a JOIN b_site as b ON a.site_id = b.id JOIN b_user c ON a.user_id = c.id WHERE a.id=[:1]';
	//实名认证审核
	$config['406305'] = 'UPDATE `b_user_truename_valid_log` SET `status`=[:2] where `id`=[:1]';

	//银行卡详情
	$config['406111'] = 'SELECT a.id,a.card_no,a.bank,a.acc_name,a.acc_id,a.mobile,a.open_bank,a.bank_branch,a.status,a.created_at,c.mobile,b.name as site_name FROM b_unionpay_bind_card_log as a JOIN b_site as b ON a.site_id = b.id JOIN b_user c ON a.user_id = c.id WHERE a.id=[:1]';
	//银行卡认证审核
	$config['406306'] = 'UPDATE `b_unionpay_bind_card_log` SET `status`=[:2] where `id`=[:1]';


	//查看提现金额
	$config['403112'] = 'SELECT a.amount,a.product_hash_type,a.user_id,a.site_id,a.fee,b.name from  b_account_btc_withdraw_log as a JOIN b_product_hash_type b ON a.product_hash_type=b.id where a.id=[:1]';

	//查看冻结金额
	$config['403113'] = 'SELECT  b_account_btc_withdraw_log.amount,b_user_ext.freeze_coin_withdraw_account from  b_account_btc_withdraw_log,b_user_ext where b_account_btc_withdraw_log.id=[:1] and b_account_btc_withdraw_log.product_hash_type = b_user_ext.type';






	// 'SELECT a.id,device_id,version_number,b.site_name,download_url,created_at FROM b_app_version as a LEFT JOIN b_site_domain as b ON a.site_id=b.site_id WHERE a.site_id=[:1] LIMIT [:2],[:3]';

	// //用户资金充值记录表
	// $config['401100']="SELECT * FROM `b_account_capital_racharge_log` WHERE  `user_id` = [:1]  AND  `id` = [:2]  AND  `channel` = [:3]  AND  `request_id` = [:4]  AND  `amount` = [:5]  AND  `pay_time` = [:6]  AND  `success_time` = [:7]  AND  `response_id` = [:8]  AND  `status` = [:9]  AND  `bank_num` = [:10]  AND  `url` = [:11]  AND  `site_id` = [:12] ";#用户资金充值记录表 获取单条记录 info

	// $config['401101']="SELECT * FROM `b_account_capital_racharge_log` WHERE 1=1 AND  `id` = [:3]  AND  `user_id` = [:4]  AND  `channel` = [:5]  AND  `request_id` = [:6]  AND  `amount` = [:7]  AND  `pay_time` = [:8]  AND  `success_time` = [:9]  AND  `response_id` = [:10]  AND  `status` = [:11]  AND  `bank_num` = [:12]  AND  `url` = [:13]  AND  `site_id` = [:14]  ORDER BY id DESC LIMIT [:2],[:1]";#用户资金充值记录表 获取列表 get_list

	// $config['401102']="SELECT COUNT(*) FROM `b_account_capital_racharge_log`";#用户资金充值记录表 统计条数 get_count

	// $config['401200']="INSERT INTO `b_account_capital_racharge_log`(`user_id`,`channel`,`request_id`,`amount`,`pay_time`,`success_time`,`response_id`,`status`,`bank_num`,`url`,`site_id`) VALUES([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11])";#用户资金充值记录表 添加 add

	// $config['401300']="UPDATE `b_account_capital_racharge_log` SET `user_id`=[:2],`channel`=[:3],`request_id`=[:4],`amount`=[:5],`pay_time`=[:6],`success_time`=[:7],`response_id`=[:8],`status`=[:9],`bank_num`=[:10],`url`=[:11],`site_id`=[:12]  WHERE  `id` = [:1] ";#用户资金充值记录表 修改 update

	// $config['401400']="DELETE FROM `b_account_capital_racharge_log`  WHERE  `id` = [:1] ";#用户资金充值记录表 删除 delete




    //交易所系统 todo jzuo
    //1、关于提现
    //1、根据ID 获取详情
    $config['501101'] = 'SELECT  user_withdraws.* from  user_withdraws where user_withdraws.id=[:1]';
    //2、查询所有币种
    $config['501102'] = 'SELECT  asset_code,asset_name from assets where site_id = [:1] AND deleted_at is null';
    //获取用户所选币种的提现冻结资金
    $config['501103'] = 'SELECT  balance from user_withdraw_freezes where `asset`=[:1] AND `user_id`=[:2]';
    //查询c2c订单详情
    $config['501104'] = 'SELECT  c2c_orders.* from  c2c_orders where c2c_orders.id=[:1]';
    //查询所有交易对
    $config['501105'] = 'SELECT  symbols.symbol from  symbols where deleted_at is null';
    //根据指定的c2c冻结记录
    $config['501106'] = 'SELECT  balance from  user_c2c_freezes where `asset`=[:1] AND `user_id`=[:2]';
    //查询单个币资产活动详情
    $config['501107'] = 'SELECT  * from  activities where `id`=[:1]';
    //查询单个币种详情
    $config['501108'] = 'SELECT  * from  assets where `asset_code`=[:1] AND site_id=1';
    //查询单个交易对详情
    $config['501109'] = 'SELECT  * from  symbols where `symbol`=[:1] AND site_id=1';
    //id查询币资产详情
    $config['501110'] = 'SELECT  asset_code from  assets where id=[:1]';
    //id查询交易对详情
    $config['501111'] = 'SELECT  symbol from  symbols where id=[:1]';
    //查询表中是否有当前所提交的vip等级
    $config['501112'] = 'SELECT  vip_level from vip_discounts where vip_level=[:1]';
    //
    $config['501113'] = 'SELECT  id,asset_code from assets where site_id=[:1]';

    $config['501114'] = 'SELECT  * from balance_history_0';
    //获取最近的用户冻结资金
    $config['501115'] = 'SELECT  balance from user_asset_freezes where asset=[:1] AND user_id=[:2] order by id desc limit 1';
    //获取出c2c交易配置列表
    $config['501116'] = 'SELECT  a.*,b.name as site_name from `options` as a LEFT JOIN b_site as b ON a.site_id=b.id where `deleted_at` is null AND `site_id`=[:3]  limit [:1],[:2]';
    
    $config['501117'] = 'SELECT  count(`id`) as totalnum from `options` where `deleted_at` is null AND `site_id`=[:1]';
    
    $config['501118'] = 'SELECT id from `users` where `deleted_at` is null AND `site_id`=[:1]';

    $config['501119'] = 'SELECT id,card_number,BB.total_amount,BB.real_amount,BB.fee from merchant_banks as AAA LEFT JOIN (SELECT cast( 
sum(a.total_amount) AS DECIMAL (25,8) 
) as total_amount,cast( 
sum(a.fee) AS DECIMAL (25,8) 
) as fee,cast( 
sum(a.real_amount) AS DECIMAL (25,8) 
) as real_amount,a.created_at, b.card_number as c_number,b.id as c_id FROM c2c_orders as a LEFT JOIN merchant_banks as b ON a.merchant_bank_id=b.id where a.site_id =[:6] AND a.`type`=[:5] AND a.`status`=3 AND a.created_at>[:1] AND a.created_at<[:2] GROUP BY b.card_number) as BB ON AAA.card_number=BB.c_number
ORDER BY id ASC LIMIT [:3],[:4]';

    $config['501120'] = 'SELECT cast( 
sum(a.total_amount) AS DECIMAL (25,8) 
) as total_amount,cast( 
sum(a.fee) AS DECIMAL (25,8) 
) as fee,cast( 
sum(a.real_amount) AS DECIMAL (25,8) 
) as real_amount,a.created_at, b.card_number,b.id FROM c2c_orders as a LEFT JOIN merchant_banks as b ON a.merchant_bank_id=b.id where a.site_id =[:4] AND a.`type`=[:3] AND a.`status`=3 AND a.created_at>[:1] AND a.created_at<[:2] GROUP BY b.card_number';

//应收/应支
    $config['501121'] = 'SELECT id,card_number,BB.total_amount,BB.real_amount,BB.fee from merchant_banks as AAA LEFT JOIN (
SELECT 
cast( 
sum(a.total_amount) AS DECIMAL (25,8) 
) as total_amount,cast( 
sum(a.fee) AS DECIMAL (25,8) 
) as fee,cast( 
sum(a.real_amount) AS DECIMAL (25,8) 
) as real_amount,
b.card_number as c_number,b.id as c_id 
FROM c2c_orders as a
LEFT JOIN merchant_banks as b ON a.merchant_bank_id=b.id 
where a.site_id =[:2] AND a.`type`=[:1] AND a.`status`!=4 AND a.updated_at>[:3] AND a.updated_at<[:4] 
GROUP BY b.card_number
) as BB ON AAA.card_number=BB.c_number
ORDER BY id ASC LIMIT [:5],[:6]';
    
    
//实际收入/支出
    $config['501122'] = 'SELECT id,card_number,BB.total_amount,BB.real_amount,BB.fee from merchant_banks as AAA LEFT JOIN (
SELECT 
cast( 
sum(a.total_amount) AS DECIMAL (25,8) 
) as total_amount,cast( 
sum(a.fee) AS DECIMAL (25,8) 
) as fee,cast( 
sum(a.real_amount) AS DECIMAL (25,8) 
) as real_amount,
b.card_number as c_number,b.id as c_id 
FROM c2c_orders as a
LEFT JOIN merchant_banks as b ON a.merchant_bank_id=b.id 
where a.site_id =[:2] AND a.`type`=[:1] AND a.`status`=3 AND a.updated_at>[:3] AND a.updated_at<[:4] 
GROUP BY b.card_number
) as BB ON AAA.card_number=BB.c_number
ORDER BY id ASC LIMIT [:5],[:6]';







    $config['501123'] = 'SELECT card_number from `user_banks` where `user_id`=[:1]';
    //获取财务信息列表的单条记录详情（bank_inout）
    $config['501124'] = 'SELECT * from `bank_inout` where `id`=[:1]';

    $config['501125'] = 'SELECT * from `bank_inout` where `m_bank_id`=[:1] AND `type`=[:2] AND `status`=[:3] AND `user_name`=[:4]';

    $config['501126'] = 'SELECT sum(`amount`) as amount from `bank_inout` where `m_bank_id`=[:1] AND `status`=[:2] AND `type`=[:3]';

    //根据站点id查询所有交易对
    $config['501127'] = 'SELECT  symbols.symbol from  symbols where site_id = [:1] and deleted_at is null';

    $config['501128'] = 'SELECT  count(*) as num from  b_banner where site_id = [:1] and type=2 and endpoint=[:2]';

    $config['501129'] = 'SELECT  count(*) as num from  perday_userstatistic where `time` = [:1]';

    $config['501130'] = 'SELECT * from  activity_holding_config where `id` = [:1]';

    $config['501131'] = 'SELECT id from  users';

    $config['501132'] = 'SELECT balance from  user_asset_freezes where asset =[:2] and user_id=[:1] order by id desc limit 1';
    
    $config['501133'] = 'SELECT id,asset,user_id,snapshot_asset,award_percent from  activity_holding_award where h_c_id =[:1] and status=[:2]';

    $config['501134'] = 'SELECT api_key from  user_apps where `api_key` =[:1]';

    //查询系统币种详情
    $config['501135'] = 'SELECT  * from  total_assets where `asset_code`=[:1]';

    $config['501136'] = 'SELECT  * from  total_symbols where `symbol`=[:1]';

    $config['501137'] = 'SELECT  * from  symbols where `symbol`=[:1] AND site_id=[:2]';

    $config['501138'] = 'SELECT  * from  total_assets where `id`=[:1]';

    $config['501139'] = 'SELECT  * from  total_symbols where `id`=[:1]';

    $config['501140'] = 'SELECT  id from  users where `id`=[:1]';

    $config['501141'] = 'SELECT  code from  treasures order by id desc limit 1';

    $config['501142'] = 'SELECT  * from  treasures where `id`=[:1]';

    $config['501143'] = 'SELECT  * from  treasure_sessions where `id`=[:1]';

    $config['501144'] = 'SELECT  * from  treasures where `code`=[:1]';

    $config['501145'] = 'SELECT  * from  treasure_sessions where `treasure_id`=[:1] and `code`=[:2]';

    $config['501146'] = 'SELECT  * from  user_treasure_logs where `session_id`=[:1] and `code`=[:2]';

    $config['501147'] = 'SELECT  * from  treasure_sessions where `treasure_id`=[:1]';

    $config['501148'] = 'select * from `users` WHERE 1=1 AND `id`=[:1]';

    $config['501149'] = 'select * from `total_assets`';

    $config['501150'] = 'SELECT  symbols.symbol from symbols where site_id=[:1]';

    $config['501151'] = 'SELECT  card_number from  merchant_banks where card_number=[:1]';

    $config['501152'] = 'SELECT  * from  mail_tongji_config where tongji_type=[:1]';

    $config['501153'] = 'SELECT  * from  mail_tongji_config where tongji_type=[:1]';

    $config['501154'] = 'SELECT  * from  user_identities where id=[:1]';

    $config['501155'] = 'SELECT  * from  perday_data_statistics order by id desc limit 1';

    $config['501156'] = 'SELECT  balance from user_asset_operatings where asset=[:1] AND user_id=[:2] order by id desc limit 1';

    $config['501157'] = 'SELECT  * from  perday_register_statistics order by id desc limit 1';

    $config['501158'] = 'SELECT  * from  perday_recharge_statistics order by id desc limit 1';

    $config['501159'] = 'SELECT  * from  perday_withdraw_statistics order by id desc limit 1';

    $config['501160'] = 'SELECT  * from  user_identity_imgs where user_identity_id = [:1] and deleted_at is null order by id desc';

    $config['501161'] = 'SELECT  * from  countries where id = [:1]';

    $config['501162'] = 'SELECT  * from  users where phone = [:1] and id!=[:2]';

    $config['501163'] = 'SELECT  * from  users where email = [:1] and id!=[:2]';

    $config['501164'] = 'SELECT  * from  symbol_classes where site_id = [:1] and deleted_at is null';

    $config['501165'] = 'SELECT  symbol_id from  symbol_relations where symbol_class_id = [:1] and deleted_at is null';

    $config['501166'] = 'SELECT  id from  symbol_classes where site_id = [:1] and name=[:2] and deleted_at is null';

    $config['501167'] = 'SELECT  id from  symbol_classes where site_id = [:1] and unique_id=[:2] and deleted_at is null';

    $config['501168'] = 'SELECT  id from  symbol_classes where site_id = [:1] and shorthand=[:2] and deleted_at is null';

    $config['501169'] = 'SELECT  *  from  b_inviteimg_config where id = [:1] and deleted_at is null';

    $config['501170'] = 'SELECT  *  from  b_site_email where id = [:1] and deleted_at is null';

    $config['501171'] = 'SELECT  *  from  b_site_sms where id = [:1] and deleted_at is null';

    $config['501172'] = 'SELECT  total,asset,snapshot_time from  asset_snapshots where asset = [:1] and snapshot_time= [:2] and deleted_at is null';
   
    $config['501173'] = 'SELECT  * from  asset_snapshots where asset = [:1] and created_at>=[:2] and created_at<[:3] and deleted_at is null';

    $config['501174'] = 'SELECT  * from  merchant_banks where admin_id = [:1] and deleted_at is null';

    $config['501175'] = 'SELECT  * from  tickets where id = [:1]';

    $config['501176'] = 'SELECT  symbol from  total_symbols where deleted_at is null';

    $config['501177'] = 'SELECT * from  user_lock_positions where deleted_at is null and asset=[:1] and user_id=[:2] and status=[:3]';

    $config['501178'] = 'SELECT sum(`amount`) as amount from `otc_inout` where `m_bank_id`=[:1] AND `status`=[:2] AND `type`=[:3]';

    $config['501179'] = 'SELECT * from `otc_inout` where `id`=[:1]';

    $config['501180'] = 'SELECT  * from  merchant_account where admin_id = [:1] and deleted_at is null';
    //以手机号或者邮箱查询用户信息
    $config['501181'] = 'SELECT  id,phone,email from  users where phone = [:1] or email = [:1]';

    $config['501182'] = 'SELECT ip from admin_white_ip where admin_id = [:1]';

    $config['501183'] = 'SELECT ip from admin_white_ip where admin_id = [:1] and deleted_at is null';
    //查询是否有重复api配置用户
    $config['501184'] = 'SELECT count(*) as numrows from user_apps where `user_id` =[:1] and deleted_at is null';

    $config['501185'] = 'SELECT name from symbol_classes_exp where `symbol_classes_id` =[:1] and `lang`=[:2]';

    $config['501186'] = 'SELECT statement from symbol_classes_exp where `symbol_classes_id` =[:1] and `lang`=[:2]';









    //更改冻结资金
    $config['501301'] = 'UPDATE `user_withdraw_freezes` SET `balance`=`balance`-[:3] where `asset`=[:1] AND `user_id`=[:2]';
    //更改提现状态
    $config['501302'] = 'UPDATE `user_withdraws` SET `status`=[:2],`process_time`=[:3],`remark`=[:4] where `id`=[:1]';
    //更改币资产种类
    $config['501303'] = 'UPDATE `assets` SET `asset_code`=[:1],`asset_name`=[:2],`recharge_status`=[:3],`withdraw_status`=[:4],`trade_status`=[:5],`withdraw_fee`=[:6],`precision`=[:7],`site_id`=[:8],`updated_at`=[:9],`withdraw_min`=[:11],`withdraw_max`=[:12],`is_display`=[:13],`has_memo`=[:14],`recharge_verify`=[:15],`min_amount`=[:16],`min_confirmation`=[:17],`withdraw_verify_amount`=[:18] where `id`=[:10]';
    //更改交易对信息
    $config['501304'] = 'UPDATE `symbols` SET `base_asset`=[:1],`quote_asset`=[:2],`symbol`=[:3],`tick_size`=[:4],`min_quantity`=[:5],`status`=[:6],`recommend`=[:7],`limit_taker_fee`=[:8],`limit_maker_fee`=[:9],`market_taker_fee`=[:10],`site_id`=[:11],`updated_at`=[:12],`base_asset_precision`=[:13],`quote_asset_precision`=[:14],`is_display`=[:16],`base_asset_name`=[:17],`quote_asset_name`=[:18] where `id`=[:15]';
    //更改银行卡
    $config['501305'] = 'UPDATE `merchant_banks` SET `name`=[:1],`bank`=[:2],`sub_bank`=[:3],`card_number`=[:4],`updated_at`=[:5],`site_id`=[:7],`type`=[:8],`limit_money`=[:9],`cash_deposit`=[:10],`contact_way`=[:11],`admin_id`=[:12] where `id`=[:6]';
    //更改c2c订单的状态
    $config['501306'] = 'UPDATE `c2c_orders` SET `status`=[:2],`process_time`=[:3],`updated_at`=[:4] where `id`=[:1]';
    //更改c2c冻结资金
    $config['501307'] = 'UPDATE `user_c2c_freezes` SET `balance`=`balance`-[:3] where `asset`=[:1] AND `user_id`=[:2]';
    //银行卡置为不可用
    $config['501308'] = 'UPDATE `merchant_banks` SET `status`=[:1] where `id`=[:2]';
    //更改活动
    $config['501309'] = 'UPDATE `activities` SET `top_two_award_status`=[:1],`top_two_award`=[:2],`top_two_award_asset`=[:3],`event`=[:4],`name`=[:5],`start_time`=[:6],`end_time`=[:7],`award`=[:8],`award_asset`=[:9],`top_award`=[:10],`top_award_asset`=[:11],`top_award_status`=[:12],`site_id`=[:13],`updated_at`=[:14],`recharge_asset`=[:16],`recharge_award_rate`=[:17],`is_lock`=[:18],`award_total`=[:19],`top_award_total`=[:20],`top_two_award_total`=[:21] where `id`=[:15]';
    //活动置为不可用
    $config['501310'] = 'UPDATE `activities` SET `deleted_at`=[:2] where `id`=[:1]';
    //
    $config['501311'] = 'UPDATE `users` SET `two_step_bound`=0 where `id`=[:1]';

    $config['501312'] = 'UPDATE `assets` SET `asset_code`=[:2],`asset_name`=[:3] where `asset_code`=[:1] AND `site_id`>1';

    $config['501313'] = 'UPDATE `symbols` SET `base_asset`=[:2],`quote_asset`=[:3],`symbol`=[:4],`tick_size`=[:5],`min_quantity`=[:6] where `symbol`=[:1] AND `site_id`>1';
    
    $config['501314'] = 'UPDATE `vip_discounts` SET `vip_level`=[:1],`trade_limit_taker_discount`=[:2],`trade_limit_maker_discount`=[:3],`trade_market_taker_discount`=[:4],`withdraw_discount`=[:5],`updated_at`=[:6] where `id`=[:7]';

    $config['501315'] = 'UPDATE `user_vips` SET `vip_level`=[:2] where `user_id` in ([:1])';

    $config['501316'] = 'UPDATE `users` SET `forbidden_login`=[:2] where `id`=[:1]';

    $config['501317'] = 'UPDATE `users` SET `forbidden_withdraw`=[:2] where `id`=[:1]';

    $config['501318'] = 'UPDATE `users` SET `forbidden_trade`=[:2] where `id`=[:1]';

    $config['501319'] = 'UPDATE `options` SET `value`=[:2],`memo`=[:3],`site_id`=[:4] where `id`=[:1]';

    $config['501320'] = 'UPDATE `bank_inout` SET `user_bank_number`=[:1],`user_name`=[:2],`amount`=[:3],`type`=[:4],`updated_at`=[:5],`trans_remark`=[:6],`remark`=[:7],`status`=[:8],`site_id`=[:10] where `id`=[:9]';

    $config['501321'] = 'UPDATE `bank_inout` SET `status`=[:2] where `id`=[:1]';

    $config['501322'] = 'UPDATE `b_help_class` SET `name`=[:1],`display_order`=[:2],`site_id`=[:3],`lang`=[:5] where `id`=[:4]';
    
    $config['501323'] = 'UPDATE `app_upgrades` SET `app_endpoint`=[:1],`version_id`=[:2],`version_major`=[:3],`version_minor`=[:4],`version_code`=[:5],`type`=[:6],`apk_url`=[:7],`upgrade_point`=[:8],`status`=[:9],`site_id`=[:10],`admin_id`=[:11],`remark`=[:12],`updated_at`=[:13] where `id`=[:14]';
    
    $config['501324'] = 'UPDATE `app_upgrades` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501325'] = 'UPDATE `app_upgrades` SET `status`=[:2] where `app_endpoint`=[:1] AND `site_id`=[:3]';

    $config['501326'] = 'UPDATE `user_lock_positions` SET `asset`=[:1],`user_id`=[:2],`amount`=[:3],`expire_time`=[:4],`remark`=[:5],`updated_at`=[:6] where `id`=[:7]';

    $config['501327'] = 'UPDATE `user_lock_positions` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501328'] = 'UPDATE `user_lock_positions` SET `status`=1,`check_status`=2 where `id`=[:1]';

    $config['501329'] = 'UPDATE `labelconfig` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501330'] = 'UPDATE `labelconfig` SET `label_name`=[:1],`api_url`=[:2],`order`=[:3],`type`=[:4],`site_id`=[:5],`updated_at`=[:6],`class_id`=[:8],`icon`=[:9],`qrcode`=[:10],`lang`=[:11] where `id`=[:7]';
   
    $config['501331'] = 'UPDATE `activity_holding_config` SET `asset`=[:1],`hold_area`=[:2],`award_get`=[:3],`snapshot`=[:4],`site_id`=[:5],`updated_at`=[:6] where `id`=[:7]';

    $config['501332'] = 'UPDATE `activity_holding_config` SET `deleted_at`=[:2] where `id`=[:1]';
    
    $config['501333'] = 'UPDATE `activity_holding_award` SET `award`=[:2],`status`=1,`updated_at`=[:3] where `id`=[:1]';

    $config['501334'] = 'UPDATE `activity_holding_config` SET `status`=3 where `id`=[:1]';

    $config['501335'] = 'UPDATE `user_apps` SET `user_id`=[:1],`api_key`=[:2],`secret_key`=[:3],`updated_at`=[:4],`bind_ips`=[:6],`remark`=[:7],`expire_time`=[:8] where `id`=[:5]';

    $config['501336'] = 'UPDATE `user_apps` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501337'] = 'UPDATE `total_assets` SET `asset_code`=[:1],`asset_name`=[:2],`recharge_status`=[:3],`withdraw_status`=[:4],`trade_status`=[:5],`withdraw_fee`=[:6],`precision`=[:7],`sub_true`=[:8],`updated_at`=[:9],`withdraw_min`=[:11],`withdraw_max`=[:12],`is_exclusive`=[:13],`has_memo`=[:14],`recharge_verify`=[:15],`min_amount`=[:16],`min_confirmation`=[:17],`withdraw_verify_amount`=[:18],`regex`=[:19],`warning_status`=[:20],`withdraw_fee_percent`=[:21] where `id`=[:10]';

    $config['501338'] = 'UPDATE `total_symbols` SET `base_asset`=[:1],`quote_asset`=[:2],`symbol`=[:3],`tick_size`=[:4],`min_quantity`=[:5],`status`=[:6],`recommend`=[:7],`limit_taker_fee`=[:8],`limit_maker_fee`=[:9],`market_taker_fee`=[:10],`sub_true`=[:11],`updated_at`=[:12],`base_asset_precision`=[:13],`quote_asset_precision`=[:14],`is_exclusive`=[:16],`base_asset_name`=[:17],`quote_asset_name`=[:18],`alert_percent`=[:19] where `id`=[:15]';

    $config['501339'] = 'UPDATE `treasures` SET `name`=[:1],`code`=[:2],`init_method`=[:3],`total`=[:4],`pay_per_max`=[:5],`pay_amount`=[:6],`pay_asset`=[:7],`unaward_rule`=[:8],`award_type`=[:9],`award`=[:10],`award_detail`=[:11],`award_img`=[:12],`start_time`=[:13],`end_time`=[:14],`day_start_time`=[:15],`day_end_time`=[:16],`finished`=[:17],`site_id`=[:18],`updated_at`=[:19] where `id`=[:20]';

    $config['501340'] = 'UPDATE `treasures` SET `finished`=[:1] where `id`=[:2]';

    $config['501341'] = 'UPDATE `treasures` SET `is_display`=[:1] where `id`=[:2]';

    $config['501342'] = 'UPDATE `mail_tongji_config` SET `site_id`=[:1],`uid`=[:2],`email`=[:3],`tongji_type`=[:4],`updated_at`=[:5] where `id`=[:6]';

    $config['501343'] = 'DELETE FROM `mail_tongji_config` where `id`=[:1]';

    $config['501344'] = 'UPDATE `user_identities` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501345'] = 'UPDATE `users` SET `phone`=[:2],`email`=[:3] where `id`=[:1]';

    $config['501346'] = 'UPDATE `user_identities` SET `status`=[:2],`remark`=[:3],`updated_at`=[:4] where `id`=[:1]';

    $config['501347'] = 'UPDATE `users` SET `user_identity_auth`=1,`identity_success_time`=[:2] where `id`=[:1]';

    $config['501348'] = 'UPDATE `user_identity_imgs` SET `deleted_at`=[:2] where `user_identity_id`=[:1]';

    $config['501349'] = 'UPDATE `users` SET `user_identity_auth`=0 where `id`=[:1]';

    $config['501350'] = 'UPDATE `users` SET `password`=[:2] where `id`=[:1]';

    $config['501351'] = 'UPDATE `users` SET `withdraw_password`=[:2] where `id`=[:1]';

    $config['501352'] = 'UPDATE `asset_intros` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501353'] = 'UPDATE `asset_intros` SET `asset_code`=[:1],`icon`=[:2],`desc`=[:3],`full_name`=[:4],`official_website`=[:5],`white_paper`=[:6],`block_query`=[:7],`founding_team`=[:8],`recommend_organization`=[:9],`release_time`=[:10],`release_total`=[:11],`circulation_total`=[:12],`detail`=[:13],`updated_at`=[:14],`erc`=[:16],`lang`=[:17],`three_url`=[:18],`three_icon`=[:19] where `id`=[:15]';

    $config['501354'] = 'UPDATE `symbol_classes` SET `site_id`=[:1],`name`=[:2],`unique_id`=[:3],`display_order`=[:4],`shorthand`=[:5],`updated_at`=[:6],`symbol_count`=[:8],`lang`=[:9],`icon`=[:10] where `id`=[:7]';

    $config['501355'] = 'UPDATE `symbol_classes` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501356'] = 'UPDATE `symbol_relations` SET `deleted_at`=[:2] where `symbol_class_id`=[:1]';

    $config['501357'] = 'UPDATE `b_site_sms` SET `site_id`=[:1],`is_default`=[:2],`account`=[:3],`password`=[:4],`sign_name`=[:5],`channel`=[:6],`dy_template_code`=[:7],`internal`=[:8],`updated_at`=[:9] where `id`=[:10]';

    $config['501358'] = 'UPDATE `b_site_sms` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501359'] = 'UPDATE `b_site_email` SET `site_id`=[:1],`is_default`=[:2],`account`=[:3],`password`=[:4],`channel`=[:5],`updated_at`=[:6] where `id`=[:7]';

    $config['501360'] = 'UPDATE `b_site_email` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501361'] = 'UPDATE `b_inviteimg_config` SET `site_id`=[:1],`image`=[:2],`qrcode_x`=[:3],`qrcode_y`=[:4],`qrcode_w`=[:5],`qrcode_h`=[:6],`updated_at`=[:7] WHERE `id`=[:8]';
    $config['501362'] = 'UPDATE `b_inviteimg_config` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501363'] = 'UPDATE `b_inviteimg_config` SET `is_used`=0 where `site_id`=[:1] and `id`!=[:2]';
    
    $config['501364'] = 'UPDATE `b_inviteimg_config` SET `is_used`=1 where `id`=[:1]';

    $config['501365'] = 'UPDATE `b_site_email` SET `is_default`=1 where `id`=[:1]';

    $config['501366'] = 'UPDATE `b_site_email` SET `is_default`=0 where `site_id`=[:1] and `id`!=[:2]';

    $config['501367'] = 'UPDATE `b_site_sms` SET `is_default`=0 where `site_id`=[:1] and `id`!=[:2]';

    $config['501368'] = 'UPDATE `b_site_sms` SET `is_default`=1 where `id`=[:1]';

    $config['501370'] = 'UPDATE `user_two_factors` SET `deleted_at`=[:2] where `user_id`=[:1]';

    $config['501369'] = 'UPDATE `b_admin` SET `admin_language_switch`=[:2] where `user_id`=[:1]';
    //$first_name,$last_name,$name,$number,$country_id
    $config['501371'] = 'UPDATE `user_identities` SET `first_name`=[:2],`last_name`=[:3],`name`=[:4],`number`=[:5],`country_id`=[:6] where `id`=[:1]';

    $config['501372'] = 'UPDATE `b_site_ip` SET `ip`=[:1],`type`=[:2],`expire_time`=[:3],`remark`=[:4],`updated_at`=[:5],`site_id`=[:7] where `id`=[:6]';

    $config['501373'] = 'UPDATE `b_site_ip` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501374'] = 'UPDATE `b_news_content` SET `title`=[:1],`news_id`=[:2],`content`=[:3],`updated_at`=[:4],`lang`=[:6],`resume`=[:7] where `id`=[:5]';

    $config['501375'] = 'UPDATE `b_news_content` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501376'] = 'UPDATE `assets` SET `asset_name`=[:2] where `asset_code`=[:1]';
    $config['501377'] = 'UPDATE `symbols` SET `base_asset_name`=[:2] where `base_asset`=[:1]';
    $config['501378'] = 'UPDATE `total_symbols` SET `base_asset_name`=[:2] where `base_asset`=[:1]';

    $config['501379'] = 'UPDATE `tickets` SET `close_time`=[:2],`status`=[:3] where `id`=[:1]';

    $config['501380'] = 'UPDATE `tickets` SET `status`=[:1] where `id`=[:2]';

    $config['501381'] = 'UPDATE `b_help_content` SET `title`=[:1],`help_id`=[:2],`content`=[:3],`updated_at`=[:4],`lang`=[:6] where `id`=[:5]';

    $config['501382'] = 'UPDATE `b_help_content` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501383'] = 'UPDATE `b_help_class_content` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501384'] = 'UPDATE `b_help_class_content` SET `name`=[:1],`help_class_id`=[:2],`lang`=[:3],`display_order`=[:4],`updated_at`=[:5] where `id`=[:6]';

    $config['501385'] = 'UPDATE `merchant_account` SET `name`=[:1],`bank`=[:2],`sub_bank`=[:3],`card_number`=[:4],`updated_at`=[:5],`site_id`=[:7],`type`=[:8],`limit_money_high`=[:9],`cash_deposit`=[:10],`contact_way`=[:11],`admin_id`=[:12],`alipay_number`=[:13],`alipay_name`=[:14],`alipay_image`=[:15],`wechat_number`=[:16],`wechat_name`=[:17],`wechat_image`=[:18],`limit_money_low`=[:19],`pay_method`=[:20],`price`=[:21],`amount`=[:22],`transaction_number`=[:23] where `id`=[:6]';

    $config['501386'] = 'UPDATE `merchant_account` SET `status`=[:1] where `id`=[:2]';

    $config['501387'] = 'UPDATE `otc_inout` SET `user_bank_number`=[:1],`user_name`=[:2],`amount`=[:3],`type`=[:4],`updated_at`=[:5],`trans_remark`=[:6],`remark`=[:7],`status`=[:8],`site_id`=[:10] where `id`=[:9]';

    $config['501388'] = 'UPDATE `symbols` SET `base_asset_name`=[:2] where `base_asset`=[:1]';

    $config['501389'] = 'UPDATE `symbols` SET `quote_asset_name`=[:2] where `quote_asset`=[:1]';

    $config['501390'] = 'UPDATE `assets` SET `withdraw_verify_amount`=[:2] where `asset_code`=[:1]';

    $config['501391'] = 'UPDATE `admin_white_ip` SET `admin_id`=[:1],`ip`=[:2],`updated_at`=[:3] where `id`=[:4]';

    $config['501392'] = 'UPDATE `admin_white_ip` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['501393'] = 'UPDATE `assets` SET `min_confirmation`=[:2] where `asset_code`=[:1]';

    $config['501394'] = 'UPDATE `assets` SET `regex`=[:2] where `asset_code`=[:1]';

    $config['501395'] = 'UPDATE `user_withdraws` SET `process_time`=[:2],`remark`=[:3] where `id`=[:1]';

    $config['501396'] = 'UPDATE `assets` SET `withdraw_fee_percent`=[:2] where `asset_code`=[:1]';

    $config['501397'] = 'UPDATE `symbols` SET `alert_percent`=[:2] where `symbol`=[:1]';

    $config['501398'] = 'UPDATE `advert_place` SET `title`=[:1],`site_id`=[:2],`img`=[:3],`url`=[:4],`updated_at`=[:5] where `id`=[:6]';

    $config['501399'] = 'UPDATE `advert_place` SET `deleted_at`=[:2] where `id`=[:1]';

    $config['502301'] = 'UPDATE `fingerpost` SET `title`=[:1],`desc`=[:2],`site_id`=[:3],`img`=[:4],`vedio`=[:5],`order`=[:6],`updated_at`=[:7] where `id`=[:8]';

    $config['502302'] = 'UPDATE `fingerpost` SET `deleted_at`=[:2] where `id`=[:1]';


    $config['502303'] = 'UPDATE `user_apps` SET `status`=[:2] where `id`=[:1]';

    $config['502304'] = 'UPDATE `advert_place` SET `status`=[:2] where `id`=[:1]';

    $config['502305'] = 'UPDATE `fingerpost` SET `status`=[:2] where `id`=[:1]';

    $config['502306'] = 'UPDATE `user_apps` SET `user_id`=[:1],`api_key`=[:2],`secret_key`=[:3],`updated_at`=[:4],`bind_ips`=[:6],`remark`=[:7],`expire_time`=[:8] where `id`=[:5]';

    $config['502310'] = 'UPDATE `assets` SET `has_memo`=[:2] where `asset_code`=[:1]';

    $config['502311'] = 'UPDATE `assets` SET `precision`=[:2] where `asset_code`=[:1]';




    // $config['501384'] = 'UPDATE `b_help_class_content` SET `deleted_at`=[:2] where `id`=[:1]';



    //新增币资产种类
    $config['501201'] = 'INSERT INTO `assets` (asset_code,asset_name,recharge_status,withdraw_status,trade_status,withdraw_fee,`precision`,site_id,created_at,updated_at,withdraw_min,withdraw_max,is_display,has_memo,recharge_verify,min_amount,min_confirmation,withdraw_verify_amount) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18])';

    $config['501206'] = 'INSERT INTO `assets` (asset_code,asset_name,recharge_status,withdraw_status,trade_status,withdraw_fee,`precision`,site_id,created_at,updated_at,parent_id,withdraw_min,withdraw_max) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13])';
    //新增币交易对
    $config['501202'] = 'INSERT INTO `symbols` (base_asset,quote_asset,symbol,tick_size,min_quantity,status,recommend,limit_taker_fee,limit_maker_fee,market_taker_fee,site_id,created_at,updated_at,base_asset_precision,quote_asset_precision,is_display,base_asset_name,quote_asset_name) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18])';
    //新增银行卡
    $config['501203'] = 'INSERT INTO `merchant_banks` (name,bank,sub_bank,card_number,created_at,updated_at,status,site_id,type,limit_money,cash_deposit,contact_way,admin_id) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13])';
    //新增活动
    $config['501204'] = 'INSERT INTO `activities` (top_two_award_status,top_two_award,top_two_award_asset,event,name,start_time,end_time,award,award_asset,top_award,top_award_asset,top_award_status,site_id,created_at,updated_at,recharge_asset,recharge_award_rate,is_lock,award_total,top_award_total,top_two_award_total) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19],[:20],[:21])';
    //新增变更资金操作记录
    $config['501205'] = 'INSERT INTO `operation_money_logs` (admin_id,created_time,asset_code,amount,user_id,`extra`,`site_id`,`type`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
    
    $config['501208'] = 'INSERT INTO `user_asset_freezes` (created_at,updated_at,user_id,asset,`change`,business,balance,detail) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
    
    $config['501207'] = 'INSERT INTO `vip_discounts` (vip_level,trade_limit_taker_discount,trade_limit_maker_discount,trade_market_taker_discount,withdraw_discount,created_at,updated_at) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';

    $config['501209'] = 'INSERT INTO `options` (var_name,value,memo,site_id) VALUES ([:1],[:2],[:3],[:4])';

    $config['501210'] = 'INSERT INTO `event_logs` (created_at,updated_at,`name`,`ip`,`endpoint`,`params`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';
    $config['501211'] = 'INSERT INTO `bank_inout` (`m_bank_id`,`user_bank_number`,`user_name`,`amount`,`type`,`created_at`,`updated_at`,`trans_remark`,`remark`,`status`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11])';
    //添加每日的交易统计数据（定时任务）
    $config['501212'] = 'INSERT INTO `perday_tradelogs` (`time_area`,`symbol`,`start_time`,`end_time`,`total`,`number`,`BID_fee`,`ASK_fee`,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';

    $config['501213'] = 'INSERT INTO `b_help_class` (name,display_order,site_id,`lang`) VALUES ([:1],[:2],[:3],[:4])';

    $config['501214'] = 'INSERT INTO `sssss` (`url`) VALUES ([:1])';

    $config['501215'] = 'INSERT INTO `perday_userstatistic` (`site_name`,`site_id`,`time`,`time_area`,`register_user`,`recommend_user`,`identity_user`,`login_user`,`last_rate`,`three_rate`,`seven_rate`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11])';

    $config['501216'] = 'INSERT INTO `app_upgrades` (app_endpoint,version_id,version_major,version_minor,version_code,`type`,apk_url,upgrade_point,`status`,site_id,admin_id,`remark`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14])';
    $config['501217'] = 'INSERT INTO `user_lock_positions` (`asset`,`user_id`,`amount`,`expire_time`,`remark`,`status`,`created_at`,`updated_at`,`check_status`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';

    
    $config['501218'] = 'INSERT INTO `labelconfig` (`label_name`,`api_url`,`order`,`type`,`site_id`,`created_at`,`updated_at`,`class_id`,`icon`,`qrcode`,`lang`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11])';
    
    $config['501219'] = 'INSERT INTO `activity_holding_config` (`asset`,`hold_area`,`award_get`,`snapshot`,`site_id`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';

    $config['501220'] = 'INSERT INTO `activity_holding_award` (`asset`,`user_id`,`h_c_id`,`snapshot`,`snapshot_asset`,`award_grant`,`award_percent`,`status`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';

    $config['501221'] = 'INSERT INTO `user_apps` (`user_id`,`api_key`,`secret_key`,`created_at`,`updated_at`,`admin_id`,`remark`,`bind_ips`,`site_id`,`expire_time`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';

    $config['501222'] = 'INSERT INTO `assets` (asset_code,asset_name,recharge_status,withdraw_status,trade_status,withdraw_fee,`precision`,site_id,created_at,updated_at,withdraw_min,withdraw_max,sub_true,has_memo,regex,warning_status,withdraw_fee_percent) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17])';

    $config['501223'] = 'INSERT INTO `symbols` (base_asset,quote_asset,symbol,tick_size,min_quantity,status,recommend,limit_taker_fee,limit_maker_fee,market_taker_fee,site_id,created_at,updated_at,base_asset_precision,quote_asset_precision,sub_true,base_asset_name,quote_asset_name,alert_percent) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19])';

    $config['501224'] = 'INSERT INTO `total_assets` (asset_code,asset_name,recharge_status,withdraw_status,trade_status,withdraw_fee,`precision`,sub_true,created_at,updated_at,withdraw_min,withdraw_max,is_exclusive,has_memo,recharge_verify,min_amount,min_confirmation,withdraw_verify_amount,regex,warning_status,withdraw_fee_percent) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19],[:20],[:21])';

    $config['501225'] = 'INSERT INTO `total_symbols` (base_asset,quote_asset,symbol,tick_size,min_quantity,status,recommend,limit_taker_fee,limit_maker_fee,market_taker_fee,sub_true,created_at,updated_at,base_asset_precision,quote_asset_precision,is_exclusive,base_asset_name,quote_asset_name,alert_percent) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19])';

    $config['501226'] = 'INSERT INTO `assets` (asset_code,asset_name,recharge_status,withdraw_status,trade_status,withdraw_fee,`precision`,site_id,created_at,updated_at,withdraw_min,withdraw_max,sub_true,has_memo,recharge_verify,min_amount,min_confirmation,withdraw_verify_amount,regex,warning_status,withdraw_fee_percent) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19],[:20],[:21])';

    $config['501227'] = 'INSERT INTO `treasures` (`name`,`code`,init_method,`total`,pay_per_max,pay_amount,pay_asset,unaward_rule,award_type,`award`,award_detail,award_img,`start_time`,`end_time`,`day_start_time`,`day_end_time`,`finished`,`site_id`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19],[:20])';

    $config['501228'] = 'INSERT INTO `mail_tongji_config` (`site_id`,`uid`,`email`,`tongji_type`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';

    $config['501229'] = 'INSERT INTO `csv_logs` (`tongji_type`,`url`,`created_at`) VALUES ([:1],[:2],[:3])';

    $config['501230'] = 'INSERT INTO `perday_data_statistics` (`site_id`,`created_at`,`updated_at`,`register_amount`,`invite_register_amount`,`trunname_amount`,`c2c_trade_amount`,`recharge_amount`,`withdraw_amount`,`coin_trade_amount`,`register_total`,`invite_register_total`,`trunname_total`,`c2c_trade_total`,`recharge_total`,`withdraw_total`,`coin_trade_total`,`time`,`time_area`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19])';

    $config['501231'] = 'INSERT INTO `perday_register_statistics` (`site_id`,`time_area`,`time`,`register_amount`,`trunname_amount`,`invite_register_amount`,`invite_trunname_amount`,`active_amount`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';

    $config['501232'] = 'INSERT INTO `perday_recharge_statistics` (`site_id`,`time_area`,`time`,`asset_code`,`recharge_total`,`price`,`number`,`recharge_number`,`per_recharge_amount`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';

    $config['501233'] = 'INSERT INTO `perday_c2cbuy_statistics` (`site_id`,`time_area`,`time`,`orders_total`,`orders_finish_total`,`orders_total_number`,`trading_amount`,`trading_number`,`per_trading_amount`,`complete_rate`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';

    $config['501234'] = 'INSERT INTO `perday_c2csell_statistics` (`site_id`,`time_area`,`time`,`orders_total`,`orders_finish_total`,`orders_total_number`,`trading_amount`,`trading_number`,`per_trading_amount`,`complete_rate`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';

    $config['501235'] = 'INSERT INTO `perday_withdraw_statistics` (`site_id`,`time_area`,`time`,`symbols`,`withdraw_total`,`price`,`number`,`withdraw_number`,`per_withdraw_amount`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';

    $config['501236'] = 'INSERT INTO `perday_coin_trade_statistics` (`site_id`,`time_area`,`time`,`symbols`,`trading_amount`,`trading_number`,`people`,`BID_fee`,`ASK_fee`,`per_trading_amount`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';

    $config['501237'] = 'INSERT INTO `asset_intros` (`asset_code`,`icon`,`desc`,`full_name`,`official_website`,`white_paper`,`block_query`,`founding_team`,`recommend_organization`,`release_time`,`release_total`,`circulation_total`,`detail`,`created_at`,`updated_at`,`erc`,`lang`,`three_url`,`three_icon`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19])';

    $config['501238'] = 'INSERT INTO `symbol_classes` (`site_id`,`name`,`unique_id`,`display_order`,`shorthand`,`created_at`,`updated_at`,`symbol_count`,`lang`,`icon`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';

    $config['501239'] = 'INSERT INTO `symbol_relations` (`created_at`,`updated_at`,`symbol_id`,`symbol_class_id`) VALUES ([:1],[:2],[:3],[:4])';

    $config['501240'] = 'INSERT INTO `b_site_sms` (`site_id`,`is_default`,`account`,`password`,`sign_name`,`channel`,`dy_template_code`,`internal`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';

    $config['501241'] = 'INSERT INTO `b_site_email` (`site_id`,`is_default`,`account`,`password`,`channel`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
    
    $config['501242'] = 'INSERT INTO `b_inviteimg_config` (`site_id`,`image`,`qrcode_x`,`qrcode_y`,`qrcode_w`,`qrcode_h`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';

    $config['501243'] = 'INSERT INTO `b_site_ip` (`ip`,`type`,`expire_time`,`remark`,`created_at`,`updated_at`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';

    $config['501244'] = 'INSERT INTO `b_news_content` (`title`,`news_id`,`content`,`created_at`,`updated_at`,`lang`,`resume`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';

    $config['501245'] = 'INSERT INTO `ticket_messages` (`ticket_id`,`message`,`attach`,`created_at`,`updated_at`,`is_sys`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';

    $config['501246'] = 'INSERT INTO `b_help_content` (`title`,`help_id`,`content`,`created_at`,`updated_at`,`lang`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';

    $config['501247'] = 'INSERT INTO `b_help_class_content` (`name`,`help_class_id`,`lang`,`display_order`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';

    //新增商户
    $config['501248'] = 'INSERT INTO `merchant_account` (name,bank,sub_bank,card_number,created_at,updated_at,status,site_id,type,limit_money_high,cash_deposit,contact_way,admin_id,alipay_number,alipay_name,alipay_image,wechat_number,wechat_name,wechat_image,limit_money_low,pay_method,price,amount,transaction_number) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18],[:19],[:20],[:21],[:22],[:23],[:24])';

    $config['501249'] = 'INSERT INTO `otc_inout` (`m_bank_id`,`user_bank_number`,`user_name`,`amount`,`type`,`created_at`,`updated_at`,`trans_remark`,`remark`,`status`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11])';

    $config['501250'] = 'INSERT INTO `user_recommends` (`created_at`,`updated_at`,`user_id`,`recommend_user_id`,`recommend_user_name`,`status`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';

    $config['501251'] = 'INSERT INTO `admin_white_ip` (`admin_id`,`ip`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4])';

    $config['501252'] = 'INSERT INTO `platform_inout_detail` (`created_at`,`time_area`,`asset`,`price`,`trade_fee`,`withdraw_fee`,`activity_in`,`activity_out`,`trade_amount`,`withdraw_amount`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';

    $config['501253'] = 'INSERT INTO `symbol_classes_exp` (`name`,`symbol_classes_id`,`statement`,`lang`) VALUES ([:1],[:2],[:3],[:4])';

    $config['501254'] = 'INSERT INTO `admin_send_email` (`content`,`created_at`) VALUES ([:1],[:2])';

    //新增变更资金操作记录
    $config['501255'] = 'INSERT INTO `operation_money_apply` (admin_id,created_time,asset_code,amount,user_id,`remark`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';

    $config['501256'] = 'INSERT INTO `advert_place` (`title`,`site_id`,`img`,`url`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';

    $config['501257'] = 'INSERT INTO `fingerpost` (`title`,`desc`,`site_id`,`img`,`vedio`,`order`,`created_at`,`updated_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';

    //删除指定站点币种
    $config['501401'] = 'DELETE FROM assets WHERE  1=1 AND `site_id`=[:1]';
    //删除指定站点交易对
    $config['501402'] = 'DELETE FROM symbols WHERE  1=1 AND `site_id`=[:1]';
    $config['501403'] = 'DELETE FROM user_securities WHERE `type`=[:2] AND `user_id`=[:1]';

    $config['501404'] = 'DELETE FROM b_help_class WHERE `id`=[:1]';

    $config['501405'] = 'DELETE FROM assets WHERE `site_id`=[:1] AND `asset_code`=[:2]';

    $config['501406'] = 'DELETE FROM symbols WHERE `site_id`=[:1] AND `symbol`=[:2]';

    $config['501407'] = 'DELETE FROM symbols WHERE `site_id`=[:1] AND `symbol`=[:2]';

    $config['501408'] = 'DELETE FROM symbol_classes_exp WHERE `symbol_classes_id`=[:1]';

    // $config['501407'] = 'DELETE FROM user_identities WHERE `type`=[:2] AND `user_id`=[:1]';

    //根据站点id查询所有交易对 2018-10-17
    $config['401120'] = 'SELECT id,symbol from total_symbols where deleted_at is null';
    $config['401121'] = 'SELECT  rm_parameter.rate,rm_parameter.symbol from  rm_parameter where `symbol`=[:1] and `status`= [:2]';
    //查询c2c订单记录 2018-10-18
    $config['401122'] = 'SELECT sum(total_amount) as total,user_id from  c2c_orders where asset = [:1] and user_id = [:2] group by user_id';
    //查询法币充值记录 2018-10-19
    $config['401123'] = 'SELECT user_id,asset,sum(amount) as total from  user_recharge_logs where asset = [:1] and user_id = [:2] group by user_id';
    //查询提现充值记录 2018-10-19
    $config['401124'] = 'SELECT user_id,asset,sum(amount) as total from  user_withdraws where asset = [:1] and user_id = [:2] group by user_id';
    //查询用户资产 2018-10-19
    //$config['401125'] = 'SELECT * from  assets where ';
    //检查该记录是否存在 2018-10-22
    $config['401126'] = 'SELECT symbol,site_id from  rm_parameter where site_id = [:1] and status = [:2] AND deleted_at is null';
    //检查账目该记录是否存在 2018-10-22
    $config['401127'] = 'SELECT * from  rm_parameter where site_id = [:1] and status = "5"';
    //查询站点名称 2018-10-29
    $config['401128'] = 'SELECT name from b_site where id = [:1]';
    //查询用户所在站点  2018-10-31
    $config['401130'] = 'SELECT site_id from users where id = [:1]';
    //查询币种 2018-10-31
    $config['401131'] = 'SELECT  asset_code from assets where  deleted_at is null group by asset_code';
    //查询盈亏费率 2018-11-01
    $config['401132'] = 'SELECT  rm_parameter.rate from  rm_parameter where `status`=[:1]';
    //检查账目该记录是否存在 2018-10-22
    $config['401133'] = 'SELECT * from  rm_parameter where site_id = [:1] and status = "6"';

    //查询用户账号  2018-11-07
    $config['401137'] = 'SELECT id from users where id = [:1]';
    //查询用户是否在白名单  2018-11-07
    $config['401135'] = 'SELECT phone from user_white_list where phone = [:1]';
    //查询用户是否在白名单  2018-11-07
    $config['401136'] = 'SELECT id,phone from user_white_list where phone = [:1]';

    //
    $config['401134'] = 'SELECT id,name_cn,name_en,code,area_code from countries where is_show = [:1] and deleted_at is [:2]';
    //查询用户账号  2018-11-08
    $config['401138'] = 'SELECT id from users where id = [:1]';
    $config['401139'] = 'SELECT phone,email from users where email = [:1]';
    //获取不平资产记录  2018-11-08
    $config['401140'] = 'SELECT user_id,asset,balance,created_at from user_asset_freezes where balance < 0 group by user_id,asset';
    //获取不平活动记录  2018-11-08
    $config['401141'] = 'SELECT user_id,asset,balance,created_at from user_asset_operatings where balance < 0 group by user_id,asset';
    //查询提现充值记录 2018-11-09
    $config['401142'] = 'SELECT user_id,asset,balance as total from  user_asset_operatings where asset = [:1] and user_id = [:2] group by user_id,asset';
    //获取不平活动记录  2018-11-20
    $config['401143'] = 'SELECT id,user_id from platform_account where user_id = [:1] and name = [:2] and site_id = [:3]';
    //获取不平活动记录  2018-11-20
    $config['401144'] = 'SELECT id from users where site_id = [:1] and status = [:2]';
    //获取不平活动记录  2018-11-22
    $config['401145'] = 'SELECT * from b_admin where user_id = [:1]';
    //获取不平活动记录  2018-11-23
    $config['401146'] = 'SELECT sum(amount) as loan_total from platfrom_loan_record where user_id = [:1] and asset = [:2] and site_id = [:3] and status = 0 and type = 1';
    //获取还款总额  2018-11-23
    $config['401147'] = 'SELECT sum(amount) as repayment_total from platfrom_loan_record where user_id = [:1] and asset = [:2] and site_id = [:3] and status = 1';
    //获取所有总账户  2018-11-23
    $config['401148'] = 'SELECT user_id from platform_account where status = [:1]';
    //获取总账户的user_id  2018-11-23
    $config['401149'] = 'SELECT user_id from platform_account where site_id = [:1] and status = 1';
    //获取总账户的user_id  2018-11-26
    $config['401150'] = 'SELECT * from user_withdraws where site_id = [:1] and status = 1';
    //获取总账户的user_id  2018-11-27
    $config['401151'] = 'SELECT * from platfrom_account_asset_record where site_id = [:1] and user_id = [:2] and asset = [:3]';
    //查询提币重复hash
    $config['401152'] = 'select * from user_withdraws  where tx_id in (select tx_id from user_withdraws group by tx_id  having count(tx_id) > 1) and tx_id != "" ORDER BY tx_id,id desc';
    $config['401155'] = 'select * from user_recharge_logs  where tx_hash in (select tx_hash from user_recharge_logs group by tx_hash  having count(tx_hash) > 1) and tx_hash != "" ORDER BY tx_hash,id desc';
    $config['401153'] = 'SELECT * from platform_account where id = [:1]';
    $config['401154'] = 'SELECT * from assets where site_id = [:1]';
    $config['401156'] = 'SELECT * from rm_withdraws_recharge_alarm where tx_hash = [:1] and amount = [:2] and user_id = [:3] and asset = [:4]';
    $config['401157'] = 'SELECT id,type,user_id from platform_account where site_id = [:1] and status = [:2]';
    $config['401158'] = 'SELECT user_id from platform_account where user_id = [:1]';
    $config['401159'] = 'SELECT user_id from platform_account where site_id = [:1]';
    $config['401160'] = 'SELECT sum(amount) as repayment_total from user_recharge_logs where user_id = [:1] and asset = [:2] and status = 1';
    $config['401161'] = 'SELECT address from user_recharge_addresses where user_id = [:1] and asset = [:2]';
    //$config['401162'] = 'select * from user_recharge_addresses  where address in (select address from user_recharge_addresses  group by address  having count(address) > 1) and user_id in (select max(id) from user_recharge_addresses group by user_id) and address != ""  ORDER BY id desc';
    $config['401162'] = 'select * from user_recharge_addresses where address in (select address from user_recharge_addresses group by address  having count(distinct user_id) > 1) group by user_id  order by address desc';

    $config['401163'] = 'SELECT * from rm_address_alarm where address = [:1] and user_id = [:2] and asset = [:3]';
    $config['401164'] = 'select * from `users` WHERE 1=1  AND `id`=[:1] AND `site_id`=[:2]';
    $config['401165'] = 'select * from `perday_holdcoin_statistics` WHERE 1=1  AND `user_id`=[:1] AND `asset`=[:2]';

    $config['401166'] = 'SELECT * from user_identities where `number` = [:1] and deleted_at is null';
    $config['401167'] = 'SELECT * from wallet_users where `user_id` = [:1]';
    $config['401168'] = 'SELECT * from wallet_snapshot where `asset` = [:1]';
    $config['401169'] = 'SELECT sum(register_amount) as count from perday_register_statistics where `time` >= [:1] and `time` < [:2] and `site_id` = [:3] ' ;
    $config['401170'] = 'SELECT sum(trunname_amount) as count from perday_register_statistics where `time` >= [:1] and `time` < [:2] and `site_id` = [:3]';
    $config['401182'] = 'SELECT sum(trunname_amount) as count from perday_register_statistics where `time` >= [:1] and `time` < [:2] ';
    $config['401171'] = 'select count(distinct `asset`,`created_at`,`wallet_id`,`balance`,`amount`,`collectAmount`,`collectCount`,`date`,`freeze`,`plaform`,`rechargeAmount`,`rechargeCount`,`withdrawAmount`,`withdrawAmount`,`platFeeAmount`,`platRechargeAmount`) FROM wallet_snapshot';
    $config['401172'] = 'SELECT sum(total_amount) as c2c_amount from c2c_orders where UNIX_TIMESTAMP(`created_at`) > [:1] and UNIX_TIMESTAMP(`created_at`) < [:2] and `type` = [:3] and `site_id` = [:4]';
    //2019-01-09 数据可视化
    $config['401173'] = 'SELECT sum(register_amount) as count from perday_register_statistics where `time` >= [:1] and `time` < [:2]' ;
    $config['401174'] = 'SELECT sum(total_amount) as c2c_amount from c2c_orders where UNIX_TIMESTAMP(`created_at`) > [:1] and UNIX_TIMESTAMP(`created_at`) < [:2] and `type` = [:3]';
    //数据可视化-数组总览总注册用户
    $config['401175'] = 'SELECT count(*) as count from users where `site_id` = [:1] ' ;
    $config['401176'] = 'SELECT count(*) as count from users ' ;
    $config['401177'] = 'SELECT count(*) as count from user_identities where  user_identities.status = 2';
    $config['401183'] = 'SELECT count(*) as count from user_identities LEFT JOIN users ON user_identities.user_id=users.id
where  user_identities.status = 2 and users.site_id = [:1]';
    //数据可视化-用户总览c2c数据
    $config['401178'] = 'SELECT sum(orders_total_number) as c2c_amount from perday_c2cbuy_statistics where `site_id` = [:1]';
    $config['601137'] = 'SELECT sum(orders_total_number) as c2c_amount from perday_c2csell_statistics where `site_id` = [:1]';;
    $config['401179'] = 'SELECT sum(orders_total_number) as c2c_amount from perday_c2cbuy_statistics';
    $config['601136'] = 'SELECT sum(orders_total_number) as c2c_amount from perday_c2csell_statistics';
    $config['401180'] = 'SELECT sum(orders_total_number) as c2c_amount from perday_c2cbuy_statistics where `time` >= [:1] and `time` < [:2]  and `site_id` = [:3]';
    $config['401181'] = 'SELECT sum(orders_total_number) as c2c_amount from perday_c2cbuy_statistics where `time` >= [:1] and `time` < [:2] ';
    $config['601134'] = 'SELECT sum(orders_total_number) as c2c_amount from perday_c2csell_statistics where `time` >= [:1] and `time` < [:2]  and `site_id` = [:3]';
    $config['601135'] = 'SELECT sum(orders_total_number) as c2c_amount from perday_c2csell_statistics where `time` >= [:1] and `time` < [:2] ';
    //数据可视化-交易统计-c2c交易数据 2019-01-15
    $config['401184'] = 'SELECT sum(orders_total_number) as user_count,sum(trading_amount) as amount_money,sum(orders_total) as trade_count from perday_c2cbuy_statistics where  `time` >= [:1] and `time` < [:2] and `site_id` = [:3]';
    $config['401185'] = 'SELECT sum(orders_total_number) as user_count,sum(trading_amount) as amount_money,sum(orders_total) as trade_count from perday_c2csell_statistics where  `time` >= [:1] and `time` < [:2] and `site_id` = [:3]';
    $config['401186'] = 'SELECT sum(orders_total_number) as user_count,sum(trading_amount) as amount_money,sum(orders_total) as trade_count from perday_c2cbuy_statistics where  `time` >= [:1] and `time` < [:2]';
    $config['401187'] = 'SELECT sum(orders_total_number) as user_count,sum(trading_amount) as amount_money,sum(orders_total) as trade_count from perday_c2csell_statistics where  `time` >= [:1] and `time` < [:2]';
    //数据可视化-币种详情-充提币 2019-01-16
    $config['401188'] = 'SELECT sum(amount) as recharge_sum from user_recharge_logs LEFT JOIN users ON user_recharge_logs.user_id=users.id  where  user_recharge_logs.created_at > [:1] and user_recharge_logs.created_at < [:2] and users.site_id = [:3] and `asset` = [:4]';
    $config['401189'] = 'SELECT sum(amount) as withdraw_sum from user_withdraws where  `created_at` > [:1] and `created_at` < [:2] and `site_id` = [:3] and `asset` = [:4]';
    $config['401190'] = 'SELECT sum(amount) as recharge_sum from user_recharge_logs LEFT JOIN users ON user_recharge_logs.user_id=users.id  where  user_recharge_logs.created_at > [:1] and user_recharge_logs.created_at < [:2] and users.site_id = [:3]';
    $config['401191'] = 'SELECT sum(amount) as recharge_sum from user_recharge_logs LEFT JOIN users ON user_recharge_logs.user_id=users.id  where  user_recharge_logs.created_at > [:1] and user_recharge_logs.created_at < [:2]  and `asset` = [:3]';
    $config['401192'] = 'SELECT sum(amount) as recharge_sum from user_recharge_logs LEFT JOIN users ON user_recharge_logs.user_id=users.id  where  user_recharge_logs.created_at > [:1] and user_recharge_logs.created_at < [:2] ';
    $config['401193'] = 'SELECT sum(amount) as withdraw_sum from user_withdraws where `created_at` > [:1] and `created_at` < [:2] and `site_id` = [:3]';
    $config['401194'] = 'SELECT sum(amount) as withdraw_sum from user_withdraws where  `created_at` > [:1] and `created_at` < [:2] and `asset` = [:3]';
    $config['401195'] = 'SELECT sum(amount) as withdraw_sum from user_withdraws where `created_at` > [:1] and `created_at` < [:2]';
    //数据可视化-交易对
    $config['401196'] = 'SELECT symbol,site_id from symbols where  base_asset = [:1] and site_id = [:2] and deleted_at is null';
    $config['401197'] = 'SELECT symbol,site_id from symbols where  base_asset = [:1] and deleted_at is null ';
    //获取运营统计数据的交易人数-按站点
    $config['401198'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where   `time` >= [:1] and `time` < [:2] and `site_id` = [:3]';
    $config['401199'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where `site_id` = [:1]';
    $config['401119'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where `time` >= [:1] and `time` < [:2]';
    $config['401118'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics';

    $config['401105'] = 'SELECT symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where  `time` >= [:1] and `time` < [:2] and `site_id` = [:3] and LEFT(symbols,length([:4])) = [:4]';
    $config['401104'] = 'SELECT symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where `site_id` = [:1] and LEFT(symbols,length([:2])) = [:2]';
    $config['401103'] = 'SELECT symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where  `time` >= [:1] and `time` < [:2] and `site_id` = [:3] and RIGHT(symbols,length([:4])) = [:4]';
    $config['401102'] = 'SELECT symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where `site_id` = [:1] and RIGHT(symbols,length([:2])) = [:2]';

    $config['401101'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where  `time` >= [:1] and `time` < [:2]  and LEFT(symbols,length([:3])) = [:3]';
    $config['401100'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where  LEFT(symbols,length([:1])) = [:1]';
    $config['601101'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where  `time` >= [:1] and `time` < [:2] and RIGHT(symbols,length([:3])) = [:3]';
    $config['601102'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where RIGHT(symbols,length([:1])) = [:1]';

    $config['601103'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where  `time` >= [:1] and `time` < [:2] and `site_id` = [:3] and `symbols` = [:4]';
    $config['601104'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where   `site_id` = [:1] and `symbols` = [:2]';
    $config['601105'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where  `time` >= [:1] and `time` < [:2]  and `symbols` = [:3]';
    $config['601106'] = 'SELECT  symbols,sum(people) as count,sum(trading_number) as trading_number,sum(trading_amount) as trading_amount,sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee from perday_coin_trade_statistics where  `symbols` = [:1]';


    //数据可视化-提币未审核
    $config['401117'] = 'SELECT count(id) as amount from user_withdraws where site_id = [:1] and status in (0,1)';
    $config['401116'] = 'SELECT count(id) as amount from user_withdraws where site_id = [:1]';
    $config['401115'] = 'SELECT count(id) as amount from user_withdraws where status in (0,1)';
    $config['401114'] = 'SELECT count(id) as amount from user_withdraws ';
    //数据可视化-认证未审核
    $config['401113'] = 'SELECT count(A.id) as amount from user_identities A  left join users B on (A.user_id = B.id) where B.site_id = [:1] and A.status = 1';
    $config['401112'] = 'SELECT count(A.id) as amount from user_identities A  left join users B on (A.user_id = B.id) where B.site_id = [:1]';
    $config['401111'] = 'SELECT count(id) as amount from user_identities where status = 1';
    $config['401110'] = 'SELECT count(id) as amount from user_identities ';
    //数据可视化-c2c未审核
    $config['401109'] = 'SELECT count(id) as amount from c2c_orders where site_id = [:1] and status in (1,2) and type = [:2]';
    $config['401108'] = 'SELECT count(id) as amount from c2c_orders where site_id = [:1] and type = [:2]';
    $config['401107'] = 'SELECT count(id) as amount from c2c_orders where type = [:1] and status in (1,2)';
    $config['401106'] = 'SELECT count(id) as amount from c2c_orders where type = [:1] ';

    //查询c2c订单详情 2019-02-27
    $config['601107'] = 'SELECT  otc_orders.* from  otc_orders where otc_orders.id=[:1]';

    $config['601108'] = 'SELECT * from `otc_inout` where `m_bank_id`=[:1] AND `type`=[:2] AND `status`=[:3] AND `user_name`=[:4]';
    //活动锁仓余额
    $config['601109'] = 'SELECT * from `user_asset_operatings` where `user_id`=[:1] AND `asset`=[:2] order by id desc';
    $config['601110'] = 'SELECT * from `user_asset_operatings` where `user_id`=[:1]';
    //获取已经完成数量 2019-03-02
    $config['601111'] = 'SELECT sum(amount) as sus_amount from `otc_orders` where `merchant_bank_id`=[:1] and `status` in (1,2,3,5,7,8)';
    $config['601112'] = 'SELECT sum(amount) as sus_amount from `otc_orders` where `merchant_bank_id`=[:1] and `status` in (1,2,3,5,7,8) ';
    //获取 2019-03-05
    $config['601113'] = 'SELECT * from `merchant_account` where `id`=[:1] ';
    $config['601114'] = 'SELECT * from `otc_orders` where `id`=[:1]';
    $config['601115'] = 'SELECT distinct(user_id),card_number,sub_bank,pre_phone,bank from `user_banks` where `user_id`=[:1]';
    $config['601116'] = 'SELECT account,name from `otc_user_account` where `user_id`=[:1] and `status`=[:2]';
    $config['601117'] = 'SELECT card_number,sub_bank,pre_phone,bank from `user_banks` where `user_id`=[:1]';
    $config['601118'] = 'SELECT value from `options` where `var_name`=[:1]';
    //获取sort_id 2019-03-13
    $config['601119'] = 'SELECT id from `merchant_account` where `sort_id`=[:1]';
    //获取sort_id最大值和最小值
    $config['601120'] = 'SELECT max(sort_id) as sort_id from `merchant_account` ';
    $config['601121'] = 'SELECT min(sort_id) as sort_id from `merchant_account` ';
    //获取商户完成交易笔数 2019-03-13
    $config['601122'] = 'SELECT count(id) as count from `otc_orders` where `status` = 7 and `merchant_bank_id` = [:1]';
    //查询后台验证码是否正确
    $config['601123'] = 'SELECT * from `user_valids` where `extra` = [:1] and `code` = [:2] and `use_type` = 15';
    //查询后台验证码是否正确
    $config['601124'] = 'SELECT * from `b_admin` where `user_name` = [:1] and `mobile` = [:2]';
    $config['601130'] = 'SELECT * from `b_admin` where `user_name` = [:1] and `email` = [:2]';
    //活动总数量
    $config['601125'] = 'SELECT sum(amount) as send_amount from `user_awards` where LEFT(activity_unique,length([:1])) = [:1] ';
    //后台用户目前存储的token和ip
    $config['601126'] = 'SELECT *  from `b_admin` where  `user_name` = [:1] ';
    $config['601127'] = 'SELECT *  from `b_admin` where  `id` = [:1] ';
    //查看后台管理员绑定邮箱账号是否重复
    $config['601128'] = "SELECT `user_id`,`user_name`,`site_id` FROM `b_admin` where 1=1 AND `email`=[:1]";
    $config['601129'] = "SELECT `user_id`,`user_name`,`site_id` FROM `b_admin` where 1=1 AND `mobile`=[:1]";
    //获取登录失败次数
    $config['601130'] = "SELECT * FROM `b_admin` where 1=1 AND `user_name`=[:1]";
    //获取站点所有币种
    $config['601131'] = "SELECT asset_code FROM `assets` where 1=1 AND `site_id`=[:1]";
    //获取实名 2019-03-26
    $config['601132'] = "SELECT name FROM `user_identities` where 1=1 AND `user_id`=[:1]";
    $config['601133'] = "SELECT user_name FROM `b_admin` where 1=1 AND `user_name`=[:1]";
    //风控-七日内提币按用户分类
    $config['601138'] = "SELECT sum(to_cny_amount) as amount,user_id,created_at,site_id FROM `user_withdraws` where 1=1 AND `created_at`>=[:1] and  `created_at`<[:2]  group by user_id";
    //风控-大额充值-获取参数临界值
    $config['601139'] = "SELECT * FROM `rm_new_par` where 1=1 AND status = [:1]";
    //风控-七日内提币按用户分类
    $config['601140'] = "SELECT sum(to_cny_amount) as amount,user_id,created_at FROM `user_recharge_logs` where 1=1 AND `created_at`>=[:1] and  `created_at`<[:2]  group by user_id";
    //风控-提币监控
    $config['601141'] = "SELECT user_id,created_at,site_id,user_withdraw_address_id,asset,real_amount,amount FROM `user_withdraws` where 1=1 AND `created_at` >=[:1] and  `created_at`<[:2] and `wallet_status`='INIT'";
    //获取币价
    $config['601142'] = "SELECT `price` FROM `symbols_price` where 1=1 AND `symbols`=[:1] AND  `created_at` > [:2] limit 1";
    //获取c2c记录 2019-05-06
    $config['601143'] = "SELECT sum(amount) as amount FROM `c2c_orders` where 1=1 AND `user_id`=[:1] AND  `type` = [:2] AND `status` = 3";
    //获取单个用户充值记录 2019-05-06
    $config['601144'] = "SELECT sum(amount) as amount,asset FROM `user_recharge_logs` where 1=1 AND `user_id`=[:1]  AND `status` = 1 group by asset";
    //获取活动资金记录 2019-05-06
    $config['601145'] = "SELECT sum(amount) as amount,asset  FROM `activity_changes` where `user_id`=[:1]  AND 1=1 AND `amount`>0 group by asset";
    //获取活动资金记录 2019-05-06
    $config['601146'] = "SELECT sum(amount) as amount,asset_code  FROM `operation_money_logs` where `user_id`=[:1]  AND 1=1 AND `amount`>0 group by asset_code";
    //otc转账记录 2019-05-06
    $config['601147'] = "SELECT sum(`change`) as amount,asset  FROM `otc_transfer_histories` where `user_id`=[:1]  AND `type`=[:2]  group by asset";
    //获取活动资金记录 2019-05-06
    $config['601148'] = "SELECT sum(amount) as amount,asset  FROM `activity_changes` where `user_id`=[:1]  AND 1=1 AND `amount`<0 group by asset";
    //获取后台调整资金记录 2019-05-06
    $config['601149'] = "SELECT sum(amount) as amount,asset_code  FROM `operation_money_logs` where `user_id`=[:1]  AND 1=1 AND `amount`<0 group by asset_code";
    //获取单个用户提币记录 2019-05-06
    $config['601150'] = "SELECT sum(amount) as amount,asset FROM `user_withdraws` where 1=1 AND `user_id`=[:1]  AND `status` = 3 group by asset";
/**
 * 全部
 */
    //获取单个用户提币记录-按币种 2019-05-06
    $config['601151'] = "SELECT sum(to_cny_amount) as to_cny_amount,sum(amount) as amount,asset FROM `user_withdraws` where 1=1 AND `user_id`=[:1]  AND `status` = 3 group by asset";
    //获取单个用户充值记录-按币种 2019-05-06
    $config['601152'] = "SELECT sum(to_cny_amount) as to_cny_amount,sum(amount) as amount,asset FROM `user_recharge_logs` where 1=1 AND `user_id`=[:1]  AND `status` = 1 group by asset";
    //获取活动资金记录 2019-05-06
    $config['601153'] = "SELECT sum(amount) as amount,asset  FROM `activity_changes` where `user_id`=[:1]  AND 1=1  group by asset";
    //获取后台调整资金记录 2019-05-06
    $config['601154'] = "SELECT sum(amount) as amount,asset_code as asset FROM `operation_money_logs` where `user_id`=[:1]  AND 1=1 group by asset_code";
    //otc转账记录 2019-05-06
    $config['601155'] = "SELECT sum(`change`) as amount,asset  FROM `otc_transfer_histories` where `user_id`=[:1]  AND `type`=[:2]  AND `status` = 1 group by asset";
    //获取c2c记录 2019-05-06
    $config['601156'] = "SELECT sum(amount) as amount FROM `c2c_orders` where 1=1 AND `user_id`=[:1] AND  `type` = [:2] AND `status` = 3";

    /**
     * 按币种
    */
    //获取单个用户提币记录-按币种 2019-05-06
    $config['601157'] = "SELECT sum(to_cny_amount) as to_cny_amount,sum(amount) as amount,asset FROM `user_withdraws` where 1=1 AND  `user_id`=[:1] AND  `asset`=[:2]  AND `status` = 3 group by asset";
    //获取单个用户充值记录-按币种 2019-05-06
    $config['601158'] = "SELECT sum(to_cny_amount) as to_cny_amount,sum(amount) as amount,asset FROM `user_recharge_logs` where 1=1 AND `user_id`=[:1] AND  `asset`=[:2] AND `status` = 1 group by asset";
    //获取活动资金记录 2019-05-06
    $config['601159'] = "SELECT sum(amount) as amount,asset  FROM `activity_changes` where `user_id`=[:1] AND  `asset`=[:2] AND 1=1  group by asset";
    //获取后台调整资金记录 2019-05-06
    $config['601160'] = "SELECT sum(amount) as amount,asset_code as asset FROM `operation_money_logs` where `user_id`=[:1] AND  `asset_code`=[:2]  AND 1=1 group by asset_code";
    //otc转账记录 2019-05-06
    $config['601161'] = "SELECT sum(`change`) as amount,asset  FROM `otc_transfer_histories` where `user_id`=[:1]  AND `type`=[:2] AND  `asset`=[:3] AND `status` = 1 group by asset";
    //获取c2c记录 2019-05-06
    $config['601162'] = "SELECT sum(amount) as amount FROM `c2c_orders` where 1=1 AND `user_id`=[:1] AND  `type` = [:2] AND `status` = 3";

    //获取c2c卖出记录 2019-05-14
    $config['601163'] = "SELECT* FROM `c2c_orders` where 1=1 AND `user_id`=[:1] AND  `type` = 2 AND `status`in (1,5)";

    //获取该币种所有交易对
    $config['601164'] = "SELECT `price`,`symbols` FROM `symbols_price` where 1=1 AND  LEFT(symbols,length([:1])) = [:1]  AND  `created_at` > [:2]";

    //查询提币警报数据是否已经存在
    $config['601165'] = "SELECT * FROM `rm_withdraws_wallet` where  `user_id` = [:1] and  `asset` = [:2] and  `address_id` = [:3] and  `amount` = [:4] and  `time` = [:5] and  `site_id` = [:6] ";

    //获取单个用户充值记录 2019-05-22
    $config['601166'] = "SELECT sum(amount) as amount,asset FROM `user_recharge_logs` where 1=1 AND `user_id`=[:1]  AND `status` = 1 AND `asset` = [:2]";
    //otc转账记录 2019-05-022
    $config['601167'] = "SELECT sum(`change`) as amount,asset  FROM `otc_transfer_histories` where `user_id`=[:1]  AND `type`=[:2] AND `asset` = [:3]";
    //获取单个用户提币记录 2019-05-06
    $config['601168'] = "SELECT sum(amount) as amount,asset FROM `user_withdraws` where 1=1 AND `user_id`=[:1]  AND `status` = 3 AND `asset` = [:2]";
//获取推送数据 2019-06-25
$config['601169'] = "SELECT * FROM `push_notification` where 1=1 AND `id`=[:1]";
//获取过期时间配置
$config['601170'] = "SELECT * FROM `options` where 1=1 AND `var_name`='update_password_time'";
//获取交易区数据 2019-07-31
$config['601171'] = "select sum(trading_amount) as trading_amount,time from `perday_coin_trade_statistics` where  time >= [:2] and time < [:3] and site_id = [:1]";
//获取真实交易金额 2019-07-31
$config['601172'] = "select sum(trading_amount) as trading_amount,time from `perday_coin_trade_statistics_all` where  time >= [:2] and time < [:3] and site_id = [:1]";
//获取交易区明细 2019-07-31
$config['601173'] = "select  *  from `perday_coin_trade_statistics` where RIGHT(symbols,length([:4])) = [:4] and time >= [:1] and time < [:2] and site_id = [:3]";
//获取交易区明细 2019-07-31
$config['601174'] = "select * from `perday_coin_trade_statistics_all` where RIGHT(symbols,length([:4])) = [:4] and time >= [:1] and time < [:2] and site_id = [:3]";

//获取交易对明细 2019-07-31
$config['601175'] = "select * from `perday_coin_trade_statistics` where RIGHT(symbols,length([:4])) = [:4] and time >= [:1] and time < [:2] and site_id = [:3]";
$config['601176'] = "select trading_number as real_trading_number,unit_price as real_unit_price,trading_amount as real_trading_amount from `perday_coin_trade_statistics_all` where RIGHT(symbols,length([:4])) = [:4] and time >= [:1] and time < [:2] and site_id = [:3]";
    
$config['601177'] = "SELECT a.*,b.name as site_name,c.role_id FROM `b_admin`as a LEFT JOIN `b_site` as b ON a.site_id = b.id LEFT JOIN `b_admin_roles` as c ON a.user_id=c.user_id WHERE 1=1 AND a.`sadmin`=[:3] AND a.`site_id`=[:4] LIMIT [:1],[:2]";

$config['601178'] = "SELECT count(*) FROM `b_admin` WHERE  1=1  AND `sadmin`=[:1] AND `site_id`=[:2]";

$config['601179'] = "SELECT * FROM `user_lock_positions` WHERE `id`=[:1]";

$config['601180'] = "SELECT * FROM `operation_money_apply` WHERE `id`=[:1]";




    //2018-10-18
    $config['402203'] = 'INSERT INTO `rm_transaction_alarm` (`start_time`,`end_time`,`market`,`total_trading_amount`,`user_trading_amount`,`user_trading_ratio`,`user_uid`,`created_at`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';



    //参数表（增加新纪录） 2018-10-22
    $config['402204'] = 'INSERT INTO `rm_parameter` (`symbol`,`rate`,`site_id`,`status`,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5])';
    //参数表（增加不平账目新纪录） 2018-10-22
    $config['402205'] = 'INSERT INTO `rm_parameter` (`rate`,`send_time`,`site_id`,`status`,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5])';
    //增加不平资产记录 2018-10-22
    $config['402206'] = 'INSERT INTO `rm_account_alarm` (`unfair_asset_type`,`unfair_asset_amount`,`user_id`,`created_at`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5])';
    //增加异常盈亏记录 2018-11-01
    $config['402207'] = 'INSERT INTO `rm_profit_loss_alarm` (`user_id`,`out`,`in`,`rate`,`start_asset`,`created_at`,`end_asset`,`asset`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
    //参数表（增加盈亏新纪录） 2018-11-01
    $config['402208'] = 'INSERT INTO `rm_parameter` (`rate`,`send_time`,`site_id`,`status`,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5])';
    //白名单增加 2018-11-07
    $config['402209'] = 'INSERT INTO `user_white_list` (`phone`,`site_id`,`created_at`) VALUES ([:1],[:2],[:3])';
    //用户账户增加 2018-11-20
    $config['402210'] = 'INSERT INTO `platform_account` (`name`,`site_id`,`remark`,`created_at`,`status`) VALUES ([:1],[:2],[:3],[:4],[:5])';
    //生成子站总账户 2018-11-20
    $config['402211'] = 'INSERT INTO `users` (`forbidden_login`,`forbidden_withdraw`,`forbidden_trade`,`site_id`,`created_at`,`status`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';
    //新增转账操作记录 2018-11-22
    $config['402212'] = 'INSERT INTO `platfrom_transfer_record` (operator,created_at,asset,amount,transfer_out_uid,`remark`,`site_id`,`transfer_in_uid`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
    //新增借款操作记录 2018-11-22
    $config['402213'] = 'INSERT INTO `platfrom_loan_record` (operator,created_at,asset,amount,user_id,`remark`,`site_id`,`status`,`payer_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';
    //新增赠币操作记录 2018-11-22
    $config['402214'] = 'INSERT INTO `platfrom_gift_coin_record` (`operator`,`created_at`,`asset`,`amount`,`user_id`,`remark`,`site_id`,`total_account_id`,`lock`,`expire_time`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10])';
    $config['402227'] = 'INSERT INTO `platfrom_gift_coin_record` (`operator`,`created_at`,`asset`,`amount`,`user_id`,`remark`,`site_id`,`total_account_id`,`lock`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';
    $config['402215'] = 'INSERT INTO `platfrom_account_asset_record` (`site_id`,`asset`,`balance`,`loan_total`,`repayment_total`,`wait_repayment`,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
    $config['402216'] = 'INSERT INTO `rm_withdraws_recharge_alarm` (`user_id`,`asset`,`tx_hash`,`amount`,`type`,`created_at`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
    $config['402217'] = 'INSERT INTO `rm_withdraws_recharge_alarm` (`user_id`,`asset`,`tx_hash`,`amount`,`type`,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';
    $config['402218'] = 'INSERT INTO `platform_account` (`name`,`site_id`,`user_id`,`remark`,`created_at`,`status`,`type`,`operator`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
    $config['402219'] = 'INSERT INTO `platfrom_account_asset_record` (`site_id`,`user_id`,`asset`,`balance`,`loan_total`,`repayment_total`,`wait_repayment`,`created_at`,`asset_balance`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9])';
    $config['402220'] = 'INSERT INTO `rm_address_alarm` (`user_id`,`address`,`asset`,`created_at`,`status`) VALUES ([:1],[:2],[:3],[:4],[:5])';
    $config['402221'] = 'INSERT INTO `perday_holdcoin_statistics` (`user_id`,`asset`,`amount`,`proportion`,`created_at`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';
    //以下三条插入用户钱包地址数据 2018-12-14user_recharge_addresses
    $config['402222'] = 'INSERT INTO `wallet_users` (`wallet_user_id`,`created_at`,`user_id`) VALUES ([:1],[:2],[:3])';
    $config['402223'] = 'INSERT INTO `wallet_user_assets` (`wallet_user_id`,`address`,`asset`,`created_at`,`balance`) VALUES ([:1],[:2],[:3],[:4],[:5])';
    $config['402224'] = 'INSERT INTO `user_recharge_addresses` (`created_at`,`user_id`,`asset`,`address`) VALUES ([:1],[:2],[:3],[:4])';
    $config['402225'] = 'INSERT INTO `wallet_snapshot` (`created_at`,`asset`,`wallet_id`,`balance`,`amount`,`collectAmount`,`collectCount`,`freeze`,`plaform`,`rechargeAmount`,`rechargeCount`,`withdrawAmount`,`withdrawCount`,`platFeeAmount`,`platRechargeAmount`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15])';
    //插入撤销订单记录
    $config['402226'] = 'INSERT INTO `cancel_market_record` (`uid`,`amount`,`market`,`ctime`,`mtime`,`source`,`price`,`type`,`deal_money`,`side`,`taker_fee`,`maker_fee`,`left`,`deal_stock`,`order_id`,`status`,`operator`,`created_at`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8],[:9],[:10],[:11],[:12],[:13],[:14],[:15],[:16],[:17],[:18])';
    //otc插入事件 2019-02-27
    $config['402229'] = 'INSERT INTO `event_logs` (created_at,updated_at,`name`,`ip`,`endpoint`,`params`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';
    $config['402228'] = 'INSERT INTO `user_asset_freezes` (created_at,updated_at,user_id,asset,`change`,business,balance,detail) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
    //新增活动解锁操作 2019-03-01
    $config['402230'] = 'INSERT INTO `activity_unlock` (`operator`,`created_at`,`asset`,`amount`,`user_id`,`remark`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
    //新增监控人员信息 2019-03-19
    $config['402231'] = 'INSERT INTO `rm_people_alarm` (`name`,`phone`,`email`,`created_at`,`site_id`,`target`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6])';
    //赠币记录 2019-03-27
    $config['402232'] = 'INSERT INTO `platfrom_gift_coin` (`uid`,`asset`,`amount`,`remark`,`lock`,`expire_time`,`site_id`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
    //新增手续费结转记录 2019-03-28
    $config['402233'] = 'INSERT INTO `platfrom_settlement_record` (operator,created_at,asset,amount,transfer_out_uid,`remark`,`site_id`,`transfer_in_uid`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
    //保全记录 2019-04-09

    $config['402234'] = 'INSERT INTO `baoquan_message` (`hash`,`baoquan_no`,`status`,`start_time`,`end_time`,`created_at`,`block_size`,`block_count`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';
    //新增手续费结转记录(日结) 2019-04-16
    $config['402235'] = 'INSERT INTO `platfrom_daysettlement_record` (operator,created_at,asset,amount,transfer_out_uid,`remark`,`site_id`,`transfer_in_uid`) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7],[:8])';

    //插入大额充值告警记录 2019-04-24
    $config['402236'] = 'INSERT INTO `rm_large_amount` (amount,user_id,created_at,site_id,type) VALUES ([:1],[:2],[:3],[:4],[:5])';
    //插入提币未返回记录 2019-04-24
    $config['402237'] = 'INSERT INTO `rm_withdraws_wallet` (created_at,user_id,asset,address_id,amount,time,site_id) VALUES ([:1],[:2],[:3],[:4],[:5],[:6],[:7])';
    //插入零点交易对成交价格 2019-04-29
    $config['402238'] = 'INSERT INTO `symbols_price` (created_at,symbols,price) VALUES ([:1],[:2],[:3])';



    //修改纪录 2018-10-22
    $config['403301'] = 'UPDATE `rm_parameter` SET `symbol`=[:1],`rate`=[:2],`status`=[:4],`updated_at`=[:5],`deleted_at`=[:6] where `symbol`=[:1] and `site_id`=[:3]';
    //修改不平账目纪录 2018-10-22
    $config['403302'] = 'UPDATE `rm_parameter` SET `rate`=[:1],`send_time`=[:2],`site_id`=[:3],`status`=[:4],`updated_at`=[:5] where `id`=[:6]';
    //修改不平账目纪录 2018-11-01
    $config['403303'] = 'UPDATE `rm_parameter` SET `rate`=[:1],`send_time`=[:2],`site_id`=[:3],`status`=[:4],`updated_at`=[:5] where `id`=[:6]';
    //修改白名单 2018-11-07
    $config['403304'] = 'UPDATE `user_white_list` SET `phone`=[:1],`site_id`=[:2],`updated_at`=[:3] where `id`=[:4]';
    //删除白名单 2018-11-07
    $config['403305'] = 'UPDATE `user_white_list` SET `phone`=[:1],`site_id`=[:2],`deleted_at`=[:3] where `id`=[:4]';
    //修改账户 2018-11-20
    $config['403306'] = 'UPDATE `platform_account` SET `name`=[:1],`site_id`=[:2],`user_id`=[:3],`remark`=[:4],`updated_at`=[:5],`status`=[:6],`type`=[:8],`operator`=[:9] where `id`=[:7]';
    //修改账户 2018-11-20
    $config['403307'] = 'UPDATE `platform_account` SET `id`=[:1],`deleted_at`=[:2] where `id`=[:1]';

    $config['403308'] = 'UPDATE `platfrom_account_asset_record` SET `balance`=[:4],`loan_total`=[:5],`repayment_total`=[:6], `wait_repayment`=[:7],`created_at`=[:8],`asset_balance`=[:9] where `site_id`=[:1] and `user_id`=[:2] and `asset`=[:3]';

    $config['403309'] = 'UPDATE `rm_withdraws_recharge_alarm` SET `status`=[:2],`operator` = [:3],`updated_at` = [:4] where `id`=[:1]';
    $config['403310'] = 'UPDATE `users` SET `forbidden_login`=[:1],`forbidden_withdraw`=[:2],`forbidden_trade`=[:3],`status`=[:5] where  `id`=[:4]';
    $config['403311'] = 'UPDATE `platform_account` SET `user_id`=[:1],`updated_at`=[:3],`operator`=[:5],`type`=[:6] where `id`=[:4] and `site_id`=[:2]';

    $config['403312'] = 'UPDATE `platfrom_account_asset_record` SET `user_id`=[:1],`updated_at`=[:2] where `site_id`=[:3] and `asset`=[:4]';
    $config['403313'] = 'UPDATE `users` SET `status`=[:2] where `id`=[:1]';
    $config['403314'] = 'UPDATE `rm_address_alarm` SET `status`=[:2],`operator` = [:3],`updated_at` = [:4] where `id`=[:1]';
    $config['403315'] = 'UPDATE `perday_holdcoin_statistics` SET `amount`=[:3],`proportion`=[:4],`created_at`=[:5],`site_id`=[:6] where `user_id`=[:1] and `asset`=[:2]';
    $config['403316'] = 'UPDATE `wallet_snapshot` SET `created_at`=[:1],`wallet_id`=[:3],`balance`=[:4],`amount`=[:5],`collectAmount`=[:6],`collectCount`=[:7],`freeze`=[:8],`plaform`=[:9],`rechargeAmount`=[:10],`rechargeCount`=[:11],`withdrawAmount`=[:12],`withdrawCount`=[:13],`platFeeAmount`=[:13],`platRechargeAmount`=[:13] where `asset`=[:2]';
    $config['403317'] = 'UPDATE `user_recharge_logs` SET `status`=[:2] where `id`=[:1]';
    $config['403318'] = 'UPDATE `b_site` SET `is_preaudit`=[:1]';
    $config['403319'] = 'UPDATE `user_withdraws` SET `status`=4 where `status` = 3 and id = [:1]'  ;
    //修改otc状态
    $config['403320'] = 'UPDATE `otc_inout` SET `status`=[:2] where `id`=[:1]';
    //更改otc订单的状态
    $config['403321'] = 'UPDATE `otc_orders` SET `status`=[:2],`process_time`=[:3] where `id`=[:1]';
    //更改otc冻结资金
    $config['403322'] = 'UPDATE `user_c2c_freezes` SET `balance`=`balance`-[:3] where `asset`=[:1] AND `user_id`=[:2]';
    //审核拒绝修改余额 2019-03-06
    $config['403323'] = 'UPDATE `merchant_account` SET `amount`= [:1] where `id`=[:2]';
    //修改商家列表排序状态 2019-03-13
    $config['403324'] = 'UPDATE `options` SET `value`=[:1]  where `var_name` = [:2]';
    //修改商家交易次数 2019-03-13
    $config['403325'] = 'UPDATE `merchant_account` SET `transaction_number`=[:1]  where `id` = [:2]';
    //修改商家排序id
    $config['403326'] = 'UPDATE `merchant_account` SET `sort_id`=[:1]  where `id` = [:2]';
    $config['403327'] = 'UPDATE `merchant_account` SET `sort_id`=[:1]  where `id` = [:2]';
    //更新登录时间 2019-03-19
    $config['403328'] = 'UPDATE `b_admin` SET `login_time`=[:2],`ip`=[:3],`token`=[:4] where 1=1 AND `user_id`=[:1]';
    //修改监听用户信息 2019-03-19
    $config['403329'] = 'UPDATE `rm_people_alarm` SET `name`=[:2],`phone`=[:3],`email`=[:4],`updated_at`=[:5],`site_id`=[:6],`target`=[:7] where `id`=[:1] ';
    $config['403330'] = 'UPDATE `rm_people_alarm` SET `deleted_at`=[:2] where `id`=[:1] ';
    //记录登录错误次数 2019-03-20
    $config['403331'] = 'UPDATE `b_admin` SET `frequency`= 1 + [:2] where `user_name`=[:1] ';
    $config['403332'] = 'UPDATE `b_admin` SET `frequency`= [:2] where `user_name`=[:1] ';
    //修改otc币种状态
    $config['403333'] = 'UPDATE `assets` SET `otc_true`= [:3] where `site_id`=[:1] and `asset_code`=[:2]';
    //删除多余记录
    $config['403334'] = 'UPDATE `rm_parameter` SET `deleted_at`= [:2] where `id` =[:1]';
    //修改赠币状态
    $config['403335'] = 'UPDATE `platfrom_gift_coin` SET `gift_result`= 1 where `asset` =[:1] and `amount` =[:2] and `uid` =[:3] and `remark` =[:4] and `lock` =[:5] ';