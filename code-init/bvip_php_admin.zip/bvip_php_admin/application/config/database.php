<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$active_group = 'default';
$query_builder = TRUE;
$db['zg_activity'] = array(
    'dsn'	=> '',

    'hostname' => '47.111.138.2:3306',
    'username' => 'exchange',
    'password' => 'exchange',
    'database' => 'activity',

    // 'hostname' => 'localhost',
    // 'username' => 'exchange',
    // 'password' => 'exchange',
    // 'database' => 'trade_log',

    'dbdriver' => 'mysqli',
    'dbprefix' => '',
    'pconnect' => FALSE,
    'db_debug' => (ENVIRONMENT !== 'production'),
    'cache_on' => FALSE,
    'cachedir' => '',
    'char_set' => 'utf8',
    'dbcollat' => 'utf8_general_ci',
    'swap_pre' => '',
    'encrypt' => FALSE,
    'compress' => FALSE,
    'stricton' => FALSE,
    'failover' => array(),
    'save_queries' => TRUE
);
$db['default'] = array(
	'dsn'	=> '',

	//'hostname' => 'localhost',
	//'username' => 'root',
	//'password' => 'root',
	//'database' => 'exchange',

	 'hostname' => '47.111.138.2',
	 'username' => 'exchange',
	 'password' => 'exchange',
	 'database' => 'exchange',

	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);



$db['trade_history'] = array(
	'dsn'	=> '',

	//'hostname' => 'localhost',
	//'username' => 'root',
	//'password' => 'root',
	//'database' => 'trade_history',
	
	 'hostname' => '47.111.138.2',
	 'username' => 'exchange',
	 'password' => 'exchange',
	 'database' => 'trade_history',

	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

$db['trade_log'] = array(
	'dsn'	=> '',
	
	//'hostname' => 'localhost',
	//'username' => 'root',
	//'password' => 'root',
	//'database' => 'trade_log',
	
	 'hostname' => '47.111.138.2',
	 'username' => 'exchange',
	 'password' => 'exchange',
	 'database' => 'trade_log',

	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

$db['trade_history_snap'] = array(
	'dsn'	=> '',
	//本地数据配置
	'hostname' => '47.111.138.2:3306',
	'username' => 'exchange',
	'password' => 'exchange',
	'database' => 'trade_history_snap',	
	
	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

$db['snapshot'] = array(
    'dsn'	=> '',

//	'hostname' => 'localhost',
//	'username' => 'root',
//	'password' => 'root',
//	'database' => 'trade_log',

    'hostname' => '47.111.138.2:3306',
    'username' => 'exchange',
    'password' => 'exchange',
    'database' => 'snapshot',

    'dbdriver' => 'mysqli',
    'dbprefix' => '',
    'pconnect' => FALSE,
    'db_debug' => (ENVIRONMENT !== 'production'),
    'cache_on' => FALSE,
    'cachedir' => '',
    'char_set' => 'utf8',
    'dbcollat' => 'utf8_general_ci',
    'swap_pre' => '',
    'encrypt' => FALSE,
    'compress' => FALSE,
    'stricton' => FALSE,
    'failover' => array(),
    'save_queries' => TRUE
);

$db['otc_trade'] = array(
    'dsn'       => '',

//      'hostname' => 'localhost',
//      'username' => 'root',
//      'password' => 'root',
//      'database' => 'trade_log',

    'hostname' => '47.111.138.2:3306',
    'username' => 'exchange',
    'password' => 'exchange',
    'database' => 'otc_trade',

    'dbdriver' => 'mysqli',
    'dbprefix' => '',
    'pconnect' => FALSE,
    'db_debug' => (ENVIRONMENT !== 'production'),
    'cache_on' => FALSE,
    'cachedir' => '',
    'char_set' => 'utf8',
    'dbcollat' => 'utf8_general_ci',
    'swap_pre' => '',
    'encrypt' => FALSE,
    'compress' => FALSE,
    'stricton' => FALSE,
    'failover' => array(),
    'save_queries' => TRUE
);
