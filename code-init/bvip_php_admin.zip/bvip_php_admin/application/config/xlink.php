<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * xlink
 */

$config['enable']=false;
//
$config['server']='121.196.225.199';
//
$config['port']='8188';

/* End of file yeepay.php */
/* Location: ./application/config/yeepay.php */