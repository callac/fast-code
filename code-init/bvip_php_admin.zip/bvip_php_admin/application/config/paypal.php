<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['Sandbox'] = TRUE;   //为true说明为正式环境配置false为沙盒环境

$config['ClientId']  = $config['Sandbox'] ? '' :'ARcpEZ00gOJ2i-rcgtOPmqdr5a7WlnU8LL-srx2Mp7MMvwbjfS3AZ_A9tQNW6MAg5I04uCX5M1Qsst_D';
$config['PaySecret'] = $config['Sandbox'] ? '' :'EAms6NNndnl1zQVVE6Q93E_hv_lx1hCvWmIKUDofkURGzoPsszS74RNK7QAVYmEj-PWFaHMbv6ue9brB';
$config['PayType'] = 'USD' ;
$config['ReturnUrl'] = '';


