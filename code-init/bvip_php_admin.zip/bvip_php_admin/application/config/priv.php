<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//权限优化
//注意：lang()语言函数字符串不能有空格，否则识别不到，编码需规范
//当前码标 20000
//权限码区分 50000-59999 created by jzuo 2019-06-28 当前编码序：50001
$admin_menu_file = array(
    //用户管理
    'user-userList'=>array(
        //用户列表接口
        array('id' => '30001' ,'name' => lang('jys_user_list') ,'mod_do_url' => '/zjys_user/get_list','permission' => 1),
        //解冻ip
        array('id' => '30026' ,'name' => lang('jys_unfreezeip') ,'mod_do_url' => '/zjys_trade/unfreezeip','permission' => 1),
        //添加vip账户
//        array('id' => '30056' ,'name' => lang('jys_vip_adduser') ,'mod_do_url' => '/zjys_user/vip_adduser','permission' => 0),
        //禁止/解禁登陆
        array('id' => '30057' ,'name' => lang('jys_user_forbidden_login') ,'mod_do_url' => '/zjys_user/forbid_login','permission' => 1),
        //禁止/解禁提现
        array('id' => '30058' ,'name' => lang('jys_user_forbidden_withdraw') ,'mod_do_url' => '/zjys_user/forbid_withdraw','permission' => 1),
        //禁止/解禁交易
        array('id' => '30059' ,'name' => lang('jys_user_forbidden_trade') ,'mod_do_url' => '/zjys_user/forbid_trade','permission' => 1),
        //用户详情
        array('id' => '30061' ,'name' => lang('jys_user_get_info') ,'mod_do_url' => '/zjys_user/get_info','permission' => 1),
        //用户详情->用户提币地址
        array('id' => '30062' ,'name' => lang('jys_withdraw_address_user_list') ,'mod_do_url' => '/zjys_user/user_withdraw_address_list','permission' => 1),
        //用户详情->用户提币记录
        // array('id' => '30063' ,'name' => lang('jys_withdraw_address_user_logs') ,'mod_do_url' => '/zjys_user/user_withdraw_address_logs','permission' => 1),
        //用户详情->用户充币地址
        // array('id' => '30064' ,'name' => lang('jys_recharge_address_user_list') ,'mod_do_url' => '/zjys_user/user_recharge_address_list','permission' => 1),
        //用户充值记录
        array('id' => '30065' ,'name' => lang('jys_recharge_address_user_logs') ,'mod_do_url' => '/zjys_user/user_recharge_address_logs','permission' => 1),
        //单个用户银行卡列表
        array('id' => '30066' ,'name' => lang('jys_get_userbank') ,'mod_do_url' => '/zjys_user/get_bank_list','permission' => 1),

        array('id' => '20065' ,'name' => lang('batch_user_file') ,'mod_do_url' => '/zjys_user/batch_user_file','permission' => 1),

        array('id' => '40006' ,'name' => lang('jys_reset_password') ,'mod_do_url' => '/zjys_user/reset_password','permission' => 1),
        //用户的前端登录日志
        array('id' => '33000' ,'name' => lang('jys_websafe_login_logs') ,'mod_do_url' => '/zjys_user/websafe_login_logs','permission' => 1),
        //用户的前端安全设置日志
        array('id' => '33001' ,'name' => lang('jys_websafe_operation_logs') ,'mod_do_url' => '/zjys_user/websafe_operation_logs','permission' => 1),

        


    ),
    'user-userIdentity'=>array(
        //重置认证
        array('id' => '32002' ,'name' => lang('jys_useridentity_reset') ,'mod_do_url' => '/zjys_user/resetidentity','permission' => 1),
        //认证信息列表
        array('id' => '30046' ,'name' => lang('jys_user_identity') ,'mod_do_url' => '/zjys_user/user_identity_list','permission' => 1),

        array('id' => '40003' ,'name' => lang('jys_user_country') ,'mod_do_url' => '/zjys_user/country_list','permission' => 0),

        array('id' => '40000' ,'name' => lang('jys_user_identity_check') ,'mod_do_url' => '/zjys_user/user_identity_check','permission' => 1),

        array('id' => '40038' ,'name' => lang('jys_correct_identity_info') ,'mod_do_url' => '/zjys_user/correct_identity_info','permission' => 1),
    ),
    'user-coinAddress'=>array(
        array('id' => '30007' ,'name' => lang('jys_withdraw_address_list') ,'mod_do_url' => '/zjys_withdraw/withdraw_address_list','permission' => 1),
    ),
    'user-rechargeAddress'=>array(
        //充值地址列表
        array('id' => '30048' ,'name' => lang('jys_recharge_address_list') ,'mod_do_url' => '/zjys_recharge/recharge_address_list','permission' => 1),
    ),
    'user-userSafeinfo'=>array(
        //安全信息
        array('id' => '30051' ,'name' => lang('jys_user_safeinfo') ,'mod_do_url' => '/zjys_user/user_safeinfo_list','permission' => 1),
        //修改手机号邮箱
        array('id' => '31001' ,'name' => lang('jys_user_editphoneemail') ,'mod_do_url' => '/zjys_user/edit_phoneoremail','permission' => 1),
        //重置谷歌验证器（two_step_bound）
        array('id' => '30052' ,'name' => lang('jys_user_reset_two_step') ,'mod_do_url' => '/zjys_user/reset_google_verify','permission' => 1),
    ),

    'user-recomend'=>array(
        //用户推荐列表
        array('id' => '40004' ,'name' => lang('jys_user_recommendlist') ,'mod_do_url' => '/zjys_user/user_recomend_list','permission' => 1),
        //用户推荐列表导出
        array('id' => '40005' ,'name' => lang('jys_user_recommendlist_csv') ,'mod_do_url' => '/zjys_user/user_recomend_list_csv','permission' => 1),

        array('id' => '40040' ,'name' => lang('jys_get_user_recommend_statistic') ,'mod_do_url' => '/zjys_statistics/get_user_recommend_statistic','permission' => 1),
        
        array('id' => '40110' ,'name' => lang('jys_add_recommend') ,'mod_do_url' => '/zjys_user/add_recommend','permission' => 1),
    ),

    //资产管理
    'property-propertyList'=>array(
        //获取总站所有币种
        array('id' => '30037' ,'name' => lang('jys_asset_list_totalsite') ,'mod_do_url' => '/zjys_assets/asset_list_totalsite','permission' => 0),
        //获取总站交易对
        array('id' => '30038' ,'name' => lang('jys_symbol_list_totalsite') ,'mod_do_url' => '/zjys_symbols/symbol_list_totalsite','permission' => 0),
        //后台调整资金
        // array('id' => '30010' ,'name' => lang('jys_edit_updateusermoney') ,'mod_do_url' => '/zjys_trade/updateusermoney','permission' => 1),
        //后台解冻资金
        // array('id' => '30083' ,'name' => lang('jys_admin_unfreeze_asset') ,'mod_do_url' => '/zjys_c2corder/admin_unfreeze_asset','permission' => 1),
        //ajax实时查询网站相关信息
        array('id' => '30045' ,'name' => lang('jys_list_ajaxsearch') ,'mod_do_url' => '/site/ajaxsearch','permission' => 0),
        //用户总资产（换算成人名币）
        array('id' => '30013' ,'name' => lang('jys_user_totalassets') ,'mod_do_url' => '/zjys_trade/user_totalassets','permission' => 1),
        //用户资产详情
        array('id' => '30014' ,'name' => lang('jys_user_assetsdetail') ,'mod_do_url' => '/zjys_trade/user_assetsdetail','permission' => 1),
        //用户资产流水
        array('id' => '30015' ,'name' => lang('jys_user_assetsflow') ,'mod_do_url' => '/zjys_trade/user_assetsflow','permission' => 1),
        //用户资产流水导出
        array('id' => '32000' ,'name' => lang('jys_user_assetsflow_csv') ,'mod_do_url' => '/zjys_trade/user_assetsflow_csv','permission' => 1),

        array('id' => '30025' ,'name' => lang('jys_user_assetsflow_csv') ,'mod_do_url' => '/zjys_trade/flow_business_type','permission' => 0),
        //用户成交记录
        array('id' => '30016' ,'name' => lang('jys_user_dealrecords') ,'mod_do_url' => '/zjys_trade/user_dealrecords','permission' => 1),
        //用户委托记录
        array('id' => '30017' ,'name' => lang('jys_user_entrustedrecords') ,'mod_do_url' => '/zjys_trade/user_entrustedrecords','permission' => 1),
        //导出用户资产
        array('id' => '40001' ,'name' => lang('zjys_print_user_assets') ,'mod_do_url' => '/zjys_trade/print_user_assets','permission' => 1),
        // //增加锁仓
        // array('id' => '30099' ,'name' => lang('jys_lockposition_add') ,'mod_do_url' => '/zjys_user/lockposition_add','permission' => 1),
        // //手动解仓
        // array('id' => '30101' ,'name' => lang('jys_unlockposition') ,'mod_do_url' => '/zjys_user/unlockposition','permission' => 1),
        //撤销单个用户订单
        array('id' => '20074' ,'name' => lang('cancel_order_user_market') ,'mod_do_url' => '/zjys_trade/cancel_order_user_market','permission' => 1),
        //撤销订单单个用户记录
        array('id' => '20077' ,'name' => lang('cancel_order_record_list1') ,'mod_do_url' => '/zjys_trade/cancel_order_record_list1','permission' => 1),


        //用户总资产（换算成人名币）-全部
        array('id' => '20096' ,'name' => lang('jys_user_totalassets_all') ,'mod_do_url' => '/zjys_trade/user_totalassets_all','permission' => 1),
        //用户资产详情 -全部
        array('id' => '20097' ,'name' => lang('jys_user_assetsdetail_all') ,'mod_do_url' => '/zjys_trade/user_assetsdetail_all','permission' => 1),
        //导出用户资产 -全部
        array('id' => '20098' ,'name' => lang('zjys_print_user_assets_all') ,'mod_do_url' => '/zjys_trade/print_user_assets_all','permission' => 1),
        //重新发送提币请求
        // array('id' => '20300' ,'name' => lang('zjys_resend_withdraw') ,'mod_do_url' => '/zjys_assets/resend_withdraw','permission' => 1),
    ),
    //撤销订单
//    'cancel-orderList'=>array(
//
//    ),
    'property-rechargeList'=>array(
        //充值记录列表
        array('id' => '30002' ,'name' => lang('jys_recharge_log_list') ,'mod_do_url' => '/zjys_recharge/recharge_list','permission' => 1),
        //导出充值记录
        array('id' => '30080' ,'name' => lang('jys_recharge_printexcel') ,'mod_do_url' => '/zjys_recharge/recharge_list_printexcel','permission' => 1),
        array('id' => '20069' ,'name' => lang('recharge_review') ,'mod_do_url' => '/zjys_recharge/recharge_review','permission' => 1),
    ),
    'property-presentList'=>array(
        //提现记录
        array('id' => '30003' ,'name' => lang('jys_withdraw_list') ,'mod_do_url' => '/zjys_withdraw/withdraw_list','permission' => 1),
        //提币审核(审核中->处理中)
        array('id' => '30005' ,'name' => lang('jys_withdraw_verify') ,'mod_do_url' => '/zjys_withdraw/withdraw_verify','permission' => 1),
        //提币再次审核（处理中->完成）
        array('id' => '30006' ,'name' => lang('jys_withdraw_sure_verify') ,'mod_do_url' => '/zjys_withdraw/withdraw_sure_verify','permission' => 1),
        //将提现审核成功的手动设置成失败
        array('id' => '20101' ,'name' => lang('jys_withdraw_failure') ,'mod_do_url' => '/zjys_withdraw/withdraw_failure','permission' => 1),
        //查看详情
        array('id' => '30067' ,'name' => lang('jys_check_detail') ,'mod_do_url' => '/zjys_user/check_detail','permission' => 0),
        //导出excle/csv
        array('id' => '30079' ,'name' => lang('jys_withdraw_printexcel') ,'mod_do_url' => '/zjys_withdraw/withdraw_list_printexcel','permission' => 1),
        //重新发送提币请求
        array('id' => '20300' ,'name' => lang('zjys_resend_withdraw') ,'mod_do_url' => '/zjys_assets/resend_withdraw','permission' => 1),
        // ajax接口 获取提币 未审核或者初次审核的订单数量
        array('id' => '200003' ,'name' => lang('zjys_withdraw_waitcheck_amount') ,'mod_do_url' => '/zjys_withdraw/waitcheckamount','permission' => 0),
    ),
    'property-propertyType'=>array(
        //增加资产种类
        array('id' => '30009' ,'name' => lang('jys_add_asset') ,'mod_do_url' => '/zjys_assets/add_asset','permission' => 1),
        //币资产管理-》币资产列表
        array('id' => '30008' ,'name' => lang('jys_asset_list') ,'mod_do_url' => '/zjys_assets/asset_list','permission' => 1),
        array('id' => '300602' ,'name' => lang('jys_asset_list') ,'mod_do_url' => '/zjys_assets/asset_list_noauth','permission' => 0),
        //站群 系统资产配置
        array('id' => '30120' ,'name' => lang('jys_sys_asset_list') ,'mod_do_url' => '/zjys_assets/system_asset_list','permission' => 0),
        array('id' => '30121' ,'name' => lang('jys_sys_asset_add') ,'mod_do_url' => '/zjys_assets/system_asset_add','permission' => 0),
        array('id' => '30122' ,'name' => lang('jys_sys_asset_delete') ,'mod_do_url' => '/zjys_assets/system_asset_delete','permission' => 0),
        array('id' => '20174' ,'name' => lang('systemAssetAddVerity') ,'mod_do_url' => '/zjys_assets/systemAssetAddVerity','permission' => 0),
        array('id' => '20177' ,'name' => lang('systemAssetDetailsLogs') ,'mod_do_url' => '/zjys_assets/systemAssetDetailsLogs','permission' => 0),

    ),
    'property-transactionPair'=>array(
        //增加交易对
        array('id' => '30012' ,'name' => lang('jys_add_symbol') ,'mod_do_url' => '/zjys_symbols/add_symbol','permission' => 1),
        //币资产管理-》交易对列表
        array('id' => '30011' ,'name' => lang('jys_symbol_list') ,'mod_do_url' => '/zjys_symbols/symbol_list','permission' => 1),
        array('id' => '300601' ,'name' => lang('jys_symbol_list') ,'mod_do_url' => '/zjys_symbols/symbol_list_noauth','permission' => 0),
        //站群 系统交易对配置
        array('id' => '30123' ,'name' => lang('jys_sys_symbol_list') ,'mod_do_url' => '/zjys_symbols/system_symbol_list','permission' => 0),
        array('id' => '30124' ,'name' => lang('jys_sys_symbol_add') ,'mod_do_url' => '/zjys_symbols/system_symbol_add','permission' => 0),
        array('id' => '30125' ,'name' => lang('jys_sys_symbol_delete') ,'mod_do_url' => '/zjys_symbols/system_symbol_delete','permission' => 0),
        array('id' => '20280' ,'name' => lang('systemSymbolAddVerity') ,'mod_do_url' => '/zjys_symbols/systemSymbolAddVerity','permission' => 0),
        array('id' => '20178' ,'name' => lang('systemSymbolDetailsLogs') ,'mod_do_url' => '/zjys_symbols/systemSymbolDetailsLogs','permission' => 0),


    ),
    'property-changeCapital'=>array(
        //资金调整记录列表
        array('id' => '30054' ,'name' => lang('jys_user_correctassetitem') ,'mod_do_url' => '/zjys_trade/user_correctassetitem','permission' => 1),
        //批量调整资金
        // array('id' => '31049' ,'name' => lang('jys_csv_insert_updatemoney') ,'mod_do_url' => '/zjys_trade/batch_update_money','permission' => 1),

        array('id' => '40002' ,'name' => lang('jys_user_correctassetitem_csv') ,'mod_do_url' => '/zjys_trade/user_correctassetitem_csv','permission' => 1),
    ),
    // 'property-lockPositionList'=>array(
    //     //锁仓记录
    //     array('id' => '30098' ,'name' => lang('jys_lockposition_list') ,'mod_do_url' => '/zjys_user/lockposition_list','permission' => 1),
    //     //锁仓记录删除（暂未使用）
    //     array('id' => '30100' ,'name' => lang('jys_lockposition_delete') ,'mod_do_url' => '/zjys_user/lockposition_delete','permission' => 0),
    //     //锁仓审核
    //     array('id' => '30222' ,'name' => lang('jys_lockposition_check') ,'mod_do_url' => '/lock_position/lockposition_check_first','permission' => 1),
    //     //解仓审核
    //     array('id' => '30223' ,'name' => lang('jys_unlockposition_check') ,'mod_do_url' => '/lock_position/lockposition_check_second','permission' => 1),
    // ),

    //进出流水查询
    'property-inOutList'=>array(
        //进出流水查询
        array('id' => '20152' ,'name' => lang('InOutMoneyQuery') ,'mod_do_url' => '/InOut_money/InOutMoneyQuery','permission' => 1),
        //进出流水查询
        array('id' => '20155' ,'name' => lang('asset_price') ,'mod_do_url' => '/InOut_money/asset_price','permission' => 0),
    ),
    //OTC转账记录
    'property-otcTransferList'=>array(
        //进出流水查询
        array('id' => '20160' ,'name' => lang('otc_transfer_list') ,'mod_do_url' => '/InOut_money/otc_transfer_list','permission' => 1),
        //进出流水查询
        array('id' => '20161' ,'name' => lang('otc_transfer_list_csv') ,'mod_do_url' => '/InOut_money/otc_transfer_list_csv','permission' => 1),
    ),

    //手动入账
    'property-handRecharge'=>array(
        //手动入账列表
        array('id' => '50012' ,'name' => lang('handrecharge_list') ,'mod_do_url' => '/Hand_recharge/handrecharge_list','permission' => 1),
        //手动入账新增
        array('id' => '50013' ,'name' => lang('handrecharge_add') ,'mod_do_url' => '/Hand_recharge/add','permission' => 1),
        //
        array('id' => '50010' ,'name' => lang('handrecharge_verify_first') ,'mod_do_url' => '/Hand_recharge/handrecharge_verify_first','permission' => 1),
        //
        array('id' => '50011' ,'name' => lang('handrecharge_verify') ,'mod_do_url' => '/Hand_recharge/handrecharge_verify','permission' => 1),

        array('id' => '50014' ,'name' => lang('handrecharge_detail') ,'mod_do_url' => '/Hand_recharge/detail','permission' => 1),
    ),




    //C2C交易
    'c2c-c2cInOut'=>array(
        //后台法币买入卖出列表
        array('id' => '30020' ,'name' => lang('jys_c2c_inout') ,'mod_do_url' => '/zjys_c2corder/inout','permission' => 1),
        //后台法币买入卖出审核
        array('id' => '30021' ,'name' => lang('jys_c2c_verify') ,'mod_do_url' => '/zjys_c2corder/c2c_verify','permission' => 1),
        //买入卖出初次审核
        array('id' => '30089' ,'name' => lang('jys_c2c_verify_first') ,'mod_do_url' => '/zjys_c2corder/c2c_verify_first','permission' => 1),
        //审核详情
        array('id' => '30067' ,'name' => lang('jys_check_detail') ,'mod_do_url' => '/zjys_user/check_detail','permission' => 0),
        //法币买入卖出导出
        array('id' => '30078' ,'name' => lang('jys_c2c_printexcel') ,'mod_do_url' => '/zjys_c2corder/inout_printexcel','permission' => 1),
    
    ),
    'c2c-bankCardList'=>array(
        //银行卡列表
        array('id' => '30018' ,'name' => lang('jys_merchantbank_list') ,'mod_do_url' => '/zjys_merchantbank/merchantbank_list','permission' => 1),
        //银行卡新增与编辑
        array('id' => '30019' ,'name' => lang('jys_merchantbank_add') ,'mod_do_url' => '/zjys_merchantbank/addbank','permission' => 1),
        //后台用户银行卡列表
        array('id' => '30022' ,'name' => lang('jys_userbank_list') ,'mod_do_url' => '/zjys_userbank/userbank_list','permission' => 0),
        //查看明细
        array('id' => '30085' ,'name' => lang('jys_add_admin_merbank_inout_list') ,'mod_do_url' => '/zjys_merchantbank/add_merbank_inout_list','permission' => 1),
        //增加明细
        array('id' => '30084' ,'name' => lang('jys_add_admin_merbank_inout_flows') ,'mod_do_url' => '/zjys_merchantbank/add_merbank_inout_flows','permission' => 1),
        //银行卡禁用
        array('id' => '30024' ,'name' => lang('jys_merchantbank') ,'mod_do_url' => '/zjys_merchantbank/deletebank','permission' => 1),
        //查看明细列表导出
        array('id' => '30087' ,'name' => lang('jys_merchant_inout_list_printexcel') ,'mod_do_url' => '/zjys_merchantbank/add_merbank_inout_list_printexcel','permission' => 1),
    ),

    //财务统计
    'statistics-coinStatistics'=>array(
        array('id' => '30072' ,'name' => lang('jys_total_c2c') ,'mod_do_url' => '/zjys_trade/get_type_one','permission' => 0),
        //站点币种资产相关统计
        array('id' => '30060' ,'name' => lang('jys_timetask_totalsiteassets') ,'mod_do_url' => '/zjys_trade/get_site_totalassets','permission' => 0),
        //获取平台币种的交易冻结
        array('id' => '30073' ,'name' => lang('jys_get_trade_freeze') ,'mod_do_url' => '/zjys_trade/get_trade_freeze','permission' => 0),
        //获取c2c冻结
        array('id' => '30074' ,'name' => lang('jys_get_c2cwithdraw_freeze') ,'mod_do_url' => '/zjys_trade/get_c2c_freeze','permission' => 0),
    ),
    'statistics-usersStatistics'=>array(
        array('id' => '30086' ,'name' => lang('jys_user_statistics') ,'mod_do_url' => '/zjys_user/statistics_users','permission' => 1),
        array('id' => '30088' ,'name' => lang('jys_statistics_users_printexcel') ,'mod_do_url' => '/zjys_user/statistics_users_printexcel','permission' => 1),
    ),
    'statistics-inOut'=>array(
        array('id' => '30090' ,'name' => lang('jys_statistics_c2c_inout') ,'mod_do_url' => '/zjys_merchantbank/statistics_c2c_inout','permission' => 1),
        array('id' => '30091' ,'name' => lang('jys_statistics_c2c_inout_printexcel') ,'mod_do_url' => '/zjys_merchantbank/statistics_c2c_inout_printexcel','permission' => 1),
    ),
    // 'statistics-orderStatistics'=>array(
    //     array('id' => '30092' ,'name' => lang('jys_get_trade_statistic') ,'mod_do_url' => '/zjys_trade/get_trade_statistic','permission' => 1),
    //     array('id' => '30093' ,'name' => lang('jys_get_trade_statistic_print') ,'mod_do_url' => '/zjys_trade/get_trade_statistic_printexcel','permission' => 1),
    // ),

    // 'statistics-platformAsset'=>array(
        // array('id' => '40026' ,'name' => lang('jys_platformAsset') ,'mod_do_url' => '/checkaccount/platform_asset_list','permission' => 1),
        // array('id' => '40027' ,'name' => lang('jys_platformAsset_csv') ,'mod_do_url' => '/checkaccount/platform_asset_list_csv','permission' => 1),
        
        
    // ), 

    'statistics-checkAccount'=>array(
        array('id' => '40029' ,'name' => lang('jys_checkaccount') ,'mod_do_url' => '/checkaccount/Checkaccount_list','permission' => 1),
        array('id' => '40030' ,'name' => lang('jys_checkaccount_csv') ,'mod_do_url' => '/checkaccount/Checkaccount_list_csv','permission' => 1),

    ),

    'statistics-walletSnapshot'=>array(
        array('id' => '20066' ,'name' => lang('wallet_snapshot_list') ,'mod_do_url' => '/checkaccount/wallet_snapshot_list','permission' => 1),
        array('id' => '20068' ,'name' => lang('wallet_snapshot_list_csv') ,'mod_do_url' => '/checkaccount/wallet_snapshot_list_csv','permission' => 1),
    ),

    'statistics-systemCheckAccount'=>array(
        array('id' => '40041' ,'name' => lang('jys_system_checkaccount') ,'mod_do_url' => '/checkaccount/system_checkamount','permission' => 1),
        array('id' => '40042' ,'name' => lang('jys_system_checkaccount_csv') ,'mod_do_url' => '/checkaccount/system_checkamount_csv','permission' => 1),
        array('id' => '40026' ,'name' => lang('jys_platformAsset') ,'mod_do_url' => '/checkaccount/platform_asset_list','permission' => 1),
        array('id' => '40027' ,'name' => lang('jys_platformAsset_csv') ,'mod_do_url' => '/checkaccount/platform_asset_list_csv','permission' => 1),
    ),

    'statistics-tradefeeSettlement'=>array(
        array('id' => '40080' ,'name' => lang('jys_settlement_list') ,'mod_do_url' => '/checkaccount/settlement_list','permission' => 1),
        array('id' => '40084' ,'name' => lang('jys_settlement_csv') ,'mod_do_url' => '/checkaccount/settlement_list_csv','permission' => 1),
        array('id' => '40081' ,'name' => lang('jys_settlement') ,'mod_do_url' => '/checkaccount/settlement','permission' => 1),
        array('id' => '40082' ,'name' => lang('jys_perday_detail_list') ,'mod_do_url' => '/checkaccount/perday_detail_list','permission' => 0),
        array('id' => '40083' ,'name' => lang('jys_perday_detail_csv') ,'mod_do_url' => '/checkaccount/perday_detail_csv','permission' => 0),
        array('id' => '40085' ,'name' => lang('jys_settlement_all') ,'mod_do_url' => '/checkaccount/settlement_all','permission' => 0),
        array('id' => '40086' ,'name' => lang('jys_checkbalance') ,'mod_do_url' => '/checkaccount/check_balance','permission' => 1),
        array('id' => '40087' ,'name' => lang('jys_settlement_record_list') ,'mod_do_url' => '/checkaccount/settlement_record_list','permission' => 1),
        array('id' => '40088' ,'name' => lang('jys_settlement_record_list_csv') ,'mod_do_url' => '/checkaccount/settlement_record_list_csv','permission' => 1),
    ),
    'statistics-tradefeeSettlementPerday'=>array(
        array('id' => '40089' ,'name' => lang('jys_day_settlement_list') ,'mod_do_url' => '/checkaccount/day_settlement_list','permission' => 1),
        array('id' => '40090' ,'name' => lang('jys_day_settlement_csv') ,'mod_do_url' => '/checkaccount/day_settlement_list_csv','permission' => 1),
        array('id' => '40091' ,'name' => lang('jys_day_settlement') ,'mod_do_url' => '/checkaccount/day_settlement','permission' => 1),
        // array('id' => '40082' ,'name' => lang('jys_perday_detail_list') ,'mod_do_url' => '/checkaccount/perday_detail_list','permission' => 0),
        // array('id' => '40083' ,'name' => lang('jys_perday_detail_csv') ,'mod_do_url' => '/checkaccount/perday_detail_csv','permission' => 0),
        array('id' => '40092' ,'name' => lang('jys_day_settlement_all') ,'mod_do_url' => '/checkaccount/day_settlement_all','permission' => 1),
        // array('id' => '40086' ,'name' => lang('jys_checkbalance') ,'mod_do_url' => '/checkaccount/check_balance','permission' => 1),
        array('id' => '40093' ,'name' => lang('jys_day_settlement_record_list') ,'mod_do_url' => '/checkaccount/day_settlement_record_list','permission' => 1),
        array('id' => '40094' ,'name' => lang('jys_day_settlement_record_list_csv') ,'mod_do_url' => '/checkaccount/day_settlement_record_list_csv','permission' => 1),
    ),
    'statistics-platformInout'=>array(
        array('id' => '40095' ,'name' => lang('platform_balacne_payment') ,'mod_do_url' => '/checkaccount/platform_balacne_payment','permission' => 1),
        array('id' => '40096' ,'name' => lang('platform_balacne_payment_detail') ,'mod_do_url' => '/checkaccount/platform_balacne_payment_detail','permission' => 1),
    ),

    //交易管理
    'order-transactionOrder'=>array(
        //成交记录
        array('id' => '30081' ,'name' => lang('jys_get_platform_deal') ,'mod_do_url' => '/zjys_trade/platform_deal_detail','permission' => 1),
        array('id' => '40032' ,'name' => lang('jys_get_platform_deal_printcsv') ,'mod_do_url' => '/zjys_trade/platform_deal_detail_printcsv','permission' => 1),
    ),
    'order-commissionOrder'=>array(
        //委托记录
        array('id' => '30082' ,'name' => lang('jys_get_platform_order') ,'mod_do_url' => '/zjys_trade/platform_order_detail','permission' => 1),
        array('id' => '40033' ,'name' => lang('jys_get_platform_order_printcsv') ,'mod_do_url' => '/zjys_trade/platform_order_detail_printcsv','permission' => 1),
        array('id' => '40034' ,'name' => lang('jys_cancel_order_single') ,'mod_do_url' => '/order/cancel_order_single','permission' => 1),
        array('id' => '40035' ,'name' => lang('jys_cancel_order_market') ,'mod_do_url' => '/order/cancel_order_market','permission' => 1),
        array('id' => '40036' ,'name' => lang('jys_cancel_order_user_market') ,'mod_do_url' => '/order/cancel_order_user_market','permission' => 1),
        array('id' => '40037' ,'name' => lang('jys_QueryWalletBalance') ,'mod_do_url' => '/order/QueryWalletBalance','permission' => 0),
    ),
    //指定用户全部委托
    'order-userOrder'=>array(
        //委托记录
        array('id' => '200001' ,'name' => lang('jys_get_user_order') ,'mod_do_url' => '/zjys_trade/user_order_all','permission' => 1),
        array('id' => '200002' ,'name' => lang('jjys_get_user_order_printcsv') ,'mod_do_url' => '/zjys_trade/user_order_all_printcsv','permission' => 0),
    ),

    //撤单记录
    'order-cancelOrder'=>array(
        //撤销订单记录
        array('id' => '20075' ,'name' => lang('cancel_order_record_list') ,'mod_do_url' => '/zjys_trade/cancel_order_record_list','permission' => 1),
    ),

    //交易排名
    'order-transactionNumber'=>array(
        //撤销订单记录
        array('id' => '100015' ,'name' => lang('transaction_number') ,'mod_do_url' => '/zjys_trade/transaction_number','permission' => 1),
    ),



    //活动管理
    'activity-activityList'=>array(
        // array('id' => '30027' ,'name' => lang('jys_activity_info') ,'mod_do_url' => '/zjys_activity/get_info','permission' => 1),
        //活动列表
        array('id' => '30028' ,'name' => lang('jys_activity_list') ,'mod_do_url' => '/zjys_activity/activity_list','permission' => 1),
        //添加活动
        array('id' => '30029' ,'name' => lang('jys_activity_add') ,'mod_do_url' => '/zjys_activity/add_activity','permission' => 1),
        //删除活动
        array('id' => '30030' ,'name' => lang('jys_activity_delete') ,'mod_do_url' => '/zjys_activity/delete','permission' => 1),
        array('id' => '32001' ,'name' => lang('jys_activity_userawards') ,'mod_do_url' => '/zjys_activity/user_award_list','permission' => 1),
        array('id' => '32003' ,'name' => lang('jys_activity_award_priv') ,'mod_do_url' => '/zjys_activity/user_award_list_priv','permission' => 1),
        
    ),
    'activity-possessionActivity'=>array(
        array('id' => '30105' ,'name' => lang('jys_activityholding_list') ,'mod_do_url' => '/config/activityholdinglist','permission' => 1),
        array('id' => '30106' ,'name' => lang('jys_activityholding_add') ,'mod_do_url' => '/config/activityholdingadd','permission' => 1),
        array('id' => '30107' ,'name' => lang('jys_activityholding_delete') ,'mod_do_url' => '/config/activityholdingdelete','permission' => 1),
        array('id' => '30108' ,'name' => lang('jys_activityholdingaward_list') ,'mod_do_url' => '/config/activityholdingawardlist','permission' => 1),
    ),
    'activity-lotteryList'=>array(
        //抽奖奖励
        array('id' => '30109' ,'name' => lang('jys_user_lottery_logs') ,'mod_do_url' => '/config/user_lottery_logs','permission' => 1),
    ),
    'activity-treasureActivity'=>array(
        array('id' => '30118' ,'name' => lang('jys_user_treasure_logs') ,'mod_do_url' => '/config/user_treasure_logs','permission' => 1),
        array('id' => '30119' ,'name' => lang('jys_treasure_sessions') ,'mod_do_url' => '/config/treasure_sessions','permission' => 1),
    ), //夺宝活动
    'activity-airdropActivity'=>array(), //空投活动
    'activity-newYearActivity'=>array(
        //array('id' => '30126' ,'name' => lang('new_year_add') ,'mod_do_url' => '/zg_activity/insert_new_year_activity','permission' => 1),
        array('id' => '30127' ,'name' => lang('new_year_pool_balance') ,'mod_do_url' => '/zg_activity/change_pool_balance','permission' => 1),
        array('id' => '30128' ,'name' => lang('new_year_state') ,'mod_do_url' => '/zg_activity/year_state','permission' => 0),
        array('id' => '30129' ,'name' => lang('new_year_user_log') ,'mod_do_url' => '/zg_activity/year_activity_list','permission' => 1),
        array('id' => '30131' ,'name' => lang('new_year_pool_info') ,'mod_do_url' => '/zg_activity/year_activity_monitoring','permission' => 1),
        array('id' => '30132' ,'name' => lang('new_year_pool_log') ,'mod_do_url' => '/zg_activity/year_activity_pool_log','permission' => 1),
    ), //新年活动

    // //活动解锁
    // 'activity-unlock'=>array(
    //     array('id' => '20114' ,'name' => lang('activity_unlock') ,'mod_do_url' => '/Zjys_activity/activity_unlock','permission' => 1),
    //     array('id' => '20115' ,'name' => lang('batch_activity_file') ,'mod_do_url' => '/Zjys_activity/batch_activity_file','permission' => 1),
    //     array('id' => '20116' ,'name' => lang('batch_activity_unlock') ,'mod_do_url' => '/Zjys_activity/batch_activity_unlock','permission' => 1),
    //     array('id' => '20117' ,'name' => lang('activity_unlock_list') ,'mod_do_url' => '/Zjys_activity/activity_unlock_list','permission' => 1),
    //     array('id' => '20118' ,'name' => lang('activity_unlock_list_csv') ,'mod_do_url' => '/Zjys_activity/activity_unlock_list_csv','permission' => 1),
    //     array('id' => '20124' ,'name' => lang('activity_unlock_sample_csv') ,'mod_do_url' => '/Zjys_activity/activity_unlock_sample_csv','permission' => 0),
    // ),

    //站点管理
    'site-siteList'=>array(
        array('id' => '10001' ,'name' => lang('site_a') ,'mod_do_url' => '/site/get_site_base','permission' => 0),
        array('id' => '10002' ,'name' => lang('site_b') ,'mod_do_url' => '/site/add','permission' => 1),
        array('id' => '10003' ,'name' => lang('site_c') ,'mod_do_url' => '/site/get_list','permission' => 1),
        array('id' => '300605' ,'name' => lang('site_c') ,'mod_do_url' => '/site/get_list_noauth','permission' => 0),
        array('id' => '10004' ,'name' => lang('site_d') ,'mod_do_url' => '/site/update','permission' => 1),
        array('id' => '10005' ,'name' => lang('site_e') ,'mod_do_url' => '/site/domain_add','permission' => 0),
        array('id' => '10006' ,'name' => lang('site_f') ,'mod_do_url' => '/site/domain_update','permission' => 0),
        array('id' => '10007' ,'name' => lang('site_g') ,'mod_do_url' => '/site/domain_delete','permission' => 0),
        array('id' => '10008' ,'name' => lang('site_h') ,'mod_do_url' => '/site/site_info','permission' => 0),
    ),
    'site-siteAdmin'=>array(
        array('id' => '30049' ,'name' => lang('jys_subsite_addsadmin') ,'mod_do_url' => '/admin/subadmin_update','permission' => 1),
        //子站超管列表
        array('id' => '30050' ,'name' => lang('jys_subsite_sadminlist') ,'mod_do_url' => '/admin/subadmin_list','permission' => 1),
    ),

    //权限管理
    'authority-administratorList'=>array(
        array('id' => '13004' ,'name' => lang('roles_d') ,'mod_do_url' => '/admin/admin_list','permission' => 1),
        array('id' => '13005' ,'name' => lang('roles_e') ,'mod_do_url' => '/admin/admin_lock','permission' => 1),
        array('id' => '13006' ,'name' => lang('roles_f') ,'mod_do_url' => '/admin/admin_update','permission' => 1),
        array('id' => '13007' ,'name' => lang('roles_g') ,'mod_do_url' => '/admin/admin_delete','permission' => 1),
        array('id' => '20123' ,'name' => lang('SMS') ,'mod_do_url' => '/admin/SMS','permission' => 0),
        array('id' => '20125' ,'name' => lang('verity_login') ,'mod_do_url' => '/admin/verity_login','permission' => 0),
        array('id' => '40031' ,'name' => lang('roles_h') ,'mod_do_url' => '/admin/switch_language','permission' => 0),
        array('id' => '13009' ,'name' => lang('roles_i') ,'mod_do_url' => '/admin/update_password','permission' => 1),
        array('id' => '50000' ,'name' => lang('update_password_self') ,'mod_do_url' => '/admin/update_password_self','permission' => 0),
        array('id' => '13011' ,'name' => lang('roles_j') ,'mod_do_url' => '/admin/update_priv','permission' => 0),
        array('id' => '13012' ,'name' => lang('roles_k') ,'mod_do_url' => '/admin/get_roles_by_site','permission' => 0),
        array('id' => '8010' ,'name' => lang('account_j') ,'mod_do_url' => '/admin/quit','permission' => 0),
        array('id' => '20131' ,'name' => lang('modify_frequency') ,'mod_do_url' => '/admin/modify_frequency','permission' => 1),
    ),
    'authority-departmentRole'=>array(
        array('id' => '13001' ,'name' => lang('roles_a') ,'mod_do_url' => '/admin/roles_list','permission' => 1),
        array('id' => '13002' ,'name' => lang('roles_b') ,'mod_do_url' => '/admin/roles_update','permission' => 1),
        array('id' => '13003' ,'name' => lang('roles_c') ,'mod_do_url' => '/admin/roles_base','permission' => 1),
        array('id' => '13013' ,'name' => lang('roles_l') ,'mod_do_url' => '/admin/roles_delete','permission' => 1),
    ),

    //网站配置
    'operation-bannerList'=>array(
        array('id' => '9019' ,'name' => lang('operation_l') ,'mod_do_url' => '/config/banner_friend_list','permission' => 1),
        array('id' => '9021' ,'name' => lang('operation_m') ,'mod_do_url' => '/config/banner_friend_delete','permission' => 1),
        array('id' => '9022' ,'name' => lang('operation_n') ,'mod_do_url' => '/config/banner_update','permission' => 1),
    ),
    'operation-setting'=>array(
        array('id' => '30039' ,'name' => lang('config_agreement_update') ,'mod_do_url' => '/config/agreement_update','permission' => 1),
        array('id' => '30040' ,'name' => lang('config_agreement_list') ,'mod_do_url' => '/config/agreement_list','permission' => 1),
        array('id' => '30041' ,'name' => lang('config_agreement_delete') ,'mod_do_url' => '/config/agreement_delete','permission' => 1),
    ),
    'operation-linkList'=>array(
        array('id' => '30042' ,'name' => lang('config_friendlink_update') ,'mod_do_url' => '/config/friendlink_update','permission' => 1),
        array('id' => '30043' ,'name' => lang('config_friendlink_list') ,'mod_do_url' => '/config/friendlink_list','permission' => 1),
        array('id' => '30044' ,'name' => lang('config_friendlink_delete') ,'mod_do_url' => '/config/friendlink_delete','permission' => 1),
    ),
    'operation-newsList'=>array(
        array('id' => '9004' ,'name' => lang('operation_a') ,'mod_do_url' => '/config/newsUpdate','permission' => 1),
        array('id' => '9005' ,'name' => lang('operation_b') ,'mod_do_url' => '/config/news','permission' => 1),
        array('id' => '9006' ,'name' => lang('operation_c') ,'mod_do_url' => '/config/newsDelete','permission' => 1),
        array('id' => '9007' ,'name' => lang('operation_d') ,'mod_do_url' => '/config/newsAdd','permission' => 1),
        array('id' => '9024' ,'name' => lang('config_g') ,'mod_do_url' => '/config/news_class','permission' => 1),
        array('id' => '300603' ,'name' => lang('config_g') ,'mod_do_url' => '/config/news_class_noauth','permission' => 0),
        array('id' => '9025' ,'name' => lang('config_k') ,'mod_do_url' => '/config/news_class_delete','permission' => 1),
        array('id' => '9026' ,'name' => lang('config_l') ,'mod_do_url' => '/config/news_class_update','permission' => 1),
        array('id' => '40053' ,'name' => lang('config_news_content_list') ,'mod_do_url' => '/config/news_content_list','permission' => 1),
        array('id' => '40054' ,'name' => lang('config_news_content_add') ,'mod_do_url' => '/config/news_content_add','permission' => 1),
        array('id' => '40055' ,'name' => lang('config_news_content_delete') ,'mod_do_url' => '/config/news_content_delete','permission' => 1),
    ),
    'operation-helpList'=>array(
        array('id' => '9012' ,'name' => lang('operation_h') ,'mod_do_url' => '/config/help_list','permission' => 1),
        array('id' => '9013' ,'name' => lang('operation_i') ,'mod_do_url' => '/config/help_delete','permission' => 1),
        array('id' => '9014' ,'name' => lang('operation_j') ,'mod_do_url' => '/config/help_update','permission' => 1),
        array('id' => '9015' ,'name' => lang('operation_k') ,'mod_do_url' => '/config/help_class','permission' => 1),
        array('id' => '300604' ,'name' => lang('operation_k') ,'mod_do_url' => '/config/help_class_noauth','permission' => 0),
        array('id' => '9016' ,'name' => lang('operation_kadd') ,'mod_do_url' => '/config/help_class_add','permission' => 1),//
        array('id' => '9017' ,'name' => lang('operation_kdelete') ,'mod_do_url' => '/config/help_class_delete','permission' => 1),
        array('id' => '9018' ,'name' => lang('config_help_content_list') ,'mod_do_url' => '/config/help_content_list','permission' => 1),
        array('id' => '9020' ,'name' => lang('config_help_content_add') ,'mod_do_url' => '/config/help_content_add','permission' => 1),
        array('id' => '9023' ,'name' => lang('config_help_content_delete') ,'mod_do_url' => '/config/help_content_delete','permission' => 1),
        array('id' => '90181' ,'name' => lang('config_help_class_content_list') ,'mod_do_url' => '/config/help_class_content_list','permission' => 1),
        array('id' => '90201' ,'name' => lang('config_help_class_content_add') ,'mod_do_url' => '/config/help_class_content_add','permission' => 1),
        array('id' => '90231' ,'name' => lang('config_help_class_content_delete') ,'mod_do_url' => '/config/help_class_content_delete','permission' => 1),
    ),
    'operation-labelConfig'=>array(
        array('id' => '30102' ,'name' => lang('config_labelconfiglist') ,'mod_do_url' => '/config/labelconfiglist','permission' => 1),
        array('id' => '30103' ,'name' => lang('config_labelconfigadd') ,'mod_do_url' => '/config/labelconfigadd','permission' => 1),
        array('id' => '30104' ,'name' => lang('config_labelconfigdelete') ,'mod_do_url' => '/config/labelconfigdelete','permission' => 1),
    ),

    //广告位管理
    'operation-advertPlace'=>array(
        array('id' => '50002' ,'name' => lang('advert_place_list') ,'mod_do_url' => '/config/advert_place_list','permission' => 1),
        array('id' => '50003' ,'name' => lang('advert_place_add') ,'mod_do_url' => '/config/advert_place_add','permission' => 1),
        array('id' => '50004' ,'name' => lang('advert_place_del') ,'mod_do_url' => '/config/advert_place_delete','permission' => 1),
        array('id' => '50008' ,'name' => lang('advert_place_updown') ,'mod_do_url' => '/config/advert_place_updown','permission' => 1),
    ),

    //新手指南管理
    'operation-fingerPost'=>array(
        array('id' => '50005' ,'name' => lang('fingerpost_list') ,'mod_do_url' => '/config/fingerpost_list','permission' => 1),
        array('id' => '50006' ,'name' => lang('fingerpost_add') ,'mod_do_url' => '/config/fingerpost_add','permission' => 1),
        array('id' => '50007' ,'name' => lang('fingerpost_del') ,'mod_do_url' => '/config/fingerpost_delete','permission' => 1),
        array('id' => '50009' ,'name' => lang('fingerpost_updown') ,'mod_do_url' => '/config/fingerpost_updown','permission' => 1),
    ),


    //系统配置
    'config-appConfig'=>array(
        array('id' => '30095' ,'name' => lang('config_appconfig_list') ,'mod_do_url' => '/config/app_update_list','permission' => 1),
        array('id' => '30096' ,'name' => lang('config_appconfig_add') ,'mod_do_url' => '/config/app_update_add','permission' => 1),
        array('id' => '30097' ,'name' => lang('config_appconfig_delete') ,'mod_do_url' => '/config/app_update_delete','permission' => 1),


        array('id' => '20183' ,'name' => lang('addAppFile') ,'mod_do_url' => '/config/addAppFile','permission' => 1),
        array('id' => '20184' ,'name' => lang('appConfigList') ,'mod_do_url' => '/config/appConfigList','permission' => 1),
        array('id' => '20185' ,'name' => lang('appDownloadDetails') ,'mod_do_url' => '/config/appDownloadDetails','permission' => 1),
    
    ),
    'config-apiList'=>array(
        array('id' => '30110' ,'name' => lang('jys_app_trade_config_list') ,'mod_do_url' => '/config/apptradelist','permission' => 1),
        array('id' => '30111' ,'name' => lang('jys_app_trade_config_add') ,'mod_do_url' => '/config/apptradeadd','permission' => 1),
        array('id' => '30112' ,'name' => lang('jys_app_trade_config_delete') ,'mod_do_url' => '/config/apptradedelete','permission' => 1),
        array('id' => '20170' ,'name' => lang('appTradeDetails') ,'mod_do_url' => '/config/appTradeDetails','permission' => 1),
        array('id' => '20176' ,'name' => lang('appTradestatus') ,'mod_do_url' => '/config/appTradestatus','permission' => 1),
    ),
    'config-paramsList'=>array(
        array('id' => '30068' ,'name' => lang('jys_params_config_c2c') ,'mod_do_url' => '/zjys_c2corder/params_config_c2c','permission' => 1),
        array('id' => '30069' ,'name' => lang('jys_params_config_c2c_update') ,'mod_do_url' => '/zjys_c2corder/c2c_config_update','permission' => 1),
    ),
    'config-vipList'=>array(
        array('id' => '30053' ,'name' => lang('jys_vip_list') ,'mod_do_url' => '/zjys_user/vip_list','permission' => 1),
        array('id' => '300600' ,'name' => lang('jys_vip_list') ,'mod_do_url' => '/zjys_user/vip_list_noauth','permission' => 0),//做权限用
        array('id' => '30055' ,'name' => lang('jys_vip_edit') ,'mod_do_url' => '/zjys_user/vip_edit','permission' => 1),

        array('id' => '20171' ,'name' => lang('vipRecord') ,'mod_do_url' => '/zjys_user/vipRecord','permission' => 1),
        array('id' => '20172' ,'name' => lang('vipAddEdit') ,'mod_do_url' => '/zjys_user/vipAddEdit','permission' => 1),
        array('id' => '20173' ,'name' => lang('vipAddEditVerity') ,'mod_do_url' => '/zjys_user/vipAddEditVerity','permission' => 1),
        array('id' => '20175' ,'name' => lang('vipDelete') ,'mod_do_url' => '/zjys_user/vipDelete','permission' => 0),
    ),
    //币种详情
    'config-assetIntroList'=>array(
        array('id' => '40007' ,'name' => lang('jys_assetintro_list') ,'mod_do_url' => '/zjys_assets/asset_intro_list','permission' => 1),
        array('id' => '40008' ,'name' => lang('jys_assetintro_add') ,'mod_do_url' => '/zjys_assets/asset_intro_add','permission' => 1),
        array('id' => '40009' ,'name' => lang('jys_assetintro_del') ,'mod_do_url' => '/zjys_assets/asset_intro_delete','permission' => 1),
    ),
    //交易区块
    'config-symbolBlockList'=>array(
        array('id' => '40010' ,'name' => lang('jys_symbolblock_list') ,'mod_do_url' => '/zjys_symbols/symbolblock_list','permission' => 1),
        array('id' => '40011' ,'name' => lang('jys_symbolblock_add') ,'mod_do_url' => '/zjys_symbols/symbolblock_add','permission' => 1),
        array('id' => '40012' ,'name' => lang('jys_symbolblock_del') ,'mod_do_url' => '/zjys_symbols/symbolblock_delete','permission' => 1),
        array('id' => '40013' ,'name' => lang('symbolblock_list_list_noauth') ,'mod_do_url' => '/zjys_symbols/symbolblock_list_noauth','permission' => 0),
    ),

    'config-smsConfigList'=>array(
        array('id' => '40014' ,'name' => lang('jys_smsconfig_list') ,'mod_do_url' => '/config/smsconfig_list','permission' => 1),
        array('id' => '40015' ,'name' => lang('jys_smsconfig_add') ,'mod_do_url' => '/config/smsconfig_add','permission' => 1),
        array('id' => '40016' ,'name' => lang('jys_smsconfig_del') ,'mod_do_url' => '/config/smsconfig_delete','permission' => 1),
        array('id' => '40024' ,'name' => lang('jys_smsconfig_used') ,'mod_do_url' => '/config/smsconfig_used','permission' => 1),
    ),

    'config-emailConfigList'=>array(
        array('id' => '40017' ,'name' => lang('jys_emailconfig_list') ,'mod_do_url' => '/config/emailconfig_list','permission' => 1),
        array('id' => '40018' ,'name' => lang('jys_emailconfig_add') ,'mod_do_url' => '/config/emailconfig_add','permission' => 1),
        array('id' => '40019' ,'name' => lang('jys_emailconfig_del') ,'mod_do_url' => '/config/emailconfig_delete','permission' => 1),
        array('id' => '40025' ,'name' => lang('jys_emailconfig_used') ,'mod_do_url' => '/config/emailconfig_used','permission' => 1),
    ),
    //邀请好友配置
    'config-inviteConfigList'=>array(
        array('id' => '40020' ,'name' => lang('jys_inviteconfig_list') ,'mod_do_url' => '/config/inviteconfig_list','permission' => 1),
        array('id' => '40021' ,'name' => lang('jys_inviteconfig_add') ,'mod_do_url' => '/config/inviteconfig_add','permission' => 1),
        array('id' => '40022' ,'name' => lang('jys_inviteconfig_del') ,'mod_do_url' => '/config/inviteconfig_delete','permission' => 1),
        array('id' => '40023' ,'name' => lang('jys_inviteconfig_used') ,'mod_do_url' => '/config/inviteconfig_used','permission' => 1),
    ),

    //ip黑白名单管理
    'config-ipManage'=>array(
        array('id' => '40050' ,'name' => lang('jys_ip_list') ,'mod_do_url' => '/config/ip_list','permission' => 1),
        array('id' => '40051' ,'name' => lang('jys_ip_add') ,'mod_do_url' => '/config/ip_add','permission' => 1),
        array('id' => '40052' ,'name' => lang('jys_ip_del') ,'mod_do_url' => '/config/ip_delete','permission' => 1),
        array('id' => '30077' ,'name' => lang('jys_amdin_whiteip_list') ,'mod_do_url' => '/config/admin_whiteip_list','permission' => 1),
        array('id' => '100013' ,'name' => lang('jys_amdin_whiteip_add') ,'mod_do_url' => '/config/admin_whiteip_add','permission' => 1),
        array('id' => '100014' ,'name' => lang('jys_amdin_whiteip_del') ,'mod_do_url' => '/config/admin_whiteip_delete','permission' => 1),
    ),

    
  

    //系统记录
    'log-codeLogs'=>array(
        array('id' => '30004' ,'name' => lang('jys_valids_list') ,'mod_do_url' => '/zjys_valids/valids_list','permission' => 1),
    ),
    'log-operationLogs'=>array(
        array('id' => '8004' ,'name' => lang('account_d') ,    'mod_do_url' => '/account/get_logs_list','permission' => 1),
    ),
    'log-walletLogs'=>array(
        array('id' => '30075' ,'name' => lang('zjys_wallet_request_logs') ,'mod_do_url' => '/zjys_trade/get_wallet_logs','permission' => 1),
    ),

    'log-keyLogs'=>array(
        array('id' => '30076' ,'name' => lang('sys_key_log') ,'mod_do_url' => '/keylog/keylog_list','permission' => 1),
    ),

     // //风控管理
     'alarm-alarmList'=>array(
         array('id' => '20005' ,'name' => lang('symbols') ,'mod_do_url' => '/alarm/get_market','permission' => 0),
         array('id' => '20006' ,'name' => lang('transaction_alarm_list') ,'mod_do_url' => '/alarm/get_transaction_alarm_list','permission' => 1),
         array('id' => '20007' ,'name' => lang('profit_loss_alarm_list') ,'mod_do_url' => '/alarm/get_profit_loss_alarm_list','permission' => 1),
         array('id' => '20008' ,'name' => lang('account_alarm_list') ,'mod_do_url' => '/alarm/get_account_alarm_list','permission' => 1),
         array('id' => '20053' ,'name' => lang('withdraws_alarm_list') ,'mod_do_url' => '/Alarm/withdraws_alarm_list','permission' => 1),
         array('id' => '20054' ,'name' => lang('deal_status') ,'mod_do_url' => '/Alarm/deal_status','permission' => 1),

         array('id' => '20059' ,'name' => lang('recharge_address_list') ,'mod_do_url' => '/Alarm/recharge_address_list','permission' => 1),
         array('id' => '20060' ,'name' => lang('address_deal_status') ,'mod_do_url' => '/Alarm/address_deal_status','permission' => 1),
         array('id' => '20145' ,'name' => lang('large_amount_list') ,'mod_do_url' => '/Alarm/large_amount_list','permission' => 1),
         array('id' => '20146' ,'name' => lang('withdraws_wallet_list') ,'mod_do_url' => '/Alarm/withdraws_wallet_list','permission' => 1),
         array('id' => '20147' ,'name' => lang('large_amount_deal') ,'mod_do_url' => '/Alarm/large_amount_deal','permission' => 1),
         array('id' => '20148' ,'name' => lang('withdraws_wallet_deal') ,'mod_do_url' => '/Alarm/withdraws_wallet_deal','permission' => 1),
         array('id' => '20148889' ,'name' => lang('rabbit_message') ,'mod_do_url' => '/Alarm/rabbit_message','permission' => 0),

     ),
     'alarm-alarmParams'=>array(
         array('id' => '20009' ,'name' => lang('transaction_param') ,'mod_do_url' => '/alarm/get_transaction_param','permission' => 1),
         array('id' => '20010' ,'name' => lang('account_param') ,'mod_do_url' => '/alarm/get_account_param','permission' => 1),
         array('id' => '20011' ,'name' => lang('modify_transaction_param') ,'mod_do_url' => '/alarm/modify_transaction_param',   'permission' => 0),
         array('id' => '20012' ,'name' => lang('modify_account_param') ,'mod_do_url' => '/alarm/modify_account_param','permission' => 1),
         array('id' => '20013' ,'name' => lang('get_profit_param') ,'mod_do_url' => '/alarm/get_profit_param','permission' => 1),
         array('id' => '20014' ,'name' => lang('modify_profit_param') ,'mod_do_url' => '/alarm/modify_profit_param','permission' => 1),
         array('id' => '20149' ,'name' => lang('large_amount_par') ,'mod_do_url' => '/Alarm/large_amount_par','permission' => 1),
         array('id' => '20150' ,'name' => lang('withdraws_wallet_par') ,'mod_do_url' => '/Alarm/withdraws_wallet_par','permission' => 1),
         array('id' => '20151' ,'name' => lang('get_new_par') ,'mod_do_url' => '/Alarm/get_new_par','permission' => 1),
     ),
     'alarm-userWhite'=>array(
         array('id' => '20029' ,'name' => lang('user_white_list') ,'mod_do_url' => '/alarm/user_white_list','permission' => 1),
         array('id' => '20030' ,'name' => lang('user_white_add') ,'mod_do_url' => '/alarm/user_white_add','permission' => 1),
         array('id' => '20031' ,'name' => lang('user_white_delete') ,'mod_do_url' => '/alarm/user_white_delete','permission' => 1),
     ),
    'alarm-target'=>array(
        array('id' => '20126' ,'name' => lang('add_target_roles') ,'mod_do_url' => '/alarm/add_target_roles','permission' => 1),
        array('id' => '20127' ,'name' => lang('delete_target_roles') ,'mod_do_url' => '/alarm/delete_target_roles','permission' => 1),
        array('id' => '20128' ,'name' => lang('target_people_list') ,'mod_do_url' => '/alarm/target_people_list','permission' => 1),
    ),




    //第三方服务
    'service-serviceList'=>array(),

    //运营数据统计：
    'data-statisticsList'=>array(
        //新的运营统计数据接口
        array('id' => '20015' ,'name' => lang('asset_list') ,'mod_do_url' => '/zjys_statistics/asset_list','permission' => 1),
        array('id' => '20016' ,'name' => lang('asset_list_csv') ,'mod_do_url' => '/zjys_statistics/asset_list_csv','permission' => 1),
        array('id' => '20017' ,'name' => lang('register_list') ,'mod_do_url' => '/zjys_statistics/register_list','permission' => 1),
        array('id' => '20018' ,'name' => lang('register_list_csv') ,'mod_do_url' => '/zjys_statistics/register_list_csv','permission' => 1),
        array('id' => '20019' ,'name' => lang('recharge_list') ,'mod_do_url' => '/zjys_statistics/recharge_list','permission' => 1),
        array('id' => '20020' ,'name' => lang('recharge_list_csv') ,'mod_do_url' => '/zjys_statistics/recharge_list_csv','permission' => 1),
        array('id' => '20021' ,'name' => lang('withdraws_list') ,'mod_do_url' => '/zjys_statistics/withdraws_list','permission' => 1),
        array('id' => '20022' ,'name' => lang('withdraws_list_csv') ,'mod_do_url' => '/zjys_statistics/withdraws_list_csv','permission' => 1),
        array('id' => '20023' ,'name' => lang('c2cbuy_list') ,'mod_do_url' => '/zjys_statistics/c2cbuy_list','permission' => 1),
        array('id' => '20024' ,'name' => lang('c2cbuy_list_csv') ,'mod_do_url' => '/zjys_statistics/c2cbuy_list_csv','permission' => 1),
        array('id' => '20025' ,'name' => lang('c2csell_list') ,'mod_do_url' => '/zjys_statistics/c2csell_list','permission' => 1),
        array('id' => '20026' ,'name' => lang('c2csell_list_csv') ,'mod_do_url' => '/zjys_statistics/c2csell_list_csv','permission' => 1),
        array('id' => '20027' ,'name' => lang('cointrade_list') ,'mod_do_url' => '/zjys_statistics/cointrade_list','permission' => 1),
        array('id' => '20028' ,'name' => lang('cointrade_list_csv') ,'mod_do_url' => '/zjys_statistics/cointrade_list_csv','permission' => 1),
        array('id' => '20200' ,'name' => lang('trade_detail') ,'mod_do_url' => '/zjys_statistics/trade_detail','permission' => 0),

        array('id' => '20032' ,'name' => lang('cointrade_list_csv') ,'mod_do_url' => '/zjys_statistics/deal_history','permission' => 0),
        array('id' => '20033' ,'name' => lang('cointrade_list_csv') ,'mod_do_url' => '/zjys_statistics/order_history','permission' => 0),
        array('id' => '20034' ,'name' => lang('cointrade_list_csv') ,'mod_do_url' => '/zjys_statistics/login_ip','permission' => 0),
        array('id' => '20062' ,'name' => lang('hold_coin_list') ,'mod_do_url' => '/zjys_statistics/hold_coin_list','permission' => 1),
        array('id' => '20063' ,'name' => lang('hold_coin_csv') ,'mod_do_url' => '/zjys_statistics/hold_coin_csv','permission' => 1),

        array('id' => '40056' ,'name' => lang('deal_fee_platform') ,'mod_do_url' => '/zjys_statistics/platform_fee','permission' => 1),
        array('id' => '20153' ,'name' => lang('symbols_price_list') ,'mod_do_url' => '/zjys_statistics/symbols_price_list','permission' => 0),
        array('id' => '20154' ,'name' => lang('symbols_price_csv') ,'mod_do_url' => '/zjys_statistics/symbols_price_csv','permission' => 0),

        array('id' => '20180' ,'name' => lang('tradeAmount') ,'mod_do_url' => '/zjys_statistics/tradeAmount','permission' => 1),

        array('id' => '20181' ,'name' => lang('tradeZoneDetails') ,'mod_do_url' => '/zjys_statistics/tradeZoneDetails','permission' => 1),

        array('id' => '20182' ,'name' => lang('symbolDetails') ,'mod_do_url' => '/zjys_statistics/symbolDetails','permission' => 1),
    ),
    'data-statisticsConfig'=>array(
        array('id' => '30113' ,'name' => lang('jys_statistics_mail_config_list') ,'mod_do_url' => '/config/mailconfiglist','permission' => 1),
        array('id' => '30114' ,'name' => lang('jys_statistics_mail_config_add') ,'mod_do_url' => '/config/mailconfigadd','permission' => 1),
        array('id' => '30115' ,'name' => lang('jys_statistics_mail_config_delete') ,'mod_do_url' => '/config/mailconfigdelete','permission' => 1),
        // array('id' => '30116' ,'name' => lang('jys_statistics_mail_sent_records') ,'mod_do_url' => '/config/statisticmailsentrecords','permission' => 1),

    ),
    //新增资产统计
    'data-newaddAsset'=>array(
        array('id' => '31000' ,'name' => lang('jys_statistics_newaddasset_list') ,'mod_do_url' => '/zjys_statistics/newaddasset_list','permission' => 1),
        array('id' => '31002' ,'name' => lang('jys_statistics_newaddasset_list_total') ,'mod_do_url' => '/zjys_statistics/newaddasset_list_total','permission' => 1),
    ),
     //统计的参数设定
    'data-statisticAsset'=>array(
        array('id' => '30117' ,'name' => lang('jys_statistics_asset_general') ,'mod_do_url' => '/zjys_statistics/asset_general','permission' => 1),
        array('id' => '30141' ,'name' => lang('jys_statistics_asset_general_form') ,'mod_do_url' => '/zjys_statistics/asset_general_form','permission' => 1),
    ),

     // 定时任务
    'time_task' => array(
        array('id' => '99999' ,'name' => lang('zjys_get_trade_statistic') ,'mod_do_url' => '/tools/message','permission' => 0),
        array('id' => '999991' ,'name' => lang('zjys_get_trade_statistic') ,'mod_do_url' => '/tools/get_trade_statistic','permission' => 0),
        array('id' => '999992' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/statistics_users_task','permission' => 0),
        // array('id' => '999993' ,'name' => lang('zjys_get_trade_statistic') ,'mod_do_url' => '/zjys_trade/print_user_assets1','permission' => 0),
        array('id' => '999995' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/unlock_position','permission' => 0),
        array('id' => '999996' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/activityholding_cron','permission' => 0),
        array('id' => '999997' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/activityholdingaward_cron','permission' => 0),
        array('id' => '999998' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/aaa','permission' => 0),
        array('id' => '999999' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/tradetotal','permission' => 0),
        array('id' => '50001' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/getdata/tradetotal_all','permission' => 0),
        array('id' => '999994' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/usertotal','permission' => 0),
        array('id' => '100000' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/recharge_logs_csv','permission' => 0), 
        array('id' => '100001' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/user_withdraw_csv','permission' => 0), 
        array('id' => '100002' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/c2c_order_csv','permission' => 0), 
        array('id' => '100003' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/deduplication_data','permission' => 0), //去重数据
        array('id' => '100004' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/shiwu','permission' => 0),
        array('id' => '100005' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/get_login_numbers','permission' => 0),
        array('id' => '100006' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/trade_number','permission' => 0),
        array('id' => '20001' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/price_alarm','permission' => 0),  
        array('id' => '20002' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/transaction_alarm','permission' => 0), 
        array('id' => '20003' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/profit_loss_alarm','permission' => 0),
        array('id' => '20004' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/account_alarm','permission' => 0),
        array('id' => '100007' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/abc','permission' => 0),
        array('id' => '100010' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/abcd','permission' => 0),
        array('id' => '100009' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/get_holdcoin_numbers','permission' => 0),
        array('id' => '100011' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/user_down_account','permission' => 0),
        array('id' => '20051' ,'name' => lang('withdraws_alarm') ,'mod_do_url' => '/tools/withdraws_alarm','permission' => 0),
        array('id' => '20058' ,'name' => lang('address_alarm') ,'mod_do_url' => '/tools/address_alarm','permission' => 0),
        array('id' => '100008' ,'name' => lang('sys_service_wallet_recharge') ,'mod_do_url' => '/sys_grpc/wallet_recharge','permission' => 0),
        array('id' => '20067' ,'name' => lang('wallet_snapshot') ,'mod_do_url' => '/tools/wallet_snapshot','permission' => 0),
        array('id' => '20100' ,'name' => lang('wallet_snapshot_all') ,'mod_do_url' => '/tools/wallet_snapshot_all','permission' => 0),
        array('id' => '20070' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/data_visualization_real_time','permission' => 0),
        array('id' => '40028' ,'name' => lang('jys_statistics_mail_config_delete') ,'mod_do_url' => '/config/mailconfigdelete','permission' => 0),
        array('id' => '20133' ,'name' => lang('gift_coin') ,'mod_do_url' => '/tools/gift_coin','permission' => 0),
        array('id' => '20134' ,'name' => lang('baoquan_recharge') ,'mod_do_url' => '/tools/baoquan_recharge','permission' => 0),
        array('id' => '20135' ,'name' => lang('baoquan_trade') ,'mod_do_url' => '/tools/baoquan_trade','permission' => 0),
        array('id' => '20136' ,'name' => lang('baoquan_reward') ,'mod_do_url' => '/tools/baoquan_reward','permission' => 0),
        array('id' => '20137' ,'name' => lang('baoQuanList') ,'mod_do_url' => '/Baoquan/baoQuanList','permission' => 0),
        array('id' => '20138' ,'name' => lang('TradeList') ,'mod_do_url' => '/Baoquan/TradeList','permission' => 0),
        array('id' => '20139' ,'name' => lang('BlockList') ,'mod_do_url' => '/Baoquan/BlockList','permission' => 0),
        array('id' => '20140' ,'name' => lang('BlockList') ,'mod_do_url' => '/Baoquan/NextbaoQuanList','permission' => 0),
        array('id' => '20141' ,'name' => lang('real_data_time') ,'mod_do_url' => '/tools/real_data_time','permission' => 0),
        array('id' => '20142' ,'name' => lang('get_market') ,'mod_do_url' => '/tools/get_market','permission' => 0),
        array('id' => '20143' ,'name' => lang('tools') ,'mod_do_url' => '/tools/large_amount_charge_alarm','permission' => 0),
        array('id' => '20144' ,'name' => lang('tools') ,'mod_do_url' => '/tools/withdraws_wallet_alarm','permission' => 0),
        array('id' => '20150' ,'name' => lang('tools') ,'mod_do_url' => '/getdata/get_payment','permission' => 0),//定时任务生成利润收支
        array('id' => '20179' ,'name' => lang('getTradeZoneData') ,'mod_do_url' => '/tools/getTradeZoneData','permission' => 0),
        array('id' => '20190' ,'name' => lang('getTradeZoneData') ,'mod_do_url' => '/getdata/newassetstatistics','permission' => 0),
    ),

    'other' =>array(
        array('id' => '30033' ,'name' => lang('jys_upload_img') ,'mod_do_url' => '/file/upload','permission' => 0),
        array('id' => '40039' ,'name' => lang('jys_upload_img') ,'mod_do_url' => '/file/signe_upload','permission' => 0),
        array('id' => '40077' ,'name' => lang('jys_upload_img') ,'mod_do_url' => '/file/upload_vedio','permission' => 0),
        //线上统计数据本地化
        array('id' => '40044' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/deduplication_data','permission' => 0),
        array('id' => '40045' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/recycle_method_curl','permission' => 0),
        array('id' => '40046' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/tradetotal','permission' => 0),
        array('id' => '40047' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/deal_fee','permission' => 0),
        array('id' => '40048' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/recharge_logs_csv','permission' => 0),
        array('id' => '40049' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/user_withdraw_csv','permission' => 0),
        array('id' => '40070' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/deduplication_data','permission' => 0),
        array('id' => '40071' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/deduplication_data','permission' => 0),
        array('id' => '40072' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/deduplication_data','permission' => 0),
        array('id' => '40075' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/tradetotal_test','permission' => 0),
        array('id' => '40076' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/data_text','permission' => 0),



        array('id' => '40073' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/export/print_user_assets','permission' => 0),
        array('id' => '40074' ,'name' => lang('getdata_deduplication_data') ,'mod_do_url' => '/getdata/deduplication_data','permission' => 0),

    ),


//    平台资产
    'account-transfer' =>array(
        array('id' => '20037' ,'name' => lang('transfer_user_money') ,'mod_do_url' => '/Transfer/transfer_user_money','permission' => 1),
        array('id' => '20038' ,'name' => lang('check_balance') ,'mod_do_url' => '/Transfer/check_balance','permission' => 1),
        array('id' => '20039' ,'name' => lang('transfer_list') ,'mod_do_url' => '/Transfer/transfer_list','permission' => 1),
        array('id' => '20040' ,'name' => lang('transfer_list_csv') ,'mod_do_url' => '/Transfer/transfer_list_csv','permission' => 1),
        array('id' => '20164' ,'name' => lang('transfer_user_money_verity') ,'mod_do_url' => '/Transfer/transfer_user_money_verity','permission' => 1),
    ),
    'account-management' =>array(
        array('id' => '20032' ,'name' => lang('get_account_list') ,'mod_do_url' => '/Transfer/get_account_list','permission' => 1),
        array('id' => '20033' ,'name' => lang('add_account') ,'mod_do_url' => '/Transfer/add_account','permission' => 1),
        array('id' => '20034' ,'name' => lang('delete_account') ,'mod_do_url' => '/Transfer/delete_account','permission' => 1),
        array('id' => '20035' ,'name' => lang('generate_total_account') ,'mod_do_url' => '/Transfer/generate_total_account','permission' => 0),
        array('id' => '20036' ,'name' => lang('total_account_assets') ,'mod_do_url' => '/Transfer/total_account_assets','permission' => 1),
        array('id' => '20052' ,'name' => lang('total_account_assets_csv') ,'mod_do_url' => '/Transfer/total_account_assets_csv','permission' => 0),
        array('id' => '20055' ,'name' => lang('add_total_account') ,'mod_do_url' => '/Transfer/add_total_account','permission' => 0),
        array('id' => '20056' ,'name' => lang('add_asset_record') ,'mod_do_url' => '/Transfer/add_asset_record','permission' => 0),
        array('id' => '20041' ,'name' => lang('loan') ,'mod_do_url' => '/Transfer/loan','permission' => 1),
        array('id' => '20042' ,'name' => lang('repayment') ,'mod_do_url' => '/Transfer/repayment','permission' => 1),
        array('id' => '20057' ,'name' => lang('repayment_address') ,'mod_do_url' => '/Transfer/repayment_address','permission' => 1),
   ),
    'account-loanRepayment' =>array(
        array('id' => '20043' ,'name' => lang('loan_list') ,'mod_do_url' => '/Transfer/loan_list','permission' => 1),
        array('id' => '20044' ,'name' => lang('repayment_list') ,'mod_do_url' => '/Transfer/repayment_list','permission' => 1),
        array('id' => '20045' ,'name' => lang('loan_list_csv') ,'mod_do_url' => '/Transfer/loan_list_csv','permission' => 1),
        array('id' => '20046' ,'name' => lang('repayment_list_csv') ,'mod_do_url' => '/Transfer/repayment_list_csv','permission' => 1),
        array('id' => '20159' ,'name' => lang('loan_verity') ,'mod_do_url' => '/Transfer/loan_verity','permission' => 1),
    ),
    'account-giftCoin' =>array(
        array('id' => '20047' ,'name' => lang('gift_coin_list') ,'mod_do_url' => '/Transfer/gift_coin_list','permission' => 1),
        array('id' => '20048' ,'name' => lang('gift_coin_list_csv') ,'mod_do_url' => '/Transfer/gift_coin_list_csv','permission' => 1),
        array('id' => '20049' ,'name' => lang('gift_coin') ,'mod_do_url' => '/Transfer/gift_coin','permission' => 1),
        array('id' => '20050' ,'name' => lang('batch_gift_coin') ,'mod_do_url' => '/Transfer/batch_gift_coin','permission' => 1),
        array('id' => '20061' ,'name' => lang('batch_gift_file') ,'mod_do_url' => '/Transfer/batch_gift_file','permission' => 0),
        array('id' => '20064' ,'name' => lang('gift_sample_csv') ,'mod_do_url' => '/Transfer/gift_sample_csv','permission' => 1),
        array('id' => '20165' ,'name' => lang('gift_coin_verity') ,'mod_do_url' => '/Transfer/gift_coin_verity','permission' => 1),
        array('id' => '20162' ,'name' => lang('batch_gift_coin_verity') ,'mod_do_url' => '/Transfer/batch_gift_coin_verity','permission' => 1),
    ),
    //调账管理

    'account-updateMoney' =>array(
        //申请调账列表
        array('id' => '20201' ,'name' => lang('update_money_apply_list') ,'mod_do_url' => '/Update_money/updatemoney_apply_list','permission' => 1),
        //申请调账
        array('id' => '20202' ,'name' => lang('update_money_apply') ,'mod_do_url' => '/Update_money/updatemoney_apply','permission' => 1),
        //批量申请调账
        array('id' => '20203' ,'name' => lang('batch_updatemoney_apply') ,'mod_do_url' => '/Update_money/batch_updatemoney_apply','permission' => 1),
        //调账审核
        array('id' => '20204' ,'name' => lang('update_money_check') ,'mod_do_url' => '/Update_money/update_money_check','permission' => 1),
        //批量调账审核
        array('id' => '20205' ,'name' => lang('batch_update_money_check') ,'mod_do_url' => '/Update_money/batch_updatemoney_check','permission' => 0),
        //批量调账检测（主要是调账为负值时，检测账户有足够余额）
        array('id' => '20206' ,'name' => lang('test_batch_enough_money') ,'mod_do_url' => '/Update_money/test_batch_enough_money','permission' => 0),
    ),


     //活动解锁
    'account-activityUnlock'=>array(
        array('id' => '20114' ,'name' => lang('activity_unlock') ,'mod_do_url' => '/Zjys_activity/activity_unlock','permission' => 1),
        array('id' => '20115' ,'name' => lang('batch_activity_file') ,'mod_do_url' => '/Zjys_activity/batch_activity_file','permission' => 1),
        array('id' => '20116' ,'name' => lang('batch_activity_unlock') ,'mod_do_url' => '/Zjys_activity/batch_activity_unlock','permission' => 1),
        array('id' => '20117' ,'name' => lang('activity_unlock_list') ,'mod_do_url' => '/Zjys_activity/activity_unlock_list','permission' => 1),
        array('id' => '20118' ,'name' => lang('activity_unlock_list_csv') ,'mod_do_url' => '/Zjys_activity/activity_unlock_list_csv','permission' => 1),
        array('id' => '20124' ,'name' => lang('activity_unlock_sample_csv') ,'mod_do_url' => '/Zjys_activity/activity_unlock_sample_csv','permission' => 0),
    ),

    'account-lockPositionList'=>array(
        //锁仓记录
        array('id' => '30098' ,'name' => lang('jys_lockposition_list') ,'mod_do_url' => '/zjys_user/lockposition_list','permission' => 1),
        //锁仓记录删除（暂未使用）
        array('id' => '30100' ,'name' => lang('jys_lockposition_delete') ,'mod_do_url' => '/zjys_user/lockposition_delete','permission' => 0),
        //锁仓审核
        array('id' => '30222' ,'name' => lang('jys_lockposition_check') ,'mod_do_url' => '/lock_position/lockposition_check_first','permission' => 1),
        //解仓审核
        array('id' => '30223' ,'name' => lang('jys_unlockposition_check') ,'mod_do_url' => '/lock_position/lockposition_check_second','permission' => 1),
        //增加锁仓
        array('id' => '30099' ,'name' => lang('jys_lockposition_add') ,'mod_do_url' => '/zjys_user/lockposition_add','permission' => 1),
        //手动解仓
        array('id' => '30101' ,'name' => lang('jys_unlockposition') ,'mod_do_url' => '/zjys_user/unlockposition','permission' => 1),

    ),



    'workorders-manage' =>array(
        array('id' => '40100' ,'name' => lang('workorders_list') ,'mod_do_url' => '/ticket/ticket_list','permission' => 1),//工单列表
        array('id' => '40101' ,'name' => lang('workorders_reply') ,'mod_do_url' => '/ticket/ticket_message_reply','permission' => 1),
        // array('id' => '40102' ,'name' => lang('workorders_delete') ,'mod_do_url' => '/ticket/ticket_delete','permission' => 0),
        array('id' => '40104' ,'name' => lang('workorders_close') ,'mod_do_url' => '/ticket/ticket_close','permission' => 1),
        array('id' => '40103' ,'name' => lang('workorders_reply_list') ,'mod_do_url' => '/ticket/ticket_reply_list','permission' => 1),
    ),

    //    数据可视化
          'data-visualization' =>array(
           array('id' => '20071' ,'name' => lang('real_draw') ,'mod_do_url' => '/Data_visualization/real_draw','permission' => 0),
          array('id' => '20072' ,'name' => lang('real_data') ,'mod_do_url' => '/Data_visualization/real_data','permission' => 0),
           array('id' => '20073' ,'name' => lang('user_data') ,'mod_do_url' => '/Data_visualization/user_data','permission' => 1),
           array('id' => '20076' ,'name' => lang('user_data_draw') ,'mod_do_url' => '/Data_visualization/user_data_draw','permission' => 1),
           array('id' => '20078' ,'name' => lang('trade_data') ,'mod_do_url' => '/Data_visualization/trade_data','permission' => 1),
           array('id' => '20079' ,'name' => lang('trade_data_draw') ,'mod_do_url' => '/Data_visualization/trade_data_draw','permission' => 1),
           array('id' => '20080' ,'name' => lang('trade_fee_data') ,'mod_do_url' => '/Data_visualization/trade_fee_data','permission' => 1),
           array('id' => '20081' ,'name' => lang('trade_fee_data_draw') ,'mod_do_url' => '/Data_visualization/trade_fee_data_draw','permission' => 1),
           array('id' => '20082' ,'name' => lang('trade_money_rank') ,'mod_do_url' => '/Data_visualization/trade_money_rank','permission' => 1),
           array('id' => '20083' ,'name' => lang('trade_c2c_data') ,'mod_do_url' => '/Data_visualization/trade_c2c_data','permission' => 1),
           array('id' => '20084' ,'name' => lang('trade_c2c_data_draw') ,'mod_do_url' => '/Data_visualization/trade_c2c_data_draw','permission' => 1),
           array('id' => '20085' ,'name' => lang('withdraws_coin_rank') ,'mod_do_url' => '/Data_visualization/withdraws_coin_rank','permission' => 1),
           array('id' => '20086' ,'name' => lang('recharge_coin_rank') ,'mod_do_url' => '/Data_visualization/recharge_coin_rank','permission' => 1),
           array('id' => '20087' ,'name' => lang('coin_details_data') ,'mod_do_url' => '/Data_visualization/coin_details_data','permission' => 1),
           array('id' => '20088' ,'name' => lang('coin_details_fee_data') ,'mod_do_url' => '/Data_visualization/coin_details_fee_data','permission' => 1),
           array('id' => '20089' ,'name' => lang('coin_details_trade_draw') ,'mod_do_url' => '/Data_visualization/coin_details_trade_draw','permission' => 1),
           array('id' => '20090' ,'name' => lang('coin_details_fee_draw') ,'mod_do_url' => '/Data_visualization/coin_details_fee_draw','permission' => 1),
           array('id' => '20091' ,'name' => lang('coin_recharge_withdraws_data') ,'mod_do_url' => '/Data_visualization/coin_recharge_withdraws_data','permission' => 1),
           array('id' => '20092' ,'name' => lang('coin_recharge_withdraws_draw') ,'mod_do_url' => '/Data_visualization/coin_recharge_withdraws_draw','permission' => 1),
           array('id' => '20093' ,'name' => lang('trade_order_rank') ,'mod_do_url' => '/Data_visualization/trade_order_rank','permission' => 1),
           array('id' => '20094' ,'name' => lang('trade_user_rank') ,'mod_do_url' => '/Data_visualization/trade_user_rank','permission' => 1),
           array('id' => '20095' ,'name' => lang('asset_symbols') ,'mod_do_url' => '/Data_visualization/asset_symbols','permission' => 1),
           array('id' => '20099' ,'name' => lang('site_asset') ,'mod_do_url' => '/Data_visualization/site_asset','permission' => 1),
           array('id' => '20102' ,'name' => lang('wait_review') ,'mod_do_url' => '/Data_visualization/wait_review','permission' => 1),
       ),


    //OTC
    'otc-InOut' =>array(
        array('id' => '20103' ,'name' => lang('otc_inout') ,'mod_do_url' => '/OTC_order/inout','permission' => 1),
        array('id' => '20105' ,'name' => lang('inout_printexcel') ,'mod_do_url' => '/OTC_order/inout_printexcel','permission' => 1),
        array('id' => '20106' ,'name' => lang('otc_verify_first') ,'mod_do_url' => '/OTC_order/otc_verify_first','permission' => 1),
        array('id' => '20112' ,'name' => lang('c2c_verify') ,'mod_do_url' => '/OTC_order/c2c_verify','permission' => 1),

    ),
    'otc-merchantAccount' =>array(
        array('id' => '20104' ,'name' => lang('merchant_account_list') ,'mod_do_url' => '/Merchant_account/merchantaccount_list','permission' => 1),
        array('id' => '20107' ,'name' => lang('merchant_account_add_edit') ,'mod_do_url' => '/Merchant_account/addbank','permission' => 1),
        array('id' => '20108' ,'name' => lang('merchant_account_delete') ,'mod_do_url' => '/Merchant_account/deletebank','permission' => 1),
        array('id' => '20109' ,'name' => lang('otc_inout_add_edit') ,'mod_do_url' => '/Merchant_account/add_merbank_inout_flows','permission' => 1),
        array('id' => '20110' ,'name' => lang('otc_inout_list') ,'mod_do_url' => '/Merchant_account/add_merbank_inout_list','permission' => 1),
        array('id' => '20111' ,'name' => lang('otc_inout_list_csv') ,'mod_do_url' => '/Merchant_account/add_merbank_inout_list_printexcel','permission' => 1),
        array('id' => '20119' ,'name' => lang('sort_value') ,'mod_do_url' => '/Merchant_account/sort_value','permission' => 0),
        array('id' => '20120' ,'name' => lang('mer_sort') ,'mod_do_url' => '/Merchant_account/mer_sort','permission' => 0),
        array('id' => '20121' ,'name' => lang('modify_trade_count') ,'mod_do_url' => '/Merchant_account/modify_trade_count','permission' => 1),
        array('id' => '20122' ,'name' => lang('modify_sort') ,'mod_do_url' => '/Merchant_account/modify_sort','permission' => 1),
    ),
    'otc-user' =>array(
        array('id' => '20113' ,'name' => lang('otc_user_account') ,'mod_do_url' => '/OTC_order/otc_user_account','permission' => 1),
    ),


    'knowledge-base' =>array(
        array('id' => '20156' ,'name' => lang('knowledge_base_list') ,'mod_do_url' => '/Knowledge_base/knowledge_base_list','permission' => 1),
        array('id' => '20157' ,'name' => lang('knowledge_base_add') ,'mod_do_url' => '/Knowledge_base/knowledge_base_add','permission' => 1),
        array('id' => '20158' ,'name' => lang('knowledge_base_delete') ,'mod_do_url' => '/Knowledge_base/knowledge_base_delete','permission' => 1),
    ),

    'operation-push' =>array(
        array('id' => '20166' ,'name' => lang('push_list') ,'mod_do_url' => '/push/push_list','permission' => 1),
        array('id' => '20167' ,'name' => lang('push_add') ,'mod_do_url' => '/push/push_add','permission' => 1),
        array('id' => '20168' ,'name' => lang('push_delete') ,'mod_do_url' => '/push/push_delete','permission' => 1),
        array('id' => '20169' ,'name' => lang('push') ,'mod_do_url' => '/push/push','permission' => 1),
    ),


//    'otc-foreignTransfers' =>array(
//        array('id' => '20129' ,'name' => lang('foreign_otc_transfers') ,'mod_do_url' => '/OTC_order/foreign_otc_transfers','permission' => 1),
//        array('id' => '20130' ,'name' => lang('foreign_otc_transfers_export') ,'mod_do_url' => '/OTC_order/foreign_otc_transfers_export','permission' => 1),
//    ),
//
//    'otc-assets' =>array(
//        array('id' => '20132' ,'name' => lang('update_otc_assets') ,'mod_do_url' => '/OTC_order/update_otc_assets','permission' => 1),
//    ),


);
