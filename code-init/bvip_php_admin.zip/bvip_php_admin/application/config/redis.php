<?php

$config['socket_type'] = 'tcp';
$config['host'] = '127.0.0.1';
$config['password'] = NULL;
$config['port'] = 6380;
$config['timeout'] = 0;

?>
