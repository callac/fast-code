<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//name 模块介绍 /mod_do_url 接口地址 / permission=0 过滤掉的权限
//总站权限列表
$admin_menu_file = array(
    //子站管理
    // 'site' =>array(
    //     // //站点列表（包括子站）
    //     // array('id' => '30034' ,'name' => lang('jys_subsite_list') ,'mod_do_url' => '/site/get_list','permission' => 1),
    //     //添加/编辑子站超管用户
    //     array('id' => '30049' ,'name' => lang('jys_subsite_addsadmin') ,'mod_do_url' => '/admin/subadmin_update','permission' => 1),
    //     //子站超管列表
    //     array('id' => '30050' ,'name' => lang('jys_subsite_sadminlist') ,'mod_do_url' => '/admin/subadmin_list','permission' => 1),
    //     //子站用户统计
    //     array('id' => '30035' ,'name' => lang('jys_subsite_user_statistics') ,'mod_do_url' => '/site/sub_user_statistics','permission' => 1),
    //     //子站交易统计
    //     array('id' => '30036' ,'name' => lang('jys_subsite_trade_statistics') ,'mod_do_url' => '/site/sub_trade_statistics','permission' => 1),

    //     array('id' => '10001' ,'name' => lang('site_a') ,'mod_do_url' => '/site/get_site_base','permission' => 0),
    //     array('id' => '10002' ,'name' => lang('site_b') ,'mod_do_url' => '/site/add','permission' => 1),
    //     array('id' => '10003' ,'name' => lang('site_c') ,'mod_do_url' => '/site/get_list','permission' => 1),
    //     array('id' => '10004' ,'name' => lang('site_d') ,'mod_do_url' => '/site/update','permission' => 1),
    //     array('id' => '10005' ,'name' => lang('site_e') ,'mod_do_url' => '/site/domain_add','permission' => 0),
    //     array('id' => '10006' ,'name' => lang('site_f') ,'mod_do_url' => '/site/domain_update','permission' => 0),
    //     array('id' => '10007' ,'name' => lang('site_g') ,'mod_do_url' => '/site/domain_delete','permission' => 0),
    //     array('id' => '10008' ,'name' => lang('site_h') ,'mod_do_url' => '/site/site_info','permission' => 0),
    // ),


    // //用户管理
    // 'user' =>array(
    //     //用户列表接口
    //     array('id' => '30001' ,'name' => lang('jys_user_list') ,'mod_do_url' => '/zjys_user/get_list','permission' => 1),
    //     //提币地址列表
    //     array('id' => '30007' ,'name' => lang('jys_withdraw_address_list') ,'mod_do_url' => '/zjys_withdraw/withdraw_address_list','permission' => 1),
    //     //解冻ip
    //     array('id' => '30026' ,'name' => lang('jys_unfreezeip') ,'mod_do_url' => '/zjys_trade/unfreezeip','permission' => 1),
    //      //用户认证信息列表
    //     array('id' => '30046' ,'name' => lang('jys_user_identity') ,'mod_do_url' => '/zjys_user/user_identity_list','permission' => 1),
    //     //银行卡信息
    //     // array('id' => '30047' ,'name' => lang('jys_userbank_list') ,'mod_do_url' => '/site/sub_trade_statistics','permission' => 1),
    //     //充值地址列表
    //     array('id' => '30048' ,'name' => lang('jys_recharge_address_list') ,'mod_do_url' => '/zjys_recharge/recharge_address_list','permission' => 1),
    //     //安全信息
    //     array('id' => '30051' ,'name' => lang('jys_user_safeinfo') ,'mod_do_url' => '/zjys_user/user_safeinfo_list','permission' => 1),
    //     //充值谷歌验证器（two_step_bound）
    //     array('id' => '30052' ,'name' => lang('jys_user_reset_two_step') ,'mod_do_url' => '/zjys_user/reset_google_verify','permission' => 1),
        
    //     // array('id' => '30052' ,'name' => lang('jys_user_reset_two_step') ,'mod_do_url' => '/zjys_user/reset_google_verify','permission' => 1),
    //     //添加vip账户
    //     array('id' => '30056' ,'name' => lang('jys_vip_adduser') ,'mod_do_url' => '/zjys_user/vip_adduser','permission' => 1),

    //     array('id' => '30057' ,'name' => lang('jys_user_forbidden_login') ,'mod_do_url' => '/zjys_user/forbid_login','permission' => 1),
       
    //     array('id' => '30058' ,'name' => lang('jys_user_forbidden_withdraw') ,'mod_do_url' => '/zjys_user/forbid_withdraw','permission' => 1),
        
    //     array('id' => '30059' ,'name' => lang('jys_user_forbidden_trade') ,'mod_do_url' => '/zjys_user/forbid_trade','permission' => 1),
    //     //用户详情
    //     array('id' => '30061' ,'name' => lang('jys_user_get_info') ,'mod_do_url' => '/zjys_user/get_info','permission' => 1),
    //     //用户提币地址
    //     array('id' => '30062' ,'name' => lang('jys_withdraw_address_user_list') ,'mod_do_url' => '/zjys_user/user_withdraw_address_list','permission' => 1),
    //     //用户提币记录
    //     array('id' => '30063' ,'name' => lang('jys_withdraw_address_user_logs') ,'mod_do_url' => '/zjys_user/user_withdraw_address_logs','permission' => 1),
    //     //用户充币地址
    //     array('id' => '30064' ,'name' => lang('jys_recharge_address_user_list') ,'mod_do_url' => '/zjys_user/user_recharge_address_list','permission' => 1),
    //     //用户充值记录
    //     array('id' => '30065' ,'name' => lang('jys_recharge_address_user_logs') ,'mod_do_url' => '/zjys_user/user_recharge_address_logs','permission' => 1),
    //     //单个用户银行卡列表
    //     array('id' => '30066' ,'name' => lang('jys_get_userbank') ,'mod_do_url' => '/zjys_user/get_bank_list','permission' => 1),
        
    //     array('id' => '30098' ,'name' => lang('jys_lockposition_list') ,'mod_do_url' => '/zjys_user/lockposition_list','permission' => 1),
        
    //     array('id' => '30100' ,'name' => lang('jys_lockposition_delete') ,'mod_do_url' => '/zjys_user/lockposition_delete','permission' => 1),
        
    // ),

    // //资产管理
    // 'property' =>array(
    //     //充值记录列表
    //     array('id' => '30002' ,'name' => lang('jys_recharge_log_list') ,'mod_do_url' => '/zjys_recharge/recharge_list','permission' => 1),
    //     //提现记录
    //     array('id' => '30003' ,'name' => lang('jys_withdraw_list') ,'mod_do_url' => '/zjys_withdraw/withdraw_list','permission' => 1),
    //     //提币审核(审核中->处理中)
    //     array('id' => '30005' ,'name' => lang('jys_withdraw_verify') ,'mod_do_url' => '/zjys_withdraw/withdraw_verify','permission' => 1),
    //     //提币再次审核（处理中->完成）
    //     array('id' => '30006' ,'name' => lang('jys_withdraw_sure_verify') ,'mod_do_url' => '/zjys_withdraw/withdraw_sure_verify','permission' => 1),
    //     //币资产管理-》币资产列表
    //     array('id' => '30008' ,'name' => lang('jys_asset_list') ,'mod_do_url' => '/zjys_assets/asset_list','permission' => 1),
    //     //获取总站所有币种
    //     array('id' => '30037' ,'name' => lang('jys_asset_list_totalsite') ,'mod_do_url' => '/zjys_assets/asset_list_totalsite','permission' => 0),
    //     //获取总站交易对
    //     array('id' => '30038' ,'name' => lang('jys_symbol_list_totalsite') ,'mod_do_url' => '/zjys_symbols/symbol_list_totalsite','permission' => 0),
    //     //增加资产种类
    //     array('id' => '30009' ,'name' => lang('jys_add_asset') ,'mod_do_url' => '/zjys_assets/add_asset','permission' => 1),
    //     //更改用户资金
    //     array('id' => '30010' ,'name' => lang('jys_edit_updateusermoney') ,'mod_do_url' => '/zjys_trade/updateusermoney','permission' => 1),
    //     array('id' => '30083' ,'name' => lang('jys_admin_unfreeze_asset') ,'mod_do_url' => '/zjys_c2corder/admin_unfreeze_asset','permission' => 1),
    //     //币资产管理-》交易对列表
    //     array('id' => '30011' ,'name' => lang('jys_symbol_list') ,'mod_do_url' => '/zjys_symbols/symbol_list','permission' => 1),
    //     //增加交易对
    //     array('id' => '30012' ,'name' => lang('jys_add_symbol') ,'mod_do_url' => '/zjys_symbols/add_symbol','permission' => 1),
    //     //ajax实时查询网站相关信息
    //     array('id' => '30045' ,'name' => lang('jys_list_ajaxsearch') ,'mod_do_url' => '/site/ajaxsearch','permission' => 0),
    //     //用户总资产（换算成人名币）
    //     array('id' => '30013' ,'name' => lang('jys_user_totalassets') ,'mod_do_url' => '/zjys_trade/user_totalassets','permission' => 1),
    //     //用户资产详情
    //     array('id' => '30014' ,'name' => lang('jys_user_assetsdetail') ,'mod_do_url' => '/zjys_trade/user_assetsdetail','permission' => 1),
    //     //用户资产流水
    //     array('id' => '30015' ,'name' => lang('jys_user_assetsflow') ,'mod_do_url' => '/zjys_trade/user_assetsflow','permission' => 1),
    //    //用户成交记录
    //     array('id' => '30016' ,'name' => lang('jys_user_dealrecords') ,'mod_do_url' => '/zjys_trade/user_dealrecords','permission' => 1),
    //    //用户委托记录
    //     array('id' => '30017' ,'name' => lang('jys_user_entrustedrecords') ,'mod_do_url' => '/zjys_trade/user_entrustedrecords','permission' => 1),
    //     //不同交易市场的交易量排行（用户）
    //     // array('id' => '30031' ,'name' => lang('jys_trade_totalcount') ,'mod_do_url' => '/zjys_trade/totalcount','permission' => 1),
    //     //不同交易市场的交易手续费排行（用户）
    //     // array('id' => '30032' ,'name' => lang('jys_trade_totalfee') ,'mod_do_url' => '/zjys_trade/totalfee','permission' => 1),
    //     //资金调整记录列表
    //     array('id' => '30054' ,'name' => lang('jys_user_correctassetitem') ,'mod_do_url' => '/zjys_trade/user_correctassetitem','permission' => 1),
        
    //     array('id' => '40001' ,'name' => lang('zjys_print_user_assets') ,'mod_do_url' => '/zjys_trade/print_user_assets','permission' => 1),
    //     array('id' => '30079' ,'name' => lang('jys_withdraw_printexcel') ,'mod_do_url' => '/zjys_withdraw/withdraw_list_printexcel','permission' => 1),
    //     array('id' => '30080' ,'name' => lang('jys_recharge_printexcel') ,'mod_do_url' => '/zjys_recharge/recharge_list_printexcel','permission' => 1),
        
    //     array('id' => '30099' ,'name' => lang('jys_lockposition_add') ,'mod_do_url' => '/zjys_user/lockposition_add','permission' => 1),
    
    //     array('id' => '30098' ,'name' => lang('jys_lockposition_list') ,'mod_do_url' => '/zjys_user/lockposition_list','permission' => 1),
        
    //     array('id' => '30100' ,'name' => lang('jys_lockposition_delete') ,'mod_do_url' => '/zjys_user/lockposition_delete','permission' => 1),
    //     array('id' => '30101' ,'name' => lang('jys_unlockposition') ,'mod_do_url' => '/zjys_user/unlockposition','permission' => 1),
        

    //     //站群 系统交易对配置
    //     array('id' => '30120' ,'name' => lang('jys_sys_asset_list') ,'mod_do_url' => '/zjys_assets/system_asset_list','permission' => 0),
    //     array('id' => '30121' ,'name' => lang('jys_sys_asset_add') ,'mod_do_url' => '/zjys_assets/system_asset_add','permission' => 0),
    //     array('id' => '30122' ,'name' => lang('jys_sys_asset_delete') ,'mod_do_url' => '/zjys_assets/system_asset_delete','permission' => 0),
        
    //     array('id' => '30123' ,'name' => lang('jys_sys_symbol_list') ,'mod_do_url' => '/zjys_symbols/system_symbol_list','permission' => 0),
    //     array('id' => '30124' ,'name' => lang('jys_sys_symbol_add') ,'mod_do_url' => '/zjys_symbols/system_symbol_add','permission' => 0),
    //     array('id' => '30125' ,'name' => lang('jys_sys_symbol_delete') ,'mod_do_url' => '/zjys_symbols/system_symbol_delete','permission' => 0),
    // ),

    // //C2C交易
    // 'c2c' =>array(
    //     //银行卡列表
    //     array('id' => '30018' ,'name' => lang('jys_merchantbank_list') ,'mod_do_url' => '/zjys_merchantbank/merchantbank_list','permission' => 1),
    //     //银行卡新增与编辑
    //     array('id' => '30019' ,'name' => lang('jys_merchantbank_add') ,'mod_do_url' => '/zjys_merchantbank/addbank','permission' => 1),
    //     //后台法币买入卖出列表
    //     array('id' => '30020' ,'name' => lang('jys_c2c_inout') ,'mod_do_url' => '/zjys_c2corder/inout','permission' => 1),
    //     //后台法币买入卖出审核
    //     array('id' => '30021' ,'name' => lang('jys_c2c_verify') ,'mod_do_url' => '/zjys_c2corder/c2c_verify','permission' => 1),
    //     // 买入卖出初次审核
    //     array('id' => '30089' ,'name' => lang('jys_c2c_verify_first') ,'mod_do_url' => '/zjys_c2corder/c2c_verify_first','permission' => 1),
    //     //后台用户银行卡列表
    //     array('id' => '30022' ,'name' => lang('jys_userbank_list') ,'mod_do_url' => '/zjys_userbank/userbank_list','permission' => 0),
    //     //银行卡禁用
    //     array('id' => '30024' ,'name' => lang('jys_merchantbank') ,'mod_do_url' => '/zjys_merchantbank/deletebank','permission' => 1),
    //     //审核详情
    //     array('id' => '30067' ,'name' => lang('jys_check_detail') ,'mod_do_url' => '/zjys_user/check_detail','permission' => 0),
        
    //     array('id' => '30084' ,'name' => lang('jys_add_admin_merbank_inout_flows') ,'mod_do_url' => '/zjys_merchantbank/add_merbank_inout_flows','permission' => 1),
        
    //     array('id' => '30085' ,'name' => lang('jys_add_admin_merbank_inout_list') ,'mod_do_url' => '/zjys_merchantbank/add_merbank_inout_list','permission' => 1),

    //     array('id' => '30078' ,'name' => lang('jys_c2c_printexcel') ,'mod_do_url' => '/zjys_c2corder/inout_printexcel','permission' => 1),
    //     //平台卡收支明细
    //     array('id' => '30087' ,'name' => lang('jys_merchant_inout_list_printexcel') ,'mod_do_url' => '/zjys_merchantbank/add_merbank_inout_list_printexcel','permission' => 1),
     
    // ),



    // 'order' =>array(
    //     //成交记录
    //     array('id' => '30081' ,'name' => lang('jys_get_platform_deal') ,'mod_do_url' => '/zjys_trade/platform_deal_detail','permission' => 1),
    //     //委托记录
    //     array('id' => '30082' ,'name' => lang('jys_get_platform_order') ,'mod_do_url' => '/zjys_trade/platform_order_detail','permission' => 1),
    // ),



    // //活动管理
    // 'activity' =>array(
    //     //获取活动详情
    //     array('id' => '30027' ,'name' => lang('jys_activity_info') ,'mod_do_url' => '/zjys_activity/get_info','permission' => 1),
    //     //活动列表
    //     array('id' => '30028' ,'name' => lang('jys_activity_list') ,'mod_do_url' => '/zjys_activity/activity_list','permission' => 1),
    //     //添加活动
    //     array('id' => '30029' ,'name' => lang('jys_activity_add') ,'mod_do_url' => '/zjys_activity/add_activity','permission' => 1),
    //     //删除活动
    //     array('id' => '30030' ,'name' => lang('jys_activity_delete') ,'mod_do_url' => '/zjys_activity/delete','permission' => 1),
        
    //     array('id' => '30105' ,'name' => lang('jys_activityholding_list') ,'mod_do_url' => '/config/activityholdinglist','permission' => 1),
    //     array('id' => '30106' ,'name' => lang('jys_activityholding_add') ,'mod_do_url' => '/config/activityholdingadd','permission' => 1),
    //     array('id' => '30107' ,'name' => lang('jys_activityholding_delete') ,'mod_do_url' => '/config/activityholdingdelete','permission' => 1),
    //     array('id' => '30108' ,'name' => lang('jys_activityholdingaward_list') ,'mod_do_url' => '/config/activityholdingawardlist','permission' => 1),
    //     array('id' => '30109' ,'name' => lang('jys_user_lottery_logs') ,'mod_do_url' => '/config/user_lottery_logs','permission' => 1),

    //     array('id' => '30118' ,'name' => lang('jys_user_treasure_logs') ,'mod_do_url' => '/config/user_treasure_logs','permission' => 1),
    //     array('id' => '30119' ,'name' => lang('jys_treasure_sessions') ,'mod_do_url' => '/config/treasure_sessions','permission' => 1),
        
    //     // array('id' => '30121' ,'name' => lang('jys_activity_treasurelist') ,'mod_do_url' => '/zjys_activity/treasure_activity_list','permission' => 1),
    //     // array('id' => '30122' ,'name' => lang('jys_activity_treasureadd') ,'mod_do_url' => '/zjys_activity/treasure_activity_add','permission' => 1),
    //     // array('id' => '30123' ,'name' => lang('jys_activity_treasuredelete') ,'mod_do_url' => '/zjys_activity/treasure_activity_delete','permission' => 1),
    //     // array('id' => '30124' ,'name' => lang('jys_activity_treasurenext') ,'mod_do_url' => '/zjys_activity/treasure_activity_next','permission' => 1),
    //     // array('id' => '30125' ,'name' => lang('jys_activity_treasureend') ,'mod_do_url' => '/zjys_activity/treasure_activity_end','permission' => 1),
    //     // array('id' => '30126' ,'name' => lang('jys_activity_treasure_session_list') ,'mod_do_url' => '/zjys_activity/treasure_session_activity_list','permission' => 1),
    //     // array('id' => '30127' ,'name' => lang('jys_activity_treasure_logs_list') ,'mod_do_url' => '/zjys_activity/treasure_logs_activity_list','permission' => 1),
        
    // ),

    // //权限控制
    // 'authority' =>array(
    //     //保全管理
    //     array('id' => '13001' ,'name' => lang('roles_a') ,'mod_do_url' => '/admin/roles_list','permission' => 1),
    //     array('id' => '13002' ,'name' => lang('roles_b') ,'mod_do_url' => '/admin/roles_update','permission' => 1),
    //     array('id' => '13003' ,'name' => lang('roles_c') ,'mod_do_url' => '/admin/roles_base','permission' => 1),
    //     array('id' => '13004' ,'name' => lang('roles_d') ,'mod_do_url' => '/admin/admin_list','permission' => 1),
    //     array('id' => '13005' ,'name' => lang('roles_e') ,'mod_do_url' => '/admin/admin_lock','permission' => 1),
    //     array('id' => '13006' ,'name' => lang('roles_f') ,'mod_do_url' => '/admin/admin_update','permission' => 1),
    //     array('id' => '13007' ,'name' => lang('roles_g') ,'mod_do_url' => '/admin/admin_delete','permission' => 1),
    //     array('id' => '13008' ,'name' => lang('roles_h') ,'mod_do_url' => '/admin/login','permission' => 0),
    //     array('id' => '13009' ,'name' => lang('roles_i') ,'mod_do_url' => '/admin/update_password','permission' => 1),
    //     array('id' => '13011' ,'name' => lang('roles_j') ,'mod_do_url' => '/admin/update_priv','permission' => 0),
    //     array('id' => '13012' ,'name' => lang('roles_k') ,'mod_do_url' => '/admin/get_roles_by_site','permission' => 0),
    //     array('id' => '13013' ,'name' => lang('roles_l') ,'mod_do_url' => '/admin/roles_delete','permission' => 1),
    //     array('id' => '8010' ,'name' => lang('account_j') ,'mod_do_url' => '/admin/quit','permission' => 0),
    // ),

    // //网站管理
    // 'operation' =>array(
    //     //网站配置
    //     array('id' => '9004' ,'name' => lang('operation_a') ,'mod_do_url' => '/config/newsUpdate','permission' => 1),
    //     array('id' => '9005' ,'name' => lang('operation_b') ,'mod_do_url' => '/config/news','permission' => 1),
    //     array('id' => '9006' ,'name' => lang('operation_c') ,'mod_do_url' => '/config/newsDelete','permission' => 1),
    //     array('id' => '9007' ,'name' => lang('operation_d') ,'mod_do_url' => '/config/newsAdd','permission' => 1),

    //     array('id' => '9012' ,'name' => lang('operation_h') ,'mod_do_url' => '/config/help_list','permission' => 1),
    //     array('id' => '9013' ,'name' => lang('operation_i') ,'mod_do_url' => '/config/help_delete','permission' => 1),
    //     array('id' => '9014' ,'name' => lang('operation_j') ,'mod_do_url' => '/config/help_update','permission' => 1),
    //     array('id' => '9015' ,'name' => lang('operation_k') ,'mod_do_url' => '/config/help_class','permission' => 1),
    //     array('id' => '9016' ,'name' => lang('operation_kadd') ,'mod_do_url' => '/config/help_class_add','permission' => 1),//
    //     array('id' => '9017' ,'name' => lang('operation_kdelete') ,'mod_do_url' => '/config/help_class_delete','permission' => 1),

    //     array('id' => '9019' ,'name' => lang('operation_l') ,'mod_do_url' => '/config/banner_friend_list','permission' => 1),
    //     array('id' => '9021' ,'name' => lang('operation_m') ,'mod_do_url' => '/config/banner_friend_delete','permission' => 1),
    //     array('id' => '9022' ,'name' => lang('operation_n') ,'mod_do_url' => '/config/banner_update','permission' => 1),
        
    //     array('id' => '9024' ,'name' => lang('config_g') ,'mod_do_url' => '/config/news_class','permission' => 1),
    //     array('id' => '9025' ,'name' => lang('config_k') ,'mod_do_url' => '/config/news_class_delete','permission' => 1),
    //     array('id' => '9026' ,'name' => lang('config_l') ,'mod_do_url' => '/config/news_class_update','permission' => 1),

    //     array('id' => '30039' ,'name' => lang('config_agreement_update') ,'mod_do_url' => '/config/agreement_update','permission' => 1),
    //     array('id' => '30040' ,'name' => lang('config_agreement_list') ,'mod_do_url' => '/config/agreement_list','permission' => 1),
    //     array('id' => '30041' ,'name' => lang('config_agreement_delete') ,'mod_do_url' => '/config/agreement_delete','permission' => 1),
    //     array('id' => '30042' ,'name' => lang('config_friendlink_update') ,'mod_do_url' => '/config/friendlink_update','permission' => 1),
    //     array('id' => '30043' ,'name' => lang('config_friendlink_list') ,'mod_do_url' => '/config/friendlink_list','permission' => 1),
    //     array('id' => '30044' ,'name' => lang('config_friendlink_delete') ,'mod_do_url' => '/config/friendlink_delete','permission' => 1),

    //     array('id' => '30102' ,'name' => lang('config_labelconfiglist') ,'mod_do_url' => '/config/labelconfiglist','permission' => 1),
    //     array('id' => '30103' ,'name' => lang('config_labelconfigadd') ,'mod_do_url' => '/config/labelconfigadd','permission' => 1),
    //     array('id' => '30104' ,'name' => lang('config_labelconfigdelete') ,'mod_do_url' => '/config/labelconfigdelete','permission' => 1),
    // ),

    // 'other' =>array(
    //     array('id' => '30033' ,'name' => lang('jys_upload_img') ,'mod_do_url' => '/file/upload','permission' => 0),
    // ),

    // 'statistics' =>array(
    //     array('id' => '30070' ,'name' => lang('jys_get_intotal') ,'mod_do_url' => '/zjys_trade/in_total','permission' => 1),
        
    //     array('id' => '30072' ,'name' => lang('jys_total_c2c') ,'mod_do_url' => '/zjys_trade/get_type_one','permission' => 0),
    //     //站点币种资产相关统计
    //     array('id' => '30060' ,'name' => lang('jys_timetask_totalsiteassets') ,'mod_do_url' => '/zjys_trade/get_site_totalassets','permission' => 0),
    //     //获取平台币种的交易冻结
    //     array('id' => '30073' ,'name' => lang('jys_get_trade_freeze') ,'mod_do_url' => '/zjys_trade/get_trade_freeze','permission' => 0),
    //     //获取c2c冻结
    //     array('id' => '30074' ,'name' => lang('jys_get_c2cwithdraw_freeze') ,'mod_do_url' => '/zjys_trade/get_c2c_freeze','permission' => 0),
    //     //统计站点用户数据
    //     array('id' => '30086' ,'name' => lang('jys_user_statistics') ,'mod_do_url' => '/zjys_user/statistics_users','permission' => 1),
        
    //     array('id' => '30088' ,'name' => lang('jys_statistics_users_printexcel') ,'mod_do_url' => '/zjys_user/statistics_users_printexcel','permission' => 1),

    //     array('id' => '30090' ,'name' => lang('jys_statistics_c2c_inout') ,'mod_do_url' => '/zjys_merchantbank/statistics_c2c_inout','permission' => 1),

    //     array('id' => '30091' ,'name' => lang('jys_statistics_c2c_inout_printexcel') ,'mod_do_url' => '/zjys_merchantbank/statistics_c2c_inout_printexcel','permission' => 1),
        
    //     array('id' => '30092' ,'name' => lang('jys_get_trade_statistic') ,'mod_do_url' => '/zjys_trade/get_trade_statistic','permission' => 1),

    //     array('id' => '30093' ,'name' => lang('jys_get_trade_statistic_print') ,'mod_do_url' => '/zjys_trade/get_trade_statistic_printexcel','permission' => 1),
    // ),

    // //统计数据邮件配置
    // 'statistics_mail_config' => array(
    //     array('id' => '30113' ,'name' => lang('jys_statistics_mail_config_list') ,'mod_do_url' => '/config/mailconfiglist','permission' => 0),
    //     array('id' => '30114' ,'name' => lang('jys_statistics_mail_config_add') ,'mod_do_url' => '/config/mailconfigadd','permission' => 0),
    //     array('id' => '30115' ,'name' => lang('jys_statistics_mail_config_delete') ,'mod_do_url' => '/config/mailconfigdelete','permission' => 0),
        
    //     array('id' => '30116' ,'name' => lang('jys_statistics_mail_sent_records') ,'mod_do_url' => '/config/statisticmailsentrecords','permission' => 0),
    //     array('id' => '30117' ,'name' => lang('jys_statistics_mail_content_download') ,'mod_do_url' => '/config/statisticmailcontentdownload','permission' => 0),
        

    // ),
    // // 定时任务
    // 'time_task' => array(
    //     array('id' => '99999' ,'name' => lang('ssssss') ,'mod_do_url' => '/tools/message','permission' => 0),
    //     array('id' => '999991' ,'name' => lang('zjys_get_trade_statistic') ,'mod_do_url' => '/tools/get_trade_statistic','permission' => 0),
    //     array('id' => '999992' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/statistics_users_task','permission' => 0),
    //     array('id' => '999993' ,'name' => lang('zjys_get_trade_statistic') ,'mod_do_url' => '/zjys_trade/print_user_assets1','permission' => 0),
    //     array('id' => '999995' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/unlock_position','permission' => 0),
    //     array('id' => '999996' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/activityholding_cron','permission' => 0),
    //     array('id' => '999997' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/activityholdingaward_cron','permission' => 0),
    //     array('id' => '999998' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/aaa','permission' => 0),
    //     array('id' => '999998' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/tradetotal','permission' => 0),
    //     array('id' => '999998' ,'name' => lang('zjys_statistics_users_task') ,'mod_do_url' => '/tools/usertotal','permission' => 0),

    // ),
    // //系统配置
    // 'system_config' => array(
    //     array('id' => '30110' ,'name' => lang('jys_app_trade_config_list') ,'mod_do_url' => '/config/apptradelist','permission' => 1),
    //     array('id' => '30111' ,'name' => lang('jys_app_trade_config_add') ,'mod_do_url' => '/config/apptradeadd','permission' => 1),
    //     array('id' => '30112' ,'name' => lang('jys_app_trade_config_delete') ,'mod_do_url' => '/config/apptradedelete','permission' => 1),
    //     array('id' => '30095' ,'name' => lang('config_appconfig_list') ,'mod_do_url' => '/config/app_update_list','permission' => 1),
    //     array('id' => '30096' ,'name' => lang('config_appconfig_add') ,'mod_do_url' => '/config/app_update_add','permission' => 1),
    //     array('id' => '30097' ,'name' => lang('config_appconfig_delete') ,'mod_do_url' => '/config/app_update_delete','permission' => 1),
    //     array('id' => '30053' ,'name' => lang('jys_vip_list') ,'mod_do_url' => '/zjys_user/vip_list','permission' => 1),
    //     array('id' => '30068' ,'name' => lang('jys_params_config_c2c') ,'mod_do_url' => '/zjys_c2corder/params_config_c2c','permission' => 1),
    //     array('id' => '30069' ,'name' => lang('jys_params_config_c2c_update') ,'mod_do_url' => '/zjys_c2corder/c2c_config_update','permission' => 1),
    //     array('id' => '30055' ,'name' => lang('jys_vip_edit') ,'mod_do_url' => '/zjys_user/vip_edit','permission' => 1),
        
    // ),
    
    //系统日志记录
    'system_log' => array(
        'system-log'=>array(
            array('id' => '30004' ,'name' => lang('jys_valids_list') ,'mod_do_url' => '/zjys_valids/valids_list','permission' => 1),
        ),
        'system-log2'=>array(
            array('id' => '8004' ,'name' => lang('account_d') ,    'mod_do_url' => '/account/get_logs_list','permission' => 1),
            array('id' => '30075' ,'name' => lang('zjys_wallet_request_logs') ,'mod_do_url' => '/zjys_trade/get_wallet_logs','permission' => 1),
        )
    ),

    'system_log222' => array(
        'system-log3'=>array(
            array('id' => '300045' ,'name' => lang('jys_valids_list') ,'mod_do_url' => '/zjys_valids/valids_list','permission' => 1),
        ),
        'system-log23'=>array(
            array('id' => '80046' ,'name' => lang('account_d') ,    'mod_do_url' => '/account/get_logs_list','permission' => 1),
            array('id' => '300757' ,'name' => lang('zjys_wallet_request_logs') ,'mod_do_url' => '/zjys_trade/get_wallet_logs','permission' => 1),
        )
    ),
        



    
);

