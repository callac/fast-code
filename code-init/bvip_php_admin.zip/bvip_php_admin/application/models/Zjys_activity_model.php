<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_activity_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    //新增活动
    public function add_activity($top_two_award_status,$top_two_award,$top_two_award_asset,$event,$name,$start_time,$end_time,$award,$award_asset,$top_award,$top_award_asset,$top_award_status,$site_id,$created_at,$updated_at,$recharge_asset,$recharge_award_rate,$is_lock,$award_total,$top_award_total,$top_two_award_total){
        return xlink(501204,array($top_two_award_status,$top_two_award,$top_two_award_asset,$event,$name,$start_time,$end_time,$award,$award_asset,$top_award,$top_award_asset,$top_award_status,$site_id,$created_at,$updated_at,$recharge_asset,$recharge_award_rate,$is_lock,$award_total,$top_award_total,$top_two_award_total),0);
    }
    //编辑活动
    public function edit_activity($top_two_award_status,$top_two_award,$top_two_award_asset,$event,$name,$start_time,$end_time,$award,$award_asset,$top_award,$top_award_asset,$top_award_status,$site_id,$updated_at,$id,$recharge_asset,$recharge_award_rate,$is_lock,$award_total,$top_award_total,$top_two_award_total){
        return xlink(501309,array($top_two_award_status,$top_two_award,$top_two_award_asset,$event,$name,$start_time,$end_time,$award,$award_asset,$top_award,$top_award_asset,$top_award_status,$site_id,$updated_at,$id,$recharge_asset,$recharge_award_rate,$is_lock,$award_total,$top_award_total,$top_two_award_total),0);
    }

    //活动详情
    public function get_info($id)
    {
        return xlink(501107,array($id),0);
    }

    //删除
    public function delete($id)
    {
        $time = date('Y-m-d H:i:s',time());
        return xlink(501310,array($id,$time),0);
    }

    public function get_last_detail()
    {
        return xlink(501141,array(),0);
    }

    public function get_detail($id)
    {
        return xlink(501142,array($id),0);
    }

    public function add_treasure_activity($name,$code,$init_method,$total,$pay_per_max,$pay_amount,$pay_asset,$unaward_rule,$award_type,$award,$award_detail,$award_img,$start_time,$end_time,$day_start_time,$day_end_time,$finished,$site_id,$created_at,$updated_at){
        return xlink(501227,array($name,$code,$init_method,$total,$pay_per_max,$pay_amount,$pay_asset,$unaward_rule,$award_type,$award,$award_detail,$award_img,$start_time,$end_time,$day_start_time,$day_end_time,$finished,$site_id,$created_at,$updated_at),0);
    }

    public function edit_treasure_activity($name,$code,$init_method,$total,$pay_per_max,$pay_amount,$pay_asset,$unaward_rule,$award_type,$award,$award_detail,$award_img,$start_time,$end_time,$day_start_time,$day_end_time,$finished,$site_id,$updated_at,$id){
        return xlink(501339,array($name,$code,$init_method,$total,$pay_per_max,$pay_amount,$pay_asset,$unaward_rule,$award_type,$award,$award_detail,$award_img,$start_time,$end_time,$day_start_time,$day_end_time,$finished,$site_id,$updated_at,$id),0);
    }

    public function treasure_activity_end($finished,$id){
        return xlink(501340,array($finished,$id),0);
    }

    public function treasure_activity_delete($is_display,$id){
        return xlink(501341,array($is_display,$id),0);
    }

    public function get_session_detail($session_id)
    {
        return xlink(501143,array($session_id),0);
    }


    public function get_detail_bycode($code)
    {
        return xlink(501144,array($code),0);
    }

    public function get_session_by_code_id($treasure_id,$code)
    {
        return xlink(501145,array($treasure_id,$code),0);
    }

    public function get_treasure_session($session_id,$code)
    {
        return xlink(501146,array($session_id,$code),0);
    }

    public function treasure_status($treasure_id)
    {
        return xlink(501147,array($treasure_id));
    }








}
