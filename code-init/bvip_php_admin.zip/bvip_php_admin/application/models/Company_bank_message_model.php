<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Company_bank_message_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function get_detail_by_site($site_id){
        return xlink('202134',array($site_id),0);
    }
    public function update_company_bank_message($site_id,$subject,$opening_bank,$bankcard_number){
        return xlink('201315',array($site_id,$subject,$opening_bank,$bankcard_number));
    }
    public function add_company_bank_message($site_id,$subject,$opening_bank,$bankcard_number){
        return xlink('203212',array($site_id,$subject,$opening_bank,$bankcard_number));
    }

    



}
