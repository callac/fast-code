<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/1/9
 * Time: 20:18
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Cancel_market_record_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 插入撤销记录
     * User: 张哲
     * Date: 2019/1/10
     * Time: 15:21
     * @param $args
     * @param $operation_admin_id
     * @param $status
     * @return mixed
     */
    public function cancel_market($user,$amount,$market,$ctime,$mtime,$source,$price,$type,$deal_money,$side,$taker_fee,$maker_fee,$left,$deal_stock,$id,$status,$operation_admin_id)
    {
        $time = date('Y-m-d H:i:s',time());
        return xlink(402226, array($user,$amount,$market,$ctime,$mtime,$source,$price,$type,$deal_money,$side,$taker_fee,$maker_fee,$left,$deal_stock,$id,$status,$operation_admin_id,$time), 0);
    }
}