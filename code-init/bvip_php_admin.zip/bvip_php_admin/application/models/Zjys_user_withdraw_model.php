<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_user_withdraw_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //获取提现记录详情
    public function get_withdraw_info($id)
    {
        return xlink(501101, array($id), 0);
    }

    //改变提币状态
    public function update_status($id, $status, $created_at,$description)
    {
        return xlink(501302, array($id, $status, $created_at,$description), 0);
    }

    public function update_remark($id, $created_at,$description)
    {
        return xlink(501395, array($id, $created_at,$description), 0);
    }


    public function get_last_balance($asset, $user_id)
    {
        return xlink(501115, array($asset, $user_id), 0);
    }

    public function get_last_operatings($asset, $user_id)
    {
        return xlink(501156, array($asset, $user_id), 0);
    }

    public function change_lockposition_status($id)
    {
        return xlink(501328, array($id), 0);
    }

    public function add_aseet_fressze($created_at, $updated_at, $user_id, $asset, $amount, $business, $balance, $detail)
    {
        return xlink('501208', array($created_at, $updated_at, $user_id, $asset, $amount, $business, $balance, $detail), 0);
    }


    //统计用户数量
    public function get_count($site_id, $start, $end)
    {
        return xlink(201116, array($site_id, $start, $end), 0, 0);
    }

    //禁止登陆/允许登陆
    public function update_forbid_login($user_id, $type)
    {
        return xlink(201301, array($user_id, $type), 0);
    }

    //禁止交易/允许交易
    public function update_forbid_withdraw($user_id, $type)
    {
        return xlink(201302, array($user_id, $type), 0);
    }

    //禁止提现/允许提现
    public function update_forbid_trade($user_id, $type)
    {
        return xlink(201303, array($user_id, $type), 0);
    }

    //更新用户token信息
    public function update_user_token($user_id, $token)
    {
        return xlink(201316, array($user_id, $token));
    }

    //资金解冻
    public function capital_unfreeze($user_id, $amount)
    {
        return xlink(403309, array($user_id, $amount), 0);
    }

    //提现审核失败资金解冻并还原余额
    public function capital_unfreeze_back_account($user_id, $amount)
    {
        return xlink(403310, array($user_id, $amount), 0);
    }

    //银行卡充值更新余额
    public function update_user_balance($user_id, $balance)
    {
        return xlink(201314, array($user_id, $balance), 0);
    }


    //根据站点获取 所有用户id
    public function get_user_info_by_site($site_id)
    {
        return xlink(201117, array($site_id));
    }

    //根據手機號獲取用戶信息
    public function get_info_by_mobile($str)
    {
        return xlink(201118, array($str), 0);
    }

    //根據郵箱號獲取用戶信息
    public function get_info_by_email($str)
    {
        return xlink(201119, array($str), 0);
    }


    /**
     * 提现记录
     * @Author   张哲
     * @DateTime 2018-10-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $id [description]
     * @return   [type]           [description]
     */
    public function get_user_withdraws($asset, $user_id)
    {
        return xlink(401124, array($asset, $user_id), 0);
    }

    public function get_user_activity($asset, $user_id)
    {
        return xlink(401142, array($asset, $user_id), 0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/26
     * Time: 20:52
     * @return mixed
     */
    public function get_withdraws_record(){
        return xlink(401152, array());
    }

    /**
     * Notes: 数据可视化-提币数据
     * User: 张哲
     * Date: 2019/1/16
     * Time: 11:40
     * @param $start_time
     * @param $end_time
     * @param $site_id
     * @param $asset
     * @return mixed
     */
    public function withdraws_sum_asset($start_time, $end_time,$site_id,$asset){
        return xlink(401189, array($start_time, $end_time,$site_id,$asset));
    }

    public function withdraws_sum_site($start_time,$end_time,$site_id){
        return xlink(401193, array($start_time,$end_time,$site_id));
    }

    public function withdraws_sum_nol($start_time,$end_time,$asset){
        return xlink(401194, array($start_time,$end_time,$asset));
    }

    public function withdraws_sum($start_time,$end_time)
    {
        return xlink(401195, array($start_time, $end_time));
    }

    /**
     * Notes: 将提现审核成功的手动设置成失败
     * User: 张哲
     * Date: 2019/2/18
     * Time: 15:56
     * @param $WithdrawId
     * @return mixed
     */
    public function success_to_failure($WithdrawId){
        return xlink(403319, array($WithdrawId));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/2/19
     * Time: 11:06
     * @param $WithdrawId
     * @return mixed
     */
    public function withdraw_no_review_site_id($site_id){
        return xlink(401117, array($site_id));
    }
    public function withdraw_site_id($site_id){
        return xlink(401116, array($site_id));
    }
    public function withdraw_no_review(){
        return xlink(401115, array());
    }
    public function withdraw(){
        return xlink(401114, array());
    }


    /**
     * Notes: 风控-七日内按用户分类
     * User: 张哲
     * Date: 2019-04-24
     * Time: 11:49
     * @param $WithdrawId
     * @return mixed
     */
    public function large_amount_charge_withdraws($start_time,$end_time){
        return xlink(601138, array($start_time,$end_time));
    }


    /**
     * Notes: 钱包状态变化
     * User: 张哲
     * Date: 2019-04-24
     * Time: 16:37
     */
    public function withdraws_wallet_alarm($start_time,$end_time){
        return xlink(601141, array($start_time,$end_time));
    }

}
