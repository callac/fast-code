<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Order_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取产品订单详情
    public function get_product_detail($order_id){
        return xlink('203100',array($order_id),0);
    }

    //获取转让产品订单详情
    public function get_transfer_product_detail($order_id){
        return xlink('203101',array($order_id),0);
    }

    //获取算力交易信息 成功的
    public function get_info_by_user_id($user_id,$status){
        return xlink('203102',array($user_id,$status),0);
    }

    //获取算力交易信息 成功的
    public function update_income($hash_income_id,$remain_fee){
        return xlink('105300',array($hash_income_id,$remain_fee),0,0);
    }

    //获取算力交易信息 成功的
    public function update_product_status($product_id){
        return xlink('105301',array($product_id),0,0);
    }
}