<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
     * 实名
     * @Author   张哲
     * @DateTime 2018-05-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
 

class User_truename_valid_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    

    //实名数据详情
    public function truename_detail($id)
    {
        return xlink(406110,array($id));
    }

    //提现审核
    public function truename_verify($id,$status)
    {
       
        return xlink(406305,array($id,$status));
    }


    //获取实名消息
    public function get_truename_detail($id){
        return xlink('204112',array($id),0);
    }

    //更新用户实名信息
    public function update_user_truename($user_id,$truename,$idcard,$status,$ret_msg){
        return xlink('201312',array($user_id,$truename,$idcard,$status,$ret_msg));
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/2/19
     * Time: 11:40
     * @param $site_id
     * @return mixed
     */
    public function identities_no_review_site_id($site_id){
        return xlink(401113, array($site_id));
    }
    public function identities_site_id($site_id){
        return xlink(401112, array($site_id));
    }
    public function identities_no_review(){
        return xlink(401111, array());
    }
    public function identities()
    {
        return xlink(401110, array());
    }

    /**
     * Notes: 获取用户实名
     * User: 张哲
     * Date: 2019/3/26
     * Time: 14:53
     * @return mixed
     */
    public function true_name($user_id)
    {
        return xlink(601132, array($user_id),0);
    }
}
