<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Deposit_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }


    //托管审核 张哲 2018-05-09
    public function verify($id,$status,$remark)
    {
        return xlink(405304,array($id,$status,$remark,$this->site_id));
    }

    //托管管理详情 张哲 2018-05-09
    public function manager_details($id)
    {
        return xlink(405109,array($id,$this->site_id));
    }



    // //获取消息信息
    // public function get_list($offset,$limit)
    // {
    //     return xlink('301105',array($this->site_id,$offset,$limit));
    // }

    // //获取消息信息
    // public function get_count()
    // {
    //     return xlink('301106',array($this->site_id),0,0);
    // }

    // //获取BDC名称
    // public function get_bdc()
    // {
    //     return xlink('301107',array($this->site_id));
    // }

    // //新增托管信息
    // public function add($dep_name,$dep_tel,$dep_logistics,$created_at,$dep_bdc_id,$electric_charge,$deposit_fee,$process_fee,$mine_pool,$wallet_address,$run_time,$deposit_start_time,$deposit_end_time,$deposit_money,$remark,$contract_name,$contract_copy_picture)
    // {
    //     return xlink('301202',[$dep_name,$dep_tel,$dep_logistics,$created_at,$dep_bdc_id,$electric_charge,$deposit_fee,$process_fee,$mine_pool,$wallet_address,$run_time,$deposit_start_time,$deposit_end_time,$deposit_money,$remark,$contract_name,$contract_copy_picture,$this->site_id]);
    // }

    // //托管修改--显示数据页面
    // public function updateShow($id)
    // {
    //     return xlink('301108',[$id,$this->site_id]);
    // }

    // //托管修改--保存数据
    // public function updateSave($dep_name,$dep_tel,$dep_logistics,$remark,$electric_charge,$deposit_fee,$process_fee,$mine_pool,$contract_name,$wallet_address,$run_time,$deposit_start_time,$deposit_end_time,$deposit_money,$contract_copy_picture,$dep_bdc_id,$id)
    // {
    //     return xlink('301300',[$dep_name,$dep_tel,$dep_logistics,$remark,$electric_charge,$deposit_fee,$process_fee,$mine_pool,$contract_name,$wallet_address,$run_time,$deposit_start_time,$deposit_end_time,$deposit_money,$contract_copy_picture,$dep_bdc_id,$id]);
    // }

    // //托管--删除数据
    // public function delete($id)
    // {
    //     return xlink('301400',[$id]);
    // }

    // public function bdc_list($offset,$limit)
    // {
    //     return xlink('301123',[$this->site_id,$offset,$limit]);
    // }

    // public function bdc_count()
    // {
    //     return xlink('301124',[$this->site_id],0,0);
    // }

    // public function bdc_update($bdc_address,$bdc_electric_type,$bdc_address,$created_at,$bdc_building_scope,$current_electrify_time,$bdc_electrify_price,$total_position,$bdc_trust_fee,$bdc_mining_pool,$is_run,$id)
    // {
    //     return xlink('301307',[$bdc_address,$bdc_electric_type,$bdc_address,$created_at,$bdc_building_scope,$current_electrify_time,$bdc_electrify_price,$total_position,$bdc_trust_fee,$bdc_mining_pool,$is_run,$id,$this->site_id]);
    // }

    // public function bdc_add($bdc_address,$bdc_electric_type,$created_at,$bdc_building_scope,$current_electrify_time,$bdc_electrify_price,$total_position,$bdc_trust_fee,$bdc_mining_pool,$is_run)
    // {
    //     return xlink('301207',[$bdc_address,$bdc_electric_type,$created_at,$bdc_building_scope,$current_electrify_time,$bdc_electrify_price,$total_position,$bdc_trust_fee,$bdc_mining_pool,$is_run,$this->site_id]);
    // }

    // public function bdc_delete($id)
    // {
    //     return xlink('301405',[$id,$this->site_id]);
    // }
    // //获取累计托管数量
     public function get_count_by_user_id($user_id){
         return xlink('301129',[$user_id],0,0);
     }

     //获取托管机器
    public function get_count($site,$time){
        return xlink('204122',[$site,$time],0,0);
    }

    //获取托管机器
    public function handle_num($site,$status){
        return xlink('204143',[$site,$status],0,0);
    }

}
