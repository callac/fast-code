<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
     * 提币
     * @Author   张哲
     * @DateTime 2018-05-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
 

class Account_btc_withdraw_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //提币数据详情
    public function Digital_currency_withdraw_details($id)
    {
        return xlink(404108,array($id));
    }


    //提币审核
    public function Digital_currency_withdraw_verify($id,$status)
    {
        return xlink(404304,array($id,$status));
    }


    //确认审核
    public function sure_verify($id,$status)
    {
        return xlink(404303,array($id,$status));//更改审核状态
    }

    //查询提币数量
    public function find($id)
    {
        return xlink(403112,array($id));
    }

    //查询冻结数量
    public function btc_freeze($id)
    {
        return xlink(403113,array($id));
    }
}
