<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/11/21
 * Time: 11:48
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Platfrom_transfer_record_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function add($operator,$created_at,$asset,$amount,$transfer_out_uid,$remark,$site_id,$transfer_in_uid){
        return xlink(402212,array($operator,$created_at,$asset,$amount,$transfer_out_uid,$remark,$site_id,$transfer_in_uid),0);
    }

    public function settlement_add($operator,$created_at,$asset,$amount,$transfer_out_uid,$remark,$site_id,$transfer_in_uid){
        return xlink(402233,array($operator,$created_at,$asset,$amount,$transfer_out_uid,$remark,$site_id,$transfer_in_uid),0);
    }

    public function day_settlement_add($operator,$created_at,$asset,$amount,$transfer_out_uid,$remark,$site_id,$transfer_in_uid){
        return xlink(402235,array($operator,$created_at,$asset,$amount,$transfer_out_uid,$remark,$site_id,$transfer_in_uid),0);
    }


    /**
     * Notes: 获取单个用户单个币种的借款记录
     * User: 张哲
     * Date: 2018/11/23
     * Time: 09:52
     * @param $user_id
     * @param $asset
     * @return mixed
     */
    public function get_loan_sum($user_id,$asset){
        return xlink(401146,array($user_id,$asset),0);
    }

    /**
     * Notes: 获取单个用户单个币种的还款记录
     * User: 张哲
     * Date: 2018/11/23
     * Time: 09:52
     * @param $user_id
     * @param $asset
     * @return mixed
     */
    public function get_repayment_sum($user_id,$asset){
        return xlink(401147,array($user_id,$asset),0);
    }
}
