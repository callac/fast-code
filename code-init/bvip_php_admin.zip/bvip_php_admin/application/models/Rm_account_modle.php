<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Rm_account_modle extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //新增交易异常记录
    public function add($unfair_asset_type,$unfair_asset_amount,$user_id,$created_at,$site_id){
        return xlink(402206,array($unfair_asset_type,$unfair_asset_amount,$user_id,$created_at,$site_id),0);
    }


    /**
     * Notes: 新增监听用户
     * User: 张哲
     * Date: 2019/3/19
     * Time: 21:00
     */
    public function add_name($name,$phone,$email,$created_at,$site_id,$target){
        return xlink(402231,array($name,$phone,$email,$created_at,$site_id,$target),0);
    }


    /**
     * Notes: 修改监听用户
     * User: 张哲
     * Date: 2019/3/19
     * Time: 21:00
     */
    public function edit_name($id,$name,$phone,$email,$updated_at,$site_id,$target){
        return xlink(403329,array($id,$name,$phone,$email,$updated_at,$site_id,$target),0);
    }


    /**
     * Notes: 删除监控账户
     * User: 张哲
     * Date: 2019/3/19
     * Time: 21:18

     */
    public function delete_target_roles($id,$deleted_at){
        return xlink(403330,array($id,$deleted_at),0);
    }
}