<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/1/4
 * Time: 16:40
 */


class Data_visualzation_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 有站点和币种
     * User: 张哲
     * Date: 2019/2/21
     * Time: 17:12
     * @param $one_time
     * @param $two_time
     * @param $site_id
     * @param $asset
     * @return mixed
     */
    public function trade_asset_site_left($one_time, $two_time,$site_id,$asset)
    {
        return xlink('401105',array($one_time, $two_time,$site_id,$asset),0);
    }

    public function trade_asset_site_all_left($site_id,$asset)
    {
        return xlink('401104',array($site_id,$asset),0);
    }

    public function trade_asset_site_right($one_time, $two_time,$site_id,$asset)
    {
        return xlink('401103',array($one_time, $two_time,$site_id,$asset),0);
    }

    public function trade_asset_site_all_right($site_id,$asset)
    {
        return xlink('401102',array($site_id,$asset),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/2/21
     * Time: 17:58
     * @param $one_time
     * @param $two_time
     * @param $asset
     * @return mixed
     */
    public function trade_asset_left($one_time, $two_time,$asset)
    {
        return xlink('401101',array($one_time, $two_time,$asset),0);
    }

    public function trade_asset_all_left($asset)
    {
        return xlink('401100',array($asset),0);
    }

    public function trade_asset_right($one_time, $two_time,$asset)
    {
        return xlink('601101',array($one_time, $two_time,$asset),0);
    }

    public function trade_asset_all_right($asset)
    {
        return xlink('601102',array($asset),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/2/21
     * Time: 20:00
     * @param $one_time
     * @param $two_time
     * @param $symblos
     * @return mixed
     */
    public function trade_asset_site_symblos($one_time, $two_time,$site_id,$symblos)
    {
        return xlink('601103',array($one_time, $two_time,$site_id,$symblos),0);
    }
    public function trade_asset_site_all_symblos($site_id,$symblos)
    {
        return xlink('601104',array($site_id,$symblos),0);
    }
    public function trade_asset_symblos($one_time, $two_time,$symblos)
    {
        return xlink('601105',array($one_time, $two_time,$symblos),0);
    }
    public function count($symblos)
    {
        return xlink('601106',array($symblos),0);
    }
    /**
     * Notes: 交易人数
     * User: 张哲
     * Date: 2019/2/15
     * Time: 14:46
     * @param $one_time
     * @param $two_time
     * @param $site_id
     * @return mixed
     */
    public function trade_user_amount($one_time, $two_time,$site_id)
    {
        return xlink('401198',array($one_time, $two_time,$site_id),0);
    }

    public function trade_user_amount_all($site_id)
    {
        return xlink('401199',array($site_id),0);
    }

    /**
     * Notes: 无站点id
     * User: 张哲
     * Date: 2019/2/15
     * Time: 15:03
     * @param $site_id
     * @return mixed
     */
    public function trade_user_amount_no($one_time, $two_time)
    {
        return xlink('401119',array($one_time, $two_time),0);
    }

    public function trade_user_amount_all_no()
    {
        return xlink('401118',array(),0);
    }
}