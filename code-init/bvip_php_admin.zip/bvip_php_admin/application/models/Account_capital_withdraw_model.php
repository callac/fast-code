<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
 

class Account_capital_withdraw_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //提现列表
    public function withdraw_list($offset,$limit)
    {
        return xlink(402103,array($offset,$limit,$this->site_id));
    }

    //提现总条数
    public function withdraw_list_count()
    {
        return xlink(402104,array($this->site_id),0,0);
    }

    //提现数据详情
    public function withdraw_details($id)
    {
        return xlink(402105,array($id));
    }

    //提现审核
    public function withdraw_verify($id,$status)
    {
    	// var_dump($this->site_id);die;
        return xlink(402300,array($id,$status));
    }

    //提币待处理
    public function withdraw_waiting($site_id){
        return xlink('204120',array($site_id),0,0);
    }
























}
