<?php

//公共的Model
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Banner_model
 */
Class Base_Model extends CI_Model {

   public function __construct()
   {  
       //获取站点信息
       //$this->site_id = get_site_info()['site_id'];
       $this->site_id = 1;
   }
}