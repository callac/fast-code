<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/11/26
 * Time: 20:11
 */


defined('BASEPATH') OR exit('No direct script access allowed');
class Platfrom_account_asset_record_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/27
     * Time: 09:47
     * @param $site_id
     * @param $user_id
     * @param $asset
     * @param $balance
     * @param $loan_total
     * @param $repayment_total
     * @param $wait_repayment
     * @param $created_at
     * @return mixed
     */
    public function add($site_id,$asset,$balance,$loan_total,$repayment_total,$wait_repayment,$created_at){
        return xlink(402215,array($site_id,$asset,$balance,$loan_total,$repayment_total,$wait_repayment,$created_at),0);
    }

    /**
     * Notes: 查看记录是否已存在
     * User: 张哲
     * Date: 2018/11/27
     * Time: 09:47
     */
    public function get_data($site_id,$user_id,$asset){
        return xlink(401151,array($site_id,$user_id,$asset),0);
    }

    //更新币种信息
    public function update($site_id,$user_id,$asset,$balance,$loan_total,$repayment_total,$wait_repayment,$created_at,$asset_balance){
        return xlink(403308,array($site_id,$user_id,$asset,$balance,$loan_total,$repayment_total,$wait_repayment,$created_at,$asset_balance),0);
    }

    //更新币种信息
    public function add_account_asset($site_id,$user_id,$asset,$balance,$loan_total,$repayment_total,$wait_repayment,$created_at,$asset_balance){
        return xlink(402219,array($site_id,$user_id,$asset,$balance,$loan_total,$repayment_total,$wait_repayment,$created_at,$asset_balance),0);
    }

    /**
     * Notes: 增加用户id
     * User: 张哲
     * Date: 2018/11/29
     * Time: 15:25
     * @param $user_id
     * @param $time
     * @return mixed
     */
    public function add_user($user_id,$time,$site_id,$asset){
        return xlink(403312,array($user_id,$time,$site_id,$asset),0);
    }


}
