<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_symbols_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //新增币资产种类sql
    public function add_symbol($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$site_id,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$is_display,$base_asset_name,$quote_asset_name){
        return xlink(501202,array($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$site_id,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$is_display,$base_asset_name,$quote_asset_name),0);
    }

    public function system_symbol_add($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$subtrue,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$site_id,$base_asset_name,$quote_asset_name,$alert_percent){
        return xlink(501225,array($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$subtrue,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$site_id,$base_asset_name,$quote_asset_name,$alert_percent),0);
    }


    public function add_symbol_true($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$site_id,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$subtrue,$base_asset_name,$quote_asset_name,$alert_percent){
        return xlink(501223,array($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$site_id,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$subtrue,$base_asset_name,$quote_asset_name,$alert_percent),0);
    }


    //修改币资产种类sql
    public function edit_symbol($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$site_id,$updated_at,$base_asset_precision,$quote_asset_precision,$id,$is_display,$base_asset_name,$quote_asset_name){
        return xlink(501304,array($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$site_id,$updated_at,$base_asset_precision,$quote_asset_precision,$id,$is_display,$base_asset_name,$quote_asset_name),0);
    }

    public function system_symbol_edit($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$subtrue,$updated_at,$base_asset_precision,$quote_asset_precision,$id,$site_id,$base_asset_name,$quote_asset_name,$alert_percent){
        return xlink(501338,array($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$subtrue,$updated_at,$base_asset_precision,$quote_asset_precision,$id,$site_id,$base_asset_name,$quote_asset_name,$alert_percent),0);
    }

    //获取所有交易对
    public function list_all(){
        // echo 5;die;
        return xlink(501105,0);
    }
    //获取total_symbols表所有交易对
    public function list_totalsymbols(){
        return xlink(501176,0);
    }


    public function list_all_siteid($site_id){
        // echo 5;die;
        return xlink(501150,array($site_id));
    }


    public function get_symbols_by_site_id($site_id){
        // echo 5;die;
        return xlink(501127,array($site_id));
    }

    public function get_name_exp($symbol_classes_id,$lang)
    {
        return xlink(501185,array($symbol_classes_id,$lang),0);
    }

    public function get_statement_exp($symbol_classes_id,$lang)
    {
        return xlink(501186,array($symbol_classes_id,$lang),0);
    }



    //查询单个币种详情
    public function get_symbol_detail($symbol,$site_id){
        return xlink(501109,array($symbol,$site_id),0);
    }

    public function symbol_true($symbol,$site_id){
        return xlink(501109,array($symbol,$site_id),0);
    }

    //查询系统币种详情
    public function get_sys_symbol_detail($symbol){
        return xlink(501136,array($symbol),0);
    }

    public function get_system_asset_detail_byid($id){
        return xlink(501139,array($id),0);
    }

    public function delete_by_site_id($site_id)
    {
        return xlink(501402,array($site_id),0);
    }

    public function get_detail_by_id($id)
    {
        return xlink(501111,array($id),0);
    }

    public function update_subsite_symbol($where,$base_asset,$quote_asset,$symbol,$tick_size,$min_quantity)
    {
        return xlink(501313,array($where,$base_asset,$quote_asset,$symbol,$tick_size,$min_quantity),0);
    }

    public function correct_symbols($symbol,$alert_percent)
    {
        return xlink(501397,array($symbol,$alert_percent),0);
    }

    public function symbol_delete($site_id,$symbol)
    {
        return xlink(501406,array($site_id,$symbol),0);
    }


    /**
     * 更具站点获取站点交易对机器id
     * @Author   张哲
     * @DateTime 2018-10-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $site_id [description]
     * @return   [type]                [description]
     */
     public function get_symbols_by_site_id1(){
       
        return xlink(401120,array());
    }

    /**
     * 获取站点名称
     * @Author   张哲
     * @DateTime 2018-10-29
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $site_id [description]
     * @return   [type]                [description]
     */
     public function get_symbols_name($site_id){
       
        return xlink(401128,array($site_id),0);
    }


    //
    public function add_symbolblock($site_id,$name,$unique_id,$display_order,$shorthand,$created_at,$updated_at,$count,$lang,$icon){
         return xlink(501238,array($site_id,$name,$unique_id,$display_order,$shorthand,$created_at,$updated_at,$count,$lang,$icon),0);
     }

     public function edit_symbolblock($site_id,$name,$unique_id,$display_order,$shorthand,$updated_at,$id,$count,$lang,$icon){
         return xlink(501354,array($site_id,$name,$unique_id,$display_order,$shorthand,$updated_at,$id,$count,$lang,$icon),0);
     }

     public function symbolblock_delete($id,$time){
         return xlink(501355,array($id,$time),0);
     }

     public function symbolblock_list_noauth($site_id){
         return xlink(501164,array($site_id));
     }

     public function add_symbols_relation($created_at,$updated_at,$symbol_id,$symbol_class_id){
         return xlink(501239,array($created_at,$updated_at,$symbol_id,$symbol_class_id),0);
     }
     //新增交易板块
     public function add_symbolclasses_exp($name,$symbol_classes_id,$statement,$lang)
     {
         return xlink(501253,array($name,$symbol_classes_id,$statement,$lang),0);
     }

     public function delete_relations($id,$time){
         return xlink(501356,array($id,$time),0);
     }

     public function delete_symbolclasses_exp($id){
         return xlink(501408,array($id),0);
     }
     //
     public function get_relation($id){
         return xlink(501165,array($id));
     }

     public function is_name_true($site_id,$name){
         return xlink(501166,array($site_id,$name));
     }

     public function is_unique_true($site_id,$unique_id){
         return xlink(501167,array($site_id,$unique_id));
     }

     public function is_shorthand_true($site_id,$shorthand){
         return xlink(501168,array($site_id,$shorthand));
     }


    /**
     * Notes: 数据可视化-获取站点交易对和总交易对
     * User: 张哲
     * Date: 2019/1/16
     * Time: 14:46
     * @param $site_id
     * @return mixed
     */

    public function get_symbols_all(){
        return xlink(501168,array());
    }

    /**
     * Notes: 数据可视化-根据币种给出交易对
     * User: 张哲
     * Date: 2019/1/17
     * Time: 11:50
     * @return mixed
     */
    public function asset_symbols($asset,$site_id){
        return xlink(401196,array($asset,$site_id));
    }

    public function asset_symbols_nol($asset){
        return xlink(401197,array($asset));
    }
}
