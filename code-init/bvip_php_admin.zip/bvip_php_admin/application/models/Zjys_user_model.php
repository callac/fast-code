<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_user_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取用户详情
    public function get_info($user_id){
        return xlink(501148,array($user_id),0);
    }

    public function find_phone($phone,$id){
        return xlink(501162,array($phone,$id),0);
    }

    public function is_position_true($asset,$user_id,$status){
        return xlink(501177,array($asset,$user_id,$status),0);
    }

    public function find_email($email,$id){
        return xlink(501163,array($email,$id),0);
    }

    //统计用户数量
    public function get_count($site_id,$start,$end){
        return xlink(201116,array($site_id,$start,$end),0,0);
    }

    public function get_info_phoneoremail($re){
        return xlink(501181,array($re));
    }

    // //禁止登陆/允许登陆
    // public function update_forbid_login($user_id,$type){
    //     return xlink(201301,array($user_id,$type),0);
    // }
    // //禁止交易/允许交易
    // public function update_forbid_withdraw($user_id,$type){
    //     return xlink(201302,array($user_id,$type),0);
    // }
    // //禁止提现/允许提现
    // public function update_forbid_trade($user_id,$type){
    //     return xlink(201303,array($user_id,$type),0);
    // }

    //更新用户token信息
    public function update_user_token($user_id,$token){
        return xlink(201316,array($user_id,$token));
    }

    //资金解冻
    public function capital_unfreeze($user_id,$amount)
    {
        return xlink(403309,array($user_id,$amount),0);
    }

    //提现审核失败资金解冻并还原余额
    public function capital_unfreeze_back_account($user_id,$amount)
    {
        return xlink(403310,array($user_id,$amount),0);
    }

    //银行卡充值更新余额
    public function update_user_balance($user_id,$balance)
    {
        return xlink(201314,array($user_id,$balance),0);
    }


    //根据站点获取 所有用户id
    public function get_user_info_by_site($site_id){
        return xlink(201117,array($site_id));
    }

    public function get_userid_by_site($site_id){
        return xlink(501118,array($site_id));
    }

    //根據手機號獲取用戶信息
    public function get_info_by_mobile($str){
        return xlink(201118,array($str),0);
    }
    //根據郵箱號獲取用戶信息
    public function get_info_by_email($str){
        return xlink(201119,array($str),0);
    }
    //重置两步验证
    public function reset_google_verify($id)
    {
        return xlink(501311,array($id),0);
    }

    //重置两步验证
    public function delete_google_verify($id,$type=2)
    {
        return xlink(501403,array($id,$type),0);
    }

    //重置认证信息
    public function resetidentity($id,$time)
    {
        return xlink(501344,array($id,$time),0);
    }





    public function add_vip($vip_level,$limit_taker_discount,$limit_maker_discount,$market_taker_discount,$withdraw_discount,$created_at,$updated_at)
    {
        return xlink(501207,array($vip_level,$limit_taker_discount,$limit_maker_discount,$market_taker_discount,$withdraw_discount,$created_at,$updated_at),0);
    }

    public function edit_vip($vip_level,$limit_taker_discount,$limit_maker_discount,$market_taker_discount,$withdraw_discount,$updated_at,$id)
    {
        return xlink(501314,array($vip_level,$limit_taker_discount,$limit_maker_discount,$market_taker_discount,$withdraw_discount,$updated_at,$id),0);
    }


    public function vip_adduser($user_id,$vip_level)
    {
        return xlink(501315,array($user_id,$vip_level),0);
    }

    public function is_true($vip_level)
    {
        return xlink(501112,array($vip_level),0);
    }


    //禁止登陆/允许登陆
    public function update_forbid_login($user_id,$type){
        return xlink(501316,array($user_id,$type),0);
    }
    //禁止交易/允许交易
    public function update_forbid_withdraw($user_id,$type){
        return xlink(501317,array($user_id,$type),0);
    }
    //禁止提现/允许提现
    public function update_forbid_trade($user_id,$type){
        return xlink(501318,array($user_id,$type),0);
    }

    //定时任务写入用户统计信息
    public function add_perday_userstatistic($name,$site_id,$time,$time_area,$register_user,$recommend_user,$identity_user,$login_user,$last_rate,$three_rate,$seven_rate)
    {
        return xlink(501215,array($name,$site_id,$time,$time_area,$register_user,$recommend_user,$identity_user,$login_user,$last_rate,$three_rate,$seven_rate),0);
    }
    //  查询当前日期是否已经存在
    public function time_is_true($time)
    {
        return xlink(501129,array($time),0);
    }



    public function lockposition_update($asset,$user_id,$amount,$expire_time,$remark,$updated_at,$id)
    {
        return xlink(501326,array($asset,$user_id,$amount,$expire_time,$remark,$updated_at,$id),0);
    }

    public function lockposition_add($asset,$user_id,$amount,$expire_time,$remark,$status,$created_at,$updated_at,$check_status)
    {
        return xlink(501217,array($asset,$user_id,$amount,$expire_time,$remark,$status,$created_at,$updated_at,$check_status),0);
    }

    public function lockposition_delete($id,$time){
        return xlink("501327",[$id,$time],0,0);
    }

    public function identity_info($id)
    {
        return xlink(501154,array($id),0);
    }

    public function edit_phoneoremail($id,$phone,$email)
    {
        return xlink(501345,array($id,$phone,$email),0);
    }


    /**
     * 获取用户站点id
     * @Author   张哲
     * @DateTime 2018-10-31
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $user_id [description]
     * @return   [type]                [description]
     */
    public function check_site_id($user_id){
        return xlink(401130,array($user_id),0);
    }

     /**
      * 获取用户手机号、邮箱
      * @Author   张哲
      * @DateTime 2018-11-07
      * @createby SublimeText3
      * @version  1.0
      * @return   [return]
      * @param    [type]       $user_id [description]
      * @return   [type]                [description]
      */
    public function check_phone($user_id){
        return xlink(401137,array($user_id),0);
    }
    /**
     * 查用户表是否有该账户
     * @Author   张哲
     * @DateTime 2018-11-08
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $user_id [description]
     * @return   [type]                [description]
     */
    public function check_account_phone($account){
        return xlink(401138,array($account),0);
    }
    public function check_account_email($account){
        return xlink(401139,array($account),0);
    }
    //更新认证状态
    public function edit_identity_status($id,$status,$remark,$time)
    {
        return xlink("501346",[$id,$status,$remark,$time],0,0);
    }

    public function delete_identity_img($id,$time)
    {
        return xlink("501348",[$id,$time],0,0);
    }

    public function edit_userauth_status($id,$time)
    {
        return xlink("501347",[$id,$time],0,0);
    }
    //  获取图片
    public function get_img($user_identity_id)
    {
        return xlink('501160',array($user_identity_id));
    }

    public function get_country($id)
    {
        return xlink('501161',array($id),0);
    }

    public function reset_user_auth($id)
    {
        return xlink("501349",[$id],0,0);
    }

    public function reset_two_factor($id,$time)
    {
        return xlink("501370",[$id,$time],0,0);
    }

    /**
     * Notes: 生成站点总账户
     * User: 张哲
     * Date: 2018/11/20
     * Time: 16:34
     * @param $site_id
     * @param $time
     * @return mixed
     */
    public function generate_total_account($forbidden_login,$forbidden_withdraw,$forbidden_trade,$site_id,$created_at,$status)
    {
        return xlink("402211",array($forbidden_login,$forbidden_withdraw,$forbidden_trade,$site_id,$created_at,$status),0);
    }

    /**
     * Notes: 检查站点总账户是否存在
     * User: 张哲
     * Date: 2018/11/20
     * Time: 18:25
     * @param $site_id
     * @param $status
     * @return mixed
     */
    public function check_generate_total_account($site_id,$status)
    {
        return xlink("401144",array($site_id,$status),0);
    }

    /**
     * Notes: 修改账户为总账户
     * User: 张哲
     * Date: 2018/11/28
     * Time: 14:21
     * @param $user_id
     * @param $status
     * @return mixed
     */
    public function update_total_status($forbidden_login,$forbidden_withdraw,$forbidden_trade,$user_id,$status)
    {
        return xlink("403310",array($forbidden_login,$forbidden_withdraw,$forbidden_trade,$user_id,$status),0);
    }

    public function update_status($user_id,$status)
    {
        return xlink("403313",array($user_id,$status),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/30
     * Time: 11:37
     * @param $user_id
     * @return mixed
     */
    public function get_total_info($user_id,$site_id){
        return xlink(401164,array($user_id,$site_id),0);
    }

    public function is_true_cardnumber($number){
        return xlink(401166,array($number),0);
    }

    public function correct_identity_baseinfo($id,$first_name,$last_name,$name,$number,$country_id)
    {
        return xlink("501371",array($id,$first_name,$last_name,$name,$number,$country_id),0);
    }

    /**
     * Notes:  数据可视化-实时注册用户数据
     * User: 张哲
     * Date: 2019/1/4
     * Time: 20:08
     * @return mixed
     */
    public function real_data_user($start_time,$end_time,$site_id){
        return xlink("401169",array($start_time,$end_time,$site_id),0);
    }

    public function real_data_user1($start_time,$end_time){
        return xlink("401173",array($start_time,$end_time),0);
    }

    /**
     * Notes:数据可视化-用户总览总注册用户
     * User: 张哲
     * Date: 2019/1/9
     * Time: 16:35
     * @param $start_time
     * @param $end_time
     * @return mixed
     */
    public function real_data_user_all($site_id){
        return xlink("401175",array($site_id),0);
    }

    public function real_data_user_all1(){
        return xlink("401176",array(),0);
    }

    /**
     * Notes: 数据可视化-实时实名认证数据
     * User: 张哲
     * Date: 2019/1/8
     * Time: 09:57
     * @param $start_time
     * @param $end_time
     * @return mixed
     */
    public function real_data_identities($start_time,$end_time,$site_id){
        return xlink("401170",array($start_time,$end_time,$site_id),0);
    }

    public function real_data_identities1($start_time,$end_time){
        return xlink("401182",array($start_time,$end_time),0);
    }




    /**
     * Notes:数据可视化-用户总览总实名用户
     * User: 张哲
     * Date: 2019/1/9
     * Time: 16:48
     * @param $start_time
     * @param $end_time
     * @return mixed
     */
    public function real_data_identities_all($site_id){
        return xlink("401183",array($site_id),0);
    }

    public function real_data_identities_all1(){
        return xlink("401177",array(),0);
    }


    /**
     * Notes: 交易人数
     * User: 张哲
     * Date: 2019/2/15
     * Time: 14:46
     * @param $one_time
     * @param $two_time
     * @param $site_id
     * @return mixed
     */
    public function trade_user_amount($one_time, $two_time,$site_id)
    {
        return xlink('401198',array($one_time, $two_time,$site_id),0);
    }

    public function trade_user_amount_all($site_id)
    {
        return xlink('401199',array($site_id),0);
    }

    /**
     * Notes: 无站点id
     * User: 张哲
     * Date: 2019/2/15
     * Time: 15:03
     * @param $site_id
     * @return mixed
     */
    public function trade_user_amount_no($start_time,$end_time)
    {
        return xlink('401119',array($start_time,$end_time),0);
    }

    public function trade_user_amount_all_no()
    {
        return xlink('401118',array(),0);
    }

    /**
     * Notes: 查找user_asset_operatings表用户锁仓余额是否够
     * User: 张哲
     * Date: 2019/3/1
     * Time: 16:39
     * @return mixed
     */
    public function user_asset_operatings_balance($user_id,$asset)
    {
        return xlink('601109',array($user_id,$asset),0);
    }

    /**
     * Notes: 查找user_asset_operatings表是否有该用户
     * User: 张哲
     * Date: 2019/3/1
     * Time: 17:52
     * @param $user_id
     * @return mixed
     */
    public function asset_uid($user_id)
    {
        return xlink('601110',array($user_id),0);
    }


    /**
     * Notes: 活动送出
     * User: 张哲
     * Date: 2019/3/15
     * Time: 11:23
     */
    public function send_amount($id){
        return xlink('601125',array($id),0);
    }
    /**
     * 手动添加邀请关系
     * @param [type] $created_at          [description]
     * @param [type] $updated_at          [description]
     * @param [type] $user_id             [description]
     * @param [type] $recommend_user_id   [description]
     * @param [type] $recommend_user_name [description]
     * @param [type] $status              [description]
     */
    public function add_recommend($created_at,$updated_at,$user_id,$recommend_user_id,$recommend_user_name,$status)
    {
        return xlink(501250,array($created_at,$updated_at,$user_id,$recommend_user_id,$recommend_user_name,$status),0);
    }


}
