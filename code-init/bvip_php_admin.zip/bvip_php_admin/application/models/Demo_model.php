<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Demo_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function info($id){
        return xlink("",array($id,$this->site_id),0);
    }

    public function get_list($offset,$limit){
        return xlink("",array($offset,$limit,$this->site_id));
    }
    public function get_count(){
        return xlink("",array($this->site_id),0,0);
    }

    public function add($a,$b){
        return xlink("",array($a,$b,$this->site_id));
    }

    public function update($id){
        return xlink("",array($id,$this->site_id));
    }

    public function delete($id){
        return xlink("",array($id,$this->site_id));
    }
}
