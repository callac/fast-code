<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Roles_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //角色详情
    public function roles_details($id){
        return xlink("204100",array($id),0);
    }

    //管理员列表
    public function roles_list($offset,$limit,$parent_id){
        return xlink("204106",array($offset,$limit,$parent_id));
    }

    //管理员列表-统计
    public function roles_count($parent_id){
        return xlink("204107",array($parent_id),0,0);
    }

    //管理员列表
    public function roles_list_by_site($offset,$limit,$parent_id,$site_id){
        return xlink("204109",array($offset,$limit,$parent_id,$site_id));
    }

    //管理员列表-统计
    public function roles_count_by_site($parent_id,$site_id){
        return xlink("204110",array($parent_id,$site_id),0,0);
    }


    //岗位列表
    public function roles_list_all_by_site($offset,$limit,$site_id){
        return xlink("204117",array($offset,$limit,$site_id));
    }

    //岗位列表-统计
    public function roles_count_all_by_site($site_id){
        return xlink("204118",array($site_id),0,0);
    }

    //岗位列表
    public function roles_list_all($offset,$limit){
        return xlink("204115",array($offset,$limit));
    }

    //岗位列表-统计
    public function roles_count_all(){
        return xlink("204116",array(),0,0);
    }


    //管理员 禁用/启用
    public function roles_lock($id,$type){
        return xlink("204303",array($id,$type));
    }

    //管理员新增
    public function roles_update($role_id,$user_name,$true_name,$email){
        return xlink("204304",array($role_id,$user_name,$true_name,$email));
    }
    //管理员编辑
    public function roles_add($user_name,$true_name,$email){
        return xlink("204202",array($user_name,$true_name,$email));
    }

    //获取所有角色信息
    public function roles_all(){
        return xlink("204104",array());
    }

    //根据role_name查询
    public function get_info_by_role_name($role_name,$site_id){
        return xlink("204108",array($role_name,$site_id),0);
    }

    //编辑部门/岗位
    public function roles_update_parent($role_id,$role_name,$description,$parent_id){
        return xlink("204305",array($role_id,$role_name,$description,$parent_id));
    }

    //新增部门/岗位
    public function roles_add_parent($role_name,$description,$site_id,$parent_id,$create_time){
        return xlink("204203",array($role_name,$description,$site_id,$parent_id,$create_time));
    }

    // 更新部门/岗位权限列表
    public function roles_update_privilages($id,$privilages){
        return xlink("204306",array($id,$privilages));
    }

    //获取该用户拥有的角色
    public function get_admin_roles_by_user($user_id){
        return xlink("204114",array($user_id));
    }
    //修改权限
    public function update_priv($role_id,$priv_ids){
        return xlink("204311",array($role_id,$priv_ids));
    }

    // 更新部门/岗位权限列表
    public function roles_update_site($parent_id,$privilages){
        return xlink("204315",array($parent_id,$privilages));
    }

    // 更新部门/岗位权限列表
    public function roles_update_parent_site($role_id,$site_id){
        return xlink("204314",array($role_id,$site_id));
    }

    public function get_parent_roles_by_site($site_id){
        return xlink("204135",array($site_id));
    }

    public function get_roles_by_site($site_id){
        return xlink("204136",array($site_id));
    }

    public function get_roles_by_parent($parent_id){
        return xlink("204137",array($parent_id));
    }

    public function admin_roles_delete($role_id){
        return xlink("201417",array($role_id));
    }
    public function roles_delete_parent($parent_id){
        return xlink("201418",array($parent_id));
    }

    public function roles_delete($role_id){
        return xlink("201419",array($role_id));
    }
    //获取子站点超管的所有权限码
    public function get_sub_privilages($site_id)
    {
        return xlink("204138",array($site_id));
    }

    //添加子站总超管角色权限信息
    public function add_subadmin_role($role_name,$privs,$site_id,$time,$sadmin)
    {
        return xlink("204212",array($role_name,$privs,$site_id,$time,$sadmin));
    }


}