<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Account_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    // ------------------------- 数字货币类型---------------------------------
    public function get_currency_list($offset,$limit,$site_id){
        return xlink("202116",array($offset,$limit,$site_id));
    }

    public function get_currency_count($site_id){
        return xlink("202117",array($site_id),0,0);
    }

    public function currency_update($id,$name,$site_id){
        return xlink("201306",array($id,$name,$site_id));
    }

    public function currency_add($name,$time,$site_id){
        return xlink("203206",array($name,$time,$site_id));
    }

    public function currency_delete($id){
        return xlink("201408",array($id));
    }

    // ------------------------- 操作日志---------------------------------
    public function get_logs_list($offset,$limit,$site_id,$name,$ip,$start_time,$end_time){
        return xlink("202118",array($offset,$limit,$site_id,$name,$ip,$start_time,$end_time));
    }

    public function get_logs_count($site_id,$name,$ip,$start_time,$end_time){
        return xlink("202119",array($site_id,$name,$ip,$start_time,$end_time),0,0);
    }

    public function logs_delete($id){
        return xlink("201409",array($id));
    }
    // ------------------------- 电子合同---------------------------------

    public function get_contract_all($site_id){
        return xlink("202122",array($site_id));
    }

    public function get_contract_list($offset,$limit,$site_id,$type){
        return xlink("202120",array($offset,$limit,$site_id,$type));
    }

    public function get_contract_count($site_id,$type){
        return xlink("202121",array($site_id,$type),0,0);
    }

    public function contract_update($id,$title_buy,$desc,$content,$site_id,$type){
        return xlink("201307",array($id,$title_buy,$desc,$content,$site_id,$type));
    }

    public function contract_add($title_buy,$desc,$content,$modify_user,$modify_time,$site_id,$type){
        return xlink("203207",array($title_buy,$desc,$content,$modify_user,$modify_time,$site_id,$type));
    }

    public function contract_delete($id){
        return xlink("201410",array($id));
    }



}
