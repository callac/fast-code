<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Miner_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //矿机--列表
    public function get_list($offset,$limit)
    {
        return xlink('301112',array($this->site_id,$offset,$limit));
    }

    //矿机--总条数
    public function get_info_count()
    {
        return xlink('301113',array($this->site_id),0,0);
    }

    //获取算力类型,新增和修改需要调用
    public function getHashType()
    {
        return xlink('301114',array($this->site_id));
    }

    //矿机--新增
    public function add($hash_type_id,$name,$amount,$one_amount_value,$single_limit_amount,$MinerAddress,$is_index_see,$is_see,$MInerBrief,$status,$sell_start_time,$sell_end_time,$DeliveryTime,$minerPicture,$site_id,$miner_type_id,$contract_id)
    {
        return xlink('301203',[$hash_type_id,$name,$amount,$one_amount_value,$single_limit_amount,$MinerAddress,$is_index_see,$is_see,$MInerBrief,$status,$sell_start_time,$sell_end_time,$DeliveryTime,$minerPicture,$site_id,$miner_type_id,$contract_id]);
    }

    //矿机--编辑
    public function update($hash_type_id,$name,$amount,$one_amount_value,$single_limit_amount,$MinerAddress,$is_index_see,$is_see,$MInerBrief,$status,$sell_start_time,$sell_end_time,$DeliveryTime,$minerPicture,$site_id,$miner_type_id,$id,$contract_id)
    {
        return xlink('301301',[$hash_type_id,$name,$amount,$one_amount_value,$single_limit_amount,$MinerAddress,$is_index_see,$is_see,$MInerBrief,$status,$sell_start_time,$sell_end_time,$DeliveryTime,$minerPicture,$site_id,$miner_type_id,$id,$contract_id]);
    }
    //矿机--售罄
    public function sellOut($id)
    {
        return xlink('301302',[$id,$this->site_id]);
    }


    //矿机数据详情 张哲 2018-05-08
    public function miner_details($id)
    {
        return xlink('301127',array($id,$this->site_id));
    }

     //矿机类型 张哲 2018-05-08
    public function miner_type()
    {
        return xlink('301128');
    }

    //算力类型 张哲 2018-05-09
    public function hash_type()
    {
        return xlink('301114',array($this->site_id));
    }
























}