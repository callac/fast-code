<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Assets_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function info_list(){
        return xlink("106100",array());
    }

    public function info($time){
        return xlink("106101",array($time,$time+86400));
    }

    public function get_hash_info($start_time,$time,$hash_type){
        return xlink("106102",array($start_time,$time,$hash_type));
    }
   
    public function sum_paid_amount($hash_income_id){
        return xlink("106103",array($hash_income_id),0,0);
    }

    public function get_address($hash_type){
        return xlink("106104",array($hash_type));
    }

    public function add($total_balance,$cold_balance,$hot_balance,$block_balance,$slb_balance,$buy_balance,$mine_time,$hash_type,$create_time){
        return xlink("106200",array($total_balance,$cold_balance,$hot_balance,$block_balance,$slb_balance,$buy_balance,$mine_time,$hash_type,$create_time),0,0);
    }

    public function change_coin_info($id,$total_balance,$cold_balance,$hot_balance,$block_balance,$slb_balance,$buy_balance){
        return xlink("106300",array($id,$total_balance,$cold_balance,$hot_balance,$block_balance,$slb_balance,$buy_balance),0,0);
    }

    public function hash_income_info($time){
        return xlink("107100",array($time,$time+86400));
    }

    public function get_newest_info($hash_type){
        return xlink("107101",array($hash_type),0);
    }
   
    public function add_paid_income($total_income,$paid_income,$withdraw_btc,$trust_fee,$procedure_fee,$electric_fee,$mine_time,$hash_type,$create_time,$assign_type){
        return xlink("107200",array($total_income,$paid_income,$withdraw_btc,$trust_fee,$procedure_fee,$electric_fee,$mine_time,$hash_type,$create_time,$assign_type),0,0);
    }

    public function change_paid_income($id,$total_income,$paid_income,$withdraw_btc,$trust_fee,$procedure_fee,$electric_fee){
        return xlink("107300",array($id,$total_income,$paid_income,$withdraw_btc,$trust_fee,$procedure_fee,$electric_fee),0,0);
    }

    public function get_withdraw_btc($start_time,$time){
        return xlink("108100",array($start_time,$time,1),0,0);
    }

    public function get_explain_info($time){
        return xlink("109100",array($time,$time+86400),0);
    }
    public function get_explain_info_by_id($id){
        return xlink("109101",array($id),0);
    }

    public function add_explain(){
        return xlink("109200",array(0,0,0,0,time(),time()),0,0);
    }
    public function edit_explain_info($id,$coin_explain,$btc_explain,$eth_explain,$ltc_explain){
        return xlink("109300",array($id,$coin_explain,$btc_explain,$eth_explain,$ltc_explain),0,0);
    }

    /**
     * Notes: 获取站点所有币种
     * User: 张哲
     * Date: 2018/11/27
     * Time: 18:10
     */
    public function get_coin_asset($site_id){
        return xlink("401154",array($site_id));
    }

}
