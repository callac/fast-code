<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mail_tpl_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function get($uniqueid,$site_id){
        return xlink('202188',array($uniqueid,$site_id),0);
    }
}
