<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Checkaccount_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function get_lastday($asset,$snapshot_time){
        return xlink("501172",array($asset,$snapshot_time),0);
    }
    //获取当前币种在指定日期的资产详情 
    // public function get_snapshot($asset,$snapshot_time){
    //     return xlink("501172",array($asset,$snapshot_time),0);
    // }
    //当前币种在这个时间区间内的列表
    public function get_area_list($asset,$stime,$etime){
        return xlink("501173",array($asset,$stime,$etime));
    }
}
