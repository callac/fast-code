<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/12/14
 * Time: 21:04
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Wallet_users_asset_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 插入用户地址
     * User: 张哲
     * Date: 2018/12/14
     * Time: 21:34
     * @param $create_user_id
     * @param $time
     * @param $user_id
     * @return mixed
     */
    public function add_user_address($create_user_id,$create_address,$asset,$time,$balance){
        return xlink(402223,array($create_user_id,$create_address,$asset,$time,$balance),0);
    }
}