<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Transfer_product_hash_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function get_data_by_id($product_id,$site_id=null){
        return xlink("103100",array($product_id,$site_id),0);
    }


}
