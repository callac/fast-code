<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Rm_profit_loss_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //新增交易异常记录
    public function add($user_id,$out,$in,$rate,$start_asset,$created_at,$end_asset,$asset){
        return xlink(402207,array($user_id,$out,$in,$rate,$start_asset,$created_at,$end_asset,$asset),0);
    }


    /**
     * Notes: 获取c2c的所有记录
     * User: 张哲
     * Date: 2019-05-22
     * Time: 15:25
     */
    public function c2c($user_id,$type)
    {
        return xlink('601143', array($user_id,$type),0);
    }

    /**
     * Notes: 充值数据
     * User: 张哲
     * Date: 2019-05-22
     * Time: 16:59
     */
    public function recharge($user_id,$asset)
    {
        return xlink('601166', array($user_id,$asset),0);
    }

    /**
     * Notes: otc数据
     * User: 张哲
     * Date: 2019-05-22
     * Time: 16:59
     */
    public function otc($user_id,$type,$asset)
    {
        return xlink('601167', array($user_id,$type,$asset),0);
    }

    /**
     * Notes: 提现
     * User: 张哲
     * Date: 2019-05-22
     * Time: 16:59
     */
    public function withdraws($user_id,$asset)
    {
        return xlink('601168', array($user_id,$asset));
    }
}