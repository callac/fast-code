<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Site_roles_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }
    public function get_all(){
        return xlink('202108',array());
    }

    public function get_list_pid($pid)
    {
        return xlink(203126,array($pid));

    }

    public function update_site_roles($name,$lock){
        return xlink(204307,array($name,$lock));
    }
    public function update_site_roles_all(){
        return xlink(204308,array());
    }

}