<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Rm_transaction_alarm_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //新增交易异常记录
    public function add($start_time,$end_time,$market,$total_trading_amount,$user_trading_amount,$user_trading_ratio,$user_uid,$created_at,$site_id){
        return xlink(402203,array($start_time,$end_time,$market,$total_trading_amount,$user_trading_amount,$user_trading_ratio,$user_uid,$created_at,$site_id),0);
    }
}