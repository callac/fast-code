<?php
/**
 * Created by PhpStorm.
 * User: 63039
 * Date: 2018/4/20
 * Time: 14:17
 */
class User_post_addr_model extends Base_Model{
    function __construct()
    {

    }

    public function get_info_by_user_id($user_id){
       return  xlink("201113",array($user_id));
    }
}