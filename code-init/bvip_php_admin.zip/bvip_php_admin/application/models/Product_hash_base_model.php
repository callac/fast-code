<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Product_hash_base_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function add($hash,$time,$batch_area,$producer,$site_id,$product_img){
        return xlink('203209',array($hash,$time,$batch_area,$producer,$site_id,$product_img));
    }

    public function update($base_id,$hash,$batch_area,$producer,$product_img){
        return xlink('201308',array($base_id,$hash,$batch_area,$producer,$product_img));
    }
}
