<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Keylog_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }
    /**
     * 添加关键记录
     */
    public function add()
    {

    }
}