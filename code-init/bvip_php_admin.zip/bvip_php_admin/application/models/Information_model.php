<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Information_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //获取消息类型
    public function get_info_type($site_id){

        return xlink('301101',array($site_id));
    }

//    //添加消息
//    public function add_info($title,$msg,$msg_type_id,$created_at)
//    {
//        return xlink('301201',[$title,$msg,$msg_type_id,$created_at,$this->site_id]);
//    }

    //获取用户信息
    public function get_user_info($id)
    {
        return xlink('301102',array($id,$this->site_id));
    }

    //获取消息信息
    public function get_info($offset,$limit)
    {
        return xlink('301103',array($this->site_id,$offset,$limit));
    }

    //获取消息信息
    public function get_info_count()
    {
        return xlink('301104',array($this->site_id),0,0);
    }

    //新增
    public function notification_add($msg_type_id,$title,$msg,$site_id,$created_at,$user_id){
        return xlink('203208',array($msg_type_id,$title,$msg,$site_id,$created_at,$user_id),0,0);
    }

    //详情
    public function get_detail($id){
        return xlink('202129',array($id),0);
    }

    public function notification_class_update($id,$name,$site_id){
        return xlink('201309',array($id,$name,$site_id),0);
    }

    public function notification_class_add($name,$time,$site_id){
        return xlink('203210',array($name,$time,$site_id),0);
    }

    public function notification_class_delete($id){
        return xlink('201412',array($id),0);
    }

}
