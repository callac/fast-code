<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //角色详情
    public function admin_details($id){
        return xlink("204103",array($id),0);
    }
    //后台指用户的ip白名单列表
    public function admin_white_list($id){
        return xlink("501182",array($id),0);
    }
    //管理员列表
    public function admin_list($offset,$limit,$site_id){
        return xlink("204101",array($offset,$limit,$site_id));
    }
    //子站超管列表
    public function subadmin_list($offset,$limit,$sadmin){
        return xlink("204131",array($offset,$limit,$sadmin));
    }

    public function subadmin_list_bysiteid($offset,$limit,$sadmin,$site_id){
        return xlink("601177",array($offset,$limit,$sadmin,$site_id));
    }


    //管理员列表-统计
    public function admin_count($site_id){
        return xlink("204102",array($site_id),0,0);
    }

    //子站超管列表-统计
    public function subadmin_count($sadmin){
        return xlink("204132",array($sadmin),0,0);
    }
    //子站超管列表-统计+站点
    public function subadmin_count_bysiteid($sadmin,$site_id){
        return xlink("601178",array($sadmin,$site_id),0,0);
    }

    //管理员 禁用/启用
    public function admin_lock($id,$type){
        return xlink("204301",array($id,$type));
    }

    //查看该用户名是否存在
    public function get_admin_by_username($user_name){
        return xlink("204105",array($user_name),0);
    }

    //编辑
    public function admin_update($id,$user_name,$true_name,$email,$phone,$mobile,$site_id){
        return xlink("204302",array($id,$user_name,$true_name,$email,$phone,$mobile,$site_id));
    }

    public function admin_update1($id,$user_name,$true_name,$email,$phone,$mobile,$site_id,$admin_id){
        return xlink("402240",array($id,$user_name,$true_name,$email,$phone,$mobile,$site_id,$admin_id));
    }

    //新增
    public function admin_add($user_name,$password,$true_name,$email,$phone,$mobile,$site_id){
        return xlink("204200",array($user_name,$password,$true_name,$email,$phone,$mobile,$site_id));
    }

    //子站超管新增
    public function subadmin_add($user_name,$password,$true_name,$email,$phone,$mobile,$site_id,$sadmin){
        return xlink("204201",array($user_name,$password,$true_name,$email,$phone,$mobile,$site_id,$sadmin));
    }


    public function subadmin_add1($user_name,$password,$true_name,$email,$phone,$mobile,$site_id,$sadmin,$admin_id){
        return xlink("402239",array($user_name,$password,$true_name,$email,$phone,$mobile,$site_id,$sadmin,$admin_id));
    }

    //获取用户角色分组
    public function get_roles($user_id){
        return xlink("204111",array($user_id));
    }

    //新增管理员对应部门/岗位
    public function add_admin_roles($user_id,$role_id,$site_id){
        return xlink("204204",array($user_id,$role_id,$site_id));
    }

    //删除管理员对应部门/岗位
    public function delete_admin_roles($user_id){
        return xlink("201404",array($user_id));
    }

    public function delete_admin_roles_by_user($user_id){
        return xlink("201405",array($user_id));
    }
    public function delete_admin_by_user($user_id){
        return xlink("201406",array($user_id));
    }
    public function get_info_by_user_name($user_name){
        return xlink("204130",array($user_name),0);
    }
    //更新token
    public function update_user_token($user_id,$token,$time,$ip){
        return xlink("204309",array($user_id,$token,$time,$ip));
    }

    /**
     * Notes: 更新登录时间
     * User: 张哲
     * Date: 2019/3/19
     * Time: 13:56
     */
    public function update_user_login_time($user_id,$time,$ip,$token){
        return xlink("403328",array($user_id,$time,$ip,$token));
    }

    //更新token
    public function quit_token($user_id,$token){
        return xlink("204316",array($user_id,$token));
    }

    //更新password
    public function update_password($user_id,$password){
        $update_password_time=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        return xlink("204310",array($user_id,$password,$update_password_time),0);
    }

    public function login_roles_all($user_id){
        return xlink("204140",array($user_id));
    }

    /**
     * Notes: 获取管理员真实姓名
     * User: 张哲
     * Date: 2018/11/22
     * Time: 14:26
     * @param $user_id
     * @return mixed
     */
    public function get_admin_name($user_id){
        return xlink("401145",array($user_id),0);
    }

    //更新切换语言
    public function switch_language($admin_id,$language){
        return xlink("501369",array($admin_id,$language),0);
    }

    /**
     * Notes: 验证验证码是否正确
     * User: 张哲
     * Date: 2019/3/14
     * Time: 15:02
     */
    public function verification_code($account,$code){
        return xlink("601123",array($account,$code),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/14
     * Time: 15:19
     * @param $account
     * @param $code
     * @return mixed
     */
    public function find($user_name,$account){
        return xlink("601124",array($user_name,$account),0);
    }
    public function find2($user_name,$account){
        return xlink("601130",array($user_name,$account),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/15
     * Time: 14:06
     * @param $user_name
     * @return mixed
     */
    public function admin_message($user_name){
        return xlink("601126",array($user_name),0);

    }

    public function admin_message1($user_id){
        return xlink("601127",array($user_id),0);

    }


    /**
     * Notes: 查看邮箱是否重复
     * User: 张哲
     * Date: 2019/3/18
     * Time: 09:48
     * @param $email
     * @return mixed
     */
    public function get_admin_by_email($email){
        return xlink("601128",array($email),0);
    }


    /**
     * Notes: 查看手机是否重复
     * User: 张哲
     * Date: 2019/3/18
     * Time: 09:48
     * @param $mobile
     * @return mixed
     */
    public function get_admin_by_mobile($mobile){
        return xlink("601129",array($mobile),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/20
     * Time: 15:19
     * @param $mobile
     * @return mixed
     */
    public function failure_frequency($user_name,$failure_frequncy){
        return xlink("403331",array($user_name,$failure_frequncy),0);
    }


    /**
     * Notes: 获取失败次数
     * User: 张哲
     * Date: 2019/3/20
     * Time: 15:42
     * @param $user_name
     * @return mixed
     */
    public function failure_frequency_count($user_name){
        return xlink("601130",array($user_name),0);
    }

    /**
     * Notes: 次数设置为0
     * User: 张哲
     * Date: 2019/3/20
     * Time: 15:53
     * @param $user_name
     * @return mixed
     */
    public function modify_frequency($user_name,$number){
        return xlink("403332",array($user_name,$number),0);
    }

    /**
     * Notes: 检查账号是否存在
     * User: 张哲
     * Date: 2019/3/28
     * Time: 14:37
     * @param $user_name
     * @return mixed
     */
    public function name($user_name){
        return xlink("601133",array($user_name),0);
    }


    /**
     * Notes: h获取参数配置过期时间
     * User: 张哲
     * Date: 2019-06-28
     * Time: 14:52
     * @return mixed
     */
    public function expire_date(){
        return xlink("601170",array(),0);
    }
}