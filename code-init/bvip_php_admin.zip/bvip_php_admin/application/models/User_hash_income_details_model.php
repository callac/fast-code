<?php
/**
 * Created by PhpStorm.
 * User: 63039
 * Date: 2018/4/20
 * Time: 14:17
 */
class User_hash_income_details_model extends Base_Model{
    function __construct()
    {

    }

    public function get_info_by_user_id($user_id,$status){
       return  xlink("201115",array($user_id,$status));
    }

    public function get_data_by_hash_income_id($hash_income_id){
       return  xlink("101100",array($hash_income_id));
    }

    public function update_info($id,$payable_amount,$electric_fee,$trust_fee,$procedure_fee){
       return  xlink("101300",array($id,$payable_amount,$electric_fee,$trust_fee,$procedure_fee));
    }

    public function check_access($hash_income_id,$status){
       return  xlink("101301",array($hash_income_id,$status),0,0);
    }

    public function transfer_done($hash_income_id,$status,$paid_amount,$paid_time){
       return  xlink("101302",array($hash_income_id,$status,$paid_amount,$paid_time),0,0);
    }


}