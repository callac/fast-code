<?php
/**
 * Created by PhpStorm.
 * User: 63039
 * Date: 2018/4/20
 * Time: 14:05
 */
class Account_btc_bind_address_model extends Base_model{
    function __construct()
    {
        parent::__construct();
    }

    //提币地址
    public function get_info_by_user_id($user_id){
        return xlink("201112",array($user_id));
    }
}