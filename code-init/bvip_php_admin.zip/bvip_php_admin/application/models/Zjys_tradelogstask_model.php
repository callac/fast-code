<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_tradelogstask_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //新增币资产种类sql
    public function add($time_area,$symbol,$start_time,$end_time,$total,$number,$BID_fee,$ASK_fee,$created_at){
        return xlink(501212,array($time_area,$symbol,$start_time,$end_time,$total,$number,$BID_fee,$ASK_fee,$created_at),0);
    }

    public function sssssinsert($sssssinsert){
        return xlink(501214,array($sssssinsert),0);
    }


}
