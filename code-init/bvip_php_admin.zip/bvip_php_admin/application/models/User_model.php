<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取用户详情
    public function get_info($user_id){
        return xlink(201111,array($user_id),0);
    }

    //统计用户数量
    public function get_count($site_id,$start,$end){
        return xlink(201116,array($site_id,$start,$end),0,0);
    }

    //禁止登陆/允许登陆
    public function update_forbid_login($user_id,$type){
        return xlink(201301,array($user_id,$type),0);
    }
    //禁止交易/允许交易
    public function update_forbid_withdraw($user_id,$type){
        return xlink(201302,array($user_id,$type),0);
    }
    //禁止提现/允许提现
    public function update_forbid_trade($user_id,$type){
        return xlink(201303,array($user_id,$type),0);
    }

    //更新用户token信息
    public function update_user_token($user_id,$token){
        return xlink(201316,array($user_id,$token));
    }

    //资金解冻
    public function capital_unfreeze($user_id,$amount)
    {
    	return xlink(403309,array($user_id,$amount),0);
    }

    //提现审核失败资金解冻并还原余额
    public function capital_unfreeze_back_account($user_id,$amount)
    {
    	return xlink(403310,array($user_id,$amount),0);
    }

    //银行卡充值更新余额
    public function update_user_balance($user_id,$balance)
    {
        return xlink(201314,array($user_id,$balance),0);
    }


    //根据站点获取 所有用户id
    public function get_user_info_by_site($site_id){
        return xlink(201117,array($site_id));
    }

    //根據手機號獲取用戶信息
    public function get_info_by_mobile($str){
        return xlink(201118,array($str),0);
    }
    //根據郵箱號獲取用戶信息
    public function get_info_by_email($str){
        return xlink(201119,array($str),0);
    }

    /**
     * Notes: 推送数据获取
     * User: 张哲
     * Date: 2019-06-25
     * Time: 11:28
     */
    public function push($str){
        return xlink(601169,array($str),0);
    }


}
