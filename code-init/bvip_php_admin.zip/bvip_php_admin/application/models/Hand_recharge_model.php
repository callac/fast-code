<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Hand_recharge_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    

    public function update($bdc_name,$content,$site_id,$id){
        return xlink("301304",[$bdc_name,$content,$site_id,$id]);
    }

    public function add($bdc_name,$content,$created_at,$site_id){
        return xlink("301205",[$bdc_name,$content,$created_at,$site_id]);
    }

}
