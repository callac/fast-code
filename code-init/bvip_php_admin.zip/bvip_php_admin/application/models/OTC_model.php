<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/2/27
 * Time: 14:58
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class OTC_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 获取otc订单详情
     * User: 张哲
     * Date: 2019/2/27
     * Time: 14:58
     * @param $id
     * @return mixed
     */
    public function get_otcorder_info($id)
    {
        return xlink(601107, array($id), 0);
    }

    /**
     * Notes: 修改财务状态
     * User: 张哲
     *
     *
     *
     * Date: 2019/2/27
     * Time: 19:23
     * @param $id
     * @param $status
     * @return mixed
     */
    public function update_caiwu_status($id,$status)
    {
        return xlink(403320,array($id,$status),0);
    }

    /**
     * Notes: 修改订单状态
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:03
     */
    public function update_status($id,$status,$created_at){
        return xlink(403321,array($id,$status,$created_at),0);
    }

    /**
     * Notes: 增加时间记录
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:02
     */
    public function add_event($created_at,$updated_at,$name,$ip,$endpoint,$params){
        return xlink(402229,array($created_at,$updated_at,$name,$ip,$endpoint,$params),0);
    }

    /**
     * Notes: 增加用户冻结记录
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:02
     */
    public function add_aseet_fressze($created_at, $updated_at, $user_id, $asset, $amount, $business, $balance, $detail)
    {
        return xlink('402228', array($created_at, $updated_at, $user_id, $asset, $amount, $business, $balance, $detail), 0);
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/2/28
     * Time: 19:29
     */
    public function get_info_per_user($m_bank_id,$type,$status,$name)
    {
        return xlink(601108,array($m_bank_id,$type,$status,$name));
    }


    /**
     * Notes: 获取当前订单已经完成的数量
     * User: 张哲
     * Date: 2019/3/2
     * Time: 14:55
     * @param $id
     */
    public function complete_amount($id){
        return xlink(601111,array($id),0);
    }

    public function complete_amount1($id){
        return xlink(601112,array($id),0);
    }

    /**
     * Notes: 获取
     * User: 张哲
     * Date: 2019/3/5
     * Time: 20:27
     * @param $id
     * @return mixed
     */
    public function get_status($id){
        return xlink(601113,array($id),0);
    }

    public function mer_list($id){
        return xlink(601114,array($id),0);
    }

    /**
     * Notes: 审核拒绝修改余额
     * User: 张哲
     * Date: 2019/3/6
     * Time: 14:32
     * @param $id
     * @return mixed
     */
    public function update_amount($amount,$id){

        return xlink(403323,array($amount,$id),0);
    }


    public function bank_card($user_id){

        return xlink(601115,array($user_id),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/11
     * Time: 06:58
     */
    public function other_card($user_id,$type){

        return xlink(601116,array($user_id,$type),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/11
     * Time: 09:18
     * @param $user_id
     * @return mixed
     */
    public function bank_card1($user_id){

        return xlink(601117,array($user_id),0);
    }

    public function complete_count($user_id){

        return xlink(601122,array($user_id),0);
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/22
     * Time: 14:26
     * @param $user_id
     * @return mixed
     */
    public function otc_asset_update($site_id,$asset,$otc_true){

        return xlink(403333,array($site_id,$asset,$otc_true),0);
    }


}

