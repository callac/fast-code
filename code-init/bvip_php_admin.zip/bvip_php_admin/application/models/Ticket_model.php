<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Ticket_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取提现记录详情
    public function ticket_message_reply($ticket_id,$message,$attach,$created_at,$updated_at){
        return xlink(501245,array($ticket_id,$message,$attach,$created_at,$updated_at,1),0);
    }

    public function ticket_close($id,$time,$status=2)
    {
        return xlink(501379,array($id,$time,$status),0);
    }

    public function ticket_detail($ticket_id)
    {
        return xlink("501175",[$ticket_id],0);
    }

    public function ticket_status($status,$ticket_id)
    {
        return xlink(501380,array($status,$ticket_id),0);
    }
}
