<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Security_bulid_hash_model extends CI_model
{
	public function __construct()
	{
		parent::__construct();
	}
	//提现添加保全记录
	 public function add_baoquan_detail($user_id,$id)
    {
        return xlink(403202,array($user_id,$id,0,5),0,0);
    }

    //提现添加保全记录
	 public function add_baoquan_ticoin_detail($user_id,$id)
    {
        return xlink(404202,array($user_id,$id,0,6),0,0);
    }

    public function add_baoquan_recharge($user_id,$id)
    {
        return xlink(404202,array($user_id,$id,0,4),0,0);
    }


}
