<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_user_operationmoney_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取提现记录详情
    public function add($operation_admin_id,$time,$asset_code,$amount,$user_id,$extra,$site_id,$type){
        // var_dump($type);die;
        return xlink(501205,array($operation_admin_id,$time,$asset_code,$amount,$user_id,$extra,$site_id,$type),0);
    }
}
