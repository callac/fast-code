<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class user_notification_model extends Base_model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function add($user_id,$title,$text,$msg_type_id,$time){
		return xlink(202210,array($user_id,$title,$text,$msg_type_id,$time,$this->site_id));
	}

	public function get_notification_detail($id){
		
		return xlink('402102',array($id,$this->site_id),0);
	}

	public function add_notification($user_id,$title,$text,$site_id,$msg_type_id,$is_view,$time){
		return xlink(202212,array($user_id,$title,$text,$msg_type_id,$is_view,$time,$site_id));
	}


	public function add_admin_operationlogs($admin_id,$user_id,$operation_type,$time,$description,$business_id,$ip,$detail){
		return xlink(202213,array($admin_id,$user_id,$operation_type,$time,$description,$business_id,$ip,$detail));
	}


	public function add_admin_operbanklogs($admin_id,$m_bank_id,$type,$description,$time){
		return xlink(202214,array($admin_id,$m_bank_id,$type,$description,$time));
	}








}
