<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/12/19
 * Time: 15:53
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Wallet_snapshot_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/12/19
     * Time: 15:56
     * @param $created_at
     * @param $asset
     * @param $wallet_id
     * @param $balance
     * @param $amount
     * @param $collectAmount
     * @param $collectCount
     * @param $freeze
     * @param $plaform
     * @return mixed,$arr['rechargeAmount'],$arr['rechargeCount'],$arr['withdrawAmount'],$arr['withdrawCount']
     */
    public function add($created_at,$asset,$wallet_id,$balance,$amount,$collectAmount,$collectCount,$freeze,$plaform,$rechargeAmount,$rechargeCount,$withdrawAmount,$withdrawCount,$platFeeAmount,$platRechargeAmount){
        return xlink(402225,array($created_at,$asset,$wallet_id,$balance,$amount,$collectAmount,$collectCount,$freeze,$plaform,$rechargeAmount,$rechargeCount,$withdrawAmount,$withdrawCount,$platFeeAmount,$platRechargeAmount),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/12/19
     * Time: 15:56
     * @param $created_at
     * @param $asset
     * @param $wallet_id
     * @param $balance
     * @param $amount
     * @param $collectAmount
     * @param $collectCount
     * @param $freeze
     * @param $plaform
     * @return mixed
     */
    public function update($created_at,$asset,$wallet_id,$balance,$amount,$collectAmount,$collectCount,$freeze,$plaform,$rechargeAmount,$rechargeCount,$withdrawAmount,$withdrawCount,$platFeeAmount,$platRechargeAmount){
        return xlink(403316,array($created_at,$asset,$wallet_id,$balance,$amount,$collectAmount,$collectCount,$freeze,$plaform,$rechargeAmount,$rechargeCount,$withdrawAmount,$withdrawCount,$platFeeAmount,$platRechargeAmount),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/12/19
     * Time: 16:04
     * @param $asset
     * @return mixed
     */
    public function check($asset){
        return xlink(401168,array($asset),0);
    }

    public function count(){
        return xlink(401171,array(),0);
    }

}
