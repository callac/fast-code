<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Merchant_account_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    //新增银行卡
    public function addbank($name,$bank,$sub_bank,$card_number,$created_at,$updated_at,$status,$site_id,$type,$limit_money_high,$cash_deposit,$contact_way,$admin_id,$alipay_number,$alipay_name,$alipay_image,$wechat_number,$wechat_name,$wechat_image,$limit_money_low,$pay_method,$price,$amount,$transaction_number){
        return xlink(501248,array($name,$bank,$sub_bank,$card_number,$created_at,$updated_at,$status,$site_id,$type,$limit_money_high,$cash_deposit,$contact_way,$admin_id,$alipay_number,$alipay_name,$alipay_image,$wechat_number,$wechat_name,$wechat_image,$limit_money_low,$pay_method,$price,$amount,$transaction_number),0);
    }

    //修改银行卡
    public function editbank($name,$bank,$sub_bank,$card_number,$updated_at,$id,$site_id,$type,$limit_money_high,$cash_deposit,$contact_way,$admin_id,$alipay_number,$alipay_name,$alipay_image,$wechat_number,$wechat_name,$wechat_image,$limit_money_low,$pay_method,$price,$amount,$transaction_number){
        return xlink(501385,array($name,$bank,$sub_bank,$card_number,$updated_at,$id,$site_id,$type,$limit_money_high,$cash_deposit,$contact_way,$admin_id,$alipay_number,$alipay_name,$alipay_image,$wechat_number,$wechat_name,$wechat_image,$limit_money_low,$pay_method,$price,$amount,$transaction_number),0);
    }

    //删除银行卡
    public function deletebank($status,$id)
    {
        return xlink(501386,array($status,$id),0);
    }
    //获取财务输入的信息
    public function get_bankinout_detail($id)
    {
        return xlink(501179,array($id),0);
    }
    //添加财务信息
    public function addflows($m_bank_id,$user_bank_number,$user_name,$amount,$type,$created_at,$updated_at,$trans_remark,$remark,$status,$site_id)
    {
        return xlink(501249,array($m_bank_id,$user_bank_number,$user_name,$amount,$type,$created_at,$updated_at,$trans_remark,$remark,$status,$site_id),0);
    }

     //修改财务信息
    public function editflows($m_bank_id,$user_bank_number,$user_name,$amount,$type,$updated_at,$trans_remark,$remark,$status,$id,$site_id)
    {
        return xlink(501387,array($user_bank_number,$user_name,$amount,$type,$updated_at,$trans_remark,$remark,$status,$id,$site_id),0);
    }

    public function get_info_per_user($m_bank_id,$type,$status,$name)
    {
        return xlink(501125,array($m_bank_id,$type,$status,$name));
    }


    public function update_caiwu_status($id,$status)
    {
        return xlink(501321,array($id,$status),0);
    }

    // 
    public function get_total_money($m_bank_id,$status,$type)
    {
        return xlink(501178,array($m_bank_id,$status,$type),0);
    }

    public function is_true_card($card_number)
    {
        return xlink(501151,array($card_number),0);
    }

    public function get_link_cardnumber($admin_id)
    {
        return xlink(501180,array($admin_id));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/13
     * Time: 09:34
     * @param $sort
     */
    public function mer_sort($sort,$var_name){
        return xlink(403324,array($sort,$var_name));
    }

    public function sort_value($var_name){
        return xlink(601118,array($var_name));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/13
     * Time: 10:58
     * @param $var_name
     * @return mixed
     */
    public function modify_trade_count($trade_account,$merchant_id){
        return xlink(403325,array($trade_account,$merchant_id));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/13
     * Time: 13:11
     * @param $trade_account
     * @param $merchant_id
     * @return mixed
     */

    public function modify_sort($merchant_id,$sort_id){
        return xlink(403326,array($merchant_id,$sort_id));
    }

    public function modify_sort1($sort_id,$merchant_id){
        return xlink(403327,array($sort_id,$merchant_id));
    }


    /**
     * Notes: 寻找对应id
     * User: 张哲
     * Date: 2019/3/13
     * Time: 13:50
     * @param $sort_id
     * @return mixed
     */
    public function find_id($sort_id){
        return xlink(601119,array($sort_id));
    }

    public function max_id(){
        return xlink(601120,array());
    }

    public function min_id(){
        return xlink(601121,array());
    }
}
