<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Site_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }
    public function get_list($offset,$limit,$site_name,$site_id){
        if($site_id==''){
            return xlink('202106',array($offset,$limit,$site_name));
        }else{
            return xlink('202123',array($offset,$limit,$site_name,$site_id));
        }
    }

    public function get_count($site_name){
        return xlink('202107',array($site_name),0,0);
    }

    public function site_all(){
        return xlink('202109',array());
    }

    public function site_one($id){
        return xlink('202131',array($id));
    }

    public function add($site_name,$title,$logo,$icon,$style,$language,$roles,$remark,$asset_type,$symbol_type,$service_email,$service_js,$tongji_js,$ios_url,$android,$qq,$udesk_js,$udesk_key){
        return xlink('203202',array($site_name,$title,$logo,$icon,$style,$language,$roles,$remark,$asset_type,$symbol_type,$service_email,$service_js,$tongji_js,$ios_url,$android,$qq,$udesk_js,$udesk_key));
    }
    public function update($site_id,$site_name,$title,$logo,$icon,$style,$language,$roles,$remark,$asset_type,$symbol_type,$service_email,$service_js,$tongji_js,$ios_url,$android_url,$qq,$udesk_js,$udesk_key){
        return xlink('201201',array($site_id,$site_name,$title,$logo,$icon,$style,$language,$roles,$remark,$asset_type,$symbol_type,$service_email,$service_js,$tongji_js,$ios_url,$android_url,$qq,$udesk_js,$udesk_key));
    }

    public function site_close($id,$type){
        return xlink('201313',array($id,$type));
    }

    public function site_delete($id){
        return xlink('201413',array($id));
    }

}