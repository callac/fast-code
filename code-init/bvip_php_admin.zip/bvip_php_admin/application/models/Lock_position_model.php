<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Lock_position_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取详情
    public function record_info($id)
    {
        return xlink('601179',array($id),0);
    }
}
