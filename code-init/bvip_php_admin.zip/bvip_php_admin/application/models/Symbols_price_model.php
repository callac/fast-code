<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-04-29
 * Time: 17:14
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Symbols_price_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function add($time,$symbol,$price)
    {
        return xlink('402238', array($time,$symbol,$price));
    }


    /**
     * Notes: 获取当天存储币价
     * User: 张哲
     * Date: 2019-05-05
     * Time: 16:18
     */
    public function check_symbol($symbol,$time)
    {
        return xlink('601142', array($symbol,$time));
    }

    /**
     * Notes: 获取c2c记录
     * User: 张哲
     * Date: 2019-05-06
     * Time: 10:29
     */
    public function c2c($user_id,$type)
    {
        return xlink('601143', array($user_id,$type));
    }

    /**
     * Notes: 获取单个用户充值记录
     * User: 张哲
     * Date: 2019-05-06
     * Time: 15:44
     */
    public function recharge($user_id)
    {
        return xlink('601144', array($user_id));
    }

    /**
     * Notes: 活动入金
     * User: 张哲
     * Date: 2019-05-06
     * Time: 16:11
     */
    public function activity_in($user_id)
    {
        return xlink('601145', array($user_id));
    }



    /**
     * Notes: 后台调整资金
     * User: 张哲
     * Date: 2019-05-06
     * Time: 16:48
     */
    public function admin_in($user_id)
    {
        return xlink('601146', array($user_id));
    }


    /**
     * Notes: otc
     * User: 张哲
     * Date: 2019-05-06
     * Time: 16:56
     */
    public function otc($user_id,$type)
    {
        return xlink('601147', array($user_id,$type));
    }


    /**
     * Notes: 活动出金
     * User: 张哲
     * Date: 2019-05-06
     * Time: 17:08
     */
    public function activity_out($user_id)
    {
        return xlink('601148', array($user_id));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019-05-06
     * Time: 17:11
     */
    public function admin_out($user_id)
    {
        return xlink('601149', array($user_id));
    }

    /**
     * Notes: 提现记录总和
     * User: 张哲
     * Date: 2019-05-06
     * Time: 17:31
     */
    public function withdraws($user_id)
    {
        return xlink('601150', array($user_id));
    }

    /**
 * 列表-全部数据******************************************************
 */
    /**
     * Notes: 用户提币-列表-按币种
     * User: 张哲
     * Date: 2019-05-06
     * Time: 19:27
     */
    public function withdraws_list($user_id)
    {
        return xlink('601151', array($user_id));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019-05-06
     * Time: 19:34
     */
    public function recharge_list($user_id)
    {
        return xlink('601152', array($user_id));
    }

    /**
     * Notes: 活动列表
     * User: 张哲
     * Date: 2019-05-06
     * Time: 19:46
     */
    public function activity_list($user_id)
    {
        return xlink('601153', array($user_id));
    }


    /**
     * Notes:  后台资金调整列表
     * User: 张哲
     * Date: 2019-05-06
     * Time: 19:53
     */
    public function admin_list($user_id)
    {
        return xlink('601154', array($user_id));
    }

    /**
     * Notes: otc
     * User: 张哲
     * Date: 2019-05-06
     * Time: 20:02
     */
    public function otc_list($user_id,$asset)
    {
        return xlink('601155', array($user_id,$asset));
    }

    /**
     * Notes: c2c
     * User: 张哲
     * Date: 2019-05-06
     * Time: 20:03
     */
    public function c2c_list($user_id,$asset)
    {
        return xlink('601156', array($user_id,$asset));
    }

    /**
     * 列表-按币种数据******************************************************
     */
    /**
     * Notes: 用户提币-列表-按币种
     * User: 张哲
     * Date: 2019-05-06
     * Time: 19:27
     */
    public function withdraws_asset_list($user_id,$asset)
    {
        return xlink('601157', array($user_id,$asset));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019-05-06
     * Time: 19:34
     */
    public function recharge_asset_list($user_id,$asset)
    {
        return xlink('601158', array($user_id,$asset));
    }

    /**
     * Notes: 活动列表
     * User: 张哲
     * Date: 2019-05-06
     * Time: 19:46
     */
    public function activity_asset_list($user_id,$asset)
    {
        return xlink('601159', array($user_id,$asset));
    }


    /**
     * Notes:  后台资金调整列表
     * User: 张哲
     * Date: 2019-05-06
     * Time: 19:53
     */
    public function admin_asset_list($user_id,$asset)
    {
        return xlink('601160', array($user_id,$asset));
    }


    /**
     * Notes: otc
     * User: 张哲
     * Date: 2019-05-06
     * Time: 20:02
     */
    public function otc_asset_list($user_id,$type,$asset)
    {
        return xlink('601161', array($user_id,$type,$asset));
    }

    /**
     * Notes: c2c
     * User: 张哲
     * Date: 2019-05-06
     * Time: 20:03
     */
    public function c2c_asset_list($user_id,$type)
    {
        return xlink('601162', array($user_id,$type));
    }

    public function c2c_sell($user_id)
    {
        return xlink('601163', array($user_id));
    }


    /**
     * Notes:  获取该币种所有交易对
     * User: 张哲
     * Date: 2019-05-20
     * Time: 11:32
     */
    public function check_symbol1($asset,$time)
    {
        return xlink('601164', array($asset,$time));
    }
}