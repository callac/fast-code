<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/11/23
 * Time: 17:40
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Platfrom_gift_coin_record_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/23
     * Time: 17:40
     */
    public function add($operator,$created_at,$asset,$amount,$user_id,$remark,$site_id,$total_account_id,$lock,$expire_time){

        return xlink(402214,array($operator,$created_at,$asset,$amount,$user_id,$remark,$site_id,$total_account_id,$lock,$expire_time),0);
    }


    public function add1($operator,$created_at,$asset,$amount,$user_id,$remark,$site_id,$total_account_id,$lock){
        return xlink(402227,array($operator,$created_at,$asset,$amount,$user_id,$remark,$site_id,$total_account_id,$lock),0);
    }


    /**
     * Notes: 赠币数据存储
     * User: 张哲
     * Date: 2019/3/27
     * Time: 17:13
     */
    public function save_data($user_id,$asset,$amount,$remark,$lock,$expire_time,$site_id){
        return xlink(402232,array($user_id,$asset,$amount,$remark,$lock,$expire_time,$site_id),0);
    }

    /**
     * Notes: 赠送后修改状态
     * User: 张哲
     * Date: 2019/3/27
     * Time: 17:54
     */
    public function update_data($asset,$amount,$user_id,$remark,$lock){
        return xlink(403335,array($asset,$amount,$user_id,$remark,$lock),0);
    }
}
