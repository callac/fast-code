<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Site_domain_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function site_info(){
        return xlink(202104,array());
    }
    public function get_list_by_site_id($site_id){
        return xlink(202113,array($site_id));
    }

    public function get_site_info($domain)
    {
        return xlink(202101,array($domain),0);

    }

    public function get_site($site_id)
    {
        return xlink(202102,array($site_id),0,0);

    }
    public function add($domain_url,$site_name,$site_id){

        return xlink(203203,array($domain_url,$site_name,$site_id),0,0);
    }

    public function update($id,$domain_url,$site_name){
        return xlink(201202,array($id,$domain_url,$site_name),0,0);
    }
    public function delete($id){
        return xlink(201403,array($id));
    }

    public function delete_all_by_site($site_id){
        return xlink(201407,array($site_id));
    }


}