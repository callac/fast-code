<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Order_miner_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取订单详情
    public function get_detail($order_id){
        return xlink('203104',array($order_id),0);
    }
    //获取算力交易信息 成功的
    public function get_info_by_user_id($user_id,$status){
        return xlink('203103',array($user_id,$status),0);
    }

    //矿机待发货
    public function miner_waiting($site_id,$status,$start,$end){
        return xlink('204121',array($site_id,$status,$start,$end),0,0);
    }

}