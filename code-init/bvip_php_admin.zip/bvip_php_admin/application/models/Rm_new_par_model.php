<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-04-24
 * Time: 14:56
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Rm_new_par_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 查找大额临界值
     * User: 张哲
     * Date: 2019-04-24
     * Time: 15:48
     */
    public function large_amount_value($status)
    {
        return xlink("601139", array($status), 0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019-04-24
     * Time: 15:50
     */
    public function add_large_amount($amount,$user_id,$cerated_at,$site_id,$status)
    {
        return xlink("402236", array($amount,$user_id,$cerated_at,$site_id,$status), 0);
    }


    public function add_withdraws_wallet($created_at,$user_id,$asset,$address_id,$amount,$time,$site_id)
    {
        return xlink("402237", array($created_at,$user_id,$asset,$address_id,$amount,$time,$site_id), 0);
    }


    /**
     * Notes: 查看该条数据是否存在
     * User: 张哲
     * Date: 2019-05-21
     * Time: 16:26
     */
    public function check_exist($user_id,$asset,$address_id,$amount,$time,$site_id)
    {
        return xlink("601165", array($user_id,$asset,$address_id,$amount,$time,$site_id), 0);
    }

//    /**
//     * Notes: 查看参数是否存在
//     * User: 张哲
//     * Date: 2019-04-25
//     * Time: 10:58
//     */
//    public function is_exist($status)
//    {
//        return xlink("601135", array($status), 0);
//    }



}