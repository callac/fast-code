<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User_white_list_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取用户详情
    public function find_phone($phone){
        return xlink(401135,array($phone),0);
    }

     //获取用户详情
    public function check_phone($phone){
        return xlink(401136,array($phone),0);
    }

    //增加记录
    public function add_white_record($phone,$site_id,$created_at){
        return xlink(402209,array($phone,$site_id,$created_at),0);
    }


    //修改记录
    public function update_white_record($phone,$site_id,$created_at,$id){
        return xlink(403304,array($phone,$site_id,$created_at,$id),0);
    }

    //修改记录
    public function user_white_delete($phone,$site_id,$created_at,$id){
        return xlink(403305,array($phone,$site_id,$created_at,$id),0);
    }
}