<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_c2corder_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取c2c订单详情
    public function get_c2corder_info($id){
        return xlink(501104,array($id),0);
    }

    //改变提币状态
    public function update_status($id,$status,$created_at,$process_time){
        return xlink(501306,array($id,$status,$created_at,$process_time),0);
    }

    //消除c2c表里的冻结资金（将balance置为0）
    public function unfreezen_c2c($asset,$user_id,$amount){
        return xlink(501307,array($asset,$user_id,$amount),0);
    }

    //获取c2c_freeze订单详情
    public function getinfo($assets,$user_id){
        return xlink(501106,array($assets,$user_id),0);
    }

    public function add_event($created_at,$updated_at,$name,$ip,$endpoint,$params){
        return xlink(501210,array($created_at,$updated_at,$name,$ip,$endpoint,$params),0);
    }

    public function in_total($start_time,$end_time,$offset,$limit,$type,$site_id)
    {
        return xlink(501119,array($start_time,$end_time,$offset,$limit,$type,$site_id));
    }

    public function in_total_count($start_time,$end_time,$type,$site_id)
    {
        return xlink(501120,array($start_time,$end_time,$type,$site_id));
    }

    public function total($type,$site_id,$stime,$etime,$offset,$limit)
    {
        return xlink(501121,array($type,$site_id,$stime,$etime,$offset,$limit));
    }

    public function total_reality($type,$site_id,$stime,$etime,$offset,$limit)
    {
        return xlink('501122',array($type,$site_id,$stime,$etime,$offset,$limit));
    }
    // public function out_total($start_time,$end_time,$offset,$limit,$type,$site_id)
    // {
    //     return xlink(501119,array($start_time,$end_time,$offset,$limit,$type,$site_id));
    // }

    //
    public function get_user_bankcard($user_id)
    {
        return xlink('501123',array($user_id));
    }


    // public function get_totalamount_per_merchantbank($m_bank_id,$type)
    // {
    //     return xlink('501124',array($m_bank_id,$type));
    // }

    //  public function get_totalamount_per_merchantbank_reality($m_bank_id,$type)
    // {
    //     return xlink('501125',array($m_bank_id,$type));
    // }












    

    //统计用户数量
    public function get_count($site_id,$start,$end){
        return xlink(201116,array($site_id,$start,$end),0,0);
    }

    //禁止登陆/允许登陆
    public function update_forbid_login($user_id,$type){
        return xlink(201301,array($user_id,$type),0);
    }
    //禁止交易/允许交易
    public function update_forbid_withdraw($user_id,$type){
        return xlink(201302,array($user_id,$type),0);
    }
    //禁止提现/允许提现
    public function update_forbid_trade($user_id,$type){
        return xlink(201303,array($user_id,$type),0);
    }

    //更新用户token信息
    public function update_user_token($user_id,$token){
        return xlink(201316,array($user_id,$token));
    }

    //资金解冻
    public function capital_unfreeze($user_id,$amount)
    {
        return xlink(403309,array($user_id,$amount),0);
    }

    //提现审核失败资金解冻并还原余额
    public function capital_unfreeze_back_account($user_id,$amount)
    {
        return xlink(403310,array($user_id,$amount),0);
    }

    //银行卡充值更新余额
    public function update_user_balance($user_id,$balance)
    {
        return xlink(201314,array($user_id,$balance),0);
    }


    //根据站点获取 所有用户id
    public function get_user_info_by_site($site_id){
        return xlink(201117,array($site_id));
    }

    //根據手機號獲取用戶信息
    public function get_info_by_mobile($str){
        return xlink(201118,array($str),0);
    }
    //根據郵箱號獲取用戶信息
    public function get_info_by_email($str){
        return xlink(201119,array($str),0);
    }




    /**
     * 获取c2c订单详情
     * @Author   张哲
     * @DateTime 2018-10-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $id [description]
     * @return   [type]           [description]
     */
    public function get_c2corder($asset,$user_id){
        return xlink(401122,array($asset,$user_id),0);
    }

    /**
     * Notes: 数据可视化-实时实名认证数据
     * User: 张哲
     * Date: 2019/1/8
     * Time: 14:32
     * @param $start_time
     * @param $end_time
     * @return mixed
     */
    public function real_data_c2c_order($start_time,$end_time,$type,$site_id){
        return xlink("401172",array($start_time,$end_time,$type,$site_id),0);
    }

    public function real_data_c2c_order1($start_time,$end_time,$type){
        return xlink("401174",array($start_time,$end_time,$type),0);
    }



    /**
     * Notes: 数据可视化-用户总览c2c数据
     * User: 张哲
     * Date: 2019/1/9
     * Time: 17:25
     * @param $type
     * @param $site_id
     * @return mixed
     */
    public function c2c_order_all($site_id){
        return xlink("401178",array($site_id),0);
    }

    /**
     * Notes: 买入总数-站点
     * User: 张哲
     * Date: 2019-03-29
     * Time: 17:46
     */
    public function c2c_order_all_sell($site_id){
        return xlink("601137",array($site_id),0);
    }


    public function c2c_order_all1(){
        return xlink("401179",array(),0);
    }

    /**
     * Notes: 买入总数
     * User: 张哲
     * Date: 2019-03-29
     * Time: 17:46
     */
    public function c2c_order_all_sell1(){
        return xlink("601136",array(),0);
    }

    public function c2c_order_time($start_time,$end_time,$site_id){
        return xlink("401180",array($start_time,$end_time,$site_id),0);
    }

    /**
     * Notes: 查询买入人数-查询运维统计
     * User: 张哲
     * Date: 2019-03-29
     * Time: 17:11
     */
    public function c2c_order_sell($start_time,$end_time,$site_id){
        return xlink("601134",array($start_time,$end_time,$site_id),0);
    }

    public function c2c_order_time1($start_time,$end_time){
        return xlink("401181",array($start_time,$end_time),0);
    }

    public function c2c_order_sell1($start_time,$end_time){
        return xlink("601135",array($start_time,$end_time),0);
    }

    /**
     * Notes: 数据可视化-交易统计-c2c交易数据
     * User: 张哲
     * Date: 2019/1/15
     * Time: 09:52
     * @param $start_time
     * @param $end_time
     * @param $type
     * @param $site_id
     * @return mixed
     */
    public function c2c_trade_buy($start_time,$end_time,$site_id){
        return xlink("401184",array($start_time,$end_time,$site_id),0);
    }

    public function c2c_trade_sell($start_time,$end_time,$site_id){
        return xlink("401185",array($start_time,$end_time,$site_id),0);
    }

    public function c2c_trade_buy_bol($start_time,$end_time){
        return xlink("401186",array($start_time,$end_time),0);
    }

    public function c2c_trade_sell_nol($start_time,$end_time){
        return xlink("401187",array($start_time,$end_time),0);
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/2/19
     * Time: 11:50
     * @param $site_id
     * @return mixed
     */
    public function c2c_buy_no_review_site_id($site_id,$type){
        return xlink(401109, array($site_id,$type));
    }
    public function c2c_buy_site_id($site_id,$type){
        return xlink(401108, array($site_id,$type));
    }
    public function c2c_buy_no_review($type){
        return xlink(401107, array($type));
    }
    public function c2c_buy($type)
    {
        return xlink(401106, array($type));
    }

}
