<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Logs_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function add_logs($user_id,$priv_id,$desc,$time,$ip,$site_id){
        return xlink('204206',array($user_id,$priv_id,$desc,$time,$ip,$site_id));
    }

}
