<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-04-09
 * Time: 16:12
 */

class Baoquan_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function add($hash,$baoQuanID,$status,$start_time,$end_time,$time,$size,$counts){
        return xlink("402234",array($hash,$baoQuanID,$status,$start_time,$end_time,$time,$size,$counts),0);
    }

}
