<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
 

class Unionpay_bind_card_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    

    //实名数据详情
    public function bankcard_detail($id)
    {
        return xlink(406111,array($id));
    }

    //提现审核
    public function bankcard_verify($id,$status)
    {
       
        return xlink(406306,array($id,$status));
    }



    


}
