<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Product_hash_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function get_detail($id){
        return xlink("202114",array($id),0);
    }

    public function get_list($offset,$limit){
        return xlink("201101",array($offset,$limit,$this->site_id));
    }
    public function get_count(){
        return xlink("201102",array($this->site_id),0,0);
    }

    public function add($name,$product_hash_type,$unit,$amount,$one_amount_value,$buy_min_amount,$powerRate,$maintenance,$income_start_time,$income_end_time,$sell_start_time,$sell_end_time,$income_start_mode
        ,$is_loan,$is_top,$status,$site_id,$description,$base_id,$time,$contract_ids,$contract_host_ids,$miningPower,$miningModel,$assign_type,$birth_time,$minepoolFee){
        return xlink("203201",array($name,$product_hash_type,$unit,$amount,$one_amount_value,$buy_min_amount,$powerRate,$maintenance,$income_start_time,$income_end_time,$sell_start_time,$sell_end_time,$income_start_mode
        ,$is_loan,$is_top,$status,$site_id,$description,$base_id,$time,$contract_ids,$contract_host_ids,$miningPower,$miningModel,$assign_type,$birth_time,$minepoolFee));
    }

    public function update($product_hash_id,$name,$product_hash_type,$unit,$amount,$one_amount_value,$buy_min_amount,$powerRate,$maintenance,$income_start_time,$income_end_time,$sell_start_time,$sell_end_time,$income_start_mode
        ,$is_loan,$is_top,$status,$site_id,$description,$contract_ids,$contract_host_ids,$miningPower,$miningModel,$assign_type,$minepoolFee){
        return xlink("203301",array($product_hash_id,$name,$product_hash_type,$unit,$amount,$one_amount_value,$buy_min_amount,$powerRate,$maintenance,$income_start_time,$income_end_time,$sell_start_time,$sell_end_time,$income_start_mode
        ,$is_loan,$is_top,$status,$site_id,$description,$contract_ids,$contract_host_ids,$miningPower,$miningModel,$assign_type,$minepoolFee));
    }

    public function product_sell_out($id,$status){
        return xlink("201304",array($id,$status));
    }

    public function get_product_hash_type($site_id){
        return xlink("202105",array($site_id));
    }

    public function get_data_by_id($product_id,$site_id=null){
        return xlink("102100",array($product_id,$site_id),0);
    }

    public function add_product_loan($three_stage_fee,$six_stage_fee,$twelve_stage_fee,$loan_type,$installment_proportion,$overdue_fee,$product_id,$site_id){
        return xlink("203211",array($three_stage_fee,$six_stage_fee,$twelve_stage_fee,$loan_type,$installment_proportion,$overdue_fee,$product_id,$site_id));
    }

    public function update_product_loan($product_id,$three_stage_fee,$six_stage_fee,$twelve_stage_fee,$loan_type,$installment_proportion,$overdue_fee,$site_id){
        return xlink("201311",array($product_id,$three_stage_fee,$six_stage_fee,$twelve_stage_fee,$loan_type,$installment_proportion,$overdue_fee,$site_id));
    }

    public function get_product_loan_detail($product_id,$site_id){
        return xlink("202133",array($product_id,$site_id));
    }

    public function now_sell_product_hash_a($start_time,$now_time){
        return xlink("200118",array($start_time,$now_time),0,0);
    }
    public function up_sell_product_hash_a($last_time,$start_time){
        return xlink("200116",array($last_time,$start_time),0,0);
    }



}
