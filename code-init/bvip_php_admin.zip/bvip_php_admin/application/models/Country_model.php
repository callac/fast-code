<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Country_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function get_list($show,$deleted_at){
        return xlink(401134,array($show,$deleted_at)); //返回二维数组
        // return xlink(401134,array($show,$deleted_at),0); //带参数0 ,就返回一维数组。
    }

    public function reset_password($status,$password,$user_id){
        if($status == 1) //登陆密码修改
            return xlink(501350,array($user_id,$password),0,0); 
        if($status == 2) //资金密码修改
            return xlink(501351,array($user_id,$password),0,0);
    }
}
