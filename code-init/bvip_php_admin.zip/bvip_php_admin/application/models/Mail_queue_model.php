<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 
 */
class Mail_queue_model extends Base_model {
	/**
	* 构造函数
	*/
	public function __construct()
	{
		parent::__construct();
	}
	
	/**
	* 获取单条记录
	*
	* @param integer  $id    编号
	*
	* @return array  返回数组
	*/
	public function info($id)
	{
        $query = $this->db->where('id', $id)->get('mail_queue');
        return $query->row_array();
	}
	
	/**
	* 获取列表
	*
	*
	* @return array   返回多维数组
	*/
	public function get_list($offset=0,$limit=20)
	{
        $query = $this->db->get('mail_queue')->limlit($offset,$limit);
        return $query->row_array();
	}
	
	/**
	* 添加
	*
	* @param string  $to    
	* @param string  $subject    
	* @param string  $message    
	*
	* @return integer  成功返回自增ID
	*/
	public function add($to,$subject,$message,$status)
	{
        $this->db->insert('mail_queue', [
            'to' => $to,
            'subject' => $subject,
            'message' => $message,
            'dateline' =>time(),
            'status' =>$status
        ]);
        return $this->db->insert_id();
	}
	


}
/* End of file mail_queue_model.php */
/* Location: ./application/models/mail_queue_model.php */