<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Site_admin_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function add($site_id,$user_name,$true_name,$password,$email,$mobile){
        return xlink('203204',array($site_id,$user_name,$true_name,$password,$email,$mobile));
    }

    public function update($site_id,$user_name,$true_name,$password,$email,$mobile){
        return xlink('201203',array($site_id,$user_name,$true_name,$password,$email,$mobile));
    }

    public function get_admin_by_username($username){
        return xlink('202110',array($username),0);
    }

    public function site_admin_delete($site_id){
        return xlink('201414',array($site_id),0);
    }


}