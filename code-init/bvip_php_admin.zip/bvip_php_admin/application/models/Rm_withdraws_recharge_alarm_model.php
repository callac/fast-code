<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/11/28
 * Time: 09:16
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class Rm_withdraws_recharge_alarm_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/28
     * Time: 09:35
     * @param $user_id
     * @param $asset
     * @param $tx_hash
     * @param $amount
     * @param $type
     * @param $created_at
     * @param $site_id
     * @return mixed
     */
    public function add_withdraws($user_id,$asset,$tx_hash,$amount,$type,$created_at,$site_id){
        return xlink(402216,array($user_id,$asset,$tx_hash,$amount,$type,$created_at,$site_id),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/28
     * Time: 09:35
     * @param $user_id
     * @param $asset
     * @param $tx_hash
     * @param $amount
     * @param $type
     * @param $created_at
     * @return mixed
     */
    public function add_recharge($user_id,$asset,$tx_hash,$amount,$type,$created_at){
        return xlink(402217,array($user_id,$asset,$tx_hash,$amount,$type,$created_at),0);
    }

    /**
     * Notes: 查看hash是否存在
     * User: 张哲
     * Date: 2018/11/28
     * Time: 09:47
     * @param $tx_hash
     */
    public function check_hash($tx_hash,$amount,$user_id,$asset){
          return xlink(401156,array($tx_hash,$amount,$user_id,$asset));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/28
     * Time: 11:26
     * @param $id
     * @param $status
     * @param $operator
     * @return mixed
     */
    public function deal_status($id,$status,$operator,$time){

        return xlink(403309,array($id,$status,$operator,$time));
    }
}