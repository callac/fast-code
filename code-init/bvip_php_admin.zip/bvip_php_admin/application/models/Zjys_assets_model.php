<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_assets_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    //新增币资产种类sql
    public function add_asset($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$created_at,$updated_at,$withdraw_min,$withdraw_max,$is_display,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount){
        return xlink(501201,array($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$created_at,$updated_at,$withdraw_min,$withdraw_max,$is_display,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount),0);
    }

    public function add_asset_by_system($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$created_at,$updated_at,$withdraw_min,$withdraw_max,$subtrue,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent){
        return xlink(501226,array($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$created_at,$updated_at,$withdraw_min,$withdraw_max,$subtrue,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent),0);
    }

    public function add_asset_true($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$created_at,$updated_at,$withdraw_min,$withdraw_max,$subtrue,$has_memo,$regex,$warning_status,$withdraw_fee_percent){
        return xlink(501222,array($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$created_at,$updated_at,$withdraw_min,$withdraw_max,$subtrue,$has_memo,$regex,$warning_status,$withdraw_fee_percent),0);
    }

    public function system_asset_add($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$created_at,$updated_at,$withdraw_min,$withdraw_max,$site_id,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent)
    {
        return xlink(501224,array($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$created_at,$updated_at,$withdraw_min,$withdraw_max,$site_id,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent),0);
    }

    public function system_asset_edit($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,$site_id,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent){
        return xlink(501337,array($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,$site_id,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent),0);
    }






        
    

    //修改币资产种类sql
    public function edit_asset($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$updated_at,$id,$withdraw_min,$withdraw_max,$is_display,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount){
        return xlink(501303,array($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$updated_at,$id,$withdraw_min,$withdraw_max,$is_display,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount),0);
    }

    public function list_all($site_id){
        return xlink(501102,array($site_id));
    }
    //查询单个币种详情
    public function get_asset_detail($asset_code,$site_id){
        return xlink(501108,array($asset_code,$site_id),0);
    }

    public function get_sys_asset_detail($asset_code){
        return xlink(501135,array($asset_code),0);
    }

    public function get_system_asset_detail_byid($id){
        return xlink(501138,array($id),0);
    }


    public function delete_by_site_id($site_id)
    {
        return xlink(501401,array($site_id),0);
    }

    public function get_detail_by_id($id)
    {
        return xlink(501110,array($id),0);
    }

    public function update_subsite_asset($where,$asset_code,$asset_name)
    {
        return xlink(501312,array($where,$asset_code,$asset_name),0);
    }

    public function get_assets_by_site_id($site_id)
    {
        return xlink(501113,array($site_id));
    }

    public function get_systemassets()
    {
        return xlink(501149,array());
    }


    public function asset_delete($site_id,$asset_code)
    {
        return xlink(501405,array($site_id,$asset_code),0);
    }


    // public function test()
    // {
    //     return xlink(501113);
    // }

    /**
     * 获取不平资产
     * @Author   张哲
     * @DateTime 2018-10-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
     public function get_assets(){
         return xlink(501405,array());
     }


      public function list_all_alarm(){
        return xlink(401131,array());
    }

    /**
     * 获取不平资产总额记录
     * @Author   张哲
     * @DateTime 2018-11-08
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
     public function user_assets(){
         return xlink(401140,array());
     }

     public function user_activity_assets(){
         return xlink(401141,array());
     }

     public function add_assetintros($asset_code,$icon,$desc,$full_name,$official_website,$white_paper,$block_query,$founding_team,$recommend_organization,$release_time,$release_total,$circulation_total,$detail,$created_at,$updated_at,$erc,$lang,$three_url,$three_icon){
         return xlink(501237,array($asset_code,$icon,$desc,$full_name,$official_website,$white_paper,$block_query,$founding_team,$recommend_organization,$release_time,$release_total,$circulation_total,$detail,$created_at,$updated_at,$erc,$lang,$three_url,$three_icon),0);
     }

     public function edit_assetintros($asset_code,$icon,$desc,$full_name,$official_website,$white_paper,$block_query,$founding_team,$recommend_organization,$release_time,$release_total,$circulation_total,$detail,$updated_at,$id,$erc,$lang,$three_url,$three_icon){
         return xlink(501353,array($asset_code,$icon,$desc,$full_name,$official_website,$white_paper,$block_query,$founding_team,$recommend_organization,$release_time,$release_total,$circulation_total,$detail,$updated_at,$id,$erc,$lang,$three_url,$three_icon),0);
     }

     public function asset_intro_delete($id,$time){
         return xlink(501352,array($id,$time),0);
     }

     public function correct_assets($asset_code,$asset_name){
         return xlink(501376,array($asset_code,$asset_name),0);
     }

     public function correct_assets_withdraw_verify_amount($asset_code,$withdraw_verify_amount){
         return xlink(501390,array($asset_code,$withdraw_verify_amount),0);
     }

     public function correct_assets_regex($asset_code,$regex){
         return xlink(501394,array($asset_code,$regex),0);
     }

     public function correct_assets_fee_percent($asset_code,$withdraw_fee_percent){
         return xlink(501396,array($asset_code,$withdraw_fee_percent),0);
     }



     public function correct_total_symbols($asset_code,$asset_name){
         return xlink(501377,array($asset_code,$asset_name),0);
     }

     public function correct_symbols($asset_code,$asset_name){
         return xlink(501378,array($asset_code,$asset_name),0);
     }

     public function correct_symbols_basename($asset_code,$asset_name){
         return xlink(501388,array($asset_code,$asset_name),0);
     }

     public function correct_symbols_quotename($asset_code,$asset_name){
         return xlink(501389,array($asset_code,$asset_name),0);
     }

     public function correct_assets_min_confirmation($asset_code,$min_confirmation){
         return xlink(501393,array($asset_code,$min_confirmation),0);
     }

     public function correct_assets_has_memo($asset_code,$has_memo){
         return xlink(502310,array($asset_code,$has_memo),0);
     }

     public function correct_assets_precision($asset_code,$precision){
         return xlink(502311,array($asset_code,$precision),0);
     }


     



    

}
