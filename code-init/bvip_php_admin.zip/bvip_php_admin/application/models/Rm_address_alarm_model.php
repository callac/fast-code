<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/11/29
 * Time: 19:03
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Rm_address_alarm_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 查看地址是否存在
     * User: 张哲
     * Date: 2018/11/29
     * Time: 19:15
     * @param $address
     * @param $user_id
     * @param $asset
     * @return mixed
     */
    public function check_address($address,$user_id,$asset){
        return xlink(401163,array($address,$user_id,$asset),0);
    }

    /**
     * Notes: 增加记录
     * User: 张哲
     * Date: 2018/11/29
     * Time: 19:16
     * @param $user_id
     * @param $address
     * @param $asset
     * @param created_at
     * @return mixed
     */
    public function add_address($user_id,$address,$asset,$created_at,$status){

        return xlink(402220,array($user_id,$address,$asset,$created_at,$status));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/28
     * Time: 11:26
     * @param $id
     * @param $status
     * @param $operator
     * @return mixed
     */
    public function address_deal_status($id,$status,$operator,$time){
        return xlink(403314,array($id,$status,$operator,$time));
    }
}