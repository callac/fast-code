<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Rm_parameter_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //
    public function param($market,$status){
        return xlink("401121",array($market,$status),0);
    }

    /**
     * 根据类型查询
     * @Author   张哲
     * @DateTime 2018-11-01
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $status [description]
     * @return   [type]               [description]
     */
    public function param_profit($status){
        return xlink("401132",array($status),0);
    }


    /**
     * 检查该记录是否存在
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $symbol  [description]
     * @param    [type]       $site_id [description]
     * @param    [type]       $status  [description]
     * @return   [type]                [description]
     */
    public function check_record($site_id){
        return xlink("401126",array($site_id,4),0);
    }


    /**
     * 增加新纪录
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $symbol       [description]
     * @param    [type]       $send_time    [description]
     * @param    [type]       $target_phone [description]
     * @param    [type]       $site_id      [description]
     * @param    [type]       $status       [description]
     * @return   [type]                     [description]
     */
    public function add_record($symbol,$rate,$site_id,$created_at){
        return xlink("402204",array($symbol,$rate,$site_id,4,$created_at),0);
    }

    /**
     * 更新纪录
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $symbol       [description]
     * @param    [type]       $rate         [description]
     * @param    [type]       $send_time    [description]
     * @param    [type]       $target_phone [description]
     * @param    [type]       $site_id      [description]
     * @param    [type]       $status       [description]
     * @param    [type]       $created_at   [description]
     */
    public function update_record($symbol,$rate,$site_id,$created_at,$update_at){
        return xlink("403301",array($symbol,$rate,$site_id,4,$created_at,$update_at),0);
    }

    /**
     * 检查是否存在
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $site_id [description]
     * @param    [type]       $status  [description]
     * @return   [type]                [description]
     */
    public function check_account_record($site_id){
        return xlink("401127",array($site_id,5),0);
    }

    /**
     * 账目参数增加新纪录
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $rate         [description]
     * @param    [type]       $send_time    [description]
     * @param    [type]       $target_phone [description]
     * @param    [type]       $site_id      [description]
     * @param    [type]       $status       [description]
     * @param    [type]       $created_at   [description]
     */
    public function add_account_record($rate,$send_time,$site_id,$created_at){
        return xlink("402205",array($rate,$send_time,$site_id,5,$created_at),0);
    }


    /**
     * 账目参数更新纪录
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $site_id [description]
     * @param    [type]       $status  [description]
     * @return   [type]                [description]
     */
    public function update_account_record($rate,$send_time,$site_id,$created_at,$id){
        return xlink("403302",array($rate,$send_time,$site_id,5,$created_at,$id),0);
    }


    /**
     * 检查是否存在
     * @Author   张哲
     * @DateTime 2018-11-01
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $site_id [description]
     * @param    [type]       $status  [description]
     * @return   [type]                [description]
     */
    public function check_profit_record($site_id){
        return xlink("401133",array($site_id,),0);
    }

    /**
     * 账目参数增加新纪录
     * @Author   张哲
     * @DateTime 2018-11-01
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $rate         [description]
     * @param    [type]       $send_time    [description]
     * @param    [type]       $target_phone [description]
     * @param    [type]       $site_id      [description]
     * @param    [type]       $status       [description]
     * @param    [type]       $created_at   [description]
     */
    public function add_profit_record($rate,$send_time,$site_id,$created_at){
        return xlink("402208",array($rate,$send_time,$site_id,6,$created_at),0);
    }


    /**
     * 账目参数更新纪录
     * @DateTime 2018-11-01
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $site_id [description]
     * @param    [type]       $status  [description]
     * @return   [type]                [description]
     */
    public function update_profit_record($rate,$send_time,$site_id,$created_at,$id){
        return xlink("403303",array($rate,$send_time,$site_id,6,$created_at,$id),0);
    }

    /**
     * Notes: 删除多余记录
     * User: 张哲
     * Date: 2019/3/25
     * Time: 17:13
     */
    public function delete_record($id,$time){
        //var_dump($site_id,$symbol,$status,$time);die();
        return xlink("403334",array($id,$time),0);
    }

}