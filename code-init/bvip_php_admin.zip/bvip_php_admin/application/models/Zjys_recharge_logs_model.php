<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_recharge_logs_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //获取用户详情
    public function get_info($user_id){
        return xlink(201111,array($user_id),0);
    }

    //统计用户数量
    public function get_count($site_id,$start,$end){
        return xlink(201116,array($site_id,$start,$end),0,0);
    }

    //禁止登陆/允许登陆
    public function update_forbid_login($user_id,$type){
        return xlink(201301,array($user_id,$type),0);
    }
    //禁止交易/允许交易
    public function update_forbid_withdraw($user_id,$type){
        return xlink(201302,array($user_id,$type),0);
    }
    //禁止提现/允许提现
    public function update_forbid_trade($user_id,$type){
        return xlink(201303,array($user_id,$type),0);
    }

    //更新用户token信息
    public function update_user_token($user_id,$token){
        return xlink(201316,array($user_id,$token));
    }

    //资金解冻
    public function capital_unfreeze($user_id,$amount)
    {
        return xlink(403309,array($user_id,$amount),0);
    }

    //提现审核失败资金解冻并还原余额
    public function capital_unfreeze_back_account($user_id,$amount)
    {
        return xlink(403310,array($user_id,$amount),0);
    }

    //银行卡充值更新余额
    public function update_user_balance($user_id,$balance)
    {
        return xlink(201314,array($user_id,$balance),0);
    }


    //根据站点获取 所有用户id
    public function get_user_info_by_site($site_id){
        return xlink(201117,array($site_id));
    }

    //根據手機號獲取用戶信息
    public function get_info_by_mobile($str){
        return xlink(201118,array($str),0);
    }
    //根據郵箱號獲取用戶信息
    public function get_info_by_email($str){
        return xlink(201119,array($str),0);
    }


    /**
     * 获取法币充值记录
     * @Author   张哲
     * @DateTime 2018-10-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $user_id [description]
     * @return   [type]                [description]
     */
    public function get_user_recharge_logs($asset,$user_id){
        return xlink(401123,array($asset,$user_id),0);
    }

    /**
     * Notes: 获取充值hash重复记录
     * User: 张哲
     * Date: 2018/11/28
     * Time: 09:04
     * @return mixed
     */
    public function get_recharge_record(){
        return xlink(401155, array());
    }

    /**
     * Notes: 获取该账户充值总和
     * User: 张哲
     * Date: 2018/11/29
     * Time: 18:45
     * @param $user_id
     * @param $asset
     * @return mixed
     */
    public function get_repayment_sum($user_id,$asset){
        return xlink(401160,array($user_id,$asset),0);
    }

    /**
     * Notes: 获取还款地址
     * User: 张哲
     * Date: 2018/11/29
     * Time: 16:18
     * @param $user_id
     * @param $asset
     * @return mixed
     */
    public function repayment_address($user_id,$asset){
        return xlink(401161,array($user_id,$asset));
    }

    /**
     * Notes: 获取重复充值地址
     * User: 张哲
     * Date: 2018/11/29
     * Time: 18:46
     * @return mixed
     */
    public function double_address(){
        return xlink(401162, array());
    }

    /**
     * Notes: 给充值表插入地址
     * User: 张哲
     * Date: 2018/12/14
     * Time: 21:37
     * @return mixed
     */
    public function add_address($time,$user_id,$asset,$create_address){
        return xlink(402224, array($time,$user_id,$asset,$create_address));
    }

    /**
     * Notes: 改变充值表状态
     * User: 张哲
     * Date: 2018/12/20
     * Time: 10:44
     */
    public function recharge_review($id,$status){
        return xlink(403317, array($id,$status));
    }

    /**
     * Notes: 数据可视化-充币数据
     * User: 张哲
     * Date: 2019/1/16
     * Time: 11:03
     * @param $start_time
     * @param $end_time
     * @param $site_id
     * @param $asset
     * @return mixed
     */
    public function recharge_sum_asset($start_time, $end_time,$site_id,$asset){
        return xlink(401188, array($start_time, $end_time,$site_id,$asset));
    }

    public function recharge_sum_site($start_time,$end_time,$site_id){
        return xlink(401190, array($start_time,$end_time,$site_id));
    }

    public function recharge_sum_nol($start_time,$end_time,$asset){
        return xlink(401191, array($start_time,$end_time,$asset));
    }

    public function recharge_sum($start_time,$end_time){
        return xlink(401192, array($start_time,$end_time));
    }



    /**
     * Notes: 风控-七日内按用户分类
     * User: 张哲
     * Date: 2019-04-24
     * Time: 11:49
     * @param $WithdrawId
     * @return mixed
     */
    public function large_amount_charge_recharge($start_time,$end_time){
        return xlink(601140, array($start_time,$end_time));
    }

}
