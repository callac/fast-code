<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    /**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
 

class Account_capital_racharge_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //充值列表
    public function recharge_list($offset,$limit)
    {
        return xlink(401100,array($offset,$limit,$this->site_id));
    }

    //充值总条数
    public function recharge_list_count()
    {
        return xlink(401101,array($this->site_id),0,0);
    }

    //充值数据详情
    public function recharge_details($id)
    {
        return xlink(401102,array($id));
    }


    //充值审核
    public function recharge_verify($id,$status)
    {
        return xlink(401301,array($id,$status,$this->site_id));
    }

    //充值待处理
    public function racharge_waiting($site_id){
        return xlink('204119',array($site_id),0,0);
    }

    //改变状态
    public function update_status($id,$status=1){
        return xlink('403333',array($id,$status),0,0);
    }
}
