<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/11/23
 * Time: 13:55
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Platform_account_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 根据状态查询借还款的总额
     * User: 张哲
     * Date: 2018/11/23
     * Time: 17:05
     * @param $status
     * @return mixed
     */
    public function get_total_account($status){

        return xlink(401148,array($status),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/23
     * Time: 17:14
     * @param $status
     * @return mixed
     */
    public function get_user_id($site_id){

        return xlink(401149,array($site_id),0);
    }
}
