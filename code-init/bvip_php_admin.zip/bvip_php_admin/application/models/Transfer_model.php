<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/11/20
 * Time: 14:20
 */


defined('BASEPATH') OR exit('No direct script access allowed');
class Transfer_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 查询账户是否存在
     * User: 张哲
     * Date: 2018/11/20
     * Time: 14:55
     * @param $user_id
     * @return mixed
     */
    public function check_account($user_id,$name,$site_id){
        return xlink("401143",array($user_id,$name,$site_id),0);
    }

    public function check_account1($id){
        return xlink("401153",array($id),0);
    }

    /**
     * Notes: 增加总账户信息
     * User: 张哲
     * Date: 2018/11/20
     * Time: 15:32
     * @param $name
     * @param $site_id
     * @param $user_id
     * @param $remark
     * @param $created_at
     * @return mixed
     */
    public function add_total_account($name,$site_id,$remark,$created_at,$status){
        return xlink(402210,array($name,$site_id,$remark,$created_at,$status),0);
    }

    /**
     * Notes: 增加子账户
     * User: 张哲
     * Date: 2018/11/29
     * Time: 15:50
     * @param $name
     * @param $site_id
     * @param $user_id
     * @param $remark
     * @param $time
     * @param $status
     * @return mixed
     */
    public function add_zi_account($name,$site_id,$user_id,$remark,$created_at,$status,$type,$operator){
        return xlink(402218,array($name,$site_id,$user_id,$remark,$created_at,$status,$type,$operator),0);
    }

    /**
     * Notes: 修改更新账户信息
     * User: 张哲
     * Date: 2018/11/20
     * Time: 15:31
     * @param $name
     * @param $site_id
     * @param $user_id
     * @param $remark
     * @param $updated_at
     * @param $id
     * @return mixed
     */
    public function update_account($name,$site_id,$user_id,$remark,$updated_at,$status,$id,$type,$operator){
        return xlink(403306,array($name,$site_id,$user_id,$remark,$updated_at,$status,$id,$type,$operator),0);
    }

    /**
     * Notes: 删除账户
     * User: 张哲
     * Date: 2018/11/20
     * Time: 15:32
     * @param $id
     * @return mixed
     */
    public function delete_accout($id,$time){
        return xlink(403307,array($id,$time),0);
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/28
     * Time: 17:24
     * @param $site_id
     * @param $status
     * @return mixed
     */
    public function check_generate_total_account($site_id,$status){
        return xlink(401157,array($site_id,$status),0);
    }

    /**
     * Notes: 生成总账户
     * User: 张哲
     * Date: 2018/11/29
     * Time: 10:32
     */
    public function update_total_account($user_id,$site_id,$time,$id,$operator,$type){
        return xlink(403311,array($user_id,$site_id,$time,$id,$operator,$type),0);
    }

    /**
     * Notes: 查询该总账户是否已经使用
     * User: 张哲
     * Date: 2018/11/29
     * Time: 14:06
     * @return mixed
     */
    public function check_generate_user($user_id){
        return xlink(401158,array($user_id),0);
    }

    /**
     * Notes: 查询该站点的总账户id
     * User: 张哲
     * Date: 2018/11/29
     * Time: 14:17
     * @param $site_id
     * @return mixed
     */
    public function check_site_id($site_id){
        return xlink(401159,array($site_id),0);
    }


    /**
     * Notes: 获取当天一个站点一个交易区的交易统计数据
     * User: 张哲
     * Date: 2019-07-31
     * Time: 10:32
     */
    public function trade_zone($site_id,$start_time,$end_time){
        return xlink(601171,array($site_id,$start_time,$end_time),0);
    }


    public function real_trade_zone($site_id,$start_time,$end_time){
        return xlink(601172,array($site_id,$start_time,$end_time),0);
    }

    /**
     * Notes: 获取交易区数据
     * User: 张哲
     * Date: 2019-07-31
     * Time: 16:24
     */
    public function trade_zone_details($start_time,$end_time,$site_id,$val){
        return xlink(601173,array($start_time,$end_time,$site_id,$val));
    }

    public function real_trade_zone_details($start_time,$end_time,$site_id,$val){
        return xlink(601174,array($start_time,$end_time,$site_id,$val));
    }

    /**
     * Notes: 获取交易对明细
     * User: 张哲
     * Date: 2019-07-31
     * Time: 17:18
     */
    public function symbolDetails($start_time,$end_time,$site_id,$symbol){
        return xlink(601175,array($start_time,$end_time,$site_id,$symbol));
    }

    public function realSymbolDetails($start_time,$end_time,$site_id,$symbol){
        return xlink(601176,array($start_time,$end_time,$site_id,$symbol));
    }




}