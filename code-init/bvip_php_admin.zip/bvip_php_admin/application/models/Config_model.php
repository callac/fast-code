<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Config_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function get_list($offset,$limit,$site_id){
        return xlink("202111",array($offset,$limit,$site_id));
    }

    public function is_adminid_true($admin_id){
        return xlink("501183",array($admin_id));
    }

    public function c2c_param_config_list($offset,$limit,$site_id){
        return xlink("501116",array($offset,$limit,$site_id));
    }

    public function c2c_param_config_list_count($site_id){
        return xlink("501117",array($site_id));
    }

    public function c2c_config_update($id,$value,$memo,$site_id){
        return xlink("501319",array($id,$value,$memo,$site_id));
    }

    public function c2c_config_add($varname,$value,$memo,$site_id){
        return xlink("501209",array($varname,$value,$memo,$site_id));
    }

    public function help_class_update($name,$display_order,$site_id,$id,$lang){
        return xlink("501322",array($name,$display_order,$site_id,$id,$lang));
    }

    public function help_class_add($name,$display_order,$site_id,$lang){
        return xlink("501213",array($name,$display_order,$site_id,$lang));
    }


    public function help_class_delete($id){
        return xlink("501404",array($id));
    }



    public function get_info_by_va($name,$site_id){
        return xlink("202115",array($name,$site_id),0);
    }

    public function get_count($site_id){
        return xlink("202112",array($site_id),0,0);
    }

    public function config_update($id,$varname,$value,$remark,$site_id){
        return xlink("201305",array($id,$varname,$value,$remark,$site_id));
    }

    public function config_add($varname,$value,$remark,$site_id){
        return xlink("203205",array($varname,$value,$remark,$site_id));
    }

    public function config_delete($id){
        return xlink("201402",array($id));
    }

    public function news_list($type,$offset,$limit,$site_id)
    {
        return xlink("301115",array($type,$offset,$limit,$site_id));
    }

    public function news_count($type,$site_id)
    {
        return xlink("301116",array($type,$site_id),0,0);
    }
    //资讯管理
    public function newsUpdate($title,$content,$site_id,$id,$news_class_id,$resume,$image,$dateline,$lang)
    {
        return xlink("301303",array($title,$content,$site_id,$id,$news_class_id,$resume,$image,$dateline,$lang));
    }

    public function newsAdd($title,$content,$dateline,$site_id,$news_class_id,$resume,$image,$lang)
    {
        return xlink("301204",array($title,$content,$dateline,$site_id,$news_class_id,$resume,$image,$lang));
    }

    public function newsDelete($id){
        return xlink("301401",array($id));
    }

    public function bdc_update($bdc_name,$content,$site_id,$id){
        return xlink("301304",[$bdc_name,$content,$site_id,$id]);
    }

    public function bdc_add($bdc_name,$content,$created_at,$site_id){
        return xlink("301205",[$bdc_name,$content,$created_at,$site_id]);
    }

    public function bdc_list($offset,$limit,$site_id){
        return xlink("301117",[$site_id,$offset,$limit]);
    }

    public function bdc_count($site_id){
        return xlink("301118",[$site_id],0,0);
    }

    public function bdc_delete($id){
        return xlink("301402",[$id],0,0);
    }
    //帮助管理
    public function help_update($help_class_id,$title,$content,$site_id,$id,$lang){
        return xlink("301305",[$help_class_id,$title,$content,$site_id,$id,$lang]);
    }

    public function help_add($help_class_id,$title,$content,$dateline,$site_id,$lang){
        return xlink("301206",[$help_class_id,$title,$content,$dateline,$site_id,$lang]);
    }

    public function app_update_add($app_endpoint,$version_id,$version_major,$version_minor,$version_code,$type,$apk_url,$upgrade_point,$status,$site_id,$admin_id,$remark,$ctime,$utime)
    {
        return xlink("501216",[$app_endpoint,$version_id,$version_major,$version_minor,$version_code,$type,$apk_url,$upgrade_point,$status,$site_id,$admin_id,$remark,$ctime,$utime]);
    }

    public function app_update_update($app_endpoint,$version_id,$version_major,$version_minor,$version_code,$type,$apk_url,$upgrade_point,$status,$site_id,$admin_id,$remark,$utime,$id)
    {
        return xlink("501323",[$app_endpoint,$version_id,$version_major,$version_minor,$version_code,$type,$apk_url,$upgrade_point,$status,$site_id,$admin_id,$remark,$utime,$id]);
    }

    public function help_list($offset,$limit,$site_id,$help_class_id){
        return xlink("301119",[$site_id,$offset,$limit,$help_class_id]);
    }

    public function agreement_list($offset,$limit,$site_id){
        
        return xlink("301130",[$site_id,$offset,$limit]);
    }

    public function app_update_list($offset,$limit,$site_id){
        
        return xlink("301138",[$site_id,$offset,$limit]);
    }

    public function friendlink_list($offset,$limit,$site_id){
        
        return xlink("301132",[$site_id,$offset,$limit]);
    }

    public function help_class(){
        return xlink("301140",[]);
    }

    public function help_count($site_id,$help_class_id){
        return xlink("301120",[$site_id,$help_class_id],0,0);
    }

    public function agreement_count($site_id){
        return xlink("301131",[$site_id],0,0);
    }

    public function friendlink_count($site_id){
        return xlink("301135",[$site_id],0,0);
    }

    public function help_delete($id){
        return xlink("301403",[$id],0,0);
    }

    public function app_update_delete($id,$time){
        return xlink("501324",[$id,$time],0,0);
    }

    public function labelconfigdelete($id,$time){
        return xlink("501329",[$id,$time],0,0);
    }

    public function activityholdingdelete($id,$time){
        return xlink("501332",[$id,$time],0,0);
    }



    public function agreement_delete($id){
        return xlink("301407",[$id],0,0);
    }

     public function friendlink_delete($id){
        return xlink("301408",[$id],0,0);
    }


    public function version_list($offset,$limit,$site_id){
        return xlink("301121",[$site_id,$offset,$limit,]);
    }

    public function version_count($site_id){
        return xlink("301122",[$site_id],0,0);
    }

    public function version_update($device_id,$version_number,$download_url,$site_id,$id){
        return xlink("301306",[$device_id,$version_number,$download_url,$site_id,$id]);
    }
    public function version_add($device_id,$version_number,$download_url,$site_id,$time){
        return xlink("301211",[$device_id,$version_number,$download_url,$site_id,$time]);
    }


    public function version_delete($id){
        return xlink("301404",[$id],0,0);
    }

    public function banner_friend_list($type,$offset,$limit,$site_id){
        return xlink("301125",array($type,$site_id,$offset,$limit,));
    }

    public function banner_friend_count($type,$site_id){
        return xlink("301126",array($type,$site_id),0,0);
    }
    //轮播图管理
    public function banner_update($title,$image,$url,$url_type,$endpoint,$position,$display_order,$id,$site_id,$type,$lang)
    {
        return xlink("301308",array($title,$image,$url,$url_type,$endpoint,$position,$display_order,$id,$site_id,$type,$lang));
    }

    public function banner_add($title,$image,$url,$url_type,$endpoint,$position,$display_order,$site_id,$type,$lang)
    {
        return xlink("301208",array($title,$image,$url,$url_type,$endpoint,$position,$display_order,$site_id,$type,$lang));
    }

    public function friend_update($title,$url,$id)
    {
        return xlink("301309",array($title,$url,$id));
    }

    public function friend_add($title,$url,$site_id)
    {
        return xlink("301209",array($title,$url,$site_id));
    }

    public function banner_friend_delete($id)
    {
        return xlink("301406",[$id],0,0);
    }


    public function news_class_list($site_id,$offset,$limit){
        return xlink("204123",[$site_id,$offset,$limit]);
    }

    public function news_class_count($site_id){
        return xlink("204124",[$site_id],0,0);
    }

    public function news_class_update($id,$name,$remark,$display_order,$site_id,$lang){
        return xlink("204312",[$id,$name,$remark,$display_order,$site_id,$lang]);
    }

    public function news_class_add($name,$remark,$display_order,$site_id,$lang){
        return xlink("204207",[$name,$remark,$display_order,$site_id,$lang]);
    }

    public function news_class_delete($id){
        return xlink("201429",[$id]);
    }


    public function about_list($offset,$limit,$site_id){
        return xlink("204125",[$site_id,$offset,$limit]);
    }

    public function about_count($site_id){
        return xlink("204126",[$site_id],0,0);
    }
    public function about_us_by_site($site_id){
        return xlink("204127",[$site_id]);
    }

    public function delete_about_us($site_id){
        return xlink("201415",[$site_id]);
    }

    public function add_about_us($center_block_title,$center_block_content,$center_block_image,$time,$site_id,$bottom_block_image,$bottom_block_word){
        return xlink("204208",[$center_block_title,$center_block_content,$center_block_image,$time,$site_id,$bottom_block_image,$bottom_block_word]);
    }
    public function about_update($banner_title,$banner_content,$banner_up_title,$banner_up_resume,$map_title,$map_des,$slogan,$slogn_content,$site_id,$id){
        return xlink("204313",[$banner_title,$banner_content,$banner_up_title,$banner_up_resume,$map_title,$map_des,$slogan,$slogn_content,$site_id,$id]);
    }

    public function about_add($banner_title,$banner_content,$banner_up_title,$banner_up_resume,$map_title,$map_des,$slogan,$slogn_content,$time,$site_id){
        return xlink("204209",[$banner_title,$banner_content,$banner_up_title,$banner_up_resume,$map_title,$map_des,$slogan,$slogn_content,$time,$site_id]);
    }

    public function get_about_by_site($site_id){
        return xlink("204128",[$site_id],0);
    }

    public function about_delete($site_id){
        return xlink("201416",[$site_id]);
    }

    public function question_list($offset,$limit,$site_id){
        return xlink("301133",[$site_id,$offset,$limit,]);
    }

    public function question_count($site_id){
        return xlink("301134",[$site_id],0,0);
    }

    //基本配置（关于我们/隐私政策/注册协议）
    public function agreement_update($unique_id,$title,$content,$dateline,$admin_user_id,$site_id,$id,$lang){
        return xlink("301310",[$unique_id,$title,$content,$dateline,$admin_user_id,$site_id,$id,$lang]);
    }
    //
    public function agreement_add($unique_id,$title,$content,$dateline,$admin_user_id,$site_id,$lang){
        return xlink("301210",[$unique_id,$title,$content,$dateline,$admin_user_id,$site_id,$lang]);
    }

    //友情链接
    public function friendlink_update($image,$url,$remark,$site_id,$id,$lang){
        return xlink("301311",[$image,$url,$remark,$site_id,$id,$lang]);
    }

    public function friendlink_add($image,$url,$remark,$site_id,$lang){
        return xlink("301212",[$image,$url,$remark,$site_id,$lang]);
    }

    

    public function get_popup_num_by_id($site_id,$endpoint){
        return xlink("501128",[$site_id,$endpoint]);
    }

    public function update_appupgrades($app_endpoint,$status,$site_id){
        return xlink("501325",[$app_endpoint,$status,$site_id]);
    }

    //导航栏配置
    public function labelconfigupdate($label_name,$api_url,$order,$type,$site_id,$utime,$id,$class_id,$icon,$qrcode,$lang){
        return xlink("501330",[$label_name,$api_url,$order,$type,$site_id,$utime,$id,$class_id,$icon,$qrcode,$lang]);
    }


    public function labelconfigadd($label_name,$api_url,$order,$type,$site_id,$ctime,$utime,$class_id,$icon,$qrcode,$lang){
        return xlink("501218",[$label_name,$api_url,$order,$type,$site_id,$ctime,$utime,$class_id,$icon,$qrcode,$lang]);
    }


    public function activityholdingadd($asset,$hold_area,$award_get,$snapshot,$site_id,$ctime,$utime){
        return xlink("501219",[$asset,$hold_area,$award_get,$snapshot,$site_id,$ctime,$utime]);
    }

    public function activityholdingupdate($asset,$hold_area,$award_get,$snapshot,$site_id,$utime,$id){
        return xlink("501331",[$asset,$hold_area,$award_get,$snapshot,$site_id,$utime,$id]);
    }


    public function activityholdingdetail($id)
    {
        return xlink("501130",[$id],0);
    }

    public function getuserids()
    {
        return xlink("501131",array());
    }

    public function getuserfreeze_by_asset($asset,$id)
    {
        return xlink("501132",[$asset,$id],0);
    }

    public function add_activityholding_award($asset,$user_id,$h_c_id,$snapshot,$freeze,$award_grant,$award_percent,$status,$created_at,$updated_at){
        return xlink("501220",[$asset,$user_id,$h_c_id,$snapshot,$freeze,$award_grant,$award_percent,$status,$created_at,$updated_at]);
    }

    public function getactivityholdawardlist($h_c_id,$status){
        return xlink("501133",[$h_c_id,$status]);
    }

    public function updateactivityholdaward($id,$amount,$time){
        return xlink("501333",[$id,$amount,$time]);
    }

    public function changeholdingstatus($id){
        return xlink("501334",[$id]);
    }

    public function apptrade_update($user_id,$api_key,$secret_key,$updated_at,$id,$bind_ips,$remark,$expire_time){
        return xlink("501335",[$user_id,$api_key,$secret_key,$updated_at,$id,$bind_ips,$remark,$expire_time]);
    }

    public function apptrade_update_bind_ips($user_id,$api_key,$secret_key,$updated_at,$id,$bind_ips,$remark,$expire_time){
        return xlink("502306",[$user_id,$api_key,$secret_key,$updated_at,$id,$bind_ips,$remark,$expire_time]);
    }

    public function apptrade_add($user_id,$api_key,$secret_key,$created_at,$updated_at,$admin_id,$remark,$bind_ips,$site_id,$expire_time){
        return xlink("501221",[$user_id,$api_key,$secret_key,$created_at,$updated_at,$admin_id,$remark,$bind_ips,$site_id,$expire_time]);
    }

    public function apptrade_delete($id,$time){
        return xlink("501336",[$id,$time]);
    }

    public function mailconfigdelete($id,$time){
        return xlink("501343",[$id,$time]);
    }


    public function is_true_apikey($api_key)
    {
        return xlink("501134",[$api_key],0);
    }

    public function is_true_userid($user_id)
    {
        return xlink("501184",[$user_id],0);
    }

    public function is_true_user($user_id)
    {
        return xlink("501140",[$user_id],0);
    }

    public function mailconfigadd_update($site_id,$uid,$email,$tongji_type,$updated_at,$id){
        return xlink("501342",[$site_id,$uid,$email,$tongji_type,$updated_at,$id]);
    }

    public function mailconfigadd_add($site_id,$uid,$email,$tongji_type,$created_at,$updated_at){
        return xlink("501228",[$site_id,$uid,$email,$tongji_type,$created_at,$updated_at]);
    }

    public function get_mailconfig($tongji_type){
        return xlink("501152",[$tongji_type],0);
    }

    public function csvlogs_add($tongji_type,$url,$created_at){
        return xlink("501229",[$tongji_type,$url,$created_at]);
    }

    public function is_tongji_type($tongji_type){
        return xlink("501153",[$tongji_type],0);
    }



    public function add_smsconfig($site_id,$is_default,$account,$password,$sign_name,$channel,$template_code,$internal,$created_at,$updated_at)
    {
        return xlink(501240,[$site_id,$is_default,$account,$password,$sign_name,$channel,$template_code,$internal,$created_at,$updated_at]);
    }

    public function edit_smsconfig($site_id,$is_default,$account,$password,$sign_name,$channel,$template_code,$internal,$updated_at,$id)
    {
        return xlink(501357,array($site_id,$is_default,$account,$password,$sign_name,$channel,$template_code,$internal,$updated_at,$id),0);
    }

    public function smsconfig_delete($id,$time)
    {
        return xlink(501358,array($id,$time),0);
    }

    public function get_smsconfig_info($id){
        return xlink("501171",[$id],0);
    }

    public function smsconfig_is_used($site_id,$id){
        return xlink("501367",[$site_id,$id],0);
    }

    public function smsconfig_is_used_byid($id){
        return xlink("501368",[$id],0);
    }


    public function add_emailconfig($site_id,$is_default,$account,$password,$channel,$created_at,$updated_at)
    {
        return xlink(501241,[$site_id,$is_default,$account,$password,$channel,$created_at,$updated_at]);
    }

    public function edit_emailconfig($site_id,$is_default,$account,$password,$channel,$updated_at,$id)
    {
        return xlink(501359,array($site_id,$is_default,$account,$password,$channel,$updated_at,$id),0);
    }

    public function emailconfig_delete($id,$time)
    {
        return xlink(501360,array($id,$time),0);
    }

    public function get_emailconfig_info($id){
        return xlink("501170",[$id],0);
    }

    public function emailconfig_is_used($site_id,$id){
        return xlink("501366",[$site_id,$id],0);
    }

    public function emailconfig_is_used_byid($id){
        return xlink("501365",[$id],0);
    }




    public function add_inviteconfig($site_id,$image,$qrcode_x,$qrcode_y,$qrcode_w,$qrcode_h,$created_at,$updated_at)
    {
        return xlink(501242,[$site_id,$image,$qrcode_x,$qrcode_y,$qrcode_w,$qrcode_h,$created_at,$updated_at]);
    }

    public function edit_inviteconfig($site_id,$image,$qrcode_x,$qrcode_y,$qrcode_w,$qrcode_h,$updated_at,$id)
    {
        return xlink(501361,array($site_id,$image,$qrcode_x,$qrcode_y,$qrcode_w,$qrcode_h,$updated_at,$id),0);
    }

    public function inviteconfig_delete($id,$time)
    {
        return xlink(501362,array($id,$time),0);
    }

    public function get_inviteimg_info($id){
        return xlink("501169",[$id],0);
    }

    public function is_used($site_id,$id){
        return xlink("501363",[$site_id,$id],0);
    }

    public function is_used_byid($id){
        return xlink("501364",[$id],0);
    }

    public function add_ip($ip,$type,$expire_time,$remark,$created_at,$updated_at,$site_id)
    {
        return xlink('501243',[$ip,$type,$expire_time,$remark,$created_at,$updated_at,$site_id]);
    }

    public function edit_ip($ip,$type,$expire_time,$remark,$updated_at,$id,$site_id)
    {
        return xlink('501372',array($ip,$type,$expire_time,$remark,$updated_at,$id,$site_id),0);
    }

    public function ip_delete($id,$time)
    {

        return xlink(501373,array($id,$time),0);
    }

    public function advert_place_add($title,$site_id,$img,$url,$created_at,$updated_at)
    {
        return xlink('501256',[$title,$site_id,$img,$url,$created_at,$updated_at]);
    }

    public function advert_place_edit($title,$site_id,$img,$url,$updated_at,$id)
    {
        return xlink('501398',array($title,$site_id,$img,$url,$updated_at,$id),0);
    }

    public function advert_place_delete($id,$time)
    {
        return xlink(501399,array($id,$time),0);
    }

    public function advert_place_updown($id,$status)
    {
        return xlink(502304,array($id,$status),0);
    }

    public function fingerpost_add($title,$desc,$site_id,$img,$vedio,$order,$created_at,$updated_at)
    {
        return xlink('501257',[$title,$desc,$site_id,$img,$vedio,$order,$created_at,$updated_at]);
    }

    public function fingerpost_edit($title,$desc,$site_id,$img,$vedio,$order,$updated_at,$id)
    {
        return xlink('502301',array($title,$desc,$site_id,$img,$vedio,$order,$updated_at,$id),0);
    }

    public function fingerpost_delete($id,$time)
    {
        return xlink(502302,array($id,$time),0);
    }

    public function fingerpost_updown($id,$status)
    {
        return xlink(502305,array($id,$status),0);
    }

    public function add_news_content($title,$news_id,$content,$created_at,$updated_at,$lang,$resume)
    {
        return xlink('501244',[$title,$news_id,$content,$created_at,$updated_at,$lang,$resume]);
    }

    public function edit_news_content($title,$news_id,$content,$updated_at,$id,$lang,$resume)
    {
        return xlink('501374',array($title,$news_id,$content,$updated_at,$id,$lang,$resume),0);
    }

    public function news_content_delete($id,$time)
    {
        // var_dump($id,$time);die;
        return xlink(501375,array($id,$time),0);
    }


    public function add_help_content($title,$help_id,$content,$created_at,$updated_at,$lang)
    {
        return xlink('501246',[$title,$help_id,$content,$created_at,$updated_at,$lang]);
    }

    public function edit_help_content($title,$news_id,$content,$updated_at,$id,$lang)
    {
        return xlink('501381',array($title,$news_id,$content,$updated_at,$id,$lang),0);
    }

    public function help_content_delete($id,$time)
    {

        return xlink(501382,array($id,$time),0);
    }



    public function add_help_class_content($name,$help_class_id,$lang,$display_order,$created_at,$updated_at)
    {
        return xlink('501247',[$name,$help_class_id,$lang,$display_order,$created_at,$updated_at]);
    }

    public function edit_help_class_content($name,$help_class_id,$lang,$display_order,$updated_at,$id)
    {
        return xlink('501384',array($name,$help_class_id,$lang,$display_order,$updated_at,$id),0);
    }

    public function help_class_content_delete($id,$time)
    {

        return xlink(501383,array($id,$time),0);
    }

    public function admin_whiteip_add($admin_id,$ip,$created_at,$updated_at)
    {
         return xlink(501251,array($admin_id,$ip,$created_at,$updated_at),0);
    }

    public function admin_whiteip_edit($admin_id,$ip,$updated_at,$id)
    {
         return xlink(501391,array($admin_id,$ip,$updated_at,$id),0);
    }

    public function admin_whiteip_delete($id,$time)
    {
         return xlink(501392,array($id,$time),0);
    }

    public function appTradestatus($id,$des_status)
    {
        return xlink(502303,array($id,$des_status),0);
    }


















    





}
