<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    /**
     * 资金管理-资金流水
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
 

class User_capital_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //资金流水列表
    public function capital_list($offset,$limit)
    {
        return xlink(403106,array($offset,$limit,$this->site_id));
    }

    //资金流水总条数
    public function capital_list_count()
    {
        return xlink(403107,array($this->site_id),0,0);
    }

    //新增资金明细
    public function add_capital_detail($id,$user_id,$amount,$fee,$status)
    {
    	$remark = '手续费：'.$fee;
        return xlink(403201,array($user_id,$_SERVER['REQUEST_TIME'],2,'提现',-$amount,$id,$remark,$status),0,0);
    }

    //新增资金明细
    public function add_ticoin_detail($id,$user_id,$amount,$fee,$name,$status)
    {
    	$remark = '手续费：'.$fee.$name;
        return xlink(404201,array($user_id,$_SERVER['REQUEST_TIME'],16,'提币',-$amount,$id,$remark,$status),0,0);
    }

   

    public function add($time,$user_id,$type,$description,$num,$pay_value,$order_id,$channel,$trade_id,$status,$site_id){
        return xlink('202208',array($time,$user_id,$type,$description,$num,$pay_value,$order_id,$channel,$trade_id,$status,$site_id));
    }






















}
