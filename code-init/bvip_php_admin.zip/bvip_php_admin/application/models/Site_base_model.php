<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Site_base_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }
    public function get_info_by_type($type){
        return xlink('202130',array($type));
    }
}