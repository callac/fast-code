<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/12/7
 * Time: 11:42
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Perday_holdcoin_statistics_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 插入数据
     * User: 张哲
     * Date: 2018/12/7
     * Time: 13:41
     * @param $user_id
     * @param $asset
     * @param $balance
     * @param $pop
     * @param $created_at
     * @return mixed
     */
    public function add($user_id,$asset,$balance,$pop,$created_at,$site_id){
        return xlink(402221,array($user_id,$asset,$balance,$pop,$created_at,$site_id),0);
    }

    /**
     * Notes: 更新表
     * User: 张哲
     * Date: 2018/12/7
     * Time: 13:53
     * @param $user_id
     * @param $asset
     * @param $balance
     * @param $pop
     * @param $created_at
     * @return mixed
     */
    public function update($user_id,$asset,$balance,$pop,$updated_at,$site_id){
        return xlink(403315,array($user_id,$asset,$balance,$pop,$updated_at,$site_id),0);
    }

    /**
     * Notes: 查询是否出现
     * User: 张哲
     * Date: 2018/12/7
     * Time: 13:42
     * @param $user_id
     * @param $asset
     * @return mixed
     */
    public function get_data($user_id,$asset){
        return xlink(401165,array($user_id,$asset),0);
    }

}
