<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2018/12/14
 * Time: 21:02
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Wallet_users_model extends CI_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 查询用户是否存在
     * User: 张哲
     * Date: 2018/12/14
     * Time: 21:05
     * @param $user_id
     * @return mixed
     */
    public function check_user_id($user_id){
        return xlink(401167,array($user_id),0);
    }

    /**
     * Notes: 插入钱包用户表
     * User: 张哲
     * Date: 2018/12/14
     * Time: 21:34
     * @param $create_user_id
     * @param $time
     * @param $user_id
     * @return mixed
     */
    public function add_user_id($create_user_id,$time,$user_id){
        return xlink(402222,array($create_user_id,$time,$user_id),0);
    }
}