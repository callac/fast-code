<?php
/**
 * Created by PhpStorm.
 * User: 63039
 * Date: 2018/4/20
 * Time: 14:17
 */
class User_hash_income_model extends Base_Model{
    function __construct()
    {

    }

    public function hash_income_list($limit,$offset,$assign_type,$product_hash_type){
       return  xlink("100100",array($limit,$offset,$assign_type,$product_hash_type));
    }

    public function hash_income_count($assign_type,$product_hash_type){
       return  xlink("100101",array($assign_type,$product_hash_type),0,0);
    }

    public function get_data_by_id($hash_income_id){
       return  xlink("100102",array($hash_income_id),0);
    }

    public function update_hash_income($hash_income_id,$coin_price,$mine_amount,$mine_user,$mine_time,$status){
       return  xlink("100300",array($hash_income_id,$coin_price,$mine_amount,$mine_user,$mine_time,$status),0,0);
    }

    public function change_status($hash_income_id,$status){
       return  xlink("100303",array($hash_income_id,$status),0,0);
    }

    public function update_info($hash_income_id,$status,$electricity_fees,$trust_fee,$procedure_fee,$apportion_time){
       return  xlink("100301",array($hash_income_id,$status,$electricity_fees,$trust_fee,$procedure_fee,$apportion_time),0,0);
    }

    public function check_access($hash_income_id,$audit_user,$audit_time,$status){
       return  xlink("100302",array($hash_income_id,$audit_user,$audit_time,$status),0,0);
    }

    public function transfer_done($hash_income_id,$distribution_user,$distribution_time,$status){
       return  xlink("100304",array($hash_income_id,$distribution_user,$distribution_time,$status),0,0);
    }

    //更改状态
    public function update_status($hash_income_id,$status)
    {
        return xlink(401301,array($hash_income_id,$status,$this->site_id));
    }

}