<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Invite_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    //邀请--列表
    public function get_list($offset,$limit,$site_id,$email,$mobile)
    {
        return xlink('301109',array($site_id,$offset,$limit,$email,$mobile));
    }

    //邀请--总条数
    public function get_info_count($site_id,$email,$mobile)
    {
        return xlink('301110',array($site_id,$email,$mobile),0,0);
    }

    //邀请--详情
    public function detail($id)
    {
        return xlink('301111',array($id));
    }

}
