<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Tongji_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //取最近生成的去重数据表里面的数据（perday_data_statistics）
    public function last_data(){
        return xlink('501155',array(),0);
    }
    //去重数据入库
    public function add_deduplication_data($site_id,$created_at,$updated_at,$register_amount,$invite_register_amount,$trunname_amount,$c2c_trade_amount,$recharge_amount,$withdraw_amount,$coin_trade_amount,$register_total,$invite_register_total,$trunname_total,$c2c_trade_total,$recharge_total,$withdraw_total,$coin_trade_total,$time,$time_area){
        return xlink('501230',array($site_id,$created_at,$updated_at,$register_amount,$invite_register_amount,$trunname_amount,$c2c_trade_amount,$recharge_amount,$withdraw_amount,$coin_trade_amount,$register_total,$invite_register_total,$trunname_total,$c2c_trade_total,$recharge_total,$withdraw_total,$coin_trade_total,$time,$time_area),0);
    }

    //注册一览表入库
    public function add_register_data($site_id,$time_area,$time,$register_amount,$trunname_amount,$invite_register_amount,$invite_trunname_amount,$active_amount){
        return xlink('501231',array($site_id,$time_area,$time,$register_amount,$trunname_amount,$invite_register_amount,$invite_trunname_amount,$active_amount),0);
    }

    public function add_recharge_data($site_id,$time_area,$time,$asset,$amount,$price,$number,$people,$averge){
        return xlink('501232',array($site_id,$time_area,$time,$asset,$amount,$price,$number,$people,$averge),0);
    }
    //提现一览表入库
    public function add_withdraw_data($site_id,$time_area,$time,$asset,$amount,$price,$number,$people,$averge){
        return xlink('501235',array($site_id,$time_area,$time,$asset,$amount,$price,$number,$people,$averge),0);
    }


    public function add_buy_data($site_id,$time_area,$time,$order_total,$finish_order_total,$people,$total_amount,$amount,$averge_price,$finish_rate){
        return xlink('501233',array($site_id,$time_area,$time,$order_total,$finish_order_total,$people,$total_amount,$amount,$averge_price,$finish_rate),0);
    }

    public function add_sell_data($site_id,$time_area,$time,$order_total,$finish_order_total,$people,$total_amount,$amount,$averge_price,$finish_rate){
        return xlink('501234',array($site_id,$time_area,$time,$order_total,$finish_order_total,$people,$total_amount,$amount,$averge_price,$finish_rate),0);
    }

    public function add_cointrade($site_id,$time_area,$time,$symbol,$total,$number,$people,$BID_fee,$ASK_fee,$averge){
        return xlink('501236',array($site_id,$time_area,$time,$symbol,$total,$number,$people,$BID_fee,$ASK_fee,$averge),0);
    }

    public function add_admin_sendemail($content,$time)
    {
        return xlink('501254',array($content,$time),0);
    }

    //最近一次的注册一览表的数据
    public function last_register_data(){
        return xlink('501157',array(),0);
    }

    //最近一次的充值一览表的数据
    public function last_recharge_data(){
        return xlink('501158',array(),0);
    }

    //最近一次的提现一览表的数据
    public function last_withdraw_data(){
        return xlink('501159',array(),0);
    }
    //增加平台每日收支利润
    public function add_platform_inout($created_at,$time_area,$asset,$price,$trade_fee,$withdraw_fee,$activity_in,$activity_out,$trade_amount,$withdraw_amount)
    {
        return xlink('501252',array($created_at,$time_area,$asset,$price,$trade_fee,$withdraw_fee,$activity_in,$activity_out,$trade_amount,$withdraw_amount),0);
    }

    //最近一次的注册一览表的数据
    // public function last_register_data(){
    //     return xlink('501155',array(),0);
    // }
    // 
}
