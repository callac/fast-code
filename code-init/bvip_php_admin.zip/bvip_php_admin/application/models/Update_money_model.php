<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Update_money_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    //调账申请
    public function updatemoney_apply($admin_id,$created_time,$asset_code,$amount,$user_id,$remark,$site_id)
    {
        return xlink('501255',array($admin_id,$created_time,$asset_code,$amount,$user_id,$remark,$site_id),0);
    }

    //通过id获取调账申请详情
    public function info($id)
    {
        return xlink('601180',array($id),0);
    }
}
