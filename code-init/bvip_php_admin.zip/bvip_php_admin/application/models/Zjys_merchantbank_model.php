<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Zjys_merchantbank_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    //新增银行卡
    public function addbank($name,$bank,$sub_bank,$card_number,$created_at,$updated_at,$site_id,$type,$limit_money,$cash_deposit,$contact_way,$admin_id){
        return xlink(501203,array($name,$bank,$sub_bank,$card_number,$created_at,$updated_at,1,$site_id,$type,$limit_money,$cash_deposit,$contact_way,$admin_id),0);
    }

    //修改银行卡
    public function editbank($name,$bank,$sub_bank,$card_number,$updated_at,$id,$site_id,$type,$limit_money,$cash_deposit,$contact_way,$admin_id){
        return xlink(501305,array($name,$bank,$sub_bank,$card_number,$updated_at,$id,$site_id,$type,$limit_money,$cash_deposit,$contact_way,$admin_id),0);
    }

    //删除银行卡
    public function deletebank($status,$id)
    {
        return xlink(501308,array($status,$id),0);
    }
    //获取财务输入的信息
    public function get_bankinout_detail($id)
    {
        return xlink(501124,array($id),0);
    }
    //添加财务信息
    public function addflows($m_bank_id,$user_bank_number,$user_name,$amount,$type,$created_at,$updated_at,$trans_remark,$remark,$status,$site_id)
    {
        return xlink(501211,array($m_bank_id,$user_bank_number,$user_name,$amount,$type,$created_at,$updated_at,$trans_remark,$remark,$status,$site_id),0);
    }

     //修改财务信息
    public function editflows($m_bank_id,$user_bank_number,$user_name,$amount,$type,$updated_at,$trans_remark,$remark,$status,$id,$site_id)
    {
        return xlink(501320,array($user_bank_number,$user_name,$amount,$type,$updated_at,$trans_remark,$remark,$status,$id,$site_id),0);
    }

    public function get_info_per_user($m_bank_id,$type,$status,$name)
    {
        return xlink(501125,array($m_bank_id,$type,$status,$name));
    }


    public function update_caiwu_status($id,$status)
    {
        return xlink(501321,array($id,$status),0);
    }

    // 
    public function get_total_money($m_bank_id,$status,$type)
    {
        return xlink(501126,array($m_bank_id,$status,$type),0);
    }

    public function is_true_card($card_number)
    {
        return xlink(501151,array($card_number),0);
    }

    public function get_link_cardnumber($admin_id)
    {
        return xlink(501174,array($admin_id));
    }




}
