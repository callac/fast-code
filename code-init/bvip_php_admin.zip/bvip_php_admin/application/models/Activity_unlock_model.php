<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/3/1
 * Time: 11:01
 */

defined('BASEPATH') OR exit('No direct script access allowed');
class Activity_unlock_model extends Base_model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/1
     * Time: 11:03
     */
    public function add($operator,$created_at,$asset,$amount,$user_id,$remark,$site_id){
        return xlink(402230,array($operator,$created_at,$asset,$amount,$user_id,$remark,$site_id),0);
    }
}
