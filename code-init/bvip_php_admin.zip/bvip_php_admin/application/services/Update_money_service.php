<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Update_money_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Update_money_model');
        $this->load->model('Zjys_user_withdraw_model');
        $this->load->model('Zjys_user_operationmoney_model');
        $this->load->service('Transfer_service');
    }


    public function updatemoney_apply_list($offset,$limit,$start_time,$end_time,$site_id,$uid)
    {
        $object = $this->db->select("operation_money_apply.*,b_admin.true_name,b_site.name as site_name,users.realname")->
        from('operation_money_apply')
        ->join('b_admin','b_admin.user_id=operation_money_apply.admin_id','left')
        ->join('b_site','b_site.id=operation_money_apply.site_id','left')
        ->join('users','users.id=operation_money_apply.user_id','left');

        if($site_id!='') $object =$this->db->where('operation_money_apply.site_id = ',$site_id);
        // $object =$this->db->where('user_identities.deleted_at is null');
        if(!empty($uid)){
            $object =$this->db->where('operation_money_apply.user_id =',$uid);
        }

        if(!empty($start_time)){
            $object =$this->db->where('operation_money_apply.created_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('operation_money_apply.created_time <=',$end_time);
        }
        
        $list =  $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        return $list;
    } 

    public function updatemoney_apply_list_count($start_time,$end_time,$site_id,$uid)
    {
        $object = $this->db->select("*")->from('operation_money_apply');
        if($site_id!='') $object =$this->db->where('operation_money_apply.site_id = ',$site_id);
        // $object =$this->db->where('user_identities.deleted_at is null');
        if(!empty($uid)){
            $object =$this->db->where('operation_money_apply.user_id =',$uid);
        }

        if(!empty($start_time)){
            $object =$this->db->where('operation_money_apply.created_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('operation_money_apply.created_time <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    //调账申请
    public function updatemoney_apply($args)
    {
        $admin_id = $this->user_id;
        $created_time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $asset_code = trim($args['asset']);
        $remark = trim($args['remark']);
        $amount = bcsub(trim($args['amount']),'0',12);
        $user_id = trim($args['user_id']);
        $site_id = $this->db->query("select site_id from users where id=$user_id")->row_array()['site_id'];

        $this->db->trans_begin();
        $insert_id = $this->Update_money_model->updatemoney_apply($admin_id,$created_time,$asset_code,$amount,$user_id,$remark,$site_id);
        admin_operation_logs($admin_id,$user_id,40,$remark,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$insert_id); //调账申请提交 记录关键日志
        $res_status = true;
        if($amount<0){
            //预先查询user_asset_freeze冻结
            $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset_code,$user_id);
            if(empty($last_balance)) $last_balance['balance'] = '0';
            $balance = bcadd($last_balance['balance'],bcmul($amount,'-1',16),16);

            // var_dump($amount,bcmul($amount,'-1',12));
            // var_dump($last_balance['balance'],$balance);die;
            if($balance<0) $trans_status = false; //若满足则有异常冻结记录

            $detail1 = json_encode(array('id'=>$insert_id));
            $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
            $insert_id2 = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_time,$created_time,$user_id,$asset_code,bcmul($amount,'-1',16),$business,$balance,$detail1);
            //扣除可用
            $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
            $text = '申请调账预先扣除可用';
            $ss = array('info'=>$text);
            $res = update_user_balance_bycurl($user_id,$asset_code,$amount,$insert_id2,$ss,$business);
            
            if($res['result']['status'] !== 'success'){
                $res_status = false;
            }
        }
        $trans_status = $this->db->trans_status();

        // var_dump($trans_status===false);
        // var_dump($res_status===false);die;
        if ($trans_status === false || $res_status===false) {
            $this->db->trans_rollback();
            returnJson('402','数据：用户ID为：'.$user_id.',币种为：'.$asset_code.',数量为：'.$amount.'异常，申请调整资金失败，请检查数据合法性！');
        } else {
            $this->db->trans_commit();
            return true;
        }

    }

    public function update_money_check($id,$check_status,$check_remark)
    {
        // $a = '0.0000000023';
        // $b = '0.00000001';
        // var_dump(bccomp($a, $b,12));die;
        //获取调账申请记录详情
        $detail = $this->Update_money_model->info($id);
        // var_dump($detail);
        if($detail['check_status'] != 0) returnJson('402','记录审核状态异常');
        if($check_status == 0) returnJson('402','提交审核状态非法');
        $amount = bcsub($detail['amount'],'0',12);
        $site_id = $this->db->query("select site_id from users where id=$detail[user_id]")->row_array()['site_id'];

        $this->db->trans_begin();
        if($check_status==1){ //审核成功
            //写入日志
            admin_operation_logs($this->user_id,$detail['user_id'],41,$check_remark,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['id']);
            //判断是 加款还是扣款 
            
            // var_dump($amount);die;

            if($amount>0)
            {
                //调账增加，直接增加可用
                // $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
                $text = $detail['remark'];
                // $text = '申请调账审核通过增加可用';
                $ss = array('info'=>$text);
                $res = update_user_balance_bycurl($detail['user_id'],$detail['asset_code'],$amount,$detail['id'],$ss,'admin_updatemoney');
                
                // var_dump($site_id);die;
                $this->Zjys_user_operationmoney_model->add($this->user_id,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['asset_code'],$amount,$detail['user_id'],$text,$site_id,$type=1);
            
            }else{
                //预先查询user_asset_freeze冻结
                $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($detail['asset_code'],$detail['user_id']);
                // var_dump($last_balance['balance'],$amount);
                $balance = bcadd($last_balance['balance'],$amount,12);
                if($balance<0){
                    if(bccomp(bcmul($balance,'-1',12),'0.00000001',12) == -1){
                        $balance = '0';
                    }else{
                        returnJson('402','数据异常，操作失败！');
                    }
                }
                // var_dump($balance);die;
                //调账减少，扣除冻结，增加一条冻结流水
                $detail1 = json_encode(array('id'=>$detail['id']));
                $business = $this->config->item('ADMIN_UNFREEZE');//freeze表中的business
                $created_time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
                $text = $detail['remark'];
                // $text = '申请调账（负值）审核通过去掉冻结';
                $insert_id2 = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_time,$created_time,$detail['user_id'],$detail['asset_code'],$amount,$business,$balance,$detail1);
                $this->Zjys_user_operationmoney_model->add($this->user_id,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['asset_code'],$amount,$detail['user_id'],$text,$site_id,$type=1);
            }
            
            $data['check_status'] = $check_status;
            $data['check_remark'] = $check_remark;
            $data['check_time'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
            // var_dump($data);
            $this->db->where('id', $detail['id']);
            $this->db->update('operation_money_apply', $data);
        }else{
            // echo 2;die;
            //审核失败  check_status = 2;
            admin_operation_logs($this->user_id,$detail['user_id'],42,$check_remark,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['id']);
            $data['check_status'] = $check_status;
            $data['check_remark'] = $check_remark;
            $data['check_time'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
            $this->db->where('id', $detail['id']);
            $this->db->update('operation_money_apply', $data);
            if($amount<0)
            {
                //解除冻结，增加冻结流水记录
                $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($detail['asset_code'],$detail['user_id']);
                $balance = bcadd($last_balance['balance'],$amount,12);
                // var_dump($balance);die;
                if($balance<0) return false;
                //调账减少，扣除冻结，增加一条冻结流水
                $detail1 = json_encode(array('id'=>$detail['id']));
                $business = $this->config->item('ADMIN_UNFREEZE');//freeze表中的business
                $created_time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
                $insert_id2 = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_time,$created_time,$detail['user_id'],$detail['asset_code'],$amount,$business,$balance,$detail1);
                //审核失败，还回可用
                $text = $detail['remark'];
                // $text = '申请调账审核失败增加可用';
                $ss = array('info'=>$text);
                $res = update_user_balance_bycurl($detail['user_id'],$detail['asset_code'],-$amount,$insert_id2,$ss,'admin_updatemoney');
                // $this->Zjys_user_operationmoney_model->add($this->user_id,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['asset_code'],-$amount,$detail['user_id'],$text,$site_id,$type=1);
            }
        }
        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            returnJson('402','Transaction failed');
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    public function test_batch_enough_money($id,$check_status,$check_remark)
    {
        $detail = $this->Update_money_model->info($id);
        if($detail['check_status'] != 0) returnJson('402','id为'.$id.'的记录审核状态异常');
        if($check_status == 0) returnJson('402','id为'.$id.'的提交审核状态非法');

        if($detail['amount']<0){
            $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($detail['asset_code'],$detail['user_id']);
            $balance = bcadd($last_balance['balance'],$detail['amount'],12);
            if($balance<0){
                if(bccomp(bcmul($balance,'-1',12),'0.00000001',12) == -1){
                    $balance = '0';
                }else{
                    returnJson('402','数据异常，操作失败！');
                }
            }
                // returnJson('402','id为'.$detail['user_id'].'的'.$detail['asset_code'].'冻结不足,当前冻结'.$last_balance['balance'].'个,您希望解除冻结'.$detail['amount'].'个');
        }
        

        // $result = $this->Transfer_service->check_balance($detail['user_id'],$detail['asset_code']);
        
        // $amount = bcadd($detail['amount'],$result['balance'],12);

        // if($amount<0)
        // {
        //     returnJson('402','id为'.$detail['user_id'].'的'.$detail['asset_code'].'账户余额不足,当前余额'.$result['balance'].'个,您希望调整'.$detail['amount'].'个');
        // }
    }
}
