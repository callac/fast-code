<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-07-30
 * Time: 18:17
 */



class Time_task_service extends MY_Service
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Transfer_model');
    }


    public function getTradeZoneData($args)
    {
        $start_time_timestamp = get_last_day($args); 
        $end_time_timestamp = $start_time_timestamp+86400;
        $data = array();
       // $asset_arr = array('CNT','ETH','BTC','USDT');
        $start_time = date("Y-m-d", $start_time_timestamp);
        $end_time = date("Y-m-d", $end_time_timestamp);
            //获取当天的有交易数据的站点
            $object = $this->db->select("site_id")
                ->from('perday_coin_trade_statistics');
            $object = $this->db->group_by ('site_id');
            $object =$this->db->where('perday_coin_trade_statistics.time >=',$start_time);
            $object =$this->db->where('perday_coin_trade_statistics.time <',$end_time);
            $site = $object->get()->result_array();
        $number = 0;
        $real_number = 0;

            foreach ($site as $key => $val){

                $data = array();
                $arr = array();
                $arr1 = array();
                $asset_arr = array('CNT','ETH','BTC','USDT');


                $trading_amount = 0;
                $real_trading_amount = 0;

                $site_id = $val['site_id'];
                foreach ($asset_arr as $key => $val){
                    $trade_zone = $this->Transfer_model->trade_zone_details($start_time,$end_time,$site_id,$val);
                    $real_trade_zone = $this->Transfer_model->real_trade_zone_details($start_time,$end_time,$site_id,$val);
                    foreach ($trade_zone as $key1 => $val1){
                        // var_dump($val1);
                        $symbol_last =  substr($val1['symbols'],strripos($val1['symbols'],"_")+1); //后
                        // $symbol_fir =  substr($val['symbols'],0,strripos($val['symbols'],"_")); //前
                        if($symbol_last != 'CNT') {
                            $symbol1 = $symbol_last . '_' . 'CNT';
                            $time = $val1['time'];
                            $time = strtotime($time) + 86400;
                            $time = date("Y-m-d H:i:s", $time);
                            $time1 = strtotime($time) + 96400;
                            $time2 = date("Y-m-d H:i:s", $time1);
                            $object = $this->db->select("symbols_price.*")
                                ->from('symbols_price');
                            $object = $this->db->where('symbols_price.symbols = ', $symbol1);
                            $object = $this->db->where('symbols_price.created_at > ', $time);
                            $object = $this->db->where('symbols_price.created_at < ', $time2);
                            $list1 = $object->get()->result_array();
                            if (empty($list1)) $list1[0]['price'] = 0;

                            $arr[$key1]['trading_amount'] = $val1['trading_amount'] * $list1[0]['price'];
                        }else{
                            $arr[$key1]['trading_amount'] = $val1['trading_amount'];
                        }

                        $trading_amount += $arr[$key1]['trading_amount'];
                    }



                    foreach ($real_trade_zone as $key2 => $val2){
                        $symbol_last =  substr($val2['symbols'],strripos($val2['symbols'],"_")+1); //后
                        // $symbol_fir =  substr($val['symbols'],0,strripos($val['symbols'],"_")); //前
                        if($symbol_last != 'CNT') {
                            $symbol1 = $symbol_last . '_' . 'CNT';
                            $time = $val2['time'];
                            $time = strtotime($time) + 86400;
                            $time = date("Y-m-d H:i:s", $time);
                            $time1 = strtotime($time) + 96400;
                            $time2 = date("Y-m-d H:i:s", $time1);
                            $object = $this->db->select("symbols_price.*")
                                ->from('symbols_price');
                            $object = $this->db->where('symbols_price.symbols = ', $symbol1);
                            $object = $this->db->where('symbols_price.created_at > ', $time);
                            $object = $this->db->where('symbols_price.created_at < ', $time2);
                            $list1 = $object->get()->result_array();
                            if (empty($list1)) $list1[0]['price'] = 0;

                            $arr1[$key2]['trading_amount'] = $val2['trading_amount'] * $list1[0]['price'];
                        }else{
                            $arr1[$key2]['trading_amount'] = $val2['trading_amount'];
                        }

                        $real_trading_amount += $arr1[$key2]['trading_amount'];
                    }



//
//            if(empty($trade_zone['unit_price'])){
//                $trade_zone['unit_price'] = 0;
//                $trade_zone['trading_amount'] = 0;
//            }
//            if(empty($real_trade_zone['unit_price'])){
//                $real_trade_zone['unit_price'] = 0;
//                $real_trade_zone['trading_amount'] = 0;
//            }

                    $number += $trading_amount;
                    $real_number += $real_trading_amount;


                    $trading_amount = 0;
                    $real_trading_amount = 0;
                }


//                $trade_zone = $this->Transfer_model->trade_zone($val['site_id'],$start_time,$end_time);
//                $real_trade_zone = $this->Transfer_model->real_trade_zone($val['site_id'],$start_time,$end_time);
//
//                //$data[$i][$key]['site_id']=$val['site_id'];
//                if(empty($trade_zone)) $trade_zone['trading_amount'] = '0';
//                if(empty($real_trade_zone)) $real_trade_zone['trading_amount'] = '0';
                $data['time']=$start_time;
                $data['trading_amount']= $number ;
                $data['real_trading_amount']=$real_number;
                $data['site_id']=$site_id;
                //插入统计数据表中
                $created_at = date("Y-m-d H:i:s", time());
                $data ['created_at'] = $created_at;
                //新增
                $this->db->insert('perday_trade_money', $data);

                $number = 0;
                $real_number = 0;

            }

      //  }
        //二维数组变一维数组
     //   $data1 = array_reduce($data, 'array_merge', array());
       // var_dump(count($data1),$data1);die();
        //select * from perday_coin_trade_statistics where RIGHT(symbols,length('CNT')) = 'CNT' and time >= '2019-03-14 00:00:00' and time < '2019-03-15 00:00:00' and site_id = 146
        //获取该表所有站点
        //select * from perday_coin_trade_statistics group by site_id

    }
}


