<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Keylog_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Keylog_model');    
    }   

    //关机日志记录列表
    //type 为 日志的类型（法币1、提币2、更改管理员权限3）
    public function keylog_list($offset,$limit,$user_id,$admin_id,$start_time,$end_time,$type){
        $object = $this->db->select("admin_operation_logs.*,b_admin.true_name as admin_name")
            ->join('b_admin','b_admin.user_id=admin_operation_logs.admin_id','left')
            ->from('admin_operation_logs');
        if($type==1) //法币相关
            $object =$this->db->where('admin_operation_logs.operation_type in (4,5,10,6,11,7)');
        if($type==2) //提币相关
            $object = $this->db->where('admin_operation_logs.operation_type in (1,8,2,3,13,14)');
        if($type==4) //交易API相关
            $object = $this->db->where('admin_operation_logs.operation_type in (31,32)');   
        if(!empty($admin_id)){
            $object =$this->db->where('b_admin.user_id =',$admin_id);
        }
        if(!empty($user_id)){
            $object =$this->db->where('admin_operation_logs.user_id =',$user_id);
        }
        if(!empty($start_time)){
            $object =$this->db->where('admin_operation_logs.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('admin_operation_logs.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();

        // var_dump($this->db->last_query());die;
        foreach ($list as &$value) {
            if($value['operation_type']==4)
                $value['operation_type'] = 'c2c交易买入审核失败';
            if($value['operation_type']==5)
                $value['operation_type'] = 'c2c交易买入再次审核成功';
            if($value['operation_type']==10)
                $value['operation_type'] = 'c2c交易买入初次审核成功';
            if($value['operation_type']==6)
                $value['operation_type'] = 'c2c交易卖出审核失败';
            if($value['operation_type']==11)
                $value['operation_type'] = 'c2c交易卖出再次审核成功';
            if($value['operation_type']==7)
                $value['operation_type'] = 'c2c交易卖出初次审核成功';
            if($value['operation_type']==1)
                $value['operation_type'] = '提币初次审核拒绝';
            if($value['operation_type']==8)
                $value['operation_type'] = '提币再次审核拒绝';
            if($value['operation_type']==2)
                $value['operation_type'] = '提币初次审核通过';
            if($value['operation_type']==3)
                $value['operation_type'] = '提币再次审核通过';
            if($value['operation_type']==13)
                $value['operation_type'] = '提币手动置为失败';
            if($value['operation_type']==14)
                $value['operation_type'] = '提币重新发送';
        }
        return $list;
    }

    //获取数量
    public function keylog_list_count($user_id,$admin_id,$start_time,$end_time,$type){
            // echo 111;die;
        $object = $this->db->select("admin_operation_logs.*,b_admin.name as admin_name")
            ->join('b_admin','b_admin.user_id=admin_operation_logs.admin_id','left')
            ->from('admin_operation_logs');

        if($type==1) //法币相关
            $object =$this->db->where('admin_operation_logs.operation_type in (4,5,10,6,11,7)');
        if($type==2) //提币相关
            $object = $this->db->where('admin_operation_logs.operation_type in (1,8,2,3,13,14)');
        if($type==4) //交易API相关
            $object = $this->db->where('admin_operation_logs.operation_type in (22,21)'); 
        if(!empty($admin_id)){
            $object =$this->db->where('b_admin.user_id =',$admin_id);
        }
        if(!empty($user_id)){
            $object =$this->db->where('admin_operation_logs.user_id =',$user_id);
        }
        if(!empty($start_time)){
            $object =$this->db->where('admin_operation_logs.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('admin_operation_logs.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }
}
