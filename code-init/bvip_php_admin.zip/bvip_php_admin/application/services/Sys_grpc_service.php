<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Sys_grpc_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        require_once './vendor/autoload.php';
    }

    public function wallet_recharge($asset,$stime,$etime,$log_type){
        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure()
        ]);
        $req = new \Sys\QueryWalletReq();
        $startTime = new \Google\Protobuf\Timestamp();
        $startTime->setSeconds(strtotime($stime));
        $req->setStartTime($startTime);
        $endTime = new \Google\Protobuf\Timestamp();
        $endTime->setSeconds(strtotime($etime));
        $req->setEndTime($endTime);
        $req->setAssetCode($asset);
        if($log_type==='RECHARGE')
            $req->setLogType(\Sys\QueryWalletReq\Log_type::RECHARGE);
        if($log_type==='WITHDRAW')
            $req->setLogType(\Sys\QueryWalletReq\Log_type::WITHDRAW);

        list($reply, $status) = $client->QueryWalletReconciliation($req)->wait();
        // var_dump($reply);
        // var_dump($status);die;
        $res = object_to_array($status);

        $arr = json_decode($reply->getResult(), true);
        if($res['code']==0){
            return $arr;
        }else{
            return false;
        }
    }


    //撤销市场单个交易对所有订单
    public function cancel_order_market($market){
        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure()
        ]);
        $req = new \Sys\CancelMarketOrdersReq();
        $req->setMarket($market);
        list($reply, $status) = $client->CancelMarketOrders($req)->wait();
        $res = object_to_array($status);
        if($res['code']==0){
            return true;
        }else{
            return false;
        }
    } 

    //撤销市场单个用户单个交易对所有订单
    public function cancel_order_user_market($user_id,$market){
        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure()
        ]);
        $req = new \Sys\CancelUserOrdersReq();
        $req->setMarket($market);
        $req->setUserId($user_id);
        list($reply, $status) = $client->CancelUserOrders($req)->wait();
        $res = object_to_array($status);
        if($res['code']==0){
            return true;
        }else{
            return false;
        }
    }     


    //查询钱包资产
    public function QueryWalletBalance($asset,$time){
        //var_dump($asset,$time);
        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure()
        ]);
        $req = new \Sys\QueryWalletBalanceReq();
        $req->setAsset($asset);
        $req->setDate($time);
        list($reply, $status) = $client->QueryWalletBalance($req)->wait();
        $res = object_to_array($status);
        //var_dump($res,$reply);die();
        $arr = json_decode($reply->getResult(), true);
        if($res['code']==0){
            return $arr;
        }else{
            return false;
        }
    }


    //用户注册
    public function CreateWalletUser($user_id){
        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure()
        ]);
        $req = new \Google\Protobuf\GPBEmpty();
        list($reply, $status) = $client->CreateWalletUser($req)->wait();
        $res = object_to_array($status);
        if($res['code']==0){
            return $reply->getUserId();
        }else{
            return false;
        }
    }

    //生成钱包地址
    public function CreateWalletAddress($asset,$user_id){
        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);
        $req = new \Sys\CreateWalletAddressReq();
        $req->setUserId($user_id);
        $req->setAsset($asset);
        list($reply, $status) = $client->CreateWalletAddress($req)->wait();
        $res = object_to_array($status);

        if($res['code']==0){
            $arr = $reply->getAddress();
            return $arr;
        }else{
            return false;
        }

    }


    //批量生成用户
    public function BatchCreateUsers($mobile){

        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);

        $req = new \Sys\BatchCreateUsersReq();
        $req->setUsernames(array($mobile));
        $req->setDefaultPassword("vip123456");
        $req->setCountryId("86");
        $req->setSiteId('124');
        list($reply, $status) = $client->BatchCreateUsers($req)->wait();
        $res = object_to_array($status);
        if($res['code']==0){
            return true;
        }else{
            return false;
        }
    }

    //充值审核
    public function VerifyRecharge($recharge_id,$status){

        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);

        $req = new \Sys\VerifyRechargeReq();
        $req->setStatus(\Sys\VerifyRechargeReq\Status_type::SUCCESS);
        $req->setRechargeLogId($recharge_id);
        list($reply, $status) = $client->VerifyRecharge($req)->wait();
        $res = object_to_array($status);
        if($res['code']==0){
            return true;
        }else{
            return false;
        }
    }

    //将提现审核成功的手动设置成失败
    public function SetWithdrawStatusToFail($WithdrawId,$remark){

        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);
        $req = new \Sys\SetWithdrawStatusToFailReq();
        $req->setUserWithdrawId($WithdrawId);
        $req->setRemark($remark);
        list($reply, $status) = $client->SetWithdrawStatusToFail($req)->wait();
        $res = object_to_array($status);
       // var_dump($reply, $status);
//        if($res['code']==0){
//            return true;
//        }else{
//            //return $res['details'];
//            return false;
//        }
        return $res;
    }

    /**
     * Notes: 活动资产变化
     * User: 张哲
     * Detail: 1 => 活动奖励实时分发，此时的type = 0，is_unlocked = false
     * Detail: 2 => 活动奖励冻结，此时的type = 1，is_unlocked = false
     * Detail: 3 => 活动奖励解冻，此时的type = 1, is_unlocked = true
     * Date: 2019/2/28
     * Time: 20:36
     */
    public function ActivityBalanceUpdate($uid,$type,$asset,$bussness,$bussness_id,$amount,$site_id,$detail,$remark){

        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);
        $req = new \Sys\ActivityBalanceUpdateReq();
        $req->setUserId($uid); //用户id
        $req->setType($type); //类型
        $req->setAsset($asset); //币种
        $req->setBusiness($bussness);// 业务
        $req->setBusinessId($bussness_id); // 业务ID
        $req->setChange($amount); //更新资金
        $req->setDetail($detail); //详情
        $req->setSiteId($site_id); //站点
        $req->setRemark($remark); //备注
        $req->setActivityUnique(''); //活动唯一编号
        $req->setActivityType(0); //活动类型
        $req->setIsUnlocked(true); //是否解锁 false / true
        list($reply, $status) = $client->ActivityBalanceUpdate($req)->wait();
        $res = object_to_array($status);
         //var_dump($reply, $status);
//        if($res['code']==0){
//            return true;
//        }else{
            //return $res['details'];
            return $res;
       // }
    }


    /**
     * Notes: 发送验证码
     * User: 张哲
     * Date: 2019/3/14
     * Time: 10:36
     * @return bool
     */
    public function AdminSendVerifyMessage($account,$ip){
        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);
        $req = new \Sys\AdminSendVerifyMessageReq();
        $req->setUsername($account);
        $req->setUseType(\Sys\AdminSendVerifyMessageReq\Use_type::UserValidUseTypeAdminLogin);
        $req->setIp($ip);
        list($reply, $status) = $client->AdminSendVerifyMessage($req)->wait();
        $res = object_to_array($status);
        return $res;
    }

    /**
     * 重新发起提币请求
     */
    public function ResendWithdraw($WithdrawId){

        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);
        $req = new \Sys\ResendWithdrawReq();
        $req->setWithdrawId($WithdrawId);
        list($reply, $status) = $client->ResendWithdraw($req)->wait();
        $res = object_to_array($status);

        if($res['code']==0)
            return true;
        else
            return $res['details'];

    }

    /**
     * 手动二次校验通过时校验钱包的手动充值记录
     */
    public function CheckRecharge($asset,$recharge_hash,$recharge_address,$amount,$remark){

        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);
        $req = new \Sys\RechargeSupplementReq();
        $req->setCoinCode($asset);
        $req->setTxCode($recharge_hash);
        $req->setTo($recharge_address);
        $req->setAmount($amount);
        $req->setRemark($remark);
        list($reply, $status) = $client->RechargeSupplement($req)->wait();
        $res = object_to_array($status);

        if($res['code']==0)
            return true;
        else
            return $res['details'];

    }


    /**
     * 手动二次校验通过时校验钱包的手动充值记录
     */
    public function FirstCheckRecharge($asset,$recharge_hash,$recharge_address,$amount){

        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure(),
        ]);
        $obj = 'ss';
        $req = new \Sys\RechargeSupplementCheckReq();
        $req->setCoinCode($asset);
        $req->setTxCode($recharge_hash);
        $req->setTo($recharge_address);
        $req->setAmount($amount);
        $req->setObj($obj);
        // var_dump($client,$req);die;
        list($reply, $status) = $client->RechargeSupplementCheck($req)->wait();
        $res = object_to_array($status);
        var_dump($res);die;

        if($res['code']==0)
            return true;
        else
            return $res['details'];

    }



    
}
