<?php   if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-05-21
 * Time: 10:10
 */

class Knowledge_base_service extends MY_Service
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 知识库列表
     * User: 张哲
     * Date: 2019-05-21
     * Time: 10:16
     */
    public function knowledge_base_list($offset, $limit,$title)
    {
       // var_dump($title);die();
        $object = $this->db->select("knowledge_base.*")
            ->from('knowledge_base');
           // ->like('knowledge_base.title', "%".$title."%");

        $object = $this->db->where('knowledge_base.deleted_at is null');
        $object = $this->db->like('knowledge_base.title',$title);

        $list = $object->limit($limit, $offset)->order_by('created_at', 'desc')->get()->result_array();
        return $list;
    }

    /**
     * Notes: 知识库数量
     * User: 张哲
     * Date: 2019-05-21
     * Time: 10:16
     */
    public function knowledge_base_count()
    {
        $object = $this->db->select("knowledge_base.*")
            ->from('knowledge_base');

        $object = $this->db->where('knowledge_base.deleted_at is null');

        return $this->db->count_all_results();
    }


    /**
     * Notes: 知识库编辑
     * User: 张哲
     * Date: 2019-05-21
     * Time: 10:16
     */
    public function knowledge_base_add($args)
    {
        $id = isset($args['id']) ? $args['id'] : '';
        if (!$id) {
            $created_at = date("Y-m-d H:i:s", time());
            $args ['created_at'] = $created_at;
            //新增
            $business_id = $this->db->insert('knowledge_base', $args);
        } else {
            $updated_at = date("Y-m-d H:i:s", time());
            $args ['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $this->db->update('knowledge_base', $args);
        }
        return true;
    }


    /**
     * Notes: 知识库删除
     * User: 张哲
     * Date: 2019-05-21
     * Time: 10:17
     */
    public function knowledge_base_delete($args)
    {

        $data = array();
        $id = isset($args['id']) ? $args['id']: '';
        $deleted_at = date("Y-m-d H:i:s", time());
        $args['deleted_at'] = $deleted_at;
        $this->db->where('id', $id);
        $this->db->update('knowledge_base', $args);
    }

}