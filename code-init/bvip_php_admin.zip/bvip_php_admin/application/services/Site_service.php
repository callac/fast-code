<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site_service extends MY_Service {

    public static $currency_type = array(
        '1' => '人民币',
        '2' => '美元',
        '3' => '日元',


    );
    public static $pay_type = array(
        '1' => 'paypal',
        '2' => '支付宝',
        '3' => '银行卡',
    );
    public static $otc_asset = array(
        'USDT' => 'USDT',
        'BTC' => 'BTC',
        'ETH' => 'ETH',
        'CNYQ' => 'CNYQ',
    );
    public static $otc_currency = array(
        '人民币' => '人民币',
        '美元' => '美元',
    );
    public static $language = array(
        'english' => '英文',
        'chinese' => '中文',
        'japanese' => '日文'
    );
    public static  $account_type = array(
        '1' => '邮箱',
        '2' => '手机号'
    );
    public static  $juhe = array(
        '1' => 'CNY',
        '2' => 'USD',
        '3' => 'JPY',
    );

    public function __construct()
    {
        parent::__construct();
        $this->config->load('xlink', TRUE);      
        $xlink = $this->config->item('xlink');
        if ($xlink['enable'] === TRUE) {
            $this->load->helper('xlink_tcp');
        } else {
            $this->load->database();
            $this->load->helper('xlink_db');
        }
        $this->load->model('Site_model');
        $this->load->model('Site_domain_model');
        $this->load->model('Site_admin_model');
        $this->load->model('Site_roles_model');
        $this->load->model('Zjys_assets_model');
        $this->load->model('Zjys_symbols_model');
    }

    /**
    *获取站点配置信息
    *
     */
    public function get_site_info($domain){
       
        $this->load->model('Site_domain_model');

        $site_info = $this->Site_domain_model->get_site_info($domain);
    
        return $site_info;
    }


    public function get_site($site_id){
        return $this->Site_domain_model->get_site($site_id);
    }

    public function site_info(){
        return $this->Site_domain_model->site_info();
    }

    //分页获取站点列表
    public function get_list($offset,$limit,$site_name,$site_id){
        $list  =  $this->Site_model->get_list($offset,$limit,$site_name,$site_id);
        foreach ($list as &$value){
            $privilages = $this->conversion_privilages($value['privilages']);
            foreach ($privilages as $key=>$val){
                $value[$key] = $val;
            }
            $value['domain_arr'] = $this->Site_domain_model->get_list_by_site_id($value['id']);
        }
        return $list;
    }

    //站点权限转换
    public function conversion_privilages($str,$name=false){
        $privilages = explode(',', $str);
        $this->load->model('Site_roles_model');
        $roles = array();
        $roles_pid_list = $this->Site_roles_model->get_list_pid(-1);
        foreach ($roles_pid_list as $val){
            $roles[$val['priv_name']] = $roles_list =$this->Site_roles_model->get_list_pid($val['id']);
        }
        $a = array();
        foreach ($roles as $key => &$val){
            foreach ($val as &$v){
                if(in_array($v['id'],$privilages)){
                    if($name){
                        $a[$key][] = array($v['priv_name'] => $v['description']);
                    }else{
                        $a[$key][] = array($v['priv_name'] => true);
                    }
                }else{
                    $a[$key][] = array($v['priv_name'] => false);
                }
            }
        }
        $rr =array();
        $rr1 =array();
        foreach ($a as $key => $value) {
            foreach ($value as $k => $v){
                $rr = array_merge($rr,$v);
            }
            $rr1[$key] = $rr;
            unset($rr);
            $rr =array();
        }
        return $rr1;
    }

    //统计
    public function get_count($site_name){
        return $this->Site_model->get_count($site_name);
    }

    public function site_all(){
        $list = $this->Site_model->site_all();

        return $list;
    }

    //新增站点
    public function add_site($args){
        // var_dump($args);die;
        $site_name = $args['name']; //子站名称
        $domain = $args['domain']; //子站域名
        $title = isset($args['title']) ? $args['title']: '';  //标题
        $logo = isset($args['logo']) ?$args['logo'] : ''; //logo
        $icon = isset($args['icon']) ?$args['icon'] : ''; //icon
        $parent_id = isset($args['parent_id']) ?$args['parent_id'] : 0; //父级站点id

        $domain_user = $args['domain_user']; //联系人
        $mobile = isset($args['domain_userphone']) ?$args['domain_userphone'] : '' ; //联系方式
        $email = isset($args['email']) ?$args['email'] : '' ; //联系方式(邮箱)
        $remark = isset($args['remark']) ?$args['remark'] : '' ; //备注信息备注信息
        $service_email = isset($args['service_email']) ?$args['service_email'] : '' ;
        $service_js = isset($args['service_js']) ?$args['service_js'] : '' ;
        $tongji_js = isset($args['tongji_js']) ?$args['tongji_js'] : '' ;
        $qq = isset($args['qq']) ?$args['qq'] : '';
        $udesk_js = isset($args['udesk_js']) ?$args['udesk_js'] : '';
        $udesk_key = isset($args['udesk_key']) ?$args['udesk_key'] : '';
        $identity_method = isset($args['identity_method']) ?$args['identity_method'] : '';//实名认证方式0为自动，1为手动，2为两者都有
        $recommend_code_force = isset($args['recommend_code_force']) ?$args['recommend_code_force'] : '';//邀请码是否必填配置
        $default_register_method = isset($args['default_register_method']) ?$args['default_register_method'] : 1;//默认客户端注册方式1:手机 2:邮箱
        $otc_asset = isset($args['otc_asset']) ? $args['otc_asset']: ''; //otc币种
        $otc_currency = isset($args['otc_currency']) ? $args['otc_currency']: ''; //otc法币
        $seo_title = isset($args['seo_title']) ?$args['seo_title'] : '';
        $seo_keywords = isset($args['seo_keywords']) ?$args['seo_keywords'] : '';
        $seo_content = isset($args['seo_content']) ?$args['seo_content'] : '';

        $settlement_percent = isset($args['settlement_percent']) ?$args['settlement_percent'] : 0;
        $ts_status = isset($args['ts_status']) ?$args['ts_status'] : 0;
        $ws_status = isset($args['ws_status']) ?$args['ws_status'] : 0;


        $language = isset($args['language']) ? $args['language']: ''; //支持语言

        $asset_type = $args['asset_type']; //资产类型
        $symbol_type = isset($args['symbol_type']) ? $args['symbol_type']: ''; //交易对类型
        $general= isset($args['general']) ?$args['general'] : array(); //通用配置模块
        $ios_url= isset($args['ios_url']) ?$args['ios_url'] : ''; 
        $android_url= isset($args['android_url']) ?$args['android_url'] : ''; 
        $style= isset($args['style']) ?$args['style'] : 'default'; 
        // $style = $args['style'];  //模板

        //模块功能
        $product = isset($args['product']) ?$args['product'] : array(); //产品模块
        $money = isset($args['money']) ?$args['money'] : array(); //资金
        $account = isset($args['account']) ?$args['account'] : array(); //用户信息
        $site_roles = array_merge($product,$money,$account,$general);
        // var_dump($site_roles);die;
        $this->db->trans_begin();
        //查看username是否重名
        $res = $this->Site_admin_model->get_admin_by_username($domain_user);
        if($res) return false;
        $this->load->model('Site_roles_model');
        $site_info = $this->Site_roles_model->get_all();
        $roles = array();
        foreach ($site_info as $val){
            if(in_array($val['priv_name'],$site_roles)){
                $roles[] =   $val['id'];
            }
        }

        // var_dump($roles);die;
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());
        $roles = implode(',',$roles); //数组转字符串
        // var_dump($roles);die;
        $site_id = $this->Site_model->add($site_name,$title,$logo,$icon,$style,$language,$roles,$remark,$asset_type,$symbol_type,$service_email,$service_js,$tongji_js,$ios_url,$android_url,$qq,$udesk_js,$udesk_key,$identity_method,$recommend_code_force,$default_register_method,$seo_title,$seo_keywords,$seo_content,$otc_asset,$otc_currency,$settlement_percent,$ts_status,$ws_status); //写入b_site表
        //根据站点写入assets 和 symbols表
        $asset_type = explode(',',$asset_type);
        $symbol_type = explode(',',$symbol_type);

        if($this->config->item('SITE') === 'priv_one'){
            for($i=0;$i<count($asset_type);$i++) {
            # code...
            //取当前币种的详细参数
            $v = $this->Zjys_assets_model->get_asset_detail($asset_type[$i],$site_id);
            $this->Zjys_assets_model->add_asset($v['asset_code'],$v['asset_name'],$v['recharge_status'],$v['withdraw_status'],$v['trade_status'],$v['withdraw_fee'],$v['precision'],$site_id,$created_at,$updated_at,$v['withdraw_min'],$v['withdraw_max'],$v['is_display'],$v['has_memo']);
            }

            for($i=0;$i<count($symbol_type);$i++) {
                //取当前币种的详细参数
                $v = $this->Zjys_symbols_model->get_symbol_detail($symbol_type[$i],$site_id);
                $this->Zjys_symbols_model->add_symbol($v['base_asset'],$v['quote_asset'],$v['symbol'],$v['tick_size'],$v['min_quantity'],$v['status'],$v['recommend'],$v['limit_taker_fee'],$v['limit_maker_fee'],$v['market_taker_fee'],$site_id,$created_at,$updated_at,$v['base_asset_precision'],$v['quote_asset_precision'],$v['base_asset_name'],$v['quote_asset_name'],$v['alert_percent']);
            }
        }else{
            for($i=0;$i<count($asset_type);$i++) {
                $v = $this->Zjys_assets_model->get_sys_asset_detail($asset_type[$i]);
                if($v['sub_true'] == 1){
                    $this->Zjys_assets_model->add_asset_true($v['asset_code'],$v['asset_name'],$v['recharge_status'],$v['withdraw_status'],$v['trade_status'],$v['withdraw_fee'],$v['precision'],$site_id,$created_at,$updated_at,$v['withdraw_min'],$v['withdraw_max'],$v['sub_true'],$v['has_memo'],$v['regex'],$v['warning_status'],$v['withdraw_fee_percent']);
                }else{
                    $this->Zjys_assets_model->add_asset_true($v['asset_code'],$v['asset_name'],0,0,0,$v['withdraw_fee'],$v['precision'],$site_id,$created_at,$updated_at,$v['withdraw_min'],$v['withdraw_max'],$v['sub_true'],$v['has_memo'],$v['regex'],$v['warning_status'],$v['withdraw_fee_percent']);
                }
            }

            for($i=0;$i<count($symbol_type);$i++) {
                //取当前币种的详细参数
                $v = $this->Zjys_symbols_model->get_sys_symbol_detail($symbol_type[$i]);
                if($v['sub_true'] == 1)
                {
                    $this->Zjys_symbols_model->add_symbol_true($v['base_asset'],$v['quote_asset'],$v['symbol'],$v['tick_size'],$v['min_quantity'],$v['status'],$v['recommend'],$v['limit_taker_fee'],$v['limit_maker_fee'],$v['market_taker_fee'],$site_id,$created_at,$updated_at,$v['base_asset_precision'],$v['quote_asset_precision'],$v['sub_true'],$v['base_asset_name'],$v['quote_asset_name'],$v['alert_percent']);
                }else{
                    $this->Zjys_symbols_model->add_symbol_true($v['base_asset'],$v['quote_asset'],$v['symbol'],$v['tick_size'],$v['min_quantity'],0,$v['recommend'],$v['limit_taker_fee'],$v['limit_maker_fee'],$v['market_taker_fee'],$site_id,$created_at,$updated_at,$v['base_asset_precision'],$v['quote_asset_precision'],$v['sub_true'],$v['base_asset_name'],$v['quote_asset_name'],$v['alert_percent']);
                }
            }
        }

        $domainarr = explode(';', $domain);
        for($i=0;$i<count($domainarr);$i++)
        {
            $this->Site_domain_model->add($domainarr[$i],$site_name,$site_id); //写入site_domain表
        }
        
        $this->Site_admin_model -> add($site_id,$domain_user,$domain_user,'',$email,$mobile);//写入b_site_admin表
        if($this->config->item('SITE') === 'priv'){
            require(APPPATH.'config/template_site.php');
            $this->load->service('Config_service');

            //默认添加上网站基本信息
            $banner_template['site_id'] = $site_id;
            // var_dump($banner_template);die;
            $helps_template['site_id'] = $site_id;
            $helps_class_template['site_id'] = $site_id;
            $news_template['site_id'] = $site_id;
            $about_us_template['site_id'] = $site_id;
            $privacy_policy_template['site_id'] = $site_id;
            $user_agreement_template['site_id'] = $site_id;

            // $this->Config_service->banner_update($banner_template);

            $help_class_id = $this->Config_service->help_class_add($helps_class_template);
            $helps_template['help_class_id'] = $help_class_id;

            $this->Config_service->help_update($helps_template);
            $this->Config_service->newsAdd($news_template);
            $this->Config_service->agreement_update($about_us_template);
            $this->Config_service->agreement_update($privacy_policy_template);
            $this->Config_service->agreement_update($user_agreement_template);

        }
        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    //编辑站点
    public function update($args){
        $site_name = $args['name']; //子站名称
        // var_dump($args);die;
        if($this->config->item('SITE') === 'priv_one'){
            $domain = $args['domain'][0]['domain'];
        }else{
            $domain = $args['domain']; //子站域名
        }
        $title = isset($args['title']) ? $args['title']: '';  //标题
        $logo = isset($args['logo']) ?$args['logo'] : ''; //logo
        $icon = isset($args['icon']) ?$args['icon'] : ''; //icon
        $domain_user = $args['domain_user']; //联系人
        $mobile = isset($args['domain_userphone']) ?$args['domain_userphone'] : '' ; //联系方式
        $email = isset($args['email']) ?$args['email'] : '' ; //联系方式(邮箱)
        $remark = isset($args['remark']) ?$args['remark'] : '' ; //备注信息
        $service_email = isset($args['service_email']) ?$args['service_email'] : '' ; 
        $service_js = isset($args['service_js']) ?$args['service_js'] : '' ;
        $tongji_js = isset($args['tongji_js']) ?$args['tongji_js'] : '' ;
        
        $language = isset($args['language']) ? $args['language']: ''; //支持语言
        $is_preaudit = isset($args['is_preaudit']) ? $args['is_preaudit']: '1';
        if($is_preaudit == 1){
            $this->Site_model->update_preaudi(1);
        }else{
            $this->Site_model->update_preaudi(0);
        }


        $asset_type = isset($args['asset_type']) ? $args['asset_type']: ''; //资产类型
        $symbol_type = isset($args['symbol_type']) ? $args['symbol_type']: ''; //交易对类型
        $otc_asset = isset($args['otc_asset']) ? $args['otc_asset']: ''; //otc币种
        $otc_currency = isset($args['otc_currency']) ? $args['otc_currency']: ''; //otc法币
        $general= isset($args['general']) ?$args['general'] : array(); //通用配置模块
        $style= isset($args['style']) ?$args['style'] : 'default'; //模版配置
        $site_id= isset($args['id']) ?$args['id'] : ''; //模版配置
        $ios_url= isset($args['ios_url']) ?$args['ios_url'] : ''; //模版配置
        $android_url= isset($args['android_url']) ?$args['android_url'] : ''; //模版配置
        $qq= isset($args['qq']) ?$args['qq'] : ''; //模版配置
        $udesk_js = isset($args['udesk_js']) ?$args['udesk_js'] : '';
        $udesk_key = isset($args['udesk_key']) ?$args['udesk_key'] : '';

        $identity_method = isset($args['identity_method']) ?$args['identity_method'] : '';

        $recommend_code_force = isset($args['recommend_code_force']) ?$args['recommend_code_force'] : 0;
        $default_register_method = isset($args['default_register_method']) ?$args['default_register_method'] : 1;

        $seo_title = isset($args['seo_title']) ?$args['seo_title'] : '';
        $seo_keywords = isset($args['seo_keywords']) ?$args['seo_keywords'] : '';
        $seo_content = isset($args['seo_content']) ?$args['seo_content'] : '';

        $settlement_percent = isset($args['settlement_percent']) ?$args['settlement_percent'] : 0;
        $ts_status = isset($args['ts_status']) ?$args['ts_status'] : 0;
        $ws_status = isset($args['ws_status']) ?$args['ws_status'] : 0;


        // $style = $args['style'];  //模板

        //模块功能
        $product = isset($args['product']) ?$args['product'] : array(); //产品模块
        $money = isset($args['money']) ?$args['money'] : array(); //资金
        $account = isset($args['account']) ?$args['account'] : array(); //用户信息
        $site_roles = array_merge($product,$money,$account,$general);        //查看username是否重名
        $res = $this->Site_admin_model->get_admin_by_username($domain_user);

        $this->db->trans_begin();


        if($res && $res['site_id'] !=$site_id) return false;
        $this->load->model('Site_roles_model');
        $site_info = $this->Site_roles_model->get_all();
        $roles = array();
        foreach ($site_info as $val){
            if(in_array($val['priv_name'],$site_roles)){
                $roles[] =   $val['id'];
            }
        }
        $roles = implode(',',$roles);
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());
        $this->Site_model->update($site_id,$site_name,$title,$logo,$icon,$style,$language,$roles,$remark,$asset_type,$symbol_type,$service_email,$service_js,$tongji_js,$ios_url,$android_url,$qq,$udesk_js,$udesk_key,$identity_method,$recommend_code_force,$default_register_method,$seo_title,$seo_keywords,$seo_content,$otc_asset,$otc_currency,$settlement_percent,$ts_status,$ws_status);
        $this->Site_domain_model ->delete_all_by_site($site_id);
        
        if($this->config->item('SITE') === 'priv_one'){
            $this->Site_domain_model->add($domain,$site_name,$site_id);
        }else{
            $domainarr = explode(';', $domain);
            for($i = 0;$i<count($domainarr);$i++)
            {
                $this->Site_domain_model->add($domainarr[$i],$site_name,$site_id); //写入site_domain表
            }
        }
        
        

        if($this->config->item('SITE') === 'priv_one'){
            
        }else{
            $aa = $this->Zjys_assets_model->list_all($site_id); //当前站点的资产列表
            $site_asset_list = [];
            foreach ($aa as $key => $value) {
                $site_asset_list[] = $value['asset_code'];
            }
            $bb = $this->Zjys_symbols_model->list_all_siteid($site_id); //当前站点的资产列表
            $site_symbol_list = [];
            foreach ($bb as $key => $value) {
                $site_symbol_list[] = $value['symbol'];
            }
            
            $asset_type = explode(',',$asset_type); //表单提交的资产列表
            $symbol_type = explode(',',$symbol_type); //表单提交的交易对列表
            
            for($i=0;$i<count($asset_type);$i++)
            {
                if(!in_array($asset_type[$i], $site_asset_list)){
                    //加
                    $v = $this->Zjys_assets_model->get_sys_asset_detail($asset_type[$i]);
                    if(is_array($v) && !empty($v)){
                        if($v['sub_true'] == 1){
                            $this->Zjys_assets_model->add_asset_true($v['asset_code'],$v['asset_name'],$v['recharge_status'],$v['withdraw_status'],$v['trade_status'],$v['withdraw_fee'],$v['precision'],$site_id,$created_at,$updated_at,$v['withdraw_min'],$v['withdraw_max'],$v['sub_true'],$v['has_memo'],$v['regex'],$v['warning_status'],$v['withdraw_fee_percent']);
                        }else{
                            $this->Zjys_assets_model->add_asset_true($v['asset_code'],$v['asset_name'],0,0,0,$v['withdraw_fee'],$v['precision'],$site_id,$created_at,$updated_at,$v['withdraw_min'],$v['withdraw_max'],$v['sub_true'],$v['has_memo'],$v['regex'],$v['warning_status'],$v['withdraw_fee_percent']);
                        }
                    }
                }
            }

            for($i=0;$i<count($site_asset_list);$i++)
            {
                if(!in_array($site_asset_list[$i], $asset_type)){
                    //去
                    $this->Zjys_assets_model->asset_delete($site_id,$site_asset_list[$i]);
                }
            }

            for($i=0;$i<count($symbol_type);$i++)
            {
                if(!in_array($symbol_type[$i], $site_symbol_list)){
                    //加
                    $v = $this->Zjys_symbols_model->get_sys_symbol_detail($symbol_type[$i]);
                    // var_dump($v);
                    if($v['sub_true'] == 1)
                    {
                        $this->Zjys_symbols_model->add_symbol_true($v['base_asset'],$v['quote_asset'],$v['symbol'],$v['tick_size'],$v['min_quantity'],$v['status'],$v['recommend'],$v['limit_taker_fee'],$v['limit_maker_fee'],$v['market_taker_fee'],$site_id,$created_at,$updated_at,$v['base_asset_precision'],$v['quote_asset_precision'],$v['sub_true'],$v['base_asset_name'],$v['quote_asset_name'],$v['alert_percent']);
                    }else{
                        $this->Zjys_symbols_model->add_symbol_true($v['base_asset'],$v['quote_asset'],$v['symbol'],$v['tick_size'],$v['min_quantity'],0,$v['recommend'],$v['limit_taker_fee'],$v['limit_maker_fee'],$v['market_taker_fee'],$site_id,$created_at,$updated_at,$v['base_asset_precision'],$v['quote_asset_precision'],$v['sub_true'],$v['base_asset_name'],$v['quote_asset_name'],$v['alert_percent']);
                    }
                }
            }

            for($i=0;$i<count($site_symbol_list);$i++)
            {
                if(!in_array($site_symbol_list[$i], $symbol_type)){
                    //去
                    $this->Zjys_symbols_model->symbol_delete($site_id,$site_symbol_list[$i]);
                }
            }

        }
        
        $this->Site_admin_model->update($site_id,$domain_user,$domain_user,'',$email,$mobile);//写入b_site_admin表        
        
        // var_dump($this->db->last_query());
        // var_dump($this->db->trans_status());die;

        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }


    //更新站点权限
    public function update_site_roles($arr){
        foreach ($arr as $val){
            $this->Site_roles_model->update_site_roles($val,1);
        }
    }
    //获取站点基础信息
    public function get_site_role(){
        $this->load->model('Site_roles_model');
        $site_roles = $this->Site_roles_model->get_all();
        $privilages = array();
        foreach ($site_roles as $key=>$val){
            $privilages[] =$val['id'];
        }
        $privilages = implode(',',$privilages);
        $privilages = $this->conversion_privilages($privilages,true);
        return $privilages;

    }


    //domain新增
    public function domain_add($domain_url,$site_name,$site_id){
        return $this->Site_domain_model->add($domain_url,$site_name,$site_id);
    }
    //domain编辑
    public function domain_update($id,$domain_url,$site_name){
        return $this->Site_domain_model->update($id,$domain_url,$site_name);
    }
    //domain删除
    public function domain_delete($id){
        return $this->Site_domain_model->delete($id);
    }

    //关闭站点
    public function site_close($id,$type){
        return $this->Site_model->site_close($id,$type);
    }

    //删除
    public function site_delete(){
        $id = $this->input->post('id');

        //若失败手动回滚 成功手动提交
        $this->db->trans_begin();
        $this->Site_model->site_delete($id);
        $this->Site_admin_model->site_admin_delete($id);
        $this->Site_domain_model->delete_all_by_site($id);
        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            returnJson('402','error');
        } else {
            $this->db->trans_commit();
            returnJson('200','success');
        }
    }
    /**
     * @return 
     */
    public function ajaxsearch()
    {
        $name = $this->input->post('name');
        $object = $this->db->select("b_site.name,b_site.id")
        ->from('b_site');
        if(!empty($name)){
            $object =$this->db->where('b_site.name like','%'.$name.'%');
        }
        $list = $object->get()->result_array();
        return $list;
    }
}
