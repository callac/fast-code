<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Lock_position_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Lock_position_model');
        $this->load->model('Zjys_user_withdraw_model');
    }   

    //锁仓审核
    public function lockposition_check_first($id,$check_status,$remark){
        //获取锁仓记录详情
        $detail = $this->Lock_position_model->record_info($id);
        // print_r($detail);
        if($detail['check_status'] != 0) returnJson('402','记录状态异常');
        if($detail['status'] == 1) returnJson('402','记录状态异常');
        if($check_status == 0) returnJson('402','审核状态非法');
        $this->db->trans_begin();

        if($check_status==1){
            //审核成功
            admin_operation_logs($this->user_id,$detail['user_id'],34,$remark,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['id']);
            $data['check_status'] = $check_status;
            $this->db->where('id', $detail['id']);
            $this->db->update('user_lock_positions', $data);
        }else{
            //$status = 3;
            //审核失败
            admin_operation_logs($this->user_id,$detail['user_id'],35,$remark,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['id']);
            $data['check_status'] = $check_status;
            $data['status'] = 1;
            $this->db->where('id', $detail['id']);
            $this->db->update('user_lock_positions', $data);
            //解除user_asset_freezes中的冻结
            $created_at = date("Y-m-d H:i:s",time());
            $updated_at = date("Y-m-d H:i:s",time());
            $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($detail['asset'],$detail['user_id']);
            $balance = $last_balance['balance']-$detail['amount'];
            if($balance<0) $trans_status = false;
            $detail1 = json_encode(array('id'=>$detail['id']));
            $business = $this->config->item('ADMIN_UNFREEZE');//freeze表中的business
            $result = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$detail['user_id'],$detail['asset'],-$detail['amount'],$business,$balance,$detail1);
            // print_r($result);die;
            //解冻资金
            $text = '锁仓审核失败加可用';
            $ss = array('info'=>$text);
            $res = update_user_balance_bycurl($detail['user_id'],$detail['asset'],$detail['amount'],$detail['id'],$ss,$business);
            // $res = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$args['asset'],'unlock_position',$value['id'],$value['amount'],1,$remark,$remark)
        }

        $trans_status = $this->db->trans_status(); 
        if($trans_status == false)
        {
            $trans_status = false;
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            returnJson('402','Transaction failed');
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    //解仓审核
    public function lockposition_check_second($id,$check_status,$remark){
        //获取锁仓记录详情
        $detail = $this->Lock_position_model->record_info($id);
        // var_dump(TONGJI_TYPE_REGISTER);die;
        // print_r($detail);die;
        // var_dump($detail['check_status'] == 0);
        // var_dump($detail['check_status'] == 2);
        // var_dump($detail['status'] == 1);
        // var_dump(false || false || false);
        // die;
        if($detail['check_status'] == 0 || $detail['check_status']==2 || $detail['status']==1) returnJson('402','记录状态异常');
        if($check_status == 0 || $check_status==1) returnJson('402','审核状态非法');

        $this->db->trans_begin();
        //
        if($check_status==4){
            //解仓审核失败
            admin_operation_logs($this->user_id,$detail['user_id'],37,$remark,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['id']);
            $data['check_status'] = $check_status;
            $this->db->where('id', $detail['id']);
            $this->db->update('user_lock_positions', $data);
        }else{
            //$check_status = 2;
            //审核成功
            admin_operation_logs($this->user_id,$detail['user_id'],36,$remark,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$detail['id']);
            $data['check_status'] = $check_status;
            $data['status'] = 1;
            $this->db->where('id', $detail['id']);
            $this->db->update('user_lock_positions', $data);
            //解除user_asset_freezes中的冻结
            $created_at = date("Y-m-d H:i:s",time());
            $updated_at = date("Y-m-d H:i:s",time());
            $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($detail['asset'],$detail['user_id']);
            $balance = bcsub($last_balance['balance'],$detail['amount'],12);
            if($balance<0) returnJson('402','数据异常，操作失败！');
            $detail1 = json_encode(array('id'=>$detail['id']));
            $business = $this->config->item('ADMIN_UNFREEZE');//freeze表中的business
            $result = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$detail['user_id'],$detail['asset'],-$detail['amount'],$business,$balance,$detail1);
            // print_r($result);die;
            $text = '解仓审核成功加可用';
            $ss = array('info'=>$text);
            $res = update_user_balance_bycurl($detail['user_id'],$detail['asset'],$detail['amount'],$detail['id'],$ss,$business);
            // $res = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$args['asset'],'unlock_position',$value['id'],$value['amount'],1,$remark,$remark)
        }

        $trans_status = $this->db->trans_status(); 
        if($trans_status == false)
        {
            $trans_status = false;
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            returnJson('402','Transaction failed');
        } else {
            $this->db->trans_commit();
            return true;
        }
    }
}
