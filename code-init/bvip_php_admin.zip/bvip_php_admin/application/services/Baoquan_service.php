<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-04-09
 * Time: 16:00
 */

class Baoquan_service extends MY_Service
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Baoquan_model');
    }

    //请求时间段内的所有交易额
    public function add($hash,$baoQuanID,$status,$start_time,$end_time,$time,$size,$counts)
    {
        $this->Baoquan_model->add($hash,$baoQuanID,$status,$start_time,$end_time,$time,$size,$counts);
    }

    /**
     * Notes: 获取充提数据
     * User: 张哲
     * Date: 2019-04-09
     * Time: 16:51
     */
    public function recharge_list($start_time,$end_time){

        $start_time = date('Y-m-d H:i:s', $start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);

        $object = $this->db->select("asset,amount,updated_at")
            ->from('user_recharge_logs');

        $object =$this->db->where('user_recharge_logs.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_logs.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_logs.created_at <',$end_time);
        }
        $list_recharge = $object->order_by('created_at','desc')->get()->result_array();

        foreach ($list_recharge as &$val){

            $val['status'] = 1;

        }

        $object = $this->db->select("asset,amount,updated_at")
            ->from('user_withdraws');

        $object =$this->db->where('user_withdraws.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_withdraws.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_withdraws.created_at <',$end_time);
        }
        $list_withdraws = $object->order_by('created_at','desc')->get()->result_array();

        foreach ($list_withdraws as &$val){

            $val['status'] = 2;

        }

        $list = array_merge($list_recharge,$list_withdraws);

       // $count = count($list);
        return $list;
    }

    /**
     * Notes: 获取交易数据
     * User: 张哲
     * Date: 2019-04-09
     * Time: 17:17
     */
    public function trade_list($start_time,$end_time){
        $DB1 = $this->load->database('trade_history', true);
        for ($i = 0; $i < 100; $i++) {
            $sql = "select market,price,amount,deal_money,finish_time from order_history_" . $i . "  where  finish_time > " . $start_time . " and finish_time < " . $end_time . " ";
            $object = object_to_array($DB1->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        return $new;
    }


    /**
     * Notes: 获取奖励数据
     * User: 张哲
     * Date: 2019-04-09
     * Time: 18:08
     */
    public function reward_list($start_time,$end_time){
        $start_time = date('Y-m-d H:i:s', $start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("asset,amount,created_at")
            ->from('user_awards');

        $object =$this->db->where('user_awards.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_awards.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_awards.created_at <',$end_time);
        }
        $list = $object->order_by('created_at','desc')->get()->result_array();

        return $list;
    }


//    public function baoQuanList($hash,$page,$limit){
//
//        $object = $this->db->select("status,baoquan_no,created_at,block_size,block_count,id")
//            ->from('baoquan_message');
//        $object =$this->db->where('baoquan_message.hash =',$hash);
//        $baoquan = $object->get()->result_array();
//        $url = 'https://ztstatictest.oss-cn-hangzhou.aliyuncs.com/csv/'.$hash;
//        //获取url内容
//        $retData = @file_get_contents($url);
//
//
//        $result['list'] = $retData;
//                $result['list'] =  array_reverse($result['list']);
//
//
//                $result['type'] = 1;
//                $result['hash'] = $hash;
//                $result['baoquan_no'] =  $baoquan[0]['baoquan_no'];
//                $result['baoquan_time'] = $baoquan[0]['created_at'];
//                $result['count'] = count($result['list']);
//
//
//
//                $result['block_hash'] = $hash;
//                $result['block_height'] =  $baoquan[0]['id'];
//                $result['block_count'] = $baoquan[0]['block_count'];
//                $result['block_size'] = $baoquan[0]['block_size'];
//                $result['block_time'] = $baoquan[0]['created_at'];
//
//
//                $start = ($page-1) * $limit;
//                // var_dump($start,$limit);die();
//                $result['list'] = array_slice($result['list'],$start,$limit);
//        var_dump($retData);die();
//                return $result;
//
//if(isset($http_response_header)){
//
//$data = json_decode($retData, true);
//
//
//if($data){
//            if(isset($data['data'])){
//                $result['error_code'] = 0;
//$result['error_msg'] = '';
//$result['data'] = $data['data'][0];
//}else{
//                $result['error_code'] = 3;
//$result['error_msg'] = 'api获取数据失败,请看日志文件';
//
//}
//
//}else{
//          $result['error_code'] = 2;
//$result['error_msg'] = 'api帐号信息等失败,请看日志文件';
//
//}
//}else{
//           $result['error_code'] = 1;
//$result['error_msg'] = 'api链接失效,请看日志文件';
//$result['data'] = '';
//
//}
//
//var_dump($result);die();
//return $result;
//    }




    /**
     * Notes: 保全数据
     * User: 张哲
     * Date: 2019-04-09
     * Time: 18:43
     * @return mixed
     */
    public function baoQuanList($hash,$page,$limit){

        $object = $this->db->select("status,baoquan_no,created_at,block_size,block_count,id")
            ->from('baoquan_message');
        $object =$this->db->where('baoquan_message.hash =',$hash);
        $baoquan = $object->get()->result_array();

        //if(empty($baoquan))  returnJson('403','无效hash');
//        $result = array();
//        $result['list'] = '';
//        $result['type'] = 1;
//        $result['hash'] = $hash;
//        $result['baoquan_no'] =  $baoquan[0]['baoquan_no'];
//        $result['baoquan_time'] = $baoquan[0]['created_at'];
//        $result['count'] = 0;
//
//        $result['block_hash'] = $hash;
//        $result['block_height'] =  $baoquan[0]['id'];
//        $result['block_count'] = $baoquan[0]['block_count'];
//        $result['block_size'] = $baoquan[0]['block_size'];
//        $result['block_time'] = $baoquan[0]['created_at'];
//
//
//        // var_dump($start,$limit);die();
//        $result['list'] = '';
//        return $result;
        if(!empty($baoquan)){
            $status1 = $baoquan[0]['status'];
            $url = 'https://sipc-p.oss-cn-hangzhou.aliyuncs.com/csv/'.$hash;

          //  $lines = @file_get_contents($url);

            $lines = array_map('str_getcsv', file($url));
            $result = array();
            $headers = null;
            if (count($lines) > 0) {
                $headers = $lines[0];
            }
            for($i=1; $i<count($lines); $i++) {
                $obj = $lines[$i];
                $result1[] = array_combine($headers, $obj);//转成数组
                $new = array_merge(array(),$result1);
            }


            if(empty($new)) {
                $result['list'] = '';
                $result['type'] = $status1;
                $result['hash'] = $hash;
                $result['baoquan_no'] =  $baoquan[0]['baoquan_no'];
                $result['baoquan_time'] = $baoquan[0]['created_at'];
                $result['count'] = 0;

                $result['block_hash'] = $hash;
                $result['block_height'] =  $baoquan[0]['id'];
                $result['block_count'] = $baoquan[0]['block_count'];
                $result['block_size'] = $baoquan[0]['block_size'];
                $result['block_time'] = $baoquan[0]['created_at'];


                // var_dump($start,$limit);die();
                $result['list'] = '';
                return $result;
            }else{
                $result['list'] = $new;
                $result['list'] =  array_reverse( $result['list']);
                if($status1 == 2){
                    foreach ( $result['list'] as &$value){
                        if (!empty($value['status'])){
                            if($value['status'] == 1 ){
                                $value['status'] = '充值';
                            }else if($value['status'] == 2 ){
                                $value['status'] = '提现';
                            }
                        }

                        //$value ['time'] = get_microtime_format(  $value ['time']);
                    }
                }else if($status1 == 1){
                    foreach ( $result['list'] as &$value){
                        $value ['time'] = get_microtime_format(  $value ['time']);
                    }
                }

                $result['type'] = $status1;
                $result['hash'] = $hash;
                $result['baoquan_no'] =  $baoquan[0]['baoquan_no'];
                $result['baoquan_time'] = $baoquan[0]['created_at'];
                $result['count'] = count($result['list']);

                $result['block_hash'] = $hash;
                $result['block_height'] =  $baoquan[0]['id'];
                $result['block_count'] = $baoquan[0]['block_count'];
                $result['block_size'] = $baoquan[0]['block_size'];
                $result['block_time'] = $baoquan[0]['created_at'];


                $start = ($page-1) * $limit;
                // var_dump($start,$limit);die();
                $result['list'] = array_slice($result['list'],$start,$limit);
                return $result;
            }
        }
    }


    /**
     * Notes: 最新交易数据保全信息
     * User: 张哲
     * Date: 2019-04-10
     * Time: 14:09
     * @param $hash
     * @return array
     */
    public function TradeList($page,$limit){
        $object = $this->db->select("hash")
            ->from('baoquan_message');
        $object =$this->db->where('baoquan_message.status =',1);
        $baoquan1 = $object->limit(1,0)->order_by('created_at','desc')->get()->result_array();
        if(!empty($baoquan1)){
            $hash = $baoquan1[0]['hash'];
            $result = $this->baoQuanList($hash,$page,$limit);
            return $result;
        }
    }


    /**
     * Notes: 区块列表
     * User: 张哲
     * Date: 2019-04-16
     * Time: 15:39
     */
    public function BlockList($offset, $limit)
    {
        $object = $this->db->select("baoquan_message.*")
            ->from('baoquan_message');
        $object = $this->db->where('baoquan_message.deleted_at is null');
        $list = $object->limit($limit, $offset)->order_by('created_at', 'desc')->get()->result_array();
        return $list;
    }

    /**
     * Notes: 区块列表
     * User: 张哲
     * Date: 2019-04-16
     * Time: 15:39
     */
    public function BlockCount()
    {
        $object = $this->db->select("baoquan_message.*")
            ->from('baoquan_message');
        $object = $this->db->where('baoquan_message.deleted_at is null');
        return $this->db->count_all_results();
    }


    /**
     * Notes: 上一个块，下一个块
     * User: 张哲
     * Date: 2019-04-16
     * Time: 15:55
     */
    public function NextbaoQuanList($block_id,$page,$limit,$status){
        if($status == 1){
            $block_id = $block_id - 1;
        }else  if($status == 2){
            $block_id = $block_id + 1;
        }
        if($block_id == 0){
            returnJson('402','已经是初始区块了');
        }


        $object = $this->db->select("hash")
            ->from('baoquan_message');
        $object =$this->db->where('baoquan_message.id =',$block_id);
        $baoquan1 = $object->limit(1,0)->order_by('created_at','desc')->get()->result_array();
        if(empty($baoquan1)){
            returnJson('402','已经是最新区块了');
        }
        $hash = $baoquan1[0]['hash'];
        $result = $this->baoQuanList($hash,$page,$limit);
        return $result;
    }


}