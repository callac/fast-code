<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/1/9
 * Time: 20:15
 */



class Cancel_market_record_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Cancel_market_record_model');

    }

    /**
     * Notes: 撤销订单
     * User: 张哲
     * Date: 2019/1/10
     * Time: 09:30
     * @param $args
     * @return mixed
     */
    public function cancel_market($user,$amount,$market,$ctime,$mtime,$source,$price,$type,$deal_money,$side,$taker_fee,$maker_fee,$left,$deal_stock,$id,$status)
    {
        $operation_admin_id = $this->user_id;
        $data = $this->Cancel_market_record_model->cancel_market($user,$amount,$market,$ctime,$mtime,$source,$price,$type,$deal_money,$side,$taker_fee,$maker_fee,$left,$deal_stock,$id,$status,$operation_admin_id);
        return $data;
    }

    /**
     * Notes:  撤销记录表
     * User: 张哲
     * Date: 2019/1/10
     * Time: 09:33
     */
    public function cancel_order_record_list($start_time,$end_time,$offset,$limit,$symbol,$site_id,$user){
        $object = $this->db->select("cancel_market_record.*")
            ->from('cancel_market_record');
        $object =$this->db->where('cancel_market_record.deleted_at is null');
        if($symbol!='') $object =$this->db->where('cancel_market_record.market = ',$symbol);
        if($site_id!='') $object =$this->db->where('cancel_market_record.site_id = ',$site_id);
        if($user!='') $object =$this->db->where('cancel_market_record.uid = ',$user);
        if(!empty($start_time)){
            $object =$this->db->where('cancel_market_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('cancel_market_record.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
//            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
//            if(!empty($site_name['name'])){
//                $val['site_name'] = $site_name['name'];
//            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }

            if($val['type'] == 1){
                $val['type'] = lang('limit_price');
            }else if($val['type'] == 2){
                $val['type'] = lang('market_price');
            }

            if($val['status'] == 0){
                $val['status'] = lang('cancel_order_failed');
            }else if($val['status'] == 1){
                $val['status'] = lang('cancel_order_success');
            }

            if($val['side'] == 1){
                $val['side'] = lang('ask_sale');
            }else if($val['side'] == 2){
                $val['side'] = lang('bid_buy');
            }

        }
        return $list;
    }

    /**
     * Notes: 撤销记录表数量
     * User: 张哲
     * Date: 2019/1/10
     * Time: 09:33
     * @param $start_time
     * @param $end_time
     * @param $symbol
     * @param $site_id
     * @return mixed
     */
    public function cancel_order_record_count($start_time,$end_time,$symbol,$site_id,$user){
        $object = $this->db->select("cancel_market_record.*")
            ->from('cancel_market_record')
            ->where('cancel_market_record.status = ',1);
        $object =$this->db->where('cancel_market_record.deleted_at is null');
        if($symbol!='') $object =$this->db->where('cancel_market_record.market = ',$symbol);
        if($site_id!='') $object =$this->db->where('cancel_market_record.site_id = ',$site_id);
        if($user!='') $object =$this->db->where('cancel_market_record.uid = ',$user);
        if(!empty($start_time)){
            $object =$this->db->where('cancel_market_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('cancel_market_record.created_at <=',$end_time);
        }

        return $this->db->count_all_results();
    }
}