<?php use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-04-29
 * Time: 16:48
 */

class InOut_money_service extends MY_Service
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_symbols_model');
        $this->load->model('Symbols_price_model');
        $this->load->model('Zjys_user_model');
    }

    /**
     * Notes: 获取当前交易对币价
     * User: 张哲
     * Date: 2019-04-29
     * Time: 17:02
     */
    public function get_market_last($args)
    {
        // var_dump($args);die;
        if(empty($args))
        {
            $data = $this->Zjys_symbols_model->get_symbols_by_site_id1();
            foreach ($data as $value){
              $price = get_market_last($value['symbol']);
              $time = date('Y-m-d H:i:s',time());
              //如果获取当时没有交易数据，则获取数据库最新一条交易所数据
              if(empty($price)) $price = '0';
              $this->Symbols_price_model->add($time,$value['symbol'],$price);
            }
        }
        else
        {
            $start_time_timestamp = get_last_day($args); 
            $end_time_timestamp = $start_time_timestamp+86400;

            $start_time = date("Y-m-d", $start_time_timestamp);
            $end_time = date("Y-m-d", $end_time_timestamp);

            $data = $this->Zjys_symbols_model->get_symbols_by_site_id1();
            $trade_history_snap_db = $this->load->database('trade_history_snap',true);
            // var_dump($trade_history_snap_db);die;

            foreach ($data as $value){
                $sql = "show tables like 'order_history_$end_time_timestamp'";
                if(! $trade_history_snap_db->query($sql)->result_array()) returnJson('402','table order_history_'.$end_time_timestamp.' not exit');
                $sql = "select price from order_history_$end_time_timestamp where market= '".$value['symbol']."' order by id desc limit 1";
                $price = $trade_history_snap_db->query($sql)->row_array();
                if($price==NULL){
                    $price = '0';
                }else{
                    $price = $price['price'];
                }
                // $price = get_market_last($value['symbol']);
                $time = date('Y-m-d H:i:s',$start_time_timestamp);
                //循环插入
                $this->Symbols_price_model->add($time,$value['symbol'],$price);
            }
        }
        
    }


    /**
     * Notes: 获取当前币种币价
     * User: 张哲
     * Date: 2019-04-30
     * Time: 11:46
     * @param $user_id
     */
    public function asset_price($asset,$time_area=NULL){
        //获取当前币价
        //看下有没有交易对 拼接没有的话，
        $ci =& get_instance();
        if($asset == $ci->config->item('C2C_ASSET')){
            $price = '1';
        }else{
            $symbol = $asset.'_'.$ci->config->item('C2C_ASSET');
            if($time_area===NULL)
                $time = date('Y-m-d');
            else
                $time = $time_area;
            $price =  $this->Symbols_price_model->check_symbol($symbol,$time); //获取指定日期开盘价 table symbols_price
            // var_dump($price);
            if (empty($price)){
                //如果没有直接对应法币交易对，递归遍历现有交易对
                //现获取，自有交易对
                $symbol_asset =  $this->Symbols_price_model->check_symbol1($asset,$time);
                if(empty($symbol_asset)){
                    $price = 0;
                }else{
                    $symbol_last =  substr($symbol_asset[0]['symbols'],strripos($symbol_asset[0]['symbols'],"_")+1); //后
                    $symbol1 = $symbol_last.'_'.$ci->config->item('C2C_ASSET');
                    $price2 =  $this->Symbols_price_model->check_symbol($symbol1,$time);
                    // var_dump($price2);
                    if(empty($price2)) $price2 = '0';
                    // $price = floatval($price2) * floatval($symbol_asset[0]['price']);
                    if($price2==='0'){
                        $price = bcmul($price2, ($symbol_asset[0]['price']),12);
                    }else{
                        $price = bcmul($price2[0]['price'], ($symbol_asset[0]['price']),12);
                    }
                }
            }
        }
        // var_dump($price);
        if(empty($price)){
            return '0';
        }else{
            if($asset == $ci->config->item('C2C_ASSET')){
                return '1';
            }else{
                if(is_array($price)){
                    // var_dump($price[0]['price']);
                    return (string)$price[0]['price'];
                }else{
                    // var_dump($price);
                    return (string)$price;
                }
            }
        }
    }


    /**
     * Notes: 根据
     * User: 张哲
     * Date: 2019-05-05
     * Time: 17:08
     */
    public function asset_symbol($symbol){

        //获取当前币价
        $ci =& get_instance();
        //$symbol = trim(strrchr($symbol, '_'));

        $symbol_last =  substr($symbol,strripos($symbol,"_")+1); //后
        $symbol_fir =  substr($symbol,0,strripos($symbol,"_")); //前
        $time = date('Y-m-d');
        if ($symbol_last == $ci->config->item('C2C_ASSET')) {
            $price_trans = $this->Symbols_price_model->check_symbol($symbol,$time);
        } else {
            $price_trans = $this->Symbols_price_model->check_symbol($symbol_fir . '_' . $ci->config->item('C2C_ASSET'),$time);
        }
        return $price_trans;
    }

    /**
     * Notes: 获取用户可用资产，冻结
     * User: 张哲
     * Date: 2019-05-05
     * Time: 18:09
     */
    public function get_info_per_asset($id,$site_id){
        return get_per_user_assets_by_curl($id,$site_id);
    }




    /**
     * 1.当前申请提币：所有提币申请(未完成)-user_withdraws(status：0，1)
     * 2.C2C卖出：当前所有C2C卖出申请(未完成)-c2c_orders(type:2)
     * 3.当前资产总额（可用+冻结）按目前用户资产明细来-乘0点币价后相加
     * 4.入金：C2C买入-c2c_orders-历史累计已完成相加（type:1）、充值-user_recharge_logs-根据币种累加后乘0点币价，再次累加、活动(赠币、转账、活动系统)-acitivity_changes-累计活动按币种增加折算成CNT再次相加、后台资金调整-operation_money_logs-累计活动按币种增加折算成CNT再次相加、转入（OTC）-otc_transfer_histories
     * 5.出金：C2C卖出-c2c_orders、提币-user_withdraws、活动(赠币、转账、活动系统)-acitivity_changes、后台资金调整-operation_money_logs、转出（OTC）-otc_transfer_histories
     * 7.明细:业务类型（充值-user_recharge_logs、C2C买入-c2c_orders、活动-acitivity_changes、系统调整-operation_money_logs、转入-otc_transfer_histories、提币-user_withdraws、C2C卖出-c2c_orders、转出-otc_transfer_histories）
     *
     *
     * 1.获取0点各个交易对成交币价-调取market.last接口
     */
    /**
     * Notes: 获取用户进出资产记录
     * User: 张哲
     * Date: 2019-04-29
     * Time: 18:02
     */
    public function InOutMoneyQuery($offset,$limit,$user_id,$asset,$type)
    {

        //先看转出用户是否存在
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out))  returnJson('300','用户不存在');
        $ci =& get_instance();
        $data = array();
        /**
         * 获取所有申请提币记录
         */
        $object = $this->db->select("*")
            ->from('user_withdraws');
        $object = $this->db->where('user_withdraws.user_id =', $user_id);
        $object = $this->db->where('user_withdraws.status =', 0);
        $withdraws_list = $object->get()->result_array();
        $withdraws_arr =array();
        $i = 0;
        foreach ($withdraws_list as $key => $value){
            $price = $this->asset_price($value['asset']);
            //$withdraws_arr[$i]['asset'] = $value['asset'];
            $withdraws_arr[$i]['amount'] = $value['amount'].$value['asset'].'≈'.round($value['amount'] * $price,2).'CNY';
           // $withdraws_arr[$i]['price'] = round($value['amount'] * $price,2);
            $i++;
        }
        $data['withdraws'] = $withdraws_arr;

        /**
         * C2C卖出
         */
        $c2c_list = $this-> Symbols_price_model->c2c_sell($user_id);
//        $object = $this->db->select("*")
//            ->from('c2c_orders');
//        $object = $this->db->where('c2c_orders.user_id =', $user_id);
//        $object = $this->db->where('c2c_orders.status =', 2);
//        $object = $this->db->where('c2c_orders.type =', 1);
//        $c2c_list = $object->get()->result_array();
        $c2c_arr =array();
        $j = 0;
        foreach ($c2c_list as  &$value){
            $c2c_arr[$j]['amount'] = $value['amount'].$ci->config->item('C2C_ASSET').'≈'.round($value['amount'] * 0.99,2);
            $j++;
        }

        $data['c2c'] = $c2c_arr;
        /**
         * 冻结数据
//         */
        //查该用户站点id
        $site_id = $this->Zjys_user_model->check_site_id($user_id);

        $assets = $this->get_info_per_asset($user_id,$site_id['site_id']);
        $arr = array();
        $i = 0;


        foreach ($assets as $key => $value) { //组合拼接数组
            $price = $this->asset_price($key);
            $arr[$i]['available'] = $value['available'] * $price;
            $arr[$i]['freeze'] = ($value['freeze'] + $value['other_freeze']) * $price ;
            $arr[$i]['activity_freeze'] = ($value['activity_freeze']['activity_freeze']) * $price;
            $arr[$i]['asset'] = $key;
            $i++;
        }
        $other_data = array();
        $available = 0;
        $freeze = 0;
        foreach ($arr as &$value){
            $available += $value['available'];
            $freeze += $value['freeze'] + $value['activity_freeze'];
        }

        $data['available'] = round($available,2); //总计可用
        $data['freeze'] = round($freeze,2); //总计冻结
        $data['total'] = round($data['available'] + $data['freeze'],2); //总计金额

        /**
         * 累计流入
         */
        //c2c充值
        $c2c_data_in = $this-> Symbols_price_model->c2c($user_id,1);
        $c2c_in = $c2c_data_in[0]['amount'];
//        foreach ($c2c_data_in as &$value){
//            $c2c_in += $value['amount'];
//        }

        //充值
        $recharge_data = $this-> Symbols_price_model->recharge($user_id);
        //$recharge = $recharge_data['amount'] ;
        $recharge = 0;
        foreach ($recharge_data as &$value){
            $price = $this->asset_price($value['asset']);
            $recharge += $value['amount'] * $price ;
        }

        //$recharge = $recharge_data['amount'] * $price;
        //活动
        $activity_data = $this-> Symbols_price_model->activity_in($user_id);
        $activity = 0;
        foreach ($activity_data as &$value){
            $price = $this->asset_price($value['asset']);
            $activity += $value['amount'] * $price ;
        }
        //后台资金调整
        $admin_data_in = $this-> Symbols_price_model->admin_in($user_id);
        $admin_in = 0;
        foreach ($admin_data_in as &$value){
            $price = $this->asset_price($value['asset_code']);
            $admin_in += round($value['amount'] * $price,2) ;
        }
        //otc转入
        $otc_data_in = $this-> Symbols_price_model->otc($user_id,1);
        $otc_in = 0;
        foreach ($otc_data_in as &$value){
            $price = $this->asset_price($value['asset']);
            $otc_in += $value['amount'] * $price ;
        }

        $total_in = $c2c_in + $recharge + $activity + $admin_in + $otc_in;
        $data['total_in'] = round($total_in,2);
        /**
         * 累计流出
         */
        //c2c
        $c2c_data_out = $this-> Symbols_price_model->c2c($user_id,2);
        $c2c_out = $c2c_data_out[0]['amount'];

        //提现
        $withdraws_data = $this-> Symbols_price_model->withdraws($user_id);
//        $price = $this->asset_price($withdraws_data['asset']);
//        $withdraws = $withdraws_data['amount'] * $price;
        $withdraws = 0;
        foreach ($withdraws_data as &$value){
            $price = $this->asset_price($value['asset']);
            $withdraws += $value['amount'] * $price;
        }
        //活动
        $activity_data_out = $this-> Symbols_price_model->activity_out($user_id);
        $activity_out = 0;
        foreach ($activity_data_out as &$value){
            $price = $this->asset_price($value['asset']);
            $activity_out += $value['amount'] * $price ;
        }
        //后台资金调整
        $admin_data_out = $this-> Symbols_price_model->admin_out($user_id);
        $admin_out = 0;
        foreach ($admin_data_out as &$value){
            $price = $this->asset_price($value['asset_code']);
            $admin_out += $value['amount'] * $price ;
        }
        //otc转入
        $otc_data_out = $this-> Symbols_price_model->otc($user_id,2);
        $otc_out = 0;
        foreach ($otc_data_out as &$value){
            $price = $this->asset_price($value['asset']);
            $otc_out += $value['amount'] * $price ;
        }
        $activity_out = abs($activity_out);
        $admin_out = abs($admin_out);
        $total_out = $c2c_out + $withdraws + $activity_out + $admin_out + $otc_out;
        $data['total_out'] = round($total_out,2);

        $list = array();
        /**
         * 出入金明细  1.提现 2.充值 3.活动 4.资金调整 5.otc转入 6.otc转出 7.c2c转入 8.c2c转出
         */
        if(empty($asset)){
            if(!empty($type)){
                if($type == 1){
                    //提现
                    $withdraws = array();
                    $withdraws_list = $this-> Symbols_price_model->withdraws_list($user_id);
                    foreach ($withdraws_list as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $withdraws[$key]['amount'] = $value['amount'];
                        $withdraws[$key]['asset'] = $value['asset'];
                        $withdraws[$key]['to_cny_amount'] = round($value['amount']*$price,2);
                        $withdraws[$key]['type'] = '提币';
                    }
                    $list = $withdraws;
                }
                if($type == 2){
                    //充值
                    $recharge_arr = array();
                    $recharge_list = $this-> Symbols_price_model->recharge_list($user_id);
                    foreach ($recharge_list as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $recharge_arr[$key]['amount'] = $value['amount'];
                        $recharge_arr[$key]['asset'] = $value['asset'];
                        $recharge_arr[$key]['to_cny_amount'] = round($value['amount']*$price,2);
                        $recharge_arr[$key]['type'] = '充值';
                    }
                    $list = $recharge_arr;
                }


                if($type == 3) {
                    //活动
                    $activity_arr = array();
                    $activity_list = $this-> Symbols_price_model->activity_list($user_id);
                    foreach ($activity_list as $key=>$value){

                            $price = $this->asset_price($value['asset']);
                            $activity_arr[$key]['amount'] = $value['amount'];
                            $activity_arr[$key]['asset'] = $value['asset'];
                            $activity_arr[$key]['to_cny_amount'] = $value['amount'] * $price;
                            $activity_arr[$key]['type'] = '活动';
                    }
                    $list = $activity_arr;
                }

                if($type == 4) {
                    //后台资金调整
                    $admin_arr = array();
                    $admin_list = $this-> Symbols_price_model->admin_list($user_id);
                    foreach ($admin_list as $key=>$value){

                            $price = $this->asset_price($value['asset']);
                            $admin_arr[$key]['amount'] = $value['amount'];
                            $admin_arr[$key]['asset'] = $value['asset'];
                            $admin_arr[$key]['to_cny_amount'] = $value['amount'] * $price;
                            $admin_arr[$key]['type'] = '系统调整';

                    }
                    $list = $admin_arr;
                }

                if($type == 5) {
                    //otc转入
                    $otc_in = array();
                    $otc_list_in = $this-> Symbols_price_model->otc_list($user_id,1);
                    foreach ($otc_list_in as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $otc_in[$key]['amount'] = $value['amount'];
                        $otc_in[$key]['asset'] = $value['asset'];
                        $otc_in[$key]['to_cny_amount'] = $value['amount'] * $price;
                        $otc_in[$key]['type'] = '转入';
                    }
                    $list = $otc_in;
                }

                if($type == 6) {
                    //otc转出
                    $otc_out = array();
                    $otc_list_out = $this-> Symbols_price_model->otc_list($user_id,2);
                    foreach ($otc_list_out as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $otc_out[$key]['amount'] = $value['amount'];
                        $otc_out[$key]['asset'] = $value['asset'];
                        $otc_out[$key]['to_cny_amount'] = $value['amount'] * $price;
                        $otc_out[$key]['type'] = '转出';
                    }
                    $list = $otc_out;
                }

                if($type == 7) {
                    //c2c转出
                    $c2c_in = array();
                    $c2c_list_in = $this-> Symbols_price_model->c2c_list($user_id,1);
                    foreach ($c2c_list_in as $key=>$value){
                        if(empty($value['amount'])){
                            $c2c_in[$key]['amount'] = '0';
                            $c2c_in[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_in[$key]['to_cny_amount'] = '0' ;
                            $c2c_in[$key]['type'] = 'C2C买入';
                        }else{
                            $c2c_in[$key]['amount'] = $value['amount'];
                            $c2c_in[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_in[$key]['to_cny_amount'] = $value['amount'] ;
                            $c2c_in[$key]['type'] = 'C2C买入';
                        }
                    }
                    $list = $c2c_in;
                }

                if($type == 8) {
                    //c2c转出
                    $c2c_out = array();
                    $c2c_list_out = $this-> Symbols_price_model->c2c_list($user_id,2);

                    foreach ($c2c_list_out as $key=>$value){
                        if(empty($value['amount'])){
                            $c2c_out[$key]['amount'] = '0';
                            $c2c_out[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_out[$key]['to_cny_amount'] = '0' ;
                            $c2c_out[$key]['type'] = 'C2C卖出';
                        }else{
                            $c2c_out[$key]['amount'] = $value['amount'];
                            $c2c_out[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_out[$key]['to_cny_amount'] = $value['amount'] ;
                            $c2c_out[$key]['type'] = 'C2C卖出';
                        }
                    }
                    $list = $c2c_out;
                }

            }else{
                //提现
                $withdraws = array();
                $withdraws_list = $this-> Symbols_price_model->withdraws_list($user_id);

                foreach ($withdraws_list as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $withdraws[$key]['amount'] = $value['amount'];
                    $withdraws[$key]['asset'] = $value['asset'];
                    $withdraws[$key]['to_cny_amount'] = round($value['amount']*$price,2);
                    $withdraws[$key]['type'] = '提币';

                    //var_dump($value['amount'],$price,$withdraws[$key]['to_cny_amount']);die();
                }
                //充值
                $recharge_arr = array();
                $recharge_list = $this-> Symbols_price_model->recharge_list($user_id);
                foreach ($recharge_list as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $recharge_arr[$key]['amount'] = $value['amount'];
                    $recharge_arr[$key]['asset'] = $value['asset'];
                    $recharge_arr[$key]['to_cny_amount'] = round($value['amount']*$price,2);
                    $recharge_arr[$key]['type'] = '充值';
                }
                //活动
                $activity_arr = array();
                $activity_list = $this-> Symbols_price_model->activity_list($user_id);
                foreach ($activity_list as $key=>$value){
                    $price = $this->asset_price($value['asset']);

                    $activity_arr[$key]['amount'] = $value['amount'];
                    $activity_arr[$key]['asset'] = $value['asset'];
                    $activity_arr[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                    $activity_arr[$key]['type'] = '活动';
                }
                //后台资金调整
                $admin_arr = array();
                $admin_list = $this-> Symbols_price_model->admin_list($user_id);
                foreach ($admin_list as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $admin_arr[$key]['amount'] = $value['amount'];
                    $admin_arr[$key]['asset'] = $value['asset'];
                    $admin_arr[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                    $admin_arr[$key]['type'] = '系统调整';
                }
                //otc转入
                $otc_in = array();
                $otc_list_in = $this-> Symbols_price_model->otc_list($user_id,1);
                foreach ($otc_list_in as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $otc_in[$key]['amount'] = $value['amount'];
                    $otc_in[$key]['asset'] = $value['asset'];
                    $otc_in[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                    $otc_in[$key]['type'] = '转入';
                }
                //otc转出
                $otc_out = array();
                $otc_list_out = $this-> Symbols_price_model->otc_list($user_id,2);
                foreach ($otc_list_out as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $otc_out[$key]['amount'] = $value['amount'];
                    $otc_out[$key]['asset'] = $value['asset'];
                    $otc_out[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                    $otc_out[$key]['type'] = '转出';
                }
                //c2c转出
                $c2c_in = array();
                $c2c_list_in = $this-> Symbols_price_model->c2c_list($user_id,1);
                foreach ($c2c_list_in as $key=>$value){
                    if(empty($value['amount'])){
                        $c2c_in[$key]['amount'] = '0';
                        $c2c_in[$key]['asset'] = $ci->config->item('C2C_ASSET');
                        $c2c_in[$key]['to_cny_amount'] = '0' ;
                        $c2c_in[$key]['type'] = 'C2C买入';
                    }else{
                        $c2c_in[$key]['amount'] = $value['amount'];
                        $c2c_in[$key]['asset'] = $ci->config->item('C2C_ASSET');
                        $c2c_in[$key]['to_cny_amount'] = round($value['amount'],2) ;
                        $c2c_in[$key]['type'] = 'C2C买入';
                    }

                }
                //c2c转出
                $c2c_out = array();
                $c2c_list_out = $this-> Symbols_price_model->c2c_list($user_id,2);
                foreach ($c2c_list_out as $key=>$value){
                    if(empty($value['amount'])){
                        $c2c_out[$key]['amount'] = '0';
                        $c2c_out[$key]['asset'] = $ci->config->item('C2C_ASSET');
                        $c2c_out[$key]['to_cny_amount'] = '0' ;
                        $c2c_out[$key]['type'] = 'C2C卖出';
                    }else{
                        $c2c_out[$key]['amount'] = $value['amount'];
                        $c2c_out[$key]['asset'] = $ci->config->item('C2C_ASSET');
                        $c2c_out[$key]['to_cny_amount'] = round($value['amount'],2) ;
                        $c2c_out[$key]['type'] = 'C2C卖出';
                    }

                }
                $list = array_merge($withdraws,$recharge_arr,$activity_arr,$admin_arr,$otc_in,$otc_out,$c2c_in,$c2c_out);
            }

        }else{


            if(!empty($type)){
                if($type == 1){
                    //提现
                    $withdraws = array();
                    $withdraws_list = $this-> Symbols_price_model->withdraws_asset_list($user_id,$asset);
                    foreach ($withdraws_list as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $withdraws[$key]['amount'] = $value['amount'];
                        $withdraws[$key]['asset'] = $value['asset'];
                        $withdraws[$key]['to_cny_amount'] = round($value['amount']*$price,2);
                        $withdraws[$key]['type'] = '提币';
                    }
                    $list = $withdraws;
                }

                if($type == 2){
                    //充值
                    $recharge_arr = array();
                    $recharge_list = $this-> Symbols_price_model->recharge_asset_list($user_id,$asset);
                    foreach ($recharge_list as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $recharge_arr[$key]['amount'] = $value['amount'];
                        $recharge_arr[$key]['asset'] = $value['asset'];
                        $recharge_arr[$key]['to_cny_amount'] = round($value['amount']*$price,2);
                        $recharge_arr[$key]['type'] = '充值';
                    }
                    $list = $recharge_arr;
                }

                if($type == 3){
                    //活动
                    $activity_arr = array();
                    $activity_list = $this-> Symbols_price_model->activity_asset_list($user_id,$asset);
                    foreach ($activity_list as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $activity_arr[$key]['amount'] = $value['amount'];
                        $activity_arr[$key]['asset'] = $value['asset'];
                        $activity_arr[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                        $activity_arr[$key]['type'] = '活动';
                    }
                    $list = $activity_arr;
                }

                if($type == 4){
                    //后台资金调整
                    $admin_arr = array();
                    $admin_list = $this-> Symbols_price_model->admin_asset_list($user_id,$asset);
                    foreach ($admin_list as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $admin_arr[$key]['amount'] = $value['amount'];
                        $admin_arr[$key]['asset'] = $value['asset'];
                        $admin_arr[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                        $admin_arr[$key]['type'] = '系统调整';
                    }
                    $list = $admin_arr;
                }

                if($type == 5){
                    //otc转入
                    $otc_in = array();
                    $otc_list_in = $this-> Symbols_price_model->otc_asset_list($user_id,1,$asset);
                    foreach ($otc_list_in as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $otc_in[$key]['amount'] = $value['amount'];
                        $otc_in[$key]['asset'] = $value['asset'];
                        $otc_in[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                        $otc_in[$key]['type'] = '转入';
                    }
                    $list = $otc_in;
                }

                if($type == 6){
                    //otc转出
                    $otc_out = array();
                    $otc_list_out = $this-> Symbols_price_model->otc_asset_list($user_id,2,$asset);
                    foreach ($otc_list_out as $key=>$value){
                        $price = $this->asset_price($value['asset']);
                        $otc_out[$key]['amount'] = $value['amount'];
                        $otc_out[$key]['asset'] = $value['asset'];
                        $otc_out[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                        $otc_out[$key]['type'] = '转出';
                    }
                    $list = $otc_out;
                }

                if($type == 7){
                    $c2c_in = array();
                    $c2c_list_in = $this-> Symbols_price_model->c2c_asset_list($user_id,1,$asset);
                    foreach ($c2c_list_in as $key=>$value){
                        if(empty($value['amount'])){
                            $c2c_in[$key]['amount'] = 0 ;
                            $c2c_in[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_in[$key]['to_cny_amount'] = 0 ;
                            $c2c_in[$key]['type'] = 'C2C买入';
                        }else{
                            $c2c_in[$key]['amount'] = $value['amount'];
                            $c2c_in[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_in[$key]['to_cny_amount'] = round($value['amount'],2) ;
                            $c2c_in[$key]['type'] = 'C2C买入';
                        }

                    }
                    $list = $c2c_in;
                }

                if($type == 8){
                    //c2c转出
                    $c2c_out = array();
                    $c2c_list_out = $this-> Symbols_price_model->c2c_asset_list($user_id,2,$asset);
                    foreach ($c2c_list_out as $key=>$value){
                        if(empty($value['amount'])){
                            $c2c_out[$key]['amount'] = 0;
                            $c2c_out[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_out[$key]['to_cny_amount'] = 0 ;
                            $c2c_out[$key]['type'] = 'C2C卖出';
                        }else{
                            $c2c_out[$key]['amount'] = $value['amount'];
                            $c2c_out[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_out[$key]['to_cny_amount'] = round($value['amount'],2) ;
                            $c2c_out[$key]['type'] = 'C2C卖出';
                        }

                    }
                    $list = $c2c_out;
                }


            }else{
                //提现
                $withdraws = array();
                $withdraws_list = $this-> Symbols_price_model->withdraws_asset_list($user_id,$asset);
                foreach ($withdraws_list as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $withdraws[$key]['amount'] = $value['amount'];
                    $withdraws[$key]['asset'] = $value['asset'];
                    $withdraws[$key]['to_cny_amount'] = round($value['amount']*$price,2);
                    $withdraws[$key]['type'] = '提币';
                }
                //充值
                $recharge_arr = array();
                $recharge_list = $this-> Symbols_price_model->recharge_asset_list($user_id,$asset);
                foreach ($recharge_list as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $recharge_arr[$key]['amount'] = $value['amount'];
                    $recharge_arr[$key]['asset'] = $value['asset'];
                    $recharge_arr[$key]['to_cny_amount'] = round($value['amount']*$price,2);
                    $recharge_arr[$key]['type'] = '充值';
                }
                //活动
                $activity_arr = array();
                $activity_list = $this-> Symbols_price_model->activity_asset_list($user_id,$asset);
                foreach ($activity_list as $key=>$value){

                    $price = $this->asset_price($value['asset']);
                    //var_dump($value['asset'],$price);die();
                    $activity_arr[$key]['amount'] = $value['amount'];
                    $activity_arr[$key]['asset'] = $value['asset'];
                    $activity_arr[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                    $activity_arr[$key]['type'] = '活动';
                }
                //后台资金调整
                $admin_arr = array();
                $admin_list = $this-> Symbols_price_model->admin_asset_list($user_id,$asset);
                foreach ($admin_list as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $admin_arr[$key]['amount'] = $value['amount'];
                    $admin_arr[$key]['asset'] = $value['asset'];
                    $admin_arr[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                    $admin_arr[$key]['type'] = '系统调整';
                }
                //otc转入
                $otc_in = array();
                $otc_list_in = $this-> Symbols_price_model->otc_asset_list($user_id,1,$asset);
                foreach ($otc_list_in as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $otc_in[$key]['amount'] = $value['amount'];
                    $otc_in[$key]['asset'] = $value['asset'];
                    $otc_in[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                    $otc_in[$key]['type'] = '转入';
                }
                //otc转出
                $otc_out = array();
                $otc_list_out = $this-> Symbols_price_model->otc_asset_list($user_id,2,$asset);
                foreach ($otc_list_out as $key=>$value){
                    $price = $this->asset_price($value['asset']);
                    $otc_out[$key]['amount'] = $value['amount'];
                    $otc_out[$key]['asset'] = $value['asset'];
                    $otc_out[$key]['to_cny_amount'] = round($value['amount'] * $price,2);
                    $otc_out[$key]['type'] = '转出';
                }
                //c2c转出
                if($ci->config->item('C2C_ASSET') == $asset){
                    $c2c_in = array();
                    $c2c_list_in = $this-> Symbols_price_model->c2c_asset_list($user_id,1,$asset);
                    foreach ($c2c_list_in as $key=>$value){
                        if(empty($value['amount'])){
                            $c2c_in[$key]['amount'] = 0 ;
                            $c2c_in[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_in[$key]['to_cny_amount'] = 0 ;
                            $c2c_in[$key]['type'] = 'C2C买入';
                        }else{
                            $c2c_in[$key]['amount'] = $value['amount'];
                            $c2c_in[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_in[$key]['to_cny_amount'] = round($value['amount'],2) ;
                            $c2c_in[$key]['type'] = 'C2C买入';
                        }
                    }
                    //c2c转出
                    $c2c_out = array();
                    $c2c_list_out = $this-> Symbols_price_model->c2c_asset_list($user_id,2,$asset);
                    foreach ($c2c_list_out as $key=>$value){
                        if(empty($value['amount'])){
                            $c2c_out[$key]['amount'] = 0;
                            $c2c_out[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_out[$key]['to_cny_amount'] = 0 ;
                            $c2c_out[$key]['type'] = 'C2C卖出';
                        }else{
                            $c2c_out[$key]['amount'] = $value['amount'];
                            $c2c_out[$key]['asset'] = $ci->config->item('C2C_ASSET');
                            $c2c_out[$key]['to_cny_amount'] = round($value['amount'],2) ;
                            $c2c_out[$key]['type'] = 'C2C卖出';
                        }
                    }
                    $list = array_merge($withdraws,$recharge_arr,$activity_arr,$admin_arr,$otc_in,$otc_out,$c2c_in,$c2c_out);
                }else{
                    $list = array_merge($withdraws,$recharge_arr,$activity_arr,$admin_arr,$otc_in,$otc_out);
                }
            }
        }
        $data['list'] = $list;
        $data['list'] = array_slice($data['list'],$offset,$limit);
        $data['count'] = count($list);

        return $data;

       // var_dump($withdraws_list,$recharge_list,$activity_list,$admin_list,$otc_list_in,$c2c_list_in,$c2c_list_out,$otc_list_out);die();
//var_dump($list);die();
    }

    public function otc_transfer_list($start_time,$end_time,$offset,$limit,$asset,$type)
    {
        $object = $this->db->select("*")
        ->from('otc_transfer_histories');
        if(!empty($asset))
            $object = $this->db->where('otc_transfer_histories.asset =', $asset);
        if(!empty($type))
            $object = $this->db->where('otc_transfer_histories.type =', $type);

        if(!empty($start_time)){
            $object =$this->db->where('otc_transfer_histories.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('otc_transfer_histories.created_at <',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();        
        return $list;

    }

    public function otc_transfer_list_count($start_time,$end_time,$asset,$type)
    {
        $object = $this->db->select("*")
        ->from('otc_transfer_histories');
        if(!empty($asset))
            $object = $this->db->where('otc_transfer_histories.asset =', $asset);
        if(!empty($type))
            $object = $this->db->where('otc_transfer_histories.type =', $type);
        if(!empty($start_time)){
            $object =$this->db->where('otc_transfer_histories.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('otc_transfer_histories.created_at <',$end_time);
        }

        return $this->db->count_all_results();
    }



}