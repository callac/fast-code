<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

class Alarm_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_symbols_model');
        $this->load->model('Rm_parameter_model');
        $this->load->model('Rm_transaction_alarm_model');
        $this->load->model('Zjys_c2corder_model');
        $this->load->model('Zjys_recharge_logs_model');
        $this->load->model('Zjys_user_withdraw_model');  
        $this->load->model('Zjys_assets_model');
        $this->load->model('Site_model');
        $this->load->model('Rm_account_modle');
        $this->load->model('Zjys_user_model'); 
        $this->load->model('Rm_profit_loss_model');
        $this->load->model('User_white_list_model');
        $this->load->model('Zjys_assets_model');
        $this->load->model('Rm_withdraws_recharge_alarm_model');
        $this->load->model('Rm_address_alarm_model');
        $this->load->model('OTC_model');
        $this->load->model('Rm_new_par_model');
        $this->load->model('Symbols_price_model');
    }

    /**
     * Notes: 告警信息打入消息队列
     * User: 张哲
     * Date: 2019-04-22
     * Time: 13:47
     * @param $id
     * @param $message
     */
    public function rabbit_message($id,$message,$business){
        $created_at = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        //打入消息队列
        require_once './vendor/autoload.php';
        $connection = new AMQPStreamConnection($this->config->item('rabbitmq_host'), $this->config->item('rabbitmq_port'), $this->config->item('rabbitmq_user'), $this->config->item('rabbitmq_pwd'));
        $channel = $connection->channel();
        $channel->queue_declare('task_queue', false, true, false, false);

        $arr = array(
            'name'=>$business,
            'ip'=>$_SERVER['REMOTE_ADDR'],
            'endpoint'=>'admin',
            'params'=> array((int)$id),
            'time'=>$_SERVER['REQUEST_TIME'],
        );

        $detail = json_encode($arr);
        $msg = new AMQPMessage($detail,array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
        $cc = $channel->basic_publish($msg, '', 'task_queue');
        $channel->close();
        $connection->close();
        if($cc != NULL){
            $queue_status = 'failed';
        }else{
            $queue_status = 'success';
        }

        if($queue_status == 'failed'){
            returnJson('402','打入队列失败');
        }
        $this->OTC_model->add_event($created_at,$updated_at,$arr['name'],$arr['ip'],$arr['endpoint'],$message);
    }


    //请求时间段内的所有交易额
    public function get_trade_statistic($start_time,$end_time)
    {
        $DB1 = $this->load->database('trade_history',true);
        $res = array();
        //获取站点交易对
        $symbolList = $this->Zjys_symbols_model->get_symbols_by_site_id(1); //只有总站有的交易对
        foreach ($symbolList as $key => $value) {
            for ($i=0; $i < 100; $i++) { 
                $sql = "select deal_money,user_id,market,side,price,amount,deal_money,finish_time from order_history_".$i." where market='".$value['symbol']."' and finish_time >".$start_time." and finish_time <".$end_time." ";
                $object = object_to_array($DB1->query($sql)->result()); 
                if($i==0){
                    $new = array_merge(array(),$object);
                }else{
                    @$new = &array_merge($new,$object);
                }
            }
            $sum = 0;
            foreach($new as $ii => $item){ 
              $sum += $item['deal_money'];
            }
            $res[$key]['symbol'] =  $value['symbol'];
            $res[$key]['total'] =  $sum;//总交易量
            $res[$key]['number'] =  count($new);//总交易笔数
        }
        return $res;
    }

    /**
     * 异常交易警报
     * @Author   张哲
     * @DateTime 2018-10-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_transaction_alarm($start_time,$end_time)
    { 
        $DB1 = $this->load->database('trade_history',true);
        $res = array();  //存储有问题数据数组
        $last = array();  //存储过滤后额数组
        //获取站点交易对
        $symbolList = $this->Zjys_symbols_model->get_symbols_by_site_id1(); //只有总站有的交易对
        foreach ($symbolList as $key => $value) {
            for ($i=0; $i < 100; $i++) { 
                //$sql = "select user_id,market,side,price,amount,deal_money,finish_time from order_history_".$i." where market='".$value['symbol']."' and finish_time >".$start_time." and finish_time <".$end_time." ";
                //$sql = "select  sum(deal_money) as totalmoney,user_id,market from order_history_".$i." where market='".$value['symbol']."' and finish_time >".$start_time." and finish_time <".$end_time." and substring(source,5)='".$value['site_id']."' group by user_id";
                $sql = "select  sum(deal_money) as totalmoney,user_id,market from order_history_".$i." where market='".$value['symbol']."' and finish_time >".$start_time." and finish_time <".$end_time." group by user_id";

                $object = object_to_array($DB1->query($sql)->result()); 
                if($i==0){
                    $new = array_merge(array(),$object);
                }else{
                    @$new = &array_merge($new,$object);
                }                       
            }  
            $sum = 0;
            foreach($new as $key => $item){
                $sum += $item['totalmoney'];
            }
            foreach($new as $key => $item){           
            $rate = round($item['totalmoney']/$sum,2);
              $param = $this->Rm_parameter_model->param($value['symbol'],4);
              if(!empty($param['rate'])){
                if ($rate >= round($param['rate']/100,2)){
                   $res[$key]['user_id'] =  $item['user_id'];
                   $res[$key]['market'] =  $value['symbol'];
                   $res[$key]['total'] =  $sum;//总交易量
                   $res[$key]['user_sum'] = $item['totalmoney']; //单个用户交易总量
                   $res[$key]['rate'] = $rate*100; //交易占比
                   //查找站点                  
                   
                }
              } 
            }                         
        } 
        //白名单过滤
        foreach($res as $key => $value){
         $phone = $this->Zjys_user_model->check_phone($value['user_id']);
         if(!empty($phone['id'])){
            $account = $phone['id'];
         }
         $phone = $this->User_white_list_model->find_phone($account);
         if(empty($phone)){
            $last[$key]['user_id'] =  $value['user_id'];
            $last[$key]['market'] =  $value['market'];
            $last[$key]['total'] =  $value['total'];//总交易量
            $last[$key]['user_sum'] = $value['user_sum']; //单个用户交易总量
            $last[$key]['rate'] = $value['rate'];
            $site = $this->Zjys_user_model->check_site_id($last[$key]['user_id']);
            if(!empty($site['site_id'])){
                $last[$key]['site_id'] = $site['site_id'];
            }                  
         }
        }
        $time = date('Y-m-d H:i:s',time());
        foreach ($last as $key => $val) {
            $id = $this->Rm_transaction_alarm_model->add($start_time,$end_time,$val['market'],$val['total'],$val['user_sum'],$val['rate'],$val['user_id'],$time,$val['site_id']);

            $message = '['.$id.','.$start_time.','.$end_time.','.$val['user_id'].','.$val['market'].','.$val['rate'].','.$time.','.$val['site_id'].']';
            $business = 'transaction_alarm';
            $this->rabbit_message($id,$message,$business);
         }
    }


    /**
     * 期初总资产 slice_balance表数据
     * 期间流入 c2c、otc、充值
     * 期间流出 c2c、otc、提币
     */

    /**
     * 异常盈亏监控
     * @Author   张哲
     * @DateTime 2018-10-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * 取出每个用户的所有记录，并把资产转成同一种类型（比如CNZ）,需要知道每种交易对的兑换比例
     */
    public function get_profit_loss($args){

        $object = $this->db->select("users.id")->from('users');
        $list = $object->get()->result_array();

        $res = array();
        $last = array();  //存储过滤后额数组
        //foreach ($list as $key => $val){
//            $totalassets = $this->asset_price($val['id']);
//            $val['total_available'] = $totalassets['total_trans']; //净资产
//            $total=floatval($val['total_available']);//
//            $val['c2c'] = $totalassets['c2c'];  //法币充值
//            $val['recharge'] = $totalassets['recharge'];  //充值
//            $val['total_recharge'] = $totalassets['recharge'] + $totalassets['c2c'] + $totalassets['user_activity'];  //充值总值
//            $rec=floatval($val['total_recharge']);//  总充值
//            $val['withdraw'] = $totalassets['withdraws'];  //提币
//            $withdraw=floatval($val['withdraw']);//
//            $rechange = $total + $withdraw - $rec; //净资产+提币

            //$user_id = $val['id'];
            //获取期初快照数据
            $time_start = date('Y-m-d H:i:s', time()-86400);
            $sub_start = substr($time_start, 0, 14);
            $new_time_start = $sub_start . "00:00";
            $timestamp_start = strtotime($new_time_start);

            $DB1 = $this->load->database('trade_log', true);
            //先取用户及其币种数组
            $sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp_start . "  group by asset,user_id";
            $object = object_to_array($DB1->query($sql)->result());
            $new = array_merge(array(), $object);

            foreach ($new as $key => $value){
                $asset = $value['asset'];
                $start_asset = $value['balance'];
                $user_id =$value['user_id'];

                $time = date('Y-m-d H:i:s', time());
                $sub = substr($time, 0, 14);
                $new_time = $sub . "00:00";
                $timestamp = strtotime($new_time);
                //期末数据
                $DB1_end = $this->load->database('trade_log', true);
                //先取用户及其币种数组
                $sql_end = "select user_id,sum(balance) as balance from slice_balance_" . $timestamp . " where user_id = '$user_id' and asset = '$asset'";
                $object = object_to_array($DB1_end->query($sql_end)->result());
                $new_end = array_merge(array(), $object);
                if(empty($new_end[0]['balance'])){
                    $end_asset = 0;
                } else{
                    $end_asset = $new_end[0]['balance'];
                }

                //期间c2c数据
                if($asset == 'CNT'){
                    $c2c_data_in = $this-> Rm_profit_loss_model->c2c($user_id,1);
                    if(empty($c2c_data_in['amount'])){
                        $c2c_in = 0;
                    } else{
                        $c2c_in = $c2c_data_in['amount'];
                    }
                    //转出
                    $c2c_data_out = $this-> Rm_profit_loss_model->c2c($user_id,2);
                    if(empty($c2c_data_out['amount'])){
                        $c2c_out = 0;
                    } else{
                        $c2c_out = $c2c_data_out['amount'];
                    }
                }else{
                    $c2c_in = 0;
                    $c2c_out = 0;
                }


                //期间otc数据
                //otc转入
                $otc_data_in = $this-> Rm_profit_loss_model->otc($user_id,1,$asset);
                if(empty($otc_data_in['amount'])){
                    $otc_in = 0;
                } else{
                    $otc_in = $otc_data_in['amount'];
                }

                //otc转出
                $otc_data_out = $this-> Rm_profit_loss_model->otc($user_id,2,$asset);
                if(empty($otc_data_out['amount'])){
                    $otc_out = 0;
                } else{
                    $otc_out = $otc_data_out['amount'];
                }
                //期间提币数据
                $withdraws_data = $this-> Rm_profit_loss_model->withdraws($user_id,$asset);
                if(empty($withdraws_data['amount'])){
                    $withdraws = 0;
                } else{
                    $withdraws = $withdraws_data['amount'];
                }

                //期间充值数据
                $recharge_data = $this-> Rm_profit_loss_model->recharge($user_id,$asset);
                if(empty($recharge_data['amount'])){
                    $recharge = 0;
                } else{
                    $recharge = $recharge_data['amount'];
                }

                $out = $c2c_out + $withdraws + $otc_out;
                $in  = $c2c_in + $recharge + $otc_in;
                $original_data = $start_asset - $out + $in;


                if($start_asset==0){
                    $value['rate'] = 0;
                }else{
                    $value['rate'] = round(floatval(($original_data - $start_asset))/floatval($start_asset),2);
                }

                $param = $this->Rm_parameter_model->param_profit(6);

               // if(!empty($param['rate'])){

                    if ($value['rate'] >= round($param['rate']/100,2)){
//                        $site = $this->Zjys_user_model->check_site_id($value['id']);
//                        if(!empty($site['site_id']))
//                            $val['site_id'] = $site['site_id'];
                        $res[$key]['user_id'] = $user_id;
                        $res[$key]['asset'] = $asset;
                        $res[$key]['out'] = $out;
                        $res[$key]['in'] = $in;
                        $res[$key]['original_data'] = $original_data;
                        $res[$key]['rate'] =  $value['rate'];
                        $res[$key]['start_asset'] = $start_asset;
                        $res[$key]['end_asset'] = $end_asset;
                    }
                }
          //  }


       // }


//        if (!empty($res))
//         //白名单过滤
//        foreach($res as $key => $value){
//         $phone = $this->Zjys_user_model->check_phone($value['id']);
//         if(!empty($phone))
//         $white = $this->User_white_list_model->find_phone($value['id']);
//         if(empty($white)){
//             $last[$key]['user_id'] =  $value['user_id'];
//            $last[$key]['out'] =  $value['out'];
//            $last[$key]['in'] =  $value['in'];
//            $last[$key]['original_data'] =  $value['original_data'];
//            $last[$key]['rate'] = $value['rate'];
//            $last[$key]['start_asset'] = $value['start_asset'];
//            $last[$key]['end_asset'] = $value['end_asset'];
//         }
//        }
        if(!empty($res))
        $time = date('Y-m-d H:i:s',time());
        if(!empty($time)){
            foreach ($res as $ke => $val) {
                $id = $this->Rm_profit_loss_model->add($val['user_id'],$val['out'],$val['in'],$val['rate'],$val['start_asset'],$time,$val['end_asset'],$val['asset']);

//                $message = '['.$id.','.$val['user_id'].','.$val['asset'].','.$val['balance'].','.$time.','.$val['site_id'].']';
//                $business = 'profit_loss_alarm';
//                $this->rabbit_message($id,$message,$business);
            }
        }
    }


    /**
     * 异常账目监控
     * @Author   张哲
     * @DateTime 2018-10-19
     * @createby SublimeText3
     * @version  1.0
     * 如果出现不平资产，同一个用户的同一个币种只取最后一条记录
     */
    public function get_account_alarm(){
        //获取用户的不平资产（）
        $DB1 = $this->load->database('trade_history',true);
        $res = array();
        $last = array(); //存储过滤后额数组

             for ($i=0; $i < 100; $i++) { 
                $sql = "select user_id,asset,balance,substring_index(group_concat(time order by time desc),  
                                    ',',  
                                    1) as time from balance_history_".$i." where  balance < 0 group by user_id,asset order by user_id desc";               
                $object = object_to_array($DB1->query($sql)->result());
                 if($i==0){
                    $new = array_merge(array(),$object);
                }else{
                    @$new = &array_merge($new,$object);
                }                                 
            } 
            foreach($new as $key => $item){             
                   //查找站点
                   $site = $this->Zjys_user_model->check_site_id($item['user_id']);
                   if(!empty($site['site_id'])){
                    $res[$key]['site_id'] = $site['site_id'];
                   }

                   $res[$key]['asset'] = $item['asset'];
                   $res[$key]['balance'] = $item['balance'];                  
                   $res[$key]['user_id'] = $item['user_id']; 
                   $res[$key]['time'] = $item['time']; 
                   $res[$key]['mark'] = "余额";                                 
                }
        //}
        //总资产不平记录
        $user_assets = $this->Zjys_assets_model->user_assets();
        //if(!empty( $user_assets)){
            foreach($user_assets as $key => $item){             
            //查找站点
            $site = $this->Zjys_user_model->check_site_id($item['user_id']);
            if(!empty($site['site_id'])){
                $res[$key]['site_id'] = $site['site_id'];
            }
            $res[$key]['asset'] =  $item['asset'];
            $res[$key]['balance'] =  $item['balance'];           
            $res[$key]['user_id'] = $item['user_id'];
            $res[$key]['time'] = $item['created_at']; 
            $res[$key]['mark'] = "其它";                                 
         }
        //}
        
        //活动不平记录
        $user_activity_assets = $this->Zjys_assets_model->user_activity_assets();
        //if(!empty($user_activity_assets)){
             foreach($user_activity_assets as $key => $item){             
            //查找站点
            $site = $this->Zjys_user_model->check_site_id($item['user_id']);
            if(!empty($site['site_id'])){
                $res[$key]['site_id'] = $site['site_id'];
            }
            $res[$key]['asset'] =  $item['asset'];
            $res[$key]['balance'] =  $item['balance'];          
            $res[$key]['user_id'] = $item['user_id'];
            $res[$key]['time'] = $item['created_at'];
            $res[$key]['mark'] = "其它";                                  
         }


         //白名单过滤
        foreach($res as $key => $value){
         $phone = $this->Zjys_user_model->check_phone($value['user_id']);

         if(!empty($phone['id'])){
            $account = $phone['id'];
         }

         $phone = $this->User_white_list_model->find_phone($account);

         if(empty($phone)){
            $last[$key]['asset'] =  $value['asset'];
            $last[$key]['balance'] =  $value['balance'];
            $last[$key]['user_id'] =  $value['user_id'];
            $last[$key]['site_id'] = $value['site_id']; 
            $last[$key]['time'] = $value['time'];            
         }
         
        }
        $time = date('Y-m-d H:i:s',time());
        if(!empty($time)){
            foreach ($last as $key => $val) {
                $id =  $this->Rm_account_modle->add($val['asset'],$val['balance'],$val['user_id'],$time,$val['site_id']);

                $message = '['.$id.','.$val['user_id'].','.$val['asset'].','.$val['balance'].','.$time.','.$val['site_id'].']';
                $business = 'account_asset_alarm';
                $this->rabbit_message($id,$message,$business);
            }
        }
    }


    /**
     * Notes: 异常提币监控-相同hash
     * User: 张哲
     * Date: 2018/11/26
     * Time: 20:43
     * @param $site_id
     */
    public function get_withdraws_alarm(){
        //获取提币相同交易哈希
        $withdraws_record = $this->Zjys_user_withdraw_model->get_withdraws_record();
        //获取充值相同交易哈希
        $recharge_record = $this->Zjys_recharge_logs_model->get_recharge_record();
        $time = date('Y-m-d H:i:s',time());
        if(!empty($time)){
            foreach ($withdraws_record as $key => $val) {
                $check_hash = $this->Rm_withdraws_recharge_alarm_model->check_hash($val['tx_id'],$val['real_amount'],$val['user_id'],$val['asset']);
                if(empty($check_hash)){
                    $type = 1;
                    $id = $this->Rm_withdraws_recharge_alarm_model->add_withdraws($val['user_id'],$val['asset'],$val['tx_id'],$val['real_amount'],$type,$time,$val['site_id']);

                    $message = '['.$id.','.$val['user_id'].','.$val['tx_id'].','.$val['asset'].','.$time.','.$val['site_id'].']';
                    $business = 'withdraws_hash_same_alarm';
                    $this->rabbit_message($id,$message,$business);
                }
            }
            foreach ($recharge_record as $key => $val) {
                $check_hash1 = $this->Rm_withdraws_recharge_alarm_model->check_hash($val['tx_hash'],$val['amount'],$val['user_id'],$val['asset']);
                if(empty($check_hash1)){
                    $type1 = 0;
                    $id = $this->Rm_withdraws_recharge_alarm_model->add_recharge($val['user_id'],$val['asset'],$val['tx_hash'],$val['amount'],$type1,$time);

                    $message = '['.$id.','.$val['user_id'].','.$val['tx_hash'].','.$val['asset'].','.$time.']';
                    $business = 'recharge_hash_same_alarm';
                    $this->rabbit_message($id,$message,$business);
                }
            }
        }
    }


    /**
     * Notes: 重复充币地址监控
     * User: 张哲
     * Date: 2018/11/29
     * Time: 18:44
     */
    public function get_address_alarm(){

        //获取提币相同充币地址
        $recharge_address_record = $this->Zjys_recharge_logs_model->double_address();
        //var_dump($recharge_address_record);die();
        $time = date('Y-m-d H:i:s',time());
        if(!empty($time)){
            foreach ($recharge_address_record as $key => $val) {
                $check_hash = $this->Rm_address_alarm_model->check_address($val['address'],$val['user_id'],$val['asset']);
                if(empty($check_hash)){
                    $status = 0;
                    $id = $this->Rm_address_alarm_model->add_address($val['user_id'],$val['address'],$val['asset'],$time,$status);

                    $status = '未处理';
                    $message = '['.$id.','.$val['user_id'].','.$val['address'].','.$val['asset'].','.$time.','.$status.']';
                    $business = 'address_alarm';
                    $this->rabbit_message($id,$message,$business);
                }
            }
        }
    }

    /**
     * 获取交易对
     * @Author   张哲
     * @DateTime 2018-10-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * 如果出现不平资产，同一个用户的同一个币种只取最后一条记录
     */
    public function get_market($site_id){


        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $assetList = $this->Zjys_symbols_model->list_all_siteid(1);
        } else {
            $assetList = $this->Zjys_symbols_model->list_all_siteid($site_id);
        }


        return $assetList;
    }


    /**
     * 交易警报列表
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_transaction_list($offset,$limit,$start_time,$end_time,$site_id,$symbol){
        $object = $this->db->select("rm_transaction_alarm.*")
        ->from('rm_transaction_alarm');
        $object =$this->db->where('rm_transaction_alarm.deleted_at is null');
        if($site_id!='') $object =$this->db->where('rm_transaction_alarm.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('rm_transaction_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_transaction_alarm.created_at <=',$end_time);
        }
        
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
       
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        }        
        return $list;
    }

    /**
     * 交易警报条数
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_transaction_count($start_time,$end_time,$site_id,$symbol){
        $object = $this->db->select("rm_transaction_alarm.*")
        ->from('rm_transaction_alarm');             
       
        if($site_id!='') $object =$this->db->where('rm_transaction_alarm.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('rm_transaction_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_transaction_alarm.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * 盈亏警报列表
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_profit_loss_list($offset,$limit,$start_time,$end_time,$site_id,$sort){
        $object = $this->db->select("rm_profit_loss_alarm.*")
        ->from('rm_profit_loss_alarm');
        if($site_id!='') $object =$this->db->where('rm_profit_loss_alarm.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('rm_profit_loss_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_profit_loss_alarm.created_at <=',$end_time);
        }
        if($sort == 0){
            $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        }else{
            $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        }
        
        
        foreach ($list as &$val){
           $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
           if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        } 
        }        
        return $list;
    }

    /**
     * 盈亏警报条数
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_profit_loss_count($start_time,$end_time,$site_id){
        $object = $this->db->select("rm_profit_loss_alarm.*")
        ->from('rm_profit_loss_alarm');             
       
        if($site_id!='') $object =$this->db->where('rm_profit_loss_alarm.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('rm_profit_loss_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_profit_loss_alarm.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }


     /**
     * 异常账目警报列表
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_account_list($offset,$limit,$start_time,$end_time,$site_id){
        $object = $this->db->select("rm_account_alarm.*")
        ->from('rm_account_alarm');
        if($site_id!='') $object =$this->db->where('rm_account_alarm.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('rm_account_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_account_alarm.created_at <=',$end_time);
        }
        
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        
        foreach ($list as &$val){
           $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
           if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
            } 
        }        
        return $list;
    }

    /**
     * 异常账目条数
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     */
    public function get_account_count($start_time,$end_time,$site_id){
        $object = $this->db->select("rm_account_alarm.*")
        ->from('rm_account_alarm');             
       
        if($site_id!='') $object =$this->db->where('rm_account_alarm.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('rm_account_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_account_alarm.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }



   /**
   * 获取异常交易警报参数
   * @Author   张哲
   * @DateTime 2018-10-29
   * @createby SublimeText3
   * @version  1.0
   * @return   [return]
   */
    public function get_transaction_param($site_id){
//        $check = $this->Rm_parameter_model->check_record($symbol,$site_id);
//        if(!empty($check['rate'])){
//             $check['rate'] = $check['rate'].'%';
//        }
//        if(!empty($check['site_id'])){
//            $site_name = $this->Zjys_symbols_model->get_symbols_name($check['site_id']);
//        }
//        if(!empty($site_name['name'])){
//            $check['site_name'] = $site_name['name'];
//        }
//        return $check;


        $object = $this->db->select("rm_parameter.*")
            ->from('rm_parameter');
       // $object =$this->db->where('rm_parameter.symbol is null');
        if($site_id!='') $object =$this->db->where('rm_parameter.site_id = ',$site_id);

        $list = $object->get()->result_array();

        return $list;
    }

    /**
     * 增加异常交易警报参数
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function modify_transaction_param($result,$site_id){
        $object = $this->db->select("rm_parameter.*")
            ->from('rm_parameter');
        if($site_id!='') $object =$this->db->where('rm_parameter.site_id = ',$site_id);
        $status = 4;
        if($status!='') $object =$this->db->where('rm_parameter.status = ',$status);
        $list = $object->get()->result_array();

        $site_asset_list = array();
        foreach ($list as $key => $value) {
            $site_asset_list[] = $value['symbol'];
        }
        //看传参是否在表中存在，存在就修改参数，不存在就增加记录
        foreach ($result as $key => $value) {
            if(in_array($value['symbol'], $site_asset_list)){
                $time = date('Y-m-d H:i:s',time());
                $update_at = NULL;
                $this->Rm_parameter_model->update_record($value['symbol'],$value['rate'],$site_id,$time,$update_at);
            }else{
                $time = date('Y-m-d H:i:s',time());
                $this->Rm_parameter_model->add_record($value['symbol'],$value['rate'],$site_id,$time);
            }
        }

        $client_asset_list = array();
        foreach ($result as $key => $value) {
            $client_asset_list[] = $value['symbol'];
        }
        //var_dump($list,$client_asset_list);die();
        //表中多余的数据需要删除
        foreach ($list as $key => $value) {
            if(!in_array($value['symbol'], $client_asset_list)){
                $time = date('Y-m-d H:i:s',time());
                $this->Rm_parameter_model->delete_record($value['id'],$time);
            }
        }
        return;
    }



    /**
     * 获取异常账目警报参数
     * @Author   张哲
     * @DateTime 2018-10-29
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_account_param($site_id){     
        $check = $this->Rm_parameter_model->check_account_record($site_id); 
        if(!empty($check['rate'])){
             $check['rate'] = $check['rate'].'%'; 
        }
        if(!empty($check['site_id'])){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($check['site_id']);
        }
        if(!empty($site_name['name'])){
            $check['site_name'] = $site_name['name'];
        }
        return $check;         
    }

    /**
     * 增加修改异常账目参数
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function modify_account_param($rate,$send_time,$site_id){
        //先检测数据是否存在，不存在的话增加新的记录，存在的话就修改原纪录
        $check = $this->Rm_parameter_model->check_account_record($site_id);
        // var_dump($check);die();
        if(!empty($check)){
            $time = date('Y-m-d H:i:s',time());           
            $this->Rm_parameter_model->update_account_record($rate,$send_time,$site_id,$time,$check['id']);
        }else{           
            $time = date('Y-m-d H:i:s',time());           
            $this->Rm_parameter_model->add_account_record($rate,$send_time,$site_id,$time);
        }
        
    }


    /**
     * 获取异常盈亏警报参数
     * @Author   张哲
     * @DateTime 2018-11-01
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_profit_param($site_id){     
        $check = $this->Rm_parameter_model->check_profit_record($site_id); 
        if(!empty($check['rate'])){
             $check['rate'] = $check['rate'].'%'; 
        }
        if(!empty($check['site_id'])){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($check['site_id']);
        }
        if(!empty($site_name['name'])){
            $check['site_name'] = $site_name['name'];
        }
        return $check;         
    }

    /**
     * 增加修改异常盈亏参数
     * @Author   张哲
     * @DateTime 2018-11-01
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function modify_profit_param($rate,$send_time,$site_id){
        //先检测数据是否存在，不存在的话增加新的记录，存在的话就修改原纪录
        $check = $this->Rm_parameter_model->check_profit_record($site_id);
        // var_dump($check);die();
        if(!empty($check)){
            $time = date('Y-m-d H:i:s',time());           
            $this->Rm_parameter_model->update_profit_record($rate,$send_time,$site_id,$time,$check['id']);
        }else{           
            $time = date('Y-m-d H:i:s',time());           
            $this->Rm_parameter_model->add_profit_record($rate,$send_time,$site_id,$time);
        }
        
    }

    /**
     * 白名单列表
     * @Autor   张哲
     * @DateTime 2018-11-07
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_user_white_list($offset,$limit,$start_time,$end_time,$site_id){
        $object = $this->db->select("user_white_list.*")
        ->from('user_white_list');
      
        $object =$this->db->where('user_white_list.deleted_at is null');

        if($site_id!='') $object =$this->db->where('user_white_list.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('user_white_list.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_white_list.created_at <=',$end_time);
        }
        
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        
        foreach ($list as &$val){
           $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
           if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
            } 
        }        
        return $list;
    }

    /**
     * 白名单列表条数
     * @Author   张哲
     * @DateTime 2018-11-07
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function get_user_white_count($start_time,$end_time,$site_id){
        $object = $this->db->select("user_white_list.*")
        ->from('user_white_list');             
        $object =$this->db->where('user_white_list.deleted_at is null');
        if($site_id!='') $object =$this->db->where('user_white_list.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('user_white_list.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_white_list.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    
    /**
     * 白名单修改
     * @Author   张哲
     * @DateTime 2018-11-07
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function user_white_add($account,$site_id){
        //先检测数据是否存在，不存在的话增加新的记录，存在的话就修改原纪录
        $check = $this->Zjys_user_model->check_account_phone($account);
      
        $account1 = $this->User_white_list_model->check_phone($account); 

       
            if(!empty($check) && empty($account1['id'])){
            $time = date('Y-m-d H:i:s',time());           
            $this->User_white_list_model->add_white_record($check['id'],$site_id,$time); 
            
        }else if(!empty($account1['id'])){
            returnJson('300',lang('account_exist'));
        }else{
            returnJson('100',lang('no_account')); 
        } 
            
               
    }

    /**
     * 白名单删除
     * @Author   张哲
     * @DateTime 2018-11-07
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
    public function user_white_delete($account,$site_id){
        $check = $this->User_white_list_model->check_phone($account); 

        $time = date('Y-m-d H:i:s',time()); 
        if(!empty($check['id'])){
            $this->User_white_list_model->user_white_delete($account,$site_id,$time,$check['id']);         
        }          
        
    }


    /**
     * Notes: 充提监控列表
     * User: 张哲
     * Date: 2018/11/28
     * Time: 10:50
     */
    public function withdraws_alarm_list($offset,$limit,$start_time,$end_time,$site_id,$user_id,$type){
        $object = $this->db->select("rm_withdraws_recharge_alarm.*")
            ->from('rm_withdraws_recharge_alarm');

        $object =$this->db->where('rm_withdraws_recharge_alarm.deleted_at is null');

        if($site_id!='') $object =$this->db->where('rm_withdraws_recharge_alarm.site_id = ',$site_id);
        if($user_id!='') $object =$this->db->where('rm_withdraws_recharge_alarm.user_id = ',$user_id);
        if($type!='') $object =$this->db->where('rm_withdraws_recharge_alarm.type = ',$type);
        if(!empty($start_time)){
            $object =$this->db->where('rm_withdraws_recharge_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_withdraws_recharge_alarm.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();

        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            if($val['type'] == 0){
                $val['type_name'] = '充值';
            } elseif($val['type'] == 1){
                $val['type_name'] = '提现';
            }
        }
        return $list;
    }

    /**
     * Notes: 充提监控列表条数
     * User: 张哲
     * Date: 2018/11/28
     * Time: 10:51
     */
    public function withdraws_alarm_list_count($start_time,$end_time,$site_id,$user_id,$type){
        $object = $this->db->select("rm_withdraws_recharge_alarm.*")
            ->from('rm_withdraws_recharge_alarm');
        $object =$this->db->where('rm_withdraws_recharge_alarm.deleted_at is null');
        if($site_id!='') $object =$this->db->where('rm_withdraws_recharge_alarm.site_id = ',$site_id);
        if($user_id!='') $object =$this->db->where('rm_withdraws_recharge_alarm.user_id = ',$user_id);
        if($type!='') $object =$this->db->where('rm_withdraws_recharge_alarm.type = ',$type);

        if(!empty($start_time)){
            $object =$this->db->where('rm_withdraws_recharge_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_withdraws_recharge_alarm.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/28
     * Time: 11:23
     * @param $id
     */
    public function deal_status($id){
        $status = 1;
        $operation_admin_id = $this->user_id;
        $admin_operator = $this->Admin_model->get_admin_name($operation_admin_id);
        $time = date('Y-m-d H:i:s',time());
       $this->Rm_withdraws_recharge_alarm_model->deal_status($id,$status,$admin_operator['true_name'],$time);

    }

    /**
     * Notes: 重复地址列表
     * User: 张哲
     * Date: 2018/11/29
     * Time: 19:58
     */
    public function recharge_address_list($offset,$limit,$start_time,$end_time,$user_id){
        $object = $this->db->select("rm_address_alarm.*")
            ->from('rm_address_alarm');

        $object =$this->db->where('rm_address_alarm.deleted_at is null');
        if($user_id!='') $object =$this->db->where('rm_address_alarm.user_id = ',$user_id);
        if(!empty($start_time)){
            $object =$this->db->where('rm_address_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_address_alarm.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();

        return $list;
    }

    /**
     * Notes: 重复地址列表条数
     * User: 张哲
     * Date: 2018/11/29
     * Time: 19:59
     */
    public function recharge_address_list_count($start_time,$end_time,$user_id){
        $object = $this->db->select("rm_address_alarm.*")
            ->from('rm_address_alarm');
        $object =$this->db->where('rm_address_alarm.deleted_at is null');

        if($user_id!='') $object =$this->db->where('rm_address_alarm.user_id = ',$user_id);
        if(!empty($start_time)){
            $object =$this->db->where('rm_address_alarm.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('rm_address_alarm.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * Notes:  重复地址状态处理
     * User: 张哲
     * Date: 2018/11/29
     * Time: 20:00
     * @param $id
     */
    public function address_deal_status($id){
        $status = 1;
        $operation_admin_id = $this->user_id;
        $admin_operator = $this->Admin_model->get_admin_name($operation_admin_id);
        $time = date('Y-m-d H:i:s',time());
        $this->Rm_address_alarm_model->address_deal_status($id,$status,$admin_operator['true_name'],$time);

    }

    /**
     * Notes: 风控通知人员
     * User: 张哲
     * Date: 2019/3/19
     * Time: 20:55
     * @param $args
     * @return bool
     */
    public function add_target_roles($args){
        $id = isset($args['id']) ? $args['id']: '';
        $name = isset($args['name']) ? $args['name'] : '';
        $phone= isset($args['phone']) ? $args['phone'] : '';
        $email= isset($args['email']) ? $args['email'] : '';
        $target= isset($args['target']) ? $args['target'] : '';
        $site_id= isset($args['site_id']) ? $args['site_id'] : '';
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());

        if(!$id){
            //新增
             $this->Rm_account_modle->add_name($name,$phone,$email,$created_at,$site_id,$target);
        }else{
            //修改
            $this->Rm_account_modle->edit_name($id,$name,$phone,$email,$updated_at,$site_id,$target);
        }
        return true;
    }


    /**
     * Notes: 删除监控账户
     * User: 张哲
     * Date: 2019/3/19
     * Time: 21:16
     * @param $args
     * @return mixed
     */
    public function delete_target_roles($id){
        $time = time();
        return $this->Rm_account_modle->delete_target_roles($id,$time);
    }

    /**
     * Notes: 监控账户列表
     * User: 张哲
     * Date: 2019/3/19
     * Time: 21:29
     */
    public function target_list($offset,$limit,$name){
        $object = $this->db->select("rm_people_alarm.*")
            ->from('rm_people_alarm');
        $object =$this->db->where('rm_people_alarm.deleted_at is null');
        if($name!='') $object =$this->db->where('rm_people_alarm.name = ',$name);
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
        }
        return $list;
    }

    /**
     * Notes: 监控账户列表
     * User: 张哲
     * Date: 2019/3/19
     * Time: 21:29
     */
    public function target_count($name){
        $object = $this->db->select("rm_people_alarm.*")
            ->from('rm_people_alarm');

        $object =$this->db->where('rm_people_alarm.deleted_at is null');

        if($name!='') $object =$this->db->where('rm_people_alarm.name = ',$name);
        return $this->db->count_all_results();
    }


    function symbol_combine($asset){
        $ci =& get_instance();
        $symbol = $asset.'_'.$ci->config->item('C2C_ASSET');
        $price_trans = get_market_last($symbol);
        return $price_trans;

    }

    /**
     * Notes: 大额充提监控(7日内累计折合，获取最近1日0点价格，对7日内的充值、提币进行折合，当折合值大于设置的阈值后，进行报警)
     * User: 张哲
     * Date: 2019-04-22
     * Time: 16:00
     * @param $start_time
     * @param $end_time
     */
    public function large_amount_charge_alarm()
    {
        /**
         * 获取提币7日数据；
         * 1.资产的直接求和
         * 2.C2C的直接求和
         */
        $res = array();
        $last = array();
        $end_time = time();
        $start_time = $end_time - 86400 * 7;
        $end_time = date('Y-m-d H:i:s',time());
        $start_time = date('Y-m-d H:i:s',$start_time);
        //获取临界值
        $withdraws_set_value = $this->Rm_new_par_model->large_amount_value(2);
        $amount = $withdraws_set_value['value'];
        //获取记录
        $withdraws_record = $this->Zjys_user_withdraw_model->large_amount_charge_withdraws($start_time,$end_time);
        //var_dump($withdraws_record);
        foreach($withdraws_record as $key => $item){
            if($item['amount'] > $amount){
                $res[$key]['amount'] =  $item['amount'];
                $res[$key]['user_id'] = $item['user_id'];
                $res[$key]['time'] = $item['created_at'];
                $res[$key]['site_id'] = $item['site_id'];
                $res[$key]['status'] = 2;
            }
        }

        //充值
        $withdraws_set_value = $this->Rm_new_par_model->large_amount_value(1);
        $amount = $withdraws_set_value['value'];
        $recharge_record = $this->Zjys_recharge_logs_model->large_amount_charge_recharge($start_time,$end_time);
        foreach($recharge_record as $key => $item){
            if($item['amount'] > $amount){
                $site = $this->Zjys_user_model->check_site_id($item['user_id']);
                if(!empty($site['site_id'])){
                    $res[$key]['site_id'] = $site['site_id'];
                }
                $res[$key]['amount'] =  $item['amount'];
                $res[$key]['user_id'] = $item['user_id'];
                $res[$key]['time'] = $item['created_at'];
                $res[$key]['status'] = 1;
            }
        }

        //白名单过滤
        foreach($res as $key => $value) {
            $phone = $this->Zjys_user_model->check_phone($value['user_id']);

            if (!empty($phone['id'])) {
                $account = $phone['id'];
            }

            $phone = $this->User_white_list_model->find_phone($account);

            if (empty($phone)) {
                $last[$key]['amount'] = $value['amount'];
                $last[$key]['user_id'] = $value['user_id'];
                $last[$key]['time'] = $value['time'];
                $last[$key]['site_id'] = $value['site_id'];
                $last[$key]['status'] = $value['status'];
            }
        }

        $time = date('Y-m-d H:i:s',time());
        if(!empty($time)){
            foreach ($last as $key => $val) {
                $id =  $this->Rm_new_par_model->add_large_amount($val['amount'],$val['user_id'],$time,$val['site_id'],$val['status']);
                $message = '['.$id.','.$val['user_id'].','.$val['amount'].','.$time.','.$val['site_id'].']';
                $business = 'large_amount_alarm';
                $this->rabbit_message($id,$message,$business);
            }
        }


    }


    /**
     * Notes: 提币到账时间监控
     * User: 张哲
     * Date: 2019-04-24
     * Time: 16:19
     */
    public function withdraws_wallet_alarm()
    {
        $res = array();
        $last = array();
        $end_time = time();
        $start_time = $end_time - 3600;
        $end_time = date('Y-m-d H:i:s',time());
        $start_time = date('Y-m-d H:i:s',$start_time);
        //获取临界值-时间
        $withdraws_set_value = $this->Rm_new_par_model->large_amount_value(3);
        $amount = $withdraws_set_value['value'];
        $withdraws_record = $this->Zjys_user_withdraw_model->withdraws_wallet_alarm($start_time,$end_time);


        foreach($withdraws_record as $key => $item){
            //当前时间减去
            $time = time();
            $send_time = strtotime($item['created_at']);
            $difference_time = $time - $send_time;

            if($difference_time > $amount * 60){
                $res[$key]['user_id'] = $item['user_id'];
                $res[$key]['asset'] = $item['asset'];
                $res[$key]['address_id'] =  $item['user_withdraw_address_id'];
                $res[$key]['amount'] = $item['amount'];
                $res[$key]['time'] = $item['created_at'];
                $res[$key]['site_id'] = $item['site_id'];
            }
        }

        $time = date('Y-m-d H:i:s',time());
        if(!empty($time)){
            foreach ($res as $key => $val) {
                $check_exist = $this->Rm_new_par_model->check_exist($val['user_id'],$val['asset'],$val['address_id'],$val['amount'],$val['time'],$val['site_id']);
                if(empty($check_exist)){
                    $id =  $this->Rm_new_par_model->add_withdraws_wallet($time,$val['user_id'],$val['asset'],$val['address_id'],$val['amount'],$val['time'],$val['site_id']);

                    $message = '['.$id.','.$val['user_id'].','.$val['amount'].','.$time.','.$val['site_id'].']';
                    $business = 'large_amount_alarm';
                    $this->rabbit_message($id,$message,$business);
                }

            }
        }


    }


    /**
     * Notes: 大额充值列表
     * User: 张哲
     * Date: 2019-04-24
     * Time: 18:25
     */
    public function large_amount_list($offset, $limit, $start_time, $end_time,$user_id)
    {
        $object = $this->db->select("rm_large_amount.*")
            ->from('rm_large_amount');

        $object = $this->db->where('rm_large_amount.deleted_at is null');

        if (!empty($start_time)) {
            $object = $this->db->where('rm_large_amount.created_at >=', $start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('rm_large_amount.created_at <', $end_time);
        }
        //用户搜索
        if (!empty($currency)) {
            $object = $this->db->where('rm_large_amount.user_id =', $user_id);
        }

        $list = $object->limit($limit, $offset)->order_by('created_at', 'desc')->get()->result_array();


        foreach ($list as &$value) {

            if ($value['status'] == 1) {
                $value['status_code'] = '已处理';
            } else {
                $value['status_code'] = '未处理';
            }
            if ($value['type'] == 1) {
                $value['type_code'] = '大额充值';
            } else {
                $value['type_code'] = '大额提现';
            }
        }
        return $list;
    }

    /**
     * Notes: 大额充值列表-数量
     * User: 张哲
     * Date: 2019-04-24
     * Time: 18:25
     */
    public function large_amount_list_count($start_time, $end_time,$user_id)
    {
        $object = $this->db->select("rm_large_amount.*")
            ->from('rm_large_amount');

        $object = $this->db->where('rm_large_amount.deleted_at is null');

        if (!empty($start_time)) {
            $object = $this->db->where('rm_large_amount.created_at >=', $start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('rm_large_amount.created_at <', $end_time);
        }
        //用户搜索
        if (!empty($currency)) {
            $object = $this->db->where('rm_large_amount.user_id =', $user_id);
        }

        return $this->db->count_all_results();
    }


    /**
     * Notes: 提币hash钱包反馈监控
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:38
     */
    public function withdraws_wallet_list($offset, $limit, $start_time, $end_time,$user_id)
    {
        $object = $this->db->select("rm_withdraws_wallet.*")
            ->from('rm_withdraws_wallet');

        $object = $this->db->where('rm_withdraws_wallet.deleted_at is null');

        if (!empty($start_time)) {
            $object = $this->db->where('rm_withdraws_wallet.created_at >=', $start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('rm_withdraws_wallet.created_at <', $end_time);
        }
        //用户搜索
        if (!empty($currency)) {
            $object = $this->db->where('rm_withdraws_wallet.user_id =', $user_id);
        }


        $list = $object->limit($limit, $offset)->order_by('created_at', 'desc')->get()->result_array();

        foreach ($list as &$value) {

            if ($value['status'] == 1) {
                $value['status_code'] = '已处理';
            } else {
                $value['status_code'] = '未处理';
            }

            $object = $this->db->select("user_withdraw_addresses.address")
                ->from('user_withdraw_addresses');
            $object = $this->db->where('user_withdraw_addresses.id =', $value['address_id']);
            $list1 = $object->order_by('created_at', 'desc')->get()->result_array();
            $value['address'] = $list1[0]['address'];
        }

        return $list;
    }

    /**
     * Notes: 提币hash钱包反馈监控
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:38
     */
    public function withdraws_wallet_list_count($start_time, $end_time,$user_id)
    {
        $object = $this->db->select("rm_withdraws_wallet.*")
            ->from('rm_withdraws_wallet');

        $object = $this->db->where('rm_withdraws_wallet.deleted_at is null');

        if (!empty($start_time)) {
            $object = $this->db->where('rm_withdraws_wallet.created_at >=', $start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('rm_withdraws_wallet.created_at <', $end_time);
        }
        //用户搜索
        if (!empty($currency)) {
            $object = $this->db->where('rm_withdraws_wallet.user_id =', $user_id);
        }

        return $this->db->count_all_results();
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:51
     * @param $args
     */
    public function large_amount_deal($args)
    {
        $data = array();
        $id = isset($args['id']) ? $args['id']: '';
        $data['status'] = 1;
        $updated_at = date("Y-m-d H:i:s", time());
        $data['deal_time'] = $updated_at;
        $this->db->where('id', $id);
        $this->db->update('rm_large_amount', $data);
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:51
     * @param $args
     */
    public function withdraws_wallet_deal($args)
    {
        $data = array();
        $id = isset($args['id']) ? $args['id']: '';
        $data['status'] = 1;
        $updated_at = date("Y-m-d H:i:s", time());
        $data['deal_time'] = $updated_at;
        $this->db->where('id', $id);
        $this->db->update('rm_withdraws_wallet', $data);
    }

    /**
     * Notes: 大额参数编辑
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:59
     */
    public function large_amount_par($args)
    {
        //$id = isset($args['id']) ? $args['id']: '';
        if($args['status'] == 1){
            $id = $this->Rm_new_par_model->large_amount_value(1);
        }else{
            $id = $this->Rm_new_par_model->large_amount_value(2);
        }


        if (!$id) {
            $created_at = date("Y-m-d H:i:s", time());
            $args ['created_at'] = $created_at;
            //新增
            $this->db->insert('rm_new_par', $args);
        } else {
            $updated_at = date("Y-m-d H:i:s", time());
            $args ['updated_at'] = $updated_at;
            $this->db->where('status', $id['status']);
            $this->db->update('rm_new_par', $args);
        }
        return true;
    }


    /**
     * Notes: 提币参数编辑
     * User: 张哲
     * Date: 2019-04-25
     * Time: 10:13
     * @param $args
     * @return bool
     */
    public function withdraws_wallet_par($args)
    {
        //$id = isset($args['id']) ? $args['id']: '';
        $id = $this->Rm_new_par_model->large_amount_value(3);

        if (!$id) {
            $created_at = date("Y-m-d H:i:s", time());
            $args ['created_at'] = $created_at;
            $args ['status'] = 3;
            //新增
            $this->db->insert('rm_new_par', $args);
        } else {
            $updated_at = date("Y-m-d H:i:s", time());
            $args ['updated_at'] = $updated_at;
            $this->db->where('status', $id['status']);
            $this->db->update('rm_new_par', $args);
        }
        return true;
    }


    /**
     * Notes: 获取新的参数
     * User: 张哲
     * Date: 2019-04-29
     * Time: 10:19
     */
    public function get_new_par($args)
    {
        $object = $this->db->select("value,status")
            ->from('rm_new_par');

        $object = $this->db->where('rm_new_par.deleted_at is null');


      //  $object = $this->db->where('rm_new_par.status =', $args['status']);



        $list = $object->get()->result_array();
        $arr = array();
        foreach ($list as &$value) {

            if ($value['status'] == 1) {
                $arr['recharge'] = $value['value'];
            } else if ($value['status'] == 2) {
                $arr['withdraws'] = $value['value'];
            } else if ($value['status'] == 3) {
                $arr['withdraws_account'] = $value['value'];
            }
        }

        return $arr;
    }

}