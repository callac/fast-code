<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Zg_activity_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->zg_activity_db= $this->load->database('zg_activity', TRUE);
    }
    const NewYearWaitingForBonus     = 1 ;// 等待开奖      未获取区块hash前
    const NewYearWaitingForConfirmed = 2 ;// 等待区块确认	获取区块hash，但区块确认数未到30
    const NewYearPayBonus            = 3 ;// 奖金已发放    区块确认数达到30，并完成奖金发放
    const NewYearRepealBet           = 4 ;// 投注回退      出现异常，并投注金额已退回
    const NewYearLoseBet             = 5 ;// 未中奖

    const NewYearWaitingStart = 1;
    const NewYearRunning = 2 ;
    const NewYearFinished =3 ;

    public function year_activity_list($pool_type,$user_id,$start_time,$end_time,$type,$page,$limit,$activity_id){
        $offset = ($page- 1) *$limit;
        if($pool_type){
            $this->zg_activity_db->where('a.pool_type',$pool_type);
        }
        if($user_id){
            $this->zg_activity_db->where('a.user_id',$user_id);
        }
        if($start_time){
            $this->zg_activity_db->where('a.bet_time >=',$start_time);
        }
        if($end_time){
            $this->zg_activity_db->where('a.bet_time <=',$end_time);
        }
        if($type){
            $this->zg_activity_db->where('a.state',$type);
        }
        if($activity_id){
            $this->zg_activity_db->where('b.id',$activity_id);
        }
        // $this->zg_activity_db->where('state',$this::NewYearRunning);
        $year_activity_list  = $this->zg_activity_db
            ->select('a.*,c.block_num,c.block_hash,c.block_time,b.activity_name,b.activity_start_time,b.activity_end_time')
            ->order_by('a.id desc')
            ->join('new_year_activities as b','a.activity_id = b.id','left')
            ->join('new_year_block_infos as c','a.eos_id = c.id','left')
            ->limit($limit,$offset)
            ->get_where('new_year_user_bet_logs as a')
            ->result_array();
        $year_activity_count = $this->year_activity_count($pool_type,$user_id,$start_time,$end_time,$type,$activity_id);
        $data['list'] =$year_activity_list;
        $data['total'] =$year_activity_count;
        $data['totalPage'] =ceil($year_activity_count/$limit);
        return $data;
    }

    public function year_activity_count($pool_type,$user_id,$start_time,$end_time,$type,$activity_id){
        if($pool_type){
            $this->zg_activity_db->where('a.pool_type',$pool_type);
        }
        if($user_id){
            $this->zg_activity_db->where('a.user_id',$user_id);
        }
        if($start_time){
            $this->zg_activity_db->where('a.bet_time >=',$start_time);
        }
        if($end_time){
            $this->zg_activity_db->where('a.bet_time <=',$end_time);
        }
        if($type){
            $this->zg_activity_db->where('a.state',$type);
        }
        if($activity_id){
            $this->zg_activity_db->where('b.id',$activity_id);
        }
        //$this->zg_activity_db->where('state',$this::NewYearRunning);
        return $this->zg_activity_db->join('new_year_activities as b','a.activity_id = b.id','left')
                ->get_where('new_year_user_bet_logs as a')
                ->num_rows();
    }

    public function year_activity_pool_log($page,$limit){
        $offset = ($page- 1) *$limit;
        $list =$this->zg_activity_db->limit($limit,$offset)->order_by('id desc')->get('new_year_pool_logs')->result_array();
        $count =$this->zg_activity_db->get('new_year_pool_logs')->num_rows();
        $data['list'] =$list;
        $data['total'] =$count;
        $data['totalPage'] =ceil($count/$limit);
        return $data;
    }

    public function year_state(){
        return array(
            $this::NewYearWaitingForBonus => '等待开奖',
            $this::NewYearWaitingForConfirmed => '等待区块确认',
            $this::NewYearPayBonus => '奖金已发放',
            $this::NewYearRepealBet => '投注回退',
            $this::NewYearLoseBet => '未中奖',
        );
    }

    public function year_activity_monitoring($activity_id){

        //eos奖池
        $eos_pool =$this->zg_activity_db->select('amount,user_total_support_amount,backstage_total_support_amount')
            ->order_by('id desc')
            ->get_where('new_year_pools',array(
                'type' => 'EOS',
            ))
            ->row_array();
        //ZG奖池
        $zg_pool =$this->zg_activity_db->select('amount,user_total_support_amount,backstage_total_support_amount')
            ->order_by('id desc')
            ->get_where('new_year_pools',array(
                'type' => 'ZG',
            ))
            ->row_array();
        $activity_info = $this->zg_activity_db->select('state,activity_start_time,activity_end_time')->get_where('new_year_activities')->row_array();
        $data['start_time'] =@$activity_info['activity_start_time'];
        $data['end_time'] =@$activity_info['activity_end_time'];
        $data['state'] =@$activity_info['state'];
        $data['eos_pool'] =$eos_pool;
        $data['zg_pool'] =$zg_pool;
        return $data;
    }

    public function change_pool_balance($activity_id,$pool_type,$balance){
        if($activity_id){
            $this->zg_activity_db->where('activity_id',$activity_id);
        }
        $res =$this->zg_activity_db->get_where('new_year_pools',array('type'=>$pool_type))->row_array();
        if(!$res || $res['amount'] + $balance < 0){
            return false;
        }
        if($activity_id){
            $this->zg_activity_db->where('activity_id',$activity_id);
        }

        $this->zg_activity_db->trans_begin();
        $this->zg_activity_db->set('backstage_total_support_amount', 'backstage_total_support_amount+'.$balance, FALSE);
        $this->zg_activity_db->set('amount', 'amount+'.$balance, FALSE);
        $this->zg_activity_db->where('type',$pool_type)->update('new_year_pools');
        $pool_info =$this->zg_activity_db->get_where('new_year_pools',array('type'=>$pool_type))->row_array();
        $activity_id = @$pool_info['activity_id'];
        $time = (string)date('Y-m-d H:i:s',time());
        $business = 'admin';
        $detail ="后台调整";
        $sql = "insert into `new_year_pool_logs` (created_at,updated_at,activity_id,asset,business,`change`,balance,detail) select '".$time."','".$time."',".$activity_id.",'".$pool_type."','".$business."',".$balance.", "."case when max(balance) IS NULL THEN 0 +".$balance." else ( select
        balance + '". $balance ."'  from new_year_pool_logs where activity_id = ".$activity_id ." AND asset = '".$pool_type."' ORDER BY id DESC LIMIT 1 ) END balance".",'".$detail."' from new_year_pool_logs where activity_id = ".$activity_id ." AND asset = '".$pool_type."' ORDER BY id DESC LIMIT 1";
        $this->zg_activity_db->query($sql);
        if ($this->zg_activity_db->trans_status() === false) {
            $this->zg_activity_db->trans_rollback();
            return false;
        } else {
            $this->zg_activity_db->trans_commit();
            return true;
        }
    }

    public function insertNewYearActivity($activity_name,$start_time,$end_time,$site_id){
        $activity['activity_start_time'] = $activity_name;
        $activity['activity_end_time'] = $start_time;
        $activity['state'] = $this::NewYearWaitingStart;
        $activity['activity_name'] = $end_time;
        $activity['created_at'] = date('Y-m-d H:i:s',time());
        $activity['updated_at'] = date('Y-m-d H:i:s',time());
        return $this->zg_activity_db->insert('new_year_activities',$activity);
    }

}