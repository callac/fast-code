<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_assets_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_user_withdraw_model');
        $this->load->model('Zjys_user_withdraw_freezes_model');    
        $this->load->model('Zjys_assets_model');    
        $this->load->model('Site_model');    
    }   

    //币资产种类
    public function asset_list($offset,$limit,$asset_code,$start_time,$end_time,$site_id){
        $object = $this->db->select("assets.*,b_site.name")
            ->join('b_site','b_site.id=assets.site_id','left')
            ->from('assets');
        if($site_id!='') $object =$this->db->where('assets.site_id = ',$site_id);
        if(!empty($asset_code)){
            $object =$this->db->where('assets.asset_code =',$asset_code);
        }
        if(!empty($start_time)){
            $object =$this->db->where('assets.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('assets.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        // var_dump($list);die;
        foreach ($list as &$value) {
            # code...
            if($value['recharge_status'] == 1){
                $value['recharge_status'] = '1';
            }else{
                $value['recharge_status'] = '0';
            }
            if($value['withdraw_status'] == 1){
                $value['withdraw_status'] = '1';
            }else{
                $value['withdraw_status'] = '0';
            }
            if($value['trade_status'] == 1){
                $value['trade_status'] = '1';
            }else{
                $value['trade_status'] = '0';
            }
        }
        return $list;
    }


    public function system_asset_list($offset,$limit,$asset_code,$start_time,$end_time){
        $object = $this->db->select("total_assets.*")
            ->from('total_assets');
        if(!empty($asset_code)){
            $object =$this->db->where('total_assets.asset_code =',$asset_code);
        }
        if(!empty($start_time)){
            $object =$this->db->where('total_assets.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('total_assets.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        // var_dump($list);die;
        foreach ($list as &$value) {
            # code...
            if($value['recharge_status'] == 1){
                $value['recharge_status'] = '1';
            }else{
                $value['recharge_status'] = '0';
            }
            if($value['withdraw_status'] == 1){
                $value['withdraw_status'] = '1';
            }else{
                $value['withdraw_status'] = '0';
            }
            if($value['trade_status'] == 1){
                $value['trade_status'] = '1';
            }else{
                $value['trade_status'] = '0';
            }
        }
        return $list;
    }

    public function system_asset_list_count($asset_code,$start_time,$end_time){
        $object = $this->db->select("total_assets.*")
            ->from('total_assets');
        if(!empty($asset_code)){
            $object =$this->db->where('total_assets.asset_code =',$asset_code);
        }
        if(!empty($start_time)){
            $object =$this->db->where('total_assets.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('total_assets.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }


    //
    public function asset_list_totalsite($offset,$limit,$asset_code,$start_time,$end_time,$site_id){
        // var_dump($site_id);die;
        if($this->config->item('SITE')==='priv_one'){
            $object = $this->db->select("asset_code,recharge_status,withdraw_status,trade_status,is_exclusive")
            ->from('assets');
            $object = $this->db->where('assets.site_id =',$site_id);
            if(!empty($asset_code)){
                $object =$this->db->where('assets.asset_code =',$asset_code);
            }
            if(!empty($start_time)){
                $object =$this->db->where('assets.created_at >=',$start_time);
            }
            if(!empty($end_time)){
                $object =$this->db->where('assets.created_at <',$end_time);
            }
            $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
            // var_dump($list);die;
            foreach ($list as &$value) {
                # code...
                if($value['recharge_status'] == 1){
                    $value['recharge_status'] = 1;
                }else{
                    $value['recharge_status'] = 0;
                }
                if($value['withdraw_status'] == 1){
                    $value['withdraw_status'] = 1;
                }else{
                    $value['withdraw_status'] = 0;
                }
                if($value['trade_status'] == 1){
                    $value['trade_status'] = 1;
                }else{
                    $value['trade_status'] = 0;
                }
            }
            return $list;
        }else{
            $object = $this->db->select("asset_code,recharge_status,withdraw_status,trade_status,is_exclusive")
            ->from('total_assets');
            if(!empty($asset_code)){
                $object =$this->db->where('total_assets.asset_code =',$asset_code);
            }

            if(!empty($site_id)){
                $object =$this->db->where('total_assets.sub_true = 0 and is_exclusive=0');
                $object =$this->db->or_where('total_assets.sub_true =',1);
                $object =$this->db->or_where('total_assets.sub_true = 0 and is_exclusive=',$site_id);
                
            }

            if(!empty($start_time)){
                $object =$this->db->where('total_assets.created_at >=',$start_time);
            }
            if(!empty($end_time)){
                $object =$this->db->where('total_assets.created_at <',$end_time);
            }
            $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
            // var_dump($this->db->last_query());die;
            foreach ($list as &$value) {
                # code...
                if($value['recharge_status'] == 1){
                    $value['recharge_status'] = 1;
                }else{
                    $value['recharge_status'] = 0;
                }
                if($value['withdraw_status'] == 1){
                    $value['withdraw_status'] = 1;
                }else{
                    $value['withdraw_status'] = 0;
                }
                if($value['trade_status'] == 1){
                    $value['trade_status'] = 1;
                }else{
                    $value['trade_status'] = 0;
                }
            }
            return $list;
        }
    }


    //
    public function asset_list_count($asset_code,$start_time,$end_time,$site_id){
        $object = $this->db->select("assets.*,b_site.name")
            ->join('b_site','b_site.id=assets.site_id','left')
            ->from('assets');
        if($site_id!='') $object =$this->db->where('assets.site_id = ',$site_id);
        if(!empty($asset_code)){
            $object =$this->db->where('assets.asset_code =',$asset_code);
        }
        if(!empty($start_time)){
            $object =$this->db->where('assets.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('assets.created_at <',$end_time);
        }
        return $this->db->count_all_results();
        return $list;
    }



    //添加、编辑币种类
    public function add_asset($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $asset_code = isset($args['asset_code']) ? $args['asset_code']: '';//资产码
        $asset_name = isset($args['asset_name']) ? $args['asset_name']: '';//资产名称
        $recharge_status = isset($args['recharge_status']) ? $args['recharge_status']: '';
        $withdraw_status = isset($args['withdraw_status']) ? $args['withdraw_status']: '';
        $trade_status = isset($args['trade_status']) ? $args['trade_status']: '';
        $withdraw_fee = isset($args['withdraw_fee']) ? $args['withdraw_fee']: '';
        $withdraw_min = isset($args['withdraw_min']) ? $args['withdraw_min']: '';
        $withdraw_max = isset($args['withdraw_max']) ? $args['withdraw_max']: '';
        $recharge_verify = isset($args['recharge_verify']) ? $args['recharge_verify']: '';
        $precision = isset($args['precision']) ? $args['precision']: 8; //精度（小数点后8位）
        $site_id = isset($args['site_id']) ? $args['site_id']: 1; //不传默认为1，总站
        $has_memo = isset($args['has_memo']) ? $args['has_memo']: 0; 

        $is_display = isset($args['is_display']) ? $args['is_display']: 1; //是否前台显示
        $min_amount = isset($args['min_amount']) ? $args['min_amount']: '0'; 
        $min_confirmation = isset($args['min_confirmation']) ? $args['min_confirmation']: 0; 
        $withdraw_verify_amount = isset($args['withdraw_verify_amount']) ? $args['withdraw_verify_amount']: 0; 
        
        if($this->config->item('SITE') === 'priv_one') $site_id = 1;
        // var_dump($site_id);die;
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());
        if(!$id){
            //新增
            $result = $this->Zjys_assets_model->add_asset($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$created_at,$updated_at,$withdraw_min,$withdraw_max,$is_display,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount);
            return true;
        }else{
            //修改总站币资产dd_asset
            // echo 111;die;
            $this->db->trans_begin();
            $this->Zjys_assets_model->edit_asset($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$site_id,$updated_at,$id,$withdraw_min,$withdraw_max,$is_display,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount);
            if($this->config->item('SITE') === 'priv_one'){
                $this->Zjys_assets_model->correct_symbols_basename($asset_code,$asset_name);
                $this->Zjys_assets_model->correct_symbols_quotename($asset_code,$asset_name);
            }
            // $this->Zjys_assets_model->correct_total_symbols($asset_code,$asset_name);

            if ($this->db->trans_status() === false) {
                $this->db->trans_rollback();
                return false;
            } else {
                $this->db->trans_commit();
                return true;
            }
        }
    }


    //添加、编辑币种类
    public function system_asset_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $asset_code = isset($args['asset_code']) ? trim($args['asset_code']) : '';//资产码
        $asset_name = isset($args['asset_name']) ? $args['asset_name']: '';//资产名称
        // var_dump($asset_name);die;s
        $recharge_status = isset($args['recharge_status']) ? $args['recharge_status']: '';
        $withdraw_status = isset($args['withdraw_status']) ? $args['withdraw_status']: '';
        $trade_status = isset($args['trade_status']) ? $args['trade_status']: '';
        $withdraw_fee = isset($args['withdraw_fee']) ? $args['withdraw_fee']: '';
        $withdraw_min = isset($args['withdraw_min']) ? $args['withdraw_min']: '';
        $withdraw_max = isset($args['withdraw_max']) ? $args['withdraw_max']: '';
        $recharge_verify = isset($args['recharge_verify']) ? $args['recharge_verify']: '';
        $precision = isset($args['precision']) ? $args['precision']: 8; //精度（小数点后8位）
        $sub_true = isset($args['sub_true']) ? $args['sub_true']: 0;
        $is_exclusive = isset($args['is_exclusive']) ? $args['is_exclusive']: 0;
        $has_memo = isset($args['has_memo']) ? $args['has_memo']: 0;
        $regex = isset($args['regex']) ? $args['regex']: ''; //地址正则
        $warning_status = isset($args['warning_status']) ? $args['warning_status']: ''; //警示状态
        $withdraw_fee_percent = isset($args['withdraw_fee_percent']) ? $args['withdraw_fee_percent']: 0; //提币手续费百分比

        $min_amount = isset($args['min_amount']) ? $args['min_amount']: '0'; 
        $min_confirmation = isset($args['min_confirmation']) ? $args['min_confirmation']: 0; 
        $withdraw_verify_amount = isset($args['withdraw_verify_amount']) ? $args['withdraw_verify_amount']: 0; 

        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());
        
        $this->db->trans_begin();
        $site_all = $this->Site_model->site_all();
        if(!$id){
            $is_true = $this->Zjys_assets_model->get_sys_asset_detail($asset_code);
            if(is_array($is_true) && !empty($is_true)) returnJson('402','该币种已经存在');
            if($sub_true == 1){ //子站默认
                $result = $this->Zjys_assets_model->system_asset_add($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$created_at,$updated_at,$withdraw_min,$withdraw_max,0,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                
                foreach ($site_all as $key => $value) {
                    $result = $this->Zjys_assets_model->add_asset_by_system($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$value['id'],$created_at,$updated_at,$withdraw_min,$withdraw_max,$sub_true,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                }
            }else{
                if($is_exclusive == 1){ //子站专属
                    $site_id = trim($args['site_id']); 
                    if(empty($site_id)) returnJson('402','请选择站点');
                    $is_true = $this->Site_model->site_one($site_id); 
                    if(is_array($is_true) && empty($is_true)) returnJson('402','无该站点');

                    $result = $this->Zjys_assets_model->system_asset_add($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$created_at,$updated_at,$withdraw_min,$withdraw_max,$site_id,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                }else{
                    $result = $this->Zjys_assets_model->system_asset_add($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$created_at,$updated_at,$withdraw_min,$withdraw_max,0,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                }
            }
        }else{
            $detail = $this->Zjys_assets_model->get_system_asset_detail_byid($id);
            if($detail['sub_true'] ==1){ //如果初始的状态是非默认，想改成已默认
                if($sub_true == 1){
                    $this->Zjys_assets_model->system_asset_edit($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,0,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);

                    foreach ($site_all as $key => $value) {
                        $this->Zjys_assets_model->asset_delete($value['id'],$detail['asset_code']);
                    }
                    foreach ($site_all as $key => $value) {
                        $result = $this->Zjys_assets_model->add_asset_by_system($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$value['id'],$created_at,$updated_at,$withdraw_min,$withdraw_max,$sub_true,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                    }
                }else{
                    foreach ($site_all as $key => $value) {
                        $this->Zjys_assets_model->system_asset_edit($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,0,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                    }
                    foreach ($site_all as $key => $value) {
                        $this->Zjys_assets_model->asset_delete($value['id'],$detail['asset_code']);
                    }
                    if($is_exclusive == 1){
                        $site_id = trim($args['site_id']); 
                        if(empty($site_id)) returnJson('402','请选择站点');
                        $is_true = $this->Site_model->site_one($site_id); 
                        if(is_array($is_true) && empty($is_true)) returnJson('402','无该站点');

                        $this->Zjys_assets_model->system_asset_edit($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,$site_id,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                    }else{
                        $this->Zjys_assets_model->system_asset_edit($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,0,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                    }
                }
            }else{
                if($sub_true == 1){
                    $this->Zjys_assets_model->system_asset_edit($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,0,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                    foreach ($site_all as $key => $value) {
                        $result = $this->Zjys_assets_model->add_asset_by_system($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$value['id'],$created_at,$updated_at,$withdraw_min,$withdraw_max,$sub_true,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                    }
                }else{
                    if($is_exclusive == 1){
                        $site_id = trim($args['site_id']); 
                        if(empty($site_id)) returnJson('402','请选择站点');
                        $is_true = $this->Site_model->site_one($site_id); 
                        if(is_array($is_true) && empty($is_true)) returnJson('402','无该站点');

                        $this->Zjys_assets_model->system_asset_edit($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,$site_id,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                    }else{
                        $this->Zjys_assets_model->system_asset_edit($asset_code,$asset_name,$recharge_status,$withdraw_status,$trade_status,$withdraw_fee,$precision,$sub_true,$updated_at,$id,$withdraw_min,$withdraw_max,0,$has_memo,$recharge_verify,$min_amount,$min_confirmation,$withdraw_verify_amount,$regex,$warning_status,$withdraw_fee_percent);
                    }
                }
            }
            //修改各个表的base_asset_name
            $this->Zjys_assets_model->correct_assets($asset_code,$asset_name);
            $this->Zjys_assets_model->correct_assets_withdraw_verify_amount($asset_code,$withdraw_verify_amount);
            $this->Zjys_assets_model->correct_assets_regex($asset_code,$regex);
            $this->Zjys_assets_model->correct_assets_fee_percent($asset_code,$withdraw_fee_percent);
            $this->Zjys_assets_model->correct_assets_min_confirmation($asset_code,$min_confirmation);
            $this->Zjys_assets_model->correct_total_symbols($asset_code,$asset_name);
            $this->Zjys_assets_model->correct_symbols($asset_code,$asset_name);
            $this->Zjys_assets_model->correct_assets_has_memo($asset_code,$has_memo);
            $this->Zjys_assets_model->correct_assets_precision($asset_code,$precision);


            /**
             * 修改该编辑后的状态
             */
            $data = array();
            $data['status'] = 0;
            $updated_at = date("Y-m-d H:i:s",time());
            $data['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $record_id =  $this->db->update('total_assets', $data);
        }

        if ($this->db->trans_status() === false) {
                $this->db->trans_rollback();
                return false;
            } else {
                $this->db->trans_commit();


//            if(!empty($result))
//                $business_id = $result;
//            var_dump($business_id);die();
//            $user_id = '';
//            $time = date('Y-m-d H:i:s',time());
//            $business = '26'; //o
//            $description = '币资产提交';
//            admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);
                return true;
            }
    }


    public function list_all($site_id){
        return $this->Zjys_assets_model->list_all($site_id);
    }


    public function list_all_alarm(){
        return $this->Zjys_assets_model->list_all_alarm();
    }

    public function asset_intro_list($offset,$limit,$asset_code)
    {
        $object = $this->db->select("asset_intros.*")
            ->where('deleted_at is null')
            ->from('asset_intros');
        if(!empty($asset_code)){
            $object =$this->db->where('asset_intros.asset_code =',$asset_code);
        }
        return $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
    }

    public function asset_intro_list_count($asset_code)
    {
        $object = $this->db->select("asset_intros.*")
            ->where('deleted_at is null')
            ->from('asset_intros');
        if(!empty($asset_code)){
            $object =$this->db->where('asset_intros.asset_code =',$asset_code);
        }
        return $this->db->count_all_results();
    }


    public function asset_intro_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        // $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $asset_code = isset($args['asset_code']) ? $args['asset_code']: '';
        $icon = isset($args['icon']) ? $args['icon']: '';
        $desc = isset($args['desc']) ? $args['desc']: '';
        $full_name = isset($args['full_name']) ? $args['full_name']: '';
        $official_website = isset($args['official_website']) ? $args['official_website']: '';
        $white_paper = isset($args['white_paper']) ? $args['white_paper']: '';
        $block_query = isset($args['block_query']) ? $args['block_query']: '';
        $founding_team = isset($args['founding_team']) ? $args['founding_team']: '';
        $erc = isset($args['erc']) ? $args['erc']: '';
        $recommend_organization = isset($args['recommend_organization']) ? $args['recommend_organization']: '';
        $release_time = isset($args['release_time']) ? $args['release_time']: '';
        $release_total = isset($args['release_total']) ? $args['release_total']: '';
        $circulation_total = isset($args['circulation_total']) ? $args['circulation_total']: '';
        $detail = isset($args['detail']) ? $args['detail']: '';
        $three_url = isset($args['three_url']) ? $args['three_url']: '';
        $three_icon = isset($args['three_icon']) ? $args['three_icon']: '';
        $lang = isset($args['lang']) ? $args['lang']: 'zh-hans';
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Zjys_assets_model->add_assetintros($asset_code,$icon,$desc,$full_name,$official_website,$white_paper,$block_query,$founding_team,$recommend_organization,$release_time,$release_total,$circulation_total,$detail,$created_at,$updated_at,$erc,$lang,$three_url,$three_icon);
        }else{
            //修改
            $this->Zjys_assets_model->edit_assetintros($asset_code,$icon,$desc,$full_name,$official_website,$white_paper,$block_query,$founding_team,$recommend_organization,$release_time,$release_total,$circulation_total,$detail,$updated_at,$id,$erc,$lang,$three_url,$three_icon);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }

    public function asset_intro_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Zjys_assets_model->asset_intro_delete($id,$time);
    }


    public function get_systemassets(){
        return $this->Zjys_assets_model->get_systemassets();
    }


    /**
     * Notes: 系统资产审核
     * User: 张哲
     * Date: 2019-07-22
     * Time: 15:26
     * @param $args
     */
    public function systemAssetAddVerity($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $type = isset($args['type']) ? $args['type']: '';
        $object = $this->db->select("total_assets.*")
            ->from('total_assets');
        $object =$this->db->where('total_assets.id =',$id);
        $list1 = $object->order_by('id','desc')->get()->result_array();
        if(empty($list1)) returnJson('402','没有该记录');


        if($type == 0){
            $id = isset($args['id']) ? $args['id']: '';
            $data = array();
            $data['status'] = 2;
            $data['remark'] = $args['remark'];
            $updated_at = date("Y-m-d H:i:s",time());
            $data['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $record_id =  $this->db->update('total_assets', $data);
        }else{
            $id = isset($args['id']) ? $args['id']: '';
            $data = array();
            $data['status'] = 1;
            $data['remark'] = $args['remark'];
            $updated_at = date("Y-m-d H:i:s",time());
            $data['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $record_id =  $this->db->update('total_assets', $data);
        }




        if(!empty($record_id))
            $business_id = $id;
        $user_id = '';
        $time = date('Y-m-d H:i:s',time());
        $business = '27'; //o
        $description = '币资产审核';
        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);
    }

    /**
     * Notes: 币资产日志
     * User: 张哲
     * Date: 2019-07-23
     * Time: 17:34
     * @param $args
     */
    public function systemAssetDetailsLogs($args)
    {
        $id = isset($args['id']) ? $args['id'] : '';

        //先查看是否有次用户
        $object = $this->db->select("admin_operation_logs.*")
            ->from('admin_operation_logs');
        $object = $this->db->where('admin_operation_logs.business_id=', $id);
        $names = array('26', '27');
        $object = $this->db->where_in('admin_operation_logs.operation_type', $names);
        $list = $object->order_by('id', 'desc')->get()->result_array();
        return $list;

    }


}
