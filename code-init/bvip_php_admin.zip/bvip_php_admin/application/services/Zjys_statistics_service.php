<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Zjys_statistics_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Config_model');
        $this->load->model('Zjys_symbols_model'); 
        $this->load->model('Zjys_user_model');
        $this->load->model('User_truename_valid_model');
        $this->load->model('Transfer_model');

    }   

    /**
     * 去重数据列表
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function asset_list($offset,$limit,$start_time,$end_time,$site_id){
        $object = $this->db->select("perday_data_statistics.*")
        ->from('perday_data_statistics');
        if($site_id!='') $object =$this->db->where('perday_data_statistics.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('perday_data_statistics.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_data_statistics.created_at <=',$end_time);
        }
       
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();

        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        }  
        return $list;
    }

    /**
     * 去重数据列表条数统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function asset_list_count($start_time,$end_time,$site_id){
        $object = $this->db->select("perday_data_statistics.*")
        ->from('perday_data_statistics');             
       
        if($site_id!='') $object =$this->db->where('perday_data_statistics.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('perday_data_statistics.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_data_statistics.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }


    //新增资产统计列表详细
    public function newaddasset_list($offset,$limit,$start_time,$end_time,$symbol)
    {
        // var_dump($start_time,$end_time);die;
        $object = $this->db->select("newaddasset.*")
        ->from('newaddasset');
        if(!empty($start_time)){
            $object =$this->db->where('newaddasset.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('newaddasset.time_area <=',$end_time);
        }

        if(!empty($symbol)){
            $object =$this->db->where('newaddasset.asset =',$symbol);
        }

        $list = $object->limit($limit,$offset)->order_by('time_area','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        // print_r($list);die;
        return $list;
    }

    //新增资产统计表累计
    public function newaddasset_list_total($offset,$limit,$start_time,$end_time,$symbol)
    {
        $default_time_end = date('Y-m-d',$_SERVER['REQUEST_TIME']);
        $default_time_start = date('Y-m-d',$_SERVER['REQUEST_TIME']-7*86400);

        $object = $this->db->select("newaddasset.*")
        ->from('newaddasset');
        if(!empty($start_time)){
            $object =$this->db->where('newaddasset.time_area >=',$start_time);
        }else{
            $object =$this->db->where('newaddasset.time_area >=',$default_time_start);
        }
        if(!empty($end_time)){
            $object =$this->db->where('newaddasset.time_area <',$end_time);
        }else{
            $object =$this->db->where('newaddasset.time_area <',$default_time_end);
        }

        if(!empty($symbol)){
            $object =$this->db->where('newaddasset.asset =',$symbol);
        }
        //获取指定时间段下的所有记录
        $list = $object->get()->result_array();
        //获取此段时间内的币种
        $allAsset = [];
        foreach ($list as $key => $value) {
            array_push($allAsset, $value['asset']);
        }

        // var_dump($list);die;

        $allAssetUnique = array_values(array_unique($allAsset));

        $new = array();
        for ($i=0; $i < count($allAssetUnique); $i++) { 
            $new[$i]['recharge_people_total'] = 0;
            $new[$i]['trade_people_total'] = 0;
            $new[$i]['chibi_people_total'] = 0;
            $new[$i]['asset_createtime'] = '';

            foreach ($list as $k => $v) {
                if($allAsset[$i] == $v['asset']){
                    $new[$i]['recharge_people_total'] += $v['recharge_people'];
                    $new[$i]['trade_people_total'] += $v['trade_people'];
                    $new[$i]['chibi_people_total'] += $v['chibi_people'];
                    $new[$i]['asset_createtime']  = $v['asset_createtime'];
                }
                if(!empty($start_time) && !empty($end_time)){
                    $new[$i]['time_area']  = $start_time.'--'.$end_time;
                }else{
                    $new[$i]['time_area']  = $default_time_start.'--'.$default_time_end;
                }
            }

            $new[$i]['asset']  = $allAssetUnique[$i];
            // print_r($new);die;
        }
        // var_dump($this->db->last_query());die;
        $data['list'] = array_slice($new,$offset,$limit);
        $data['total'] = count($new);
        $data['totalPage'] = ceil($data['total']/$limit);
        $data['pageSize'] = $limit;
        return $data;
    }

    public function newaddasset_list_count($start_time,$end_time,$symbol)
    {
        $object = $this->db->select("newaddasset.*")
        ->from('newaddasset');
        if(!empty($start_time)){
            $object =$this->db->where('newaddasset.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('newaddasset.time_area <=',$end_time);
        }

        if(!empty($symbol)){
            $object =$this->db->where('newaddasset.asset =',$symbol);
        }

        return $this->db->count_all_results();
    }


    /**
     * 去重数据导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function quchong($start_time,$end_time,$site_id){
    	 $object = $this->db->select("perday_data_statistics.*")
        ->from('perday_data_statistics');
        if($site_id!='') $object =$this->db->where('perday_data_statistics.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('perday_data_statistics.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_data_statistics.created_at <=',$end_time);
        }
       
        $list = $object->order_by('created_at','desc')->get()->result_array();
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        }  
        return $list;
    }


    /**
     * 注册数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function register_list($offset,$limit,$start_time,$end_time,$site_id){
        $object = $this->db->select("perday_register_statistics.*")
        ->from('perday_register_statistics');
        if($site_id!='') $object =$this->db->where('perday_register_statistics.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('perday_register_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_register_statistics.time_area <',$end_time);
        }
       
        $list = $object->limit($limit,$offset)->order_by('time_area','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        }  
        return $list;
    }

    /**
     * 注册数据条数统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function register_list_count($start_time,$end_time,$site_id){
        $object = $this->db->select("perday_register_statistics.*")
        ->from('perday_register_statistics');             
       
        if($site_id!='') $object =$this->db->where('perday_register_statistics.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('perday_register_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_register_statistics.time_area <',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * 注册数据导出列表
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function register_csv($start_time,$end_time,$site_id){
    	 $object = $this->db->select("perday_register_statistics.*")
        ->from('perday_register_statistics');
        if($site_id!='') $object =$this->db->where('perday_register_statistics.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('perday_register_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_register_statistics.time_area <',$end_time);
        }
       
        $list = $object->order_by('time_area','desc')->get()->result_array(); 
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        	if(!empty($site_name['name'])){
            	$val['site_name'] = $site_name['name']; 
        	}    
        } 
        return $list;
    }


    /**
     * 充值数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     */
    public function recharge_list($offset,$limit,$start_time,$end_time,$site_id,$asset1){

        $object = $this->db->select("perday_recharge_statistics.*")
        ->from('perday_recharge_statistics');
        if($site_id!='') $object =$this->db->where('perday_recharge_statistics.site_id = ',$site_id);
       if($asset1!='') $object =$this->db->where('perday_recharge_statistics.asset_code = ',$asset1);
        if(!empty($start_time)){
            $object =$this->db->where('perday_recharge_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_recharge_statistics.time_area <',$end_time);
        }
       
        $list = $object->limit($limit,$offset)->order_by('time_area','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name']; 
            }    
        }  
        return $list;
    }

    /**
     * 充值数据列表条数统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function recharge_list_count($start_time,$end_time,$site_id,$asset){
        $object = $this->db->select("perday_recharge_statistics.*")
        ->from('perday_recharge_statistics');             
       
        if($site_id!='') $object =$this->db->where('perday_recharge_statistics.site_id = ',$site_id);
        if($asset!='') $object =$this->db->where('perday_recharge_statistics.asset_code = ',$asset);

        if(!empty($start_time)){
            $object =$this->db->where('perday_recharge_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_recharge_statistics.time_area <',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * 充值数据列表导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function recharge_csv($start_time,$end_time,$site_id,$asset){
    	 $object = $this->db->select("perday_recharge_statistics.*")
        ->from('perday_recharge_statistics');
        if($site_id!='') $object =$this->db->where('perday_recharge_statistics.site_id = ',$site_id);
        if($asset!='') $object =$this->db->where('perday_recharge_statistics.symbols = ',$asset);

        if(!empty($start_time)){
            $object =$this->db->where('perday_recharge_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_recharge_statistics.time_area <',$end_time);
        }
       
        $list = $object->order_by('time_area','desc')->get()->result_array(); 
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        } 
        return $list;
    }

    /**
     * 提现数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function withdraws_list($offset,$limit,$start_time,$end_time,$site_id,$asset){
        $object = $this->db->select("perday_withdraw_statistics.*")
        ->from('perday_withdraw_statistics');
        if($site_id!='') $object =$this->db->where('perday_withdraw_statistics.site_id = ',$site_id);
        if($asset!='') $object =$this->db->where('perday_withdraw_statistics.symbols = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('perday_withdraw_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_withdraw_statistics.time_area <',$end_time);
        }
       
        $list = $object->limit($limit,$offset)->order_by('time_area','desc')->get()->result_array();
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        }  
        return $list;
    }

    /**
     * 提现数据列表条数统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function withdraws_list_count($start_time,$end_time,$site_id,$asset){
        $object = $this->db->select("perday_withdraw_statistics.*")
        ->from('perday_withdraw_statistics');             
       
        if($site_id!='') $object =$this->db->where('perday_withdraw_statistics.site_id = ',$site_id);
        if($asset!='') $object =$this->db->where('perday_withdraw_statistics.symbols = ',$asset);

        if(!empty($start_time)){
            $object =$this->db->where('perday_withdraw_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_withdraw_statistics.time_area <',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * 提现数据列表导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function withdraws_csv($start_time,$end_time,$site_id,$asset){
    	 $object = $this->db->select("perday_withdraw_statistics.*")
        ->from('perday_withdraw_statistics');
        if($site_id!='') $object =$this->db->where('perday_withdraw_statistics.site_id = ',$site_id);
        if($asset!='') $object =$this->db->where('perday_withdraw_statistics.symbols = ',$asset);

        if(!empty($start_time)){
            $object =$this->db->where('perday_withdraw_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_withdraw_statistics.time_area <',$end_time);
        }
       
        $list = $object->order_by('time_area','desc')->get()->result_array(); 
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        } 
        return $list;
    }


    /**
     * 法币买入数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function c2cbuy_list($offset,$limit,$start_time,$end_time,$site_id){
        $object = $this->db->select("perday_c2cbuy_statistics.*")
        ->from('perday_c2cbuy_statistics');
        if($site_id!='') $object =$this->db->where('perday_c2cbuy_statistics.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('perday_c2cbuy_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_c2cbuy_statistics.time_area <',$end_time);
        }
       
        $list = $object->limit($limit,$offset)->order_by('time_area','desc')->get()->result_array();
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        }  
        return $list;
    }

    /**
     * 法币买入数据列表条数统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function c2cbuy_list_count($start_time,$end_time,$site_id){
        $object = $this->db->select("perday_c2cbuy_statistics.*")
        ->from('perday_c2cbuy_statistics');             
       
        if($site_id!='') $object =$this->db->where('perday_c2cbuy_statistics.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('perday_c2cbuy_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_c2cbuy_statistics.time_area <',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * 法币买入数据列表导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function c2cbuy_csv($start_time,$end_time,$site_id){
    	 $object = $this->db->select("perday_c2cbuy_statistics.*")
        ->from('perday_c2cbuy_statistics');
        if($site_id!='') $object =$this->db->where('perday_c2cbuy_statistics.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('perday_c2cbuy_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_c2cbuy_statistics.time_area <',$end_time);
        }
       
        $list = $object->order_by('time_area','desc')->get()->result_array(); 
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        } 
        return $list;
    }

    /**
     * 法币卖出数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function c2csell_list($offset,$limit,$start_time,$end_time,$site_id){
        $object = $this->db->select("perday_c2csell_statistics.*")
        ->from('perday_c2csell_statistics');
        if($site_id!='') $object =$this->db->where('perday_c2csell_statistics.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('perday_c2csell_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_c2csell_statistics.time_area <',$end_time);
        }
       
        $list = $object->limit($limit,$offset)->order_by('time_area','desc')->get()->result_array();
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        }  
        return $list;
    }

    /**
     * 法币卖出数据列表条数统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function c2csell_list_count($start_time,$end_time,$site_id){
        $object = $this->db->select("perday_c2csell_statistics.*")
        ->from('perday_c2csell_statistics');             
       
        if($site_id!='') $object =$this->db->where('perday_c2csell_statistics.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('perday_c2csell_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_c2csell_statistics.time_area <',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * 法币买入数据列表导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function c2csell_csv($start_time,$end_time,$site_id){
    	 $object = $this->db->select("perday_c2csell_statistics.*")
        ->from('perday_c2csell_statistics');
        if($site_id!='') $object =$this->db->where('perday_c2csell_statistics.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('perday_c2csell_statistics.time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_c2csell_statistics.time_area <',$end_time);
        }
       
        $list = $object->order_by('time_area','desc')->get()->result_array(); 
        foreach ($list as &$val){
        $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        if(!empty($site_name['name'])){
            $val['site_name'] = $site_name['name']; 
        }    
        } 
        return $list;
    }

    /**
     * 插入数据表
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $tongji_type [description]
     * @param    [type]       $url         [description]
     * @param    [type]       $created_at  [description]
     * @return   [type]                    [description]
     */
    public function csvlogs($tongji_type,$url,$created_at){
        $this->Config_model->csvlogs_add($tongji_type,$url,$created_at);
    }
    //币币交易
    public function cointrade_list($offset,$limit,$start_time,$end_time,$site_id,$symbols)
    {
        $object = $this->db->select("perday_coin_trade_statistics.*,b_site.name as site_name")
        ->join('b_site','b_site.id=perday_coin_trade_statistics.site_id','left')
        ->from('perday_coin_trade_statistics');
        if($site_id!='') $object =$this->db->where('site_id = ',$site_id);
        if($symbols!='') $object =$this->db->where('perday_coin_trade_statistics.symbols = ',$symbols);

        if(!empty($start_time)){
            $object =$this->db->where('time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('time_area <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('time_area','desc')->get()->result_array();

        $trade_history_snap = $this->load->database('trade_history_snap',true);
        foreach ($list as &$value) {
            $timestamp = strtotime($value['time'])+86400;
            $sql = "show tables like 'order_history_$timestamp'";
            if(! $trade_history_snap->query($sql)->result_array()){
                $value['price'] = 0;
            }else{
                $sql = "select price from order_history_$timestamp where market='".$value['symbols']."' order by id desc limit 1";
                $value['price'] = $trade_history_snap->query($sql)->row_array()['price'];
            }
        }
        return $list;
    }


    public function cointrade_list_count($start_time,$end_time,$site_id,$symbols)
    {
        $object = $this->db->select("perday_coin_trade_statistics.*")
        ->join('b_site','b_site.id=perday_coin_trade_statistics.site_id','left')
        ->from('perday_coin_trade_statistics');
        if($site_id!='') $object =$this->db->where('site_id = ',$site_id);
        if($symbols!='') $object =$this->db->where('perday_coin_trade_statistics.symbols = ',$symbols);
        if(!empty($start_time)){
            $object =$this->db->where('time_area >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('time_area <',$end_time);
        }
       
        return $this->db->count_all_results();
    }
    //
    public function trade_detail($market,$time,$offset,$limit,$user_id)
    {
        //取每日成交记录快照数据，获得最佳性能
        $db_tradelog = $this->load->database('trade_log',true);
        $time = '2019-03-20';
        $time = strtotime($time);
        if($user_id !== '')
            $where = ' and user_id=".$user_id."';
        else{
            $where = ' and 1=1';
        }

        $sql = "select user_id,sum(deal_money) deal_money,market from order_history_$time where market='".$market."' group by user_id";
        $list = $db_tradelog->query($sql)->result_array();

        $sql = "select user_id,sum(deal_money) deal_money,market from order_history_$time where market='".$market."'";
        $list1 = $db_tradelog->query($sql)->row_array();
        var_dump($list1);die;


    }

    public function deal_history($args)
    {
        $table_index = $args['user_id'] % 100;
        $where = ' where user_id='.$args['user_id'];
        if(!empty($args['ltime'])) $where .= ' and time>='.$args['ltime'];
        if(!empty($args['rtime'])) $where .= ' and time<'.$args['rtime'];
        if(!empty($args['market'])) $where .= ' and market='.$args['market'];
        if(!empty($args['side'])) $where .= ' and side='.$args['side']; //1、ask 卖出 2、BID买入

        $DB1 = $this->load->database('trade_history',true);

        $sql = 'SELECT FROM_UNIXTIME(time,"%Y-%m-%d %H:%i:%s") as `time`,user_id,market,side,price,amount,deal,fee,deal_fee from user_deal_history_'.$table_index.$where.' order by id desc';
        return object_to_array($DB1->query($sql)->result());
    }

    public function order_history($args)
    {
        
    } 
    //指定用户，指定时间登录ip
    public function login_ip($args)
    {

    }

    /**
     * Notes: 持币列表
     * User: 张哲
     * Date: 2018/12/7
     * Time: 14:05
     */
    public function hold_coin_list($offset,$limit,$hold_coin_time,$end_time,$asset,$user_id){

        if(empty($hold_coin_time)){
            $hold_coin_time = date('Y-m-d H:i:s', time());
        }
        if(empty($asset)){
            $asset = 'ZT';
        }

        //三天前的时间替换为0点数据
        $holdtime = strtotime($hold_coin_time);
        $threetime = time() - 86400 * 3;
        if($holdtime < $threetime){
            $hold_coin_time =  substr($hold_coin_time, 0, 10);
            $hold_coin_time = $hold_coin_time .' '. "00:00:00";

            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);

            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);

            // var_dump($hold_coin_time,$timestamp);die();
            $DB1 = $this->load->database('snapshot', true);
            //先取用户及其币种数组

            if(!empty($asset) && empty($user_id)){
                $sql = "select sum(balance) as balance,user_id,asset from slice_balance_" . $timestamp . " where asset = '$asset' group by user_id order by balance desc limit $offset,$limit";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else  if(!empty($user_id)  && empty($asset)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " where user_id = '$user_id' group by asset order by balance desc limit $offset,$limit";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else if(!empty($user_id) && !empty($user_id)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . "  where user_id = '$user_id' and asset = '$asset' order by balance desc limit $offset,$limit";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else{

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " group by user_id,asset order by balance desc limit $offset,$limit";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }
        }else{
            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);
            $DB1 = $this->load->database('trade_log', true);
            //先取用户及其币种数组
            if(!empty($asset) && empty($user_id)){
                $sql = "select sum(balance) as balance,user_id,asset from slice_balance_" . $timestamp . " where asset = '$asset' group by user_id order by balance desc limit $offset,$limit";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else  if(!empty($user_id)  && empty($asset)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " where user_id = '$user_id' group by asset order by balance desc limit $offset,$limit";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else if(!empty($user_id) && !empty($user_id)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . "  where user_id = '$user_id' and asset = '$asset' order by balance desc limit $offset,$limit";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else{

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " group by user_id,asset  order by balance desc  limit $offset,$limit";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }
        }
        if(!empty($new[0]['user_id'])) {
            foreach ($new as &$val) {

                $site_id = $this->Zjys_user_model->check_site_id($val['user_id']);
                if(empty($site_id)) $site_id['site_id'] = 1;
                $site_name = $this->Zjys_symbols_model->get_symbols_name($site_id['site_id']);
                if (!empty($site_name['name'])) {
                    $val['site_name'] = $site_name['name'];
                }
                //实名
                $true_name = $this->User_truename_valid_model->true_name($val['user_id']);
                if (!empty($true_name['name'])) {
                    $val['name'] = $true_name['name'];
                }

                $val['amount'] = $val['balance'];
                $val['created_at'] = $new_time;

            }
        }else{
            $new = array();
        }
       // $new = array_slice($new,$offset,$limit);
        return $new;
    }

    /**
     * Notes: 持币条数
     * User: 张哲
     * Date: 2018/12/7
     * Time: 14:05
     */
    public function hold_coin_list_count($hold_coin_time,$end_time,$asset,$user_id){
        if(empty($hold_coin_time)){
            $hold_coin_time = date('Y-m-d H:i:s', time());
        }
        if(empty($asset)){
            $asset = 'ZT';
        }
        //三天前的时间替换为0点数据
        $holdtime = strtotime($hold_coin_time);
        $threetime = time() - 86400 * 3;
        if($holdtime < $threetime){
            $hold_coin_time =  substr($hold_coin_time, 0, 10);
            $hold_coin_time = $hold_coin_time .' '. "00:00:00";

            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);

            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);

            // var_dump($hold_coin_time,$timestamp);die();
            $DB1 = $this->load->database('snapshot', true);
            //先取用户及其币种数组

            if(!empty($asset) && empty($user_id)){
                $sql = "select sum(balance) as balance,user_id,asset from slice_balance_" . $timestamp . " where asset = '$asset' group by user_id order by balance desc ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else  if(!empty($user_id)  && empty($asset)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " where user_id = '$user_id' group by asset order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else if(!empty($user_id) && !empty($user_id)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . "  where user_id = '$user_id' and asset = '$asset' order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else{

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " group by user_id,asset order by balance desc ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }
        }else{
            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);

            // var_dump($hold_coin_time,$timestamp);die();
            $DB1 = $this->load->database('trade_log', true);
            //先取用户及其币种数组

            if(!empty($asset) && empty($user_id)){
                $sql = "select sum(balance) as balance,user_id,asset from slice_balance_" . $timestamp . " where asset = '$asset' group by user_id order by balance desc ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else  if(!empty($user_id)  && empty($asset)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " where user_id = '$user_id' group by asset order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else if(!empty($user_id) && !empty($user_id)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . "  where user_id = '$user_id' and asset = '$asset' order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else{

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " group by user_id,asset order by balance desc ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }
        }

        return count($new);
    }


    /**
     * Notes: 持币导出
     * User: 张哲
     * Date: 2019-08-01
     * Time: 10:12
     */
    public function hold_coin_csv($hold_coin_time,$end_time,$asset,$user_id){
        if(empty($hold_coin_time)){
            $hold_coin_time = date('Y-m-d H:i:s', time());
        }
        if(empty($asset)){
            $asset = 'ZT';
        }

        //三天前的时间替换为0点数据
        $holdtime = strtotime($hold_coin_time);
        $threetime = time() - 86400 * 3;
        if($holdtime < $threetime){
            $hold_coin_time =  substr($hold_coin_time, 0, 10);
            $hold_coin_time = $hold_coin_time .' '. "00:00:00";

            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);

            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);

            // var_dump($hold_coin_time,$timestamp);die();
            $DB1 = $this->load->database('snapshot', true);
            //先取用户及其币种数组

            if(!empty($asset) && empty($user_id)){
                $sql = "select sum(balance) as balance,user_id,asset from slice_balance_" . $timestamp . " where asset = '$asset' group by user_id order by balance desc ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else  if(!empty($user_id)  && empty($asset)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " where user_id = '$user_id' group by asset order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else if(!empty($user_id) && !empty($user_id)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . "  where user_id = '$user_id' and asset = '$asset' order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else{

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " group by user_id,asset order by balance desc ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }
        }else{
            $sub = substr($hold_coin_time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);
            $DB1 = $this->load->database('trade_log', true);
            //先取用户及其币种数组
            if(!empty($asset) && empty($user_id)){
                $sql = "select sum(balance) as balance,user_id,asset from slice_balance_" . $timestamp . " where asset = '$asset' group by user_id order by balance desc ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else  if(!empty($user_id)  && empty($asset)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " where user_id = '$user_id' group by asset order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else if(!empty($user_id) && !empty($user_id)){

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . "  where user_id = '$user_id' and asset = '$asset' order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }else{

                //$sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " ";
                $sql = "select sum(balance) as balance,user_id,asset  from slice_balance_" . $timestamp . " group by user_id,asset order by balance desc ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
            }
        }
        if(!empty($new[0]['user_id'])) {
            foreach ($new as &$val) {

//                $site_id = $this->Zjys_user_model->check_site_id($val['user_id']);
//                if(empty($site_id)) $site_id['site_id'] = 1;
//                $site_name = $this->Zjys_symbols_model->get_symbols_name($site_id['site_id']);
//                if (!empty($site_name['name'])) {
//                    $val['site_name'] = $site_name['name'];
//                }else{
//                    $val['site_name'] = '';
//                }
//                //实名
//                $true_name = $this->User_truename_valid_model->true_name($val['user_id']);
//                if (!empty($true_name['name'])) {
//                    $val['name'] = $true_name['name'];
//                }else{
//                    $val['name'] = '';
//                }

                $val['amount'] = $val['balance'];
                $val['created_at'] = $new_time;

            }
        }else{
            $new = array();
        }

        return $new;
    }

    /**
     * Notes: 交易对币价
     * User: 张哲
     * Date: 2019-05-07
     * Time: 11:28
     */
    public function symbols_price_list($offset,$limit,$start_time,$end_time,$symbols){
        $object = $this->db->select("*")
            ->from('symbols_price');
        if(!empty($symbols)){
            $object = $this->db->where('symbols_price.symbols =', $symbols);
        }
        if(!empty($start_time)){
            $object =$this->db->where('symbols_price.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('symbols_price.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
       return $list;
    }

    /**
     * Notes: 交易对币价数量
     * User: 张哲
     * Date: 2019-05-07
     * Time: 11:28
     */
    public function symbols_price_list_count($start_time,$end_time,$symbols){
        $object = $this->db->select("*")
            ->from('symbols_price');
        if(!empty($symbols)){
            $object = $this->db->where('symbols_price.symbols =', $symbols);
        }
        if(!empty($start_time)){
            $object =$this->db->where('symbols_price.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('symbols_price.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 交易对币价-导出
     * User: 张哲
     * Date: 2019-05-07
     * Time: 14:07
     */
    public function symbols_price_csv($start_time,$end_time,$symbols){
        $object = $this->db->select("*")
            ->from('symbols_price');
        if(!empty($symbols)){
            $object = $this->db->where('symbols_price.symbols =', $symbols);
        }
        if(!empty($start_time)){
            $object =$this->db->where('symbols_price.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('symbols_price.created_at <=',$end_time);
        }

        $list = $object->order_by('created_at','desc')->get()->result_array();
        return $list;
    }
    /**
     * Notes: 持币导出
     * User: 张哲
     * Date: 2018/12/7
     * Time: 14:16
     */

    
    //获取上级
    public function get_top_id($uid){
        return $this->Zjys_user_model->get_top_id($uid);
    }

    //指定用户求出下级、下下级用户的交易额 new
    public function get_user_recommend_statistic()
    {
        $DB1 = $this->load->database('trade_history',true);
        $DB2 = $this->load->database('default',true);
        //邀请信息
        $sql2 = 'select recommend_user_id,user_id from user_recommends where status=1 and deleted_at is null';
        $list = $DB2->query($sql2)->result_array();
        $recommends = array();
        foreach ($list as $val){
            $recommends[$val['recommend_user_id']] = $val['user_id'];
        }

        //获取货币装换CNT汇率
        $result = $this->db->select('asset_code')
            ->group_by('asset_code')
            ->get_where('assets')
            ->result_array();
        $symbol = [];
        foreach ($result as $val){
            $c2c_asset = $this->config->item('C2C_ASSET');
            $market =$val['asset_code'].'_'.$c2c_asset;
            if($val['asset_code']  == $c2c_asset){
                $symbol[$market] = 1;
            }else{
                $symbol[$market] = get_market_last($market);
            }
        }
        //用户信息
        $sql3 = "select  a.`id`,a.`email`,a.`phone`,GROUP_CONCAT(b.recommend_user_id) as str_recommend  FROM users AS a LEFT JOIN user_recommends AS b ON a.id = b.user_id GROUP BY a.id ";
        $users = $DB2->query($sql3)->result_array();
        foreach ($users as &$user){
            $two_str_recommend = array();
            if($user['str_recommend']){
                $res =$DB2->select('GROUP_CONCAT(recommend_user_id) as str_rec')->group_by('user_id')->where_in('user_id',explode(',',$user['str_recommend']))->get('user_recommends')->result_array();
                foreach ($res as $r){
                    $two_str_recommend = array_merge($two_str_recommend,explode(',',$r['str_rec']));
                }
                $user['two_str_recommend'] = implode(',',$two_str_recommend);
            }else{
                $user['two_str_recommend'] = '';
            }
        }
        foreach ($users as &$info){
            //上级id
            if(in_array($info['id'], array_keys($recommends))){
                $info['top_user_id'] = (string)$recommends[$info['id']];
            }else{
                $info['top_user_id'] = '0';
            }

            //上上级id
            if(in_array($info['top_user_id'], array_keys($recommends))){
                $info['top_two_user_id'] = (string)$recommends[$info['top_user_id']];
            }else{
                $info['top_two_user_id'] = '0';
            }

            //计算一级邀请用户交易额 CNZ
            if($info['str_recommend']){
                $arr_recommend = explode(',',$info['str_recommend']);
                $info['recommend_count'] =count($arr_recommend);
                $info['arr_recommend_count'] =$arr_recommend;
            }else{
                $info['recommend_count'] =0;
                $info['arr_recommend_count'] =array();
            }
            $deal = 0;
            if($info['recommend_count'] >0){
                foreach ( $info['arr_recommend_count'] as $recommend){
                    $sql = "select user_id,sum(deal) as trade_total,market from user_deal_history_? where  user_id = ?";
                    $res = $DB1->query($sql,array(intval($recommend)%100,intval($recommend)))->result_array();
                    foreach ($res as $val){
                        if(isset($symbol[$val['market']])){
                            $deal += $symbol[$val['market']]*$val['trade_total'];
                        }else{
                            continue;
                        }
                    }
                }
            }
            $info['deal'] =$deal;


            //计算二级邀请用户交易额 CNZ
            $two_deal = 0;
            if($info['two_str_recommend']){
                $arr_recommend = explode(',',$info['two_str_recommend']);
                $info['two_recommend_count'] =count($arr_recommend);
                $info['two_arr_recommend_count'] =$arr_recommend;
            }else{
                $info['two_recommend_count'] =0;
                $info['two_arr_recommend_count'] =array();
            }
            unset($info['two_str_recommend'],$info['str_recommend']);
            if($info['two_recommend_count'] >0){
                foreach ( $info['two_arr_recommend_count'] as $recommend){
                    $sql = "select user_id,sum(deal) as trade_total,market from user_deal_history_? where  user_id = ?";
                    $res = $DB1->query($sql,array(intval($recommend)%100,intval($recommend)))->result_array();
                    foreach ($res as $val){
                        if(isset($symbol[$val['market']])){
                            $two_deal += $symbol[$val['market']]*$val['trade_total'];
                        }else{
                            continue;
                        }
                    }
                }
            }
            $info['two_deal'] =$two_deal;
            unset($info['arr_recommend_count'],$info['two_arr_recommend_count'],$info['two_str_recommend'],$info['str_recommend']);
        }
        $csvpath = APPPATH.'cache/excel';//per_user_trade'.date('Y-m-d',time()).'.csv'
        if (is_dir($csvpath) == false) {mkdir($csvpath, 0777);}
        $csvpath =  $csvpath.'/per_user_trade-'.date('Y-m-d',time()).'.csv';
        $fp = fopen( $csvpath, 'w' );
        $title = array('用户ID','邮箱', '手机号', '上级ID','上上级ID','一级好友邀请人数','邀请一级好友交易总金额(CNY)','二级邀请好友人数','邀请二级好友交易总金额(CNY)');
        foreach($title as $key => $item) {
            $title[$key] = iconv('UTF-8', 'GB2312//IGNORE', $item);
        }
        fputcsv($fp, $title);

        $limit = 10000;
        $num = 0; //计数器
        foreach ( $users as $v ) {
            $num++;
            if($num == $limit){
                ob_flush();         //释放内存
                flush();
            }
            foreach ( $v as $kk => $vv){
                $rs[$kk] = iconv('utf-8', 'GB2312//IGNORE', $vv);  //转译编码
            }
            fputcsv($fp, $rs);
        }
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $url = $oss->uploadCsvFile($filePath,'.csv',true);
        $this->db->insert('csv_logs',array(
            'tongji_type' => ZJYS_DOWN_ACCOUNT_TYPE,
            'url' => $url,
            'created_at' => date('Y-m-d H:i:s',time())
        ));
    }



    public function platform_fee($args)
    {
        //获取站点
        $site_id = $args['site_id'];
        $stime = isset($args['start_time']) ? $args['start_time'] : "";
        $etime = isset($args['end_time']) ? $args['end_time'] : "";

        //获取交易区
        $jyq = $args['jyq'];
        $result = array();
        //获取卖出手续
        for($i=0;$i<count($jyq);$i++)
        {
            $sql = "select sum(ASK_fee) as fee from perday_coin_trade_statistics 
                    where 1=1
                    and site_id=$site_id
                    and symbols like '%_$jyq[$i]'";

            if($stime !='' && $etime !='')
            {
                $sql = $sql." and time>='".$stime."' and time<='".$etime."'";
            }
            elseif($stime !='' && $etime ='')
            {
                $sql = $sql." and time>='".$stime."'";
            }
            elseif($etime !='' && $stime ='')
            {
                $sql = $sql." and time<='".$etime."'";
            }
            
            $ASK_fee[$jyq[$i]] = array_column($this->db->query($sql)->result_array(), 'fee');

            $sql = "select base_asset,symbol from symbols where site_id=$site_id and symbol like '%_$jyq[$i]'";
            
            $symbolList = $this->db->query($sql)->result_array();

            // var_dump($symbolList);
            
            foreach ($symbolList as $key => $value) {
                $sql = "select sum(BID_fee) as fee from perday_coin_trade_statistics 
                    where 1=1
                    and site_id=$site_id
                    and symbols like '".$value['base_asset']."_".$jyq[$i]."'";

                if($stime !='' && $etime !='')
                {
                    $sql = $sql." and time>='".$stime."' and time<='".$etime."'";
                }
                elseif($stime !='' && $etime ='')
                {
                    $sql = $sql." and time>='".$stime."'";
                }
                elseif($etime !='' && $stime ='')
                {
                    $sql = $sql." and time<='".$etime."'";
                }
                $BID_fee[$jyq[$i].'交易区'][$value['symbol']] = array_column($this->db->query($sql)->result_array(),'fee');
            }
        }
        // var_dump($ASK_fee);
        // var_dump($BID_fee);die;
        //提币手续费
        $sql = "select B.`name`,A.site_id,A.asset,sum(A.fee) as fee from user_withdraws A
                LEFT JOIN b_site B on A.site_id=B.id
                where 1=1
                and A.site_id=$site_id
                and A.wallet_status='DONE'
                GROUP BY A.asset,A.site_id
                ORDER BY site_id";

        if($stime !='' && $etime !='')
        {
            $sql = "select B.`name`,A.site_id,A.asset,sum(A.fee) as fee from user_withdraws A
                LEFT JOIN b_site B on A.site_id=B.id
                where 1=1
                and A.site_id=$site_id
                and A.wallet_status='DONE'
                and A.process_time>='".$stime."'
                and A.process_time<='".$etime."'
                GROUP BY A.asset,A.site_id
                ORDER BY site_id";
        }
        elseif($stime !='' && $etime ='')
        {
            $sql = "select B.`name`,A.site_id,A.asset,sum(A.fee) as fee from user_withdraws A
                LEFT JOIN b_site B on A.site_id=B.id
                where 1=1
                and A.site_id=$site_id
                and A.wallet_status='DONE'
                and A.process_time>='".$stime."'
                GROUP BY A.asset,A.site_id
                ORDER BY site_id";

        }
        elseif($etime !='' && $stime ='')
        {
            $sql = "select B.`name`,A.site_id,A.asset,sum(A.fee) as fee from user_withdraws A
                LEFT JOIN b_site B on A.site_id=B.id
                where 1=1
                and A.site_id=$site_id
                and A.wallet_status='DONE'
                and A.process_time<='".$etime."'
                GROUP BY A.asset,A.site_id
                ORDER BY site_id";
        }
        
        $withdraw_fee = $this->db->query($sql)->result_array();
        $result['ASK_FEE'] = $ASK_fee;
        $result['BID_FEE'] = $BID_fee;
        $result['WITHDRAW_FEE'] = $withdraw_fee;

        return $result;
    }
    
    //币种交易概况
    public function asset_general($args)
    {
        $asset = $args['asset'];
        $start_time = $args['end_time'];
        $end_time = date('Y-m-d',strtotime($start_time)+86400);

        $db_exchange = $this->load->database('default',true);
        $db_tradehistory = $this->load->database('trade_history',true);
        $db_tradelog = $this->load->database('trade_log',true);

        $bid_amount_result = $this->bid_amount($start_time,$end_time,$asset,$db_tradehistory);
        $ask_amount_result = $this->ask_amount($start_time,$end_time,$asset,$db_tradehistory);
        $recharge_result = $this->asset_recharge($start_time,$end_time,$asset,$db_exchange);
        $withdraw_result = $this->asset_withdraw($start_time,$end_time,$asset,$db_exchange);

        $new = array();
        if(count($ask_amount_result)>0){
            foreach ($bid_amount_result as $k => $v) {
                array_push($new,$v['user_id']);
            }
        }
        
        if(count($ask_amount_result)>0){
            foreach ($ask_amount_result as $kk => $vv) {
                array_push($new,$vv['user_id']);
            }
        }

        if(count($recharge_result)>0){
            foreach ($recharge_result as $kk => $vv) {
                array_push($new,$vv['user_id']);
            }
        }

        if(count($withdraw_result)>0){
            foreach ($withdraw_result as $kk => $vv) {
                array_push($new,$vv['user_id']);
            }
        }

        $new = array_values(array_unique($new));
        // var_dump($new);
        if(count($new)==0) returnJson('403','no data return');

        $new1 = array();

        foreach ($new as $a) {
            $new1[]['user_id'] = $a;
        }

        if(count($bid_amount_result)>0){
            foreach ($new1 as $k => $v) {
                foreach ($bid_amount_result as $kk => $vv) {
                    $result1[$k]['user_id'] = $v['user_id'];
                    if($v['user_id'] == $vv['user_id']){
                        $result1[$k]['bid_amount'] = $vv['bid_amount'];
                        break;
                    }else{
                        $result1[$k]['bid_amount'] = 0;
                    }
                }
            }
        }else{
            foreach ($new1 as $key => $value) {
                $result1[$key]['user_id'] = $value['user_id'];
                $result1[$key]['bid_amount'] = 0;
            }
        }

        if(count($ask_amount_result)>0){
            foreach ($result1 as $k => $v) {
                foreach ($ask_amount_result as $kk => $vv) {
                    $result2[$k]['user_id'] = $v['user_id'];
                    $result2[$k]['bid_amount'] = $v['bid_amount'];
                    if($vv['user_id'] == $v['user_id']){
                        $result2[$k]['ask_amount'] = $vv['ask_amount'];
                        break;
                    }else{
                        $result2[$k]['ask_amount'] = 0;
                    }
                }
            }
        }else{
            foreach ($result1 as $key => $value) {
                $result2[$key]['user_id'] = $value['user_id'];
                $result2[$key]['bid_amount'] = $value['bid_amount'];
                $result2[$key]['ask_amount'] = 0;
            }
        }

        if(count($recharge_result)>0){
            foreach ($result2 as $k => $v) {
                foreach ($recharge_result as $kk => $vv) {
                    $result3[$k]['user_id'] = $v['user_id'];
                    $result3[$k]['bid_amount'] = $v['bid_amount'];
                    $result3[$k]['ask_amount'] = $v['ask_amount'];
                    if($vv['user_id'] == $v['user_id']){
                        $result3[$k]['recharge_amount'] = $vv['amount'];
                        break;
                    }else{
                        $result3[$k]['recharge_amount'] = 0;
                    }
                }
            }
        }else{
            foreach ($result2 as $key => $value) {
                $result3[$key]['user_id'] = $value['user_id'];
                $result3[$key]['bid_amount'] = $value['bid_amount'];
                $result3[$key]['ask_amount'] = $value['ask_amount'];
                $result3[$key]['recharge_amount'] = 0;
            }
        }

        if(count($withdraw_result)>0){
            foreach ($result3 as $k => $v) {
                foreach ($withdraw_result as $kk => $vv) {
                    $result4[$k]['user_id'] = $v['user_id'];
                    $result4[$k]['bid_amount'] = $v['bid_amount'];
                    $result4[$k]['ask_amount'] = $v['ask_amount'];
                    $result4[$k]['reharge_amount'] = $v['recharge_amount'];
                    if($vv['user_id'] == $v['user_id']){
                        $result4[$k]['withdraw_amount'] = $vv['amount'];
                        break;
                    }else{
                        $result4[$k]['withdraw_amount'] = 0;
                    }
                }
            }
        }else{
            foreach ($result3 as $key => $value) {
                $result4[$key]['user_id'] = $value['user_id'];
                $result4[$key]['bid_amount'] = $value['bid_amount'];
                $result4[$key]['ask_amount'] = $value['ask_amount'];
                $result4[$key]['recharge_amount'] = $value['recharge_amount'];
                $result4[$key]['withdraw_amount'] = 0;
            }
        }
        return $result4;
    }

    function asset_recharge($start_time,$end_time,$asset,$db_exchange)
    {
        $sql = "select user_id,sum(amount) as amount from user_recharge_logs where status=1 and asset='".$asset."' and updated_at>='".$start_time."' and updated_at<'".$end_time."' group by user_id";
        $res = $db_exchange->query($sql)->result_array();
        return $res;
    }

    function asset_withdraw($start_time,$end_time,$asset,$db_exchange)
    {
        $sql = "select user_id,sum(amount) as amount from user_withdraws where status=3 and asset='".$asset."' and arrive_time>='".$start_time."' and arrive_time<'".$end_time."' group by user_id";
        $res = $db_exchange->query($sql)->result_array();
        return $res;
    }

    function bid_amount($start_time,$end_time,$asset,$db_tradehistory)
    {
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        for ($i=0; $i <100 ; $i++) { 
            $sql = "select user_id,sum(amount) as bid_amount from user_deal_history_$i 
                where time>=$start_time and time<$end_time and side=2 and market= '".$asset."_CNT' group by user_id";
                // var_dump($sql);die;
            $object = $db_tradehistory->query($sql)->result_array();
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        return $new;
    }


    function ask_amount($start_time,$end_time,$asset,$db_tradehistory)
    {
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        for ($i=0; $i <100 ; $i++) { 
            $sql = "select user_id,sum(amount) as ask_amount from user_deal_history_$i 
                where time>=$start_time and time<$end_time and side=1 and market= '".$asset."_CNT' group by user_id";
                // var_dump($sql);die;
            $object = $db_tradehistory->query($sql)->result_array();
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        return $new;
    }


    public function asset_general_form($args)
    {
        $asset = $args['asset'];
        $start_time = $args['end_time'];
        $end_time = date('Y-m-d',strtotime($start_time)+86400);

        $db_exchange = $this->load->database('default',true);
        $db_tradehistory = $this->load->database('trade_history',true);
        $db_tradelog = $this->load->database('trade_log',true);

        $trade_amount = $this->trade_amount($start_time,$end_time,$asset,$db_tradehistory);
        $recharge_form_result = $this->asset_recharge_form($start_time,$end_time,$asset,$db_exchange);
        $withdraw_form_result = $this->asset_withdraw_form($start_time,$end_time,$asset,$db_exchange);

        $result[]['trade_amount'] = $trade_amount;
        $result[]['recharge_amount'] = $recharge_form_result;
        $result[]['withdraw_amount'] = $withdraw_form_result;
        return $result;
    }

    function trade_amount($start_time,$end_time,$asset,$db_tradehistory)
    {

        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        for ($i=0; $i <100 ; $i++) { 
            $sql = "select sum(amount) as trade_amount from user_deal_history_$i 
                where time>=$start_time and time<$end_time and market= '".$asset."_CNZ'";
            $object = $db_tradehistory->query($sql)->result_array();


            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }

        if(count($new)>0){
            $aa['amount'] = 0;
            foreach ($new as $key => $value) {
                $aa['amount'] += $value['trade_amount'];
            }
            return $aa['amount'];
        }else{
            return 0;
        }
    }

    function asset_recharge_form($start_time,$end_time,$asset,$db_exchange)
    {
        $sql = "select sum(amount) as amount from user_recharge_logs where status=1 and asset='".$asset."' and updated_at>='".$start_time."' and updated_at<'".$end_time."'";
        $res = $db_exchange->query($sql)->row_array();
        if($res['amount']!==NULL){
            return $res['amount'];
        }else{
            return 0;
        }
    }

    function asset_withdraw_form($start_time,$end_time,$asset,$db_exchange)
    {
        $sql = "select sum(amount) as amount from user_withdraws where wallet_status='DONE' and asset='".$asset."' and arrive_time>='".$start_time."' and arrive_time<'".$end_time."'";
        $res = $db_exchange->query($sql)->row_array();
        if($res['amount']!==NULL){
            return $res['amount'];
        }else{
            return 0;
        }
    }


    /**
     * Notes: 获取交易总额
     * User: 张哲
     * Date: 2019-07-31
     * Time: 16:37
     */
    public function tradeAmount($offset,$limit,$start_time,$end_time,$site_id)
    {
        $object = $this->db->select("perday_trade_money.*")
            ->from('perday_trade_money');



        if(!empty($site_id)){
            $object =$this->db->where('perday_trade_money.site_id = ',$site_id);
        }
        if(!empty($start_time)){
            $object =$this->db->where('perday_trade_money.time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_trade_money.time <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('time','desc')->get()->result_array();
        foreach ($list as &$val) {
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if (!empty($site_name['name'])) {
                $val['site_name'] = $site_name['name'];
            }

            $val['time'] = substr($val['time'], 0, 10);
        }
        return $list;
    }

    public function tradeAmountCount($start_time,$end_time,$site_id){
        $object = $this->db->select("perday_trade_money.*")
            ->from('perday_trade_money');
        if(!empty($site_id)){
            $object =$this->db->where('perday_trade_money.site_id = ',$site_id);
        }


        if(!empty($start_time)){
            $object =$this->db->where('perday_trade_money.time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_trade_money.time <',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * Notes: 交易区明细
     * User: 张哲
     * Date: 2019-07-31
     * Time: 16:16
     */
    public function tradeZoneDetails($start_time,$end_time,$site_id)
    {
        $data = array();
        $arr = array();
        $arr1 = array();
        $asset_arr = array('CNT','ETH','BTC','USDT');

        foreach ($asset_arr as $key => $val){
            $trade_zone = $this->Transfer_model->trade_zone_details($start_time,$end_time,$site_id,$val);
            $real_trade_zone = $this->Transfer_model->real_trade_zone_details($start_time,$end_time,$site_id,$val);
            $number = 0;
            $trading_amount = 0;
            $real_number = 0;
            $real_trading_amount = 0;
            foreach ($trade_zone as $key1 => $val1){
                    $symbol_last =  substr($val1['symbols'],strripos($val1['symbols'],"_")+1); //后
                    // $symbol_fir =  substr($val['symbols'],0,strripos($val['symbols'],"_")); //前
                    if($symbol_last != 'CNT') {
                        $symbol1 = $symbol_last . '_' . 'CNT';
                        $time = $val1['time'];
                        $time = strtotime($time) + 86400;
                        $time = date("Y-m-d H:i:s", $time);
                        $time1 = strtotime($time) + 96400;
                        $time2 = date("Y-m-d H:i:s", $time1);
                        $object = $this->db->select("symbols_price.*")
                            ->from('symbols_price');
                        $object = $this->db->where('symbols_price.symbols = ', $symbol1);
                        $object = $this->db->where('symbols_price.created_at > ', $time);
                        $object = $this->db->where('symbols_price.created_at < ', $time2);
                        $list1 = $object->get()->result_array();
                        if (empty($list1)) $list1[0]['price'] = 0;
                        $arr[$key1]['number'] = $val1['trading_amount'];
                        $arr[$key1]['trading_amount'] = $val1['trading_amount'] * $list1[0]['price'];
                    }else{
                        $arr[$key1]['number'] = $val1['trading_amount'];
                        $arr[$key1]['trading_amount'] = $val1['trading_amount'];
                    }

                $number +=  $arr[$key1]['number'] ;
                $trading_amount += $arr[$key1]['trading_amount'];
            }



            foreach ($real_trade_zone as $key2 => $val2){
                $symbol_last =  substr($val2['symbols'],strripos($val2['symbols'],"_")+1); //后
                // $symbol_fir =  substr($val['symbols'],0,strripos($val['symbols'],"_")); //前
                if($symbol_last != 'CNT') {
                    $symbol1 = $symbol_last . '_' . 'CNT';
                    $time = $val2['time'];
                    $time = strtotime($time) + 86400;
                    $time = date("Y-m-d H:i:s", $time);
                    $time1 = strtotime($time) + 96400;
                    $time2 = date("Y-m-d H:i:s", $time1);
                    $object = $this->db->select("symbols_price.*")
                        ->from('symbols_price');
                    $object = $this->db->where('symbols_price.symbols = ', $symbol1);
                    $object = $this->db->where('symbols_price.created_at > ', $time);
                    $object = $this->db->where('symbols_price.created_at < ', $time2);
                    $list1 = $object->get()->result_array();
                    if (empty($list1)) $list1[0]['price'] = 0;

                    $arr1[$key2]['number'] = $val2['trading_amount'];
                    $arr1[$key2]['trading_amount'] = $val2['trading_amount'] * $list1[0]['price'];
                }else{
                    $arr1[$key2]['number'] = $val2['trading_amount'];
                    $arr1[$key2]['trading_amount'] = $val2['trading_amount'];
                }

                $real_number +=  $arr1[$key2]['number'] ;
                $real_trading_amount += $arr1[$key2]['trading_amount'];
            }

//
//            if(empty($trade_zone['unit_price'])){
//                $trade_zone['unit_price'] = 0;
//                $trade_zone['trading_amount'] = 0;
//            }
//            if(empty($real_trade_zone['unit_price'])){
//                $real_trade_zone['unit_price'] = 0;
//                $real_trade_zone['trading_amount'] = 0;
//            }


            $data[$key]['time'] =substr($start_time, 0, 10);
            $data[$key]['symbol'] = $val;
            $data[$key]['number'] =  $number;
            $data[$key]['trading_amount'] = $trading_amount;
            $data[$key]['real_number'] = $real_number;
            $data[$key]['real_trading_amount'] = $real_trading_amount;
        }
        $data1['list'] = $data;
        //$data['list'] = array_slice($data,$offset,$limit);
        $data1['count'] = count($data);
        return $data1;
    }


    /**
     * Notes: 交易对明细
     * User: 张哲
     * Date: 2019-07-31
     * Time: 17:13
     */
    public function symbolDetails($offset,$limit,$start_time,$end_time,$site_id,$symbol){

        $data = array();
        $trade_zone = $this->Transfer_model->symbolDetails($start_time,$end_time,$site_id,$symbol);

       // $list = array_merge($trade_zone,$real_trade_zone);
        $list = $trade_zone;
      //  var_dump($trade_zone,$real_trade_zone,$list);die();

        foreach ($list as $key => $val){
            $data[$key]['symbols'] =$val['symbols'];
            $data[$key]['time'] = substr($val['time'], 0, 10);


            $symbol_last =  substr($val['symbols'],strripos($val['symbols'],"_")+1); //后
           // $symbol_fir =  substr($val['symbols'],0,strripos($val['symbols'],"_")); //前
            if($symbol_last != 'CNT'){
                $symbol1 = $symbol_last.'_'.'CNT';
                $time = $val['time'];
                $time = strtotime($time) + 86400;
                $time = date("Y-m-d H:i:s", $time);
                $time1 = strtotime($time) + 96400;
                $time2 = date("Y-m-d H:i:s", $time1);
                $object = $this->db->select("symbols_price.*")
                    ->from('symbols_price');
                $object =$this->db->where('symbols_price.symbols = ',$symbol1);
                $object =$this->db->where('symbols_price.created_at > ',$time);
                $object =$this->db->where('symbols_price.created_at < ',$time2);
                $list1 = $object->get()->result_array();
                if(empty($list1))   $list1[0]['price']= 0;

                $data[$key]['number'] = $val['unit_price'];
                $data[$key]['people'] = $val['people'];
                $data[$key]['trading_number'] = $val['trading_number'] ;
                $data[$key]['trading_amount'] = $val['trading_amount'] * $list1[0]['price'];
                $data[$key]['BID_fee'] = $val['BID_fee'];
                $data[$key]['ASK_fee'] = $val['ASK_fee'];
                $data[$key]['per_trading_amount'] = $val['per_trading_amount'];


                $real_trade_zone = $this->Transfer_model->realSymbolDetails($start_time,$end_time,$site_id,$val['symbols']);
                if(empty($real_trade_zone[0]['real_trading_number'])) $real_trade_zone[0]['real_trading_number'] = 0;
                if(empty($real_trade_zone[0]['real_unit_price'])) $real_trade_zone[0]['real_unit_price'] = 0;
                if(empty($real_trade_zone[0]['real_trading_amount'])) $real_trade_zone[0]['real_trading_amount'] = 0;
                $data[$key]['real_trading_number'] =$real_trade_zone[0]['real_unit_price'];
                $data[$key]['real_unit_price'] = $real_trade_zone[0]['real_trading_number'];
                $data[$key]['real_trading_amount'] = $real_trade_zone[0]['real_trading_amount'] * $list1[0]['price'];
            }else{
                $data[$key]['number'] = $val['unit_price'];
                $data[$key]['people'] = $val['people'];
                $data[$key]['trading_number'] = $val['trading_number'] ;
                $data[$key]['trading_amount'] = $val['trading_amount'] ;
                $data[$key]['BID_fee'] = $val['BID_fee'];
                $data[$key]['ASK_fee'] = $val['ASK_fee'];
                $data[$key]['per_trading_amount'] = $val['per_trading_amount'];


                $real_trade_zone = $this->Transfer_model->realSymbolDetails($start_time,$end_time,$site_id,$val['symbols']);
                if(empty($real_trade_zone[0]['real_trading_number'])) $real_trade_zone[0]['real_trading_number'] = 0;
                if(empty($real_trade_zone[0]['real_unit_price'])) $real_trade_zone[0]['real_unit_price'] = 0;
                if(empty($real_trade_zone[0]['real_trading_amount'])) $real_trade_zone[0]['real_trading_amount'] = 0;
                $data[$key]['real_trading_number'] =$real_trade_zone[0]['real_unit_price'];
                $data[$key]['real_unit_price'] = $real_trade_zone[0]['real_trading_number'];
                $data[$key]['real_trading_amount'] = $real_trade_zone[0]['real_trading_amount'] ;
            }

        }

        foreach ($data as &$value) {
            $time = $value['time'];
            $time = strtotime($time) + 86400;
            $time = date("Y-m-d H:i:s", $time);
            $time1 = strtotime($time) + 96400;
            $time2 = date("Y-m-d H:i:s", $time1);
            $object = $this->db->select("symbols_price.*")
                ->from('symbols_price');
            $object =$this->db->where('symbols_price.symbols = ',$value['symbols']);
            $object =$this->db->where('symbols_price.created_at > ',$time);
            $object =$this->db->where('symbols_price.created_at < ',$time2);
            $list1 = $object->get()->result_array();
            if(empty($list1)){
                $value['price'] = 0;
            }else{
                $value['price'] = round($list1[0]['price'],6);
            }



        }

        //$data1['list'] = $data;
        $data1['list'] = array_slice($data,$offset,$limit);
        $data1['count'] = count($data);
        return $data1;

    }
}
