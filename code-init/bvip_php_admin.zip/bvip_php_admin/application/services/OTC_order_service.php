<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/2/26
 * Time: 20:36
 */


/**
 * 资金管理-充值
 * @Author   张哲
 * @DateTime 2018-03-27
 * @createby SublimeText3
 * @version  1.0
 * @return   [return]
 */
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;


class OTC_order_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_user_withdraw_model');
        // $this->load->model('Zjys_user_withdraw_freezes_model');
        $this->load->model('Zjys_c2corder_model');
        $this->load->model('Zjys_user_operationmoney_model');
        $this->load->model('Zjys_merchantbank_model');
        $this->load->service('Zjys_user_service');
        $this->load->model('OTC_model');
        $this->load->model('Zjys_symbols_model');
        $this->load->model('Zjys_assets_model');
        $this->load->service('Sys_grpc_service');

    }

    //获取merchant_banks表中和管理员相关的卡号
    public function get_link_cardnumber($admin_id)
    {
        return $this->Merchant_account_model->get_link_cardnumber($admin_id);
    }

    /**
     * Notes:  OTC买入卖出列表
     * User: 张哲
     * Date: 2019/2/27
     * Time: 13:41
     */
    public function inout($offset,$limit,$type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchant_id){
        //查看当前管理员是否关联平台银行卡信息
        

//        $admin_link_cardnumber = $this->get_link_cardnumber($this->user_id);
//        $arr = array();
//        foreach ($admin_link_cardnumber as $key => $value) {
//            array_push($arr,$value['id']);
//        }
        $object = $this->db->select("otc_orders.*,users.realname as real_name,users.phone,users.email,users.id as uid,user_banks.card_number as user_card_number,user_banks.name,user_banks.pre_phone,user_banks.bank as user_bank,user_banks.sub_bank as user_sub_bank,merchant_account.card_number as merchanta_card_number,merchant_account.bank as merchant_bank,merchant_account.sub_bank as merchant_sub_bank,b_site.name as site_name,merchant_account.alipay_number,merchant_account.wechat_number,merchant_account.name as mer_name,merchant_account.id as mer_id,otc_user_account.account,otc_user_account.name,otc_user_account.image")
            ->from('otc_orders')
            // ->join('user_identities','user_identities.user_id=otc_orders.user_id','left')
            ->join('user_banks','user_banks.id=otc_orders.user_bank_id','left')
            ->join('otc_user_account','otc_user_account.id=otc_orders.user_bank_id','left')
            ->join('merchant_account','merchant_account.id=otc_orders.merchant_bank_id','left')
            ->join('b_site','b_site.id = otc_orders.site_id','left')
            ->join('users','users.id=otc_orders.user_id','left');
      //  $object =  $this->db->select('distinct(otc_orders.order_no)');
        $object =$this->db->where('otc_orders.type =',$type);

        // $object =$this->db->where('user_identities.deleted_at is null');


        if($site_id!='') $object =$this->db->where('otc_orders.site_id = ',$site_id);

        if(!empty($name)){ //按姓名查询
            $object =$this->db->where('users.realname =',$name);
        }

        $admin_id = $this->user_id;
//152、157 kocin;141、150 zt
        if(!empty($admin_id)){
            if($admin_id == 1 || $admin_id == 152 || $admin_id == 157 || $admin_id == 141 || $admin_id == 150 || $admin_id == 165 || $admin_id == 220) {
                $admin_id = "";
            }else{
                $admin_id  = $admin_id;
            }
        }
        if(!empty($admin_id)){
            $object =$this->db->where('merchant_account.admin_id =',$admin_id);
        }

        if(!empty($merchant_id)){ //商户id搜索
            $object =$this->db->where('merchant_account.id =',$merchant_id);
        }

        if(!empty($uid)){ //按用户id
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($useraccount)){ //按账户查询
            if(WSTIsPhone($useraccount)){
                $object =$this->db->where('users.phone = ',$useraccount);
            }else{
                $object =$this->db->where('users.email = ',$useraccount);
            }
        }

        if(!empty($status)){
            $object =$this->db->where('otc_orders.status =',$status);
        }
        if(!empty($order_no)){
            $object =$this->db->where('otc_orders.order_no =',$order_no);
        }
        if(!empty($start_time)){
            $object =$this->db->where('otc_orders.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('otc_orders.created_at <',$end_time);
        }

//        if(is_array($arr) && !empty($arr)){
//            $object = $this->db->where_in('otc_orders.merchant_bank_id',$arr);
//        }
        //1正序 2倒序

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();


        // var_dump($this->db->last_query());die;
        foreach ($list as &$value) {
            if($value['type'] == 2){
                if ($value['user_bank_id'] == 0){
                    if($value['pay_method'] == 0){
                        $test = $this->OTC_model->bank_card($value['user_id']);
                        if(!empty($test)){
                            $value['user_card_number'] = $test['card_number'].'/'.$test['bank'].'/'.$test['sub_bank'].'/'.$test['pre_phone'];
                        }

                    }else if($value['pay_method'] == 1){
                        $test = $this->OTC_model->other_card($value['user_id'],1);
                        if(!empty($test)){
                            $value['account'] = $test['account'].'/'.$test['name'];
                        }
                    }else{
                        $test = $this->OTC_model->other_card($value['user_id'],2);
                        if(!empty($test)){
                            $value['account'] = $test['account'].'/'.$test['name'];
                        }
                    }
                }else{
                    $value['user_card_number'] = $value['user_card_number'].'/'.$value['user_bank'].'/'.$value['user_sub_bank'].'/'.$value['pre_phone'];
                    $value['account'] = $value['account'].'/'.$value['name'];
                }

            }else{

                    $test = $this->OTC_model->bank_card1($value['user_id']);
                    if(!empty($test)){
                        $value['user_card_number'] = $test['card_number'].'/'.$test['bank'].'/'.$test['sub_bank'].'/'.$test['pre_phone'];
                    }
                    $test1 = $this->OTC_model->other_card($value['user_id'],1);
                    if(!empty($test1)){
                        $value['alipay_account'] = $test1['account'];
                    }else{
                        $value['alipay_account'] = '';
                    }
                    $test2 = $this->OTC_model->other_card($value['user_id'],2);
                    if(!empty($test2)){
                        $value['wechant_account'] = $test2['account'];
                    }else{
                        $value['wechant_account'] = '';
                    }
            }

//            if($type = 1){
//                if($value['status'] == 1){
//                    if($value['pay_method'] == 0){
//                        $value['pay_method'] = '银行卡';
//                        $value['merchanta_account'] = $value['mer_id'].'/'.$value['mer_name'].'/'.$value['merchant_bank'].'/'.$value['merchanta_card_number'];
//                        $value['user_account'] = '';
//                    }else if($value['pay_method'] == 1){
//                        $value['pay_method'] = '支付宝';
//                        $value['merchanta_account'] =  $value['mer_id'].'/'.$value['mer_name'].'/'.$value['alipay_number'];
//                        $value['user_account'] ='';
//                    }else if($value['pay_method'] == 2){
//                        $value['pay_method'] = '微信';
//                        $value['merchanta_account'] =  $value['mer_id'].'/'.$value['mer_name'].'/'.$value['alipay_number'];
//                        $value['user_account'] = '';
//                    }
//                }else{
//                    if($value['pay_method'] == 0){
//                        $value['pay_method'] = '银行卡';
//                        $value['merchanta_account'] = $value['mer_id'].'/'.$value['mer_name'].'/'.$value['merchant_bank'].'/'.$value['merchanta_card_number'];
//                        $value['user_account'] = $value['user_card_number'];
//                    }else if($value['pay_method'] == 1){
//                        $value['pay_method'] = '支付宝';
//                        $value['merchanta_account'] =  $value['mer_id'].'/'.$value['mer_name'].'/'.$value['alipay_number'];
//                        $value['user_account'] =$value['account'];
//                    }else if($value['pay_method'] == 2){
//                        $value['pay_method'] = '微信';
//                        $value['merchanta_account'] =  $value['mer_id'].'/'.$value['mer_name'].'/'.$value['wechat_number'];
//                        $value['user_account'] = $value['account'];
//                    }
//                }
//
//            }else  if($type = 2){
                if($value['pay_method'] == 0){
                    $value['pay_method'] = '银行卡';
                    $value['merchanta_account'] = $value['mer_id'].'/'.$value['mer_name'].'/'.$value['merchant_bank'].'/'.$value['merchanta_card_number'];
                    $value['user_account'] = $value['user_card_number'];
                }else if($value['pay_method'] == 1){
                    $value['pay_method'] = '支付宝';
                    $value['merchanta_account'] =  $value['mer_id'].'/'.$value['mer_name'].'/'.$value['alipay_number'];
                    $value['user_account'] =$value['account'];
                    $value['image'] = $this->get_image($value['image']);
                }else if($value['pay_method'] == 2){
                    $value['pay_method'] = '微信';
                    $value['merchanta_account'] =  $value['mer_id'].'/'.$value['mer_name'].'/'.$value['wechat_number'];
                    $value['user_account'] = $value['account'];
                    $value['image'] = $this->get_image($value['image']);
                }
            //}


            if($value['type'] == 1){
                $value['type'] = '买入';
            }else{
                $value['type'] = '卖出';
            }




            if ($value['status'] == 1) {
                $value['status_type'] = '未成交';
            }elseif ($value['status'] == 2){
                $value['status_type'] = '已支付';
            }elseif ($value['status'] == 3){
                $value['status_type'] = '已成功';
            }elseif ($value['status'] == 4){
                $value['status_type'] = '已取消';
            }elseif ($value['status'] == 5){
                $value['status_type'] = '处理中';
            }elseif ($value['status'] == 6){
                $value['status_type'] = '已过期';
            }elseif ($value['status'] == 7){
                $value['status_type'] = '已完成';
            }


//            if($type==1){
//                $value['card_number']=$this->get_user_bankcard($value['user_id']);
//                if ($value['status'] != 5) {
//                    $value['is_caiwu'] = $this->get_bank_flow($value['real_name'],$value['merchant_bank_id'],$type,1); //status=1:待处理状态
//                }else{
//                    $value['is_caiwu'] = $this->get_bank_flow($value['real_name'],$value['merchant_bank_id'],$type,7); //status=7:初次审核状态
//                }
//            }
        }


        return $list;
    }

    /**
     * Notes:  OTC买入卖出列表-条数
     * User: 张哲
     * Date: 2019/2/27
     * Time: 13:53
     */
    public function inout_count($type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchant_id){
        //查看当前管理员是否关联平台银行卡信息
//        $admin_link_cardnumber = $this->get_link_cardnumber($this->user_id);
//        $arr = array();
//        foreach ($admin_link_cardnumber as $key => $value) {
//            array_push($arr,$value['id']);
//        }
        $object = $this->db->select("otc_orders.*,users.realname as real_name,users.phone,users.email,users.id as uid,user_banks.card_number as user_card_number,user_banks.name,user_banks.pre_phone,user_banks.bank as user_bank,user_banks.sub_bank as user_sub_bank,merchant_account.card_number as merchanta_card_number,merchant_account.bank as merchant_bank,merchant_account.sub_bank as merchant_sub_bank,b_site.name as site_name,merchant_account.alipay_number,merchant_account.wechat_number,merchant_account.name as mer_name,merchant_account.id as mer_id,otc_user_account.account,otc_user_account.image")
            ->from('otc_orders')
            // ->join('user_identities','user_identities.user_id=otc_orders.user_id','left')
            ->join('user_banks','user_banks.id=otc_orders.user_bank_id','left')
            ->join('otc_user_account','otc_user_account.id=otc_orders.user_bank_id','left')
            ->join('merchant_account','merchant_account.id=otc_orders.merchant_bank_id','left')
            ->join('b_site','b_site.id = otc_orders.site_id','left')
            ->join('users','users.id=otc_orders.user_id','left');
        //  $object =  $this->db->select('distinct(otc_orders.order_no)');
        $object =$this->db->where('otc_orders.type =',$type);


        // $object =$this->db->where('user_identities.deleted_at is null');
        $object =$this->db->where('user_banks.deleted_at is null');


        if($site_id!='') $object =$this->db->where('otc_orders.site_id = ',$site_id);

        if(!empty($name)){ //按姓名查询
            $object =$this->db->where('users.realname =',$name);
        }
        if(!empty($merchant_id)){ //商户id搜索
            $object =$this->db->where('merchant_account.id =',$merchant_id);
        }

        $admin_id = $this->user_id;
        if(!empty($admin_id)){
            if($admin_id == 1 || $admin_id == 152 || $admin_id == 157 || $admin_id == 141 || $admin_id == 150 || $admin_id == 165 || $admin_id == 220) {
                $admin_id = "";
            }else{
                $admin_id  = $admin_id;
            }
        }
        if(!empty($admin_id)){
            $object =$this->db->where('merchant_account.admin_id =',$admin_id);


        }

        if(!empty($uid)){ //按姓名查询
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($useraccount)){ //按账户查询
            if(WSTIsPhone($useraccount)){
                $object =$this->db->where('users.phone = ',$useraccount);
            }else{
                $object =$this->db->where('users.email = ',$useraccount);
            }
        }


        if(!empty($status)){
            $object =$this->db->where('otc_orders.status =',$status);
        }
        if(!empty($order_no)){
            $object =$this->db->where('otc_orders.order_no =',$order_no);
        }
        if(!empty($start_time)){
            $object =$this->db->where('otc_orders.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('otc_orders.created_at <',$end_time);
        }
//        if(is_array($arr) && !empty($arr)){
//            $object = $this->db->where_in('otc_orders.merchant_bank_id',$arr);
//        }
        return $this->db->count_all_results();
    }


    //根据姓名和平台卡号获取财务信息
    public function get_bank_flow($name,$m_bank_id,$type,$status){
        return $this->OTC_model->get_info_per_user($m_bank_id,$type,$status,$name);
    }

    /**
     * Notes: 获取图片
     * User: 张哲
     * Date: 2019/3/6
     * Time: 15:52
     */
    public function get_image($image){
        $oss = new \App\Helpers\oss_helper();
        if(empty($image)) return array();
        $val = $oss->getSignedUrlForGettingObject($image);
        return $val;
    }

    /**
     * Notes: otc导出
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:20
     */
    public function inout_printexcel($offset,$limit,$type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchant_id)
    {
        $object = $this->db->select("otc_orders.*,users.realname as real_name,users.phone,users.email,users.id as uid,user_banks.card_number as user_card_number,user_banks.name,user_banks.pre_phone,user_banks.bank as user_bank,user_banks.sub_bank as user_sub_bank,merchant_account.card_number as merchanta_card_number,merchant_account.bank as merchant_bank,merchant_account.sub_bank as merchant_sub_bank,b_site.name as site_name,merchant_account.alipay_number,merchant_account.wechat_number,merchant_account.name as mer_name,merchant_account.id as mer_id,otc_user_account.account,otc_user_account.name,otc_user_account.image")
            ->from('otc_orders')
            // ->join('user_identities','user_identities.user_id=otc_orders.user_id','left')
            ->join('user_banks','user_banks.id=otc_orders.user_bank_id','left')
            ->join('otc_user_account','otc_user_account.id=otc_orders.user_bank_id','left')
            ->join('merchant_account','merchant_account.id=otc_orders.merchant_bank_id','left')
            ->join('b_site','b_site.id = otc_orders.site_id','left')
            ->join('users','users.id=otc_orders.user_id','left');
        //  $object =  $this->db->select('distinct(otc_orders.order_no)');
        $object =$this->db->where('otc_orders.type =',$type);

        // $object =$this->db->where('user_identities.deleted_at is null');


        if($site_id!='') $object =$this->db->where('otc_orders.site_id = ',$site_id);

        if(!empty($name)){ //按姓名查询
            $object =$this->db->where('users.realname =',$name);
        }

        $admin_id = $this->user_id;

        if(!empty($admin_id)){
            if($admin_id == 1 || $admin_id == 152 || $admin_id == 157 || $admin_id == 141 || $admin_id == 150 || $admin_id == 220) {
                $admin_id = "";
            }else{
                $admin_id  = $admin_id;
            }
        }
        if(!empty($admin_id)){
            $object =$this->db->where('merchant_account.admin_id =',$admin_id);
        }

        if(!empty($merchant_id)){ //商户id搜索
            $object =$this->db->where('merchant_account.id =',$merchant_id);
        }

        if(!empty($uid)){ //按用户id
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($useraccount)){ //按账户查询
            if(WSTIsPhone($useraccount)){
                $object =$this->db->where('users.phone = ',$useraccount);
            }else{
                $object =$this->db->where('users.email = ',$useraccount);
            }
        }

        if(!empty($status)){
            $object =$this->db->where('otc_orders.status =',$status);
        }
        if(!empty($order_no)){
            $object =$this->db->where('otc_orders.order_no =',$order_no);
        }
        if(!empty($start_time)){
            $object =$this->db->where('otc_orders.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('otc_orders.created_at <',$end_time);
        }

//        if(is_array($arr) && !empty($arr)){
//            $object = $this->db->where_in('otc_orders.merchant_bank_id',$arr);
//        }
        //1正序 2倒序

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        // var_dump($this->db->last_query());
        // var_dump($list);die;
        foreach ($list as &$value) {
            # code...
            if($value['pay_method'] == 0){
                $value['pay_method'] = '银行卡';

                $value['user_account'] = $value['name'].' '.$value['user_bank'].' '.$value['user_card_number'];
            }else if($value['pay_method'] == 1){
                $value['pay_method'] = '支付宝';

                $value['user_account'] = $value['name'].' '.$value['account'];
            }else if($value['pay_method'] == 2){
                $value['pay_method'] = '微信';

                $value['user_account'] = $value['name'].' '.$value['account'];
            }

            if($value['type'] == 1){
                $value['type'] = '买入';
            }else{
                $value['type'] = '卖出';
            }

            if ($value['status'] == 1) {
                $value['status_type'] = '未成交';
            }elseif ($value['status'] == 2){
                $value['status_type'] = '已支付';
            }elseif ($value['status'] == 3){
                $value['status_type'] = '已成功';
            }elseif ($value['status'] == 4){
                $value['status_type'] = '已取消';
            }elseif ($value['status'] == 5){
                $value['status_type'] = '处理中';
            }elseif ($value['status'] == 6){
                $value['status_type'] = '已过期';
            }elseif ($value['status'] == 7){
                $value['status_type'] = '已完成';
            }
//            if($type==1){
//                $value['card_number']=$this->get_user_bankcard($value['user_id']);
//            }
        }
        if(empty($list))
        {
            $data['url'] = false;
            returnJson('402','无导出数据',$data);
        }

        $arr = array();

        foreach ($list as $key => $val){
            $arr[$key]['uid'] = $val['uid'];
            $arr[$key]['order_no'] = $val['order_no'];
            $arr[$key]['real_name'] = $val['real_name'];
            $arr[$key]['card_number'] = $val['user_account'];
            $arr[$key]['merchanta_card_number'] = $val['merchanta_card_number'];
            $arr[$key]['price'] = $val['price'];
            $arr[$key]['amount'] = $val['amount'];
            $arr[$key]['remark'] = $val['remark'];
            $arr[$key]['status_type'] = $val['status_type'];
            $arr[$key]['updated_at'] = $val['updated_at'];
        }
        $title = array('用户id','订单号', '姓名','用户卡号', '平台卡号', '买入价格','买入数量','转账备注','状态','创建时间');
        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // var_dump($data);die;
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        // var_dump($data);die;
        returnJson('200',lang('operation_successful'),$data);
    }

    //获取用户的id,逗号隔开
    function get_user_bankcard($user_id)
    {
        $object = $this->db->select("user_banks.card_number,user_banks.bank")
            ->from('user_banks');
        $object =$this->db->where('user_banks.user_id = ',(int)$user_id);
        // $object =$this->db->where('user_banks.deleted_at is null');
        $list = $object->get()->result_array();
        // var_dump($list);die;
        $ss = [];
        foreach ($list as $key => $value) {
            $ss[$key] = $value['card_number'].$value['bank'];
        }
        // echo implode(' ', $ss);die;
        return implode(' ', $ss);
    }

    /**
     * Notes: 初次审核 法币买入卖出审核（5：初次审核成功状态，状态变处理中 4：审核不通过）
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:04
     */
    public function otc_verify_first($id,$status,$description)
    {
        $detail = $this->OTC_model->get_otcorder_info($id);
        $asset = $detail['asset'];
        $user_id = $detail['user_id'];
        $price = $detail['price'];
        $site_id = $detail['site_id'];
        $created_at = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        $type = $detail['type']==1 ? '买入':'卖出';
        $true_status = (int)$detail['status'];
        $amount = $detail['amount'];
        $real_amount = $detail['real_amount'];
        $totalamount = $price*$amount;
        $ss = '审核';

        //被禁用不可审核
        $mer_list = $this->OTC_model->mer_list($id);
        $mer_status = $this->OTC_model->get_status($mer_list['merchant_bank_id']);
//        if($mer_status['status'] == 0){
//            returnJson('402',lang('mer_forbid'));
//        }

        $mer_status1 = $mer_status['amount'];


        $this->db->trans_start();
        //获取用户最近的冻结资金
        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset,$user_id);
        if($detail['type']==1){ //买入
            if($true_status != 1 && $true_status != 2) return false;
            if($status == 4){ //审核不通过（取消状态）

                $business = $this->config->item('OTC_TRADE_BUY_CHECK_NO');
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);

                //余额加会数量 1.获取目前余额 2.相加 3.修改余额
               // $this->OTC_model->update_amount($amount,$mer_list['merchant_bank_id']);
                $update_amount = $amount + $mer_status1;
                $this->OTC_model->update_amount($update_amount,$mer_list['merchant_bank_id']);

            }else{
//                if($caiwu_id==''){
//                    returnJson('402','没选中财务信息无法审核通过');
//                }
                $business = $this->config->item('OTC_TRADE_BUY_CHECK_YES_FIRST');
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
//                if($caiwu_id!='')
//                {
//                    //将财务信息记录的状态置为待处理已通过状态。 $caiwu_id = '1,2';
//                    $caiwu_id = explode(',', $caiwu_id);
//                    // $status = 7; //bank_inout中的状态：初审通过
//                    for($i = 0;$i<count($caiwu_id);$i++)
//                    {
//                        $this->OTC_model->update_caiwu_status($caiwu_id[$i],7);
//                    }
//                }
            }
        }else{
            // 卖出
            if($true_status != 1 && $true_status != 2) return false;
            if($status == 4){ //审核不通过（取消状态）
                // $this->OTC_model->update_amount($amount,$mer_list['merchant_bank_id']);
                $update_amount = $amount + $mer_status1;
               $business_id =  $this->OTC_model->update_amount($update_amount,$mer_list['merchant_bank_id']);
                //$ss = array('info'=>$ss);
               // $result = update_user_balance_bycurl($user_id,$asset,$amount,$id,$ss,$busi='cancel_otc_sell_freeze');

                $remark_add = array('info'=>$user_id,'remark'=>$description);
                $remark_add = json_encode($remark_add);
                $business = "cancel_otc_sell_freeze";
                $result = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id,0,$asset,$business,$id,$amount,$site_id,$remark_add,$description);

                if($result['code']!=0){
                    returnJson('403',$result['details']);
                }else{
                    $balance = $last_balance['balance']-$amount;
                    $business = $this->config->item('OTC_TRADE');
                    //写入user_asset_freeze表
                    $detail1 = json_encode(array('id'=>(int)$id));
                    $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);
                    $business = $this->config->item('OTC_TRADE_SELL_CHECK_NO');
                    // $description = '法币卖出审核不通过';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
                }
            }else{
                $business = $this->config->item('OTC_TRADE_SELL_CHECK_YES_FIRST');
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
            }
        }
        $result = $this->OTC_model->update_status($id,$status,$created_at);
        $this->db->trans_complete();
        return $result;
    }

    /**
     * Notes:法币买入卖出审核（3：审核通过，状态变已成功 4：审核不通过）
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:04
     */
    public function c2c_verify($id,$status,$description)
    {
        $detail = $this->OTC_model->get_otcorder_info($id);

        $queue_status = 'success';
        $asset = $detail['asset'];
        $user_id = $detail['user_id'];
        $price = $detail['price'];
        $site_id = $detail['site_id'];
        $created_at = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        $type = $detail['type']==1 ? '买入':'卖出';
        $true_status = (int)$detail['status'];
        $amount = $detail['amount'];
        $real_amount = $detail['amount'];
        $totalamount = $price*$amount;
        $ss = '审核';
        $this->db->trans_begin();
        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset,$user_id);
        if($detail['type']==1){ //买入
            if($true_status != 5) return false;
            if($status == 4){ //审核不通过（取消状态）
//                if($caiwu_id==''){
//                    returnJson('402','请选中财务信息！');
//                }
//                // $balance = $last_balance['balance']-$amount;
//                $business = $this->config->item('OTC_TRADE');
//                //写入user_asset_freeze表
//                // $detail1 = json_encode(array('id'=>(int)$id));
//                // $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);

                $mer_list = $this->OTC_model->mer_list($id);
                $mer_status = $this->OTC_model->get_status($mer_list['merchant_bank_id']);
                $mer_status1 = $mer_status['amount'];
                //余额加会数量 1.获取目前余额 2.相加 3.修改余额
                $update_amount = $amount + $mer_status1;
                $this->OTC_model->update_amount($update_amount,$mer_list['merchant_bank_id']);
//
                $business = $this->config->item('OTC_TRADE_BUY_CHECK_NO');
                //$description = '法币买入审核拒绝';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
//                if($caiwu_id!='')
//                {
//                    //将财务信息记录的状态置为待处理已通过状态
//                    // $caiwu_id = '1,2';
//                    $caiwu_id = explode(',', $caiwu_id);
//                    for($i = 0;$i<count($caiwu_id);$i++)
//                    {
//                        $this->OTC_model->update_caiwu_status($caiwu_id[$i],8);
//                    }
//                }
            }else{
//                if($caiwu_id==''){
//                    returnJson('402','没选中财务信息无法审核通过');
//                }
                // 修改用户账户资金
               // $ss = array('info'=>$ss);
               // $result = update_user_balance_bycurl($user_id,$asset,$real_amount,$id,$ss,$busi='otc_deposit');

                $remark_add = array('info'=>$user_id,'remark'=>$description);
                $remark_add = json_encode($remark_add);
                $business = "otc_deposit";
                $result = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id,0,$asset,$business,$id,$amount,$site_id,$remark_add,$description);
                // var_dump($result);die;
                if($result['code']!=0){
                    returnJson('403',$result['details']);
                }else{
                    //打入消息队列
                    require_once './vendor/autoload.php';
                    $connection = new AMQPStreamConnection($this->config->item('rabbitmq_host'), $this->config->item('rabbitmq_port'), $this->config->item('rabbitmq_user'), $this->config->item('rabbitmq_pwd'));
                    // $connection = new AMQPStreamConnection('localhost', 5672, 'guest', 'guest');
                    $channel = $connection->channel();
                    $channel->queue_declare('task_queue', false, true, false, false);
                    $iid = array($id);
                    $arr = array(
                        'name'=>'otc_recharge',
                        'ip'=>$_SERVER['REMOTE_ADDR'],
                        'endpoint'=>'admin',
                        // 'params'=> '['.$id.']',
                        'params'=> array((int)$id),
                        'time'=>$_SERVER['REQUEST_TIME'],
                    );

                    $detail = json_encode($arr);
                    $msg = new AMQPMessage($detail,array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
                    $cc = $channel->basic_publish($msg, '', 'task_queue');
                    // echo " [x] Sent 'Hello World!'\n";
                    $channel->close();
                    $connection->close();
                    if($cc != NULL){
                        $queue_status = 'failed';
                    }else{
                        $queue_status = 'success';
                    }
                    $iid = '['.$id.']';

                    $this->OTC_model->add_event($created_at,$updated_at,$arr['name'],$arr['ip'],$arr['endpoint'],$iid);

                    $business = $this->config->item('OTC_TRADE_BUY_CHECK_YES');
                    // $description = '法币买入审核通过';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
//                    if($caiwu_id!='')
//                    {
//                        //将财务信息记录的状态置为待处理已通过状态
//                        // $caiwu_id = '1,2';
//                        $caiwu_id = explode(',', $caiwu_id);
//                        for($i = 0;$i<count($caiwu_id);$i++)
//                        {
//                            $this->OTC_model->update_caiwu_status($caiwu_id[$i],2);
//                        }
//                    }
                }
            }
        }else{
            // 卖出
            if($true_status != 5) return false;
            if($status == 4){ //审核不通过（取消状态）
                $mer_list = $this->OTC_model->mer_list($id);
                $mer_status = $this->OTC_model->get_status($mer_list['merchant_bank_id']);
                $mer_status1 = $mer_status['amount'];
                //余额加会数量 1.获取目前余额 2.相加 3.修改余额
                $update_amount = $amount + $mer_status1;
                $business_id = $this->OTC_model->update_amount($update_amount,$mer_list['merchant_bank_id']);
                //$ss = array('info'=>$ss);
               // $result = update_user_balance_bycurl($user_id,$asset,$amount,$id,$ss,$busi='cancel_otc_sell_freeze');

                $remark_add = array('info'=>$user_id,'remark'=>$description);
                $remark_add = json_encode($remark_add);
                $business = "otc_deposit";
                $result = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id,0,$asset,$business,$id,$amount,$site_id,$remark_add,$description);
                if($result['code']!=0){
                    returnJson('403',$result['details']);
                }else{
                    $balance = $last_balance['balance']-$amount;
                    $business = $this->config->item('OTC_TRADE');
                    //写入user_asset_freeze表
                    $detail1 = json_encode(array('id'=>(int)$id));
                    $this->OTC_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);

                    $business = $this->config->item('OTC_TRADE_SELL_CHECK_NO');
                    // $description = '法币卖出审核不通过';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
                }
            }else{
                $business = $this->config->item('OTC_TRADE');
                $balance = $last_balance['balance']-$amount;
                $detail1 = json_encode(array('id'=>(int)$id));
                $this->OTC_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);

                $business = $this->config->item('OTC_TRADE_SELL_CHECK_YES');
                // $description = '法币买入审核通过';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
            }
        }
        $result = $this->OTC_model->update_status($id,$status,$created_at);
        $trans_status = $this->db->trans_status();
        if($queue_status == 'failed' && $trans_status == false)
        {
            $trans_status = false;
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            returnJson('402','Transaction failed');
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    //后台解冻资金
    public function admin_unfreeze_asset($uid,$asset,$amount,$remark)
    {
        //查看当前用户是否有锁仓记录
        $args=array('uid'=>$uid,'asset'=>$asset);
        $list = $this->Zjys_user_service->is_lockposition($args);
        if(is_array($list) && !empty($list)) returnJson('402','当前用户有锁仓记录，请先解仓');

        //解冻资金
        if(!is_numeric($amount) || $amount<=0) returnJson('402','金额非法');
        $created_at = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        $business = $this->config->item('ADMIN_UNFREEZE');
        $this->db->trans_start();
        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset,$uid);
        if(is_array($last_balance) && empty($last_balance)) returnJson('402','当前币种没有冻结资金');
        if(bcsub($last_balance['balance'], $amount,16)<0){
            returnJson('402','调整冻结非法');
        }
        $balance = bcsub($last_balance['balance'],$amount);
        $detail1 = json_encode(array('uid'=>(int)$uid));

        $result = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$uid,$asset,-$amount,$business,$balance,$detail1);
        // var_dump($result);die;
        if($result){
            // 更改用户资金
            $ss = array('info'=>$business);
            $res = update_user_balance_bycurl_unfreeze($uid,$asset,$amount,$result,$ss);
            // var_dump($res);die;
            if($res['error']!==NULL){
                returnJson('402','充值系统错误');
            }elseif($res['result']['status']=='success'){
                $business_type = $this->config->item('ADMIN_UNFREEZE_ASSET');
                admin_operation_logs($this->user_id,$uid,$business_type,$remark,$created_at,$result);
                $this->Zjys_user_operationmoney_model->add($this->user_id,$created_at,$asset,$amount,$uid,$remark,$type=2);
            }
        }else{
            return false;
        }

        $this->db->trans_complete();
        return $result;
    }


    //根据用户和币种查找冻结的C2C资金
    public function get_c2c_freezen_by_assets_and_userid($assets,$user_id)
    {
        $sql = 'select balance from user_asset_freezes where asset="'.$assets.'" and user_id='.$user_id.' and business in ("c2c_sell_freeze","cancel_c2c_sell_freeze","admin_c2c_unfreeze") order by id desc limit 1';
        $result = object_to_array($this->db->query($sql)->result());
        // var_dump($this->db->last_query());
        // var_dump($result);die;
        if(is_array($result) && !empty($result)){
            return $result[0]['balance'];
        }else{
            return '0';
        }
    }

    /*
     * 法币买入卖出统计
     */
    public function get_in_total($start_time,$end_time,$offset,$limit,$type,$site_id){
        return $this->Zjys_c2corder_model->in_total($start_time,$end_time,$offset,$limit,$type,$site_id);
    }

    public function get_in_total_count($start_time,$end_time,$type,$site_id){
        return $this->Zjys_c2corder_model->in_total_count($start_time,$end_time,$type,$site_id);
    }

    //
    public function total($type,$site_id,$stime,$etime,$offset,$limit)
    {
        return $this->Zjys_c2corder_model->total($type,$site_id,$stime,$etime,$offset,$limit);
    }


    public function total_reality($type,$site_id,$stime,$etime,$offset,$limit)
    {
        return $this->Zjys_c2corder_model->total_reality($type,$site_id,$stime,$etime,$offset,$limit);
    }
    //买入卖出应收、理论指出
    public function get_totalamount_per_merchantbank($m_bank_id,$type,$start_time,$end_time,$offset,$limit)
    {
        $object = $this->db->select("DATE_FORMAT(updated_at,'%Y-%m-%d') days,sum(total_amount) total")
            ->from('c2c_orders');
        $object =$this->db->group_by('days');
        $object =$this->db->where('c2c_orders.merchant_bank_id =',$m_bank_id); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);
        $object =$this->db->where('c2c_orders.status !=',4);

        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        return $list;
    }

    //买入卖出应收、理论指出
    public function get_totalamount_per_merchantbank_count($m_bank_id,$type,$start_time,$end_time,$offset,$limit)
    {

        $object = $this->db->select("DATE_FORMAT(updated_at,'%Y-%m-%d') days,sum(total_amount) total")
            ->from('c2c_orders');
        // ->('c2c_orders')
        $object =$this->db->group_by('days');
        $object =$this->db->where('c2c_orders.merchant_bank_id =',$m_bank_id); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);
        $object =$this->db->where('c2c_orders.status !=',4);

        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time);
        }

        return $this->db->count_all_results();
    }


    //买入卖出实际收入、实际支出
    public function get_totalamount_per_merchantbank_reality($m_bank_id,$type,$start_time,$end_time,$offset,$limit)
    {
        $object = $this->db->select("DATE_FORMAT(updated_at,'%Y-%m-%d') days,sum(total_amount) total")
            ->from('c2c_orders');
        // ->('c2c_orders')
        $object =$this->db->group_by('days');
        $object =$this->db->where('c2c_orders.merchant_bank_id =',6); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);
        $object =$this->db->where('c2c_orders.status =',3);

        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        return $list;
    }

    //买入卖出实际收入、实际支出
    public function get_totalamount_per_merchantbank_reality_count($m_bank_id,$type,$start_time,$end_time,$offset,$limit)
    {
        $object = $this->db->select("DATE_FORMAT(updated_at,'%Y-%m-%d') days,sum(total_amount) total")
            ->from('c2c_orders');
        // ->('c2c_orders')
        $object =$this->db->group_by('days');
        $object =$this->db->where('c2c_orders.merchant_bank_id =',6); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);
        $object =$this->db->where('c2c_orders.status =',3);

        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time);
        }

        return $this->db->count_all_results();
    }



    public function get_c2corder()
    {
        $result = $this->Zjys_c2corder_model->get_c2corder($id);
        return $result;
    }


    /**
     * Notes:  otc用户收付款设置
     * User: 张哲
     * Date: 2019/2/28
     * Time: 11:45
     */
    public function otc_user_account($offset,$limit,$type,$uid,$site_id){
        $object = $this->db->select("otc_user_account.*,users.site_id")
            ->join('users','users.id=otc_user_account.user_id','left')
            ->from('otc_user_account');

        //$object =$this->db->where('otc_user_account.deleted_at is null');

        if(!empty($type)) {
            $object =$this->db->where('otc_user_account.status =',$type);
        }

        if(!empty($site_id)) {
            $object =$this->db->where('users.site_id =',$site_id);
        }

        if(!empty($uid)){ //按姓名查询
            $object =$this->db->where('otc_user_account.user_id =',$uid);
        }

        $list = $object->order_by('created_at','desc')->get()->result_array();


        //银行卡
        $object1 = $this->db->select("user_banks.*,users.site_id")
            ->join('users','users.id=user_banks.user_id','left')
            ->from('user_banks');

        $object1 =$this->db->where('user_banks.deleted_at is null');

        if(!empty($uid)){ //按姓名查询
            $object1 =$this->db->where('user_banks.user_id =',$uid);
        }

        if(!empty($site_id)) {
            $object1 =$this->db->where('users.site_id =',$site_id);
        }

        $list1 = $object1->order_by('created_at','desc')->get()->result_array();

        $res = array_merge($list1,$list);


        $take_arr = array_slice($res,$offset,$limit);

        foreach ($take_arr as &$value) {
            if(!empty($value['status'])){
                if($value['status'] == 1){
                    $value['status'] = '支付宝';
                    $value['name'] = !empty($value['name']) ? ($value['name']) : '';
                    $value['account'] = !empty($value['account']) ? ($value['account']) : '';
                    $value['image'] = $this->get_image($value['image']);
                }else if($value['status'] == 2){
                    $value['status'] = '微信';
                    $value['name'] = !empty($value['name']) ? ($value['name']) : '';
                    $value['account'] = !empty($value['account']) ? ($value['account']) : '';
                   $value['image'] = $this->get_image($value['image']);
                }
            }
           else{
                $value['status'] = '银行卡';
                $value['name'] = !empty($value['name']) ? ($value['name']) : '';
                $value['account'] = !empty($value['card_number']) ? ($value['card_number']) : '';
            }

            $site_id = !empty($value['site_id']) ? intval($value['site_id']) : 1;
            $site_name = $this->Zjys_symbols_model->get_symbols_name($site_id);
            if(!empty($site_name['name'])){
                $value['site_name'] = $site_name['name'];
            }else{
                $value['site_name'] = '';
            }

        }
        return $take_arr;
    }

    /**
     * Notes: 用户账号数量
     * User: 张哲
     * Date: 2019/2/28
     * Time: 11:45
     */
    public function otc_user_account_count($type,$uid,$site_id){
        $object = $this->db->select("otc_user_account.*,users.site_id")
            ->join('users','users.id=otc_user_account.user_id','left')
            ->from('otc_user_account');


        $object =$this->db->where('otc_user_account.deleted_at is null');

        if(!empty($type)) {
            $object =$this->db->where('otc_user_account.status =',$type);
        }

        if(!empty($site_id)) {
            $object =$this->db->where('users.site_id =',$site_id);
        }

        if(!empty($uid)){ //按姓名查询
            $object =$this->db->where('otc_user_account.user_id =',$uid);
        }

        return $this->db->count_all_results();

    }


    /**
     * Notes: 银行卡数量
     * User: 张哲
     * Date: 2019/3/11
     * Time: 14:46
     */
    public function otc_user_account_count1($type,$uid,$site_id){

        //银行卡
        $object = $this->db->select("user_banks.*,users.site_id")
            ->join('users','users.id=user_banks.user_id','left')
            ->from('user_banks');

        $object =$this->db->where('user_banks.deleted_at is null');

        if(!empty($uid)){ //按姓名查询
            $object =$this->db->where('user_banks.user_id =',$uid);
        }

        if(!empty($site_id)) {
            $object =$this->db->where('users.site_id =',$site_id);
        }

        return  $this->db->count_all_results();

    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/20
     * Time: 10:40
     * @return mixed
     */
    public function foreign_otc_transfers_list($offset,$limit,$start_time,$end_time,$site_id,$uid,$asset){
        $object = $this->db->select("foreign_otc_transfers.*")
            ->from('foreign_otc_transfers');
        $object =$this->db->where('foreign_otc_transfers.deleted_at is null');
        if($uid!='') $object =$this->db->where('foreign_otc_transfers.uid = ',$uid);
        if($site_id!='') $object =$this->db->where('foreign_otc_transfers.site_id = ',$site_id);
        if($asset!='') $object =$this->db->where('foreign_otc_transfers.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('foreign_otc_transfers.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('foreign_otc_transfers.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
        }
        return $list;
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/20
     * Time: 10:40
     */
    public function foreign_otc_transfers_count($start_time,$end_time,$site_id,$uid,$asset){
        $object = $this->db->select("foreign_otc_transfers.*")
            ->from('foreign_otc_transfers');
        $object =$this->db->where('foreign_otc_transfers.deleted_at is null');
        if($uid!='') $object =$this->db->where('foreign_otc_transfers.uid = ',$uid);
        if($site_id!='') $object =$this->db->where('foreign_otc_transfers.site_id = ',$site_id);
        if($asset!='') $object =$this->db->where('foreign_otc_transfers.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('foreign_otc_transfers.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('foreign_otc_transfers.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }


    /**
     * Notes: 导出
     * User: 张哲
     * Date: 2019/3/20
     * Time: 10:50
     */
    public function foreign_otc_transfers_export($offset,$limit,$start_time,$end_time,$site_id,$uid,$asset){
        $object = $this->db->select("foreign_otc_transfers.*")
            ->from('foreign_otc_transfers');
        $object =$this->db->where('foreign_otc_transfers.deleted_at is null');
        if($uid!='') $object =$this->db->where('rm_people_alarm.uid = ',$uid);
        if($site_id!='') $object =$this->db->where('rm_people_alarm.site_id = ',$site_id);
        if($asset!='') $object =$this->db->where('rm_people_alarm.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('otc_orders.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('otc_orders.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
        }
        return $list;
    }


    /**
     * Notes: otc 币种配置
     * User: 张哲
     * Date: 2019/3/22
     * Time: 11:09
     * @param $site_id
     * @return mixed
     */
    public function otc_assets($site_id){
        $object = $this->db->select("assets.*")
            ->from('assets');
        // $object =$this->db->where('rm_parameter.symbol is null');
        if($site_id!='') $object =$this->db->where('assets.site_id = ',$site_id);
        $list = $object->get()->result_array();
        return $list;
    }

    /**
     * Notes: 修改OTC
     * User: 张哲
     * Date: 2019/3/22
     * Time: 11:27
     * @param $site_id
     */
    public function update_otc_assets($args){
        $site_id = $args['site_id'];
        $aa = $this->Zjys_assets_model->list_all($site_id); //当前站点的资产列表
        $site_asset_list = array();
        foreach ($aa as $key => $value) {
            $site_asset_list[] = $value['asset_code'];
        }
        $asset = $args['asset'];
        $asset_type = explode(',',$asset);
        //在提交列表的
        for($i=0;$i<count($asset_type);$i++)
        { //匹配就修改为1
            if(in_array($asset_type[$i], $site_asset_list)){
                $this->OTC_model->otc_asset_update($site_id,$asset_type[$i],1);
            }
        }
        //不在的改为0
        for($i=0;$i<count($site_asset_list);$i++)
        {
            if(!in_array($site_asset_list[$i], $asset_type)){
                //去
                $this->OTC_model->otc_asset_update($site_id,$site_asset_list[$i],0);
            }
        }
        return;
    }

}
