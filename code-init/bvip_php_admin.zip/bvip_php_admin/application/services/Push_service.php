<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-06-25
 * Time: 09:40
 */

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Push_service extends MY_Service
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('Zjys_symbols_model');
    }

    /**
     * Notes: 推送通知
     * User: 张哲
     * Date: 2019-06-25
     * Time: 09:49
     */
    public function push_list($offset, $limit,  $start_time, $end_time,$title,$site_id)
    {
        $object = $this->db->select("push_notification.*")
            ->from('push_notification');
        $object = $this->db->where('push_notification.deleted_at is null');

        if (!empty($title)) {
            $object = $this->db->where('push_notification.title =', $title);
        }

        if (!empty($site_id)) {
            $object = $this->db->where('push_notification.site_id =', $site_id);
        }

        if (!empty($start_time)) {
            $object = $this->db->where('push_notification.created_at >=', $start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('push_notification.created_at <', $end_time);
        }
        $list = $object->limit($limit, $offset)->order_by('created_at', 'desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            if($val['status'] == 1){
                $val['status_code'] = '未推送';
            }else  if($val['status'] == 2){
                $val['status_code'] = '推送成功';
            }else{
                $val['status_code'] = '推送失败';
            }
        }
        return $list;
    }

    /**
     * Notes: 推送通知
     * User: 张哲
     * Date: 2019-06-25
     * Time: 09:51
     */
    public function push_count( $start_time, $end_time,$title,$site_id)
    {
        $object = $this->db->select("push_notification.*")
            ->from('push_notification');
        $object = $this->db->where('push_notification.deleted_at is null');

        if (!empty($title)) {
            $object = $this->db->where('push_notification.title =', $title);
        }

        if (!empty($site_id)) {
            $object = $this->db->where('push_notification.site_id =', $site_id);
        }

        if (!empty($start_time)) {
            $object = $this->db->where('push_notification.created_at >=', $start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('push_notification.created_at <', $end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 新增编辑通知
     * User: 张哲
     * Date: 2019-06-25
     * Time: 10:19
     */
    public function push_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $notification_id = isset($args['notification_id']) ? $args['notification_id']: '';
        if(empty($notification_id)) {
            if (!$id) {
                $created_at = date("Y-m-d H:i:s", time());
                $args ['created_at'] = $created_at;
                //新增
                $business_id = $this->db->insert('push_notification', $args);
            } else {
                $updated_at = date("Y-m-d H:i:s", time());
                $args ['updated_at'] = $updated_at;
                $this->db->where('id', $id);
                $this->db->update('push_notification', $args);
            }
            return true;
        }else{
            $object = $this->db->select("b_news.*")
                ->from('b_news');
            $object = $this->db->where('b_news.id =', $notification_id);
            $list = $object->get()->result_array();
            if(empty($list)){
                returnJson('402','该公告ID不合法');
            }else{
                if (!$id) {
                    $created_at = date("Y-m-d H:i:s", time());
                    $args ['created_at'] = $created_at;
                    $args ['notification_id'] = $notification_id;
                    //新增
                    $business_id = $this->db->insert('push_notification', $args);
                } else {
                    $updated_at = date("Y-m-d H:i:s", time());
                    $args ['updated_at'] = $updated_at;
                    $args ['notification_id'] = $notification_id;
                    $this->db->where('id', $id);
                    $this->db->update('push_notification', $args);
                }
                return true;
            }
        }

    }


    /**
     * Notes: 删除通知
     * User: 张哲
     * Date: 2019-06-25
     * Time: 10:17
     */
    public function push_delete($args)
    {
        $data = array();
        $id = isset($args['id']) ? $args['id']: '';
        $deleted_at = date("Y-m-d H:i:s", time());
        $args ['deleted_at'] = $deleted_at;
        $this->db->where('id', $id);
        $this->db->update('push_notification', $args);

    }


    /**
     * Notes: 推送
     * User: 张哲
     * Date: 2019-06-25
     * Time: 11:14
     */
    public function push($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $data = $this->User_model->push($id);
        $status =$data['status'];
        $notification_id = $data['notification_id'];


        if(empty($notification_id)){
            $title =$data['title'];
            $notification_id ='';

            if($status != 2){
                $res = push($title,$notification_id);
                if($res['code'] == 0){
                    // echo 2;
                    $data = array();
                    $id = isset($args['id']) ? $args['id']: '';
                    $data ['status'] = 2;
                    $update_at = date("Y-m-d H:i:s", time());
                    $data ['updated_at'] = $update_at;
                    $this->db->where('id', $id);
                    $this->db->update('push_notification', $data);
                    return true;
                }else{
                    return false;
                }
            }else{
                returnJson('402',"该记录已发送");
            }
        }else {
            $title = $data['title'];
            $notification_id = $data['notification_id'];
            $object = $this->db->select("b_news.*")
                ->from('b_news');
            $object = $this->db->where('b_news.id =', $notification_id);
            $list = $object->get()->result_array();
            if (empty($list)) {
                returnJson('402', '该公告ID不合法');
            } else {
                if ($status != 2) {

                    $res = push($title, $notification_id);
                    if ($res['code'] == 0) {
                        // echo 2;
                        $data = array();
                        $id = isset($args['id']) ? $args['id'] : '';
                        $data ['status'] = 2;
                        $update_at = date("Y-m-d H:i:s", time());
                        $data ['updated_at'] = $update_at;
                        $this->db->where('id', $id);
                        $this->db->update('push_notification', $data);
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    returnJson('402', "该记录已发送");
                }
            }
        }
    }



}