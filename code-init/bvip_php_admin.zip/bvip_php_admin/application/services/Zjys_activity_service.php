<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_activity_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_activity_model');
        $this->load->service('Sys_grpc_service');
        $this->load->model('Activity_unlock_model');
        $this->load->model('Zjys_user_model');
        $this->load->model('Zjys_symbols_model');



    } 

    public function get_info($id)
    {
        return $this->Zjys_activity_model->get_info($id);
    }

    /**
     * Notes: 活动列表
     * User: 张哲
     * Date: 2019/3/15
     * Time: 10:47
     */
    public function activity_list($offset,$limit,$event,$start_time,$end_time,$site_id){
        $object = $this->db->select("activities.*,b_site.name as site_name")
            ->join('b_site','b_site.id=activities.site_id','left')
            ->from('activities');
            $object =$this->db->where('activities.deleted_at =',null);
            if($site_id!='') $object =$this->db->where('activities.site_id = ',$site_id);
        if(!empty($event)){
            $object =$this->db->where('activities.event =',$event);
        }
        if(!empty($start_time)){
            $object =$this->db->where('activities.start_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('activities.end_time <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        // var_dump($list);die;
        foreach ($list as &$value) {
            # code...
            if($value['event'] == 'register'){
                $value['event_status'] = '注册';
            }
            if($value['event'] == 'identity'){
                $value['event_status'] = '认证';
            }
            if($value['event'] == 'c2c_recharge'){
                $value['event_status'] = 'c2c充值';
            }
            //查询该活动已经发放

            $send_amount = $this->Zjys_user_model->send_amount($value['id']);
            $value['send_amount'] = $send_amount['send_amount'];
        }
        // var_dump($list);die;
        return $list;
    }


    //
    public function activity_list_count($asset_code,$start_time,$end_time,$site_id){
        $object = $this->db->select("activities.*,b_site.name as site_name")
            ->join('b_site','b_site.id=activities.site_id','left')
            ->from('activities');
            $object =$this->db->where('activities.deleted_at =',null);
            if($site_id!='') $object =$this->db->where('activities.site_id = ',$site_id);
        if(!empty($event)){
            $object =$this->db->where('activities.event =',$event);
        }
        if(!empty($start_time)){
            $object =$this->db->where('activities.start_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('activities.end_time <',$end_time);
        }
        return $this->db->count_all_results();
    }
    //夺宝活动列表
    public function treasure_activity_list($offset,$limit,$finished,$name,$code,$init_method,$start_time,$end_time,$site_id){
        $object = $this->db->select("treasures.*,b_site.name as site_name")
            ->join('b_site','b_site.id=treasures.site_id','left')
            ->from('treasures');
            $object =$this->db->where('treasures.deleted_at =',null);
            // $object =$this->db->where('treasures.is_display =',1);
            if($site_id!='') $object =$this->db->where('treasures.site_id = ',$site_id);
        if($finished!=''){
            $object =$this->db->where('treasures.finished =',$finished);
        }
        if(!empty($name)){
            $object =$this->db->where('treasures.name =',$name);
        }
        if(!empty($code)){
            $object =$this->db->where('treasures.code =',$code);
        }
        if($init_method!=''){
            $object =$this->db->where('treasures.init_method =',$init_method);
        }
        if(!empty($start_time)){
            $object =$this->db->where('treasures.start_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('treasures.end_time <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        // var_dump($list);die;
        foreach ($list as &$value) {
            if($value['init_method'] == 1){
                if($value['finished'] == 0) $value['finished_status'] = '活动中';
                if($value['finished'] == 1) $value['finished_status'] = '已结束';
            }else{
                $res = $this->Zjys_activity_model->treasure_status($value['id']);
                // $res = $this->Zjys_activity_model->treasure_status(1);
                $num = 0;
                foreach ($res as $val) {
                    if($val['status'] ==1 ){
                        $num++;
                    }
                }
                if($num==count($res)){
                    $value['finished_status'] = '等待中';
                }else{
                    $value['finished_status'] = '活动中';
                }
            }
            
        }
        return $list;
    }

    
    


    public function treasure_activity_listcount($finished,$name,$code,$init_method,$start_time,$end_time,$site_id){
        $object = $this->db->select("treasures.*,b_site.name as site_name")
            ->join('b_site','b_site.id=treasures.site_id','left')
            ->from('treasures');
            $object =$this->db->where('treasures.deleted_at =',null);
            // $object =$this->db->where('treasures.is_display =',1);
            if($site_id!='') $object =$this->db->where('treasures.site_id = ',$site_id);
        if(!empty($finished)){
            $object =$this->db->where('treasures.finished =',$finished);
        }
        if(!empty($name)){
            $object =$this->db->where('treasures.name =',$name);
        }
        if(!empty($code)){
            $object =$this->db->where('treasures.code =',$code);
        }
        if(!empty($init_method)){
            $object =$this->db->where('treasures.init_method =',$init_method);
        }
        if(!empty($start_time)){
            $object =$this->db->where('treasures.start_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('treasures.end_time <',$end_time);
        }
        return $this->db->count_all_results();
    }

    public function treasure_session_activity_list($offset,$limit,$treasures_id,$site_id){
        $detail = $this->Zjys_activity_model->get_detail($treasures_id);
        $treasures_code = $detail['code'];
        $object = $this->db->select("treasure_sessions.*,b_site.name as site_name")
            ->join('b_site','b_site.id=treasure_sessions.site_id','left')
            ->from('treasure_sessions');
        $object =$this->db->where('treasure_sessions.deleted_at =',null);
        $object =$this->db->where('treasure_sessions.treasure_id =',$treasures_id);
        if($site_id!='') $object =$this->db->where('treasure_sessions.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        foreach ($list as &$value) {
            $value['treasures_code'] = $treasures_code;
        }
        return $list;
    }

    public function treasure_session_activity_listcount($treasures_id,$site_id){
        $object = $this->db->select("treasure_sessions.*,b_site.name as site_name")
            ->join('b_site','b_site.id=treasure_sessions.site_id','left')
            ->from('treasure_sessions');
        $object =$this->db->where('treasure_sessions.deleted_at =',null);
        $object =$this->db->where('treasure_sessions.treasure_id =',$treasures_id);
        if($site_id!='') $object =$this->db->where('treasure_sessions.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    //添加、编辑币种类
    public function add_activity($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $event = isset($args['event']) ? $args['event']: '';
        $name = isset($args['name']) ? $args['name']: '';
        $start_time = isset($args['start_time']) ? $args['start_time']: '';
        $end_time = isset($args['end_time']) ? $args['end_time']: '';
        $award = isset($args['award']) ? $args['award']: 0;
        if($award=='') $award = 0;
        $award_asset = isset($args['award_asset']) ? $args['award_asset']: '';
        $top_award = isset($args['top_award']) ? $args['top_award']: 0;
        if($top_award=='') $top_award = 0;

        $top_two_award = isset($args['top_two_award']) ? $args['top_two_award']: 0;
        if($top_two_award=='') $top_two_award = 0;

        $top_two_award_asset = isset($args['top_two_award_asset']) ? $args['top_two_award_asset']: '';
        $top_award_asset = isset($args['top_award_asset']) ? $args['top_award_asset']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: 1;
        $top_award_status = isset($args['top_award_status']) ? $args['top_award_status']: 0;
        $top_two_award_status = isset($args['top_two_award_status']) ? $args['top_two_award_status']: 0;

        $recharge_asset = isset($args['recharge_asset']) ? $args['recharge_asset']: 0;
        $recharge_award_rate = isset($args['recharge_award_rate']) ? $args['recharge_award_rate']: 0;

        $is_lock = isset($args['is_lock']) ? $args['is_lock']: 0;
        $top_award_total = isset($args['top_award_total']) ? $args['top_award_total']: 0;
        $top_two_award_total = isset($args['top_two_award_total']) ? $args['top_two_award_total']: 0;

        $award_total = isset($args['award_total']) ? $args['award_total']: 0;
        // $award_three = $award+$top_award+$top_two_award;
        // if($award_three>$award_total) returnJson('402','多级奖励数量之和不能大于总奖励数量');
        
        if(!is_numeric($is_lock)) return false;

        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());

        if(!$id){
            //新增
            $result = $this->Zjys_activity_model->add_activity($top_two_award_status,$top_two_award,$top_two_award_asset,$event,$name,$start_time,$end_time,$award,$award_asset,$top_award,$top_award_asset,$top_award_status,$site_id,$created_at,$updated_at,$recharge_asset,$recharge_award_rate,$is_lock,$award_total,$top_award_total,$top_two_award_total);
            // var_dump($result);die;
        }else{
            //修改
            $this->Zjys_activity_model->edit_activity($top_two_award_status,$top_two_award,$top_two_award_asset,$event,$name,$start_time,$end_time,$award,$award_asset,$top_award,$top_award_asset,$top_award_status,$site_id,$updated_at,$id,$recharge_asset,$recharge_award_rate,$is_lock,$award_total,$top_award_total,$top_two_award_total);
        }
        return true;
    }



    public function treasure_activity_add($args)
    {
        $last_record = $this->Zjys_activity_model->get_last_detail();
        $id = isset($args['id']) ? $args['id']: '';

        if ((floor($args['total']) - $args['total']) !=0) returnJson('402','总量一定为正整数');
        if ((floor($args['pay_per_max']) - $args['pay_per_max']) !=0) returnJson('402','格式为正整数');
        if($args['pay_per_max']>$args['total']) returnJson('402','用户单次购买数量不能操作总数量');
        $unaward_rule = object_to_array(json_decode($args['unaward_rule']));
        if(array_sum($unaward_rule)>($args['total']-1)) returnJson('402','未中奖的奖券总量不能超过总数量');
        if(empty($unaward_rule)){
            $args['unaward_rule'] = '{}';
        }
        if(is_array($last_record) && empty($last_record)) 
        {
            $code = substr(date('Ymd',time()),2).'001';
        }else{
            if($last_record['code'] == substr(date('Ymd',time()),2).'999') returnJson('超出当日活动数量');
            $code = $last_record['code']+1;
        }
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());

        if(!$id){
            //新增
            $result = $this->Zjys_activity_model->add_treasure_activity($args['name'],$code,$args['init_method'],$args['total'],$args['pay_per_max'],$args['pay_amount'],$args['pay_asset'],$args['unaward_rule'],$args['award_type'],$args['award'],$args['award_detail'],$args['award_img'],$args['start_time'],$args['end_time'],$args['day_start_time'],$args['day_end_time'],$args['finished'],$args['site_id'],$created_at,$updated_at);
        }else{
            //修改
            $this->Zjys_activity_model->edit_treasure_activity($args['name'],$code,$args['init_method'],$args['total'],$args['pay_per_max'],$args['pay_amount'],$args['pay_asset'],$args['unaward_rule'],$args['award_type'],$args['award'],$args['award_detail'],$args['award_img'],$args['start_time'],$args['end_time'],$args['day_start_time'],$args['day_end_time'],$args['finished'],$args['site_id'],$updated_at,$id);
        }
        return true;
    }

    public function delete($id){
        return $this->Zjys_activity_model->delete($id);
    }

    public function treasure_activity_end($args){
        $id = $args['id'];
        $finished = $args['finished'];
        $detail = $this->Zjys_activity_model->get_detail($id);
        if($finished == $detail['finished']) returnJson('402','状态非法');

        return $this->Zjys_activity_model->treasure_activity_end($finished,$id);
    }

    public function treasure_activity_delete($args){
        $id = $args['id'];
        if($args['is_display']==0){
            $is_display = 0;
        }else{
            $is_display = 1;
        }
        return $this->Zjys_activity_model->treasure_activity_delete($is_display,(int)$id);
        // $this->Zjys_activity_model->treasure_activity_delete($is_display,(int)$id);
        // var_dump($this->db->last_query());die;
    }


    public function treasure_logs_activity_list($offset,$limit,$is_winning,$award_sent,$start_time,$end_time,$treasures_session_logs_code,$site_id,$id){
        if($treasures_session_logs_code!='')
        {
            $code = explode('-', $treasures_session_logs_code);
            $treasuredetail = $this->Zjys_activity_model->get_detail_bycode($code[0]);
            $sessiondetail = $this->Zjys_activity_model->get_session_by_code_id($treasuredetail['id'],$code[1]);
            // var_dump($this->db->last_query());die;
            $treasurelogsdetail = $this->Zjys_activity_model->get_treasure_session($sessiondetail['id'],$code[2]);
            $list[0] = $treasurelogsdetail;
            // var_dump($list);die;
        }else{
            $object = $this->db->select("user_treasure_logs.*,b_site.name as site_name")
                ->join('b_site','b_site.id=user_treasure_logs.site_id','left')
                ->join('treasure_sessions','treasure_sessions.id=user_treasure_logs.session_id','left')
                ->join('treasures','treasures.id=treasure_sessions.treasure_id','left')
                ->from('user_treasure_logs');
            $object =$this->db->where('user_treasure_logs.deleted_at =',null);
            $object =$this->db->where('treasures.id =',$id);
            if($site_id!='') $object =$this->db->where('user_treasure_logs.site_id = ',$site_id);
            if($is_winning!=''){
                $object =$this->db->where('user_treasure_logs.is_winning =',$is_winning);
            }
            if($award_sent!=''){
                $object =$this->db->where('user_treasure_logs.award_sent =',$award_sent);
            }
            
            if(!empty($start_time)){
                $object =$this->db->where('user_treasure_logs.award_sent_time >=',$start_time);
            }
            if(!empty($end_time)){
                $object =$this->db->where('user_treasure_logs.award_sent_time <',$end_time);
            }
            $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
            // var_dump($this->db->last_query());die;
        }
        foreach ($list as &$value) {
            $value['treasures_session_logs_code'] = $this->get_treasure_session($value['session_id']).'-'.$value['code'];
        }
        return $list;
    }

    public function treasure_logs_activity_listcount($is_winning,$award_sent,$start_time,$end_time,$treasures_session_logs_code,$site_id,$id){
        if($treasures_session_logs_code!='')
        {
            return 1;
        }else{
            $object = $this->db->select("user_treasure_logs.*,b_site.name as site_name")
                ->join('b_site','b_site.id=user_treasure_logs.site_id','left')
                ->join('treasure_sessions','treasure_sessions.id=user_treasure_logs.session_id','left')
                ->join('treasures','treasures.id=treasure_sessions.treasure_id','left')
                ->from('user_treasure_logs');
            $object =$this->db->where('user_treasure_logs.deleted_at =',null);
            $object =$this->db->where('treasures.id =',$id);
            if($site_id!='') $object =$this->db->where('user_treasure_logs.site_id = ',$site_id);
            if($is_winning!=''){
                $object =$this->db->where('user_treasure_logs.is_winning =',$is_winning);
            }
            if($award_sent!=''){
                $object =$this->db->where('user_treasure_logs.award_sent =',$award_sent);
            }
            
            if(!empty($start_time)){
                $object =$this->db->where('user_treasure_logs.award_sent_time >=',$start_time);
            }
            if(!empty($end_time)){
                $object =$this->db->where('user_treasure_logs.award_sent_time <',$end_time);
            }
            return $this->db->count_all_results();
        }
    }



    public function get_treasure_session($session_id)
    {
        // var_dump($session_id);die;
        $session_detail = $this->Zjys_activity_model->get_session_detail($session_id);
        // var_dump($session_detail);die;
        $session_code = $session_detail['code'];
        $treasures_id = $session_detail['treasure_id'];
        // var_dump($treasures_id);die;
        $treasure_detail = $this->Zjys_activity_model->get_detail($treasures_id);
        $treasures_code = $treasure_detail['code'];
        return $treasures_code.'-'.$session_code;
    }

    //活动明细
    public function user_award_list($offset,$limit,$start_time,$end_time,$activity_id,$is_lock,$site_id,$user_id){
        $detail = $this->Zjys_activity_model->get_info($activity_id);
        // var_dump($detail);die;
        if(is_array($detail) && empty($detail)) returnJson('402','id非法');
        
        $object = $this->db->select("user_awards.*,users.phone,users.email,b_site.name as site_name,user_recommends.user_id as top_user_id")
            ->join('users','user_awards.user_id=users.id','left')
            ->join('b_site','user_awards.site_id=b_site.id','left')
            ->join('user_recommends','user_awards.user_id=user_recommends.recommend_user_id','left')
            ->from('user_awards');
        $object =$this->db->where('user_awards.deleted_at =',null);
        $object =$this->db->where('user_awards.activity_unique like',$activity_id.'_'.$detail['event'].'%');
        if(!empty($start_time)){
            $object =$this->db->where('user_awards.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_awards.created_at <',$end_time);
        }

        if($site_id!='') $object =$this->db->where('user_awards.site_id = ',$site_id);
        if($is_lock!='') $object =$this->db->where('user_awards.is_locked =',$is_lock);
        if($user_id!='') $object =$this->db->where('user_awards.user_id =',$user_id);

        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        
        // var_dump($this->db->last_query());die;
        // var_dump($list);die;
        foreach ($list as &$value) {
            if($value['type']==0) $value['type_status'] = '注册奖励';
            if($value['type']==1) $value['type_status'] = '实名奖励';
            if($value['type']==6) $value['type_status'] = '注册上级奖励';
            if($value['type']==7) $value['type_status'] = '注册二级奖励';
            if($value['type']==8) $value['type_status'] = '实名上级奖励';
            if($value['type']==9) $value['type_status'] = '实名二级奖励';
        }
        return $list;
    }

    public function user_award_listcount($start_time,$end_time,$activity_id,$is_lock,$site_id,$user_id){
        $detail = $this->Zjys_activity_model->get_info($activity_id);
        if(is_array($detail) && empty($detail)) returnJson('402','id非法');
        $object = $this->db->select("user_awards.*,users.phone,users.email,b_site.name as site_name")
            ->join('users','user_awards.user_id=users.id','left')
            ->join('b_site','user_awards.site_id=b_site.id','left')
            ->from('user_awards');
        $object =$this->db->where('user_awards.deleted_at =',null);
        $object =$this->db->where('user_awards.activity_unique like',$activity_id.'_'.$detail['event'].'%');
        if($site_id!='') $object =$this->db->where('user_awards.site_id = ',$site_id);
        if($is_lock!='') $object =$this->db->where('user_awards.is_locked =',$is_lock);
        if($user_id!='') $object =$this->db->where('user_awards.user_id =',$user_id);
        if(!empty($start_time)){
            $object =$this->db->where('user_awards.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_awards.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 活动解锁
     * User: 张哲
     * Date: 2019/3/1
     * Time: 11:42
     */
    public function activity_unlock_list($start_time,$end_time,$offset,$limit,$asset,$site_id,$uid){
        $object = $this->db->select("activity_unlock.*")
            ->from('activity_unlock');
        $object =$this->db->where('activity_unlock.deleted_at is null');
        if($asset!='') $object =$this->db->where('activity_unlock.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('activity_unlock.site_id = ',$site_id);
        if($uid!='') $object =$this->db->where('activity_unlock.site_id = ',$uid);
        if(!empty($start_time)){
            $object =$this->db->where('activity_unlock.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('activity_unlock.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    /**
     * Notes: 活动解锁数量
     * User: 张哲
     * Date: 2019/3/1
     * Time: 11:42
     */
    public function activity_unlock_list_count($start_time,$end_time,$asset,$site_id,$uid){
        $object = $this->db->select("activity_unlock.*")
            ->from('activity_unlock');

        $object =$this->db->where('activity_unlock.deleted_at is null');
        if($asset!='') $object =$this->db->where('activity_unlock.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('activity_unlock.site_id = ',$site_id);
        if($uid!='') $object =$this->db->where('activity_unlock.site_id = ',$uid);
        if(!empty($start_time)){
            $object =$this->db->where('activity_unlock.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('activity_unlock.created_at <=',$end_time);
        }

        return $this->db->count_all_results();
    }


    /**
     * Notes: 解锁导出
     * User: 张哲
     * Date: 2019/3/1
     * Time: 12:52
     */
    public function activity_unlock_csv($start_time,$end_time,$asset,$site_id){
        $object = $this->db->select("activity_unlock.*")
            ->from('activity_unlock');
        $object =$this->db->where('activity_unlock.deleted_at is null');
        if($asset!='') $object =$this->db->where('activity_unlock.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('activity_unlock.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('activity_unlock.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('activity_unlock.created_at <=',$end_time);
        }

        $list = $object->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    /**
     * Notes: 活动币解锁
     * User: 张哲
     * Date: 2019/2/28
     * Time: 21:54
     */
    public function activity_unlock($args)
    {
        //先看用户是否存在
        $user_id = $args['uid'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out))  returnJson('300',lang('user_id not exist'));
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $amount_neg = "-".$amount;
        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());
        //查看活动锁仓表是否有该数据
        $asset_uid = $this->Zjys_user_model->asset_uid($user_id);
        if($asset_uid ==null) returnJson('300',lang('unlock activity is not'));
        //获取活动表，当前用户最后一条记录币种的数量
        $balance = $this->Zjys_user_model->user_asset_operatings_balance($user_id,$asset);
        if($balance['balance'] < $amount) returnJson('300',lang('unlock money is not'));

        //插入解锁表
        $bussness_id = $this->Activity_unlock_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id);
        $this->db->trans_begin();
        if(!empty($bussness_id)){
            //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
            $bussness = 'admin_activity_unlock';
            $remark_add = array('info'=>$args['uid'],'remark'=>$remark);
            $remark_add = json_encode($remark_add);
            $remark1 = array('info'=>intval($args['uid']),'remark'=>$remark);
            $remark1 = json_encode($remark1);
            //记录表扣除
            $data = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],1,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);
            //余额表增加
            $data1 = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark1,$remark);
            $trans_status = $this->db->trans_status();
            if($data['code'] != 0  || $data1['code'] != 0 )
            {
                $trans_status = false;
            }
            if ($trans_status === false) {
                $this->db->trans_rollback();
                return $args;
            } else {
                $this->db->trans_commit();
                return true;
            }


        }
    }

    /**
     * Notes: 活动批量解锁
     * User: 张哲
     * Date: 2019/2/28
     * Time: 22:18
     * @param $args
     * @return bool
     */
    public function batch_activity_unlock($args,$sum,$site_id)
    {
        //先看用户是否存在
        $user_id = $args['uid'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out))  returnJson('300',lang('user_id not exist'));
        $site_id = $site_id;
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $amount_neg = "-".$amount;
        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());
        //查看活动锁仓表是否有该数据
        $asset_uid = $this->Zjys_user_model->asset_uid($user_id);
        if($asset_uid ==null) returnJson('300',lang('unlock activity is not'));

        $balance = $this->Zjys_user_model->user_asset_operatings_balance($user_id,$asset);
        if($balance['balance'] < $amount) returnJson('300',lang('unlock money is not'));

        $this->db->trans_begin();
        //插入解锁表
        $bussness_id = $this->Activity_unlock_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id);

        if(!empty($bussness_id)){
            //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
            $bussness = 'admin_activity_unlock';
            $remark_add = array('info'=>$args['uid'],'remark'=>$remark);
            $remark_add = json_encode($remark_add);
            $remark1 = array('info'=>intval($args['uid']),'remark'=>$remark);
            $remark1 = json_encode($remark1);
            //记录表扣除
            $data = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],1,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);
            //余额表增加
            $data1 = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark1,$remark);
            $trans_status = $this->db->trans_status();
            if($data['code'] != 0 || $data1['code'] != 0)
            {
                $trans_status = false;
            }
            if ($trans_status === false) {
                $this->db->trans_rollback();
                return $args;
            } else {
                $this->db->trans_commit();
                return true;
            }
        }
    }


    /**
     * Notes: 活动锁批量解锁实例文件
     * User: 张哲
     * Date: 2019/3/8
     * Time: 15:31
     * @return mixed
     */
    public function activity_unlock_sample_csv(){
        $object = $this->db->select("activity_unlock_record_sample.*")
            ->from('activity_unlock_record_sample');
        $list = $object->order_by('id','desc')->get()->result_array();
        return $list;
    }


}
