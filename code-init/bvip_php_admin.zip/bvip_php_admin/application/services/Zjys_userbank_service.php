<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_userbank_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        // $this->load->model('Zjys_user_withdraw_model');
        // $this->load->model('Zjys_user_withdraw_freezes_model');    
        // $this->load->model('Zjys_assets_model');    
        // $this->load->model('Zjys_merchantbank_model');    
    }   

    //币资产种类
    public function userbank_list($offset,$limit,$name,$code,$pre_phone,$start_time,$end_time,$site_id,$realname){
        $object = $this->db->select("user_banks.*,b_site.name as site_name,users.phone,users.email")
            ->join('users','users.id=user_banks.user_id','left')
            ->join('user_identities','user_banks.user_id=user_identities.user_id','left')
            ->join('b_site','b_site.id=users.site_id','left')
            ->from('user_banks');
        if($site_id!=1) $object =$this->db->where('users.site_id = ',$site_id);
            $object =$this->db->where('users.deleted_at is null');
        if(!empty($name)){
            $object =$this->db->where('user_banks.name =',$name);
        }
        if(!empty($code)){
            $object =$this->db->where('user_banks.card_number =',$code);
        }
        if(!empty($realname)){
            if(WSTIsPhone($realname)){
                $object =$this->db->where('users.phone = ',$realname);
            }else{
                $object =$this->db->where('users.email = ',$realname);
            }
        }

        if(!empty($start_time)){
            $object =$this->db->where('user_banks.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_banks.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();

        // var_dump($list);die;
        // var_dump($list);die;
        // foreach ($list as &$value) {
        //     # code...
        //     if($value['recharge_status'] == 1){
        //         $value['recharge_status'] = 1;
        //     }else{
        //         $value['recharge_status'] = 0;
        //     }
        //     if($value['withdraw_status'] == 1){
        //         $value['withdraw_status'] = 1;
        //     }else{
        //         $value['withdraw_status'] = 0;
        //     }
        //     if($value['trade_status'] == 1){
        //         $value['trade_status'] = 1;
        //     }else{
        //         $value['trade_status'] = 0;
        //     }
        // }
        return $list;
    }
    //
    public function userbank_list_count($name,$code,$pre_phone,$start_time,$end_time,$site_id,$realname){
        $object = $this->db->select("user_banks.*,b_site.name as site_name,users.phone,users.email")
            ->join('users','users.id=user_banks.user_id','left')
            ->join('user_identities','user_banks.user_id=user_identities.user_id','left')
            ->join('b_site','b_site.id=users.site_id','left')
            ->from('user_banks');
        if($site_id!=1) $object =$this->db->where('users.site_id = ',$site_id);
            $object =$this->db->where('users.deleted_at is null');
        if(!empty($name)){
            $object =$this->db->where('user_banks.name =',$name);
        }
        if(!empty($code)){
            $object =$this->db->where('user_banks.card_number =',$code);
        }
        if(!empty($realname)){
            if(WSTIsPhone($realname)){
                $object =$this->db->where('users.phone = ',$realname);
            }else{
                $object =$this->db->where('users.email = ',$realname);
            }
        }

        if(!empty($start_time)){
            $object =$this->db->where('user_banks.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_banks.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }



    //添加、编辑币种类
    // public function addbank($args)
    // {

    //     $id = isset($args['id']) ? $args['id']: '';
    //     $name = isset($args['name']) ? $args['name']: '';//资产码
    //     $bank = isset($args['bank']) ? $args['bank']: '';//资产名称
    //     $sub_bank = isset($args['sub_bank']) ? $args['sub_bank']: '';
    //     $card_number = isset($args['card_number']) ? $args['card_number']: '';
    //     // $trade_status = isset($args['trade_status']) ? $args['trade_status']: '';
    //     // $withdraw_fee = isset($args['withdraw_fee']) ? $args['withdraw_fee']: '';
    //     $created_at = date("Y-m-d H:i:s",time());
    //     $updated_at = date("Y-m-d H:i:s",time());
    //     if(!$id){
    //         //新增
    //         $result = $this->Zjys_merchantbank_model->addbank($name,$bank,$sub_bank,$card_number,$created_at,$updated_at);
    //         // var_dump($result);die;
    //     }else{
    //         //修改
    //         $this->Zjys_merchantbank_model->editbank($name,$bank,$sub_bank,$card_number,$updated_at,$id);
    //     }
    //     return true;
    // }

    // public function list_all(){
    //     // echo 5;die;
    //     return $this->Zjys_assets_model->list_all();
    // }

   




}
