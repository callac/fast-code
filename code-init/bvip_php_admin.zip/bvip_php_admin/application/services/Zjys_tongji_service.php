<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//set_time_limit(0);
class Zjys_tongji_service extends MY_Service{


    public function __construct()
    {
        parent::__construct();
        $this->load->model('Site_model');
        $this->load->model('Zjys_symbols_model');
        $this->load->model('Config_model');
        $this->load->model('Tongji_model');
        $this->load->model('Perday_holdcoin_statistics_model');
        $this->load->model('Zjys_user_model');
        $this->trade_db = $this->load->database('trade_history',true);

    }
    //用户统计
    public function get_login_numbers($args)
    {
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_REGISTER);
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        $siteList = $this->Site_model->site_all();
        $newarr = [];
        foreach ($siteList as $k => $v) {
            $newarr['site_id'] = $v['id'];
            $newarr['time_area'] = date('Y-m-d',$start_time);
            $newarr['time'] = date('Y-m-d H:i:s',$start_time);
            //今日注册
            $newarr['register'] = $this->register_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //今日完成认证
            $newarr['registerauth'] = $this->registerauth_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //今日推荐
            $newarr['recommend'] = $this->recommend_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            // 今日注册且完成
            $newarr['recommendby'] = $this->identity_auth($start_time,$end_time,$v['id'],$tongi_arr);

            $newarr['active_amount'] = $this->active_amount($start_time,$end_time,$v['id'],$tongi_arr);

            $result = $this->Tongji_model->add_register_data($newarr['site_id'],$newarr['time_area'],$newarr['time'],$newarr['register'],$newarr['registerauth'],$newarr['recommend'],$newarr['recommendby'],$newarr['active_amount']);
        }
    }

    //计算并生成去重数据的运营数据
    public function deduplication_data($args)
    {
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_CLEAR_REPEAT);
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        $siteList = $this->Site_model->site_all(); 
        $newarr = [];
        foreach ($siteList as $k => $v) {
            $newarr['name'] = $v['name'];
            $newarr['site_id'] = $v['id'];
            $newarr['time_area'] = date('Y-m-d',$start_time);
            $newarr['time'] = date('Y-m-d H:i:s',$start_time);
            //注册人数
            $newarr['register_usernumbers_perday'] = $this->register_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //邀请注册人数
            $newarr['recommend_usernumbers_perday'] = $this->recommend_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //认证通过人数
            $newarr['identity_usernumbers_perday'] = $this->identity_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //法币交易人数
            $newarr['c2corder_usernumbers_perday'] = $this->c2corder_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //充值人数
            $newarr['recharge_usernumbers_perday'] = $this->recharge_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //提币人数
            $newarr['withdraw_usernumbers_perday'] = $this->withdraw_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //币币交易的人数
            $newarr['tradeuser_perday'] = $this->tradeuser_perday($start_time,$end_time,$v['id'],$tongi_arr);

            $last_data = $this->Tongji_model->last_data();

            if(is_array($last_data) && !empty($last_data)){
                $newarr['register_usernumbers_perday_total'] = $newarr['register_usernumbers_perday'] + (int)$last_data['register_total'];
                $newarr['recommend_usernumbers_perday_total'] =$newarr['recommend_usernumbers_perday'] + (int)$last_data['invite_register_total'];
                $newarr['identity_usernumbers_perday_total'] = $newarr['identity_usernumbers_perday'] + (int)$last_data['trunname_total'];
                $newarr['c2corder_usernumbers_perday_total'] = $newarr['c2corder_usernumbers_perday'] + (int)$last_data['c2c_trade_total'];
                $newarr['recharge_usernumbers_perday_total'] = $newarr['recharge_usernumbers_perday'] + (int)$last_data['recharge_total'];
                $newarr['withdraw_usernumbers_perday_total'] = $newarr['withdraw_usernumbers_perday'] + (int)$last_data['withdraw_total'];
                $newarr['tradeuser_perday_total'] = $newarr['tradeuser_perday'] + (int)$last_data['coin_trade_total'];
            }else{
                $newarr['register_usernumbers_perday_total'] = $newarr['register_usernumbers_perday'];
                $newarr['recommend_usernumbers_perday_total'] =$newarr['recommend_usernumbers_perday'];
                $newarr['identity_usernumbers_perday_total'] = $newarr['identity_usernumbers_perday'];
                $newarr['c2corder_usernumbers_perday_total'] = $newarr['c2corder_usernumbers_perday'];
                $newarr['recharge_usernumbers_perday_total'] = $newarr['recharge_usernumbers_perday'];
                $newarr['withdraw_usernumbers_perday_total'] = $newarr['withdraw_usernumbers_perday'];
                $newarr['tradeuser_perday_total'] = $newarr['tradeuser_perday'];
            }
            //入库
            $result = $this->Tongji_model->add_deduplication_data($newarr['site_id'],$newarr['time_area'],$newarr['time_area'],$newarr['register_usernumbers_perday'],$newarr['recommend_usernumbers_perday'],$newarr['identity_usernumbers_perday'],$newarr['c2corder_usernumbers_perday'],$newarr['recharge_usernumbers_perday'],$newarr['withdraw_usernumbers_perday'],$newarr['tradeuser_perday'],$newarr['register_usernumbers_perday_total'],$newarr['recommend_usernumbers_perday_total'],$newarr['identity_usernumbers_perday_total'],$newarr['c2corder_usernumbers_perday_total'],$newarr['recharge_usernumbers_perday_total'],$newarr['withdraw_usernumbers_perday_total'],$newarr['tradeuser_perday_total'],$newarr['time'],$newarr['time_area']);
        }
    }


    //  每日登录用户统计
    public function login_numbers($start_time,$end_time,$site_id)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(user_id) as numrows")
        ->from('user_logins')
        ->where('created_at>',$start_time)
        ->where('created_at<',$end_time)
        ->where('site_id=',$site_id)
        ->group_by('user_id');
        return $this->db->count_all_results();
    }

    public function register_numbers($start_time,$end_time,$site_id,$tongi_arr)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(1) as numrows")
        ->from('users')
        ->where('created_at>',$start_time)
        ->where('created_at<',$end_time)
        ->where('site_id=',$site_id)
        ->where_not_in('users.id',$tongi_arr);
        return $this->db->count_all_results();
    } 
    //
    public function registerauth_numbers($start_time,$end_time,$site_id,$tongi_arr)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(1) as numrows")
        ->join('users','users.id=user_identities.user_id','left')
        ->from('user_identities')
        ->where('user_identities.updated_at>',$start_time)
        ->where('user_identities.updated_at<',$end_time)
        ->where('users.site_id=',$site_id)
        ->where('user_identities.status=',2)
        ->where('user_identities.deleted_at is null')
        ->where_not_in('users.id',$tongi_arr);
        return $this->db->count_all_results();
    }
    //今日推荐人数
    public function recommend_numbers($start_time,$end_time,$site_id,$tongi_arr)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(1) as numrows")
            ->join('users','users.id=user_recommends.recommend_user_id','left')
            ->from('user_recommends')
            ->where('users.created_at>',$start_time)
            ->where('users.created_at<',$end_time)
            ->where('users.site_id=',$site_id)
            ->where_not_in('users.id',$tongi_arr);
        return $this->db->count_all_results();
    }
    
    // public function recommendby_numbers($start_time,$end_time,$site_id)
    // {
    //     $start_time = date('Y-m-d H:i:s',$start_time);
    //     $end_time = date('Y-m-d H:i:s',$end_time);
    //     $object = $this->db->select("count(1) as numrows")
    //     ->join('users','users.id=user_recommends.recommend_user_id','left')
    //     ->from('user_recommends')
    //     ->where('users.created_at>',$start_time)
    //     ->where('users.created_at<',$end_time)
    //     ->where('users.site_id=',$site_id)
    //     ->where('status',1);
    //     return $this->db->count_all_results();
    // }
    //当日注册且认证
    public function identity_auth($start_time,$end_time,$site_id,$tongi_arr)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(1) as numrows")
        ->join('user_identities','user_identities.user_id=users.id','left')
        ->from('users')
        ->where('user_identities.created_at>',$start_time)
        ->where('user_identities.created_at<',$end_time)
        ->where('users.created_at>',$start_time)
        ->where('users.created_at<',$end_time)
        ->where('users.site_id=',$site_id)
        ->where('user_identities.status',2)
        ->where_not_in('users.id',$tongi_arr);
        
        return $this->db->count_all_results();
    }

    //当日活跃用户（计最后登陆用户停留在当日）
    public function active_amount($start_time,$end_time,$site_id,$tongi_arr)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(1) as numrows")
        ->from('users')
        ->where('users.last_login>=',$start_time)
        ->where('users.last_login<',$end_time)
        ->where_not_in('users.id',$tongi_arr);
        return $this->db->count_all_results();
    }


    //累计认证人数
    public function identity_numbers($start_time,$end_time,$site_id,$tongi_arr){
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(1) as numrows")
        ->join('users','users.id=user_identities.user_id','left')
        ->where_not_in('users.id',$tongi_arr)
        ->from('user_identities')
        ->where('user_identities.created_at>=',$start_time)
        ->where('user_identities.created_at<',$end_time)
        ->where('users.site_id=',$site_id)
        ->where('user_identities.deleted_at is null')
        ->group_by('user_id');
        return $this->db->count_all_results();
    }

    //法币交易人数
    public function c2corder_numbers($start_time,$end_time,$site_id,$tongi_arr){
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("id")
        ->from('c2c_orders')
        ->where('created_at>=',$start_time)
        ->where('created_at<',$end_time)
        ->where_not_in('c2c_orders.user_id',$tongi_arr)//
        ->where('site_id=',$site_id)
        ->where('deleted_at is null')
        ->group_by('user_id');
        return $this->db->count_all_results();
    }
    //充值人数
    public function recharge_numbers($start_time,$end_time,$site_id,$tongi_arr){
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(1) as numrows")
        ->from('user_recharge_logs')
        ->join('users','users.id=user_recharge_logs.user_id','left')
        ->where('users.created_at>=',$start_time)
        ->where_not_in('users.id',$tongi_arr)//
        ->where('users.created_at<',$end_time)
        ->where('users.deleted_at is null')
        ->where('users.site_id='.$site_id)
        ->group_by('user_id');
        return $this->db->count_all_results();
    }



    public function tradeuser_perday($start_time,$end_time,$site_id,$tongi_arr)
    {
        set_time_limit(0);
        if(count($tongi_arr) == 0){
            $tongi_arr = 0;
        }else{
            $tongi_arr = implode(',',$tongi_arr);
        }
        //可以用线上只读库
        $DB1 = $this->load->database('trade_history',true);
        for ($i=0; $i < 100; $i++) {  
            $sql = "select user_id from order_history_".$i." where finish_time >".$start_time." and user_id not in(".$tongi_arr.")"." and finish_time <".$end_time." and source='web,".$site_id."' group by user_id";
            $object = object_to_array($DB1->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }  
        return count($new);
    }





    //获取交易量的统计
    public function tradetotal($args)
    {
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_COIN_POSITION);
        if(count($tongi_arr) == 0){
            $tongi_arr = 0;
        }else{
            $tongi_arr = implode(',',$tongi_arr);
        }
        $DB1 = $this->load->database('trade_history',true);
        $siteList = $this->Site_model->site_all();
        $res = [];
        foreach ($siteList as $k => $v) { //站点
            $symbolList = $this->Zjys_symbols_model->list_all_siteid($v['id']);
            // var_dump($this->db->last_query());die;
            // var_dump($symbolList);die;
            foreach ($symbolList as $key => $value) {
                for ($i=0; $i < 100; $i++) {
                    $sql = "select  sum(deal_money) as totalmoney,user_id,market,count(id) as number from order_history_".$i." where market='".$value['symbol']."' and source='web,".$v['id']."' and finish_time >=".$start_time." and user_id not in(".$tongi_arr.")"." and finish_time <".$end_time."";
                    $object = object_to_array($DB1->query($sql)->result());
                    if($i==0){
                        $new = array_merge(array(),$object);
                    }else{
                        @$new = &array_merge($new,$object);
                    }
                }
                $sum = 0;
                $number = 0;
                foreach($new as $ii => $item){
                    $sum += $item['totalmoney'];
                    $number += $item['number'];
                } 

                for ($i=0; $i < 100; $i++) { 
                    $sql = "select id from order_history_".$i." where market='".$value['symbol']."' and source='web,".$v['id']."' and finish_time >=".$start_time." and user_id not in(".$tongi_arr.")"." and finish_time <".$end_time." group by user_id";
                    $object = object_to_array($DB1->query($sql)->result());
                    // var_dump($this->db->last_query());die;
                    if($i==0){
                        $people = array_merge(array(),$object);
                    }else{
                        @$people = &array_merge($people,$object);
                    }
                }



                $res['time_area'] =  date('Y-m-d',$start_time);
                $res['time'] =  date('Y-m-d',$start_time);
                $res['symbol'] =  $value['symbol'];
                $res['total'] =  $sum;//总交易量
                $res['people'] =  count($people);//交易人次
                $res['site_id'] =  $v['id'];
                $res['number'] =  $number; //交易笔数
                $res['BID_fee'] =  $this->get_bid_fee($value['symbol'],2,$start_time,$end_time,$v['id'],$tongi_arr);//BID买入手续费（收ZG）
                $res['ASK_fee'] =  $this->get_bid_fee($value['symbol'],1,$start_time,$end_time,$v['id'],$tongi_arr);//ASK卖出（收CNZ）
                
                if($res['people'] == 0){
                    $res['averge'] = 0; 
                }else{
                    if($res['total'] == 0 || $res['people'] == 0){
                        $res['averge'] = 0; //人均交易额
                    }else{
                        $res['averge'] = bcdiv((string)$res['total'], (string)$res['people'],8); //人均交易额
                    }

                }
                // var_dump($res);die;
                $this->Tongji_model->add_cointrade($res['site_id'],$res['time_area'],$res['time'],$res['symbol'],$res['total'],$res['number'],$res['people'],$res['BID_fee'],$res['ASK_fee'],$res['averge']); 
            }
        }
    }

    public function get_bid_fee($symbol,$side,$start_time,$end_time,$site_id,$tongi_arr)
    {

        for ($i=0; $i < 100; $i++) { 
            $sql = "select  sum(deal_fee) as totalfee,user_id,market from order_history_".$i." where market='".$symbol."' and `side`=".$side." and source='web,".$site_id."' and finish_time >=".$start_time." and user_id not in(".$tongi_arr.")"." and finish_time <".$end_time."";
            // var_dump($sql);die;
            $object = object_to_array($this->trade_db->query($sql)->result());
            if($i==0){
                $new1 = array_merge(array(),$object);
            }else{
                @$new1 = &array_merge($new1,$object);
            }
        }

        $sumfee = 0;
        foreach($new1 as $ii => $item){
            $sumfee += $item['totalfee'];
        }
        return $sumfee; 
    }

    //指定站点币种的列表
    public function rechargelogs($args)
    {
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_RECHARGEWITHDRAWAL);
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        $siteList = $this->Site_model->site_all();
        // $siteList = $this->Site_model->site_one(127);

        foreach ($siteList as $k => $v) { //站点
            $asset_list = $this->Zjys_assets_model->list_all($v['id']);
            foreach ($asset_list as $kk => $vv) { //币种
                $newarr['time_area'] = date('Y-m-d',$start_time);
                $newarr['asset_code'] = $vv['asset_code'];
                $newarr['time'] = date('Y-m-d H:i:s',$start_time);
                $newarr['site_id'] = $v['id'];
                //24小时充值数量
                $newarr['amount'] = $this->recharge_amount($start_time,$end_time,$v['id'],$vv['asset_code'],$tongi_arr);
                //当日收盘价格
                $newarr['price'] = $this->last_price($start_time,$end_time,$v['id'],$vv['asset_code']);
                //充值笔数
                $newarr['number'] = $this->recharge_numbers_per($start_time,$end_time,$v['id'],$vv['asset_code'],$tongi_arr);
                //充值人数
                $newarr['people'] = $this->recharge_people($start_time,$end_time,$v['id'],$vv['asset_code'],$tongi_arr);
                if($newarr['people']==0){
                    $newarr['averge'] = 0;
                }else{
                    $newarr['averge'] = bcdiv($newarr['amount'],$newarr['people'],12);//24小时该币种的充值数量
                }
                // var_dump($newarr);
                $this->Tongji_model->add_recharge_data($newarr['site_id'],$newarr['time_area'],$newarr['time'],$newarr['asset_code'],$newarr['amount'],$newarr['price'],$newarr['number'],$newarr['people'],$newarr['averge']);
                // var_dump($this->db->last_query());die; 
            }
        }
    }

    public function recharge_amount($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_recharge_logs.*,b_site.name as site_name")
        ->join('users','user_recharge_logs.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_recharge_logs')
        ->where_not_in('users.id',$tongi_arr);
        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('users.site_id=',$site_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);
        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        $list = $object->get()->result_array();
        $arr['total_amount'] = 0;
        if(is_array($list) && !empty($list)){
            foreach ($list as $key => $value) {
                $arr['total_amount']=bcadd($arr['total_amount'],$value['amount'],12);
            }
        }else{
            $arr['total_amount'] = 0;
        }
        // var_dump($arr['total_amount']);
        //查询该数据需去掉作市的用户
        $detail = $this->Config_model->get_mailconfig($tongji_type=3);
        if(empty($detail)){
            $nouser_totalamount = '0';
        }else{
            $uid = $detail['uid'];
            $uid_array = explode(',', $uid);
            $nouser_totalamount = '0';
            for($i=0;$i<count($uid_array);$i++){
                $no_user = $this->get_nouser($uid_array[$i],$start_time,$end_time,$asset_code);
                $nouser_totalamount = bcadd($nouser_totalamount, $no_user,12);
            }
        }
        return bcsub($arr['total_amount'], $nouser_totalamount,12);
    }

    public function get_nouser($user_id,$start_time,$end_time,$asset_code)
    {
        $object = $this->db->select("user_recharge_logs.*")
        ->from('user_recharge_logs');

        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('user_recharge_logs.user_id=',$user_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);

        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        $list = $object->get()->result_array();
        // var_dump($list);
        $arr['nouser_amount'] = '0';
        if(is_array($list) && !empty($list)){
            foreach ($list as $key => $value) {
                $arr['nouser_amount']=bcadd($arr['nouser_amount'],$value['amount'],12);
            }
        }else{
            $arr['nouser_amount'] = 0;
        }
        return $arr['nouser_amount'];
        // var_dump($arr['nouser_amount']);die;
    }
    //充值人数（除去后台配置的作市账户）
    public function recharge_people($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_recharge_logs.*,b_site.name as site_name")
        ->join('users','user_recharge_logs.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->where_not_in('users.id',$tongi_arr)
        ->from('user_recharge_logs');
        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('users.site_id=',$site_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);
        $object =$this->db->group_by('user_id');
        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        $total_people = $this->db->count_all_results();
        if($total_people==0){
            return 0;
        }
        // var_dump($total_people);

        //查询该数据需去掉作市的用户（tongji_type=3 表示充值类型需要去掉作市用户）
        $detail = $this->Config_model->get_mailconfig($tongji_type=3);
        if(empty($detail)){
            $nouser_totalpeople = 0;
        }else{
            $uid = $detail['uid'];
            $uid_array = explode(',', $uid);
            $nouser_totalpeople = count($uid_array);
        }
        
        return $total_people-$nouser_totalpeople;
    }


    //充值笔数（除去后台配置的作市账户）
    public function recharge_numbers_per($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_recharge_logs.*,b_site.name as site_name")
        ->join('users','user_recharge_logs.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->where_not_in('users.id',$tongi_arr)
        ->from('user_recharge_logs');
        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('users.site_id=',$site_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);
        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        $total_people = $this->db->count_all_results();
        if($total_people==0){
            return 0;
        }
        //查询该数据需去掉作市的用户（tongji_type=3 表示充值类型需要去掉作市用户）
        $detail = $this->Config_model->get_mailconfig($tongji_type=3);
        if(empty($detail)){
            $recharge_user = 0;
        }else{
            $uid = $detail['uid'];
            $uid_array = explode(',', $uid);
            //获取每个要去除用户充值的笔数
            $recharge_user = 0;
            foreach ($uid_array as $key => $value) {
                $number = $this->recharge_people_user($start_time,$end_time,$site_id,$asset_code,$value['id']);
                $recharge_user += $number;
            }
        }
        return $total_people-$recharge_user;
    }

    //提现笔数（除去后台配置的作市账户）
    public function withdraw_numbers_per($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_withdraws.*,b_site.name as site_name")
        ->join('b_site','b_site.id=user_withdraws.site_id','left')
        ->where_not_in('user_withdraws.user_id',$tongi_arr)
        ->from('user_withdraws');
        $object =$this->db->where('user_withdraws.deleted_at is null');
        $object =$this->db->where('user_withdraws.site_id=',$site_id);
        $object =$this->db->where('user_withdraws.asset=',$asset_code);

        if(!empty($start_time)){
            $this->db->where('user_withdraws.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_withdraws.created_at <',date('Y-m-d',$end_time));
        }
        return $this->db->count_all_results();
    }

    public function withdraw_numbers($start_time,$end_time,$site_id,$tongi_arr)
    {
        $object = $this->db->select("user_withdraws.*,b_site.name as site_name")
        ->join('b_site','b_site.id=user_withdraws.site_id','left')
        ->where_not_in('user_withdraws.user_id',$tongi_arr)//
        ->from('user_withdraws');
        $object =$this->db->where('user_withdraws.deleted_at is null');
        $object =$this->db->where('user_withdraws.site_id=',$site_id);
        $object =$this->db->group_by('user_withdraws.user_id');

        if(!empty($start_time)){
            $this->db->where('user_withdraws.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_withdraws.created_at <',date('Y-m-d',$end_time));
        }
        return $this->db->count_all_results();
    }

    //获取每个要去除用户充值的笔数
    public function recharge_people_user($start_time,$end_time,$site_id,$asset_code,$user_id){
        $object = $this->db->select("user_recharge_logs.*,b_site.name as site_name")
        ->join('users','user_recharge_logs.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_recharge_logs');
        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('users.site_id=',$site_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);
        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        return $this->db->count_all_results();
    }

    //获取当天币种的的收盘价格
    public function last_price($start_time,$end_time,$site_id,$asset_code){
        $baseasset = $this->config->item('C2C_ASSET');
        $DB1 = $this->load->database('trade_history',true);
        for ($i=0; $i < 100; $i++) {  
            $sql = "select finish_time,market,price from order_history_".$i." where finish_time >".$start_time." and finish_time <".$end_time." and source='web,".$site_id."' and market='".$asset_code.'_'.$baseasset."' order by id desc limit 1";
            // var_dump($sql);
            $object = object_to_array($DB1->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        if(is_array($new) && empty($new)) return 0;
        //给合并后的数组进行排序
        $sort = array(
            'direction' => 'SORT_DESC', //排序顺序标志 SORT_DESC 降序；SORT_ASC 升序
            'field'     => 'finish_time',       //排序字段
        );
        $new = mulsort($sort,$new);
        return $new[0]['price'];
    }

    public function csvlogs_add($tongji_type,$url,$created_at){
        $this->Config_model->csvlogs_add($tongji_type,$url,$created_at);
    }

    public function withdrawlogs($args)
    {
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_WITHDRAWAL);
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        $siteList = $this->Site_model->site_all();
        foreach ($siteList as $k => $v) { //站点
            $asset_list = $this->Zjys_assets_model->list_all($v['id']);
            foreach ($asset_list as $kk => $vv) { //币种
                $newarr['time_area'] = date('Y-m-d',$start_time);
                $newarr['asset_code'] = $vv['asset_code'];
                $newarr['site_id'] = $v['id'];
                $newarr['time'] = date('Y-m-d H:i:s',$start_time);
                $newarr['amount'] = $this->withdraw_amount($start_time,$end_time,$v['id'],$vv['asset_code']);
                //当日收盘价格
                $newarr['price'] = $this->last_price($start_time,$end_time,$v['id'],$vv['asset_code']);
                //充值笔数
                $newarr['number'] = $this->withdraw_numbers_per($start_time,$end_time,$v['id'],$vv['asset_code'],$tongi_arr);
                $newarr['people'] = $this->withdraw_people($start_time,$end_time,$v['id'],$vv['asset_code'],$tongi_arr);
                if($newarr['people']==0){
                    $newarr['averge'] = 0;
                }else{
                    $newarr['averge'] = bcdiv($newarr['amount'],$newarr['people'],12);//24小时该币种的充值数量
                } 
                $this->Tongji_model->add_withdraw_data($newarr['site_id'],$newarr['time_area'],$newarr['time'],$newarr['asset_code'],$newarr['amount'],$newarr['price'],$newarr['number'],$newarr['people'],$newarr['averge']);
            }
        }
    }

    public function withdraw_amount($start_time,$end_time,$site_id,$asset_code)
    {
        $object = $this->db->select("user_withdraws.*,b_site.name as site_name")
        ->join('b_site','b_site.id=user_withdraws.site_id','left')
        ->from('user_withdraws');
        $object =$this->db->where('user_withdraws.deleted_at is null');
        $object =$this->db->where('user_withdraws.site_id=',$site_id);
        $object =$this->db->where('user_withdraws.asset=',$asset_code);
        if(!empty($start_time)){
            $this->db->where('user_withdraws.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_withdraws.created_at <',date('Y-m-d',$end_time));
        }
        $list = $object->get()->result_array();
        // var_dump($list);
        $arr['total_amount'] = '0';
        // $arr['total_fee'] = '0';
        if(is_array($list) && !empty($list)){
            foreach ($list as $key => $value) {
                $arr['total_amount']=bcadd($arr['total_amount'],$value['amount'],12);
                // $arr['total_fee']=bcadd($arr['total_fee'],$value['fee'],12);
            }
            return $arr['total_amount'];
        }else{
            return $arr['total_amount'];
        }
        
    }
    //提现人数
    public function withdraw_people($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_withdraws.*,b_site.name as site_name")
        ->join('b_site','b_site.id=user_withdraws.site_id','left')
        ->where_not_in('user_withdraws.user_id',$tongi_arr)
        ->from('user_withdraws');
        $object =$this->db->where('user_withdraws.deleted_at is null');
        $object =$this->db->where('user_withdraws.site_id=',$site_id);
        $object =$this->db->where('user_withdraws.asset=',$asset_code);
        $object =$this->db->group_by('user_id');

        if(!empty($start_time)){
            $this->db->where('user_withdraws.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_withdraws.created_at <',date('Y-m-d',$end_time));
        }
        $total_people = $this->db->count_all_results();
        // var_dump($total_people);die;
        if($total_people==0){
            return 0;
        }
        return $total_people;
    }


    //法币买入卖出统计
    public function c2c_order($args){
        $type = isset($args['type']) ? $args['type'] :1;
        //type 1 m买 2 卖
        // var_dump($args);
        $start_time = get_last_day($args);
        // var_dump($start_time);die; 
        $end_time = $start_time+86400;
        //法币配置
        $asset_code = $this->config->item('C2C_ASSET');
        $siteList = $this->Site_model->site_all();
        if($type == 1){
            $tongji_type = TONGJI_TYPE_LAW_COIN_BY;
        }else{
            $tongji_type = TONGJI_TYPE_LAW_COIN_SELL;
        }
        $tongi_arr = $this->get_tongji_config_by_type($tongji_type);
        foreach ($siteList as $k => $v) { //站点
            $newarr['time_area'] = date('Y-m-d',$start_time);
            // $newarr['asset_code'] = $asset_code;
            $newarr['time'] = date('Y-m-d H:i:s',$start_time);
            $newarr['site_id'] = $v['id'];
            $newarr['order_total'] = $this->order_total($start_time,$end_time,$v['id'],$type,$status=false,$tongi_arr); //总下单数
            $newarr['finish_order_total'] = $this->order_total($start_time,$end_time,$v['id'],$type,$status=3,$tongi_arr); //完成订单数
            $newarr['people'] = $this->order_people($start_time,$end_time,$v['id'],$type,$tongi_arr); //总人数
            $detail = $this->order_amount($start_time,$end_time,$v['id'],$type,$status=3,$tongi_arr);
            if(is_array($detail) && !empty($detail)){
                $newarr['total_amount'] = $detail['total_amount']; //总交易金额
                $newarr['amount'] = $detail['amount']; //总交易量
                if($newarr['amount']==0){
                    $newarr['averge_price'] = 0; //交易均价
                }else{
                    $newarr['averge_price'] = bcdiv($newarr['total_amount'], $newarr['finish_order_total'],12); //交易均价
                }
            }else{
                $newarr['total_amount'] = 0;
                $newarr['amount'] = 0;
                $newarr['averge_price'] = 0;
            }
            if($newarr['order_total']==0)
                $newarr['finish_rate'] = 0;
            else
                $newarr['finish_rate'] = bcdiv($newarr['finish_order_total'], $newarr['order_total'],12);
            
            if($type==1)
                $this->Tongji_model->add_buy_data($newarr['site_id'],$newarr['time_area'],$newarr['time'],$newarr['order_total'],$newarr['finish_order_total'],$newarr['people'],$newarr['total_amount'],$newarr['amount'],$newarr['averge_price'],$newarr['finish_rate']);
            if($type==2)
                $this->Tongji_model->add_sell_data($newarr['site_id'],$newarr['time_area'],$newarr['time'],$newarr['order_total'],$newarr['finish_order_total'],$newarr['people'],$newarr['total_amount'],$newarr['amount'],$newarr['averge_price'],$newarr['finish_rate']);
        }
    }

    public function order_total($start_time,$end_time,$site_id,$type,$status,$tongi_arr){
        // echo 211;die;
            $object = $this->db->select("c2c_orders.*,b_site.name as site_name")
            ->join('b_site','b_site.id=c2c_orders.site_id','left')
            ->where_not_in('c2c_orders.user_id',$tongi_arr)
            ->from('c2c_orders');
            $object =$this->db->where('c2c_orders.deleted_at is null');
            $object =$this->db->where('c2c_orders.site_id=',$site_id);
            $object =$this->db->where('c2c_orders.type=',$type);

            if($status !== false) $object =$this->db->where('c2c_orders.status=',$status);
            
            // $object =$this->db->group_by('user_id');
            if($status === false){ //如果是取下单的数据以 updated_at时间为准
                if(!empty($start_time)){
                    $this->db->where('c2c_orders.updated_at >=',date('Y-m-d',$start_time));
                }
                if(!empty($end_time)){
                    $this->db->where('c2c_orders.updated_at <',date('Y-m-d',$end_time));
                }
            }else{ //如果是取完成单数以 process_time为准。审核操作会影响process_time
                if(!empty($start_time)){
                    $this->db->where('c2c_orders.process_time >=',date('Y-m-d',$start_time));
                }
                if(!empty($end_time)){
                    $this->db->where('c2c_orders.process_time <',date('Y-m-d',$end_time));
                }
            }
            
            return $this->db->count_all_results();
    }

    public function order_people($start_time,$end_time,$site_id,$type,$tongi_arr){
        $object = $this->db->select("c2c_orders.*,b_site.name as site_name")
        ->join('b_site','b_site.id=c2c_orders.site_id','left')
        ->where_not_in('c2c_orders.user_id',$tongi_arr)
        ->from('c2c_orders');
        $object =$this->db->where('c2c_orders.deleted_at is null');
        $object =$this->db->where('c2c_orders.site_id=',$site_id);
        $object =$this->db->where('c2c_orders.type=',$type);
        $object =$this->db->group_by('user_id');
        // $object =$this->db->group_by('user_id');
        if(!empty($start_time)){
            $this->db->where('c2c_orders.updated_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('c2c_orders.updated_at <',date('Y-m-d',$end_time));
        }
        return $this->db->count_all_results();
    }

    public function order_amount($start_time,$end_time,$site_id,$type,$status,$tongi_arr){
        // echo 211;die;
            $object = $this->db->select("c2c_orders.*,b_site.name as site_name")
            ->join('b_site','b_site.id=c2c_orders.site_id','left')
            ->where_not_in('c2c_orders.user_id',$tongi_arr)
            ->from('c2c_orders');
            $object =$this->db->where('c2c_orders.deleted_at is null');
            $object =$this->db->where('c2c_orders.site_id=',$site_id);
            $object =$this->db->where('c2c_orders.type=',$type);

            if($status !== false) $object =$this->db->where('c2c_orders.status=',$status);
            if(!empty($start_time)){
                $this->db->where('c2c_orders.updated_at >=',date('Y-m-d',$start_time));
            }
            if(!empty($end_time)){
                $this->db->where('c2c_orders.updated_at <',date('Y-m-d',$end_time));
            }
            $list = $object->get()->result_array();
            // var_dump($list);die;
            $arr['total_amount'] = '0';
            $arr['amount'] = '0';
            $arr['price'] = '0';
            // $arr['total_fee'] = '0';
            if(is_array($list) && !empty($list)){
                foreach ($list as $key => $value) {
                    $arr['total_amount']=bcadd($arr['total_amount'],$value['total_amount'],12); //总交易金额
                    $arr['amount']=bcadd($arr['amount'],$value['amount'],12); //总交易金额
                    $arr['price']=bcadd($arr['price'],$value['price'],12); //价格
                }
                // var_dump($arr['total_amount']);die;
                return $arr;
            }else{
                return $arr;
            }
    }



    public function trade_number($args)
    {
        $DB1 = $this->load->database('trade_history',true);
        for ($i=0; $i < 100; $i++) { 
            $sql = "select count(*) as total from (select count(*) from deal_history_".$i." group by deal_id) a ";
            $object = object_to_array($DB1->query($sql)->result());
            // var_dump($object);die;
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $sum = 0;
        foreach($new as $ii => $item){
            $sum += $item['total'];
        }
        return $sum;
    }

    /**
     * Notes: 用户持币占比
     * User: 张哲
     * Date: 2018/12/7
     * Time: 10:24
     * @param $args
     * @return int
     */
//    public function get_holdcoin_numbers($args)
//    {
//        //针对大数据处理
//        //向下取整点时间戳
//        if ($this->config->item('SITE') === 'priv_one') {
//            //获取所有币种
//            $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
//        } else {
//            $assetList = $this->Zjys_assets_model->get_systemassets();
//        }
//        foreach ($assetList as $key => $value) {
//
//            $asset = $value['asset_code'];
//            $time = date('Y-m-d H:i:s', time());
//            $sub = substr($time, 0, 14);
//            $new_time = $sub . "00:00";
//            $timestamp = strtotime($new_time);
//            $DB1 = $this->load->database('trade_log', true);
//            //先取用户及其币种数组
//            $sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " where asset = '$asset' group by user_id order by balance desc";
//            $object = object_to_array($DB1->query($sql)->result());
//            $new = array_merge(array(), $object);
//            $new = array_slice($new, 0, 1000);
//            // 取每种币的总额
//            $sql1 = "select asset,sum(balance) as total from slice_balance_" . $timestamp . " where asset = '$asset'";
//            $object1 = object_to_array($DB1->query($sql1)->result());
//            $new1 = array_merge(array(), $object1);
//
//            foreach ($new as $key => $value) {
//                foreach ($new1 as $key => $value1) {
//                    if ($value['asset'] == $value1['asset']) {
//                        $pop = round(doubleval($value['balance']) / doubleval($value1['total']), 10);
//                        $site_id = $this->Zjys_user_model->check_site_id($value['user_id']);
//                        $data1 = $this->Perday_holdcoin_statistics_model->get_data($value['user_id'], $value['asset']);
//                        if (!empty($data1['asset'])) {
//                            if (!empty($site_id['site_id'])) {
//                                $this->Perday_holdcoin_statistics_model->update($value['user_id'], $value['asset'], $value['balance'], $pop, $time, $site_id['site_id']);
//                            } else {
//                                $this->Perday_holdcoin_statistics_model->update($value['user_id'], $value['asset'], $value['balance'], $pop, $time, 1);
//                            }
//                        } else {
//                            if (!empty($site_id['site_id'])) {
//                                $this->Perday_holdcoin_statistics_model->add($value['user_id'], $value['asset'], $value['balance'], $pop, $time, $site_id['site_id']);
//                            } else {
//                                $this->Perday_holdcoin_statistics_model->add($value['user_id'], $value['asset'], $value['balance'], $pop, $time, 1);
//                            }
//                        }
//                    }
//                }
//            }
//        }
//
//    }

    public function get_holdcoin_numbers($args)
    {
        //向下取整点时间戳
        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
        } else {
            $assetList = $this->Zjys_assets_model->get_systemassets();
        }
        foreach ($assetList as $key => $value) {
            $asset = $value['asset_code'];
            $time = date('Y-m-d H:i:s', time());
            $sub = substr($time, 0, 14);
            $new_time = $sub . "00:00";
            $timestamp = strtotime($new_time);
            $DB1 = $this->load->database('trade_log', true);
            //先取用户及其币种数组
            $sql = "select user_id,asset,sum(balance) as balance from slice_balance_" . $timestamp . " where asset = '$asset' group by user_id order by balance desc";
            $object = object_to_array($DB1->query($sql)->result());
            $new = array_merge(array(), $object);
            $new = array_slice($new, 0, 1000);
            foreach ($new as $key => $value) {
                // 取每种币的总额
                $sql1 = "select asset,sum(balance) as total from slice_balance_" . $timestamp . " where asset = '$asset'";
                $object1 = object_to_array($DB1->query($sql1)->result());
                $new1 = array_merge(array(), $object1);
                $pop = round(doubleval($value['balance']) / doubleval($new1[0]['total']), 10);
                $site_id = $this->Zjys_user_model->check_site_id($value['user_id']);
                if (!empty($site_id['site_id'])) {
                    $site_id  = $site_id;
                }else{
                    $site_id = 1;
                }
                $this->Perday_holdcoin_statistics_model->add($value['user_id'], $value['asset'], $value['balance'], $pop, $time, $site_id['site_id']);
            }
        }
    }

    /*
     * @param  $type string
     * @return array
     */
    //运营统计数据剔除
    public function get_tongji_config_by_type($type){
        $arr = array(0);
        $result = $this->db->get_where('mail_tongji_config',array('tongji_type'=>$type))->row_array();
        if($result){
            $arr = explode(',',$result['uid']);
        }
        return $arr;
    }



}