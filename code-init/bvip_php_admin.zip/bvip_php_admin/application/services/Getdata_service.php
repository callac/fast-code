<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
set_time_limit(0);
ini_set('memory_limit','2048M');

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

class Getdata_service extends MY_Service{


    public function __construct()
    {
        parent::__construct();
        $this->load->model('Site_model');
        // $this->load->model('Zjys_symbols_model');
        $this->load->model('Config_model');
        $this->load->model('Tongji_model');
        $this->load->model('Zjys_symbols_model');
        $this->load->service('InOut_money_service');
        $this->load->model('Perday_holdcoin_statistics_model');
        $this->trade_db = $this->load->database('trade_history',true);
        // var_dump($otc_snapshot);die;

    }

    //计算并生成去重数据的运营数据
    public function deduplication_data($args,$exchange,$tradehistory,$local_exchange)
    {
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_CLEAR_REPEAT,$exchange);

        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        if(isset($args['site_id']) && !empty($args['site_id'])){
            $where = 'where id='.$args['site_id'];
        }else{
            $where = 'where 1 = 1';
        }

        $sql = 'select name,id from b_site '.$where;
        $siteList = $exchange->query($sql)->result_array(); 

        foreach ($siteList as &$value) {
            $value['time_area'] = date('Y-m-d',$start_time);
            $value['time'] = date('Y-m-d H:i:s',$start_time);
            $value['register_usernumbers_perday'] = 0;  //注册人数
            $value['recommend_usernumbers_perday'] = 0; //邀请注册人数
            $value['identity_usernumbers_perday'] = 0;  //认证通过人数
            $value['c2corder_usernumbers_perday'] = 0;  //法币交易人数
            $value['recharge_usernumbers_perday'] = 0;  //充值人数
            $value['withdraw_usernumbers_perday'] = 0;  //提现人数
            $value['tradeuser_perday'] = 0;  //币币交易人数
        }

        // var_dump($siteList);die;
        $register_result = $this->register_numbers($start_time,$end_time,$tongi_arr,$exchange);
        $recommend_result = $this->recommend_numbers($start_time,$end_time,$tongi_arr,$exchange);
        $identity_result = $this->identity_numbers($start_time,$end_time,$tongi_arr,$exchange);
        $c2corder_result = $this->c2corder_numbers($start_time,$end_time,$tongi_arr,$exchange);
        $recharge_result = $this->recharge_numbers($start_time,$end_time,$tongi_arr,$exchange);
        $withdraw_result = $this->withdraw_numbers($start_time,$end_time,$tongi_arr,$exchange);
        $tradeuser_result = $this->tradeuser_perday($start_time,$end_time,$tongi_arr,$exchange,$tradehistory);
        
        if(is_array($register_result) && !empty($register_result))
        {
            foreach ($siteList as $kk => $vv) {
                $arr[$kk] = $vv;
                foreach ($register_result as $k => $v) {
                    if($vv['id'] == $v['site_id'])
                    {
                        $arr[$kk]['register_usernumbers_perday'] = $v['numrows'];
                        break;
                    }
                }
            }
        }
        else
        {
            $arr = $siteList;
        }
        // var_dump($arr);die;  //组合成注册人数
        if(is_array($recommend_result) && !empty($recommend_result))
        {
            foreach ($arr as $kk => $vv) {
                $arr2[$kk] = $vv;
                foreach ($recommend_result as $k => $v) {
                    if($vv['id'] == $v['site_id'])
                    {
                        $arr2[$kk]['recommend_usernumbers_perday'] = $v['numrows'];
                        break;
                    }
                }
            }
        }
        else
        {
            $arr2 = $arr;
        }

        if(is_array($identity_result) && !empty($identity_result))
        {
            foreach ($arr2 as $kk => $vv) {
                $arr3[$kk] = $vv;
                foreach ($identity_result as $k => $v) {
                    if($vv['id'] == $v['site_id'])
                    {
                        $arr3[$kk]['identity_usernumbers_perday'] = $v['numrows'];
                        break;
                    }
                }
            }
        }
        else
        {
            $arr3=$arr2;
        }

        if(is_array($c2corder_result) && !empty($c2corder_result))
        {
            foreach ($arr3 as $kk => $vv) {
                $arr4[$kk] = $vv;
                foreach ($c2corder_result as $k => $v) {
                    if($vv['id'] == $v['site_id'])
                    {
                        $arr4[$kk]['c2corder_usernumbers_perday'] = $v['numrows'];
                        break;
                    }
                }
            }
        }
        else
        {
            $arr4 = $arr3;
        }

        // var_dump($recharge_result);

        if(is_array($recharge_result) && !empty($recharge_result))
        {
            foreach ($arr4 as $kk => $vv) {
                $arr5[$kk] = $vv;
                foreach ($recharge_result as $k => $v) {
                    if($vv['id'] == $v['site_id'])
                    {
                        $arr5[$kk]['recharge_usernumbers_perday'] = $v['numrows'];
                        break;
                    }
                }
            }
        }
        else
        {
            $arr5 = $arr4;
        }


        if(is_array($withdraw_result) && !empty($withdraw_result))
        {
            foreach ($arr5 as $kk => $vv) {
                $arr6[$kk] = $vv;
                foreach ($withdraw_result as $k => $v) {
                    if($vv['id'] == $v['site_id'])
                    {
                        $arr6[$kk]['withdraw_usernumbers_perday'] = $v['numrows'];
                        break;
                    }
                }
            }
        }
        else
        {
            $arr6=$arr5;
        }

        if(is_array($tradeuser_result) && !empty($tradeuser_result))
        {
            // var_dump($arr6);
            foreach ($arr6 as $kk => $vv) {
                $arr7[$kk] = $vv;
                foreach ($tradeuser_result as $k => $v) {
                    // $str = 'web,';
                    if($vv['id'] == $v['site_n'])
                    {
                        $arr7[$kk]['tradeuser_perday'] = $v['numrows'];
                        break;
                    }
                }
            }
        }
        else
        {
            $arr7 = $arr6;
        }

        // var_dump($arr7);
        $newarr = array();
        foreach ($arr7 as $m => $n) {

            $last_data = $this->last_deduplication_data($n['id'],$exchange,$local_exchange);

            if(is_array($last_data) && !empty($last_data)){
                $newarr['register_usernumbers_perday_total'] = $n['register_usernumbers_perday'] + (int)$last_data['register_total'];
                $newarr['recommend_usernumbers_perday_total'] =$n['recommend_usernumbers_perday'] + (int)$last_data['invite_register_total'];
                $newarr['identity_usernumbers_perday_total'] = $n['identity_usernumbers_perday'] + (int)$last_data['trunname_total'];
                $newarr['c2corder_usernumbers_perday_total'] = $n['c2corder_usernumbers_perday'] + (int)$last_data['c2c_trade_total'];
                $newarr['recharge_usernumbers_perday_total'] = $n['recharge_usernumbers_perday'] + (int)$last_data['recharge_total'];
                $newarr['withdraw_usernumbers_perday_total'] = $n['withdraw_usernumbers_perday'] + (int)$last_data['withdraw_total'];
                $newarr['tradeuser_perday_total'] = $n['tradeuser_perday'] + (int)$last_data['coin_trade_total'];
                $newarr['site_id'] = $n['id'];
                $newarr['time'] = $n['time'];
                $newarr['time_area'] = $n['time_area'];
                $newarr['register_usernumbers_perday'] = $n['register_usernumbers_perday'];
                $newarr['recommend_usernumbers_perday'] = $n['recommend_usernumbers_perday'];
                $newarr['identity_usernumbers_perday'] = $n['identity_usernumbers_perday'];
                $newarr['c2corder_usernumbers_perday'] = $n['c2corder_usernumbers_perday'];
                $newarr['recharge_usernumbers_perday'] = $n['recharge_usernumbers_perday'];
                $newarr['withdraw_usernumbers_perday'] = $n['withdraw_usernumbers_perday'];
                $newarr['tradeuser_perday'] = $n['tradeuser_perday'];
            }else{
                $newarr['register_usernumbers_perday_total'] = $n['register_usernumbers_perday'];
                $newarr['recommend_usernumbers_perday_total'] =$n['recommend_usernumbers_perday'];
                $newarr['identity_usernumbers_perday_total'] = $n['identity_usernumbers_perday'];
                $newarr['c2corder_usernumbers_perday_total'] = $n['c2corder_usernumbers_perday'];
                $newarr['recharge_usernumbers_perday_total'] = $n['recharge_usernumbers_perday'];
                $newarr['withdraw_usernumbers_perday_total'] = $n['withdraw_usernumbers_perday'];
                $newarr['tradeuser_perday_total'] = $n['tradeuser_perday'];
                $newarr['site_id'] = $n['id'];
                $newarr['time'] = $n['time'];
                $newarr['time_area'] = $n['time_area'];
                
                $newarr['register_usernumbers_perday'] = $n['register_usernumbers_perday'];
                $newarr['recommend_usernumbers_perday'] = $n['recommend_usernumbers_perday'];
                $newarr['identity_usernumbers_perday'] = $n['identity_usernumbers_perday'];
                $newarr['c2corder_usernumbers_perday'] = $n['c2corder_usernumbers_perday'];
                $newarr['recharge_usernumbers_perday'] = $n['recharge_usernumbers_perday'];
                $newarr['withdraw_usernumbers_perday'] = $n['withdraw_usernumbers_perday'];
                $newarr['tradeuser_perday'] = $n['tradeuser_perday'];
            }

            // var_dump($newarr);

            $this->add_deduplication_data($newarr,$exchange,$local_exchange);
        }
    }

    /**
     *  当日注册人数
     * [register_numbers description]
     * @param  [int] $start_time     [description]
     * @param  [int] $end_time       [description]
     * @param  [int] $site_id        [description]
     * @param  [string] $tongi_arr      [description]
     * @param  [object] $exchange [description]
     * @return [int]                 [description]
     */
    public function register_numbers($start_time,$end_time,$tongi_arr,$exchange)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $sql = "select count(site_id) as numrows,site_id from users where created_at>'".$start_time."' and created_at<'".$end_time."' and id not in ($tongi_arr) group by site_id";
        return $exchange->query($sql)->result_array();
    }
    
    //当日被邀请注册人数
    /**
     * [recommend_numbers description]
     * @param  [type] $start_time     [description]
     * @param  [type] $end_time       [description]
     * @param  [type] $site_id        [description]
     * @param  [type] $tongi_arr      [description]
     * @param  [type] $exchange [description]
     * @return [type]                 [description]
     */
    public function recommend_numbers($start_time,$end_time,$tongi_arr,$exchange)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);

        $sql = "SELECT count(B.id) as numrows,B.site_id from user_recommends A left join users B on B.id = A.recommend_user_id 
        where B.created_at>'".$start_time."' and B.created_at<'".$end_time."' and B.id not in ($tongi_arr) group by B.site_id";
        return  $exchange->query($sql)->result_array();
    }

    //实名通过人数
    /**
     * [recommend_numbers description]
     * @param  [type] $start_time     [description]
     * @param  [type] $end_time       [description]
     * @param  [type] $site_id        [description]
     * @param  [type] $tongi_arr      [description]
     * @param  [type] $exchange [description]
     * @return [type]                 [description]
     */
    public function identity_numbers($start_time,$end_time,$tongi_arr,$exchange){
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $sql = "SELECT count(u.id) as numrows,u.site_id from user_identities ui left join users u on u.id=ui.user_id where 
        ui.updated_at>='".$start_time."' and ui.updated_at<'".$end_time."' and ui.status=2 and ui.deleted_at is null and u.id not in ($tongi_arr) group by u.site_id";
        return $exchange->query($sql)->result_array();
    }

    //法币交易成功人数
    /**
     * [recommend_numbers description]
     * @param  [type] $start_time     [description]
     * @param  [type] $end_time       [description]
     * @param  [type] $site_id        [description]
     * @param  [type] $tongi_arr      [description]
     * @param  [type] $exchange [description]
     * @return [type]                 [description]
     */
    public function c2corder_numbers($start_time,$end_time,$tongi_arr,$exchange){
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $sql = "SELECT count(C.user_id) as numrows,D.site_id
                from
                (select 
                A.user_id
                from c2c_orders A
                left join users B
                on A.user_id=B.id
                where
                A.updated_at>='".$start_time."'
                and A.updated_at<'".$end_time."'
                and A.`status`=3
                and A.user_id not in ($tongi_arr)
                GROUP BY A.user_id) C
                LEFT JOIN users D on C.user_id=D.id
                group by D.site_id";
        // var_dump($sql);die;
        return $exchange->query($sql)->result_array();
    }

    //充值成功人数
    /**
     * [recommend_numbers description]
     * @param  [type] $start_time     [description]
     * @param  [type] $end_time       [description]
     * @param  [type] $site_id        [description]
     * @param  [type] $tongi_arr      [description]
     * @param  [type] $exchange [description]
     * @return [type]                 [description]
     */
    public function recharge_numbers($start_time,$end_time,$tongi_arr,$exchange){
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);

        $sql = "SELECT
                count(A.user_id) as numrows,B.site_id
                from
                (SELECT
                user_id 
                from 
                user_recharge_logs
                where
                status =1
                and updated_at>='".$start_time."'
                and updated_at<'".$end_time."'
                and user_id not in ($tongi_arr)
                GROUP BY user_id) A
                LEFT JOIN users B
                on A.user_id=B.id
                GROUP BY B.site_id";
        
        return $exchange->query($sql)->result_array();
    }
    /**
     * [tradeuser_perday description]
     * @param  [int] $start_time         [description]
     * @param  [int] $end_time           [description]
     * @param  [int] $site_id            [description]
     * @param  [string] $tongi_arr          [description]
     * @param  [object] $exchange [description]
     * @return [int]                     [description]
     */
    public function tradeuser_perday($start_time,$end_time,$tongi_arr,$exchange,$tradehistory)
    {
        // var_dump($exchange,$tradehistory);die;
        $item = array();
        for ($i=0; $i < 100; $i++) {

            $sql = "select  deal_money,source,user_id,market,side,deal_fee from order_history_".$i." where finish_time >=$start_time and finish_time<$end_time  and user_id not in($tongi_arr)";  
            // var_dump($sql);die;
            $res = $tradehistory->query($sql)->result_array();

            if(! empty($res))
            {
                foreach ($res as &$v) {
                    if($v['source']=='(null)'  || $v['source']=='')
                    {
                        // $v['source'] = 'web,1';//早期数据没有source来源，统一归到站点id为1的站点
                        $sql = "select site_id from users where id=".$v['user_id'];
                        $info = $exchange->query($sql)->row_array();
                        // var_dump($v['user_id']);
                        $v['source'] = 'web,'.$info['site_id'];
                        // var_dump($v['source']);
                    }
                    $v['numrows'] = 1; //人数
                    $v['number'] = 1; //笔数
                }
            }
            else
            {
                echo '单表数据为空';
                $res = array();
            }
            
            if($i==0){
                $new = array_merge(array(),$res);
            }else{
                @$new = &array_merge($new,$res);
            }
        }

        if(!empty($new))
        {
            foreach ($new as $key => $value) 
            {
                $a = (string)explode(',',$value['source'])[1].$value['user_id'];
                if(!isset($item[$a]))
                {
                    $item[$a]=$value;
                }
                else
                {
                    $item[$a]['number']+=$value['number']; 
                }
            }

            // var_dump($item);die;
            $item = array_values($item);
            if(!empty($item))
            {
                foreach ($item as $kk => $vv) {
                    $b = (string)explode(',',$vv['source'])[1];
                    if(!isset($item2[$b]))
                    {
                        $item2[$b] = $vv;
                    }
                    else
                    {
                        $item2[$b]['numrows']+=$vv['numrows'];
                    }
                }
            }
            var_dump($item2);
            foreach($item2 as $kkk=>$vvv){
                $vvv['site_n'] = $kkk;
                $result[] = $vvv;
            }
            var_dump($result);
            return $result;
            // var_dump(array_values($item2));
            // return array_values($item2);
        }
        else
        {
            echo '总体为空';
            return array();
        }
        
    }

    public function last_deduplication_data($site_id,$exchange,$local_exchange)
    {
        $sql = 'select * from perday_data_statistics where site_id='.$site_id.' order by id desc limit 1';;
        $result = $exchange->query($sql)->result_array();
        if(is_array($result) && !empty($result)){
            return $result[0];
        }else{
            return $result;
        }
    }

    public function add_deduplication_data($newarr,$exchange,$local_exchange)
    {
        // var_dump($local_exchange_db);die;
        $sql = "INSERT INTO `perday_data_statistics` (`site_id`,`created_at`,`updated_at`,`register_amount`,`invite_register_amount`,`trunname_amount`,`c2c_trade_amount`,`recharge_amount`,`withdraw_amount`,`coin_trade_amount`,`register_total`,`invite_register_total`,`trunname_total`,`c2c_trade_total`,`recharge_total`,`withdraw_total`,`coin_trade_total`,`time`,`time_area`) VALUES ($newarr[site_id],'$newarr[time_area]','$newarr[time_area]',$newarr[register_usernumbers_perday],$newarr[recommend_usernumbers_perday],$newarr[identity_usernumbers_perday],$newarr[c2corder_usernumbers_perday],$newarr[recharge_usernumbers_perday],$newarr[withdraw_usernumbers_perday],$newarr[tradeuser_perday],$newarr[register_usernumbers_perday_total],$newarr[recommend_usernumbers_perday_total],$newarr[identity_usernumbers_perday_total],$newarr[c2corder_usernumbers_perday_total],$newarr[recharge_usernumbers_perday_total],$newarr[withdraw_usernumbers_perday_total],$newarr[tradeuser_perday_total],'$newarr[time]','$newarr[time_area]')";
        // var_dump($sql);die;
        $result = $exchange->query($sql);
    }


    /**
     * 用户统计 TODO
     */
    //用户统计
    public function usertotal($args,$zt_exchange_db,$zt_tradehistory_db,$local_exchange_db)
    {
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_REGISTER);
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        if(isset($args['site_id']) && !empty($args['site_id'])){
            $where = 'where id='.$args['site_id'];
        }else{
            $where = 'where 1 = 1';
        }

        $sql = 'select name,id from b_site '.$where;
        $siteList = $this->zt_exchange_db->query($sql)->result_array(); 

        $newarr = [];
        foreach ($siteList as $k => $v) {
            $newarr['site_id'] = $v['id'];
            $newarr['time_area'] = date('Y-m-d',$start_time);
            $newarr['time'] = date('Y-m-d H:i:s',$start_time);
            //今日注册
            $newarr['register'] = $this->register_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //今日完成认证
            $newarr['registerauth'] = $this->registerauth_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            //今日推荐
            $newarr['recommend'] = $this->recommend_numbers($start_time,$end_time,$v['id'],$tongi_arr);
            // 今日注册且完成
            $newarr['recommendby'] = $this->identity_auth($start_time,$end_time,$v['id'],$tongi_arr);
            $result = $this->Tongji_model->add_register_data($newarr['site_id'],$newarr['time_area'],$newarr['time'],$newarr['register'],$newarr['registerauth'],$newarr['recommend'],$newarr['recommendby']);
        }
    }









    //当日注册且认证
    public function identity_auth($start_time,$end_time,$site_id,$tongi_arr)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $object = $this->db->select("count(1) as numrows")
        ->join('user_identities','user_identities.user_id=users.id','left')
        ->from('users')
        ->where('user_identities.created_at>',$start_time)
        ->where('user_identities.created_at<',$end_time)
        ->where('users.created_at<',$end_time)
        ->where('users.created_at<',$end_time)
        ->where('users.site_id=',$site_id)
        ->where('user_identities.status',2)
        ->where_not_in('users.id',$tongi_arr);
        
        return $this->db->count_all_results();
    }





    //币币交易统计 TODO
    public function tradetotal($args,$exchange,$tradehistory,$local_exchange)
    {


        // for($i=5;$i<6;$i++)
        // {
        //     $start_time = 1547654400;
        //     $end_time = 1547654400+3600;
        //     // $end_time = 1547740800;
        //     $sql = "select  deal_money,source,user_id,market,side,deal_fee from order_history_".$i." where finish_time >=$start_time and finish_time<$end_time";
        //     // var_dump($sql);die;
        //     $result1 = $tradehistory->query($sql)->result_array();
        //     // var_dump($result1);die;
        //     if($i==0)
        //     {
        //         $new = array_merge(array(),$result1);
        //     }
        //     else
        //     {
        //         @$new = &array_merge($new,$result1);
        //     }
        // }
        // $a = count($new);
        // $handle = fopen(APPPATH.'cache/excle/aaabbb.txt', 'wb');
        // fwrite($handle, $a);
        // fclose($handle);
        // die;



        // $arr1 = array(
        //     array(
        //         'site_id'=>127,
        //         'market'=>'aaa',
        //         'number'=>18
        //     ),
        //     array(
        //         'site_id'=>128,
        //         'market'=>'bbb',
        //         'number'=>19
        //     ),
        //     array(
        //         'site_id'=>129,
        //         'market'=>'ccc',
        //         'number'=>17
        //     ),
        // );

        // $arr2 = array(
        //     array(
        //         'site_id'=>127,
        //         'market'=>'aaa',
        //         'people'=>2
        //     ),
        //     array(
        //         'site_id'=>128,
        //         'market'=>'bbb',
        //         'people'=>3
        //     ),
        //     array(
        //         'site_id'=>129,
        //         'market'=>'ccc',
        //         'people'=>6
        //     ),
        // );

        // $arr3 = array(
        //     array(
        //         'site_id'=>127,
        //         'market'=>'aaa',
        //         'number'=>18,
        //         'people'=>2,
        //     ),
        //     array(
        //         'site_id'=>128,
        //         'market'=>'bbb',
        //         'number'=>19,
        //         'people'=>3
        //     ),
        //     array(
        //         'site_id'=>129,
        //         'market'=>'ccc',
        //         'number'=>17,
        //         'people'=>4
        //     ),
        // );


        // foreach ($arr1 as $k => $v) {
        //     foreach ($arr2 as $kk => $vv) {
        //         if(($v['site_id']==$vv['site_id']) && ($v['market']==$vv['market']))
        //         {
        //             $a[] = $v;
        //             $a[$k]['people'] = $vv['people'];
        //         }
        //     }
        // }

        // var_dump($args);die;
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;
        // var_dump($start_time);
        // var_dump($end_time);
        // $start_time = 1553702400;
        // $end_time = 1553788800;
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_COIN_POSITION,$exchange);        
        $result = array();

        for ($i=0; $i < 100; $i++) 
        {
            $result1 = array();
            $item = array();
            $item1 = array();
            $item2 = array();
            $sql = "select  deal_money,deal_stock,source,user_id,market,side,deal_fee from order_history_".$i." where finish_time >=$start_time and finish_time<$end_time  and user_id not in($tongi_arr)";
            // var_dump($sql);die;

            // $sql = "select  deal_money,deal_stock,source,user_id,market,side,deal_fee from order_history_".$i." where user_id not in($tongi_arr)";
            $list = $tradehistory->query($sql)->result_array();

            // var_dump($list);

            $item = array();
            if(!empty($list))
            {
                // echo 1;die;
                foreach ($list as &$v) 
                {
                    // var_dump($v['source']);
                    if($v['source']=='(null)' || $v['source']=='')
                    {
                        //$v['source'] = 'web,1';//早期数据没有source来源，统一归到站点id为1的站点
                        $sql = "select site_id from users where id=".$v['user_id'];
                        $info = $exchange->query($sql)->row_array();
                        var_dump($v['user_id']);
                        $v['source'] = 'web,'.$info['site_id'];
                        var_dump($v['source']);
                    }
                    if($v['side'] == 1)
                    {
                        $v['ASK_fee'] = $v['deal_fee'];
                        $v['BID_fee'] = 0;
                    }
                    else
                    {
                        $v['BID_fee'] = $v['deal_fee'];
                        $v['ASK_fee'] = 0;
                    }
                    $v['number'] = 1;
                    $v['people'] = 1;
                    unset($v['deal_fee']);
                }
                // var_dump($list);die;
                // echo "*******";
                // 求单表总交易量、买入卖出手续费、交易笔数
                foreach ($list as $key => $value) 
                {
                    $a = (string)explode(',',$value['source'])[1].$value['market'];
                    // $a = (string)$value['source'].$value['market'];
                    if(!isset($item[$a]))
                    {
                        $item[$a]=$value;
                    }
                    else
                    {
                        $item[$a]['deal_money'] = bcadd($item[$a]['deal_money'], $value['deal_money'],12); //交易总金额
                        $item[$a]['deal_stock'] = bcadd($item[$a]['deal_stock'], $value['deal_stock'],12); //交易总金额
                        $item[$a]['ASK_fee'] = bcadd($item[$a]['ASK_fee'], $value['ASK_fee'],12); //ASK手续费
                        $item[$a]['BID_fee']=bcadd($item[$a]['BID_fee'], $value['BID_fee'],12);  //BID手续费
                        $item[$a]['number']+=$value['number']; //
                    }
                }

                $item = array_values($item);
                // var_dump($item);die;
                // var_dump($item);
                //细分到用户
                foreach ($list as $s => $t) 
                {
                    $b = (string)explode(',',$t['source'])[1].$t['market'].$t['user_id'];
                    // $b = (string)$t['source'].$t['market'].$t['user_id'];
                    if(!isset($item1[$b]))
                    {
                        $item1[$b]=$t;
                    }
                }
                $item1 = array_values($item1);
                // var_dump($item1);
                // var_dump($item1);
                //再精确到交易对，把用户个数相加
                foreach ($item1 as $b => $c) 
                {
                    $s = (string)explode(',',$c['source'])[1].$c['market'];
                    if(!isset($item2[$s]))
                    {
                        $item2[$s]=$c;
                    }
                    else
                    {
                        $item2[$s]['people']+=$value['people']; //BID手续费
                    }
                }
                $item2 = array_values($item2);
                // var_dump($item2);die;
                // 遍历组装数组
                foreach ($item as $mm => $nn) 
                {
                    foreach ($item2 as $bb => $cc) 
                    {
                        if(($nn['source']==$cc['source']) && ($nn['market']==$cc['market']))
                        {
                            $result1[] = $nn;
                            $result1[$mm]['people1'] = $cc['people'];
                        }
                    }
                }
            }
            else
            {
                $result1 = array();
            }
            if($i==0)
            {
                $new = array_merge(array(),$result1);
            }
            else
            {
                @$new = &array_merge($new,$result1);
            }
        }
        // var_dump($new);die;

        foreach ($new as $kk => $vv) 
        {
            $b = (string)explode(',',$vv['source'])[1].$vv['market'];
            if(!isset($result[$b]))
            {
                $result[$b]=$vv;
            }
            else
            {
                 $result[$b]['deal_money'] = bcadd($result[$b]['deal_money'], $vv['deal_money'],12);
                 $result[$b]['deal_stock'] = bcadd($result[$b]['deal_stock'], $vv['deal_stock'],12);
                 $result[$b]['ASK_fee']    =bcadd($result[$b]['ASK_fee'], $vv['ASK_fee'],12);
                 $result[$b]['BID_fee']    =bcadd($result[$b]['BID_fee'], $vv['BID_fee'],12);;
                 $result[$b]['number']     +=$vv['number'];
                 $result[$b]['people1']    +=$vv['people1'];
            }
        }

        foreach ($result as &$x) {
            $x['site_id'] = substr($x['source'],strpos($x['source'],',')+1);
            $x['time'] = date('Y-m-d H:i:s',$start_time);
            $x['time_area'] = date('Y-m-d H:i:s',$start_time);
            $x['deal_money_avg'] = bcdiv($x['deal_money'], $x['people1'],12);
            // var_dump($x[deal_money_avg]);
        }

        // var_dump($result);die;


        foreach ($result as $n) {
            $sql = "INSERT INTO `perday_coin_trade_statistics` (`site_id`,`time_area`,`time`,`symbols`,`trading_amount`,`trading_number`,`people`,`BID_fee`,`ASK_fee`,`per_trading_amount`,`unit_price`) VALUES ($n[site_id],'$n[time_area]','$n[time]','$n[market]',$n[deal_money],$n[number],$n[people1],$n[BID_fee],$n[ASK_fee],$n[deal_money_avg],$n[deal_stock])";
            $exchange->query($sql);
        }
        return;
    }


    //币币交易统计 TODO
    public function tradetotal_all($args,$exchange,$tradehistory,$local_exchange)
    {

        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_COIN_POSITION,$exchange);        
        $result = array();
        for ($i=0; $i < 100; $i++) 
        {
            $result1 = array();
            $item = array();
            $item1 = array();
            $item2 = array();
            $sql = "select  deal_money,deal_stock,source,user_id,market,side,deal_fee from order_history_".$i." where finish_time >=$start_time and finish_time<$end_time";
            $list = $tradehistory->query($sql)->result_array();

            $item = array();
            if(!empty($list))
            {
                foreach ($list as &$v) 
                {
                    //如果元数据没有交易来源，根据用户属于那个站点，然后归结到此源
                    if($v['source']=='(null)' || $v['source']=='')
                    {
                        //$v['source'] = 'web,1';//早期数据没有source来源，统一归到站点id为1的站点
                        $sql = "select site_id from users where id=".$v['user_id'];
                        $info = $exchange->query($sql)->row_array();
                        var_dump($v['user_id']);
                        $v['source'] = 'web,'.$info['site_id'];
                        var_dump($v['source']);
                    }
                    if($v['side'] == 1)
                    {
                        $v['ASK_fee'] = $v['deal_fee'];
                        $v['BID_fee'] = 0;
                    }
                    else
                    {
                        $v['BID_fee'] = $v['deal_fee'];
                        $v['ASK_fee'] = 0;
                    }
                    $v['number'] = 1;
                    $v['people'] = 1;
                    unset($v['deal_fee']);
                }
                // 求单表总交易量、买入卖出手续费、交易笔数
                foreach ($list as $key => $value) 
                {
                    // var_dump(explode(',',$value['source'])[1]);die;
                    $a = (string)explode(',',$value['source'])[1].$value['market'];
                    // $a = (string)$value['source'].$value['market'];

                    if(!isset($item[$a]))
                    {
                        $item[$a]=$value;
                    }
                    else
                    {
                        $item[$a]['deal_money'] = bcadd($item[$a]['deal_money'], $value['deal_money'],12); //交易总金额
                        $item[$a]['deal_stock'] = bcadd($item[$a]['deal_stock'], $value['deal_stock'],12); //交易总金额
                        $item[$a]['ASK_fee'] = bcadd($item[$a]['ASK_fee'], $value['ASK_fee'],12); //ASK手续费
                        $item[$a]['BID_fee']=bcadd($item[$a]['BID_fee'], $value['BID_fee'],12);  //BID手续费
                        $item[$a]['number']+=$value['number']; //
                    }
                }

                $item = array_values($item);
                // var_dump($item);die;
                //细分到用户
                foreach ($list as $s => $t) 
                {
                    $b = (string)explode(',',$t['source'])[1].$t['market'].$t['user_id'];
                    // $b = (string)$t['source'].$t['market'].$t['user_id'];
                    if(!isset($item1[$b]))
                    {
                        $item1[$b]=$t;
                    }
                }
                $item1 = array_values($item1);
                // var_dump($item1);
                // var_dump($item1);
                //再精确到交易对，把用户个数相加
                foreach ($item1 as $b => $c) 
                {
                    $s = (string)explode(',',$c['source'])[1].$c['market'];
                    // $s = (string)$c['source'].$c['market'];
                    if(!isset($item2[$s]))
                    {
                        $item2[$s]=$c;
                    }
                    else
                    {
                        $item2[$s]['people']+=$value['people']; //BID手续费
                    }
                }
                $item2 = array_values($item2);
                // var_dump($item,$item2);die;
                // 遍历组装数组
                foreach ($item as $mm => $nn) 
                {
                    foreach ($item2 as $bb => $cc) 
                    {
                        if(($nn['source']==$cc['source']) && ($nn['market']==$cc['market']))
                        {
                            $result1[] = $nn;
                            $result1[$mm]['people1'] = $cc['people'];
                        }
                    }
                }
            }
            else
            {
                $result1 = array();
            }
            if($i==0)
            {
                $new = array_merge(array(),$result1);
            }
            else
            {
                @$new = &array_merge($new,$result1);
            }
        }
        // var_dump($new);die;

        foreach ($new as $kk => $vv) 
        {
            $b = (string)explode(',',$vv['source'])[1].$vv['market'];
            // $b = (string)$vv['source'].$vv['market'];
            if(!isset($result[$b]))
            {
                $result[$b]=$vv;
            }
            else
            {
                 $result[$b]['deal_money'] = bcadd($result[$b]['deal_money'], $vv['deal_money'],12);
                 $result[$b]['deal_stock'] = bcadd($result[$b]['deal_stock'], $vv['deal_stock'],12);
                 $result[$b]['ASK_fee']    =bcadd($result[$b]['ASK_fee'], $vv['ASK_fee'],12);
                 $result[$b]['BID_fee']    =bcadd($result[$b]['BID_fee'], $vv['BID_fee'],12);;
                 $result[$b]['number']     +=$vv['number'];
                 $result[$b]['people1']    +=$vv['people1'];
            }
        }

        foreach ($result as &$x) {
            $x['site_id'] = substr($x['source'],strpos($x['source'],',')+1);
            $x['time'] = date('Y-m-d H:i:s',$start_time);
            $x['time_area'] = date('Y-m-d H:i:s',$start_time);
            $x['deal_money_avg'] = bcdiv($x['deal_money'], $x['people1'],12);
            // var_dump($x[deal_money_avg]);
        }
        // var_dump($result);die;
        foreach ($result as $n) {
            $sql = "INSERT INTO `perday_coin_trade_statistics_all` (`site_id`,`time_area`,`time`,`symbols`,`trading_amount`,`trading_number`,`people`,`BID_fee`,`ASK_fee`,`per_trading_amount`,`unit_price`) VALUES ($n[site_id],'$n[time_area]','$n[time]','$n[market]',$n[deal_money],$n[number],$n[people1],$n[BID_fee],$n[ASK_fee],$n[deal_money_avg],$n[deal_stock])";
            $exchange->query($sql);
        }
        return;
    }


    public function tradetotal_test($args,$exchange,$tradehistory,$local_exchange){

        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;
        $item = array();
        // $start_time = 1542297600;
        // $end_time = 1547913600;
        
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_COIN_POSITION,$exchange);        
        $result = array();
        for ($i=0; $i <100 ; $i++) { 
            $sql = "select  sum(deal_money) deal_money,sum(deal_stock) deal_stock,source,user_id,market,side,sum(deal_fee) deal_fee,count(user_id) number from order_history_".$i." where finish_time >=$start_time and finish_time<$end_time  and user_id not in($tongi_arr) group by source,market,side,user_id";

            $list = $tradehistory->query($sql)->result_array();


            if($i==0)
            {
                $new = array_merge(array(),$list);
            }
            else
            {
                @$new = &array_merge($new,$list);
            }
        }
        foreach ($new as &$v) {
            if($v['source']==''){
                $sql = "select site_id from users where id=".$v['user_id'];
                $info = $exchange->query($sql)->row_array();
                $v['source'] = 'web,'.$info['site_id'];
            }
        }

        foreach ($new as &$n) {
            $n['BID_fee'] = '0';
            $n['ASK_fee'] = '0';
        }

        foreach ($new as $key => $value) 
        {
            $a = (string)$value['source'].$value['market'].$value['side'];
            if(!isset($item[$a]))
            {
                $item[$a]=$value;
            }
            else
            {
                $item[$a]['deal_money'] = bcadd($item[$a]['deal_money'], $value['deal_money'],8); //交易总金额
                $item[$a]['deal_stock'] = bcadd($item[$a]['deal_stock'], $value['deal_stock'],8); //交易总金额
                
                if($value['side']==2){
                    $item[$a]['BID_fee']=bcadd($item[$a]['deal_fee'], $value['deal_fee'],8);  //BID手续费
                }else{
                    $item[$a]['ASK_fee'] = bcadd($item[$a]['deal_fee'], $value['deal_fee'],8); //ASK手续费
                }
                $item[$a]['number']+=$value['number'];
            }
        }   

        var_dump($item);die;
        $item = array_values($item);

        foreach ($item as $kk => $vv) {
            $b = (string)$vv['source'].$vv['market'];
            if(!isset($item1[$b]))
            {
                $item1[$b]=$vv;
            }
            else
            {
                $item1[$b]['deal_money'] = bcadd($item1[$b]['deal_money'], $vv['deal_money'],8); //交易总金额
                $item1[$b]['deal_stock'] = bcadd($item1[$b]['deal_stock'], $vv['deal_stock'],8); //交易总金额
                $item1[$b]['BID_fee']=bcadd($item[$b]['BID_fee'], $vv['BID_fee'],8);  //BID手续费
                $item1[$b]['ASK_fee'] = bcadd($item[$b]['ASK_fee'], $vv['ASK_fee'],8); //ASK手续费
                $item1[$b]['number']+=$vv['number'];
            }
        }

        // var_dump($new);
        var_dump($item1);die;
    }

    public function symbol_is_true($site_id,$symbol,$exchange)
    {
        $sql = "select id from symbols where site_id=$site_id and symbol='$symbol'";
        $res = $exchange->query($sql)->result_array();
        if(is_array($res) && !empty($res))
            return TRUE;
        else
            return FALSE;
    }

    //指定站点币种的列表
    public function rechargelogs($args,$exchange,$tradehistory,$local_exchange)
    {
        $tongji_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_RECHARGEWITHDRAWAL,$exchange);
        
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        $time = $time_area = $start_time = date('Y-m-d',$start_time);
        $end_time = date('Y-m-d',$end_time);

        $sql = "select B.`name`,A.asset,
                sum(A.amount) as amount,B.id site_id,count(A.id) as number 
                from user_recharge_logs A
                LEFT JOIN users C on A.user_id=C.id
                LEFT JOIN b_site B on C.site_id=B.id
                where 1=1
                and A.status=1
                and A.user_id not in ($tongji_arr)
                and A.created_at>='".$start_time."'
                and A.created_at<'".$end_time."'
                GROUP BY A.asset,B.id
                ORDER BY B.id";
        
        $data1 = $exchange->query($sql)->result_array();

        $sql = "select AA.site_id,AA.asset,count(AA.site_id) as people from 
                (
                select B.id as site_id,asset
                from user_recharge_logs A
                LEFT JOIN users C on A.user_id=C.id
                LEFT JOIN b_site B on C.site_id=B.id
                where 1=1
                and A.status=1
                and A.user_id not in ($tongji_arr)
                and A.created_at>='".$start_time."'
                and A.created_at<'".$end_time."'
                GROUP BY B.id,A.asset,A.user_id
                ) as AA group by AA.asset,AA.site_id
                ORDER BY AA.site_id";
        
        $data = $exchange->query($sql)->result_array();

        $result = array();
        foreach ($data1 as $k=>$v)
        {
            foreach ($data as $kk=>$vv)
            {
                if($v['site_id'].$v['asset'] == $vv['site_id'].$vv['asset'])
                {
                    $v['people'] = $vv['people'];
                    $v['avg'] = bcdiv((string)$v['amount'],(string)$vv['people'],2);
                    $result[] = $v;
                }
            }
        }
        if(count($result)>0)
        {
            foreach ($result as $n) {
                //循环插入数据
                $sql = "INSERT INTO `perday_recharge_statistics` (`site_id`,`time_area`,`time`,`asset_code`,`recharge_total`,`recharge_number`,`number`,`per_recharge_amount`) VALUES ($n[site_id],'$time_area','$time','$n[asset]',$n[amount],$n[number],$n[people],$n[avg])";
                $exchange->query($sql);
            }
        }

    }

    public function recharge_amount($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_recharge_logs.*,b_site.name as site_name")
        ->join('users','user_recharge_logs.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_recharge_logs')
        ->where_not_in('users.id',$tongi_arr);
        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('users.site_id=',$site_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);
        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        $list = $object->get()->result_array();
        $arr['total_amount'] = 0;
        if(is_array($list) && !empty($list)){
            foreach ($list as $key => $value) {
                $arr['total_amount']=bcadd($arr['total_amount'],$value['amount'],12);
            }
        }else{
            $arr['total_amount'] = 0;
        }
        // var_dump($arr['total_amount']);
        //查询该数据需去掉作市的用户
        $detail = $this->Config_model->get_mailconfig($tongji_type=3);
        if(empty($detail)){
            $nouser_totalamount = '0';
        }else{
            $uid = $detail['uid'];
            $uid_array = explode(',', $uid);
            $nouser_totalamount = '0';
            for($i=0;$i<count($uid_array);$i++){
                $no_user = $this->get_nouser($uid_array[$i],$start_time,$end_time,$asset_code);
                $nouser_totalamount = bcadd($nouser_totalamount, $no_user,12);
            }
        }
        return bcsub($arr['total_amount'], $nouser_totalamount,12);
    }

    public function get_nouser($user_id,$start_time,$end_time,$asset_code)
    {
        $object = $this->db->select("user_recharge_logs.*")
        ->from('user_recharge_logs');

        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('user_recharge_logs.user_id=',$user_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);

        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        $list = $object->get()->result_array();
        // var_dump($list);
        $arr['nouser_amount'] = '0';
        if(is_array($list) && !empty($list)){
            foreach ($list as $key => $value) {
                $arr['nouser_amount']=bcadd($arr['nouser_amount'],$value['amount'],12);
            }
        }else{
            $arr['nouser_amount'] = 0;
        }
        return $arr['nouser_amount'];
        // var_dump($arr['nouser_amount']);die;
    }
    //充值人数（除去后台配置的作市账户）
    public function recharge_people($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_recharge_logs.*,b_site.name as site_name")
        ->join('users','user_recharge_logs.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->where_not_in('users.id',$tongi_arr)
        ->from('user_recharge_logs');
        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('users.site_id=',$site_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);
        $object =$this->db->group_by('user_id');
        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        $total_people = $this->db->count_all_results();
        if($total_people==0){
            return 0;
        }
        // var_dump($total_people);

        //查询该数据需去掉作市的用户（tongji_type=3 表示充值类型需要去掉作市用户）
        $detail = $this->Config_model->get_mailconfig($tongji_type=3);
        if(empty($detail)){
            $nouser_totalpeople = 0;
        }else{
            $uid = $detail['uid'];
            $uid_array = explode(',', $uid);
            $nouser_totalpeople = count($uid_array);
        }
        
        return $total_people-$nouser_totalpeople;
    }


    //充值笔数（除去后台配置的作市账户）
    public function recharge_numbers_per($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_recharge_logs.*,b_site.name as site_name")
        ->join('users','user_recharge_logs.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->where_not_in('users.id',$tongi_arr)
        ->from('user_recharge_logs');
        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('users.site_id=',$site_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);
        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        $total_people = $this->db->count_all_results();
        if($total_people==0){
            return 0;
        }
        //查询该数据需去掉作市的用户（tongji_type=3 表示充值类型需要去掉作市用户）
        $detail = $this->Config_model->get_mailconfig($tongji_type=3);
        if(empty($detail)){
            $recharge_user = 0;
        }else{
            $uid = $detail['uid'];
            $uid_array = explode(',', $uid);
            //获取每个要去除用户充值的笔数
            $recharge_user = 0;
            foreach ($uid_array as $key => $value) {
                $number = $this->recharge_people_user($start_time,$end_time,$site_id,$asset_code,$value['id']);
                $recharge_user += $number;
            }
        }
        return $total_people-$recharge_user;
    }

    //提现笔数（除去后台配置的作市账户）
    public function withdraw_numbers_per($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_withdraws.*,b_site.name as site_name")
        ->join('b_site','b_site.id=user_withdraws.site_id','left')
        ->where_not_in('user_withdraws.user_id',$tongi_arr)
        ->from('user_withdraws');
        $object =$this->db->where('user_withdraws.deleted_at is null');
        $object =$this->db->where('user_withdraws.site_id=',$site_id);
        $object =$this->db->where('user_withdraws.asset=',$asset_code);

        if(!empty($start_time)){
            $this->db->where('user_withdraws.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_withdraws.created_at <',date('Y-m-d',$end_time));
        }
        return $this->db->count_all_results();
    }

    public function withdraw_numbers($start_time,$end_time,$tongi_arr,$exchange)
    {
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);

        $sql = "SELECT
        count(A.user_id) as numrows,B.site_id
        from
        (SELECT
        user_id 
        from 
        user_withdraws
        where
        status =3
        and created_at>='".$start_time."'
        and created_at<'".$end_time."'
        and user_id not in ($tongi_arr)
        GROUP BY user_id) A
        LEFT JOIN users B
        on A.user_id=B.id
        GROUP BY B.site_id";
        
        return $exchange->query($sql)->result_array();
    }

    //获取每个要去除用户充值的笔数
    public function recharge_people_user($start_time,$end_time,$site_id,$asset_code,$user_id){
        $object = $this->db->select("user_recharge_logs.*,b_site.name as site_name")
        ->join('users','user_recharge_logs.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_recharge_logs');
        $object =$this->db->where('user_recharge_logs.deleted_at is null');
        $object =$this->db->where('users.site_id=',$site_id);
        $object =$this->db->where('user_recharge_logs.asset=',$asset_code);
        if(!empty($start_time)){
            $this->db->where('user_recharge_logs.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_recharge_logs.created_at <',date('Y-m-d',$end_time));
        }
        return $this->db->count_all_results();
    }

    //获取当天币种的的收盘价格
    public function last_price($start_time,$end_time,$site_id,$asset_code){
        $baseasset = $this->config->item('C2C_ASSET');
        $DB1 = $this->load->database('trade_history',true);
        for ($i=0; $i < 100; $i++) {  
            $sql = "select finish_time,market,price from order_history_".$i." where finish_time >".$start_time." and finish_time <".$end_time." and source='web,".$site_id."' and market='".$asset_code.'_'.$baseasset."' order by id desc limit 1";
            // var_dump($sql);
            $object = object_to_array($DB1->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        if(is_array($new) && empty($new)) return 0;
        //给合并后的数组进行排序
        $sort = array(
            'direction' => 'SORT_DESC', //排序顺序标志 SORT_DESC 降序；SORT_ASC 升序
            'field'     => 'finish_time',       //排序字段
        );
        $new = mulsort($sort,$new);
        return $new[0]['price'];
    }

    public function csvlogs_add($tongji_type,$url,$created_at){
        $this->Config_model->csvlogs_add($tongji_type,$url,$created_at);
    }

    public function withdrawlogs($args,$exchange,$tradehistory,$local_exchange)
    {
        $tongji_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_WITHDRAWAL,$exchange);
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        $time = $time_area = $start_time = date('Y-m-d',$start_time);
        $end_time = date('Y-m-d',$end_time);

        $sql = "select B.`name`,A.asset,
                sum(A.amount) as amount,B.id site_id,count(A.id) as number 
                from user_withdraws A
                LEFT JOIN users C on A.user_id=C.id
                LEFT JOIN b_site B on C.site_id=B.id
                where 1=1
                
                and A.user_id not in ($tongji_arr)
                and A.created_at>='".$start_time."'
                and A.created_at<'".$end_time."'
                GROUP BY A.asset,B.id
                ORDER BY B.id";
        
        $data1 = $exchange->query($sql)->result_array();

        $sql = "select AA.site_id,AA.asset,count(AA.site_id) as people from 
                (
                select B.id as site_id,asset
                from user_withdraws A
                LEFT JOIN users C on A.user_id=C.id
                LEFT JOIN b_site B on C.site_id=B.id
                where 1=1
                
                and A.user_id not in ($tongji_arr)
                and A.created_at>='".$start_time."'
                and A.created_at<'".$end_time."'
                GROUP BY B.id,A.asset,A.user_id
                ) as AA group by AA.asset,AA.site_id
                ORDER BY AA.site_id";
        
        $data = $exchange->query($sql)->result_array();

        $result = array();
        foreach ($data1 as $k=>$v)
        {
            foreach ($data as $kk=>$vv)
            {
                if($v['site_id'].$v['asset'] == $vv['site_id'].$vv['asset'])
                {
                    $v['people'] = $vv['people'];
                    $v['avg'] = bcdiv((string)$v['amount'],(string)$vv['people'],2);
                    $result[] = $v;
                }
            }
        }
        if(count($result)>0)
        {
            foreach ($result as $n) {
                //循环插入数据
                $sql = "INSERT INTO `perday_withdraw_statistics` (`site_id`,`time_area`,`time`,`symbols`,`withdraw_total`,`withdraw_number`,`number`,`per_withdraw_amount`) VALUES ($n[site_id],'$time_area','$time','$n[asset]',$n[amount],$n[number],$n[people],$n[avg])";
                $exchange->query($sql);
            }
        }


        
    }

    public function withdraw_amount($start_time,$end_time,$site_id,$asset_code)
    {
        $object = $this->db->select("user_withdraws.*,b_site.name as site_name")
        ->join('b_site','b_site.id=user_withdraws.site_id','left')
        ->from('user_withdraws');
        $object =$this->db->where('user_withdraws.deleted_at is null');
        $object =$this->db->where('user_withdraws.site_id=',$site_id);
        $object =$this->db->where('user_withdraws.asset=',$asset_code);
        if(!empty($start_time)){
            $this->db->where('user_withdraws.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_withdraws.created_at <',date('Y-m-d',$end_time));
        }
        $list = $object->get()->result_array();
        // var_dump($list);
        $arr['total_amount'] = '0';
        // $arr['total_fee'] = '0';
        if(is_array($list) && !empty($list)){
            foreach ($list as $key => $value) {
                $arr['total_amount']=bcadd($arr['total_amount'],$value['amount'],12);
                // $arr['total_fee']=bcadd($arr['total_fee'],$value['fee'],12);
            }
            return $arr['total_amount'];
        }else{
            return $arr['total_amount'];
        }
        
    }
    //提现人数
    public function withdraw_people($start_time,$end_time,$site_id,$asset_code,$tongi_arr)
    {
        $object = $this->db->select("user_withdraws.*,b_site.name as site_name")
        ->join('b_site','b_site.id=user_withdraws.site_id','left')
        ->where_not_in('user_withdraws.user_id',$tongi_arr)
        ->from('user_withdraws');
        $object =$this->db->where('user_withdraws.deleted_at is null');
        $object =$this->db->where('user_withdraws.site_id=',$site_id);
        $object =$this->db->where('user_withdraws.asset=',$asset_code);
        $object =$this->db->group_by('user_id');

        if(!empty($start_time)){
            $this->db->where('user_withdraws.created_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('user_withdraws.created_at <',date('Y-m-d',$end_time));
        }
        $total_people = $this->db->count_all_results();
        // var_dump($total_people);die;
        if($total_people==0){
            return 0;
        }
        return $total_people;
    }


    //法币买入卖出统计
    public function c2c_order($args){
        $type = isset($args['type']) ? $args['type'] :1;
        //type 1 m买 2 卖
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;
        //法币配置
        $asset_code = $this->config->item('C2C_ASSET');
        $siteList = $this->Site_model->site_all();
        if($type == 1){
            $tongji_type = TONGJI_TYPE_LAW_COIN_BY;
        }else{
            $tongji_type = TONGJI_TYPE_LAW_COIN_SELL;
        }
        $tongi_arr = $this->get_tongji_config_by_type($tongji_type);
        foreach ($siteList as $k => $v) { //站点
            $newarr['time_area'] = date('Y-m-d',$start_time);
            // $newarr['asset_code'] = $asset_code;
            $newarr['time'] = date('Y-m-d H:i:s',$start_time);
            $newarr['site_id'] = $v['id'];
            $newarr['order_total'] = $this->order_total($start_time,$end_time,$v['id'],$type,$status=false,$tongi_arr); //总下单数
            $newarr['finish_order_total'] = $this->order_total($start_time,$end_time,$v['id'],$type,$status=3,$tongi_arr); //完成订单数
            $newarr['people'] = $this->order_people($start_time,$end_time,$v['id'],$type,$tongi_arr); //总人数
            $detail = $this->order_amount($start_time,$end_time,$v['id'],$type,$status=3,$tongi_arr);
            if(is_array($detail) && !empty($detail)){
                $newarr['total_amount'] = $detail['total_amount']; //总交易金额
                $newarr['amount'] = $detail['amount']; //总交易量
                if($newarr['amount']==0){
                    $newarr['averge_price'] = 0; //交易均价
                }else{
                    $newarr['averge_price'] = bcdiv($newarr['total_amount'], $newarr['finish_order_total'],12); //交易均价
                }
            }else{
                $newarr['total_amount'] = 0;
                $newarr['amount'] = 0;
                $newarr['averge_price'] = 0;
            }
            if($newarr['order_total']==0)
                $newarr['finish_rate'] = 0;
            else
                $newarr['finish_rate'] = bcdiv($newarr['finish_order_total'], $newarr['order_total'],12);
            
            if($type==1)
                $this->Tongji_model->add_buy_data($newarr['site_id'],$newarr['time_area'],$newarr['time'],$newarr['order_total'],$newarr['finish_order_total'],$newarr['people'],$newarr['total_amount'],$newarr['amount'],$newarr['averge_price'],$newarr['finish_rate']);
            if($type==2)
                $this->Tongji_model->add_sell_data($newarr['site_id'],$newarr['time_area'],$newarr['time'],$newarr['order_total'],$newarr['finish_order_total'],$newarr['people'],$newarr['total_amount'],$newarr['amount'],$newarr['averge_price'],$newarr['finish_rate']);
        }
    }

    public function order_total($start_time,$end_time,$site_id,$type,$status,$tongi_arr){
        // echo 211;die;
            $object = $this->db->select("c2c_orders.*,b_site.name as site_name")
            ->join('b_site','b_site.id=c2c_orders.site_id','left')
            ->where_not_in('c2c_orders.user_id',$tongi_arr)
            ->from('c2c_orders');
            $object =$this->db->where('c2c_orders.deleted_at is null');
            $object =$this->db->where('c2c_orders.site_id=',$site_id);
            $object =$this->db->where('c2c_orders.type=',$type);

            if($status !== false) $object =$this->db->where('c2c_orders.status=',$status);
            
            // $object =$this->db->group_by('user_id');

            if(!empty($start_time)){
                $this->db->where('c2c_orders.updated_at >=',date('Y-m-d',$start_time));
            }
            if(!empty($end_time)){
                $this->db->where('c2c_orders.updated_at <',date('Y-m-d',$end_time));
            }
            return $this->db->count_all_results();
    }

    public function order_people($start_time,$end_time,$site_id,$type,$tongi_arr){
        $object = $this->db->select("c2c_orders.*,b_site.name as site_name")
        ->join('b_site','b_site.id=c2c_orders.site_id','left')
        ->where_not_in('c2c_orders.user_id',$tongi_arr)
        ->from('c2c_orders');
        $object =$this->db->where('c2c_orders.deleted_at is null');
        $object =$this->db->where('c2c_orders.site_id=',$site_id);
        $object =$this->db->where('c2c_orders.type=',$type);
        $object =$this->db->group_by('user_id');
        // $object =$this->db->group_by('user_id');
        if(!empty($start_time)){
            $this->db->where('c2c_orders.updated_at >=',date('Y-m-d',$start_time));
        }
        if(!empty($end_time)){
            $this->db->where('c2c_orders.updated_at <',date('Y-m-d',$end_time));
        }
        return $this->db->count_all_results();
    }

    public function order_amount($start_time,$end_time,$site_id,$type,$status,$tongi_arr){
        // echo 211;die;
            $object = $this->db->select("c2c_orders.*,b_site.name as site_name")
            ->join('b_site','b_site.id=c2c_orders.site_id','left')
            ->where_not_in('c2c_orders.user_id',$tongi_arr)
            ->from('c2c_orders');
            $object =$this->db->where('c2c_orders.deleted_at is null');
            $object =$this->db->where('c2c_orders.site_id=',$site_id);
            $object =$this->db->where('c2c_orders.type=',$type);

            if($status !== false) $object =$this->db->where('c2c_orders.status=',$status);
            if(!empty($start_time)){
                $this->db->where('c2c_orders.updated_at >=',date('Y-m-d',$start_time));
            }
            if(!empty($end_time)){
                $this->db->where('c2c_orders.updated_at <',date('Y-m-d',$end_time));
            }
            $list = $object->get()->result_array();
            // var_dump($list);die;
            $arr['total_amount'] = '0';
            $arr['amount'] = '0';
            $arr['price'] = '0';
            // $arr['total_fee'] = '0';
            if(is_array($list) && !empty($list)){
                foreach ($list as $key => $value) {
                    $arr['total_amount']=bcadd($arr['total_amount'],$value['total_amount'],12); //总交易金额
                    $arr['amount']=bcadd($arr['amount'],$value['amount'],12); //总交易金额
                    $arr['price']=bcadd($arr['price'],$value['price'],12); //价格
                }
                // var_dump($arr['total_amount']);die;
                return $arr;
            }else{
                return $arr;
            }
    }



    public function trade_number($args)
    {
        $DB1 = $this->load->database('trade_history',true);
        for ($i=0; $i < 100; $i++) { 
            $sql = "select count(*) as total from (select count(*) from deal_history_".$i." group by deal_id) a ";
            $object = object_to_array($DB1->query($sql)->result());
            // var_dump($object);die;
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $sum = 0;
        foreach($new as $ii => $item){
            $sum += $item['total'];
        }
        return $sum;
    }

    /**
     * Notes: 用户持币占比
     * User: 张哲
     * Date: 2018/12/7
     * Time: 10:24
     * @param $args
     * @return int
     */
    public function get_holdcoin_numbers($args)
    {
        //向下取整点时间戳
//        $time = date('Y-m-d H:i:s',time());
//        $sub=  substr($time,0,14);
//        $new_time = $sub."00:00";
//        $timestamp= strtotime($new_time);
//        $DB1 = $this->load->database('trade_log',true);
//        //先取用户及其币种数组
//        $sql = "select user_id,asset,sum(balance) as balance from slice_balance_".$timestamp." group by user_id,asset ";
//        $object = object_to_array($DB1->query($sql)->result());
//        $new = array_merge(array(),$object);
//        // 取每种币的总额
//        $sql1 = "select asset,sum(balance) as total from slice_balance_".$timestamp." group by asset ";
//        $object1 = object_to_array($DB1->query($sql1)->result());
//        $new1 = array_merge(array(),$object1);
//         foreach($new1 as $key => $value1){
//             foreach($new as $key => $value){
//                 if($value['asset'] == $value1['asset']){
//                     $pop = round(doubleval($value['balance'])/doubleval($value1['total']),8);
//                     $data1 = $this->Perday_holdcoin_statistics_model->get_data($value['user_id'],$value['asset']);
//                     if(!empty($data1['asset'])){
//                         $this->Perday_holdcoin_statistics_model->update($value['user_id'],$value['asset'],$value['balance'],$pop,$time);
//                     }else{
//                         $this->Perday_holdcoin_statistics_model->add($value['user_id'],$value['asset'],$value['balance'],$pop,$time);
//                     }
//                 }
//             }
//         }

        //针对大数据处理
        //向下取整点时间戳
        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
        } else {
            $assetList = $this->Zjys_assets_model->get_systemassets();
        }


        foreach ($assetList as $key => $value) {
            if ($value['asset_code'] != 'OEC') {
                $asset = $value['asset_code'];
                $time = date('Y-m-d H:i:s', time());
                $sub = substr($time, 0, 14);
                $new_time = $sub . "00:00";
                $timestamp = strtotime($new_time);
                $DB1 = $this->load->database('trade_log', true);
                //先取用户及其币种数组
                $sql = "select user_id,asset,sum(balance) as balance from slice_balance_".$timestamp." where asset = '$asset'  group by user_id order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
                $new = array_slice($new, 0, 100);
                // 取每种币的总额
                $sql1 = "select asset,sum(balance) as total from slice_balance_".$timestamp." where asset = '$asset'";
                $object1 = object_to_array($DB1->query($sql1)->result());
                $new1 = array_merge(array(), $object1);
                foreach ($new1 as $key => $value1) {
                    foreach ($new as $key => $value) {
                        if ($value['asset'] == $value1['asset']) {
                            $pop = round(doubleval($value['balance']) / doubleval($value1['total']), 10);
                            $data1 = $this->Perday_holdcoin_statistics_model->get_data($value['user_id'], $value['asset']);
                            if (!empty($data1['asset'])) {
                                $this->Perday_holdcoin_statistics_model->update($value['user_id'], $value['asset'], $value['balance'], $pop, $time);
                            } else {
                                $this->Perday_holdcoin_statistics_model->add($value['user_id'], $value['asset'], $value['balance'], $pop, $time);
                            }
                        }
                    }
                }
            }else{
                $asset = $value['asset_code'];
                $time = date('Y-m-d H:i:s', time());
                $sub = substr($time, 0, 14);
                $new_time = $sub . "00:00";
                $timestamp = strtotime($new_time);
                $DB1 = $this->load->database('trade_log', true);
                //先取用户及其币种数组
                $sql = "select user_id,asset,sum(balance) as balance from slice_balance_".$timestamp." where asset = '$asset' and balance > 100  group by user_id order by balance desc";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
                $new = array_slice($new, 0, 100);
                // 取每种币的总额
                $sql1 = "select asset,sum(balance) as total from slice_balance_".$timestamp." where asset = '$asset'";
                $object1 = object_to_array($DB1->query($sql1)->result());
                $new1 = array_merge(array(), $object1);
                foreach ($new1 as $key => $value1) {
                    foreach ($new as $key => $value) {
                        if ($value['asset'] == $value1['asset']) {
                            $pop = round(doubleval($value['balance']) / doubleval($value1['total']), 10);
                            $data1 = $this->Perday_holdcoin_statistics_model->get_data($value['user_id'], $value['asset']);
                            if (!empty($data1['asset'])) {
                                $this->Perday_holdcoin_statistics_model->update($value['user_id'], $value['asset'], $value['balance'], $pop, $time);
                            } else {
                                $this->Perday_holdcoin_statistics_model->add($value['user_id'], $value['asset'], $value['balance'], $pop, $time);
                            }
                        }
                    }

                }
            }
        }
    }

    /*
     * @param  $type string
     * @return array
     */
    //运营统计数据剔除
    public function get_tongji_config_by_type($type,$exchange){
        $arr = array(0);
        $sql = 'select * from mail_tongji_config where tongji_type='.$type;
        $result = $exchange->query($sql)->row_array();
        if($result===null)
            return 0;
        return $result['uid'];
    }

    /**
     * [deal_fee description]
     * @return [type] [description]
     */
    public function deal_fee($args,$exchange,$tradehistory)
    {
        //获取站点
        $site_id = $args['site_id'];
        $stime = isset($args['start_time']) ? $args['start_time'] : "";
        $etime = isset($args['end_time']) ? $args['end_time'] : "";
        //获取交易区
        $jyq = $args['jyq'];
        $result = array();
        //获取卖出手续
        for($i=0;$i<count($jyq);$i++)
        {
            $sql = "select sum(ASK_fee) as fee from perday_coin_trade_statistics 
                    where 1=1
                    and site_id=$site_id
                    and symbols like '%_$jyq[$i]'";

            if($stime !='' && $etime !='')
            {
                $sql = $sql." and time>='".$stime."' and time<='".$etime."'";
            }
            elseif($stime !='' && $etime ='')
            {
                $sql = $sql." and time>='".$stime."'";
            }
            elseif($etime !='' && $stime ='')
            {
                $sql = $sql." and time<='".$etime."'";
            }

            // var_dump($sql);die;

            $ASK_fee[$jyq[$i]] = array_column($exchange->query($sql)->result_array(), 'fee');

            $sql = "select base_asset,symbol from symbols where site_id=$site_id and symbol like '%_$jyq[$i]'";
            $symbolList = $exchange->query($sql)->result_array();

            // var_dump($symbolList);
            
            foreach ($symbolList as $key => $value) {
                $sql = "select sum(BID_fee) as fee from perday_coin_trade_statistics 
                    where 1=1
                    and site_id=$site_id
                    and symbols like '".$value['base_asset']."_".$jyq[$i]."'";
            if($stime !='' && $etime !='')
            {
                $sql = $sql." and time>='".$stime."' and time<='".$etime."'";
            }
            elseif($stime !='' && $etime ='')
            {
                $sql = $sql." and time>='".$stime."'";
            }
            elseif($etime !='' && $stime ='')
            {
                $sql = $sql." and time<='".$etime."'";
            }

                    $BID_fee[$jyq[$i].'交易区'][$value['symbol']] = array_column($exchange->query($sql)->result_array(),'fee');
            }
        }
        // var_dump($ASK_fee);
        // var_dump($BID_fee);die;
        // and A.wallet_status='DONE'
        //提币手续费
        $sql = "select B.`name`,A.site_id,A.asset,sum(A.fee) as fee from user_withdraws A
                LEFT JOIN b_site B on A.site_id=B.id
                where 1=1
                and A.site_id=$site_id
                
                GROUP BY A.asset,A.site_id
                ORDER BY site_id";
        if($stime !='' && $etime !='')
        {
            $sql = "select B.`name`,A.site_id,A.asset,sum(A.fee) as fee from user_withdraws A
                LEFT JOIN b_site B on A.site_id=B.id
                where 1=1
                and A.site_id=$site_id
                
                and A.process_time>='".$stime."'
                and A.process_time<='".$etime."'
                GROUP BY A.asset,A.site_id
                ORDER BY site_id";
        }
        elseif($stime !='' && $etime ='')
        {
            $sql = "select B.`name`,A.site_id,A.asset,sum(A.fee) as fee from user_withdraws A
                LEFT JOIN b_site B on A.site_id=B.id
                where 1=1
                and A.site_id=$site_id
                
                and A.process_time>='".$stime."'
                GROUP BY A.asset,A.site_id
                ORDER BY site_id";

        }
        elseif($etime !='' && $stime ='')
        {
            $sql = "select B.`name`,A.site_id,A.asset,sum(A.fee) as fee from user_withdraws A
                LEFT JOIN b_site B on A.site_id=B.id
                where 1=1
                and A.site_id=$site_id
                
                and A.process_time<='".$etime."'
                GROUP BY A.asset,A.site_id
                ORDER BY site_id";
        }

        $withdraw_fee = $exchange->query($sql)->result_array();
        $result['ASK_FEE'] = $ASK_fee;
        $result['BID_FEE'] = $BID_fee;
        $result['WITHDRAW_FEE'] = $withdraw_fee;

        // var_dump($result['ASK_FEE']);

        // foreach ($result['ASK_FEE'] as $a => $b) {
        //     $b[$a] = $b[0];
        //     unset($b[0]);
        //     $result_new1[] = $b;
        // }

        // var_dump($result_new1);


        // $sql = "select asset_code from assets where site_id=$site_id";
        // $assetList = $exchange->query($sql)->result_array();
        // var_dump($assetList);die;

        return $result;
    }

    public function get_payment($args,$exchange_db,$activity_db)
    {
        $time_area = date('Y-m-d',get_last_day($args));
        $time_area_next = date('Y-m-d',strtotime($time_area));
        $time_area = $time_area.' 00:00:00';
        //不区分站点算分组交易对处理
        $sql = "select sum(BID_fee) as BID_fee,sum(ASK_fee) as ASK_fee,symbols,time_area from perday_coin_trade_statistics where time_area='".$time_area."' group by symbols";
        $data = $exchange_db->query($sql)->result_array();
        if(count($data)==0) returnJson('403','币币交易手续费未获取到'); 

        $arr = array();
        $arr1 = array();

        foreach ($data as $k => $v) {
            $pieces = explode( "_", $v['symbols'] );
            $arr[$k][$pieces[0]] = $v['BID_fee'];
            $arr[$k][$pieces[1]] = $v['ASK_fee'];
        }
        //相同的币种数量相加
        foreach ($arr as $k => $v) {
            foreach ($v as $kk => $vv) {
                if(!isset($item[$kk])){
                    $item[$kk]=$vv;
                }else{
                    $item[$kk]= bcadd($vv,$item[$kk],12);
                }
            }
        }
        //每个币种的手续费数量
        $item1 = array_keys($item);
        // var_dump($item1);
        //获取活动当天的币种
        $start_time = date('Y-m-d',strtotime($time_area));
        $end_time = date('Y-m-d',strtotime($time_area)+86400);
        $sql = "select asset from activity_changes where created_at>='".$start_time."' and created_at<'".$end_time."' group by asset";
        $data = $this->db->query($sql)->result_array();
        foreach ($data as $k => $v) {
            $arr1[$k] = $v['asset'];
        }
        // var_dump($item);
        // var_dump($arr1);
        // var_dump($item1);
        $item1 = array_values(array_unique(array_merge($arr1,$item1)));
        // var_dump($item1);die;
        
        for($j=0;$j<count($item1);$j++)
        {
            if(!isset($item[$item1[$j]]))
            {
                $item[$item1[$j]] = '0';
            }
        }

        // var_dump($item);die;

        for($i=0;$i<count($item1);$i++)
        {
            $item1result[$i]['asset'] = $item1[$i];
            $item1result[$i]['trade_amount'] = $item[$item1[$i]];
            $item1result[$i]['withdraw_amount'] = $this->get_withdraw_fee($item1[$i],$time_area);
            $item1result[$i]['price'] = $this->InOut_money_service->asset_price($item1[$i],$time_area);
            $item1result[$i]['trade_fee'] = bcmul($item[$item1[$i]],$item1result[$i]['price'],12); //交易手续费
            $item1result[$i]['withdraw_fee'] = bcmul($item1result[$i]['withdraw_amount'],$item1result[$i]['price'],12);
            $item1result[$i]['activity_in'] = bcmul($this->get_activity_fee($item1[$i],$time_area,1),$item1result[$i]['price'],12);
            $item1result[$i]['activity_out'] = bcmul($this->get_activity_fee($item1[$i],$time_area,2),$item1result[$i]['price'],12);
            $item1result[$i]['time_area'] = $time_area;
            $item1result[$i]['created_at'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        }
        // var_dump($item1result);
        //入库
        foreach ($item1result as $k => $v) {
            $this->Tongji_model->add_platform_inout($v['created_at'], $v['time_area'], $v['asset'], $v['price'], $v['trade_fee'], $v['withdraw_fee'],$v['activity_in'],$v['activity_out'],$v['trade_amount'],$v['withdraw_amount']);
        }
    }

    //获取提币手续费
    public function get_withdraw_fee($asset,$time_area)
    {
        $start_time = date('Y-m-d',strtotime($time_area));
        $end_time = date('Y-m-d',strtotime($time_area)+86400);
        $sql = "select sum(amount) as amount,sum(real_amount) as real_amount from user_withdraws where asset='".$asset."' and status=3 and created_at>='".$start_time."' and created_at<'".$end_time."' group by asset";
        $data = $this->db->query($sql)->row_array();
        if($data===NULL)
            $data = [];
        // var_dump($data);
        // var_dump($data['amount']);die;
        if(count($data)>0){
            return bcsub($data['amount'], $data['real_amount'],12);
        }else{
            return '0';
        }
    }

    //获取提币手续费
    public function get_activity_fee($asset,$time_area,$type)
    {
        $start_time = date('Y-m-d',strtotime($time_area));
        $end_time = date('Y-m-d',strtotime($time_area)+86400);
        //type=1,收入，amount<0;type=2,支出，amount>0;
        if($type==1){
            $sql = "select sum(amount) as amount from activity_changes where asset='".$asset."' and amount<0 and created_at>='".$start_time."' and created_at<'".$end_time."' group by asset";
        }
        else
        {
            $sql = "select sum(amount) as amount from activity_changes where asset='".$asset."' and amount>0 and created_at>='".$start_time."' and created_at<'".$end_time."' group by asset";
        }
        
        $data = $this->db->query($sql)->row_array();
        if($data===NULL)
            $data = [];
        
        if(count($data)>0){
            return $data['amount'];
        }else{
            return '0';
        }
    }

    //数据统计
    public function data_text($args,$exchange,$tradehistory,$trade_log,$otc_trade)
    {

        $time = isset($args['time']) ? $args['time'] : date('Y-m-d',$_SERVER['REQUEST_TIME']-86400);
        $time_area = isset($args['time']) ? $args['time'].' 00:00:00' : date('Y-m-d 00:00:00',$_SERVER['REQUEST_TIME']-86400);
        
        $time_area_end = date('Y-m-d H:i:s',strtotime($time_area)+86400);
        $timestamp = strtotime($time)+86400; 

        // var_dump($time);
        // var_dump($time_area);
        // var_dump($time_area_end);
        // var_dump($timestamp);die;

        $site_id = isset($args['site_id']) ? $args['site_id'] : 1;
        $sql = "select * from perday_data_statistics where site_id=$site_id and time_area='".$time."'";
        // var_dump($sql);die;
        $qcdata = $exchange->query($sql)->row_array();
        //otc当日交易人数
        $sql = "select * from otc_orders where status=6 and created_at>='".$time_area."' and created_at<='".$time_area_end."' group by user_id";
        $qcdata1 = $otc_trade->query($sql)->result_array();
        if(empty($qcdata1)){
            $qcdata['otc_trade_amount'] = 0;
        }else{
            $qcdata['otc_trade_amount'] = count($qcdata1);
        }
        //otc累计交易人数
        $sql = "select * from otc_orders where status=6 group by user_id";
        $qcdata2 = $otc_trade->query($sql)->result_array();
        if(empty($qcdata2)){
            $qcdata['otc_trade_total'] = 0;
        }else{
            $qcdata['otc_trade_total'] = count($qcdata2);
        }
        //获取提币人数
        $sql = "select user_id from user_withdraws A left join users B on A.user_id=B.id where A.status=3 and A.created_at>='".$time_area."' and A.created_at<'".$time_area_end."' group by A.user_id";

        $qcdata3 = $exchange->query($sql)->result_array();
        if(empty($qcdata3)){
            $qcdata['withdraw_amount'] = 0;
        }else{
            $qcdata['withdraw_amount'] = count($qcdata3);
        }
        //print_r($qcdata);
        //历史充提
        //充
        $sql = "select sum(amount) amount,asset,count(id) as recharge_number from user_recharge_logs where status=1 group by asset";
        $data = $exchange->query($sql)->result_array();
        foreach ($data as $key => $value) {
            $value['recharge_people'] = count($exchange->query("select user_id from user_recharge_logs where status=1 and asset='".$value['asset']."' GROUP BY user_id")->result_array());
            $data1[] = $value;
        }
        //提
        $sql = "select sum(amount) amount,asset,count(id) as withdraw_number from user_withdraws where status=3 group by asset";
        $data = $exchange->query($sql)->result_array();
        foreach ($data as $key => $value) {
            $value['withdraw_people'] = count($exchange->query("select user_id from user_withdraws where status=3 and asset='".$value['asset']."' GROUP BY user_id")->result_array());
            $data2[] = $value;
        }

        $aa = array();
        foreach ($data1 as $k1 => $v1) {
            if(!isset($aa['asset_code'])){
                array_push($aa,$v1['asset']);
            }
        }

        $bb = array();
        foreach ($data2 as $k2 => $v2) {
            if(!isset($bb['symbols'])){
                array_push($bb,$v2['asset']);
            }
        }
        
        // var_dump($data1,$data2,$aa,$bb);

        foreach ($data1 as $kk => $vv) {
            $kk = $vv['asset'];
            $new1_history[$kk]['asset_code'] = $vv['asset'];
            $new1_history[$kk]['recharge_total'] = $vv['amount'];
            $new1_history[$kk]['recharge_number'] = $vv['recharge_number'];
            $new1_history[$kk]['recharge_people'] = $vv['recharge_people'];
            $new1_history[$kk]['per_recharge_amount'] = bcdiv($vv['amount'],$vv['recharge_people'],8);
        }

        foreach ($data2 as $kk => $vv) {
            $kk = $vv['asset'];
            $new2_history[$kk]['symbols'] = $vv['asset'];
            $new2_history[$kk]['withdraw_total'] = $vv['amount'];
            $new2_history[$kk]['withdraw_number'] = $vv['withdraw_number'];
            $new2_history[$kk]['withdraw_people'] = $vv['withdraw_people'];
            $new2_history[$kk]['per_withdraw_amount'] = bcdiv($vv['amount'],$vv['withdraw_people'],8);
        }

        $assets = array_values(array_unique(array_merge($aa,$bb)));
        if(!empty($assets))
        {
            for($i=0;$i<count($assets);$i++)
            {
                if(isset($new1_history[$assets[$i]])){
                    $new_history[$i]['asset'] = $new1_history[$assets[$i]]['asset_code'];
                    $new_history[$i]['recharge_total'] = $new1_history[$assets[$i]]['recharge_total'];
                    $new_history[$i]['recharge_number'] = $new1_history[$assets[$i]]['recharge_number'];
                    $new_history[$i]['recharge_people'] = $new1_history[$assets[$i]]['recharge_people'];
                    $new_history[$i]['per_recharge_amount'] = $new1_history[$assets[$i]]['per_recharge_amount'];

                    if(isset($new2_history[$assets[$i]])){
                        $new_history[$i]['withdraw_total'] = $new2_history[$assets[$i]]['withdraw_total'];
                        $new_history[$i]['withdraw_number'] = $new2_history[$assets[$i]]['withdraw_number'];
                        $new_history[$i]['withdraw_people'] = $new2_history[$assets[$i]]['withdraw_people'];
                        $new_history[$i]['per_withdraw_amount'] = $new2_history[$assets[$i]]['per_withdraw_amount'];
                    }else{
                        $new_history[$i]['withdraw_total'] = 0;
                        $new_history[$i]['withdraw_number'] = 0;
                        $new_history[$i]['withdraw_people'] = 0;
                        $new_history[$i]['per_withdraw_amount'] = '0';
                    }
                    $new_history[$i]['in'] = bcsub($new_history[$i]['recharge_total'], $new_history[$i]['withdraw_total'],12);
                    $new_history[$i]['price'] = digui_asset_price($new_history[$i]['asset']);
                    $new_history[$i]['in_cny'] = bcmul($new_history[$i]['in'], $new_history[$i]['price'],12);
                }else{
                    $new_history[$i]['asset'] = $new2_history[$assets[$i]]['symbols'];
                    $new_history[$i]['recharge_total'] = 0;
                    $new_history[$i]['recharge_number'] = 0;
                    $new_history[$i]['recharge_people'] = 0;
                    $new_history[$i]['per_recharge_amount'] = '0';
                    $new_history[$i]['withdraw_total'] = $new2_history[$assets[$i]]['withdraw_total'];
                    $new_history[$i]['withdraw_number'] = $new2_history[$assets[$i]]['withdraw_number'];
                    $new_history[$i]['withdraw_people'] = $new2_history[$assets[$i]]['withdraw_people'];
                    $new_history[$i]['per_withdraw_amount'] = $new2_history[$assets[$i]]['per_withdraw_amount'];
                    $new_history[$i]['in'] = bcsub($new_history[$i]['recharge_total'], $new_history[$i]['withdraw_total'],12);
                    $new_history[$i]['price'] = digui_asset_price($new_history[$i]['asset']);
                    $new_history[$i]['in_cny'] = bcmul($new_history[$i]['in'], $new_history[$i]['price'],12);
                }
            }
        }else
        {
            $new_history = array();
        }
        array_multisort(array_column($new_history,'in_cny'),SORT_DESC,$new_history);
        // print_r($new_history);
        // echo "*************************************************************************";

        //获取平台资产和指定账户资产
        if(! $trade_log->get("slice_balance_$timestamp")->num_rows()){
            $platform_balance = '';
            $user_platform_balance = '';
        }else{
            $sql = "select asset,sum(balance) as balance from slice_balance_$timestamp group by asset order by asset";
            // $sql = "select asset,sum(balance) as balance from slice_balance_1564455600 group by asset";
            $platform_balance = $trade_log->query($sql)->result_array();
            foreach ($platform_balance as &$q) {
                $q['tran_balance'] = bcmul($q['balance'],digui_asset_price($q['asset']),12);
            }
            array_multisort(array_column($platform_balance,'tran_balance'),SORT_DESC,$platform_balance);
            // var_dump($platform_balance);die;
            $total_assets = $exchange->query("select asset_code from total_assets")->result_array();
            //获取所有的资产
            $total_assets = array_column($total_assets,'asset_code');
            // $user_ids = $this->config->item('special_account'); //获取配置项
            $user_ids = array(916,1081115,1088016,33,1100035);
            for($i=0;$i<count($user_ids);$i++)
            {
                for($j=0;$j<count($total_assets);$j++)
                {
                    $sql = "select sum(balance) as balance from slice_balance_$timestamp where user_id=$user_ids[$i] and asset='$total_assets[$j]'";
                    $user_platform_balance[$total_assets[$j]][$user_ids[$i]] = $trade_log->query($sql)->row_array()['balance'];
                }
            }
            foreach ($user_platform_balance as $key => $value) {
                $value['asset'] = $key;
                $user_platform_balance_result[] = $value;
            }
            // var_dump($user_platform_balance_result);die;         
        }

        //获取资产总览（截止指定日期以前）
        for($f=0;$f<count($total_assets);$f++)
        {
            //账面
            $coin_total[$total_assets[$f]]['system'] = $trade_log->query("SELECT asset,sum(`balance`) as amount from slice_balance_$timestamp where asset='$total_assets[$f]'")->row_array()['amount'];
            //充值
            // var_dump("SELECT asset,sum(`amount`) as amount from user_recharge_logs where asset='$total_assets[$f]' and status=1 and created_at<'$time_area'");die;
            $coin_total[$total_assets[$f]]['recharge'] = $exchange->query("SELECT asset,sum(`amount`) as amount from user_recharge_logs where asset='$total_assets[$f]' and status=1 and created_at<'$time_area_end'")->row_array()['amount'];
            //提币
            $coin_total[$total_assets[$f]]['withdraw'] = $exchange->query("SELECT asset,sum(`amount`) as amount from user_withdraws where asset='$total_assets[$f]' and status=3 and created_at<'$time_area_end'")->row_array()['amount'];
            //OTC转入
            $coin_total[$total_assets[$f]]['transfer_in'] = $exchange->query("SELECT asset,sum(`change`) as amount from otc_transfer_histories where asset='$total_assets[$f]' and business='otc_transfer_in' and created_at<'$time_area_end'")->row_array()['amount'];
            //OTC转出
            $coin_total[$total_assets[$f]]['transfer_out'] = $exchange->query("SELECT asset,sum(`change`) as amount from otc_transfer_histories where asset='$total_assets[$f]' and business='otc_transfer_out' and created_at<'$time_area_end'")->row_array()['amount'];
            //调整资金增加
            $coin_total[$total_assets[$f]]['operation_in'] = $exchange->query("SELECT asset_code,sum(`amount`) as amount from operation_money_logs where asset_code='$total_assets[$f]' and amount>0 and created_time<'$time_area_end'")->row_array()['amount'];
            //调整资金减少
            $coin_total[$total_assets[$f]]['operation_out'] = $exchange->query("SELECT asset_code,sum(`amount`) as amount from operation_money_logs where asset_code='$total_assets[$f]' and amount<0 and created_time<'$time_area_end'")->row_array()['amount'];
            //手续费
                $sql = "select sum(BID_fee) as fee from perday_coin_trade_statistics where site_id=$site_id and symbols like '$total_assets[$f]%' and time_area<'".$time_area_end." 00:00:00' order by trading_number+0 desc";
                $coin_total_result = $exchange->query($sql)->row_array();
                $sql1 = "select sum(ASK_fee) as fee from perday_coin_trade_statistics where site_id=$site_id and symbols like '%$total_assets[$f]' and time_area<'".$time_area_end." 00:00:00' order by trading_number+0 desc";
                $coin_total_result1 = $exchange->query($sql1)->row_array();
                $coin_total[$total_assets[$f]]['fee'] = bcadd($coin_total_result['fee'],$coin_total_result1['fee'],12);
            
        }

        foreach ($coin_total as $key => $value) {

            if($value['system']==NULL) $value['system']=0;
            if($value['recharge']==NULL) $value['recharge']=0;
            if($value['withdraw']==NULL) $value['withdraw']=0;
            if($value['transfer_in']==NULL) $value['transfer_in']=0;
            if($value['transfer_out']==NULL) $value['transfer_out']=0;
            if($value['operation_in']==NULL) $value['operation_in']=0;
            if($value['operation_out']==NULL) $value['operation_out']=0;
            if($value['fee']==NULL) $value['fee']=0;

            $value['asset'] = $key;
            $value['price'] = digui_asset_price($value['asset']);
            $value['true_amount'] = bcsub($value['recharge'],$value['withdraw'],12);
            $value['true_money'] = bcmul($value['true_amount'],$value['price'],12);
            $new_coin_total[]= $value;
        }

        array_multisort(array_column($new_coin_total,'true_money'),SORT_DESC,$new_coin_total);

        // print_r($new_coin_total);
        // echo "*************************************************************************";

        //获取OTC相关
        $sql = "select asset from otc_orders where status=6 and updated_at>='".$time_area."' and updated_at<'".$time_area_end."' GROUP BY asset";
        $assetList = $otc_trade->query($sql)->result_array();
        $new_otc_data = array();
        foreach ($assetList as $key => $value) {
            $new_otc_data[$key]['asset'] = $value['asset'];
            $sql = "select count(*) number from otc_orders where status=6 and updated_at>='".$time_area."' and updated_at<'".$time_area_end."' and asset='".$value['asset']."' and type=1 GROUP BY asset";
            $buy_number = $otc_trade->query($sql)->row_array();
            $new_otc_data[$key]['buy_number'] = $buy_number['number'];
            $sql = "select sum(amount) buy_amount,AVG(price) as price from otc_orders where status=6 and updated_at>='".$time_area."' and updated_at<'".$time_area_end."' and asset='".$value['asset']."' and type=1";
            $buy_amount = $otc_trade->query($sql)->row_array();
            $new_otc_data[$key]['buy_amount'] = $buy_amount['buy_amount'];
            $new_otc_data[$key]['buy_amount_cny'] = bcmul($buy_amount['buy_amount'],$buy_amount['price'],12);
            $sql = "select user_id from otc_orders where status=6 and updated_at>='".$time_area."' and updated_at<'".$time_area_end."' and asset='".$value['asset']."' and type=1 group by user_id";
            $people = $otc_trade->query($sql)->result_array();
            $people1 = 0;
            foreach ($people as $k => $v) {
                if(isset($v['user_id']))
                {
                    $people1++;
                }
            }
            $new_otc_data[$key]['buy_people'] = $people1;

            $sql = "select count(*) number from otc_orders where status=6 and updated_at>='".$time_area."' and updated_at<'".$time_area_end."' and asset='".$value['asset']."' and type=2 GROUP BY asset";
            $buy_number = $otc_trade->query($sql)->row_array();
            $new_otc_data[$key]['sell_number'] = $buy_number['number'];
            $sql = "select sum(amount) buy_amount,AVG(price) as price from otc_orders where status=6 and updated_at>='".$time_area."' and updated_at<'".$time_area_end."' and asset='".$value['asset']."' and type=2";
            $buy_amount = $otc_trade->query($sql)->row_array();
            $new_otc_data[$key]['sell_amount'] = $buy_amount['buy_amount'];
            $new_otc_data[$key]['sell_amount_cny'] = bcmul($buy_amount['buy_amount'],$buy_amount['price'],12);
            $sql = "select user_id from otc_orders where status=6 and updated_at>='".$time_area."' and updated_at<'".$time_area_end."' and asset='".$value['asset']."' and type=2 group by user_id";
            $people = $otc_trade->query($sql)->result_array();
            
            $people2 = 0;
            foreach ($people as $k => $v) {
                if(isset($v['user_id']))
                {
                    $people2++;
                }
            }
            $new_otc_data[$key]['sell_people'] = $people2;
        }

        foreach ($new_otc_data as $key => $value) {
            if($value['buy_amount']==NULL) $value['buy_amount']=0;
            if($value['buy_number']==NULL) $value['buy_number']=0;
            if($value['sell_amount']==NULL) $value['sell_amount']=0;
            if($value['sell_number']==NULL) $value['sell_number']=0;
        }

        // print_r($new_otc_data);
        // echo "*************************************************************************";

        //otc相关统计
        // $sql = "SELECT asset,sum(total),sum(available),sum(transfer_in),sum(transfer_out) from slice_balance_1565251200 GROUP BY asset;";
        $otc_asset = array('USDT','CNT'); //1999817.95     2131660.66711356
        $otc_snapshot = $this->load->database('otc_snapshot',true);
        for($e=0;$e<count($otc_asset);$e++)
        {
            //账面
            //$sql = "SELECT asset,sum(`change`) as amount from otc_balances where asset='$otc_asset[$e]'";
            $otc_data[$otc_asset[$e]]['total'] = $otc_snapshot->query("SELECT asset,sum(`total`) as amount from slice_balance_$timestamp where asset='$otc_asset[$e]'")->row_array()['amount'];
            // //冻结
            // $otc_data[$otc_asset[$e]]['freeze'] = $otc_trade->query("SELECT asset,sum(`change`) as amount from otc_freezes where created_at<'".$time_area_end."' and asset='$otc_asset[$e]'")->row_array()['amount'];
            //转入
            $otc_data[$otc_asset[$e]]['transfer_in'] = $otc_trade->query("SELECT asset,sum(`change`) as amount from otc_transfers where created_at<'".$time_area_end."' and business='otc_transfer_in' and asset='$otc_asset[$e]'")->row_array()['amount'];
            //转出
            $otc_data[$otc_asset[$e]]['transfer_out'] = $otc_trade->query("SELECT asset,sum(`change`) as amount from otc_transfers where created_at<'".$time_area_end."' and business='otc_transfer_out' and asset='$otc_asset[$e]'")->row_array()['amount'];
            //买入
            $otc_data[$otc_asset[$e]]['buy'] = $otc_trade->query("select sum(amount) amount from otc_orders where updated_at<'".$time_area_end."' and status=6 and asset='".$otc_asset[$e]."' and type=1")->row_array()['amount'];
            //卖出
            $otc_data[$otc_asset[$e]]['sell'] = $otc_trade->query("select sum(amount) amount from otc_orders where updated_at<'".$time_area_end."' and status=6 and asset='".$otc_asset[$e]."' and type=2")->row_array()['amount'];
            //手续费
            $otc_data[$otc_asset[$e]]['fee'] = $otc_trade->query("select sum(fee) fee from otc_orders where updated_at<'".$time_area_end."' and status=6 and asset='".$otc_asset[$e]."'")->row_array()['fee'];
            //价格（取订单里面这个币种的最近一条）
            $otc_data[$otc_asset[$e]]['price'] = $otc_trade->query("select price from otc_orders where updated_at<'".$time_area_end."' and status=6 and asset='".$otc_asset[$e]."' order by id desc limit 1")->row_array()['price'];
        }

        foreach ($otc_data as $key => $value) {
            if($value['total']==NULL) $value['total']=0;
            if($value['transfer_in']==NULL) $value['transfer_in']=0;
            if($value['transfer_out']==NULL) $value['transfer_out']=0;
            if($value['buy']==NULL) $value['buy']=0;
            if($value['sell']==NULL) $value['sell']=0;
            if($value['price']==NULL) $value['price']=0;
            // $value['total'] = bcadd($value['available'],$value['freeze'],12);
            $value['true_amount'] = bcsub($value['transfer_in'],$value['transfer_out'],12);
            $value['true_money'] = bcmul($value['true_amount'],$value['price'],12);
            $value['asset'] = $key;
            $otc_data_result[] = $value;
        }

        array_multisort(array_column($otc_data_result,'true_money'),SORT_DESC,$otc_data_result);
        // print_r($otc_data_result);
        // echo "*************************************************************************";

        // print_r($otc_data_result);die; //otc数据
        //当日币币交易币种手续费
        $sql = "select * from perday_coin_trade_statistics where site_id=$site_id and time_area='".$time_area."' order by trading_number+0 desc";
        $trade_data = $exchange->query($sql)->result_array();

        // var_dump($trade_data);die;
        if(!empty($trade_data)){
            $b = [];
            foreach ($trade_data as $key => $value) {
                $a = explode('_', $value['symbols']);
                array_push($b,$a[0],$a[1]);
            }
            $newb = array_values(array_unique($b)); //去除重复的
            for($c=0;$c<count($newb);$c++)
            {
                $sql = "select sum(BID_fee) as fee from perday_coin_trade_statistics where site_id=$site_id and symbols like '$newb[$c]%' and time_area='".$time_area."' order by trading_number+0 desc";
                $newb_result = $exchange->query($sql)->row_array();
                $sql1 = "select sum(ASK_fee) as fee from perday_coin_trade_statistics where site_id=$site_id and symbols like '%$newb[$c]' and time_area='".$time_area."' order by trading_number+0 desc";
                $newb_result1 = $exchange->query($sql1)->row_array();
                $fee_result[$newb[$c]]['fee'] = bcadd($newb_result['fee'],$newb_result1['fee'],12);
            }
            // var_dump($fee_result);die;
            foreach ($fee_result as $key => $value) {
                $value['asset'] = $key;
                $value['price'] = digui_asset_price($key);
                $value['in_cny'] = bcmul($value['fee'],$value['price'],8);
                $trade_fee[] = $value;
            }
        }else{
            $trade_fee = [];
        }

        //otc手续费
        // print_r($trade_fee);
        // echo "*************************************************************************";


        
        //获取当日充值提币统计
        $sql = "select asset_code,sum(recharge_total) recharge_total,sum(recharge_number) recharge_number,sum(number) number from perday_recharge_statistics where time_area='".$time."' group by asset_code order by recharge_total+0 desc"; 
        $recharge_data = $exchange->query($sql)->result_array();

        $sql = "select symbols,sum(withdraw_total) withdraw_total,sum(withdraw_number) withdraw_number,sum(number) number from perday_withdraw_statistics where time_area='".$time."' group by symbols order by withdraw_total+0 desc"; 
        $withdraw_data = $exchange->query($sql)->result_array();

        // var_dump($recharge_data,$withdraw_data);die;
        $aa = array();
        foreach ($recharge_data as $k1 => $v1) {
            if(!isset($aa['asset_code'])){
                array_push($aa,$v1['asset_code']);
            }
        }

        $bb = array();
        foreach ($withdraw_data as $k2 => $v2) {
            if(!isset($bb['symbols'])){
                array_push($bb,$v2['symbols']);
            }
        }

        foreach ($recharge_data as $kk => $vv) {
            $kk = $vv['asset_code'];
            $new1[$kk]['asset_code'] = $vv['asset_code'];
            $new1[$kk]['recharge_total'] = $vv['recharge_total'];
            $new1[$kk]['recharge_number'] = $vv['recharge_number'];
            $new1[$kk]['recharge_people'] = $vv['number'];
            $new1[$kk]['per_recharge_amount'] = bcdiv($vv['recharge_total'],$vv['number'],12);
        }

        foreach ($withdraw_data as $kk => $vv) {
            $kk = $vv['symbols'];
            $new2[$kk]['symbols'] = $vv['symbols'];
            $new2[$kk]['withdraw_total'] = $vv['withdraw_total'];
            $new2[$kk]['withdraw_number'] = $vv['withdraw_number'];
            $new2[$kk]['withdraw_people'] = $vv['number'];
            $new2[$kk]['per_withdraw_amount'] = bcdiv($vv['withdraw_total'],$vv['number'],12);
        }

        $assets = array_values(array_unique(array_merge($aa,$bb)));
        // var_dump($assets);die;
        if(!empty($assets))
        {
            for($i=0;$i<count($assets);$i++)
            {
                if(isset($new1[$assets[$i]])){
                    $new[$i]['asset'] = $new1[$assets[$i]]['asset_code'];
                    $new[$i]['recharge_total'] = $new1[$assets[$i]]['recharge_total'];
                    $new[$i]['recharge_number'] = $new1[$assets[$i]]['recharge_number'];
                    $new[$i]['recharge_people'] = $new1[$assets[$i]]['recharge_people'];
                    $new[$i]['per_recharge_amount'] = $new1[$assets[$i]]['per_recharge_amount'];

                    if(isset($new2[$assets[$i]])){
                        $new[$i]['withdraw_total'] = $new2[$assets[$i]]['withdraw_total'];
                        $new[$i]['withdraw_number'] = $new2[$assets[$i]]['withdraw_number'];
                        $new[$i]['withdraw_people'] = $new2[$assets[$i]]['withdraw_people'];
                        $new[$i]['per_withdraw_amount'] = $new2[$assets[$i]]['per_withdraw_amount'];
                    }else{
                        $new[$i]['withdraw_total'] = 0;
                        $new[$i]['withdraw_number'] = 0;
                        $new[$i]['withdraw_people'] = 0;
                        $new[$i]['per_withdraw_amount'] = '0';
                    }
                    $new[$i]['in'] = bcsub($new[$i]['recharge_total'], $new[$i]['withdraw_total'],12);
                    $new[$i]['price'] = digui_asset_price($new[$i]['asset']);
                    $new[$i]['in_cny'] = bcmul($new[$i]['in'], $new[$i]['price'],12);
                }else{
                    $new[$i]['asset'] = $new2[$assets[$i]]['symbols'];
                    $new[$i]['recharge_total'] = 0;
                    $new[$i]['recharge_number'] = 0;
                    $new[$i]['recharge_people'] = 0;
                    $new[$i]['per_recharge_amount'] = '0';
                    $new[$i]['withdraw_total'] = $new2[$assets[$i]]['withdraw_total'];
                    $new[$i]['withdraw_number'] = $new2[$assets[$i]]['withdraw_number'];
                    $new[$i]['withdraw_people'] = $new2[$assets[$i]]['withdraw_people'];
                    $new[$i]['per_withdraw_amount'] = $new2[$assets[$i]]['per_withdraw_amount'];
                    $new[$i]['in'] = bcsub($new[$i]['recharge_total'], $new[$i]['withdraw_total'],12);
                    $new[$i]['price'] = digui_asset_price($new[$i]['asset']);
                    $new[$i]['in_cny'] = bcmul($new[$i]['in'], $new[$i]['price'],12);
                }
            }
        }else
        {
            $new = array();
        }

        array_multisort(array_column($new,'in_cny'),SORT_DESC,$new);
        // print_r($new);
        // echo "*************************************************************************";
        // print_r($new_history);
        // echo "*************************************************************************";

        //调整资金记录
        $sql = "select A.*,B.true_name from operation_money_logs A left join b_admin B on A.admin_id=B.user_id where A.created_time>='".$time_area."' and A.created_time<'".$time_area_end."'"; 
        $correct_balance_data = $exchange->query($sql)->result_array();

        // var_dump($correct_balance_data);die;
        //新增交易对信息
        $sql = "select A.id,A.symbol,B.admin_id,B.created_at,C.true_name from total_symbols A left join admin_operation_logs B on A.id=B.business_id left join b_admin C on C.user_id=B.admin_id where A.created_at>='".$time_area."' and A.created_at<'".$time_area_end."' and B.operation_type=41"; 
        // var_dump($sql);die;
        $new_symbols = $exchange->query($sql)->result_array();
        // print_r($new_symbols);
        // echo "*************************************************************************";

        // var_dump($new_symbols);die;
        $result['qcdata'] = $qcdata;
        $result['platform_balance'] = $platform_balance;
        $result['user_platform_balance'] = $user_platform_balance_result;
        $result['trade_data'] = $trade_data;
        $result['trade_fee'] = $trade_fee;
        $result['otc_data_result'] = $otc_data_result;
        $result['chongti_day'] = $new;
        $result['chongti_all'] = $new_history;
        $result['correct_balance_data'] = $correct_balance_data;
        $result['new_symbols'] = $new_symbols;
        $result['new_otc_data'] = $new_otc_data;
        $result['time'] = $time;
        $result['time_area_end'] = $time_area_end;
        $result['new_coin_total'] = $new_coin_total;
        // $result['current_time'] = date('Y-m-d H:i:s',time());
        // print_r($result['qcdata']);die;
        return $result;
    }

    //添加后台发送数据统计记录
    public function add_admin_sendemail($content)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $this->Tongji_model->add_admin_sendemail($content,$time);
    }

    public function send_email($content,$time)
    {
        //打入消息队列
        require_once './vendor/autoload.php';
        $connection = new AMQPStreamConnection($this->config->item('rabbitmq_host'), $this->config->item('rabbitmq_port'), $this->config->item('rabbitmq_user'), $this->config->item('rabbitmq_pwd'));
        // $connection = new AMQPStreamConnection('localhost', 5672, 'guest', 'guest');
        $channel = $connection->channel();
        $channel->queue_declare('task_queue', false, true, false, false);
        $arr = array(
            'name'      =>'admin_send_email',
            'ip'        =>$_SERVER['REMOTE_ADDR'],
            'endpoint'  =>'admin',
            // 'params'    => array('yuebo@qq.com','数据统计汇总',$content,1),
            'params'    => array('yuebo@qq.com','数据统计汇总',$content,1),
            'time'      =>$_SERVER['REQUEST_TIME'],
        );

        $detail = json_encode($arr);
        // var_dump($detail);die;
        $msg = new AMQPMessage($detail,array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
        $cc = $channel->basic_publish($msg, '', 'task_queue');
        // echo " [x] Sent 'Hello World!'\n";
        $channel->close();
        $connection->close();
        if($cc != NULL){
            return false;
        }else{
            return true;
        }
    }

    public function newassetstatistics($args,$exchange_db,$trade_log_db)
    {
        $start_time = get_last_day($args); 
        $end_time = $start_time+86400;

        $start_time_format = date('Y-m-d',$start_time);
        $end_time_format = date('Y-m-d',$end_time);

        $assetList = $this->db->query("select asset_code,created_at from total_assets")->result_array();
        // print_r($assetList);die;
        foreach ($assetList as $key => $value) {
            //获取
            $sql = "select A.id from (select id from users where created_at>='".$value['created_at']."' and created_at>='".$start_time_format."' and created_at<'".$end_time_format."') A inner join (select user_id from user_recharge_logs where created_at>'".$start_time_format."' and created_at<'".$end_time_format."' and asset='".$value['asset_code']."' group by user_id) B on A.id=B.user_id";

            // var_dump($sql);die;
            $recharge_people = $exchange_db->query($sql)->result();

            if(empty($recharge_people))
                $recharge_people = 0;
            else
                $recharge_people = count($recharge_people);

            $value['recharge_people'] = $recharge_people;
            //获取持币人数
            // echo $value['asset_code'];
            $sql = "select user_id from slice_balance_$end_time where asset='".$value['asset_code']."' group by user_id";
            // $chibi_people = $trade_log_db->query($sql)->result_array();
            $chibi_user_ids = $trade_log_db->query($sql)->result_array();

            $sql = "select id from users where created_at>='".$value['created_at']."' and created_at>='".$start_time_format."' and created_at<'".$end_time_format."'";
            $chibi_people_users = array_column($exchange_db->query($sql)->result_array(), 'id');
            
            // print_r($chibi_user_ids);
            // print_r($chibi_people_users);die;

            $chibi_people = 0;
            foreach($chibi_user_ids as $v)
            {
                if(in_array($v['user_id'], $chibi_people_users))
                {
                    $chibi_people ++;
                }
            }

            //获取交易人数
            $trade_history_snap = $this->load->database('trade_history_snap',true);
            // var_dump($trade_history_snap);die;
            // $sql = "select user_id from order_history_1555430400 where market like '%".$value['asset_code']."' or market like '".$value['asset_code']."%' group by user_id";
            $sql = "select user_id from order_history_$end_time where market like '%".$value['asset_code']."' or market like '".$value['asset_code']."%' group by user_id";
            $trade_user_ids = $trade_history_snap -> query($sql) ->result_array();

            $trade_people = 0;
            foreach($trade_user_ids as $v)
            {
                if(in_array($v['user_id'], $chibi_people_users))
                {
                    $trade_people ++;
                }
            }

            $this->db->insert('newaddasset', [
                 'time_area' => $start_time_format,
                 'created_at' => date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),
                 'asset' => $value['asset_code'],
                 'asset_createtime' => $value['created_at'],
                 'recharge_people' => $recharge_people,
                 'trade_people' => $trade_people,
                 'chibi_people' => $chibi_people,
            ]);
        }



    }


}