<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

date_default_timezone_set('Asia/Shanghai');//默认中国时区
class Admin_service extends MY_Service{

    public $is_lock = array(
        0 =>'锁定',
        1 =>'启用'
    );
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->model('Roles_model');
    }
    //权限列表
    public function roles_base($role_id,$type,$site_id){
        if($this->config->item('SITE')==='priv'){
            require(APPPATH.'config/priv.php');
        }else{
            require(APPPATH.'config/priv_one.php');
        }

        $info = $this->Roles_model->roles_details($role_id);
        $privilages = $info['privilages'];
        $privilages = explode(',',$privilages);
        $privs = array();
        if($type ==1){ //部门
            //如果是子站，基础权限从子站的超管身上取
            if($site_id!=''){
                //获取子站超管所有权限
                if($this->config->item('SITE')==='priv'){
                    $sting = $this->Roles_model->get_sub_privilages($site_id);
                    $sub_privilages = explode(',',$sting[0]['privilages']);
                    for($i=0;$i<count($sub_privilages);$i++)
                    {
                        foreach ($admin_menu_file as $key => $value) {
                            foreach ($value as $v) {
                                if($v['permission'] == 1 && $v['id'] == $sub_privilages[$i]){
                                    $privs[$v['id']]['parent_id'] =$key;
                                    $privs[$v['id']]['url'] =$v['mod_do_url'];
                                    $privs[$v['id']]['in_menu'] =0;
                                    $privs[$v['id']]['name'] =$v['name'];
                                    $privs[$v['id']]['id'] =$v['id'];
                                }
                            }
                        }
                    }
                }else{
                    foreach ($admin_menu_file as $key=>$value){
                    // var_dump($admin_menu_file);die;
                        foreach ($value as $v){
                            if($v['permission'] == 1){
                                $privs[$v['id']]['parent_id'] =$key;
                                $privs[$v['id']]['url'] =$v['mod_do_url'];
                                $privs[$v['id']]['in_menu'] =0;
                                $privs[$v['id']]['name'] =$v['name'];
                                $privs[$v['id']]['id'] =$v['id'];
                            }
                        }
                    }
                }
                
            }else{
                foreach ($admin_menu_file as $key=>$value){
                    // var_dump($admin_menu_file);die;
                    foreach ($value as $v){
                        if($v['permission'] == 1){
                            $privs[$v['id']]['parent_id'] =$key;
                            $privs[$v['id']]['url'] =$v['mod_do_url'];
                            $privs[$v['id']]['in_menu'] =0;
                            $privs[$v['id']]['name'] =$v['name'];
                            $privs[$v['id']]['id'] =$v['id'];
                        }
                    }
                }
            }
            
        }elseif($type==2){ //岗位
            $parent_info = $this->Roles_model->roles_details($info['parent_id']);
            $parent_privilages = explode(',',$parent_info['privilages']);
            //岗位权限
            foreach ($admin_menu_file as $key=>$value){
                foreach ($value as $v){
                    if($v['permission'] == 1 && in_array($v['id'],$parent_privilages)){
                        $privs[$v['id']]['parent_id'] =$key;
                        $privs[$v['id']]['url'] =$v['mod_do_url'];
                        $privs[$v['id']]['in_menu'] =0;
                        $privs[$v['id']]['name'] =$v['name'];
                        $privs[$v['id']]['id'] =$v['id'];
                    }
                }
            }

        }elseif ($type==3) { //超管
            foreach ($admin_menu_file as $key=>$value){
                foreach ($value as $v){
                    if($v['permission'] == 1){
                        $privs[$v['id']]['parent_id'] =$key;
                        $privs[$v['id']]['url'] =$v['mod_do_url'];
                        $privs[$v['id']]['in_menu'] =0;
                        $privs[$v['id']]['name'] =$v['name'];
                        $privs[$v['id']]['id'] =$v['id'];
                    }
                }
            }
        }
        $admin_menu_file = array();
        foreach ($privilages as $val){
            if(@$privs[$val]){
                $privs[$val]['in_menu'] = 1;
            }
        }
        foreach ($privs as $val){
            $admin_menu_file[$val['parent_id']][] = $val;
        }
        return $admin_menu_file;
    }


    //管理员列表
    public function admin_list($offset,$limit,$site_id){
        $list =  $this->Admin_model->admin_list($offset,$limit,$site_id);

        foreach ($list as &$val){
            $role_list = $this->Admin_model->get_roles($val['user_id']);
            $role_name = array();
            $role_ids = array();
            foreach ($role_list as $v){
                $role_name[] = $v['role_name'];
                $role_ids[] = $v['role_id'];
            }
            $val['role_name'] = implode(',',$role_name);
            $val['role_ids'] = implode(',',$role_ids);
            $val['login_time'] = date('Y-m-d H:i:s',$val['login_time']);
        }
        return $list;
    }
    //子站超管列表
    public function subadmin_list($offset,$limit,$sadmin,$site_id){
        if($site_id != NULL){
            $list =  $this->Admin_model->subadmin_list_bysiteid($offset,$limit,$sadmin,$site_id);
        }else{
            $list =  $this->Admin_model->subadmin_list($offset,$limit,$sadmin);
        }
        foreach ($list as &$val){
            $role_list = $this->Admin_model->get_roles($val['user_id']);
            $role_name = array();
            $role_ids = array();
            foreach ($role_list as $v){
                $role_name[] = $v['role_name'];
                $role_ids[] = $v['role_id'];
            }
            $val['role_name'] = implode(',',$role_name);
            $val['role_ids'] = implode(',',$role_ids);
            $val['login_time'] = date('Y-m-d H:i:s',$val['login_time']);
        }
        return $list;
    }


    //管理员列表-统计
    public function admin_count($site_id){
        return $this->Admin_model->admin_count($site_id);
    }
    //子站超管列表-统计
    public function subadmin_count($sadmin,$site_id){
        if($site_id != NULL){
            return $this->Admin_model->subadmin_count_bysiteid($sadmin,$site_id);
        }else{
            return $this->Admin_model->subadmin_count($sadmin);
        }
    }

    //管理员 禁用/启用
    public function admin_lock($id,$type){
        return $this->Admin_model->admin_lock($id,$type);
    }

    //管理员详情
    public function admin_details($id){
        return $this->Admin_model->admin_details($id);
    }

    public function expire_date(){
        return $this->Admin_model->expire_date();
    }

    //管理员白名单列表
    public function admin_white_list($id){
        return $this->Admin_model->admin_white_list($id);
    }

    //管理员  新增/编辑
    public function admin_update($args){
        $user_name = $args['user_name'];
        $password = !empty($args['password']) ? my_password_hash($args['password']) :my_password_hash(md5(123456)) ;
        $true_name = $args['true_name'];
        $email = $args['email'];
        $phone = isset($args['phone']) ?$args['phone'] : '' ;
        $mobile = $args['mobile'];
        $roles_ids = explode(',',$args['roles_id']);
        $site_id = isset($args['site_id']) ?$args['site_id'] : 0;

        $id = isset($args['user_id']) ? $args['user_id'] :false;


//        //查看邮箱是否重名
//        $cp_email = $this->Admin_model->get_admin_by_email($email);
//        if(!empty($cp_email))  returnJson('402',lang('double_email'));
//        //查看手机号是否重名
//        $cp_mobile = $this->Admin_model->get_admin_by_mobile($mobile);
//        if(!empty($cp_mobile))  returnJson('402',lang('double_mobile'));

        //查看username是否重名
        $res = $this->Admin_model->get_admin_by_username($user_name);
        $this->Admin_model->delete_admin_roles($id);
        if($id){
            if($res && $res['user_id'] !=$id) return false;
            //编辑
            $this->Admin_model->admin_update($id,$user_name,$true_name,$email,$phone,$mobile,$site_id);
            foreach ($roles_ids as $val){
                $this->Admin_model->add_admin_roles($id,$val,$site_id);
            }
        }else{
            if($res) return false;
            //新增
            $user_id =$this->Admin_model->admin_add($user_name,$password,$true_name,$email,$phone,$mobile,$site_id);
            foreach ($roles_ids as $val){
                $this->Admin_model->add_admin_roles($user_id,$val,$site_id);
            }
        }
        return true;
    }

    public function subadmin_update1 ($args)
    {
        $user_name = $args['user_name'];
        $password = !empty($args['password']) ? my_password_hash($args['password']) :my_password_hash(md5(123456)) ;
        $true_name = $args['true_name'];
        $email = $args['email'];
        $phone = $mobile = isset($args['phone']) ?$args['phone'] : '' ;
        // $mobile = isset($args['mobile']) ?$args['mobile'] : '';
        // $roles_ids = explode(',',$args['roles_id']);
        $site_id = isset($args['site_id']) ?$args['site_id'] : 1;
        $id = isset($args['user_id']) ? $args['user_id'] :false;


        $admin_id = isset($args['admin_id']) ? $args['admin_id'] :false; //目标账户id

        //获取目标账户的权限

        //查看username是否重名
        // var_dump($user_name);
        $res = $this->Admin_model->get_admin_by_username($user_name);
        // var_dump($res);die;
        // $this->Admin_model->delete_admin_roles($id);
        if($id){
            if($res && $res['user_id'] !=$id) return false;
            if($res && $res['site_id'] !=$site_id) return false;
            //编辑
            $this->Admin_model->admin_update($id,$user_name,$true_name,$email,$phone,$mobile,$site_id);
            
        }else{
            if($res) return false;
            //新增
            $user_id =$this->Admin_model->subadmin_add($user_name,$password,$true_name,$email,$phone,$mobile,$site_id,1);
            //新增一个空权限的岗位
            $role_name = '子站'.$site_id.'超管';
            $privs = $this->config->item('sub_privilages');
            $time = time();
            $result = $this->Roles_model->add_subadmin_role($role_name,$privs,$site_id,$time,1);
            //新增admin_roles表
            $result = $this->Admin_model->add_admin_roles($user_id,$result,$site_id);
        }
        return true;

    }


    /**
     * Notes: 新增超管配置
     * User: 张哲
     * Date: 2019-08-02
     * Time: 14:22
     */
    public function subadmin_update($args)
    {
        $user_name = $args['user_name'];
        $password = !empty($args['password']) ? my_password_hash($args['password']) :my_password_hash(md5(123456)) ;
        $true_name = $args['true_name'];
        $email = $args['email'];
        $phone = $mobile = isset($args['phone']) ?$args['phone'] : '' ;
        // $mobile = isset($args['mobile']) ?$args['mobile'] : '';
        // $roles_ids = explode(',',$args['roles_id']);
        $site_id = isset($args['site_id']) ?$args['site_id'] : 1;
        $id = isset($args['user_id']) ? $args['user_id'] :false;


        $admin_id = isset($args['admin_id']) ? $args['admin_id'] :false; //目标账户id
        //admin_id为非必填，未填写按之前代码走，填写后按新代码走
        if(empty($admin_id)){
            //查看username是否重名
            // var_dump($user_name);
            $res = $this->Admin_model->get_admin_by_username($user_name);
            // var_dump($res);die;
            // $this->Admin_model->delete_admin_roles($id);
            if($id){
                if($res && $res['user_id'] !=$id) return false;
                if($res && $res['site_id'] !=$site_id) return false;
                //编辑
                $this->Admin_model->admin_update($id,$user_name,$true_name,$email,$phone,$mobile,$site_id);
            }else{
                if($res) return false;
                //新增
                $user_id =$this->Admin_model->subadmin_add($user_name,$password,$true_name,$email,$phone,$mobile,$site_id,1);
                //新增一个空权限的岗位
                $role_name = '子站'.$site_id.'超管';
                $privs = $this->config->item('sub_privilages');
                $time = time();
                $result = $this->Roles_model->add_subadmin_role($role_name,$privs,$site_id,$time,1);
                //新增admin_roles表
                $result = $this->Admin_model->add_admin_roles($user_id,$result,$site_id);
            }
            return true;

        }else{
            //获取目标账户的权限，首先获取目标账户权限表id

            $object = $this->db->select("b_admin_roles.*")
                ->from('b_admin_roles');
            $object =$this->db->where('b_admin_roles.user_id = ',$admin_id);
            $list = $object->get()->result_array();
            $role_id = $list[0]['role_id'];

            $object = $this->db->select("b_roles.*")
                ->from('b_roles');
            $object =$this->db->where('b_roles.role_id = ',$role_id);
            $list1 = $object->get()->result_array();

            $privs =  $list1[0]['privilages'];

            $res = $this->Admin_model->get_admin_by_username($user_name);

            if(!empty($id)){
                //echo 1; var_dump($id,$res['user_id'],$res['site_id'],$site_id);die();
                if($res && $res['user_id'] !=$id) return false;
                if($res && $res['site_id'] !=$site_id) return false;
                //编辑
                $id1 =$this->Admin_model->admin_update1($id,$user_name,$true_name,$email,$phone,$mobile,$site_id,$admin_id);

                //获取修改账户的角色id
                $object = $this->db->select("b_admin_roles.*")
                    ->from('b_admin_roles');
                $object =$this->db->where('b_admin_roles.user_id = ',$id);
                $list = $object->get()->result_array();
                $role_id1 = $list[0]['role_id'];


                //修改权限,获取修改账户id，修改角色账户id
                $data = array();
                $data ['privilages'] = $privs;
                $this->db->where('role_id', $role_id1);
                $this->db->update('b_roles', $data);
            }else{
                if($res) return false;
                //新增
                $user_id =$this->Admin_model->subadmin_add1($user_name,$password,$true_name,$email,$phone,$mobile,$site_id,1,$admin_id);
                //新增一个空权限的岗位
                $role_name = '子站'.$site_id.'超管';
                //$privs = $this->config->item('sub_privilages');

                $time = time();

                $result = $this->Roles_model->add_subadmin_role($role_name,$privs,$site_id,$time,1);
                //新增admin_roles表
                $result = $this->Admin_model->add_admin_roles($user_id,$result,$site_id);
            }
            return true;
        }



    }

    //删除管理员
    public function admin_delete($user_id){
        $this->Admin_model->delete_admin_roles_by_user($user_id);
        $this->Admin_model->delete_admin_by_user($user_id);
    }

    //删除角色
    public function roles_delete($role_id){
        $this->db->trans_begin();
        //删除角色或者部门
        $role_info = $this->roles_details($role_id);
        if(!$role_info){
            returnJson('402','该角色或部门不存在');
        }
        $parent_id = $role_info['parent_id'];

        if($parent_id == 0){

            //如果是部门
            $roles_list = $this->Roles_model->get_roles_by_parent($role_id);
            foreach ($roles_list as $val){
                $this->Roles_model->admin_roles_delete($val['role_id']);
            }
            $this->Roles_model->roles_delete_parent($role_id);
        }else{
            //如果是岗位
            $this->Roles_model->roles_delete($role_id);
            $this->Roles_model->admin_roles_delete($role_id);
        }

        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

    }





    /*
     * 角色操作
     * */

    //获取所有角色
    public function roles_all(){
        $data = $this->Roles_model->roles_all();
        return $data;
    }
    //角色列表
    public function roles_list($offset,$limit,$parent_id,$site_id){
        if($site_id){
            $list =  $this->Roles_model->roles_list_by_site($offset,$limit,$parent_id,$site_id);
        }else{
            $list =  $this->Roles_model->roles_list($offset,$limit,$parent_id);
        }

        foreach ($list as $key=>&$val){
            $val['create_time']= date('Y-m-d',$val['create_time']);
        }
        return $list;
    }

    //角色列表-统计
    public function roles_count($parent_id,$site_id){
        if($site_id){
            $list =  $this->Roles_model->roles_count_by_site($parent_id,$site_id);
        }else{
            $list =  $this->Roles_model->roles_count($parent_id);
        }
        return $list;
    }

    //获取所有岗位
    public function roles_list_all($offset,$limit,$site_id){
        if($site_id){
            $list =  $this->Roles_model->roles_list_all_by_site($offset,$limit,$site_id);
        }else{
            $list =  $this->Roles_model->roles_list_all($offset,$limit);
        }
        foreach ($list as $key=>&$val){
            $val['create_time']= date('Y-m-d',$val['create_time']);
        }
        return $list;
    }
    //获取所有岗位-统计
    public function roles_count_all($site_id){
        if($site_id){
            $list =  $this->Roles_model->roles_count_all_by_site($site_id);
        }else{
            $list =  $this->Roles_model->roles_count_all();
        }
        return $list;
    }

    //角色 禁用/启用
    public function roles_lock($id,$type){
        return $this->Roles_model->roles_lock($id,$type);
    }

    //角色  新增/编辑
    public function roles_update($args){
        $user_name = $args['role_name'];
        $true_name = $args['description'];
        $email = $args['privilages'];
        $role_id = isset($args['role_id']) ? $args['role_id'] :false;
        if($role_id){
            //编辑
            $this->Roles_model->roles_update($role_id,$user_name,$true_name,$email);
        }else{
            //新增
            $this->Roles_model->roles_add($user_name,$true_name,$email);
        }
        return true;
    }

    //单个角色权限列表
    public function roles_details($id){
        return $this->Roles_model->roles_details($id);
    }

    //部门岗位----------------------------------------------------

    /*
     * 更新部门/岗位信息
     */
    public function roles_update_jobs($role_id,$update_parent_id,$role_name,$description,$site_id){
        $info = $this->Roles_model->get_info_by_role_name($role_name,$site_id);
        if($role_id){
            if($info && $info['role_name'] != $role_name) return false;
            if(!$update_parent_id){
                //更新站点id
                $this->Roles_model->roles_update_site($role_id,$site_id);
                $this->Roles_model->roles_update_parent_site($role_id,$site_id);
            }
            return $this->Roles_model->roles_update_parent($role_id,$role_name,$description,$update_parent_id);
        }else{
            if($info) return false;
            return $this->Roles_model->roles_add_parent($role_name,$description,$site_id,$update_parent_id,time());
        }
    }

    /*
     * 更新部门/岗位权限列表
     */
    public function roles_update_privilages($id,$privilages){
        return $this->Roles_model->roles_update_privilages($id,$privilages);
    }

    //登陆
    public function login($user_name,$password){
        $user_info = $this->Admin_model->get_info_by_user_name($user_name);
        if(empty($user_info)){
            returnJson('402','信息输入有误，请重新输入');
        }
        if($user_info['locked'] == 0){
            returnJson('402','被禁止登录，请联系管理员');
        }

        if(!$user_info || $user_info['password']!=  my_password_hash($password)){
            returnJson('402','信息输入有误，请重新输入');
        }
        return $user_info['user_id'];
    }


    public function name($user_name){
        $user_info = $this->Admin_model->name($user_name);

        return $user_info;
    }
    //退出
    public function quit($user_id,$token){
        return $this->Admin_model->quit_token($user_id,$token);
    }

    //更新token
    public function update_user_token($user_id,$token,$time,$ip){
        return $this->Admin_model->update_user_token($user_id,$token,$time,$ip);
    }

    /**
     * Notes: 更新登录时间和ip
     * User: 张哲
     * Date: 2019/3/19
     * Time: 13:55
     */
    public function update_user_login_time($user_id,$time,$ip,$token){
        return $this->Admin_model->update_user_login_time($user_id,$time,$ip,$token);
    }

    //修改密码
    public function update_password($user_id,$password){

        $password = my_password_hash($password);
        return $this->Admin_model->update_password($user_id,$password);
    }

    //自修改密码
    public function update_password_self($user_id,$old_password,$password){
        //验证原始密码正确性
        $old_password = my_password_hash($old_password);
        $result = $this->db->query("select password from b_admin where user_id=$user_id")->row_array();
        if($old_password !== $result['password'])
            returnJson('402',lang('The original password is not fought for'));
        $password = my_password_hash($password);
        return $this->Admin_model->update_password($user_id,$password);
    }

    //总览
    public function user_overview($site_id){
        $this->load->model('Account_capital_racharge_model');
        $this->load->model('Account_capital_withdraw_model');
        $this->load->model('Order_miner_model');
        $this->load->model('Deposit_model');
        $this->load->model('Product_hash_model');
        $start = strtotime(date("Y-m-d",strtotime("-1 day")));
        $end = date('Y-m-d H:i:s',$start+86400);
        $last_time = date("Y-m-d H:i:s",time()-3600*24*7);//前7天
        $data['racharge_waiting'] = $this->Account_capital_racharge_model->racharge_waiting($site_id,0,1);//充值待处理
        $data['withdraw_waiting'] =  $this->Account_capital_withdraw_model->withdraw_waiting($site_id,0,1);;//提币待处理
        $data['miner_waiting'] =$this->Order_miner_model->miner_waiting($site_id,2,null,null);//矿机待发货

        $data['miner_sell_num'] =$this->Order_miner_model->miner_waiting($site_id,6,null,null);//所有交易完成的矿机数量
        $data['miner_sell_yesterday_num'] =$this->Order_miner_model->miner_waiting($site_id,6,$start,$end);//昨日交易完成的矿机数量

        $data['user_num'] =$this->User_model->get_count($site_id,null,null);//总用户数量
        $data['user_yesterday_num'] =$this->User_model->get_count($site_id,date('Y-m-d'.'00:00:00',time()-3600*24),date('Y-m-d'.'00:00:00',time()));//昨日新增用户数量

        $data['deposit_num'] =$this->Deposit_model->get_count($site_id,null);//托管总量
        $data['deposit_yesterday_num'] =$this->Deposit_model->get_count($site_id,$last_time);//最新的托管数量
        //BDC待处理，昨日售出云算力，总售出云算力 云算力按台和按T
        $start_time = strtotime(date("Y-m-d",time())); //今日
        $now_time = time(); //昨日
        $last_time = $start_time -86400;

        $all_sell_product_hash_a=$this->Product_hash_model->now_sell_product_hash_a($start_time,$now_time,$site_id);//今日按t
        $up_sell_product_hash_a=$this->Product_hash_model->up_sell_product_hash_a($last_time,$start_time,$site_id);//昨日按t
        $data['all_sell_product_hash_a'] = empty($all_sell_product_hash_a) ? 0: $all_sell_product_hash_a;
        $data['up_sell_product_hash_a'] =empty($up_sell_product_hash_a) ? 0: $up_sell_product_hash_a;
        //托管矿机
        $handle_num=$this->Deposit_model->handle_num($site_id,1);//托管总量
        $data['handle_num'] = empty($handle_num) ? 0: $handle_num;


        return $data;
    }

    //修改权限
    public function update_priv($role_id,$priv_ids){
        $priv_ids = empty($priv_ids) ? array() : $priv_ids;
        $priv_ids = implode(',',$priv_ids);
        return $this->Roles_model->update_priv($role_id,$priv_ids);
    }

    //获取当前管理员拥有的所有的权限列表
    public function sum_privs($user_id){

        //获取权限列表
        $list = $this->Roles_model->get_admin_roles_by_user($user_id);
        
        $privilages = array();
        foreach ($list as $val){
            $privilages[] = @$this->Roles_model->roles_details($val['role_id'])['privilages'];
        }
        $arr = array();
        foreach ($privilages as $val){
            $a = explode(',',$val);
            $arr = array_unique(array_merge($arr,$a));
        }
        $privs = privs();
        $user_priv = array();
        foreach ($arr as $v){
            if(isset($privs[$v])){
                $user_priv[$privs[$v]['parent_name']][] =  $v;
            }
        }
        return $user_priv;
    }

    public function get_roles_by_site($site_id,$is_parent){
        if($is_parent){
             return $this->Roles_model->get_parent_roles_by_site($site_id);
        }else{
             return $this->Roles_model->get_roles_by_site($site_id);
        }
    }

    public function login_roles_all($user_id){
       $info =   $this->Admin_model->login_roles_all($user_id);
       $data = [];
       foreach ($info as &$val){
           $data['site_id']  = $val['site_id'];
           $data['site_name']  = $val['site_name'];
           $data['roles'][]  = $val['parent_name'].'-'.$val['role_name'];
           $data['parent'][$val['parent_id']]['name']  = $val['parent_name'];
           $data['parent'][$val['parent_id']]['parent_id']  = $val['parent_id'];
           $data['language'] =  $this->config->item('admin_language');
           $data['icon'] =  $val['icon'];
           $data['id'] =  $user_id;
           // $data['currency_symbol'] =  $val['currency_symbol'];
       }
       return $data;
    }

    //修改权限
    public function switch_language($args){
        $admin_id = $args['admin_id'];
        $language = $args['language'];
        return $this->Admin_model->switch_language($admin_id,$language);
    }


    /**
     * Notes: 验证验证码
     * User: 张哲
     * Date: 2019/3/14
     * Time: 15:15
     */
    public function verification_code($account,$code){
       return $this->Admin_model->verification_code($account,$code);

    }

    /**
     * Notes: 看下是否是该账号绑定手机号
     * User: 张哲
     * Date: 2019/3/14
     * Time: 15:15
     */
    public function find($user_name,$account){
       return $this->Admin_model->find($user_name,$account);

    }
    public function find2($user_name,$account){
        return $this->Admin_model->find2($user_name,$account);

    }

    /**
     * Notes: 获取当前用户的
     * User: 张哲
     * Date: 2019/3/15
     * Time: 14:04
     */
    public function admin_message($user_name){
        return $this->Admin_model->admin_message($user_name);

    }

    public function admin_message1($user_id){
        return $this->Admin_model->admin_message1($user_id);

    }


    /**
     * Notes: 记录错误次数
     * User: 张哲
     * Date: 2019/3/20
     * Time: 15:18
     * @param $user_id
     * @return mixed
     */
    public function failure_frequency($user_name,$failure_frequncy){
        return $this->Admin_model->failure_frequency($user_name,$failure_frequncy);

    }

    /**
     * Notes: 获取次数
     * User: 张哲
     * Date: 2019/3/20
     * Time: 15:42
     * @param $user_name
     * @return mixed
     */
    public function failure_frequency_count($user_name){
        return $this->Admin_model->failure_frequency_count($user_name);

    }

    /**
     * Notes:次数设置为0
     * User: 张哲
     * Date: 2019/3/20
     * Time: 15:52
     * @param $user_name
     * @return mixed
     */
    public function modify_frequency($user_name,$number){
        return $this->Admin_model->modify_frequency($user_name,$number);

    }




}