<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;


class Zjys_user_service extends MY_Service {

//
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_user_model');
        $this->load->model('Site_model');
        $this->load->model('Zjys_user_withdraw_model');
        $this->load->model('Zjys_c2corder_model');
    }

    public function check_detail($id,$type)
    {
        $object = $this->db->select("admin_operation_logs.*,b_admin.true_name")
        ->join('b_admin','b_admin.user_id=admin_operation_logs.admin_id','left')
        ->from('admin_operation_logs');
        $object =$this->db->where('admin_operation_logs.business_id =',$id);
        if($type==3){
            $object = $this->db->where('admin_operation_logs.operation_type in (1,8,2,3)');
        }elseif($type==2){
            $object = $this->db->where('admin_operation_logs.operation_type in (6,7,11)');
        }elseif($type==1){
            $object = $this->db->where('admin_operation_logs.operation_type in (4,5,10)');
        }elseif($type==4){
            $object = $this->db->where('admin_operation_logs.operation_type in (13,14,15)');
        }else{
            $object = $this->db->where('admin_operation_logs.operation_type in (16,17,18)');
        }
        $list = $object->get()->result_array();
        // var_dump($this->db->last_query());die;
        return $list;
    }
    //获取用户信息接口
    public function get_info($user_id)
    {
        $object = $this->db->select("users.*,b_site.name as site_name,user_identities.name as realname,user_identities.number,,user_vips.vip_level")
        ->join('b_site','b_site.id=users.site_id','left')
        ->join('user_identities','user_identities.user_id=users.id','left')
        ->join('user_vips','user_vips.user_id=users.id','left')
        // ->join('user_banks','user_banks.user_id=users.id','left')
        ->from('users');
        $object =$this->db->where('users.id =',$user_id);
        $object =$this->db->where('users.deleted_at is null');
        $list = $object->get()->result_array();
        return $list[0];
    } 
    //指定用户银行卡列表
    public function get_bank_list($user_id)
    {
        $object = $this->db->select("user_banks.*")
        ->from('user_banks');
        $object =$this->db->where('user_banks.user_id =',$user_id);
        $object =$this->db->where('user_banks.deleted_at is null');
        $list = $object->get()->result_array();
        return $list;
    }
     public function get_bank_list_count($user_id)
    {
        $object = $this->db->select("user_banks.*")
        ->from('user_banks');
        $object =$this->db->where('user_banks.user_id =',$user_id);
        $object =$this->db->where('user_banks.deleted_at is null');
        
        return $this->db->count_all_results();
    }

    //用户提现地址列表
    public function user_withdraw_address_list($offset,$limit,$start_time,$end_time,$asset_code,$user_id)
    {
        $object = $this->db->select("user_withdraw_addresses.*")
        ->from('user_withdraw_addresses');

        $object =$this->db->where('user_withdraw_addresses.user_id =',$user_id);
        $object =$this->db->where('user_withdraw_addresses.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_withdraw_addresses.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_withdraw_addresses.updated_at <=',$end_time);
        }
        
        if(!empty($asset_code)){
            $object =$this->db->where('user_withdraw_addresses.asset =',$asset_code);
        }

        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        // var_dump($list);
        return $list;
    }

    public function user_withdraw_address_list_count($start_time,$end_time,$asset_code,$user_id)
    {
        $object = $this->db->select("user_withdraw_addresses.*")
        ->from('user_withdraw_addresses');

        $object =$this->db->where('user_withdraw_addresses.user_id =',$user_id);
        $object =$this->db->where('user_withdraw_addresses.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_withdraw_addresses.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_withdraw_addresses.updated_at <=',$end_time);
        }
        
        if(!empty($asset_code)){
            $object =$this->db->where('user_withdraw_addresses.asset =',$asset_code);
        }

        return $this->db->count_all_results();
    }


    //用户充值地址列表
    public function user_recharge_address_list($offset,$limit,$start_time,$end_time,$asset_code,$user_id)
    {
        $object = $this->db->select("user_recharge_addresses.*")
        ->from('user_recharge_addresses');

        $object =$this->db->where('user_recharge_addresses.user_id =',$user_id);
        $object =$this->db->where('user_recharge_addresses.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_addresses.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_addresses.updated_at <=',$end_time);
        }
        
        if(!empty($asset_code)){
            $object =$this->db->where('user_recharge_addresses.asset =',$asset_code);
        }

        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        return $list;
    }

    public function user_recharge_address_list_count($start_time,$end_time,$asset_code,$user_id)
    {
        $object = $this->db->select("user_recharge_addresses.*")
        ->from('user_recharge_addresses');

        $object =$this->db->where('user_recharge_addresses.user_id =',$user_id);
        $object =$this->db->where('user_recharge_addresses.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_addresses.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_addresses.updated_at <=',$end_time);
        }
        
        if(!empty($asset_code)){
            $object =$this->db->where('user_recharge_addresses.asset =',$asset_code);
        }

        return $this->db->count_all_results();
    }

    //用户充值地址列表
    public function user_recharge_logs_list($offset,$limit,$start_time,$end_time,$asset_code,$user_id)
    {
        $object = $this->db->select("user_recharge_logs.*")
        ->from('user_recharge_logs');

        $object =$this->db->where('user_recharge_logs.user_id =',$user_id);
        $object =$this->db->where('user_recharge_logs.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_logs.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_logs.updated_at <=',$end_time);
        }
        
        if(!empty($asset_code)){
            $object =$this->db->where('user_recharge_logs.asset =',$asset_code);
        }

        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        return $list;
    }

    public function user_recharge_logs_list_count($start_time,$end_time,$asset_code,$user_id)
    {
        $object = $this->db->select("user_recharge_logs.*")
        ->from('user_recharge_logs');

        $object =$this->db->where('user_recharge_logs.user_id =',$user_id);
        $object =$this->db->where('user_recharge_logs.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_logs.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_logs.updated_at <=',$end_time);
        }
        
        if(!empty($asset_code)){
            $object =$this->db->where('user_recharge_logs.asset =',$asset_code);
        }

        return $this->db->count_all_results();
    }

    //用户统计
    public function statistics_users($offset,$limit,$start_time,$end_time,$site_id)
    {
        $object = $this->db->select("perday_userstatistic.*,b_site.name as site_name")
        ->join('b_site','b_site.id=perday_userstatistic.site_id','left')
        ->from('perday_userstatistic');

        if($site_id!='') $object =$this->db->where('perday_userstatistic.site_id = ',$site_id);

        
        if(!empty($start_time)){
            $object =$this->db->where('perday_userstatistic.time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_userstatistic.time <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('time','desc')->get()->result_array();
        // var_dump($list);die;
        return $list;
    }

    //用户统计
    public function statistics_users_count($start_time,$end_time,$site_id)
    {
        $object = $this->db->select("perday_userstatistic.*")
        ->from('perday_userstatistic');

        if($site_id!='') $object =$this->db->where('perday_userstatistic.site_id = ',$site_id);
        
        if(!empty($start_time)){
            $object =$this->db->where('perday_userstatistic.time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('perday_userstatistic.time <=',$end_time);
        }
        return $this->db->count_all_results();
    }



    //用户统计
    public function statistics_users_task($args)
    {
        $time = isset($args['time']) ? $args['time'] : false;
        if($time === false){//定时任务统计前一天用户
            $start_time = date('Y-m-d',time()-86400);
            $end_time = date('Y-m-d',time());
        }else{ //手动定时任务取当前的用户
            $start_time = date('Y-m-d',strtotime($time));
            $end_time = date('Y-m-d H:i:s',strtotime($time)+86400);
        }
        $start_time_timestamp = strtotime($start_time);
        $end_time_timestamp = strtotime($end_time);
        $siteList = $this->Site_model->site_all();
        $newarr = [];
        foreach ($siteList as $k => $v) {
            $newarr[$k]['name'] = $v['name']; //站点名称
            $newarr[$k]['site_id'] = $v['id']; //站点ID
            $newarr[$k]['time_area'] = $start_time;
            $newarr[$k]['time'] = $start_time;
            $newarr[$k]['register_user'] = $this->get_register_user_all_site($start_time,$end_time,$v['id']);
            $newarr[$k]['recommend_user'] = $this->get_recommend_user_all_site($start_time,$end_time,$v['id']);
            $newarr[$k]['identity_user'] = $this->get_identity_user_all_site($start_time,$end_time,$v['id']);
            $newarr[$k]['login_user'] = $this->get_login_user_all_site($start_time,$end_time,$v['id']);
            $newarr[$k]['last_rate'] = $this->get_last_rate_all_site($start_time_timestamp,$end_time_timestamp,$v['id'],2);//次日留存率
            $newarr[$k]['three_rate'] = $this->get_last_rate_all_site($start_time_timestamp,$end_time_timestamp,$v['id'],3);//次日留存率
            $newarr[$k]['seven_rate'] = $this->get_last_rate_all_site($start_time_timestamp,$end_time_timestamp,$v['id'],7);//次日留存率
        }
        //写入数据库
        //判断该日期是否存在 
        $is_true = $this->Zjys_user_model->time_is_true($start_time);
        if($is_true['num']==0){
            foreach ($newarr as $k => $v) {
                $this->Zjys_user_model->add_perday_userstatistic($v['name'],$v['site_id'],$v['time'],$v['time_area'],$v['register_user'],$v['recommend_user'],$v['identity_user'],$v['login_user'],$v['last_rate'],$v['three_rate'],$v['seven_rate']);
            }
        }
    }


    //获取指定站点注册数
    public function get_register_user_all_site($start_time,$end_time,$site_id)
    {
        $object = $this->db->select("count(users.id)")
        ->from('users');
        $object =$this->db->where('users.site_id =',$site_id);
        $object =$this->db->where('users.deleted_at is null');
        if(!empty($start_time)){
            $object =$this->db->where('users.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }

    //当前时间段内注册用户的id
    public function get_register_userid_all_site($start_time,$end_time,$site_id)
    {
        $object = $this->db->select("users.id")
        ->from('users');
        $object =$this->db->where('users.site_id =',$site_id);
        $object =$this->db->where('users.deleted_at is null');
        if(!empty($start_time)){
            $object =$this->db->where('users.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.created_at <=',$end_time);
        }
        return $this->db->get()->result_array();
    }


    //区域时间内登录用户的人数
    public function get_login_user_all_site($start_time,$end_time,$site_id)
    {
        $object = $this->db->select("count(users.id)")
        // ->join('b_site','b_site.id=users.site_id','left')
        ->from('users');
        $object =$this->db->where('users.site_id =',$site_id);
        $object =$this->db->where('users.deleted_at is null');
        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }
        return $this->db->count_all_results();
    }


    //区域时间内登录用户的id
    public function get_login_userid_all_site($start_time,$end_time,$site_id)
    {
        $object = $this->db->select("users.id")
        // ->join('b_site','b_site.id=users.site_id','left')
        ->from('users');
        $object =$this->db->where('users.site_id =',$site_id);
        $object =$this->db->where('users.deleted_at is null');
        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }
        return $this->db->get()->result_array();
    }



    public function get_recommend_user_all_site($start_time,$end_time,$site_id)
    {
        $object = $this->db->select("count(user_recommends.id) as recomment_total")
        ->join('users','users.id=user_recommends.recommend_user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_recommends');
        // $object =$this->db->where('users.site_id =',$site_id);
        $object =$this->db->where('b_site.id =',$site_id);
        $object =$this->db->where('user_recommends.deleted_at is null');
        if(!empty($start_time)){
            $object =$this->db->where('users.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    public function get_identity_user_all_site($start_time,$end_time,$site_id)
    {
        $object = $this->db->select("count(user_identities.id) as recomment_total")
        ->join('users','users.id=user_identities.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_identities');
        // $object =$this->db->where('users.site_id =',$site_id);
        $object =$this->db->where('b_site.id =',$site_id);
        $object =$this->db->where('user_identities.deleted_at is null');
        if(!empty($start_time)){
            $object =$this->db->where('user_identities.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_identities.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    public function get_last_rate_all_site($start_time,$end_time,$site_id,$days)
    {
        $res = [];
        //获取当日新增用户id
        $user_totalid = $this->get_register_userid_all_site(date('Y-m-d H:i:s',$start_time),date('Y-m-d H:i:s',$end_time),$site_id);
        // var_dump($user_totalid);

        if(!empty($user_totalid)){
            $time_left = $start_time+(86400*($days-1));
            $time_right = $end_time+(86400*($days-1));
            //获取次日登陆用户id
            $last_login_userid = $this->get_login_userid_all_site(date('Y-m-d H:i:s',$time_left),date('Y-m-d H:i:s',$time_right),$site_id);
            // var_dump($last_login_userid);die;
            if(!empty($last_login_userid)){
                foreach ($last_login_userid as $key => $value) {
                    if(in_array($value, $user_totalid))
                    {
                        array_push($res,$value);
                    }
                }
            }
            $last_rate = count($res)/count($user_totalid);
            return $last_rate;
        }else{
            return 0;
        }
    }

    public function get_three_rate_all_site($start_time,$end_time,$site_id)
    {
        
    }

    public function get_seven_rate_all_site($start_time,$end_time,$site_id)
    {
        
    }



    public function get_list($offset,$limit,$name,$start_time,$end_time,$user_identity_auth,$site_id,$uid,$realname,$vip_level)
    {
        $where = ' where 1=1';
        // $where1= ' where 1=1 and D.deleted_at is null';
        $where1= ' where 1=1';
        if($site_id!='')
            $where .= " and site_id = $site_id";
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $where .= " and phone ='".$name."'";
            }else{
                $where .= " and email ='".$name."'";
            }
            
        }
        if(!empty($realname))
            $where .= " and realname = '".$realname."'";
        if(!empty($uid))
            $where .= " and id = $uid";
        if(isset($user_identity_auth))
            $where .= " and user_identity_auth = $user_identity_auth";

        if(!empty($start_time))
            $where .= " and last_login >= '".$start_time."'";
        if(!empty($end_time))
            $where .= " and last_login < '".$end_time."'";
        if($vip_level !=='')
            $where1 .= " and E.vip_level = $vip_level";

        $other_where = " order by id desc";

        if(isset($offset) && $offset!=='' && $limit!=''){
            $other_where.= " limit $offset,$limit";
        }else{
            $other_where.= "";
        }


        $sql = "select
                B.created_at,A.id,B.email,B.phone,B.last_login,B.register_method,B.user_identity_auth,B.two_step_bound,B.forbidden_login,B.forbidden_trade,B.forbidden_withdraw,B.`status`,C.`name`,B.realname,E.vip_level
                FROM
                (select id,last_login from users ".$where.$other_where.") as A
                left join
                users as B on A.id=B.id
                left join
                b_site as C on C.id = B.site_id
                left join 
                user_vips as E on A.id = E.user_id
                ".$where1."
                GROUP BY A.id
                order by A.last_login desc";


        $list = $this->db->query($sql)->result_array();
        // var_dump($this->db->last_query($sql));die;
        foreach ($list as &$val){
            if($val['register_method'] == 0){
                $val['register_method'] = '邮箱';
            }elseif ($val['register_method'] == 1){
                $val['register_method'] = '手机';
            }
            if ($val['user_identity_auth'] == 1){
                $val['user_identity_auth'] = '已认证';
            }else{
                $val['user_identity_auth'] = '未认证';
            }
            if($val['two_step_bound'] == 1){
                $val['two_step_bound'] = '通过';
            }else{
                $val['two_step_bound'] = '不通过';
            }

            // if(!empty($val['phone'])) $val['phone'] = substr_replace($val['phone'],'****', 3,4);
            // if(!empty($val['email'])) $val['email'] = substr_replace($val['email'],'****', 1,2);
           // $val['user_account'] = !empty($val['email']) ? $val['email'] : $val['phone'];
            unset($val['password']);
            unset($val['withdraw_password']);
            unset($val['deleted_at']);
        }
        return $list;
    }


    public function get_count($name,$start_time,$end_time,$user_identity_auth,$site_id,$uid,$realname,$vip_level)
    {
        $where = ' where 1=1';
        $where1= ' where 1=1';
        if($site_id!='')
            $where .= " and site_id = $site_id";
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $where .= " and phone ='".$name."'";
            }else{
                $where .= " and email ='".$name."'";
            }
            
        }
        if(!empty($realname))
            $where .= " and realname = '".$realname."'";
        if(!empty($uid))
            return 1;
            // $where .= " and id = $uid";
        if(isset($user_identity_auth))
            $where .= " and user_identity_auth = $user_identity_auth";

        if(!empty($start_time))
            $where .= " and last_login >= '".$start_time."'";
        if(!empty($end_time))
            $where .= " and last_login < '".$end_time."'";
        if($vip_level !== '')
            $where1 .= " and E.vip_level = $vip_level";

        $sql = "select count(1) as numrows
                FROM
                (select
                count(A.id) as numrows
                FROM
                (select id,last_login from users ".$where.") as A
                left join
                users as B on A.id=B.id
                left join
                b_site as C on C.id = B.site_id
                left join
                user_vips as E on E.user_id = A.id
                ".$where1."
                GROUP BY A.id) F
                ";
        $res = $this->db->query($sql)->row_array();
        if(is_array($res) && !empty($res))
            return $res['numrows'];
        else
            return '0';
    }


    //vip管理列表
    public function vip_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("vip_discounts.*")
        // ->join('b_site','b_site.id=vip_discount.site_id','left')
        ->from('vip_discounts');
        $object =$this->db->where('vip_discounts.deleted_at is null');
        // if($site_id!=1) $object =$this->db->where('vip_discounts.site_id = ',$site_id);

        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        // var_dump($list);die;
        return $list;
    }
    //vip管理列表计数
    public function vip_list_count($site_id)
    {
        $object = $this->db->select("vip_discounts.*")
        // ->join('b_site','b_site.id=vip_discount.site_id','left')
        ->from('vip_discounts');
        $object =$this->db->where('vip_discounts.deleted_at is null');
        // if($site_id!=1) $object =$this->db->where('vip_discounts.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function vip_edit($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $vip_level = isset($args['vip_level']) ? $args['vip_level']: '';//资产码
        $limit_taker_discount = isset($args['trade_limit_taker_discount']) ? $args['trade_limit_taker_discount']: 1;
        $limit_maker_discount = isset($args['trade_limit_maker_discount']) ? $args['trade_limit_maker_discount']: 1;
        $market_taker_discount = isset($args['trade_market_taker_discount']) ? $args['trade_market_taker_discount']: 1;
        $withdraw_discount = isset($args['withdraw_discount']) ? $args['withdraw_discount']: 1;
        // $site_id = isset($args['site_id']) ? $args['site_id']: 1; //不传默认为1，总站
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());


        $this->db->trans_begin();
        if(!$id){
            //新增
//            $res = $this->Zjys_user_model->is_true($vip_level);
//            if($res) return false;
            //查询等级是否存在。查看所有是否存在等级
            $object = $this->db->select("vip_discounts.*")
                ->from('vip_discounts');
            $object =$this->db->where('vip_discounts.vip_level =',$vip_level);
            $list1 = $object->order_by('id','desc')->get()->result_array();
            if(!empty($list1)){
                returnJson('402','该等级已经存在');
            }
            $result = $this->Zjys_user_model->add_vip($vip_level,$limit_taker_discount,$limit_maker_discount,$market_taker_discount,$withdraw_discount,$created_at,$updated_at);
        }else{
//            $res = $this->Zjys_user_model->is_true($vip_level);
//            if(!$res) return false;
            //查看除自己这一条，其它数据是否已经存在改等级
            $object = $this->db->select("vip_discounts.*")
                ->from('vip_discounts');
            $object =$this->db->where('vip_discounts.vip_level =',$vip_level);
            $object =$this->db->where('vip_discounts.id !=',$id);
            $list1 = $object->order_by('id','desc')->get()->result_array();
            if(count($list1)>0){
                returnJson('402','该等级已经存在');
            }
            $result = $this->Zjys_user_model->edit_vip($vip_level,$limit_taker_discount,$limit_maker_discount,$market_taker_discount,$withdraw_discount,$updated_at,$id);
            // var_dump($result);die;
        }
        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    public function lockposition_add($args)
    {
        $id = isset($args['id']) ? $args['id'] : false;
        if(!is_numeric($args['uid'])) return false;

        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());

        // $this->db->trans_start();
        $this->db->trans_begin();
        if($id){
            $result = $this->Zjys_user_model->lockposition_update($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$updated_at,$id);
        }else{
            $status = 0;
            if($args['amount']<=0) returnJson('402','锁仓数量不能大于可用数量');
            $is_true_position = $this->Zjys_user_model->is_position_true($args['asset'],$args['uid'],$status);
            if($is_true_position) returnJson('402','当前有未锁仓冻结，请先解冻再锁仓');
            $result = $this->Zjys_user_model->lockposition_add($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$status,$created_at,$updated_at,0);
            $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'],$args['uid']);
            if(is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
            //2、新增冻结记录
            $balance = bcadd($last_balance['balance'],$args['amount']);
            $detail1 = json_encode(array('id'=>$result));
            $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
            $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$args['uid'],$args['asset'],$args['amount'],$business,$balance,$detail1);
            //3、后台新增操作记录
            // $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
            $description = '后台增加锁仓记录';
            admin_operation_logs($this->user_id,$args['uid'],12,$description,$created_at,$result);
            //4、减去用户可用资金
            $text = '后台锁仓减可用';
            $ss = array('info'=>$text);
            $remark = json_encode($ss);
            $res = update_user_balance_bycurl($args['uid'],$args['asset'],-$args['amount'],$result,$ss,$busi='admin_freeze');
            // $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$args['asset'],'lock_position',$result,-$args['amount'],1,$remark,$remark);
            $trans_status = $this->db->trans_status();
            // print_r($res);
            $data = $res['error'];
            if($data !== NULL)
            {
                $trans_status = false;
            }
        }

        if ($trans_status === false) {
            $this->db->trans_rollback();
             returnJson('402','数据异常，申请锁仓失败，请检查数据合法性！');
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    public function lockposition_list($offset,$limit,$asset,$site_id,$uid,$status)
    {
        $object = $this->db->select("user_lock_positions.*,b_site.name as site_name")
        ->join('users','user_lock_positions.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_lock_positions');
        $object =$this->db->where('user_lock_positions.deleted_at is null');

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
       // $object =$this->db->where('user_identities.status =',2); //实名过的 
        if(!empty($asset)){
            $object =$this->db->where('user_lock_positions.asset =',$asset);
        }

        if(!empty($uid)){
            $object =$this->db->where('user_lock_positions.user_id =',$uid);
        }

        if(isset($status)){
            if($status == 0) $object =$this->db->where('user_lock_positions.status =',0);
            if($status == 1) $object =$this->db->where('user_lock_positions.status =',1);
        }

            
        

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        return $list;
    }

    public function lockposition_list_cron()
    {
        $object = $this->db->select("user_lock_positions.*")
        ->from('user_lock_positions');
        $this->db->where('user_lock_positions.deleted_at is null');//未删除
        // $time = '2018-09-15 22:22:22';
        $time = date('Y-m-d H:i:s',time());
        $object =$this->db->where('user_lock_positions.expire_time <=',$time);
        $object =$this->db->where('user_lock_positions.status =',0);

        $list = $object->order_by('id','desc')->get()->result_array();
        // var_dump($list);die;
        return $list;
    }

    public function is_lockposition($args)
    {
        $object = $this->db->select("user_lock_positions.*")
        ->from('user_lock_positions');
        $this->db->where('user_lock_positions.deleted_at is null');//未删除
        $time = date('Y-m-d H:i:s',time());
        // $object =$this->db->where('user_lock_positions.expire_time <=',$time);
        $object =$this->db->where('user_lock_positions.status =',0);
        $object =$this->db->where('user_lock_positions.user_id =',$args['uid']);
        $object =$this->db->where('user_lock_positions.asset =',$args['asset']);
        return $object->order_by('id','desc')->get()->result_array();
    }

    public function unlockposition($args)
    {
        $object = $this->db->select("user_lock_positions.*")
        ->from('user_lock_positions');
        $this->db->where('user_lock_positions.deleted_at is null');//未删除
        $time = date('Y-m-d H:i:s',time());
        // $object =$this->db->where('user_lock_positions.expire_time <=',$time);
        $object =$this->db->where('user_lock_positions.status =',0);
        $object =$this->db->where('user_lock_positions.user_id =',$args['uid']);
        $object =$this->db->where('user_lock_positions.asset =',$args['asset']);
        $list = $object->order_by('id','desc')->get()->result_array();
        // var_dump($list);die;
        if(is_array($list) && !empty($list)){
            foreach ($list as $key => $value) {

                $this->db->trans_begin();

                $created_at = date("Y-m-d H:i:s",time());
                $updated_at = date("Y-m-d H:i:s",time());
                $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($value['asset'],$value['user_id']);
                
                //2、新增冻结记录
                $balance = $last_balance['balance']-$value['amount'];
                $detail1 = json_encode(array('id'=>$value['id']));
                $business = $this->config->item('ADMIN_UNFREEZE');//freeze表中的business
                $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$value['user_id'],$value['asset'],-$value['amount'],$business,$balance,$detail1);
                //3、后台新增操作记录
                $business = $this->config->item('ADMIN_UNFREEZE_ASSET'); //operation表中的operation_type
                $description = '增加手动解仓记录';
                admin_operation_logs($this->user_id,$value['user_id'],$business,$description,$created_at,$value['id']);
                $this->Zjys_user_withdraw_model->change_lockposition_status($value['id']);
                // var_dump($result);
                //4、减去用户可用资金
                $text = '手动解仓';
                $ss = array('info'=>$text);
                $remark = json_encode($ss);
                $res = update_user_balance_bycurl($value['user_id'],$value['asset'],$value['amount'],$value['id'],$ss,$busi='admin_unfreeze');
                // $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$args['asset'],'unlock_position',$value['id'],$value['amount'],1,$remark,$remark);
                $trans_status = $this->db->trans_status();
                $data = $res['error'];

                if($data !== NULL)
                {
                    $trans_status = false;
                }

                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    continue;
                } else {
                    $this->db->trans_commit();
                    //改为已解锁状态
                    
                }
            }
            return true;
        }else{
            return false;
        }

        // return $list;
    }




    public function lockposition_count($asset,$site_id,$uid,$status)
    {
        $object = $this->db->select("user_lock_positions.*,b_site.name as site_name")
        ->join('users','user_lock_positions.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_lock_positions');
        $object =$this->db->where('user_lock_positions.deleted_at is null');

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
       // $object =$this->db->where('user_identities.status =',2); //实名过的 
        if(!empty($asset)){
            $object =$this->db->where('user_lock_positions.asset =',$asset);
        }

        if(!empty($uid)){
            $object =$this->db->where('user_lock_positions.user_id =',$uid);
        }
        if(isset($status)){
            if($status == 0) $object =$this->db->where('user_lock_positions.status =',0);
            if($status == 1) $object =$this->db->where('user_lock_positions.status =',1);
        }
        return $this->db->count_all_results();
    }


    public function lockposition_delete($id,$time)
    {
        return $this->Zjys_user_model->lockposition_delete($id,$time);
    }



    public function vip_adduser($user_id,$vip_level)
    {
        $this->db->trans_begin();
        // $user_id = '25,26,27';
        $user_id = explode(',', $user_id);
        for($i=0;$i<count($user_id);$i++)
        {
            $result = $this->Zjys_user_model->vip_adduser($user_id[$i],$vip_level); 
        }
        // var_dump($this->db->last_query());
        // var_dump($result);die;

        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    //获取列表
    public function user_identity_list($offset,$limit,$name,$real_name,$code,$start_time,$end_time,$site_id,$uid,$status,$area_code){
        $object = $this->db->select("user_identities.*,b_site.name as site_name,users.phone,users.email")
        ->join('users','users.id=user_identities.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_identities');

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        $object =$this->db->where('user_identities.deleted_at is null');

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }
        if(!empty($area_code)){
            $object =$this->db->where('user_identities.country_id =',$area_code);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_identities.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_identities.updated_at <=',$end_time);
        }
        
        if(!empty($code)){
            $object =$this->db->where('user_identities.number =',$code);
        }

        if(!empty($status)){
            $object =$this->db->where('user_identities.status =',$status);
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        foreach ($list as &$val){
            if ($val['status'] == 1){
                $val['status_type'] = '已提交';
            }elseif($val['status']== 2){
                $val['status_type'] = '已认证';
            }elseif($val['status']== 3){
                $val['status_type'] = '认证失败';
            }else{
                $val['status_type'] = '审核中';
            }
            $val['card_img'] = $this->get_image($val['id']);
            $val['country'] = $this->get_country($val['country_id']);
            if(!empty($val['phone'])) $val['phone'] = substr_replace($val['phone'],'****', 3,4);
            if(!empty($val['email'])) $val['email'] = substr_replace($val['email'],'****', 1,2);
            if(!empty($val['number'])) $val['number'] = substr($val['number'],0,4).'****'.substr($val['number'],-4);
        }
        return $list;
    }

    public function user_safeinfo_list($offset,$limit,$name,$start_time,$end_time,$site_id,$uid){
        $object = $this->db->select("users.id,users.email,users.phone,users.email_bound,users.phone_bound,users.two_step_bound,users.withdraw_password_set,users.bank_card_bound,user_identities.name,b_site.name as site_name")
        ->join('user_identities','users.id=user_identities.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('users');

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        if($uid!='') $object =$this->db->where('users.id = ',$uid);

        $object =$this->db->where('users.deleted_at is null');
        $object =$this->db->where('user_identities.deleted_at is null');
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('last_login','desc')->get()->result_array();
        
        foreach ($list as &$val){
            if ($val['email_bound'] == 0){
                $val['email_bound'] = '未绑定';
            }else{
                $val['email_bound'] = '已绑定';
            }

            if ($val['phone_bound'] == 0){
                $val['phone_bound'] = '未绑定';
            }else{
                $val['phone_bound'] = '已绑定';
            }

            if ($val['withdraw_password_set'] == 0){
                $val['withdraw_password_set'] = '未设置';
            }else{
                $val['withdraw_password_set'] = '已设置';
            }

            if ($val['bank_card_bound'] == 0){
                $val['bank_card_bound'] = '未绑定';
            }else{
                $val['bank_card_bound'] = '已绑定';
            }

            if ($val['two_step_bound'] == 0){
                $val['two_step_bound_status'] = 0;
            }else{
                $val['two_step_bound_status'] = 1;
            }


            if ($val['two_step_bound'] == 0){
                $val['two_step_bound'] = '未认证';
            }else{
                $val['two_step_bound'] = '已认证';
            }

            

            // if(!empty($val['phone'])) $val['phone'] = substr_replace($val['phone'],'****', 3,4);
            // if(!empty($val['email'])) $val['email'] = substr_replace($val['email'],'****', 1,2);
        }
        return $list;
    }


    

    
    public function user_identity_list_count($name,$start_time,$end_time,$real_name,$code,$site_id,$uid,$status,$area_code)
    {
        $object = $this->db->select("user_identities.*,b_site.name as site_name,users.phone,users.email")
        ->join('users','users.id=user_identities.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        //user_identities.realname
        ->from('user_identities');


        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        $object =$this->db->where('user_identities.deleted_at is null');

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($start_time)){
            $object =$this->db->where('user_identities.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_identities.updated_at <=',$end_time);
        }

        if(!empty($area_code)){
            $object =$this->db->where('user_identities.country_id =',$area_code);
        }
        
        if(!empty($code)){
            $object =$this->db->where('user_identities.number =',$code);
        }

        if(!empty($status)){
            $object =$this->db->where('user_identities.status =',$status);
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        return $this->db->count_all_results();

    }


    public function safeinfo_list_count($name,$start_time,$end_time,$site_id,$uid)
    {
        $object = $this->db->select("count(users.id),users.id")
        // $object = $this->db->select("users.*,user_identities.name,b_site.name as site_name")
        ->join('user_identities','users.id=user_identities.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('users');

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        if($uid!='') $object =$this->db->where('users.id = ',$uid);
        $object =$this->db->where('users.deleted_at is null');
        $object =$this->db->where('user_identities.deleted_at is null');
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }
        return $this->db->count_all_results();
        // var_dump($this->db->last_query());die;

    }

    //禁止登陆/允许登陆
    public function update_forbid_login($user_id,$type){
        if($type==0){
            $forbidden_ids = $this->config->item('forbidden_ids');
            if(in_array($user_id, $forbidden_ids)) returnJson('402','该账户不允许开放登录功能');
        }
        if($type==0){
            $business_type_id = 44;
            $business_type_name = '允许用户登录';
        }
        else{
            $business_type_id = 43;
            $business_type_name = '禁止用户登录';
        }
        admin_operation_logs($this->user_id,$user_id,$business_type_id,$business_type_name,$_SERVER['REQUEST_TIME']);
        $this->Zjys_user_model->update_forbid_login($user_id,$type);
    }
    //禁止交易/允许交易
    public function update_forbid_withdraw($user_id,$type){
        if($type==0){
            $forbidden_ids = $this->config->item('forbidden_ids');
            if(in_array($user_id, $forbidden_ids)) returnJson('402','该账户不允许开放提币功能');
        }
        if($type==0){
            $business_type_id = 46;
            $business_type_name = '允许用户提币';
        }
        else{
            $business_type_id = 45;
            $business_type_name = '禁止用户提币';
        }
        admin_operation_logs($this->user_id,$user_id,$business_type_id,$business_type_name,$_SERVER['REQUEST_TIME']);
        return $this->Zjys_user_model->update_forbid_withdraw($user_id,$type);
    }
    //禁止提现/允许提现
    public function update_forbid_trade($user_id,$type){
        if($type==0){
            $business_type_id = 48;
            $business_type_name = '允许用户交易';
        }
        else{
            $business_type_id = 47;
            $business_type_name = '禁止用户交易';
        }
        admin_operation_logs($this->user_id,$user_id,$business_type_id,$business_type_name,$_SERVER['REQUEST_TIME']);
        $this->Zjys_user_model->update_forbid_trade($user_id,$type);
    }


    public function reset_google_verify($id)
    {
        return $this->Zjys_user_model->reset_google_verify($id);
    }

    public function delete_google_verify($id)
    {
        return $this->Zjys_user_model->delete_google_verify($id);
    }

    public function reset_two_factor($id,$time)
    {
        return $this->Zjys_user_model->reset_two_factor($id,$time);
    }

    public function resetidentity($id,$time)
    {
        $status = $this->Zjys_user_model->identity_info($id);
        if($status['status']==2) returnJson('402','操作非法，该用户已认证，无需重置!');
        $this->Zjys_user_model->reset_user_auth($status['user_id']);
        //$this->Zjys_user_model->reset_two_factor($status['user_id'],$time);
        return $this->Zjys_user_model->resetidentity($id,$time);
    }

    public function edit_phoneoremail($id,$phone,$email)
    {
        //查询该用户
        $detail = $this->Zjys_user_model->get_info($id);

        if(is_array($detail) && empty($detail)) return false;
        if(empty($phone) && !empty($email)){
            $email1 = $this->Zjys_user_model->find_email($email,$id);
            if(is_array($email1) && !empty($email1)) return false;
            return $this->Zjys_user_model->edit_phoneoremail($id,$detail['phone'],$email);
        }
        if(empty($email) && !empty($phone))
        {
            $phone1 = $this->Zjys_user_model->find_phone($phone,$id);
            if(is_array($phone1) && !empty($phone1)) return false;
            return $this->Zjys_user_model->edit_phoneoremail($id,$phone,$detail['email']);
        }

        if(!empty($email) && !empty($phone))
        {
            $email1 = $this->Zjys_user_model->find_email($email,$id);
            $phone1 = $this->Zjys_user_model->find_phone($phone,$id);
            if(is_array($email1) && !empty($email1)) return false;
            if(is_array($phone1) && !empty($phone1)) return false;
            return $this->Zjys_user_model->edit_phoneoremail($id,$phone,$email);
        }
    }

    //用户认证审核
    public function user_identity_checkout($id,$status,$remark)
    {
        if($status!=2 && $status!=3) returnJson('402','状态非法');
        //查询当前认证记录
        $identity_detail = $this->Zjys_user_model->identity_info($id);
        $user_id = $identity_detail['user_id'];
        $created_at = date('Y-m-d H:i:s',time());
        if($identity_detail['status'] == $status) returnJson('402','状态非法');
        
        $this->db->trans_begin();
        //成功
        if($status == 2){
            //1、更改状态
            //2、打入时间
            require_once './vendor/autoload.php';
            $connection = new AMQPStreamConnection($this->config->item('rabbitmq_host'), $this->config->item('rabbitmq_port'), $this->config->item('rabbitmq_user'), $this->config->item('rabbitmq_pwd'));
            // $connection = new AMQPStreamConnection('localhost', 5672, 'guest', 'guest');
            $channel = $connection->channel();
            $channel->queue_declare('task_queue', false, true, false, false);
            $iid = array($id);
            $arr = array(
                'name'=>'user_identity_success',
                'ip'=>$_SERVER['REMOTE_ADDR'],
                'endpoint'=>'admin',
                // 'params'=> '['.$id.']',
                'params'=> array((int)$id),
                'time'=>$_SERVER['REQUEST_TIME'],
            );
            $detail = json_encode($arr);
            $msg = new AMQPMessage($detail,array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
            $is_true = $channel->basic_publish($msg, '', 'task_queue');

            if($is_true !== null){
                $trans_status = false;
            }else{
                $trans_status = true;
            }
            // echo " [x] Sent 'Hello World!'\n";
            $channel->close();
            $connection->close();

            $iid = '['.$id.']';
            $this->Zjys_c2corder_model->add_event($created_at,$created_at,$arr['name'],$arr['ip'],$arr['endpoint'],$iid);

            $result = $this->Zjys_user_model->edit_identity_status($id,$status,$remark,$created_at);

            $auth_result = $this->Zjys_user_model->edit_userauth_status($user_id,$created_at);

            $operation_type = $this->config->item('identity_verify_success');
            
            admin_operation_logs($this->user_id,$user_id,$operation_type,'用户认证审核通过',$created_at,$id);

            if ($trans_status === false) {
                $this->db->trans_rollback();
            } else {
                $this->db->trans_commit();
                //改为已解锁状态
                
            }
        }
        //失败
        if($status == 3){
            require_once './vendor/autoload.php';
            $connection = new AMQPStreamConnection($this->config->item('rabbitmq_host'), $this->config->item('rabbitmq_port'), $this->config->item('rabbitmq_user'), $this->config->item('rabbitmq_pwd'));
            // $connection = new AMQPStreamConnection('localhost', 5672, 'guest', 'guest');
            $channel = $connection->channel();
            $channel->queue_declare('task_queue', false, true, false, false);
            $iid = array($id);
            $arr = array(
                'name'=>'user_identity_fail',
                'ip'=>$_SERVER['REMOTE_ADDR'],
                'endpoint'=>'admin',
                // 'params'=> '['.$id.']',
                'params'=> array((int)$id),
                'time'=>$_SERVER['REQUEST_TIME'],
            );
            $detail = json_encode($arr);
            $msg = new AMQPMessage($detail,array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
            $is_true = $channel->basic_publish($msg, '', 'task_queue');
            if($is_true !== null){
                $trans_status = false;
            }else{
                $trans_status = true;
            }

            $channel->close();
            $connection->close();

            $iid = '['.$id.']';
            $this->Zjys_c2corder_model->add_event($created_at,$created_at,$arr['name'],$arr['ip'],$arr['endpoint'],$iid);

            $result = $this->Zjys_user_model->edit_identity_status($id,$status,$remark,$created_at);
            $img_result = $this->Zjys_user_model->delete_identity_img($id,date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']));
            admin_operation_logs($this->user_id,$user_id,'identity_verify_fail','用户认证审核失败',$created_at,$id);
            if ($trans_status === false) {
                $this->db->trans_rollback();
            } else {
                $this->db->trans_commit();
                //改为已解锁状态
                
            }
        }
        
        return $result;
    }
    //根据认证id 获取 生份证图片
    public function get_image($user_identities_id){
        $oss = new \App\Helpers\oss_helper();
        $img = $this->Zjys_user_model->get_img($user_identities_id);
        if(empty($img)) return array();

        foreach ($img as &$val) {
            $val['value'] = $oss->getSignedUrlForGettingObject($val['value']);
        }
        return $img;
    }

    public function get_country($country_id){
        $country = $this->Zjys_user_model->get_country($country_id);
        if(empty($country)) return '';
        return $country['name_cn'];
    }

    public function correct_identity_info($id,$first_name,$last_name,$name,$number,$country_id)
    {
        $this->db->trans_begin();
        $result = $this->Zjys_user_model->identity_info($id);
        if($result['number']!=trim($number)){
            //1、判断是否存在该身份证号码
            $res = $this->Zjys_user_model->is_true_cardnumber($number);
        }
            
        if(!empty($res))
            returnJson('402',lang('cardnumber_true'));

        $result = $this->Zjys_user_model->correct_identity_baseinfo($id,$first_name,$last_name,$name,$number,$country_id);
        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }
        return $result;
    }

    public function add_recommend($re_name,$re_id,$user_name,$user_id)
    {
        //邀请人与被邀请人至少要有一组信息
        if(empty($re_name) && empty($re_id))
            returnJson('402','邀请人信息缺失，请检查所要查询数据');
        if(empty($user_name) && empty($user_id))
            returnJson('402','被邀请人信息缺失，请检查所要查询数据');

        if(!empty($re_name)){
            if(!empty($re_id)){
                //验证id与手机号或邮箱是否匹配
                $sql = "select phone,email from users where id=$re_id";
                $info = $this->db->query($sql)->row_array();
                if(!in_array($re_name,$info))
                    returnJson('402','邀请人的手机号或邮箱与id不匹配，请检查');
            }else{
                //id为空，根据手机号或邮箱查询邀请者的id
                $re_info = $this->Zjys_user_model->get_info_phoneoremail($re_name);
                if(count($re_info)==0) returnJson('402','该 手机号、邮箱没有被用户注册');
                if(count($re_info)>1) returnJson('402','您所查询的用户信息异常，请联系管理员核对');
                $re_id = $re_info[0]['id'];
            }
        }

        if(!empty($user_name)){
            if(!empty($user_id)){
                //验证id与手机号或邮箱是否匹配
                $sql = "select phone,email from users where id=$user_id";
                $info1 = $this->db->query($sql)->row_array();
                if(!in_array($user_name,$info1))
                    returnJson('402','被邀请人的手机号或邮箱与id不匹配，请检查！');
            }else{
                //id为空，根据手机号或邮箱查询被邀请者的id
                $re_info = $this->Zjys_user_model->get_info_phoneoremail($user_name);
                // var_dump($re_info);die;
                if(count($re_info)==0) returnJson('402','该 手机号、邮箱没有被用户注册');
                if(count($re_info)>1) returnJson('402','您所查询的用户信息异常，请联系管理员核对');
                $user_id = $re_info[0]['id'];
            }
        }else{
            $sql = "select phone,email from users where id=$user_id";
            $info1 = $this->db->query($sql)->row_array();
        }



        if($re_id == $user_id) returnJson('402','邀请人与被邀请人id号相同，不能建立邀请关系');
        //验证两用户id合法性
        $sql = "select id from users where id=$re_id";
        $is_safe = $this->db->query($sql)->row_array();
        if($is_safe == NULL) returnJson('402','邀请人id非法');

        $sql = "select id from users where id=$user_id";
        $is_safe = $this->db->query($sql)->row_array();
        if($is_safe == NULL) returnJson('402','被邀请人id非法');
        
        //查询被邀请人是否已经有邀请关系（递归判断）
        $sql = "select * from user_recommends where recommend_user_id=$user_id";
        $is_recommends = $this->db->query($sql)->row_array();
        if($is_recommends != NULL) returnJson(402,'被邀请人已经被别人邀请过了');
        //排除互相邀请关系
        $sql = "select * from user_recommends where recommend_user_id=$re_id and user_id=$user_id";
        $is_recommends = $this->db->query($sql)->row_array();
        if($is_recommends != NULL) returnJson(402,'两邀请用户不能互相邀请');
        //查询被邀请人的是否已经实名
        $sql = "select id from user_identities where status = 2 and user_id=$user_id and deleted_at is null";
        $is_auth = $this->db->query($sql)->row_array();

        if($is_auth == NULL)
            $status = 0;
        else
            $status = 1;


        $created_at = $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        if($user_name){
            $name = $user_name;
        }else{
            if(empty($info1['email']))
                $name = $info1['phone'];
            else
                $name = $info1['email'];
        }
            
        return $this->Zjys_user_model->add_recommend($created_at,$updated_at,$re_id,$user_id,$name,$status);
    }

    public function websafe_login_logs($offset,$limit,$user_id)
    {
        $object = $this->db->select("user_logins.*")
        ->from('user_logins');

        $object =$this->db->where('user_id = ',$user_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        return $list;
    }

    public function websafe_login_logs_count($user_id)
    {
        $object = $this->db->select("user_logins.*")
        ->from('user_logins');

        $object =$this->db->where('user_id = ',$user_id);
        return $this->db->count_all_results();
    }

    public function websafe_operation_logs($offset,$limit,$user_id)
    {
        $object = $this->db->select("user_security_logs.*")
        ->from('user_security_logs');

        $object =$this->db->where('user_id = ',$user_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        return $list;
    }

    public function websafe_operation_logs_count($user_id)
    {
        $object = $this->db->select("user_security_logs.*")
        ->from('user_security_logs');

        $object =$this->db->where('user_id = ',$user_id);
        return $this->db->count_all_results();
    }

//状态等于0不展示;  二者有一个大于零要展示;



    /**
     * Notes: vip记录列表
     * User: 张哲
     * Date: 2019-07-20
     * Time: 15:05
     */
    public function vipRecord($offset,$limit,$start_time,$end_time,$user_id,$vip_level,$status){
        $object = $this->db->select("user_vips.*")
            ->from('user_vips');
        $object =$this->db->where('user_vips.deleted_at is null');
        //$object =$this->db->where('user_vips.vip_level !=',0);
        //
        //$object =$this->db->where('user_vips.verity_level !=',0);
        //$object =$this->db->where('user_vips.status =',1);
        if(!empty($user_id)) $object =$this->db->where('user_vips.user_id = ',$user_id);

        if(!empty($vip_level)){
            $object =$this->db->where('user_vips.vip_level = ',$vip_level);
        }
        if(!empty($status)){
            $object =$this->db->where('user_vips.status = ',$status);
        }

        if(!empty($start_time)){
            $object =$this->db->where('user_vips.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_vips.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('status','asc')->get()->result_array();

        foreach ($list as &$val){
            if ($val['status'] == 0){
//                if($val['vip_level'] == 0){
//                    $val['vip_level'] =  $val['vip_level'];
//                }else{
                    $val['vip_level'] =  $val['verity_level'];
                //}
            }elseif($val['status']== 1){
                $val['vip_level'] =  $val['vip_level'];
            }else{
                $val['vip_level'] =  $val['vip_level'];
            }
        }
        return $list;

    }

    /**
     * Notes: vip记录列表数量
     * User: 张哲
     * Date: 2019-07-20
     * Time: 15:05
     */
    public function vipRecordCount($start_time,$end_time,$user_id,$vip_level,$status){
        $object = $this->db->select("user_vips.*")
            ->from('user_vips');
        $object =$this->db->where('user_vips.deleted_at is null');
        if(!empty($user_id)) $object =$this->db->where('user_vips.user_id = ',$user_id);

        if(!empty($vip_level)){
            $object =$this->db->where('user_vips.vip_level = ',$vip_level);
        }
        if(!empty($status)){
            $object =$this->db->where('user_vips.status = ',$status);
        }

        if(!empty($start_time)){
            $object =$this->db->where('user_vips.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_vips.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: vip等级添加验证
     * User: 张哲
     * Date: 2019-07-20
     * Time: 15:46
     */
    public function vipAddEdit($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $user_id = isset($args['user_id']) ? $args['user_id']: '';
        $vip_level = isset($args['vip_level']) ? $args['vip_level']: '';

        $remark =  isset($args['remark']) ? $args['remark']: '';


        //先查看是否有此用户
        $object = $this->db->select("users.*")
            ->from('users');
        $object =$this->db->where('users.id =',$user_id);
        $list = $object->order_by('id','desc')->get()->result_array();
        if(empty($list)) returnJson('402','无该用户');


        //先查看是否有该等级
        $object = $this->db->select("vip_discounts.*")
            ->from('vip_discounts');
        $object =$this->db->where('vip_discounts.vip_level =',$vip_level);
        $vip_level1 = $object->order_by('id','desc')->get()->result_array();
        if(empty($vip_level1)) returnJson('402','无该等级');


        if (empty($id)) {
      //查看该用户是否已经有修改记录
        $object = $this->db->select("user_vips.*")
            ->from('user_vips');
        $object =$this->db->where('user_vips.user_id =',$user_id);
        $list1 = $object->order_by('id','desc')->get()->result_array();

            if(!empty($list1)){
                $data =array();
                // $data['id'] = $id;
                $data['user_id'] = $user_id;
                $data['verity_level'] = $vip_level;
                $data ['status'] = 0;
                $data ['remark'] = $remark;

                $updated_at = date("Y-m-d H:i:s", time());
                $data ['created_at'] = $updated_at;
                $data ['deleted_at'] = NULL;

                $this->db->where('user_id', $user_id);
                $record_id = $this->db->update('user_vips', $data);
            } else{

                $created_at = date("Y-m-d H:i:s", time());
                $data ['created_at'] = $created_at;
            //新增
                $record_id = $this->db->insert('user_vips', $data);
            }
        } else {

            $data =array();
            // $data['id'] = $id;
            $data['user_id'] = $user_id;
            $data['verity_level'] = $vip_level;
            $data ['status'] = 0;
            $data ['remark'] = $remark;

            $updated_at = date("Y-m-d H:i:s", time());
            $data ['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $record_id = $this->db->update('user_vips', $data);
        }

        if(!empty($record_id))
            $business_id = $record_id;
        $time = date('Y-m-d H:i:s',time());
        $business = '24'; //o
        $description = 'vip提交';
        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);

    }


    /**
     * Notes: vip等级添加验证-审核
     * User: 张哲
     * Date: 2019-07-20
     * Time: 15:46
     */
    public function vipAddEditVerity($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $type = isset($args['type']) ? $args['type']: '';
        $object = $this->db->select("user_vips.*")
            ->from('user_vips');
        $object =$this->db->where('user_vips.id =',$id);
        $list1 = $object->order_by('id','desc')->get()->result_array();
        $user_id = $list1[0]['user_id'];
        if(empty($list1)) returnJson('402','没有该记录');

        $vip_level =$list1[0]['verity_level'];

        $vip_level1 =$list1[0]['vip_level'];


        if($type == 0){
            $id = isset($args['id']) ? $args['id']: '';
            $data = array();
            $data['status'] = 2;
            //拒绝后，调整为和vip_level一直；此处保证初始为0的用户，被拒绝后，页面不展示
            $data['verity_level'] = $vip_level1;
            $data['verity_remark'] = $args['verity_remark'];
            $updated_at = date("Y-m-d H:i:s",time());
            $data['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $record_id =  $this->db->update('user_vips', $data);
        }else{
            $id = isset($args['id']) ? $args['id']: '';
            $data = array();
            $data['status'] = 1;
            $data['vip_level'] = $vip_level;
            $data['verity_remark'] = $args['verity_remark'];
            $updated_at = date("Y-m-d H:i:s",time());
            $data['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $record_id =  $this->db->update('user_vips', $data);
        }


        if(!empty($record_id))
            $business_id = $record_id;
        $time = date('Y-m-d H:i:s',time());
        $business = '25'; //o
        $description = 'vip审核';
        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);
    }




    /**
     * Notes: vip记录列表
     * User: 张哲
     * Date: 2019-07-20
     * Time: 15:05
     */
//    public function vipRecord($offset,$limit,$start_time,$end_time,$user_id,$vip_level,$status){
//        $object = $this->db->select("user_vips.*")
//            ->from('user_vips');
//        $object =$this->db->where('user_vips.deleted_at is null');
//        $object =$this->db->where('user_vips.vip_level !=',0);
//        //
//        //$object =$this->db->where('user_vips.verity_level !=',0);
//        //$object =$this->db->where('user_vips.status =',1);
//        if(!empty($user_id)) $object =$this->db->where('user_vips.user_id = ',$user_id);
//
//        if(!empty($vip_level)){
//            $object =$this->db->where('user_vips.vip_level = ',$vip_level);
//        }
//        if(!empty($status)){
//            $object =$this->db->where('user_vips.status = ',$status);
//        }
//
//        if(!empty($start_time)){
//            $object =$this->db->where('user_vips.created_at >=',$start_time);
//        }
//        if(!empty($end_time)){
//            $object =$this->db->where('user_vips.created_at <=',$end_time);
//        }
//
//        $list = $object->limit($limit,$offset)->order_by('status','asc')->get()->result_array();
//
//        foreach ($list as &$val){
//            if ($val['status'] == 0){
//                if($val['verity_level'] == 0){
//                    $val['vip_level'] =  $val['vip_level'];
//                }else{
//                $val['vip_level'] =  $val['verity_level'];
//                }
//            }elseif($val['status']== 1){
//                $val['vip_level'] =  $val['vip_level'];
//            }else{
//                $val['vip_level'] =  $val['vip_level'];
//            }
//        }
//        return $list;
//
//    }
//
//    /**
//     * Notes: vip记录列表数量
//     * User: 张哲
//     * Date: 2019-07-20
//     * Time: 15:05
//     */
//    public function vipRecordCount($start_time,$end_time,$user_id,$vip_level,$status){
//        $object = $this->db->select("user_vips.*")
//            ->from('user_vips');
//        $object =$this->db->where('user_vips.deleted_at is null');
//        $object =$this->db->where('user_vips.vip_level !=',0);
//        if(!empty($user_id)) $object =$this->db->where('user_vips.user_id = ',$user_id);
//
//        if(!empty($vip_level)){
//            $object =$this->db->where('user_vips.vip_level = ',$vip_level);
//        }
//        if(!empty($status)){
//            $object =$this->db->where('user_vips.status = ',$status);
//        }
//
//        if(!empty($start_time)){
//            $object =$this->db->where('user_vips.created_at >=',$start_time);
//        }
//        if(!empty($end_time)){
//            $object =$this->db->where('user_vips.created_at <=',$end_time);
//        }
//        return $this->db->count_all_results();
//    }
//
//    /**
//     * Notes: vip等级添加验证
//     * User: 张哲
//     * Date: 2019-07-20
//     * Time: 15:46
//     */
//    public function vipAddEdit($args)
//    {
//        $id = isset($args['id']) ? $args['id']: '';
//        $user_id = isset($args['user_id']) ? $args['user_id']: '';
//        $vip_level = isset($args['vip_level']) ? $args['vip_level']: '';
//
//        $remark =  isset($args['remark']) ? $args['remark']: '';
//
//
//        //先查看是否有此用户
//        $object = $this->db->select("users.*")
//            ->from('users');
//        $object =$this->db->where('users.id =',$user_id);
//        $list = $object->order_by('id','desc')->get()->result_array();
//        if(empty($list)) returnJson('402','无该用户');
//
//
//        //先查看是否有该等级
//        $object = $this->db->select("vip_discounts.*")
//            ->from('vip_discounts');
//        $object =$this->db->where('vip_discounts.vip_level =',$vip_level);
//        $vip_level1 = $object->order_by('id','desc')->get()->result_array();
//        if(empty($vip_level1)) returnJson('402','无该等级');
//
//
//        if (empty($id)) {
//            //查看该用户是否已经有修改记录
//            $object = $this->db->select("user_vips.*")
//                ->from('user_vips');
//            $object =$this->db->where('user_vips.user_id =',$user_id);
//            $list1 = $object->order_by('id','desc')->get()->result_array();
//
//            if(!empty($list1)){
//                $data =array();
//                // $data['id'] = $id;
//                $data['user_id'] = $user_id;
//                $data['verity_level'] = $vip_level;
//                $data ['status'] = 0;
//                $data ['remark'] = $remark;
//
//                $updated_at = date("Y-m-d H:i:s", time());
//                $data ['created_at'] = $updated_at;
//                $data ['deleted_at'] = NULL;
//
//                $this->db->where('user_id', $user_id);
//                $record_id = $this->db->update('user_vips', $data);
//            } else{
//
//                $created_at = date("Y-m-d H:i:s", time());
//                $data ['created_at'] = $created_at;
//                //新增
//                $record_id = $this->db->insert('user_vips', $data);
//            }
//        } else {
//
//            $data =array();
//            // $data['id'] = $id;
//            $data['user_id'] = $user_id;
//            $data['verity_level'] = $vip_level;
//            $data ['status'] = 0;
//            $data ['remark'] = $remark;
//
//            $updated_at = date("Y-m-d H:i:s", time());
//            $data ['updated_at'] = $updated_at;
//            $this->db->where('id', $id);
//            $record_id = $this->db->update('user_vips', $data);
//        }
//
//        if(!empty($record_id))
//            $business_id = $record_id;
//        $time = date('Y-m-d H:i:s',time());
//        $business = '24'; //o
//        $description = 'vip提交';
//        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);
//
//    }
//
//
//    /**
//     * Notes: vip等级添加验证-审核
//     * User: 张哲
//     * Date: 2019-07-20
//     * Time: 15:46
//     */
//    public function vipAddEditVerity($args)
//    {
//        $id = isset($args['id']) ? $args['id']: '';
//        $type = isset($args['type']) ? $args['type']: '';
//        $object = $this->db->select("user_vips.*")
//            ->from('user_vips');
//        $object =$this->db->where('user_vips.id =',$id);
//        $list1 = $object->order_by('id','desc')->get()->result_array();
//        $user_id = $list1[0]['user_id'];
//        if(empty($list1)) returnJson('402','没有该记录');
//
//        $vip_level =$list1[0]['verity_level'];
//
//        $vip_level1 =$list1[0]['vip_level'];
//
//
//        if($type == 0){
//            $id = isset($args['id']) ? $args['id']: '';
//            $data = array();
//            $data['status'] = 2;
//            //拒绝后，调整为和vip_level一直；此处保证初始为0的用户，被拒绝后，页面不展示
//            $data['verity_level'] = $vip_level1;
//            $data['verity_remark'] = $args['verity_remark'];
//            $updated_at = date("Y-m-d H:i:s",time());
//            $data['updated_at'] = $updated_at;
//            $this->db->where('id', $id);
//            $record_id =  $this->db->update('user_vips', $data);
//        }else{
//            $id = isset($args['id']) ? $args['id']: '';
//            $data = array();
//            $data['status'] = 1;
//            $data['vip_level'] = $vip_level;
//            $data['verity_remark'] = $args['verity_remark'];
//            $updated_at = date("Y-m-d H:i:s",time());
//            $data['updated_at'] = $updated_at;
//            $this->db->where('id', $id);
//            $record_id =  $this->db->update('user_vips', $data);
//        }
//
//
//        if(!empty($record_id))
//            $business_id = $record_id;
//        $time = date('Y-m-d H:i:s',time());
//        $business = '25'; //o
//        $description = 'vip审核';
//        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);
//    }
//
//
//    /**
//     * Notes: vip删除
//     * User: 张哲
//     * Date: 2019-07-23
//     * Time: 14:23
//     */
//    public function vipDelete($args)
//    {
//        $id = isset($args['id']) ? $args['id']: '';
//        $object = $this->db->select("user_vips.*")
//            ->from('user_vips');
//        $object =$this->db->where('user_vips.id =',$id);
//        $list1 = $object->order_by('id','desc')->get()->result_array();
//        $user_id = $list1[0]['user_id'];
//        if(empty($list1)) returnJson('402','没有该记录');
//
//        $id = isset($args['id']) ? $args['id']: '';
//        $data = array();
//        $data['status'] = 1;
//        $data['cancel_remark'] = $args['cancel_remark'];
//        $deleted_at = date("Y-m-d H:i:s",time());
//        $data['deleted_at'] = $deleted_at;
//        $this->db->where('id', $id);
//        $record_id =  $this->db->update('user_vips', $data);
//
//        if(!empty($record_id))
//            $business_id = $record_id;
//        $time = date('Y-m-d H:i:s',time());
//        $business = '34'; //o
//        $description = 'vip删除';
//        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);
//    }


//$result = $this->Zjys_user_model->vip_adduser($user_id[$i],$vip_level);

}
