
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Transfer_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_symbols_model');
        $this->load->model('Transfer_model');
        $this->load->model('Zjys_user_model');
        $this->load->model('Site_model');
        $this->load->model('Platfrom_transfer_record_model');
        $this->load->model('Config_model');
        $this->load->model('Platfrom_loan_record_model');
        $this->load->model('Admin_model');
        $this->load->model('Platform_account_model');
        $this->load->model('Platfrom_gift_coin_record_model');
        $this->load->model('Platfrom_account_asset_record_model');
        $this->load->model('Assets_model');
        $this->load->model('Zjys_recharge_logs_model');
        $this->load->service('Sys_grpc_service');
        $this->load->model('Wallet_users_model');
        $this->load->model('Wallet_users_asset_model');
        $this->load->model('Zjys_user_withdraw_model');
        $this->load->service('Sys_grpc_service');
    }

    /**
     * Notes: 生成总账户
     * User: 张哲
     * Date: 2018/11/20
     * Time: 16:22
     * @param $site_id
     * @return mixed
     */
    public function generate_total_account(){
        //获取所有站点
        $site = $this->Site_model->site_all();
        foreach($site as $key => $value){
            $site_id = $value['id'];
            $status = "1"; //1为总账户
            //检查该站点总账户是否生成,存在不处理
            //$check = $this->Zjys_user_model->check_generate_total_account($site_id,$status);
            $check = $this->Transfer_model->check_generate_total_account($site_id,$status);

            if(empty($check['id'])){
                $time = date('Y-m-d H:i:s',time());
                $forbidden_login = "1"; //禁止登录
                $forbidden_withdraw = "1"; //禁止提现
                $forbidden_trade = "1"; //禁止交易
                //给users表生成用户
                //$this->Zjys_user_model->generate_total_account($forbidden_login,$forbidden_withdraw,$forbidden_trade,$site_id,$time,$status);
                //获取该用户的UID
                //$UID = $this->Zjys_user_model->check_generate_total_account($site_id,$status);
                //给platform_account表生成总账户记录
                $name = $value['name']."总账户";
                $remark = "";
                $time = date('Y-m-d H:i:s',time());
                $this->Transfer_model->add_total_account($name,$site_id,$remark,$time,$status);


//                $coin_asset = $this->Assets_model->get_coin_asset($site_id);
//                foreach($coin_asset as $key => $value1) {
//                    $balance = 0;
//                    $loan_total = 0;
//                    $repayment_total = 0;
//                    $wait_repayment = 0;
//                    $this->Platfrom_account_asset_record_model->add($value1['site_id'],$value1['asset_name'],$balance,$loan_total,$repayment_total,$wait_repayment,$time);
//                }
            }
        }
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/29
     * Time: 10:00
     */
    public function add_total_account($site_id,$user_id){
        $status = "1"; //1为总账户
        //先看用户是否存在
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out)){
            returnJson('300',lang('user_id not exist'));
        }
        $user_out = $this->Zjys_user_model->get_total_info($user_id,$site_id);
        if(empty($user_out)){
            returnJson('300',lang('not site_id account'));
        }
        $check = $this->Transfer_model->check_generate_total_account($site_id,$status);
        //查询该账户是否使用
        $check1 = $this->Transfer_model->check_generate_user($user_id);
        if(!empty($check1)) returnJson('300', lang('Already a general account'));
        if(!empty($check['id'])){
            if($check['type'] == 0){
                $time = date('Y-m-d H:i:s',time());
                $type = "1";
                $operation_admin_id = $this->user_id;
                //查询操作人员名称
                $admin_operator = $this->Admin_model->get_admin_name($operation_admin_id);
                //更新总账户信息
                $this->Transfer_model->update_total_account($user_id,$site_id,$time,$check['id'],$admin_operator['true_name'],$type);
                //修改用户表总账户的状态
                //$this->Zjys_user_model->update_status($user_id,$status);
                $forbidden_login = "1"; //禁止登录
                $forbidden_withdraw = "1"; //禁止提现
                $forbidden_trade = "1"; //禁止交易
                $this->Zjys_user_model->update_total_status($forbidden_login,$forbidden_withdraw,$forbidden_trade,$user_id,$status);
                //增加币种信息
                $coin_asset = $this->Assets_model->get_coin_asset($site_id);
                foreach($coin_asset as $key => $value1) {
                   // $this->Platfrom_account_asset_record_model->add_user($user_id,$time,$value1['site_id'],$value1['asset_name']);

                    $time = date('Y-m-d H:i:s',time());
                    $balance = 0;
                    $loan_total = 0;
                    $repayment_total = 0;
                    $wait_repayment = 0;
                    $asset_balance = 0;
                    $this->Platfrom_account_asset_record_model->add_account_asset($site_id,$user_id,$value1['asset_code'],$balance,$loan_total,$repayment_total,$wait_repayment,$time,$asset_balance);
                }
            }else{
                returnJson('300', lang('not edit'));
            }
        }
    }

    /**
     * Notes: 新增币种时增加总账户币种记录
     * User: 张哲
     * Date: 2018/11/29
     * Time: 14:15
     * @param $site_id
     * @param $asset
     */
    public function add_asset_record($site_id,$asset){
        $check = $this->Transfer_model->check_site_id($site_id);
        $time = date('Y-m-d H:i:s',time());
        $balance = 0;
        $loan_total = 0;
        $repayment_total = 0;
        $wait_repayment = 0;
        $asset_balance = 0;
        $this->Platfrom_account_asset_record_model->add_account_asset($site_id,$check['user_id'],$asset,$balance,$loan_total,$repayment_total,$wait_repayment,$time,$asset_balance);
    }



    /**
     * Notes:账户管理列表
     * User: 张哲
     * Date: 2018/11/20
     * Time: 14:50
     * @param $offset
     * @param $limit
     * @param $site_id
     * @return mixed
     */
    public function get_accout_list($start_time,$end_time,$offset,$limit,$site_id){
        $object = $this->db->select("platform_account.*")
            ->from('platform_account');
        $object =$this->db->where('platform_account.deleted_at is null');
        if($site_id!='') $object =$this->db->where('platform_account.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platform_account.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platform_account.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
        }
        return $list;
    }

    /**
     * Notes:账户管理条数
     * User: 张哲
     * Date: 2018/11/20
     * Time: 14:50
     * @param $site_id
     * @return mixed
     */
    public function get_accout_list_count($start_time,$end_time,$site_id){
        $object = $this->db->select("platform_account.*")
            ->from('platform_account');
        $object =$this->db->where('platform_account.deleted_at is null');
        if($site_id!='') $object =$this->db->where('platform_account.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platform_account.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platform_account.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes:增加账户管理
     * User: 张哲
     * Date: 2018/11/20
     * Time: 14:13
     * @param $name
     * @param $site_id
     * @param $user_id
     * @param $remark
     */
    public function add_account($name,$site_id,$user_id,$remark){
        //先检测数据是否存在，不存在的话增加新的记录，存在的话就修改原纪录
        $check = $this->Transfer_model->check_account($user_id,$name,$site_id);

        //查询该账户是否使用
        $check1 = $this->Transfer_model->check_generate_user($user_id);
        if(!empty($check1)) returnJson('300', lang('Already a general account'));


        if(!empty($check)){
            $time = date('Y-m-d H:i:s',time());
            $status = 0;
            $type = 2;
            $operation_admin_id = $this->user_id;
            //查询操作人员名称
            $admin_operator = $this->Admin_model->get_admin_name($operation_admin_id);
            $this->Transfer_model->update_account($name,$site_id,$user_id,$remark,$time,$status,$check['id'],$type,$admin_operator['true_name']);

        }else{
            $time = date('Y-m-d H:i:s',time());
            $status = 0;
            $type = 2;
            $operation_admin_id = $this->user_id;
            //查询操作人员名称
            $admin_operator = $this->Admin_model->get_admin_name($operation_admin_id);
            $this->Transfer_model->add_zi_account($name,$site_id,$user_id,$remark,$time,$status,$type,$admin_operator['true_name']);
            $this->Zjys_user_model->update_status($user_id,$status);
        }

    }

    /**
     * Notes:删除账户
     * User: 张哲
     * Date: 2018/11/20
     * Time: 15:30
     * @param $id
     */
    public function delete_accout($id){
        $time = date('Y-m-d H:i:s',time());
        $check = $this->Transfer_model->check_account1($id);
        if($check['status'] == 1){
            returnJson('300',lang('Total account cannot be deleted'));
        }else{
            $this->Transfer_model->delete_accout($id,$time);
        }
    }



    /**
     * Notes: 平台总账户资产列表（新版还款，查询总账户的充值记录总和）
     * User: 张哲
     * Date: 2018/11/29
     * Time: 14:48
     * @param $start_time
     * @param $end_time
     * @param $offset
     * @param $limit
     * @param $site_id
     * @param $page
     */
    public function total_account_assets($start_time,$end_time,$offset,$limit,$site_id,$page,$assets){
        $res = array();
        $ass = array();
        $status = 1;
        //查找所有的总账户
        $object = $this->db->select("platform_account.*")
            ->from('platform_account');
        if($status!='') $object =$this->db->where('platform_account.status = ',$status);
        $object =$this->db->where('platform_account.user_id is not null');
        $list = $object->get()->result_array();
        //查找账户所在站点的币种
        foreach ($list as $key => $asset) {
            $site_asset = $this->Assets_model->get_coin_asset($asset['site_id']);

            foreach ($site_asset as $key => $asset1){
                $ass[$key]['asset'] =  $asset1['asset_code'];
                $ass[$key]['user_id'] =  $asset['user_id'];
                $ass[$key]['site_id'] =  $asset1['site_id'];
            }
            if(!empty($ass)){
                foreach ($ass as $key => $value) {
                    $user_id = isset($value['user_id']) ?$value['user_id'] : 0;
                    $asset = isset($value['asset']) ?$value['asset'] : 0;
                    $response = check_balance($user_id,$asset);
//
                    //获取当前币种余额
                    $DB1 = $this->load->database('trade_history',true);
                    $i = $user_id%100;
                    $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $user_id and asset = '$asset' order by id DESC LIMIT 0,1 ";
                    $object = object_to_array($DB1->query($sql)->result());
                    if (!empty($object)){
                        //$arr = $response['result'][$asset]['available'];
                        $arr = $object[count($object)-1];
                    }else{
                        $arr = array();
                    }
                    $balance_total = 0;
                    if(!empty($arr['balance']))
                        $balance_total = isset($arr['balance']) ? $arr['balance'] : 0;

                    //获取负债（各个币种借款记录合）
                    $loan_sum = $this->Platfrom_loan_record_model->get_loan_sum($user_id,$asset,$value['site_id']);
                    $loan_total = isset($loan_sum['loan_total']) ? doubleval($loan_sum['loan_total']) : 0;

                    // $repayment_sum = $this->Platfrom_loan_record_model->get_repayment_sum($user_id,$val['asset'],$value['site_id']);
                    $repayment_sum = $this->Zjys_recharge_logs_model->get_repayment_sum($user_id,$asset);
                    //已还款
                    $repayment_total = isset($repayment_sum['repayment_total']) ? intval($repayment_sum['repayment_total']) : 0;
                    //欠款
                    $wait_repayment = doubleval($loan_total) - doubleval($repayment_total);

                    //当欠款为负数的时候，需要把 负数加到余额➖还款；当欠款为0或者正数时不需要管欠款，可用余额为他当前余额
                    if($wait_repayment < 0){
                        $asset_balance = $balance_total - $repayment_total - $wait_repayment;
                        $wait_repayment = 0;

                    }else{
                        $wait_repayment = $wait_repayment;
                        $asset_balance = $balance_total - $repayment_total;
                    }

                    if($loan_total == 0){
                        $loan_total = 0;
                    }else{
                        $loan_total = $loan_total;
                    }

                    if($repayment_total == 0){
                        $repayment_total = 0;
                    }else{
                        $repayment_total = $repayment_total;
                    }

                    $res[$key]['site_id'] =  $value['site_id'];
                    $res[$key]['user_id'] =  $value['user_id'];
                    $res[$key]['asset'] =  $asset;
                    $res[$key]['balance'] =  $balance_total;
                    $res[$key]['loan_total'] =  $loan_total;
                    $res[$key]['asset_balance'] =  $asset_balance;
                    $res[$key]['repayment_total'] =  $repayment_total;
                    $res[$key]['wait_repayment'] =  $wait_repayment;
                }
                $time = date('Y-m-d H:i:s',time());
                if(!empty($time)){
                    foreach ($res as $key => $val) {
                        $data1 = $this->Platfrom_account_asset_record_model->get_data($val['site_id'],$val['user_id'],$val['asset']);
                        if(!empty($data1['site_id'])){
                            $this->Platfrom_account_asset_record_model->update($val['site_id'],$val['user_id'],$val['asset'],$val['balance'],$val['loan_total'],$val['repayment_total'],$val['wait_repayment'],$time,$val['asset_balance']);
                        }else{
                            $this->Platfrom_account_asset_record_model->add_account_asset($val['site_id'],$val['user_id'],$val['asset'],$val['balance'],$val['loan_total'],$val['repayment_total'],$val['wait_repayment'],$time,$val['asset_balance']);
                        }
                    }
                }
            }
        }


        $data['list']= $this->Transfer_service->get_totalaccout_list($start_time,$end_time,$offset,$limit,$site_id,$assets);
        $count = $this->Transfer_service->get_totalaccout_list_count($start_time,$end_time,$site_id,$assets);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);

    }
    /**
     * Notes: 平台总账户资产列表（第一版还款写法，直接站内还款）
     * User: 张哲
     * Date: 2018/11/20
     * Time: 19:19
     * @param $site_id
     */
//    public function total_account_assets($start_time,$end_time,$offset,$limit,$site_id,$page){
//        $res = [];
//        $status = 1;
//        //查找所有的总账户
//        $object = $this->db->select("platform_account.*")
//            ->from('platform_account');
//        if($status!='') $object =$this->db->where('platform_account.status=',$status);
//        $list = $object->order_by('id','desc')->get()->result_array();
//        if(!empty($list)){
//            foreach ($list as &$value) {
//                $user_id = $value['user_id'];
//
//                //获取各个币种当前资产
//                $DB1 = $this->load->database('trade_history', true);
//                    for ($i = 0; $i < 100; $i++) {
//                        $sql = "select user_id,asset,balance from balance_history_" . $i . " where  $user_id = user_id group by user_id,asset";
//                        $object = object_to_array($DB1->query($sql)->result());
//                        if ($i == 0) {
//                            $new = array_merge(array(), $object);
//                        } else {
//                            @$new = &array_merge($new, $object);
//                        }
//                    }
//
//                foreach ($new as $key => $val){
//                    //获取负债（各个币种借款记录合）
//                    $loan_sum = $this->Platfrom_loan_record_model->get_loan_sum($user_id,$val['asset'],$value['site_id']);
//                    $val['loan_total'] = isset($loan_sum['loan_total']) ? intval($loan_sum['loan_total']) : 0;
//
//                    //获取已还款（各个币种还款记录）
//                    $repayment_sum = $this->Platfrom_loan_record_model->get_repayment_sum($user_id,$val['asset'],$value['site_id']);
//                    $val['repayment_total'] = isset($repayment_sum['repayment_total']) ? intval($repayment_sum['repayment_total']) : 0;
//
//                    $val['wait_repayment'] = floatval($val['loan_total']) - floatval($val['repayment_total']);
//                    if($val['loan_total'] == 0){
//                        $val['loan_total'] == 0;
//                    }else{
//                        $val['loan_total'] = '-'.$val['loan_total'];
//                    }
//                    if($val['wait_repayment'] == 0){
//                        $val['wait_repayment'] == 0;
//                    }else{
//                        $val['wait_repayment'] = '-'. $val['wait_repayment'];
//                    }
//                    $res[$key]['site_id'] =  $value['site_id'];
//                    $res[$key]['user_id'] =  $val['user_id'];
//                    $res[$key]['asset'] =  $val['asset'];
//                    $res[$key]['balance'] =  $val['balance'];
//                    $res[$key]['loan_total'] =  $val['loan_total'];
//                    $res[$key]['repayment_total'] =  $val['repayment_total'];
//                    $res[$key]['wait_repayment'] =  $val['wait_repayment'];
//                }
//            }
//        }
//
//        $time = date('Y-m-d H:i:s',time());
//        if(!empty($time)){
//            foreach ($res as $key => $val) {
//              $data1 = $this->Platfrom_account_asset_record_model->get_data($val['site_id'],$val['user_id'],$val['asset']);
//
//               if(!empty($data1['site_id'])){
//                    $this->Platfrom_account_asset_record_model->update($val['site_id'],$val['user_id'],$val['asset'],$val['balance'],$val['loan_total'],$val['repayment_total'],$val['wait_repayment'],$time);
//                }else{
//                    $this->Platfrom_account_asset_record_model->add($val['site_id'],$val['user_id'],$val['asset'],$val['balance'],$val['loan_total'],$val['repayment_total'],$val['wait_repayment'],$time);
//                }
//            }
//        }
//
//
//        $data['list']= $this->Transfer_service->get_totalaccout_list($start_time,$end_time,$offset,$limit,$site_id);
//        $count = $this->Transfer_service->get_totalaccout_list_count($start_time,$end_time,$site_id);
//        $data['total']=$count;
//        $data['pageSize']=$limit;
//        $data['curPage']=$page;
//        $data['totalPage']=ceil($count/$limit);
//        returnJson('200',lang('operation_successful'),$data);
//
//    }

    /**
     * Notes: 平台总账户资产列表导出
     * User: 张哲
     * Date: 2018/11/27
     * Time: 15:06
     * @param $start_time
     * @param $end_time
     * @param $site_id
     * @return mixed
     */
    public function total_account_assets_csv($start_time,$end_time,$site_id){
        $object = $this->db->select("platfrom_account_asset_record.*")
            ->from('platfrom_account_asset_record');

        if($site_id!='') $object =$this->db->where('platfrom_account_asset_record.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_account_asset_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_account_asset_record.created_at <=',$end_time);
        }

        $list = $object->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
        }
        return $list;
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/26
     * Time: 20:48
     * @param $start_time
     * @param $end_time
     * @param $offset
     * @param $limit
     * @param $site_id
     * @return mixed
     */
    public function get_totalaccout_list($start_time,$end_time,$offset,$limit,$site_id,$asset){

        $object = $this->db->select("platfrom_account_asset_record.*")
            ->from('platfrom_account_asset_record');
        $object =$this->db->where('platfrom_account_asset_record.deleted_at is null');
        if($site_id!='') $object =$this->db->where('platfrom_account_asset_record.site_id =',$site_id);
        if($asset!='') $object =$this->db->where('platfrom_account_asset_record.asset =',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_account_asset_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_account_asset_record.created_at <=',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
        }
        return $list;
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/26
     * Time: 20:48
     * @param $start_time
     * @param $end_time
     * @param $site_id
     * @return mixed
     */
    public function get_totalaccout_list_count($start_time,$end_time,$site_id,$asset){
        $object = $this->db->select("platfrom_account_asset_record.*")
            ->from('platfrom_account_asset_record');
        $object =$this->db->where('platfrom_account_asset_record.deleted_at is null');
        if($site_id!='') $object =$this->db->where('platfrom_account_asset_record.site_id =',$site_id);
        if($asset!='') $object =$this->db->where('platfrom_account_asset_record.asset =',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_account_asset_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_account_asset_record.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 获取当前用户当前币种余额
     * User: 张哲
     * Date: 2018/11/21
     * Time: 15:41
     * @param $user_id
     */
    public function check_balance($transfer_out_uid,$asset){
        //先看转出用户是否存在
        $user_out = $this->Zjys_user_model->get_info($transfer_out_uid);
        if(empty($user_out))  returnJson('300',lang('transfer_out_uid not exist'));

        $response = check_balance($transfer_out_uid,$asset);
        $arr = array();
        $arr['user_id'] = $transfer_out_uid;
        $arr['asset'] = $asset;
        $arr['balance'] = $response['result'][$asset]['available'];
//        //获取各个币种当前资产
//        $DB1 = $this->load->database('trade_history',true);
//        $i = $transfer_out_uid%100;
//        $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $transfer_out_uid and asset = '$asset' order by id DESC LIMIT 0,1";
//        $object = object_to_array($DB1->query($sql)->result());
        if (!empty($response)){
            //$arr = $object[count($object)-1];
            return $arr;
        }else{
            returnJson('300',lang('transfer_out_uid not asset'));
        }
    }

    /**
     * Notes: 转账列表
     * User: 张哲
     * Date: 2018/11/21
     * Time: 20:02
     * @param $offset
     * @param $limit
     * @param $site_id
     * @return mixed
     */
    public function transfer_list($start_time,$end_time,$offset,$limit,$asset){
        $object = $this->db->select("platfrom_transfer_record.*")
            ->from('platfrom_transfer_record');
        $object =$this->db->where('platfrom_transfer_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_transfer_record.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_transfer_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_transfer_record.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    /**
     * Notes: 转账列表-数量
     * User: 张哲
     * Date: 2018/11/21
     * Time: 20:02
     * @param $site_id
     * @return mixed
     */
    public function transfer_list_count($start_time,$end_time,$asset){
        $object = $this->db->select("platfrom_transfer_record.*")
            ->from('platfrom_transfer_record');
        $object =$this->db->where('platfrom_transfer_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_transfer_record.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_transfer_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_transfer_record.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 转让数据导出
     * User: 张哲
     * Date: 2018/11/21
     * Time: 20:20
     * @param $start_time
     * @param $end_time
     * @param $site_id
     * @return mixed
     */
    public function transfer_csv($start_time,$end_time,$asset,$site_id){
        $object = $this->db->select("platfrom_transfer_record.*")
            ->from('platfrom_transfer_record');
        if($asset!='') $object =$this->db->where('platfrom_transfer_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_transfer_record.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('platfrom_transfer_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_transfer_record.created_at <=',$end_time);
        }

        $list = $object->order_by('created_at','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    /** 插入导出数据记录表
     * Notes:sumf
     * User: 张哲
     * Date: 2018/11/21
     * Time: 20:23
     * @param $tongji_type
     * @param $url
     * @param $created_at
     */
    public function csvlogs($tongji_type,$url,$created_at){
        $this->Config_model->csvlogs_add($tongji_type,$url,$created_at);
    }


    /**
     * Notes: 获取还款地址
     * User: 张哲
     * Date: 2018/11/29
     * Time: 16:08
     * @param $site_id
     * @param $user_id
     */
    public function repayment_address($user_id,$asset){
        $time = date('Y-m-d H:i:s',time());
        $repayment_address = $this->Zjys_recharge_logs_model->repayment_address($user_id,$asset);

        if(empty($repayment_address)){
            $wallet_user_id = $this->Wallet_users_model->check_user_id($user_id);
            if(empty($wallet_user_id)){
                $balance = 0;
                //请求钱包用户id
                $create_user_id = $this->Sys_grpc_service->CreateWalletUser($user_id);
                //插入钱包用户表
                if(!empty($create_user_id))
                $this->Wallet_users_model->add_user_id($create_user_id,$time,$user_id);
                //请求钱包用户地址
                $create_address = $this->Sys_grpc_service->CreateWalletAddress($asset,$create_user_id);
                if(!empty($create_address)){
                    //插入钱包地址表
                    if($create_address == false){
                        returnJson('300',lang('address is failure'));
                    }else{
                        $this->Wallet_users_asset_model->add_user_address($create_user_id,$create_address,$asset,$time,$balance);
                        //插入充值地址表
                        $this->Zjys_recharge_logs_model->add_address($time,$user_id,$asset,$create_address);
                        $repayment_address = $this->Zjys_recharge_logs_model->repayment_address($user_id,$asset);
                    }
                }else{
                    returnJson('300',lang('address is null'));
                }

            }else{$balance = 0;
                //请求钱包用户地址
                $create_address = $this->Sys_grpc_service->CreateWalletAddress($asset,$wallet_user_id['wallet_user_id']);
                if(!empty($create_address)) {
                    //插入钱包地址表
                    if ($create_address == false) {
                        returnJson('300', lang('address is failure'));
                    } else {
                        $this->Wallet_users_asset_model->add_user_address($wallet_user_id['wallet_user_id'], $create_address, $asset, $time, $balance);
                        //插入充值地址表
                        $this->Zjys_recharge_logs_model->add_address($time, $user_id, $asset, $create_address);
                        $repayment_address = $this->Zjys_recharge_logs_model->repayment_address($user_id, $asset);
                    }
                }else{
                    returnJson('300',lang('address is null'));
                }
            }

        }
        return  $repayment_address;
    }

    /**
     * Notes: 总账户还款功能
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:07
     * @param $args
     * @return bool
     */
    //还款时加判断，是否小于等于借款
    public function repayment($args){
        //先看用户是否存在
        $user_id = $args['user_id'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out)) returnJson('300',lang('user_id not exist'));
        //查看该账户是否是总账户
        if($user_out['status'] == 0){
            returnJson('300',lang('not total account'));
        }
        //判断还款账户是否存在
        $payer_id = $args['payer_id'];
        $user_out1 = $this->Zjys_user_model->get_info($payer_id);
        if(empty($user_out1)) returnJson('300',lang('payer_id not exist'));

        $asset = $args['asset'];
        //获取还款账户余额，判断余额是否足够
        $DB1 = $this->load->database('trade_history',true);
        $i = $payer_id%100;
        $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $payer_id and asset = '$asset' ";
        $object = object_to_array($DB1->query($sql)->result());
        if (!empty($object)){
            $arr = $object[count($object)-1];
            if(!empty($arr['balance'])){
                if($arr['balance']<$args['amount']){
                    returnJson('300',lang('Insufficient balance'));
                }
            }
        }else{
            returnJson('300',lang('transfer_out_uid not asset'));
        }
        //查询借款账户借款总额
        $loan_sum = $this->Platfrom_loan_record_model->get_loan_sum($user_id,$args['asset'],$args['site_id']);
        if(!empty($loan_sum['loan_total']))
            $loan_sum = isset($loan_sum['loan_total']) ? $loan_sum['loan_total'] : 0;

        //获取已还款（各个币种还款记录）
        $repayment_sum = $this->Platfrom_loan_record_model->get_repayment_sum($user_id,$args['asset'],$args['site_id']);
        if(!empty( $repayment_sum['repayment_total']))
            $repayment_total = isset($repayment_sum['repayment_total']) ? $repayment_sum['repayment_total'] : 0;

        //剩余还款数
        if(!empty($repayment_total))
        $remain = floatval($loan_sum) - floatval($repayment_total);
        //还款数不能大于借款数减去已还款
        if(!empty($remain))
        if ($args['amount'] > $remain){
            returnJson('300',lang('can not'));
        }

        $site_id = $user_out['site_id'];
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $amount_neg = "-".$amount;
        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());
        $status = 1;

        $this->db->trans_begin();
        //插入还款记录表
        $bussness_id = $this->Platfrom_loan_record_model->add($operation_admin_id,$time,$asset,$amount,$user_id,$remark,$site_id,$status,$payer_id);
        $bussness = 'admin_loanmoney';
        $remark = array('info'=>$remark);
        //$res = update_user_balance_bycurl($payer_id,$asset,$amount_neg,$bussness_id,$remark,$bussness);

        $remark_add = array('info'=>$user_id,'remark'=>$remark);
        $remark_add = json_encode($remark_add);
        $res = $this->Sys_grpc_service->ActivityBalanceUpdate($payer_id,0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);

        $trans_status = $this->db->trans_status();
        if($res['result']['status'] != 'success')
        {
            $trans_status = false;
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return $args;
        } else {
            $this->db->trans_commit();
            return true;
        }

    }

    /**
     * Notes: 借款列表
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:32
     * @param $offset
     * @param $limit
     * @param $asset
     * @return mixed
     */
    public function loan_list($start_time,$end_time,$offset,$limit,$asset,$site_id){
        $object = $this->db->select("platfrom_loan_record.*")
            ->from('platfrom_loan_record')
            ->where('platfrom_loan_record.status = ',0);
        $object =$this->db->where('platfrom_loan_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_loan_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_loan_record.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_loan_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_loan_record.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();

        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }

            if($val['status'] = 0){
                $val['status'] ="借款";
            }else if($val['status'] = 1){
                $val['status'] ="还款";
            }

        }

        return $list;
    }

    /**
     * Notes: 借款列表-数量
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:33
     * @param $asset
     * @return mixed
     */
    public function loan_list_count($start_time,$end_time,$asset,$site_id){
        $object = $this->db->select("platfrom_loan_record.*")
            ->from('platfrom_loan_record')
            ->where('platfrom_loan_record.status = ',0);
        $object =$this->db->where('platfrom_loan_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_loan_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_loan_record.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_loan_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_loan_record.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 还款列表
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:42
     * @param $start_time
     * @param $end_time
     * @param $offset
     * @param $limit
     * @param $asset
     * @param $site_id
     * @return mixed
     */
    public function repayment_list($start_time,$end_time,$offset,$limit,$asset,$site_id){
        $object = $this->db->select("platfrom_loan_record.*")
            ->from('platfrom_loan_record')
            ->where('platfrom_loan_record.status = ',1);
        $object =$this->db->where('platfrom_loan_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_loan_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_loan_record.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_loan_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_loan_record.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    /**
     * Notes: 还款列表-数量
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:42
     * @param $start_time
     * @param $end_time
     * @param $asset
     * @param $site_id
     * @return mixed
     */
    public function repayment_list_count($start_time,$end_time,$asset,$site_id){
        $object = $this->db->select("platfrom_loan_record.*")
            ->from('platfrom_loan_record')
            ->where('platfrom_loan_record.status = ',1);
        $object =$this->db->where('platfrom_loan_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_loan_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_loan_record.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_loan_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_loan_record.created_at <=',$end_time);
        }

        return $this->db->count_all_results();
    }

    /**
     * Notes: 借款列表-导出
     * User: 张哲
     * Date: 2018/11/22
     * Time: 12:46
     * @param $start_time
     * @param $end_time
     * @param $asset
     * @return mixed
     */
    public function loan_csv($start_time,$end_time,$asset,$site_id){
        $object = $this->db->select("platfrom_loan_record.*")
            ->from('platfrom_loan_record')
            ->where('platfrom_loan_record.status = ',0);
        $object =$this->db->where('platfrom_loan_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_loan_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_loan_record.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_loan_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_loan_record.created_at <=',$end_time);
        }

        $list = $object->order_by('created_at','desc')->get()->result_array();

        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    /**
     * Notes: 还款列表-导出
     * User: 张哲
     * Date: 2018/11/22
     * Time: 14:38
     * @param $start_time
     * @param $end_time
     * @param $asset
     * @param $site_id
     * @return mixed
     */
    public function repayment_csv($start_time,$end_time,$asset,$site_id){
        $object = $this->db->select("platfrom_loan_record.*")
            ->from('platfrom_loan_record')
            ->where('platfrom_loan_record.status = ',1);
        $object =$this->db->where('platfrom_loan_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_loan_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_loan_record.site_id = ',$site_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_loan_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_loan_record.created_at <=',$end_time);
        }

        $list = $object->order_by('created_at','desc')->get()->result_array();

        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    /**
     * Notes: 赠币管理列表
     * User: 张哲
     * Date: 2018/11/23
     * Time: 15:41
     * @param $start_time
     * @param $end_time
     * @param $offset
     * @param $limit
     * @param $asset
     * @param $site_id
     * @return mixed
     */
    public function gift_coin_list($start_time,$end_time,$offset,$limit,$asset,$site_id,$user_id,$lock,$admin_id){
        $object = $this->db->select("platfrom_gift_coin_record.*")
            ->from('platfrom_gift_coin_record');
        $object =$this->db->where('platfrom_gift_coin_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_gift_coin_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_gift_coin_record.site_id = ',$site_id);
        if($user_id!='') $object =$this->db->where('platfrom_gift_coin_record.user_id = ',$user_id);
        if($lock!='') $object =$this->db->where('platfrom_gift_coin_record.lock = ',$lock);
        if($admin_id!='') $object =$this->db->where('platfrom_gift_coin_record.operator = ',$admin_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_gift_coin_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_gift_coin_record.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    /**
     * Notes: 赠币管理列表-数量
     * User: 张哲
     * Date: 2018/11/23
     * Time: 15:41
     * @param $start_time
     * @param $end_time
     * @param $asset
     * @param $site_id
     * @return mixed
     */
    public function gift_coin_list_count($start_time,$end_time,$asset,$site_id,$user_id,$lock,$admin_id){
        $object = $this->db->select("platfrom_gift_coin_record.*")
            ->from('platfrom_gift_coin_record');

        $object =$this->db->where('platfrom_gift_coin_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_gift_coin_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_gift_coin_record.site_id = ',$site_id);
        if($user_id!='') $object =$this->db->where('platfrom_gift_coin_record.user_id = ',$user_id);
        if($lock!='') $object =$this->db->where('platfrom_gift_coin_record.lock = ',$lock);
        if($admin_id!='') $object =$this->db->where('platfrom_gift_coin_record.operator = ',$admin_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_gift_coin_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_gift_coin_record.created_at <=',$end_time);
        }

        return $this->db->count_all_results();
    }

    /**
     * Notes: 赠币管理列表导出
     * User: 张哲
     * Date: 2018/11/23
     * Time: 15:50
     * @param $start_time
     * @param $end_time
     * @param $asset
     * @param $site_id
     * @return mixed
     */
    public function gift_coin_csv($asset,$site_id,$user_id,$lock,$admin_id){
        $object = $this->db->select("platfrom_gift_coin_record.*")
            ->from('platfrom_gift_coin_record');

        $object =$this->db->where('platfrom_gift_coin_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_gift_coin_record.asset = ',$asset);
        if($site_id!='') $object =$this->db->where('platfrom_gift_coin_record.site_id = ',$site_id);
        if($user_id!='') $object =$this->db->where('platfrom_gift_coin_record.user_id = ',$user_id);
        if($lock!='') $object =$this->db->where('platfrom_gift_coin_record.lock = ',$lock);
        if($admin_id!='') $object =$this->db->where('platfrom_gift_coin_record.operator = ',$admin_id);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_gift_coin_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_gift_coin_record.created_at <=',$end_time);
        }

        $list = $object->order_by('created_at','desc')->get()->result_array();

        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }

            if($val['lock'] == 0){
                $val['lock'] = '否';
            }else  if($val['lock'] == 1){
                $val['lock'] = '是';
            }
        }
        return $list;
    }




//    public function batch_gift_coin($args,$sum,$site_id)
//    {
//
//        if($args['lock'] == 1){
//
//            if(empty($args['expire_time'])) returnJson('300',lang('time is null'));
//
//            //先看用户是否存在
//            $user_id = $args['uid'];
//            $user_out = $this->Zjys_user_model->get_info($user_id);
//            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
//
//            //根据站点查找该站点总账户user_id
//            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
//            if($total_user_id['user_id'] == NULL){
//                returnJson('300',lang('site_id not totalaccount'));
//            }else  if($total_user_id['user_id'] == $user_id){
//                returnJson('300',lang('not give it to yourself'));
//            }
//
//            if(!empty($total_user_id['user_id'])){
//                //获取总账户余额，判断余额是否足够
//                $DB1 = $this->load->database('trade_history',true);
//                $i = $total_user_id['user_id']%100;
//                $asset = $args['asset'];
//                $user_id = $total_user_id['user_id'];
//                $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $user_id and asset = '$asset' ";
//                $object = object_to_array($DB1->query($sql)->result());
//                if (!empty($object)){
//                    $arr = $object[count($object)-1];
//                    if(!empty($arr['balance'])){
//                        if($arr['balance']<$sum){
//                            returnJson('300',lang('Insufficient balance'));
//                        }
//                    }
//                }else{
//                    returnJson('300',lang('transfer_out_uid not asset'));
//                }
//            }
//
//            $site_id = $site_id;
//            $asset = $args['asset'];
//            $amount = trim($args['amount']);
//            $amount_neg = "-".$amount;
//            $remark = isset($args['remark']) ? $args['remark'] : '';
//            $operation_admin_id = $this->user_id;
//            $time = date('Y-m-d H:i:s',time());
//
//            $this->db->trans_begin();
//            //插入赠币记录表
//            if(!empty($args['expire_time'])){
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
//            }else{
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
//            }
//
//            //修改记录表状态
//            $this->Platfrom_gift_coin_record_model->update_data($asset,$amount,$args['uid'],$remark,$args['lock']);
//
//
//            $bussness = 'admin_giftmoney';
//            $remark = array('info'=>$remark);
//            $res = update_user_balance_bycurl($args['uid'],$asset,$amount,$bussness_id,$remark,$bussness);
//            $res1 = update_user_balance_bycurl($total_user_id['user_id'],$asset,$amount_neg,$bussness_id,$remark,$bussness);
//
//
//            //锁仓
//            $id = isset($args['id']) ? $args['id'] : false;
//            if(!is_numeric($args['uid'])) return false;
//            $created_at = date("Y-m-d H:i:s",time());
//            $updated_at = date("Y-m-d H:i:s",time());
//
//            if($id){
//                $result = $this->Zjys_user_model->lockposition_update($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$updated_at,$id);
//            }else{
//                $status = 0;
//                if($args['amount']<=0) returnJson('402','锁仓数量不能大于可用数量');
//                $result = $this->Zjys_user_model->lockposition_add($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$status,$created_at,$updated_at);
//                $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'],$args['uid']);
//                if(is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
//                //2、新增冻结记录
//                $balance = bcadd($last_balance['balance'],$args['amount']);
//                $detail1 = json_encode(array('id'=>$result));
//                $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
//                $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$args['uid'],$args['asset'],$args['amount'],$business,$balance,$detail1);
//                //3、后台新增操作记录
//                $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
//                $description = null;
//                admin_operation_logs($this->user_id,$args['uid'],$business,$description,$created_at,$result);
//                //4、减去用户可用资金
//                $text = '锁仓';
//                $ss = array('info'=>$text);
//                $res_lock = update_user_balance_bycurl($args['uid'],$args['asset'],-$args['amount'],$result,$ss,$busi='lock_position');
//            }
//
//            $trans_status = $this->db->trans_status();
//            if($res['result']['status'] != 'success' || $res1['result']['status'] != 'success' || $res_lock['result']['status'] != 'success')
//            {
//                $trans_status = false;
//            }
//            if ($trans_status === false) {
//                $this->db->trans_rollback();
//                return $args;
//            } else {
//                $this->db->trans_commit();
//                return true;
//            }
//        }else if($args['lock'] == 0){
//            //先看用户是否存在
//            $user_id = $args['uid'];
//            $user_out = $this->Zjys_user_model->get_info($user_id);
//            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
//
//            //根据站点查找该站点总账户user_id
//            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
//            if($total_user_id['user_id'] == NULL){
//                returnJson('300',lang('site_id not totalaccount'));
//            }else  if($total_user_id['user_id'] == $user_id){
//                returnJson('300',lang('not give it to yourself'));
//            }
//
//            if(!empty($total_user_id['user_id'])){
//                //获取总账户余额，判断余额是否足够
//                $DB1 = $this->load->database('trade_history',true);
//                $i = $total_user_id['user_id']%100;
//                $asset = $args['asset'];
//                $user_id = $total_user_id['user_id'];
//                $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $user_id and asset = '$asset' ";
//                $object = object_to_array($DB1->query($sql)->result());
//                if (!empty($object)){
//                    $arr = $object[count($object)-1];
//                    if(!empty($arr['balance'])){
//                        if($arr['balance']<$sum){
//                            returnJson('300',lang('Insufficient balance'));
//                        }
//                    }
//                }else{
//                    returnJson('300',lang('transfer_out_uid not asset'));
//                }
//            }
//
//            $site_id = $site_id;
//            $asset = $args['asset'];
//            $amount = trim($args['amount']);
//            $amount_neg = "-".$amount;
//            $remark = isset($args['remark']) ? $args['remark'] : '';
//            $operation_admin_id = $this->user_id;
//            $time = date('Y-m-d H:i:s',time());
//
//            $this->db->trans_begin();
//            //插入赠币记录表
//            if(!empty($args['expire_time'])){
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
//            }else{
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
//            }
//            //修改记录表状态
//            $this->Platfrom_gift_coin_record_model->update_data($asset,$amount,$args['uid'],$remark,$args['lock']);
//
//            $bussness = 'admin_giftmoney';
//            $remark = array('info'=>$remark);
//            $res = update_user_balance_bycurl($args['uid'],$asset,$amount,$bussness_id,$remark,$bussness);
//            $res1 = update_user_balance_bycurl($total_user_id['user_id'],$asset,$amount_neg,$bussness_id,$remark,$bussness);
//
//            $trans_status = $this->db->trans_status();
//            if($res['result']['status'] != 'success' || $res1['result']['status'] != 'success')
//            {
//                $trans_status = false;
//            }
//            if ($trans_status === false) {
//                $this->db->trans_rollback();
//                return $args;
//            } else {
//                $this->db->trans_commit();
//                return true;
//            }
//        }else{
//            //先看用户是否存在
//            $user_id = $args['uid'];
//            $user_out = $this->Zjys_user_model->get_info($user_id);
//            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
//
//            //根据站点查找该站点总账户user_id
//            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
//            if($total_user_id['user_id'] == NULL){
//                returnJson('300',lang('site_id not totalaccount'));
//            }else  if($total_user_id['user_id'] == $user_id){
//                returnJson('300',lang('not give it to yourself'));
//            }
//
//            if(!empty($total_user_id['user_id'])){
//                //获取总账户余额，判断余额是否足够
//                $DB1 = $this->load->database('trade_history',true);
//                $i = $total_user_id['user_id']%100;
//                $asset = $args['asset'];
//                $user_id = $total_user_id['user_id'];
//                $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $user_id and asset = '$asset' ";
//                $object = object_to_array($DB1->query($sql)->result());
//                if (!empty($object)){
//                    $arr = $object[count($object)-1];
//                    if(!empty($arr['balance'])){
//                        if($arr['balance']<$sum){
//                            returnJson('300',lang('Insufficient balance'));
//                        }
//                    }
//                }else{
//                    returnJson('300',lang('transfer_out_uid not asset'));
//                }
//            }
//
//            $site_id = $site_id;
//            $asset = $args['asset'];
//            $amount = trim($args['amount']);
//            $amount_neg = "-".$amount;
//            $remark = isset($args['remark']) ? $args['remark'] : '';
//            $operation_admin_id = $this->user_id;
//            $time = date('Y-m-d H:i:s',time());
//
//            $this->db->trans_begin();
//            //插入赠币记录表
//            if(!empty($args['expire_time'])){
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
//            }else{
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
//            }
//
//            //修改记录表状态
//            $this->Platfrom_gift_coin_record_model->update_data($asset,$amount,$args['uid'],$remark,$args['lock']);
//
//            if(!empty($bussness_id)){
//                //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
//                $bussness = 'admin_gift_activity_money';
//                //'{"info":" "remark":"活动赠币"}'
//
//                $remark_add = array('info'=>$args['uid'],'remark'=>$remark);
//                $remark_add = json_encode($remark_add);
//                $remark1 = array('info'=>intval($args['uid']),'remark'=>$remark);
//                $remark1 = json_encode($remark1);
//
//                $data = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],1,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
//                $data1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark1,$remark);
//                $trans_status = $this->db->trans_status();
//                if($data === false || $data1 === false)
//                {
//                    $trans_status = false;
//                }
//                if ($trans_status === false) {
//                    $this->db->trans_rollback();
//                    return $args;
//                } else {
//                    $this->db->trans_commit();
//                    return true;
//                }
//            }
//        }
//
//    }

//    public function batch_gift_coin1($args,$sum,$site_id)
//    {
//
//        if($args['lock'] == 1){
//
//            if(empty($args['expire_time'])) returnJson('300',lang('time is null'));
//
//            //先看用户是否存在
//            $user_id = $args['uid'];
//            $user_out = $this->Zjys_user_model->get_info($user_id);
//            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
//
//            //根据站点查找该站点总账户user_id
//            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
//            if($total_user_id['user_id'] == NULL){
//                returnJson('300',lang('site_id not totalaccount'));
//            }else  if($total_user_id['user_id'] == $user_id){
//                returnJson('300',lang('not give it to yourself'));
//            }
//
//            if(!empty($total_user_id['user_id'])){
//                //获取总账户余额，判断余额是否足够
//                $DB1 = $this->load->database('trade_history',true);
//                $i = $total_user_id['user_id']%100;
//                $asset = $args['asset'];
//                $user_id = $total_user_id['user_id'];
//                $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $user_id and asset = '$asset' ";
//                $object = object_to_array($DB1->query($sql)->result());
//                if (!empty($object)){
//                    $arr = $object[count($object)-1];
//                    if(!empty($arr['balance'])){
//                        if($arr['balance']<$sum){
//                            returnJson('300',lang('Insufficient balance'));
//                        }
//                    }
//                }else{
//                    returnJson('300',lang('transfer_out_uid not asset'));
//                }
//            }
//
//            $site_id = $site_id;
//            $asset = $args['asset'];
//            $amount = trim($args['amount']);
//            $amount_neg = "-".$amount;
//            $remark = isset($args['remark']) ? $args['remark'] : '';
//           // $operation_admin_id = $this->user_id;
//            $time = date('Y-m-d H:i:s',time());
//
//            $this->db->trans_begin();
//            //插入赠币记录表
//            if(!empty($args['expire_time'])){
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add(1,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
//            }else{
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add1(1,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
//            }
//            //修改记录表状态
//            $this->Platfrom_gift_coin_record_model->update_data($asset,$amount,$args['uid'],$remark,$args['lock']);
//
//
//            $bussness = 'admin_giftmoney';
//            $remark = array('info'=>$remark);
//            $res = update_user_balance_bycurl($args['uid'],$asset,$amount,$bussness_id,$remark,$bussness);
//            $res1 = update_user_balance_bycurl($total_user_id['user_id'],$asset,$amount_neg,$bussness_id,$remark,$bussness);
//
//
//            //锁仓
//            $id = isset($args['id']) ? $args['id'] : false;
//            if(!is_numeric($args['uid'])) return false;
//            $created_at = date("Y-m-d H:i:s",time());
//            $updated_at = date("Y-m-d H:i:s",time());
//
//            if($id){
//                $result = $this->Zjys_user_model->lockposition_update($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$updated_at,$id);
//            }else {
//                $status = 0;
//                if ($args['amount'] <= 0) returnJson('402', '锁仓数量不能大于可用数量');
//                $result = $this->Zjys_user_model->lockposition_add($args['asset'], $args['uid'], trim($args['amount']), $args['expire_time'], $args['remark'], $status, $created_at, $updated_at);
//                $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'], $args['uid']);
//                if (is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
//                //2、新增冻结记录
//                $balance = bcadd($last_balance['balance'], $args['amount']);
//                $detail1 = json_encode(array('id' => $result));
//                $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
//                $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at, $updated_at, $args['uid'], $args['asset'], $args['amount'], $business, $balance, $detail1);
//                //3、后台新增操作记录
//                $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
//                $description = null;
//                admin_operation_logs($this->user_id, $args['uid'], $business, $description, $created_at, $result);
//                //4、减去用户可用资金
//                $text = '锁仓';
//                $ss = array('info' => $text);
//                $res_lock = update_user_balance_bycurl($args['uid'], $args['asset'], -$args['amount'], $result, $ss, $busi = 'lock_position');
//
//            }
//                $trans_status = $this->db->trans_status();
//                if ($res['result']['status'] != 'success' || $res1['result']['status'] != 'success' ) {
//                    $trans_status = false;
//                }
//                if ($trans_status === false) {
//                    $this->db->trans_rollback();
//                    return $args;
//                } else {
//                    $this->db->trans_commit();
//                    return true;
//                }
//
//        }else if($args['lock'] == 0){
//            //先看用户是否存在
//            $user_id = $args['uid'];
//            $user_out = $this->Zjys_user_model->get_info($user_id);
//            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
//
//            //根据站点查找该站点总账户user_id
//            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
//            if($total_user_id['user_id'] == NULL){
//                returnJson('300',lang('site_id not totalaccount'));
//            }else  if($total_user_id['user_id'] == $user_id){
//                returnJson('300',lang('not give it to yourself'));
//            }
//
//            if(!empty($total_user_id['user_id'])){
//                //获取总账户余额，判断余额是否足够
//                $DB1 = $this->load->database('trade_history',true);
//                $i = $total_user_id['user_id']%100;
//                $asset = $args['asset'];
//                $user_id = $total_user_id['user_id'];
//                $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $user_id and asset = '$asset' ";
//                $object = object_to_array($DB1->query($sql)->result());
//                if (!empty($object)){
//                    $arr = $object[count($object)-1];
//                    if(!empty($arr['balance'])){
//                        if($arr['balance']<$sum){
//                            returnJson('300',lang('Insufficient balance'));
//                        }
//                    }
//                }else{
//                    returnJson('300',lang('transfer_out_uid not asset'));
//                }
//            }
//
//            $site_id = $site_id;
//            $asset = $args['asset'];
//            $amount = trim($args['amount']);
//            $amount_neg = "-".$amount;
//            $remark = isset($args['remark']) ? $args['remark'] : '';
//            //$operation_admin_id = $this->user_id;
//            $time = date('Y-m-d H:i:s',time());
//
//            $this->db->trans_begin();
//            //插入赠币记录表
//            if(!empty($args['expire_time'])){
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add(1,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
//            }else{
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add1(1,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
//            }
//
//            //修改记录表状态
//            $this->Platfrom_gift_coin_record_model->update_data($asset,$amount,$args['uid'],$remark,$args['lock']);
//
//            $bussness = 'admin_giftmoney';
//            $remark = array('info'=>$remark);
//            $res = update_user_balance_bycurl($args['uid'],$asset,$amount,$bussness_id,$remark,$bussness);
//            $res1 = update_user_balance_bycurl($total_user_id['user_id'],$asset,$amount_neg,$bussness_id,$remark,$bussness);
//
//            $trans_status = $this->db->trans_status();
//            if($res['result']['status'] != 'success' || $res1['result']['status'] != 'success')
//            {
//                $trans_status = false;
//            }
//            if ($trans_status === false) {
//                $this->db->trans_rollback();
//                return $args;
//            } else {
//                $this->db->trans_commit();
//                return true;
//            }
//        }else{
//            //先看用户是否存在
//            $user_id = $args['uid'];
//            $user_out = $this->Zjys_user_model->get_info($user_id);
//            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
//
//            //根据站点查找该站点总账户user_id
//            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
//            if($total_user_id['user_id'] == NULL){
//                returnJson('300',lang('site_id not totalaccount'));
//            }else  if($total_user_id['user_id'] == $user_id){
//                returnJson('300',lang('not give it to yourself'));
//            }
//
//            if(!empty($total_user_id['user_id'])){
//                //获取总账户余额，判断余额是否足够
//                $DB1 = $this->load->database('trade_history',true);
//                $i = $total_user_id['user_id']%100;
//                $asset = $args['asset'];
//                $user_id = $total_user_id['user_id'];
//                $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $user_id and asset = '$asset' ";
//                $object = object_to_array($DB1->query($sql)->result());
//                if (!empty($object)){
//                    $arr = $object[count($object)-1];
//                    if(!empty($arr['balance'])){
//                        if($arr['balance']<$sum){
//                            returnJson('300',lang('Insufficient balance'));
//                        }
//                    }
//                }else{
//                    returnJson('300',lang('transfer_out_uid not asset'));
//                }
//            }
//
//            $site_id = $site_id;
//            $asset = $args['asset'];
//            $amount = trim($args['amount']);
//            $amount_neg = "-".$amount;
//            $remark = isset($args['remark']) ? $args['remark'] : '';
//            //$operation_admin_id = $this->user_id;
//            $time = date('Y-m-d H:i:s',time());
//
//            $this->db->trans_begin();
//            //插入赠币记录表
//            if(!empty($args['expire_time'])){
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add(1,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
//            }else{
//                $bussness_id = $this->Platfrom_gift_coin_record_model->add1(1,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
//            }
//            //修改记录表状态
//            $this->Platfrom_gift_coin_record_model->update_data($asset,$amount,$args['uid'],$remark,$args['lock']);
//
//
//            if(!empty($bussness_id)){
//                //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
//                $bussness = 'admin_gift_activity_money';
//                //'{"info":" "remark":"活动赠币"}'
//
//                $remark_add = array('info'=>$args['uid'],'remark'=>$remark);
//                $remark_add = json_encode($remark_add);
//                $remark1 = array('info'=>intval($args['uid']),'remark'=>$remark);
//                $remark1 = json_encode($remark1);
//
//                $data = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],1,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
//                $data1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark1,$remark);
//                $trans_status = $this->db->trans_status();
//                if($data === false || $data1 === false)
//                {
//                    $trans_status = false;
//                }
//                if ($trans_status === false) {
//                    $this->db->trans_rollback();
//                    return $args;
//                } else {
//                    $this->db->trans_commit();
//                    return true;
//                }
//            }
//        }
//
//    }
    /**
     * Notes: 赠币实例
     * User: 张哲
     * Date: 2018/12/7
     * Time: 15:43
     * @return mixed
     */
    public function gift_sample_csv(){
        $object = $this->db->select("platfrom_gift_coin_record_sample.*")
            ->from('platfrom_gift_coin_record_sample');
        $list = $object->order_by('id','desc')->get()->result_array();
        return $list;
    }

    /**
     * Notes: 赠币数据存储
     * User: 张哲
     * Date: 2019/3/27
     * Time: 17:10
     */
    public function save_data($args,$site_id){
        foreach ($args as $value) {
            $data = $this->Platfrom_gift_coin_record_model->save_data($value['uid'],$value['asset'],$value['amount'],$value['remark'],$value['lock'],$value['expire_time'],$site_id);
        }
        return true;
    }

    public function take_data(){
        $object = $this->db->select("platfrom_gift_coin.*")
            ->from('platfrom_gift_coin')
            ->where('platfrom_gift_coin.gift_result = ',0);
        $list = $object->order_by('id','desc')->get()->result_array();
        return $list;
    }


    /**
     * 1.借款-增加插入数据接口，增加日志；审核原接口加改变状态，获取相关字段
     * 2.转账-增加插入数据接口，增加日志；审核原接口加改变状态，获取相关字段
     * 3.赠币-增加插入数据接口，增加日志；审核原接口加改变状态;批量审核做处理
     * 4.调整资金-增加插入数据接口，增加日志；审核原接口加改变状态;批量审核做处理
     */

    /**
     * Notes: 总账户借款功能-老
     * User: 张哲
     * Date: 2018/11/22
     * Time: 10:18
     */
    public function loan_total1($args){
        //先看用户是否存在
        $user_id = $args['user_id'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out)){
            returnJson('300',lang('user_id not exist'));
        }

        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());
        $status = 0;

        $this->db->trans_begin();
        $payer_id = '';
        //插入借款记录表
        //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
        $bussness_id = $this->Platfrom_loan_record_model->add($operation_admin_id,$time,$asset,$amount,$user_id,$remark,$site_id,$status,$payer_id);


        $bussness = 'admin_loanmoney';
//        $remark = array('info'=>$remark);
//        $res = update_user_balance_bycurl($user_id,$asset,$amount,$bussness_id,$remark,$bussness);

        $remark_add = array('info'=>$user_id,'remark'=>$remark);
        $remark_add = json_encode($remark_add);
        $res = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id,0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);

        $trans_status = $this->db->trans_status();
        if($res['code'] != 0 )
        {
            $trans_status = false;
            returnJson('402','系统错误');
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return $args;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }


    /**
     * Notes: 账户借款功能-审核
     * User: 张哲
     * Date: 2019-06-10
     * Time: 18:04
     */
    public function loan_total($args){

        //先看用户是否存在
        $user_id = $args['user_id'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out)){
            returnJson('300',lang('user_id not exist'));
        }

        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());
        $status = 0;

        $payer_id = '';
        //插入借款记录表
        //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
        $bussness_id = $this->Platfrom_loan_record_model->add($operation_admin_id,$time,$asset,$amount,$user_id,$remark,$site_id,$status,$payer_id);
        if(!empty($bussness_id)) {

            $business = '16'; //o
            $description = '借款提交审核';
            admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);

            return true;
        }else{
            return false;
        }

    }

    /**
     * Notes: 总账户借款功能-new
     * User: 张哲
     * Date: 2019-06-18
     * Time: 11:41
     */
    public function loan_verity($args){

        //先看用户是否存在
        $id = $args['id'];
        $type = $args['type'];

        //获取改借款记录数据
        $object = $this->db->select("platfrom_loan_record.*")
            ->from('platfrom_loan_record');
        $object = $this->db->where('platfrom_loan_record.id =', $id);
        $loan = $object->get()->result_array();
        $user_id = $loan[0]['user_id'];
        $site_id = $loan[0]['site_id'];
        $asset = $loan[0]['asset'];
        $amount = trim($loan[0]['amount']);
        $remark = isset($loan[0]['remark']) ? $loan[0]['remark'] : '';
        $status = $loan[0]['type'];
        if($status == 0){
            if($type == 0){

                $data = array();
                //修改状态
                $data['type'] = 2;
                $updated_at = date("Y-m-d H:i:s",time());
                $data['updated_at'] = $updated_at;
                $this->db->where('id', $id);
                $this->db->update('platfrom_loan_record', $data);

                $bussness_id = $id;
                $time = date('Y-m-d H:i:s',time());
                $business = '17'; //o
                $description = '拒绝借款';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);


                returnJson('200','审核拒绝');
            }else{



                $this->db->trans_begin();
                //插入借款记录表
                $bussness_id = $id;

                $bussness = 'admin_loanmoney';

                $remark_add = array('info'=>$user_id,'remark'=>$remark);
                $remark_add = json_encode($remark_add);
                $res = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id,0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);

                $trans_status = $this->db->trans_status();
                if($res['code'] != 0 )
                {
                    $trans_status = false;
                    returnJson('402','系统错误');
                }
                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    return $args;
                } else {
                    $data = array();
                    //修改状态
                    $data['type'] = 1;
                    $updated_at = date("Y-m-d H:i:s",time());
                    $data['updated_at'] = $updated_at;
                    $this->db->where('id', $id);
                    $this->db->update('platfrom_loan_record', $data);


                    $time = date('Y-m-d H:i:s',time());
                    $business = '17'; //o
                    $description = '同意借款';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);

                    $this->db->trans_commit();
                    return true;
                }
            }
        }else{
            $remark =  $user_id."已经审核";
            returnJson("402",$remark);
        }


    }

    /**
     * Notes: 转账操作-老
     * User: 张哲
     * Date: 2018/11/21
     * Time: 10:52
     * @param $args
     * @return bool
     */
    public function transfer_user_money1($args)
    {
        //先看转出用户是否存在
        $user_id = $args['transfer_out_uid'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out))  returnJson('300',lang('transfer_out_uid not exist'));

        //先看转入用户是否存在
        $user_id1 = $args['transfer_in_uid'];
        $user_in = $this->Zjys_user_model->get_info($user_id1);
        if(empty($user_in))   returnJson('300',lang('transfer_in_uid not exist'));
        $asset = $args['asset'];

        if($user_id == $user_id1) returnJson('300',lang('not transfer account'));


        //获取转出账户余额，判断余额是否足够
//            $DB1 = $this->load->database('trade_history',true);
//            $i = $user_id%100;
//            $sql = "select user_id,asset,balance from balance_history_".$i." where  user_id = $user_id and asset = '$asset' order by id DESC LIMIT 0,1";
//            $object = object_to_array($DB1->query($sql)->result());

        $response = check_balance($user_id,$asset);
        if (!empty($response)){
            if($response['result'][$asset]['available']<$args['amount']){
                returnJson('300',lang('Insufficient balance'));
            }
        }else{
            returnJson('300',lang('transfer_out_uid not asset'));
        }

        $site_id = $user_out['site_id'];
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $amount_neg = "-".$amount;
        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());

        $this->db->trans_begin();
        //插入转账记录表
        $bussness_id = $this->Platfrom_transfer_record_model->add($operation_admin_id,$time,$asset,$amount,$user_id,$remark,$site_id, $user_id1);
        $bussness = 'admin_tranfsermoney';
        // $remark = array('info'=>$remark);
        // $res = update_user_balance_bycurl($user_id,$asset,$amount_neg,$bussness_id,$remark,$bussness);


        $remark_add = array('info'=>$user_id,'remark'=>$remark);
        $remark_add = json_encode($remark_add);
        $res = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id,0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);

        $data = $res['details'];
        $trans_status = $this->db->trans_status();
        if($res['code'] != 0)
        {
            $trans_status = false;
        }else{
            //$res1 = update_user_balance_bycurl($user_id1,$asset,$amount,$bussness_id,$remark,$bussness);
            $remark_add = array('info'=>$user_id,'remark'=>$remark);
            $remark_add = json_encode($remark_add);
            $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id1,0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);


            if($res1['code'] != 0){
                $trans_status = false;
                $data = $res1['details'];
            }
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return $data;
        } else {
            $this->db->trans_commit();
            return true;
        }




//        if ($data['code'] == 0) {
//            returnJson('200', lang('operation_successful'), $data);
//        } else {
//            returnJson('402', $data['details']);
//        }
    }

    /**
     * Notes: 转账功能-新
     * User: 张哲
     * Date: 2019-06-11
     * Time: 09:55
     */
    public function transfer_user_money($args){
        //先看转出用户是否存在
        $user_id = $args['transfer_out_uid'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out))  returnJson('300',lang('transfer_out_uid not exist'));

        //先看转入用户是否存在
        $user_id1 = $args['transfer_in_uid'];
        $user_in = $this->Zjys_user_model->get_info($user_id1);
        if(empty($user_in))   returnJson('300',lang('transfer_in_uid not exist'));
        $asset = $args['asset'];

        if($user_id == $user_id1) returnJson('300',lang('not transfer account'));

        $response = check_balance($user_id,$asset);
        if (!empty($response)){
            if($response['result'][$asset]['available']<$args['amount']){
                returnJson('300',lang('Insufficient balance'));
            }
        }else{
            returnJson('300',lang('transfer_out_uid not asset'));
        }

        $site_id = $user_out['site_id'];
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());


        //插入转账记录表
        $bussness_id = $this->Platfrom_transfer_record_model->add($operation_admin_id,$time,$asset,$amount,$user_id,$remark,$site_id, $user_id1);

        if(!empty($bussness_id)) {

            $time = date('Y-m-d H:i:s',time());
            $business = '18'; //o
            $description = '转账提交';
            admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);

            return true;
        }else{
            return false;
        }



    }

    /**
     * Notes: 转账操作审核
     * User: 张哲
     * Date: 2018/11/21
     * Time: 10:52
     * @param $args
     * @return bool
     */
    public function transfer_user_money_verity($args)
    {

        //先看用户是否存在
        $id = $args['id'];
        $type = $args['type'];
        //获取该转账记录数据
        $object = $this->db->select("platfrom_transfer_record.*")
            ->from('platfrom_transfer_record');
        $object = $this->db->where('platfrom_transfer_record.id =', $id);
        $loan = $object->get()->result_array();

        $asset = $loan[0]['asset'];
        $user_id = $loan[0]['transfer_out_uid'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        $site_id = $user_out['site_id'];
        $user_id1 = $loan[0]['transfer_in_uid'];
        $transfer_status = $loan[0]['transfer_status'];

        if($transfer_status == 0){
            if($type == 0){

                $data = array();
                //修改状态
                $data['type'] = 2;
                $updated_at = date("Y-m-d H:i:s",time());
                $data['updated_at'] = $updated_at;
                $this->db->where('id', $id);
                $this->db->update('platfrom_transfer_record', $data);

                $bussness_id = $id;
                $time = date('Y-m-d H:i:s',time());
                $business = '19'; //o
                $description = '拒绝转账';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);


                returnJson('200','审核拒绝');
            }else {
                $response = check_balance($user_id, $asset);
                if (!empty($response)) {
                    if ($response['result'][$asset]['available'] < $loan[0]['amount']) {
                        returnJson('300', lang('Insufficient balance'));
                    }
                } else {
                    returnJson('300', lang('transfer_out_uid not asset'));
                }

                $amount = trim($loan[0]['amount']);
                $amount_neg = "-" . $amount;
                $remark = isset($loan[0]['remark']) ? $loan[0]['remark'] : '';

                $this->db->trans_begin();
                //插入转账记录表
                $bussness_id = $id;
                $bussness = 'admin_tranfsermoney';

                $remark_add = array('info' => $user_id, 'remark' => $remark);
                $remark_add = json_encode($remark_add);
                $res = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id, 0, $asset, $bussness, $bussness_id, $amount_neg, $site_id, $remark_add, $remark);

                $data = $res['details'];
                $trans_status = $this->db->trans_status();
                if ($res['code'] != 0) {
                    $transfer_status = array();
                    $transfer_status['transfer_status'] = 1;
                    $updated_at = date("Y-m-d H:i:s",time());
                    $transfer_status['transfer_time'] = $updated_at;
                    $this->db->where('id', $id);
                    $this->db->update('platfrom_transfer_record', $transfer_status);

                    $trans_status = false;

                } else {
                    $transfer_status = array();
                    $transfer_status['transfer_status'] = 2;
                    $updated_at = date("Y-m-d H:i:s",time());
                    $transfer_status['transfer_time'] = $updated_at;
                    $this->db->where('id', $id);
                    $this->db->update('platfrom_transfer_record', $transfer_status);

                    $remark_add = array('info' => $user_id, 'remark' => $remark);
                    $remark_add = json_encode($remark_add);
                    $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id1, 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);

                    if ($res1['code'] != 0) {
                        $transfer_status = array();
                        $transfer_status['transfer_status'] = 3;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $transfer_status['transfer_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_transfer_record', $transfer_status);

                        $trans_status = false;
                        $data = $res1['details'];
                    }else{
                        $transfer_status = array();
                        $transfer_status['transfer_status'] = 4;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $transfer_status['transfer_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_transfer_record', $transfer_status);
                    }
                }
                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    return $data;
                } else {
                    $this->db->trans_commit();
                    $data = array();
                    //修改状态
                    $data['type'] = 1;
                    $updated_at = date("Y-m-d H:i:s", time());
                    $data['updated_at'] = $updated_at;
                    $this->db->where('id', $id);
                    $this->db->update('platfrom_transfer_record', $data);

                    $time = date('Y-m-d H:i:s',time());
                    $business = '19'; //o
                    $description = '同意转账';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);

                    $this->db->trans_commit();
                    return true;
                }
        }

        }else{
            $remark =  $user_id."已经审核";
            returnJson("402",$remark);
        }
    }

    /**
     * Notes: 单个用户新增赠币-老
     * User: 张哲
     * Date: 2018/11/23
     * Time: 16:21
     * @param $args
     * @return bool
     */
    public function gift_coin1($args)
    {

        if($args['lock'] == 1){
            //先看用户是否存在
            $user_id = $args['uid'];
            $user_out = $this->Zjys_user_model->get_info($user_id);
            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($args['site_id']);
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }
            $site_id = $args['site_id'];
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $amount_neg = "-".$amount;
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());

            $this->db->trans_begin();
            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }

            if(!empty($bussness_id)) {
                $bussness = 'admin_giftmoney';
                // $remark = array('info' => $remark);
                //$res = update_user_balance_bycurl($args['uid'], $asset, $amount, $bussness_id, $remark, $bussness);
                // $res1 = update_user_balance_bycurl($total_user_id['user_id'], $asset, $amount_neg, $bussness_id, $remark, $bussness);

                $remark_add = array('info'=>$user_id,'remark'=>$remark);
                $remark_add = json_encode($remark_add);
                $res = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);
            }


            //锁仓
            $id = isset($args['id']) ? $args['id'] : false;
            if(!is_numeric($args['uid'])) return false;
            $created_at = date("Y-m-d H:i:s",time());
            $updated_at = date("Y-m-d H:i:s",time());

            if($id){
                $result = $this->Zjys_user_model->lockposition_update($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$updated_at,$id);
            }else{
                $status = 0;
                $check_status =1;
                if($args['amount']<=0) returnJson('402','锁仓数量不能大于可用数量');
                $result = $this->Zjys_user_model->lockposition_add($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$status,$created_at,$updated_at,$check_status);
                $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'],$args['uid']);
                if(is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
                //2、新增冻结记录
                $balance = bcadd($last_balance['balance'],$args['amount']);
                $detail1 = json_encode(array('id'=>$result));
                $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
                $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$args['uid'],$args['asset'],$args['amount'],$business,$balance,$detail1);
                //3、后台新增操作记录
                $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
                $description = null;
                admin_operation_logs($this->user_id,$args['uid'],$business,$description,$created_at,$result);
                //4、减去用户可用资金
                $text = '锁仓';
                $ss = array('info'=>$text);
                // $res_lock = update_user_balance_bycurl($args['uid'],$args['asset'],-$args['amount'],$result,$ss,$busi='lock_position');

                $remark_add = array('info'=>$user_id,'remark'=>$remark);
                $remark_add = json_encode($remark_add);
                $business = "lock_position";
                $res_lock = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$args['asset'],$business,$result,-$args['amount'],$site_id,$remark_add,$remark);
            }

            $trans_status = $this->db->trans_status();
            if($res['code'] != 0 || $res1['code'] != 0 || $res_lock['code'] != 0)
            {
                $trans_status = false;
            }
            if ($trans_status === false) {
                $this->db->trans_rollback();
                return $args;
            } else {
                $this->db->trans_commit();
                return true;
            }
        }else if($args['lock'] == 0){
            //先看用户是否存在
            $user_id = $args['uid'];
//            $user_out = $this->Zjys_user_model->get_info($user_id);
//            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($args['site_id']);
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }
            $site_id = $args['site_id'];
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $amount_neg = "-".$amount;
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());

            $this->db->trans_begin();
            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }


            if(!empty($bussness_id)){
                $bussness = 'admin_giftmoney';
                //$remark = array('info'=>$remark);
                // $res = update_user_balance_bycurl($args['uid'],$asset,$amount,$bussness_id,$remark,$bussness);
                // $res1 = update_user_balance_bycurl($total_user_id['user_id'],$asset,$amount_neg,$bussness_id,$remark,$bussness);

                $remark_add = array('info'=>$user_id,'remark'=>$remark);
                $remark_add = json_encode($remark_add);
                $res = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);

                $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);

                $trans_status = $this->db->trans_status();

                if($res['code'] != 0 || $res1['code'] != 0)
                {
                    $trans_status = false;
                }
                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    return $args;
                } else {
                    $this->db->trans_commit();
                    return true;
                }
            }
        }else{
            //先看用户是否存在
            $user_id = $args['uid'];
            $user_out = $this->Zjys_user_model->get_info($user_id);
            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($args['site_id']);
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                //获取总账户余额，判断余额是否足够
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }
            $site_id = $args['site_id'];
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $amount_neg = "-".$amount;
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());
            $this->db->trans_begin();
            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }

            if(!empty($bussness_id)){
                //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
                $bussness = 'admin_gift_activity_money';
                //'{"info":" "remark":"活动赠币"}'

                $remark_add = array('info'=>$args['uid'],'remark'=>$remark);
                $remark_add = json_encode($remark_add);
                $remark1 = array('info'=>intval($args['uid']),'remark'=>$remark);
                $remark1 = json_encode($remark1);

                $data = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                $data1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark1,$remark);
                $trans_status = $this->db->trans_status();
                if($data['code'] != 0 || $data1['code'] != 0)
                {
                    $trans_status = false;
                }
                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    return $args;
                } else {
                    $this->db->trans_commit();
                    return true;
                }
            }
        }

    }

    /**
     * Notes: 单个用户新增赠币-new
     * User: 张哲
     * Date: 2018/11/23
     * Time: 16:21
     * @param $args
     * @return bool
     */
    public function gift_coin($args)
    {

        if($args['lock'] == 1){
            //先看用户是否存在
            $user_id = $args['uid'];
            $user_out = $this->Zjys_user_model->get_info($user_id);
            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($args['site_id']);
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }
            $site_id = $args['site_id'];
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());

            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }

            if(!empty($bussness_id)) {

                $time = date('Y-m-d H:i:s',time());
                $business = '20'; //o
                $description = '单个赠币';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);
                return true;
            }else{
                return false;
            }

        }else if($args['lock'] == 0){
            //先看用户是否存在
            $user_id = $args['uid'];
            $user_out = $this->Zjys_user_model->get_info($user_id);
            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($args['site_id']);
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }
            $site_id = $args['site_id'];
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $amount_neg = "-".$amount;
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());


            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }


            if(!empty($bussness_id)) {
                $time = date('Y-m-d H:i:s',time());
                $business = '20'; //o
                $description = '单个赠币';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);
                return true;
            }else{
                return false;
            }
        }else{
            //先看用户是否存在
            $user_id = $args['uid'];
            $user_out = $this->Zjys_user_model->get_info($user_id);
            if(empty($user_out))  returnJson('300',lang('user_id not exist'));
            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($args['site_id']);
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                //获取总账户余额，判断余额是否足够
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }
            $site_id = $args['site_id'];
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $amount_neg = "-".$amount;
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());

            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }

            if(!empty($bussness_id)) {
                $time = date('Y-m-d H:i:s',time());
                $business = '20'; //o
                $description = '单个赠币';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);
                return true;
            }else{
                return false;
            }
        }

    }

    /**
     * Notes: 单个用户赠币-审核
     * User: 张哲
     * Date: 2019-06-18
     * Time: 19:13
     */
    public function gift_coin_verity($args)
    {
        //先看用户是否存在
        $id = $args['id'];
        $type = $args['type'];
        $user_id = $args['uid'];
        $site_id = $args['site_id'];
        $object = $this->db->select("platfrom_gift_coin_record.*")
            ->from('platfrom_gift_coin_record');
        $object =$this->db->where('platfrom_gift_coin_record.id = ',$id);
        $list = $object->get()->result_array();
        $gift_status = $list[0]['gift_status'];

        if($gift_status == 0){
            if($type == 0){
                $data = array();
                //修改状态
                $data['type'] = 2;
                $updated_at = date("Y-m-d H:i:s",time());
                $data['updated_at'] = $updated_at;
                $this->db->where('id', $id);
                $this->db->update('platfrom_gift_coin_record', $data);

                $bussness_id = $id;
                $time = date('Y-m-d H:i:s',time());
                $business = '21'; //o
                $description = '拒绝单个赠币';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);


                returnJson('200','审核拒绝');
            }else {
                if ($args['lock'] == 1) {

                    if (empty($args['expire_time'])) returnJson('300', lang('time is null'));

                    //先看用户是否存在
                    $user_id = $args['uid'];
                    $user_out = $this->Zjys_user_model->get_info($user_id);
                    if (empty($user_out)) returnJson('300', lang('user_id not exist'));

                    //根据站点查找该站点总账户user_id
                    $total_user_id = $this->Platform_account_model->get_user_id($site_id);

                    if ($total_user_id['user_id'] == NULL) {
                        returnJson('300', lang('site_id not totalaccount'));
                    } else if ($total_user_id['user_id'] == $user_id) {
                        returnJson('300', lang('not give it to yourself'));
                    }

                    if (!empty($total_user_id['user_id'])) {
                        //获取总账户余额，判断余额是否足够
                        $asset = $args['asset'];
                        $response = check_balance($total_user_id['user_id'], $asset);
                        if (!empty($response)) {
                            if ($response['result'][$asset]['available'] < $args['amount']) {
                                returnJson('300', lang('Insufficient balance'));
                            }
                        } else {
                            returnJson('300', lang('transfer_out_uid not asset'));
                        }
                    }

                    $site_id = $site_id;
                    $asset = $args['asset'];
                    $amount = trim($args['amount']);
                    $amount_neg = "-" . $amount;
                    $remark = isset($args['remark']) ? $args['remark'] : '';
                    $operation_admin_id = $this->user_id;
                    $time = date('Y-m-d H:i:s', time());

                    $this->db->trans_begin();
                    //插入赠币记录表
                    $bussness_id = $id;
                    $bussness = 'admin_giftmoney';


                    $remark_add = array('info' => $user_id, 'remark' => $remark);
                    $remark_add = json_encode($remark_add);
                    //$total_account_money = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);
                    $total_account_money = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'], 0, $asset, $bussness, $bussness_id, $amount_neg, $site_id, $remark_add, $remark);


                    $trans_status = $this->db->trans_status();
                    if ( $total_account_money['code'] != 0) {
                        $trans_status = false;

                        $gift_status = array();
                        $gift_status['gift_status'] = 1;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                    }else{
                        $gift_status = array();
                        $gift_status['gift_status'] = 2;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);

                        $created_at = date("Y-m-d H:i:s", time());
                        $updated_at = date("Y-m-d H:i:s", time());


                        $status = 0;
                        $check_status = 1;
                        if ($args['amount'] <= 0) returnJson('402', '锁仓数量不能大于可用数量');
                        $result = $this->Zjys_user_model->lockposition_add($args['asset'], $args['uid'], trim($args['amount']), $args['expire_time'], $args['remark'], $status, $created_at, $updated_at,$check_status);
                        //查看冻结表余额
                        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'], $args['uid']);
                        if (is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
                        //2、新增冻结记录
                        $balance = bcadd($last_balance['balance'], $args['amount']);
                        $detail1 = json_encode(array('id' => $result));
                        $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
                        $time_lock = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at, $updated_at, $args['uid'], $args['asset'], $args['amount'], $business, $balance, $detail1);
                        //3、后台新增操作记录
                        $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
                        $description = null;
                        admin_operation_logs($this->user_id, $args['uid'], $business, $description, $created_at, $result);
                        //4、减去用户可用资金
//                    $text = '锁仓';
//                    $ss = array('info' => $text);
//                    //$res_lock = update_user_balance_bycurl($args['uid'],$args['asset'],-$args['amount'],$result,$ss,$busi='lock_position');
//
//                    $remark_add = array('info' => $user_id, 'remark' => $remark);
//                    $remark_add = json_encode($remark_add);
//                    $business = "lock_position";
                        //  $res_lock = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $args['asset'], $business, $result, -$args['amount'], $site_id, $remark_add, $remark);

                        if(empty($time_lock)){
                            $gift_status = array();
                            $gift_status['gift_status'] = 3;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                            $total_account_add = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'], 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);
                            if($total_account_money['$total_account_add'] != 0){
                                $gift_status = array();
                                $gift_status['gift_status'] = 5;
                                $updated_at = date("Y-m-d H:i:s",time());
                                $gift_status['gift_time'] = $updated_at;
                                $this->db->where('id', $id);
                                $this->db->update('platfrom_gift_coin_record', $gift_status);
                            }else{
                                $gift_status = array();
                                $gift_status['gift_status'] = 6;
                                $updated_at = date("Y-m-d H:i:s",time());
                                $gift_status['gift_time'] = $updated_at;
                                $this->db->where('id', $id);
                                $this->db->update('platfrom_gift_coin_record', $gift_status);
                            }
                        }else{
                            $gift_status = array();
                            $gift_status['gift_status'] = 4;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);

                        }

                    }



                    if ($trans_status === false) {
                        $this->db->trans_rollback();
                        return $args;
                    } else {
                        $this->db->trans_commit();
                        $data = array();
                        //修改状态
                        $data['type'] = 1;
                        $updated_at = date("Y-m-d H:i:s", time());
                        $data['updated_at'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $data);

                        $bussness_id = $id;
                        $time = date('Y-m-d H:i:s',time());
                        $business = '23'; //o
                        $description = '同意批量赠币';
                        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);

                        $this->db->trans_commit();
                        return true;
                    }
                } else if ($args['lock'] == 0) {
                    //先看用户是否存在
                    $user_id = $args['uid'];
                    $user_out = $this->Zjys_user_model->get_info($user_id);
                    if (empty($user_out)) returnJson('300', lang('user_id not exist'));

                    //根据站点查找该站点总账户user_id
                    $total_user_id = $this->Platform_account_model->get_user_id($site_id);
                    if ($total_user_id['user_id'] == NULL) {
                        returnJson('300', lang('site_id not totalaccount'));
                    } else if ($total_user_id['user_id'] == $user_id) {
                        returnJson('300', lang('not give it to yourself'));
                    }

                    $site_id = $site_id;
                    $asset = $args['asset'];
                    $amount = trim($args['amount']);
                    $amount_neg = "-" . $amount;
                    $remark = isset($args['remark']) ? $args['remark'] : '';
                    $operation_admin_id = $this->user_id;
                    $time = date('Y-m-d H:i:s', time());

                    $this->db->trans_begin();
                    //插入赠币记录表
                    $bussness_id = $id;
                    $bussness = 'admin_giftmoney';

                    $remark_add = array('info' => $user_id, 'remark' => '');
                    $remark_add = json_encode($remark_add);

                    //先扣除账户总额成功后，用户余额加钱；如果加钱失败，则总账户将扣款加回；所有操作加记录状态
                    $total_account_money = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'], 0, $asset, $bussness, $bussness_id, $amount_neg, $site_id, $remark_add, $remark);



                    if ($total_account_money['code'] != 0) {
                        //扣款失败
                        $gift_status = array();
                        $gift_status['gift_status'] = 1;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                    }else{
                        //扣款成功后，锁定用户资金
                        $gift_status = array();
                        $gift_status['gift_status'] = 2;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                        //type=1是加钱
                        $user_account_add= $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);
                    }

                    if ($user_account_add['code'] != 0) {
                        //锁仓失败
                        $gift_status = array();
                        $gift_status['gift_status'] = 3;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                        //锁仓失败后，给总账户加回钱
                        $user_account_deduction = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                        if ($user_account_deduction['code'] != 0) {
                            //总账户加钱失败
                            $gift_status = array();
                            $gift_status['gift_status'] = 5;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                        }else{
                            //总账户加钱成功
                            $gift_status = array();
                            $gift_status['gift_status'] = 6;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                        }
                    }else{
                        //锁仓成功
                        $gift_status = array();
                        $gift_status['gift_status'] = 4;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                    }


                    $trans_status = $this->db->trans_status();
                    if ($total_account_money['code'] != 0 || $user_account_add['code'] != 0) {
                        $trans_status = false;
                    }
                    if ($trans_status === false) {
                        $this->db->trans_rollback();
                        return $args;
                    } else {

                        $this->db->trans_commit();
                        $data = array();
                        //修改状态
                        $data['type'] = 1;
                        $updated_at = date("Y-m-d H:i:s", time());
                        $data['updated_at'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $data);


                        $bussness_id = $id;
                        $time = date('Y-m-d H:i:s',time());
                        $business = '23'; //o
                        $description = '同意批量赠币';
                        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);
                        $this->db->trans_commit();
                        return true;
                    }
                } else {
                    //先看用户是否存在
                    $user_id = $args['uid'];
                    $user_out = $this->Zjys_user_model->get_info($user_id);
                    if (empty($user_out)) returnJson('300', lang('user_id not exist'));

                    //根据站点查找该站点总账户user_id
                    $total_user_id = $this->Platform_account_model->get_user_id($site_id);
                    if ($total_user_id['user_id'] == NULL) {
                        returnJson('300', lang('site_id not totalaccount'));
                    } else if ($total_user_id['user_id'] == $user_id) {
                        returnJson('300', lang('not give it to yourself'));
                    }

                    if (!empty($total_user_id['user_id'])) {
                        //获取总账户余额，判断余额是否足够
                        $asset = $args['asset'];
                        $response = check_balance($total_user_id['user_id'], $asset);
                        if (!empty($response)) {
                            if ($response['result'][$asset]['available'] < $args['amount']) {
                                returnJson('300', lang('Insufficient balance'));
                            }
                        } else {
                            returnJson('300', lang('transfer_out_uid not asset'));
                        }
                    }

                    $site_id = $site_id;
                    $asset = $args['asset'];
                    $amount = trim($args['amount']);
                    $amount_neg = "-" . $amount;
                    $remark = isset($args['remark']) ? $args['remark'] : '';
                    $operation_admin_id = $this->user_id;
                    $time = date('Y-m-d H:i:s', time());

                    $this->db->trans_begin();
                    //插入赠币记录表

                    $bussness_id = $id;
                    if(!empty($bussness_id)){
                        $bussness = 'admin_gift_activity_money';
                        $remark_add = array('info'=>$user_id,'remark'=>$remark);
                        $remark_add = json_encode($remark_add);

                        $total_account_money = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);
                        if ($total_account_money['code'] != 0) {
                            //扣款失败
                            $gift_status = array();
                            $gift_status['gift_status'] = 1;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                        }else{
                            //扣款成功后，锁定用户资金
                            $gift_status = array();
                            $gift_status['gift_status'] = 2;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                            //type=1是锁仓
                            $user_activity_lock = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],1,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                        }
                        if ($user_activity_lock['code'] != 0) {
                            //锁仓失败
                            $gift_status = array();
                            $gift_status['gift_status'] = 3;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                            //锁仓失败后，给总账户加回钱
                            $total_account_add_money = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                            if ($total_account_add_money['code'] != 0) {
                                //总账户加钱失败
                                $gift_status = array();
                                $gift_status['gift_status'] = 5;
                                $updated_at = date("Y-m-d H:i:s",time());
                                $gift_status['gift_time'] = $updated_at;
                                $this->db->where('id', $id);
                                $this->db->update('platfrom_gift_coin_record', $gift_status);
                            }else{
                                //总账户加钱成功
                                $gift_status = array();
                                $gift_status['gift_status'] = 6;
                                $updated_at = date("Y-m-d H:i:s",time());
                                $gift_status['gift_time'] = $updated_at;
                                $this->db->where('id', $id);
                                $this->db->update('platfrom_gift_coin_record', $gift_status);
                            }
                        }else{
                            //锁仓成功
                            $gift_status = array();
                            $gift_status['gift_status'] = 4;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                        }

                        $trans_status = $this->db->trans_status();

                        if ( $user_activity_lock['code'] != 0 || $total_account_money['code'] != 0) {
                            $trans_status = false;
                        }
                        if ($trans_status === false) {
                            $this->db->trans_rollback();
                            return $args;
                        } else {
                            $this->db->trans_commit();
                            $data = array();
                            //修改状态
                            $data['type'] = 1;
                            $updated_at = date("Y-m-d H:i:s", time());
                            $data['updated_at'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $data);

                            $business_id = $id;
                            $time = date('Y-m-d H:i:s',time());
                            $business = '23'; //
                            $description = '同意批量赠币';
                            admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);

                            $this->db->trans_commit();
                            return true;
                        }
                    }


//                if (!empty($bussness_id)) {
//                    //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
//                    $bussness = 'admin_gift_activity_money';
//                    //'{"info":" "remark":"活动赠币"}'
//
//                    $remark_add = array('info' => $args['uid'], 'remark' => $remark);
//                    $remark_add = json_encode($remark_add);
//                    $remark1 = array('info' => intval($args['uid']), 'remark' => $remark);
//                    $remark1 = json_encode($remark1);
//
//                    $data = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);
//                    $data1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'], 0, $asset, $bussness, $bussness_id, $amount_neg, $site_id, $remark1, $remark);
//
////
//
//                    $created_at = date("Y-m-d H:i:s", time());
//                    $updated_at = date("Y-m-d H:i:s", time());
////
////                if ($id) {
////
////                    $result = $this->Zjys_user_model->lockposition_update($args['asset'], $args['uid'], trim($args['amount']), $args['expire_time'], $args['remark'], $updated_at, $id);
////
////                } else {
//
//                    $status = 0;
//                    if ($args['amount'] <= 0) returnJson('402', '锁仓数量不能大于可用数量');
//                    $result = $this->Zjys_user_model->lockposition_add($args['asset'], $args['uid'], trim($args['amount']), $args['expire_time'], $args['remark'], $status, $created_at, $updated_at);
//                    $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'], $args['uid']);
//                    if (is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
//                    //2、新增冻结记录
//                    $balance = bcadd($last_balance['balance'], $args['amount']);
//                    $detail1 = json_encode(array('id' => $result));
//                    $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
//                    $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at, $updated_at, $args['uid'], $args['asset'], $args['amount'], $business, $balance, $detail1);
//                    //3、后台新增操作记录
//                    $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
//                    $description = null;
//                    admin_operation_logs($this->user_id, $args['uid'], $business, $description, $created_at, $result);
//                    //4、减去用户可用资金
//                    $text = '锁仓';
//                    $ss = array('info' => $text);
//                    // $res_lock = update_user_balance_bycurl($args['uid'],$args['asset'],-$args['amount'],$result,$ss,$busi='lock_position');
//
//                    $remark_add = array('info' => $user_id, 'remark' => $remark);
//                    $remark_add = json_encode($remark_add);
//                    $business = "activity_lock_position";
//                    $res_lock = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $args['asset'], $business, $result, -$args['amount'], $site_id, $remark_add, $remark);
//
//                    $trans_status = $this->db->trans_status();
//                    if ( $data['code'] != 0 || $data1['code'] != 0) {
//                        $trans_status = false;
//                    }
//                    if ($trans_status === false) {
//                        $this->db->trans_rollback();
//                        return $args;
//                    } else {
//                        $this->db->trans_commit();
//                        $data = array();
//                        //修改状态
//                        $data['type'] = 1;
//                        $updated_at = date("Y-m-d H:i:s", time());
//                        $data['updated_at'] = $updated_at;
//                        $this->db->where('id', $id);
//                        $this->db->update('platfrom_gift_coin_record', $data);
//
//                        $bussness_id = $id;
//                        $time = date('Y-m-d H:i:s',time());
//                        $business = '23'; //o
//                        $description = '同意批量赠币';
//                        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);
//
//                        $this->db->trans_commit();
//                        return true;
//                    }
//                }
                }
            }
        }else{
            $remark =  $user_id."已经审核";
            returnJson("402",$remark);
        }

    }

    /**
     * Notes: 批量赠币-老
     * User: 张哲
     * Date: 2018/11/26
     * Time: 15:49
     * @param $args
     * @return bool
     */
    public function batch_gift_coin1($args,$sum,$site_id)
    {

        if($args['lock'] == 1){

            if(empty($args['expire_time'])) returnJson('300',lang('time is null'));

            //先看用户是否存在
            $user_id = $args['uid'];
            $user_out = $this->Zjys_user_model->get_info($user_id);
            if(empty($user_out))  returnJson('300',lang('user_id not exist'));

            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                //获取总账户余额，判断余额是否足够
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }

            $site_id = $site_id;
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $amount_neg = "-".$amount;
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());

            $this->db->trans_begin();
            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }
            $bussness = 'admin_giftmoney';
            //$remark = array('info'=>$remark);
            // $res = update_user_balance_bycurl($args['uid'],$asset,$amount,$bussness_id,$remark,$bussness);
            //$res1 = update_user_balance_bycurl($total_user_id['user_id'],$asset,$amount_neg,$bussness_id,$remark,$bussness);


            $remark_add = array('info'=>$user_id,'remark'=>$remark);
            $remark_add = json_encode($remark_add);
            $res = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
            $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);

            //锁仓
            $id = isset($args['id']) ? $args['id'] : false;
            if(!is_numeric($args['uid'])) return false;
            $created_at = date("Y-m-d H:i:s",time());
            $updated_at = date("Y-m-d H:i:s",time());

            if($id){
                $result = $this->Zjys_user_model->lockposition_update($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$updated_at,$id);
            }else{
                $status = 0;
                $check_status =1;
                if($args['amount']<=0) returnJson('402','锁仓数量不能大于可用数量');
                $result = $this->Zjys_user_model->lockposition_add($args['asset'],$args['uid'],trim($args['amount']),$args['expire_time'],$args['remark'],$status,$created_at,$updated_at,$check_status);
                $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'],$args['uid']);
                if(is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
                //2、新增冻结记录
                $balance = bcadd($last_balance['balance'],$args['amount']);
                $detail1 = json_encode(array('id'=>$result));
                $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
                $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$args['uid'],$args['asset'],$args['amount'],$business,$balance,$detail1);
                //3、后台新增操作记录
                $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
                $description = null;
                admin_operation_logs($this->user_id,$args['uid'],$business,$description,$created_at,$result);
                //4、减去用户可用资金
                $text = '锁仓';
                $ss = array('info'=>$text);
                //$res_lock = update_user_balance_bycurl($args['uid'],$args['asset'],-$args['amount'],$result,$ss,$busi='lock_position');

                $remark_add = array('info'=>$user_id,'remark'=>$remark);
                $remark_add = json_encode($remark_add);
                $business = "lock_position";
                $res_lock = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$args['asset'],$business,$result,-$args['amount'],$site_id,$remark_add,$remark);
            }

            $trans_status = $this->db->trans_status();
            if($res['code'] != 0 || $res1['code'] != 0 || $res_lock['code'] != 0)
            {
                $trans_status = false;
            }
            if ($trans_status === false) {
                $this->db->trans_rollback();
                return $args;
            } else {
                $this->db->trans_commit();
                return true;
            }
        }else if($args['lock'] == 0){
            //先看用户是否存在
            $user_id = intval($args['uid']);
            $user_out = $this->Zjys_user_model->get_info($user_id);
            if(empty($user_out))  returnJson('300',lang('user_id not exist'));

            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                //获取总账户余额，判断余额是否足够
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }

            $site_id = $site_id;
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $amount_neg = "-".$amount;
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());

            $this->db->trans_begin();
            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }
            $bussness = 'admin_giftmoney';
            // $remark = array('info'=>$remark);
            // $res = update_user_balance_bycurl($args['uid'],$asset,$amount,$bussness_id,$remark,$bussness);
            // $res1 = update_user_balance_bycurl($total_user_id['user_id'],$asset,$amount_neg,$bussness_id,$remark,$bussness);

            $remark_add = array('info'=>$user_id,'remark'=>$remark);
            $remark_add = json_encode($remark_add);
            $res = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id,0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);

            $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);


            $trans_status = $this->db->trans_status();
            if($res['code'] != 0 || $res1['code'] != 0)
            {
                $trans_status = false;
            }
            if ($trans_status === false) {
                $this->db->trans_rollback();
                return $args;
            } else {
                $this->db->trans_commit();
                return true;
            }
        }else{
            //先看用户是否存在
            $user_id = $args['uid'];
            $user_out = $this->Zjys_user_model->get_info($user_id);
            if(empty($user_out))  returnJson('300',lang('user_id not exist'));

            //根据站点查找该站点总账户user_id
            $total_user_id = $this->Platform_account_model->get_user_id($site_id);
            if(empty($total_user_id)) returnJson('402','该平台没有总账户');
            if($total_user_id['user_id'] == NULL){
                returnJson('300',lang('site_id not totalaccount'));
            }else  if($total_user_id['user_id'] == $user_id){
                returnJson('300',lang('not give it to yourself'));
            }

            if(!empty($total_user_id['user_id'])){
                //获取总账户余额，判断余额是否足够
                $asset = $args['asset'];
                $response = check_balance($total_user_id['user_id'],$asset);
                if (!empty($response)){
                    if($response['result'][$asset]['available']<$args['amount']){
                        returnJson('300',lang('Insufficient balance'));
                    }
                }else{
                    returnJson('300',lang('transfer_out_uid not asset'));
                }
            }

            $site_id = $site_id;
            $asset = $args['asset'];
            $amount = trim($args['amount']);
            $amount_neg = "-".$amount;
            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());

            $this->db->trans_begin();
            //插入赠币记录表
            if(!empty($args['expire_time'])){
                $bussness_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);
            }else{
                $bussness_id = $this->Platfrom_gift_coin_record_model->add1($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock']);
            }

            if(!empty($bussness_id)){
                //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
                $bussness = 'admin_gift_activity_money';
                //'{"info":" "remark":"活动赠币"}'

                $remark_add = array('info'=>$args['uid'],'remark'=>$remark);
                $remark_add = json_encode($remark_add);
                $remark1 = array('info'=>intval($args['uid']),'remark'=>$remark);
                $remark1 = json_encode($remark1);

                $data = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                $data1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark1,$remark);
                $trans_status = $this->db->trans_status();
                if($data['code'] != 0 || $data1['code'] != 0)
                {
                    $trans_status = false;
                }
                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    return $args;
                } else {
                    $this->db->trans_commit();
                    return true;
                }
            }
        }

    }


    /**
     * Notes: 批量赠币
     * User: 张哲
     * Date: 2019-06-19
     * Time: 11:06
     */
    public function batch_gift_coin($args,$sum,$site_id){
        //先看用户是否存在
      //  if(empty($args['expire_time'])) returnJson('300',lang('time is null'));

        //先看用户是否存在
        $user_id = $args['uid'];
        $user_out = $this->Zjys_user_model->get_info($user_id);
        if(empty($user_out))  returnJson('300',lang('user_id not exist'));

        //根据站点查找该站点总账户user_id
        $total_user_id = $this->Platform_account_model->get_user_id($site_id);
        if($total_user_id['user_id'] == NULL){
            returnJson('300',lang('site_id not totalaccount'));
        }else  if($total_user_id['user_id'] == $user_id){
            returnJson('300',lang('not give it to yourself'));
        }

//        if(!empty($total_user_id['user_id'])){
//            //获取总账户余额，判断余额是否足够
//            $asset = $args['asset'];
//            $response = check_balance($total_user_id['user_id'],$asset);
//
////            var_dump($response['result'][$asset]['available'],$args['amount']);die();
////            if (!empty($response)){
////                if($response['result'][$asset]['available']<$args['amount']){
////                    returnJson('300',lang('Insufficient balance'));
////                }
////            }else{
////                returnJson('300',lang('transfer_out_uid not asset'));
////            }
//        };
       // var_dump($args);die();
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());

        if(empty($args['expire_time'])) $args['expire_time'] = NULL;
        $business_id = $this->Platfrom_gift_coin_record_model->add($operation_admin_id,$time,$asset,$amount,$args['uid'],$remark,$site_id,$total_user_id['user_id'],$args['lock'],$args['expire_time']);

        if(!empty($business_id))

        $time = date('Y-m-d H:i:s',time());
        $business = '22'; //o
        $description = '批量赠币提交';
        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);

        return true;
    }

    /**
     * Notes: 批量赠币-new
     * User: 张哲
     * Date: 2018/11/26
     * Time: 15:49
     * @param $args
     * @return bool
     */
    public function batch_gift_coin_verity($args,$sum,$site_id,$type)
    {
        //先看用户是否存在
        $id = $args['id'];
        $args['uid'] = $args['user_id'];
        $site_id = $args['site_id'];
        $user_id = $args['uid'];

        $object = $this->db->select("platfrom_gift_coin_record.*")
            ->from('platfrom_gift_coin_record');
        $object =$this->db->where('platfrom_gift_coin_record.id = ',$id);
        $list = $object->get()->result_array();
        $gift_status = $list[0]['gift_status'];

        if($gift_status == 0){
            if($type == 0){

                $data = array();
                //修改状态
                $data['type'] = 2;
                $updated_at = date("Y-m-d H:i:s",time());
                $data['updated_at'] = $updated_at;
                $this->db->where('id', $id);
                $this->db->update('platfrom_gift_coin_record', $data);

                $bussness_id = $id;
                $time = date('Y-m-d H:i:s',time());
                $business = '23'; //o
                $description = '拒绝批量赠币';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);
                return true;
            }else {

                if ($args['lock'] == 1) {

                    if (empty($args['expire_time'])) returnJson('300', lang('time is null'));

                    //先看用户是否存在
                    $user_id = $args['uid'];
                    $user_out = $this->Zjys_user_model->get_info($user_id);
                    if (empty($user_out)) returnJson('300', lang('user_id not exist'));

                    //根据站点查找该站点总账户user_id
                    $total_user_id = $this->Platform_account_model->get_user_id($site_id);

                    if ($total_user_id['user_id'] == NULL) {
                        returnJson('300', lang('site_id not totalaccount'));
                    } else if ($total_user_id['user_id'] == $user_id) {
                        returnJson('300', lang('not give it to yourself'));
                    }

                    if (!empty($total_user_id['user_id'])) {
                        //获取总账户余额，判断余额是否足够
                        $asset = $args['asset'];
                        $response = check_balance($total_user_id['user_id'], $asset);
                        if (!empty($response)) {
                            if ($response['result'][$asset]['available'] < $args['amount']) {
                                returnJson('300', lang('Insufficient balance'));
                            }
                        } else {
                            returnJson('300', lang('transfer_out_uid not asset'));
                        }
                    }

                    $site_id = $site_id;
                    $asset = $args['asset'];
                    $amount = trim($args['amount']);
                    $amount_neg = "-" . $amount;
                    $remark = isset($args['remark']) ? $args['remark'] : '';
                    $operation_admin_id = $this->user_id;
                    $time = date('Y-m-d H:i:s', time());

                    $this->db->trans_begin();
                    //插入赠币记录表
                    $bussness_id = $id;
                    $bussness = 'admin_giftmoney';


                    $remark_add = array('info' => $user_id, 'remark' => $remark);
                    $remark_add = json_encode($remark_add);
                    //$total_account_money = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);
                    $total_account_money = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'], 0, $asset, $bussness, $bussness_id, $amount_neg, $site_id, $remark_add, $remark);


                    $trans_status = $this->db->trans_status();
                    if ( $total_account_money['code'] != 0) {
                        $trans_status = false;

                        $gift_status = array();
                        $gift_status['gift_status'] = 1;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                    }else{
                        $gift_status = array();
                        $gift_status['gift_status'] = 2;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);

                        $created_at = date("Y-m-d H:i:s", time());
                        $updated_at = date("Y-m-d H:i:s", time());

                        $status = 0;
                        $check_status = 1;
                        if ($args['amount'] <= 0) returnJson('402', '锁仓数量不能大于可用数量');
                        $result = $this->Zjys_user_model->lockposition_add($args['asset'], $args['uid'], trim($args['amount']), $args['expire_time'], $args['remark'], $status, $created_at, $updated_at,$check_status);
                        //查看冻结表余额
                        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'], $args['uid']);
                        if (is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
                        //2、新增冻结记录
                        $balance = bcadd($last_balance['balance'], $args['amount'],16);
                        $detail1 = json_encode(array('id' => $result));
                        $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
                        $time_lock = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at, $updated_at, $args['uid'], $args['asset'], $args['amount'], $business, $balance, $detail1);
                        //3、后台新增操作记录
                        $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
                        $description = null;
                        admin_operation_logs($this->user_id, $args['uid'], $business, $description, $created_at, $result);
                        //4、减去用户可用资金
//                    $text = '锁仓';
//                    $ss = array('info' => $text);
//                    //$res_lock = update_user_balance_bycurl($args['uid'],$args['asset'],-$args['amount'],$result,$ss,$busi='lock_position');
//
//                    $remark_add = array('info' => $user_id, 'remark' => $remark);
//                    $remark_add = json_encode($remark_add);
//                    $business = "lock_position";
                        //  $res_lock = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $args['asset'], $business, $result, -$args['amount'], $site_id, $remark_add, $remark);

                        if(empty($time_lock)){
                            $gift_status = array();
                            $gift_status['gift_status'] = 3;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                            $total_account_add = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'], 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);
                            if($total_account_money['$total_account_add'] != 0){
                                $gift_status = array();
                                $gift_status['gift_status'] = 5;
                                $updated_at = date("Y-m-d H:i:s",time());
                                $gift_status['gift_time'] = $updated_at;
                                $this->db->where('id', $id);
                                $this->db->update('platfrom_gift_coin_record', $gift_status);
                            }else{
                                $gift_status = array();
                                $gift_status['gift_status'] = 6;
                                $updated_at = date("Y-m-d H:i:s",time());
                                $gift_status['gift_time'] = $updated_at;
                                $this->db->where('id', $id);
                                $this->db->update('platfrom_gift_coin_record', $gift_status);
                            }
                        }else{
                            $gift_status = array();
                            $gift_status['gift_status'] = 4;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);

                        }

                    }

                    if ($trans_status === false) {
                        $this->db->trans_rollback();
                        return $args;
                    } else {
                        $this->db->trans_commit();
                        $data = array();
                        //修改状态
                        $data['type'] = 1;
                        $updated_at = date("Y-m-d H:i:s", time());
                        $data['updated_at'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $data);

                        $bussness_id = $id;
                        $time = date('Y-m-d H:i:s',time());
                        $business = '23'; //o
                        $description = '同意批量赠币';
                        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);

                        $this->db->trans_commit();
                        return true;
                    }
                } else if ($args['lock'] == 0) {
                    //先看用户是否存在
                    $user_id = $args['uid'];
                    $user_out = $this->Zjys_user_model->get_info($user_id);
                    if (empty($user_out)) returnJson('300', lang('user_id not exist'));

                    //根据站点查找该站点总账户user_id
                    $total_user_id = $this->Platform_account_model->get_user_id($site_id);
                    if ($total_user_id['user_id'] == NULL) {
                        returnJson('300', lang('site_id not totalaccount'));
                    } else if ($total_user_id['user_id'] == $user_id) {
                        returnJson('300', lang('not give it to yourself'));
                    }

                    $site_id = $site_id;
                    $asset = $args['asset'];
                    $amount = trim($args['amount']);
                    $amount_neg = "-" . $amount;
                    $remark = isset($args['remark']) ? $args['remark'] : '';
                    $operation_admin_id = $this->user_id;
                    $time = date('Y-m-d H:i:s', time());

                    $this->db->trans_begin();
                    //插入赠币记录表
                    $bussness_id = $id;
                    $bussness = 'admin_giftmoney';

                    $remark_add = array('info' => $user_id, 'remark' => '');
                    $remark_add = json_encode($remark_add);

                    //先扣除账户总额成功后，用户余额加钱；如果加钱失败，则总账户将扣款加回；所有操作加记录状态
                    $total_account_money = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'], 0, $asset, $bussness, $bussness_id, $amount_neg, $site_id, $remark_add, $remark);


                    if ($total_account_money['code'] != 0) {
                        //扣款失败
                        $gift_status = array();
                        $gift_status['gift_status'] = 1;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                    }else{
                        //扣款成功后，锁定用户资金
                        $gift_status = array();
                        $gift_status['gift_status'] = 2;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                        //type=1是加钱
                        $user_account_add= $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);
                    }

                    if ($user_account_add['code'] != 0) {
                        //锁仓失败
                        $gift_status = array();
                        $gift_status['gift_status'] = 3;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                        //锁仓失败后，给总账户加回钱
                        $user_account_deduction = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                        if ($user_account_deduction['code'] != 0) {
                            //总账户加钱失败
                            $gift_status = array();
                            $gift_status['gift_status'] = 5;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                        }else{
                            //总账户加钱成功
                            $gift_status = array();
                            $gift_status['gift_status'] = 6;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                        }
                    }else{
                        //锁仓成功
                        $gift_status = array();
                        $gift_status['gift_status'] = 4;
                        $updated_at = date("Y-m-d H:i:s",time());
                        $gift_status['gift_time'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $gift_status);
                    }


                    $trans_status = $this->db->trans_status();
                    if ($total_account_money['code'] != 0 || $user_account_add['code'] != 0) {
                        $trans_status = false;
                    }
                    if ($trans_status === false) {
                        $this->db->trans_rollback();
                        return $args;
                    } else {

                        $this->db->trans_commit();
                        $data = array();
                        //修改状态
                        $data['type'] = 1;
                        $updated_at = date("Y-m-d H:i:s", time());
                        $data['updated_at'] = $updated_at;
                        $this->db->where('id', $id);
                        $this->db->update('platfrom_gift_coin_record', $data);


                        $bussness_id = $id;
                        $time = date('Y-m-d H:i:s',time());
                        $business = '23'; //o
                        $description = '同意批量赠币';
                        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);
                        $this->db->trans_commit();
                        return true;
                    }
                } else {
                    //先看用户是否存在
                    $user_id = $args['uid'];
                    $user_out = $this->Zjys_user_model->get_info($user_id);
                    if (empty($user_out)) returnJson('300', lang('user_id not exist'));

                    //根据站点查找该站点总账户user_id
                    $total_user_id = $this->Platform_account_model->get_user_id($site_id);
                    if ($total_user_id['user_id'] == NULL) {
                        returnJson('300', lang('site_id not totalaccount'));
                    } else if ($total_user_id['user_id'] == $user_id) {
                        returnJson('300', lang('not give it to yourself'));
                    }

                    if (!empty($total_user_id['user_id'])) {
                        //获取总账户余额，判断余额是否足够
                        $asset = $args['asset'];
                        $response = check_balance($total_user_id['user_id'], $asset);
                        if (!empty($response)) {
                            if ($response['result'][$asset]['available'] < $args['amount']) {
                                returnJson('300', lang('Insufficient balance'));
                            }
                        } else {
                            returnJson('300', lang('transfer_out_uid not asset'));
                        }
                    }

                    $site_id = $site_id;
                    $asset = $args['asset'];
                    $amount = trim($args['amount']);
                    $amount_neg = "-" . $amount;
                    $remark = isset($args['remark']) ? $args['remark'] : '';
                    $operation_admin_id = $this->user_id;
                    $time = date('Y-m-d H:i:s', time());

                    $this->db->trans_begin();
                    //插入赠币记录表

                    $bussness_id = $id;
                    if(!empty($bussness_id)){
                        $bussness = 'admin_gift_activity_money';
                        $remark_add = array('info'=>$user_id,'remark'=>$remark);
                        $remark_add = json_encode($remark_add);

                        $total_account_money = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount_neg,$site_id,$remark_add,$remark);
                        if ($total_account_money['code'] != 0) {
                            //扣款失败
                            $gift_status = array();
                            $gift_status['gift_status'] = 1;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                        }else{
                            //扣款成功后，锁定用户资金
                            $gift_status = array();
                            $gift_status['gift_status'] = 2;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                            //type=1是锁仓
                            $user_activity_lock = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'],1,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                        }

                        if ($user_activity_lock['code'] != 0) {
                            //锁仓失败
                            $gift_status = array();
                            $gift_status['gift_status'] = 3;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                            //锁仓失败后，给总账户加回钱
                            $total_account_add_money = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'],0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark_add,$remark);
                            if ($total_account_add_money['code'] != 0) {
                                //总账户加钱失败
                                $gift_status = array();
                                $gift_status['gift_status'] = 5;
                                $updated_at = date("Y-m-d H:i:s",time());
                                $gift_status['gift_time'] = $updated_at;
                                $this->db->where('id', $id);
                                $this->db->update('platfrom_gift_coin_record', $gift_status);
                            }else{
                                //总账户加钱成功
                                $gift_status = array();
                                $gift_status['gift_status'] = 6;
                                $updated_at = date("Y-m-d H:i:s",time());
                                $gift_status['gift_time'] = $updated_at;
                                $this->db->where('id', $id);
                                $this->db->update('platfrom_gift_coin_record', $gift_status);
                            }
                        }else{
                            //锁仓成功
                            $gift_status = array();
                            $gift_status['gift_status'] = 4;
                            $updated_at = date("Y-m-d H:i:s",time());
                            $gift_status['gift_time'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $gift_status);
                        }


                        $trans_status = $this->db->trans_status();

                        if ( $user_activity_lock['code'] != 0 || $total_account_money['code'] != 0) {
                            $trans_status = false;
                        }
                        if ($trans_status === false) {
                            $this->db->trans_rollback();
                            return $args;
                        } else {
                            $this->db->trans_commit();
                            $data = array();
                            //修改状态
                            $data['type'] = 1;
                            $updated_at = date("Y-m-d H:i:s", time());
                            $data['updated_at'] = $updated_at;
                            $this->db->where('id', $id);
                            $this->db->update('platfrom_gift_coin_record', $data);

                            $business_id = $id;
                            $time = date('Y-m-d H:i:s',time());
                            $business = '23'; //
                            $description = '同意批量赠币';
                            admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);

                            $this->db->trans_commit();
                            return true;
                        }
                    }


//                if (!empty($bussness_id)) {
//                    //用户id,类型,币种, 业务, 业务ID,更新资金,详情,站点,备注,活动唯一编号,活动类型,是否解锁 false / true
//                    $bussness = 'admin_gift_activity_money';
//                    //'{"info":" "remark":"活动赠币"}'
//
//                    $remark_add = array('info' => $args['uid'], 'remark' => $remark);
//                    $remark_add = json_encode($remark_add);
//                    $remark1 = array('info' => intval($args['uid']), 'remark' => $remark);
//                    $remark1 = json_encode($remark1);
//
//                    $data = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $asset, $bussness, $bussness_id, $amount, $site_id, $remark_add, $remark);
//                    $data1 = $this->Sys_grpc_service->ActivityBalanceUpdate($total_user_id['user_id'], 0, $asset, $bussness, $bussness_id, $amount_neg, $site_id, $remark1, $remark);
//
////
//
//                    $created_at = date("Y-m-d H:i:s", time());
//                    $updated_at = date("Y-m-d H:i:s", time());
////
////                if ($id) {
////
////                    $result = $this->Zjys_user_model->lockposition_update($args['asset'], $args['uid'], trim($args['amount']), $args['expire_time'], $args['remark'], $updated_at, $id);
////
////                } else {
//
//                    $status = 0;
//                    if ($args['amount'] <= 0) returnJson('402', '锁仓数量不能大于可用数量');
//                    $result = $this->Zjys_user_model->lockposition_add($args['asset'], $args['uid'], trim($args['amount']), $args['expire_time'], $args['remark'], $status, $created_at, $updated_at);
//                    $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($args['asset'], $args['uid']);
//                    if (is_array($last_balance) && empty($last_balance)) $last_balance['balance'] = '0';
//                    //2、新增冻结记录
//                    $balance = bcadd($last_balance['balance'], $args['amount']);
//                    $detail1 = json_encode(array('id' => $result));
//                    $business = $this->config->item('ADMIN_FREEZE');//freeze表中的business
//                    $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at, $updated_at, $args['uid'], $args['asset'], $args['amount'], $business, $balance, $detail1);
//                    //3、后台新增操作记录
//                    $business = $this->config->item('ADMIN_FREEZE_ADD'); //operation表中的operation_type
//                    $description = null;
//                    admin_operation_logs($this->user_id, $args['uid'], $business, $description, $created_at, $result);
//                    //4、减去用户可用资金
//                    $text = '锁仓';
//                    $ss = array('info' => $text);
//                    // $res_lock = update_user_balance_bycurl($args['uid'],$args['asset'],-$args['amount'],$result,$ss,$busi='lock_position');
//
//                    $remark_add = array('info' => $user_id, 'remark' => $remark);
//                    $remark_add = json_encode($remark_add);
//                    $business = "activity_lock_position";
//                    $res_lock = $this->Sys_grpc_service->ActivityBalanceUpdate($args['uid'], 0, $args['asset'], $business, $result, -$args['amount'], $site_id, $remark_add, $remark);
//
//                    $trans_status = $this->db->trans_status();
//                    if ( $data['code'] != 0 || $data1['code'] != 0) {
//                        $trans_status = false;
//                    }
//                    if ($trans_status === false) {
//                        $this->db->trans_rollback();
//                        return $args;
//                    } else {
//                        $this->db->trans_commit();
//                        $data = array();
//                        //修改状态
//                        $data['type'] = 1;
//                        $updated_at = date("Y-m-d H:i:s", time());
//                        $data['updated_at'] = $updated_at;
//                        $this->db->where('id', $id);
//                        $this->db->update('platfrom_gift_coin_record', $data);
//
//                        $bussness_id = $id;
//                        $time = date('Y-m-d H:i:s',time());
//                        $business = '23'; //o
//                        $description = '同意批量赠币';
//                        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$bussness_id);
//
//                        $this->db->trans_commit();
//                        return true;
//                    }
//                }
                }
            }
        }else{
            $remark =  $user_id."已经审核";
            returnJson("402",$remark);
        }


    }

}