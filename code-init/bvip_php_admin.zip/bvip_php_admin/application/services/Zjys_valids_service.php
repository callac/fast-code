<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_valids_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Account_capital_racharge_model');
        $this->load->model('Account_capital_withdraw_model');
        $this->load->model('Security_bulid_hash_model');
        $this->load->model('User_capital_model');
        $this->load->model('User_model');
    }   

    // //充值列表
    //  public function recharge_list($page = 1,$limit = 10){
    //     $this->load->model('Account_capital_racharge_model');
    //     $offest = ($page -1) * $limit;
    //     $recharge_list = array();
    //     $recharge_list = $this->Account_capital_racharge_model->recharge_list($offest,$limit);
    //     if(!empty($recharge_list)){
    //         foreach ($recharge_list as $key => &$value) {
    //             $value['pay_time'] = date('Y-m-d H:i:s',$value['pay_time']);
    //             if($value['status'] == 0){
    //                 $value['status_type'] = '提交';
    //             } elseif($value['status'] == 1){
    //                 $value['status_type'] = '充值中';
    //             } elseif($value['status'] == 2){
    //                 $value['status_type'] = '充值成功';
    //             } elseif($value['status'] == 3){
    //                 $value['status_type'] = '充值失败';
    //             } elseif($value['status'] == 4){
    //                 $value['status_type'] = '已取消';
    //             }

    //              if($value['pay_type'] == 1){
    //                 $value['pay_way'] = '电脑支付';
    //             } elseif($value['pay_type'] == 2){
    //                 $value['pay_way'] = '手机支付';
    //             } elseif($value['pay_type'] == 3){
    //                 $value['pay_way'] = 'app支付';
    //             }
    //         }
    //     }
    //     return $recharge_list;
    // }


    /**
     * 充值列表加搜索
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      每页条数
     * @param    [type]       $name       关键词
     * @param    [type]       $start_time 开始时间
     * @param    [type]       $end_time   结束时间
     * @param    [type]       $site_id    站点id
     * @return   [type]                   [description]
     */
    public function valids_list($offset,$limit,$name,$start_time,$end_time,$type,$use_type,$site_id){
        $object = $this->db->select("user_valids.*,b_site.name as site_name")
            ->from('user_valids')
            ->join('b_site','user_valids.site_id=b_site.id','left');
            // ->join('user_withdraw_addresses','user_withdraw_addresses.id=user_withdraws.user_id','left')
            // ->join('users','users.id=user_withdraws.user_id','left');
        // $object =$this->db->where('user_identities.status =',2); //实名过的
        if($site_id!='') $object =$this->db->where('user_valids.site_id = ',$site_id);

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('user_valids.extra = ',$name);
            }else{
                $object =$this->db->where('user_valids.extra = ',$name);
            }
        }

        if($type !== null){ //手机or邮箱验证码
            $object =$this->db->where('user_valids.type =',$type);
        }

        if(!empty($use_type)){
            $object =$this->db->where('user_valids.use_type =',$use_type);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_valids.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_valids.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        foreach ($list as &$value) {
            $value['code'] = '******';
            # code...
            if($value['type'] == 0){
                $value['type'] = "手机验证码";
            } else{
                $value['type'] = "邮箱验证码";
            } 

            if($value['is_used'] == 0){
                $value['is_used'] = "未使用";
            }else{
                $value['is_used'] = "已使用";
            }

            if($value['use_type'] == 0){
                $value['use_type'] = "注册";
            }elseif($value['use_type'] == 1){
                $value['use_type'] = "登录";
            }elseif($value['use_type'] == 2){
                $value['use_type'] = "忘记密码";
            }elseif($value['use_type'] == 3){
                $value['use_type'] = "两步验证";
            }elseif($value['use_type'] == 4){
                $value['use_type'] = "绑定手机";
            }elseif($value['use_type'] == 5){
                $value['use_type'] = "绑定邮箱";
            }elseif($value['use_type'] == 6){
                $value['use_type'] = "创建提现密码";
            }elseif($value['use_type'] == 7){
                $value['use_type'] = "提现";
            }elseif($value['use_type'] == 8){
                $value['use_type'] = "关闭手机";
            }elseif($value['use_type'] == 9){
                $value['use_type'] = "关闭邮箱";
            }elseif($value['use_type'] == 10){
                $value['use_type'] = "关闭两步验证";
            }elseif($value['use_type'] == 11){
                $value['use_type'] = "重置提现密码";
            }elseif($value['use_type'] == 12){
                $value['use_type'] = "绑定银行卡";
            }elseif($value['use_type'] == 13){
                $value['use_type'] = "重新绑定银行卡";
            }elseif($value['use_type'] == 14){
                $value['use_type'] = "创建提币地址";
            }elseif($value['use_type'] == 15){
                $value['use_type'] = "后台登录";
            }
        }
            return $list;
    }

    /**
     * 提现记录查询计数
     * @Author   左俊
     * @DateTime 2018-07-12
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $name       [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function valids_list_count($name,$start_time,$end_time,$type,$use_type,$site_id){
        // var_dump($type);die;
        $object = $this->db->select("user_valids.*")
            ->from('user_valids');
            // ->join('user_identities','user_identities.user_id=user_withdraws.user_id','left')
            // ->join('user_withdraw_addresses','user_withdraw_addresses.id=user_withdraws.user_id','left')
            // ->join('users','users.id=user_withdraws.user_id','left');
        // $object =$this->db->where('user_identities.status =',2); //实名过的
        if($site_id!='') $object =$this->db->where('user_valids.site_id = ',$site_id);

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('user_valids.extra = ',$name);
            }else{
                $object =$this->db->where('user_valids.extra = ',$name);
            }
        }

        if($type !== null){ //手机or邮箱验证码
            
            $object =$this->db->where('user_valids.type =',$type);
        }
        if(!empty($use_type)){
            $object =$this->db->where('user_valids.use_type =',$use_type);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_valids.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_valids.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }


    //充值详情页
    public function recharge_details($id)
    {
        $this->load->model('Account_capital_racharge_model');
        $recharge_details = array();
        $recharge_details = $this->Account_capital_racharge_model->recharge_details($id);
        if(!empty($recharge_details)){
            foreach ($recharge_details as $key => &$value) {
                $value['pay_time'] = date('Y-m-d H:i:s',$value['pay_time']);

                //状态说明
                if($value['status'] == 0){
                    $value['status'] = '提交';
                } elseif($value['status'] == 1){
                    $value['status'] = '充值中';
                } elseif($value['status'] == 2){
                    $value['status'] = '充值成功';
                } elseif($value['status'] == 3){
                    $value['status'] = '充值失败';
                } elseif($value['status'] == 4){
                    $value['status'] = '已取消';
                }


                //充值渠道说明
                if($value['channel'] == 1){
                    $value['channel'] = 'paypal';
                } elseif($value['channel'] == 2 || $value['channel'] == 3){
                    $value['channel'] = '支付宝';
                }  elseif($value['channel'] == 4){
                    $value['channel'] = '银行卡';
                } else{
                    $value['channel'] = '未定义';
                }

                //手机号和邮箱合起来展示
                if($value['mobile'] == ''){
                  $value['user_account'] = $value['email'];
                }elseif($value['email'] == ''){
                  $value['user_account'] = $value['mobile'];
                }
            }
        }
        return $recharge_details;
    }


    //充值审核
    public function recharge_verify($id,$status)
    {
        $this->load->model('Account_capital_racharge_model');
        $this->load->model('User_model');
        // echo 111;die;
        //若失败手动回滚 成功手动提交
        $this->db->trans_begin();
        $info = $this->Account_capital_racharge_model->recharge_details($id)[0];
        //第一次审核通过,更新status状态为1
        if($status == 1){
            $result = $this->Account_capital_racharge_model->update_status($id);
        }

        //当第二次审核通过后账户更新余额
        if($status == 2){
            $user_id = $info['user_id'];
            $balance = $info['amount'];
            $balance_account = $info['balance_account']+$balance; //当前用户资金余额
            $site_id = $info['site_id'];
            $trade_id = $info['response_id'];
            $this->User_model->update_user_balance($user_id,$balance);

            $result = $this->Account_capital_racharge_model->recharge_verify($id,$status);
            //用户资金明细
            $description ='银行卡充值';
            $channel = 5;//银行卡
            $status1 = 2;//成功
            add_user_capital($user_id,1,$description,$balance,$channel,'',$order_id=$id,$trade_id,$status1,$site_id);


            //充值再次审核成功发送消息
             //再次审核通过
            
            $title = lang('top-up_success'); //消息标题
            if($info['channel']==4){
                $alipayorbank = lang('top-up_success_text1_for_bankcard'); //银行卡
            }else{
                $alipayorbank = lang('top-up_success_text2_for_bankcard'); //支付宝
            }
            $time = date('Y-m-d H:i:s',time());
            $text = $alipayorbank.$balance.lang('top-up_success_text2').$balance_account; //消息内容
            send_notification($user_id,$title,$text,$site_id);
            //增加保全表
            $this->load->model('Security_bulid_hash_model');
            $result = $this->Security_bulid_hash_model->add_baoquan_recharge($user_id,$id);
            //发短信或邮箱通知
            $replacement = array(
                'url' => get_site_domain($info['site_id'])
            );//要替换的短信内容
            send_msg($info['user_id'],$replacement,'recharge_yes');
        }
        if($status == 3){ //审核拒绝
            $result = $this->Account_capital_racharge_model->recharge_verify($id,$status);

            if($info['channel']==4){
                $alipayorbank = lang('top-up_fail_text1_for_bankcard'); //银行卡
            }else{
                $alipayorbank = lang('top-up_fail_text2_for_alipay'); //支付宝
            }

            $title = lang('top-up_fail'); //消息标题
            $time = date('Y-m-d H:i:s',time());
            $text = $alipayorbank.$info['amount'].lang('top-up_fail_text2'); //消息内容
            send_notification($info['user_id'],$title,$text);

            //发短信或邮箱通知
            $replacement = array(
                'url' => get_site_domain($info['site_id'])
            );//要替换的短信内容
            send_msg($info['user_id'],$replacement,'recharge_no');

        }
        

        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            log_message('err','订单id为'.$id.'的订单充值失败');
            return false;
        } else {
            $this->db->trans_commit();
            return $result;
        }

    }


    // /**
    //  * 提现列表
    //  * @Author   张哲
    //  * @DateTime 2018-03-28
    //  * @createby SublimeText3
    //  * @version  1.0
    //  * @return   [return]
    //  */
    //  public function withdraw_list($page = 1,$limit = 10){
    //     $this->load->model('Account_capital_withdraw_model');
    //     $offest = ($page -1) * $limit;
    //     $withdraw_list = array();
    //     $withdraw_list = $this->Account_capital_withdraw_model->withdraw_list($offest,$limit);
    //     if(!empty($withdraw_list)){
    //         foreach ($withdraw_list as $key => &$value) {
    //             $value['pay_time'] = date('Y-m-d H:i:s',$value['pay_time']);    //申请时间
    //             $value['apply_time'] = date('Y-m-d H:i:s',$value['apply_time']);  //打款时间 
    //             if($value['status'] == 0){                                      //状态
    //                 $value['status_type'] = '正在审核';
    //             } elseif($value['status'] == 1){
    //                 $value['status_type'] = '正在处理';
    //             } elseif($value['status'] == 2){
    //                 $value['status_type'] = '已完成';
    //             } elseif($value['status'] == 3){
    //                 $value['status_type'] = '已取消';
    //             } 
    //         }
    //     }
    //     return $withdraw_list;
    // }

    /**
     * 提现列表加搜索
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      每页条数
     * @param    [type]       $name       关键词
     * @param    [type]       $start_time 开始时间
     * @param    [type]       $end_time   结束时间
     * @param    [type]       $site_id    站点id
     * @return   [type]                   [description]
     */
    // public function withdraw_list($offset,$limit,$name,$start_time,$end_time,$site_id,$status){
    //     $object = $this->db->select("b_account_capital_withdraw_log.id,site.name as site_name,user.mobile,user.email,user.truename,b_account_capital_withdraw_log.bank,b_account_capital_withdraw_log.serial_number,b_account_capital_withdraw_log.account,b_account_capital_withdraw_log.amount,b_account_capital_withdraw_log.fee,b_account_capital_withdraw_log.return_receipt_code,b_account_capital_withdraw_log.status,b_account_capital_withdraw_log.apply_time,b_account_capital_withdraw_log.user_id")
    //         ->from('b_account_capital_withdraw_log')
    //         ->join('site','site.id=b_account_capital_withdraw_log.site_id','left')
    //         ->join('user','user.id=b_account_capital_withdraw_log.user_id','left');

    //     if(!empty($name)){
    //         // if('user.mobile' == ''){
    //         // $object =$this->db->where('user.email =',$name);
    //         // }elseif('user.email' == ''){
    //         $object =$this->db->where('user.mobile =',$name);
    //         //}
    //     }
        
    //     if($status != 'all'){
    //         $object =$this->db->where('b_account_capital_withdraw_log.status =',$status);
    //     }

    //     if(!empty($start_time)){
    //         $object =$this->db->where('b_account_capital_withdraw_log.apply_time >=',$start_time);
    //     }
    //     if(!empty($end_time)){
    //         $object =$this->db->where('b_account_capital_withdraw_log.apply_time <',$end_time);
    //     }
    //     if(!empty($site_id)){
    //         $object =$this->db->where('b_account_capital_withdraw_log.site_id =',$site_id);
    //     }

    //     $list = $object->limit($limit,$offset)->order_by('apply_time','desc')->get()->result_array();

    //     foreach ($list as &$val){
    //     //对时间戳的处理    
    //     $val['pay_time'] = date('Y-m-d H:i',$val['apply_time']);
    //     //到账金额
    //     $val['money'] = $val['amount'] - $val['fee'];
    //     //对支付状态的处理
    //     if($val['status'] == 0){
    //         $val['status_type'] = '正在审核';
    //     } elseif($val['status'] == 1){
    //         $val['status_type'] = '正在处理';
    //     } elseif($val['status'] == 2){
    //          $val['status_type'] = '已完成';
    //     } elseif($val['status'] == 3){
    //         $val['status_type'] = '已取消  ';
    //     } 
        

    //     //手机号和邮箱合起来展示
    //     if($val['mobile'] == ''){
    //         $val['user_account'] = $val['email'];
    //     }elseif($val['email'] == ''){
    //         $val['user_account'] = $val['mobile'];
    //     }

    //     }
    //     return $list;
    // }


    // //提现列表总数
    // public function withdraw_list_count()
    // {
    //     $this->load->model('Account_capital_withdraw_model');
    //     $res = $this->Account_capital_withdraw_model->withdraw_list_count();
    //     return $res;
    // }


    /**
     * 提现记录的条数
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $name       [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    // public function withdraw_list_count($name,$start_time,$end_time,$site_id,$status){
    //     $this->db->from('b_account_capital_withdraw_log')
    //              ->join('user','user.id=b_account_capital_withdraw_log.user_id','left');

    //     if(!empty($name)){
    //         // if('user.mobile' == ''){
    //         // $object =$this->db->where('user.email =',$name);
    //         // }elseif('user.email' == ''){
    //         $object =$this->db->where('user.mobile =',$name);
    //         //}
    //     }

        
    //     if($status != 'all'){
    //         $object =$this->db->where('b_account_capital_withdraw_log.status =',$status);
    //     }
    //     if(!empty($start_time)){
    //         $this->db->where('b_account_capital_withdraw_log.pay_time >=',$start_time);
    //     }
    //     if(!empty($end_time)){
    //         $this->db->where('b_account_capital_withdraw_log.pay_time <',$end_time);
    //     }
    //     if(!empty($site_id)){
    //         $this->db->where('b_account_capital_withdraw_log.site_id =',$site_id);
    //     }
    //     return $this->db->count_all_results();
    // }

    //提现详情页
    public function withdraw_details($id)
    {
        $this->load->model('Account_capital_withdraw_model');
        $withdraw_details = array();
        $withdraw_details = $this->Account_capital_withdraw_model->withdraw_details($id);
        if(!empty($withdraw_details)){
            foreach ($withdraw_details as $key => &$value) {
                $value['apply_time'] = date('Y-m-d H:i:s',$value['apply_time']);    //申请时间
                $value['pay_time'] = date('Y-m-d H:i:s',$value['pay_time']);    //付款时间
                $value['account_amount'] = Number_format($value['amount'] - $value['fee'],2,'.','');  //到账金额
               
                if($value['status'] == 0){
                    $value['status'] = '提交';
                } elseif($value['status'] == 1){
                    $value['status'] = '提现中';
                } elseif($value['status'] == 2){
                    $value['status'] = '提现成功';
                } elseif($value['status'] == 3){
                    $value['status'] = '提现失败';
                } elseif($value['status'] == 4){
                    $value['status'] = '已取消';
                }

                if($value['withdraw_type'] == 0){
                    $value['withdraw_type'] = 'paypal';
                } elseif($value['withdraw_type'] == 1){
                    $value['withdraw_type'] = '支付宝';
                } elseif($value['withdraw_type'] == 2){
                    $value['withdraw_type'] = '银行卡';
                } 


                //手机号和邮箱合起来展示
                if($value['mobile'] == ''){
                  $value['user_account'] = $value['email'];
                }elseif($value['email'] == ''){
                  $value['user_account'] = $value['mobile'];
                }
            }
        }
        return $withdraw_details;
    }


    //提现初次审核（1：通过，3：拒绝）
    public function withdraw_verify($id,$status)
    {
        $detail = $this->Account_capital_withdraw_model->withdraw_details($id);
        $amount = $detail[0]['amount'];
        $user_id = $detail[0]['user_id'];
        $site_id = get_user_site_id($user_id);
        $fee = $detail[0]['fee'];
        $this->db->trans_start();
        if($status == 3){
            $result = $this->User_model->capital_unfreeze_back_account($user_id,$amount);    //解除冻结资金并还原可用额度

            $title = lang('catital_fail'); //消息标题
            $time = date('Y-m-d H:i:s',time());
            $text = lang('catital_fail_text1').$amount.lang('catital_fail_text2'); //消息内容
            send_notification($user_id,$title,$text,get_user_site_id($user_id));
            //发短信或邮箱通知
            $replacement = array(
                'url' => get_site_domain($site_id)
            );//要替换的短信内容
            send_msg($user_id,$replacement,'withdraw_no');


        }
        $result = $this->Account_capital_withdraw_model->withdraw_verify($id,$status);  
        $this->db->trans_complete();      
        return $result;
    }

    //提现再次审核
    public function withdraw_sure_verify($id,$status)
    {
        $detail = $this->Account_capital_withdraw_model->withdraw_details($id);
        $amount = $detail[0]['amount'];
        $user_id = $detail[0]['user_id'];
        $fee = $detail[0]['fee'];
        $site_id = get_user_site_id($user_id);
        $this->db->trans_start();
        if($status == 3)
        {
            $result = $this->User_model->capital_unfreeze_back_account($user_id,$amount);    //解除冻结资金并还原可用额度
            $result = $this->Account_capital_withdraw_model->withdraw_verify($id,$status);
            //发短信或邮箱通知
            $replacement = array(
                'url' => get_site_domain($site_id)
            );//要替换的短信内容
            send_msg($user_id,$replacement,'withdraw_no');
        }
        else
        {
            $result = $this->User_model->capital_unfreeze($user_id,$amount);    //更改冻结资金  
            $result = $this->User_capital_model->add_capital_detail($id,$user_id,$amount,$fee,$status);    //新增资金明细记录 
            $result = $this->Security_bulid_hash_model->add_baoquan_detail($user_id,$id);    //新增保全明细记录
            $result = $this->Account_capital_withdraw_model->withdraw_verify($id,$status);    //更改状态 
            $title = lang('catital_success'); //消息标题
            $time = date('Y-m-d H:i:s',time());
            $text = lang('catital_success_text1').$amount.lang('catital_success_text2'); //消息内容
            send_notification($user_id,$title,$text,get_user_site_id($user_id));

            //发短信或邮箱通知
            $replacement = array(
                'url' => get_site_domain($site_id)
            );//要替换的短信内容
            send_msg($user_id,$replacement,'withdraw_yes');
        }

        $this->db->trans_complete();

        return $result;
    }



    // //资金流水列表
    // public function capital_list($page = 1,$limit = 10){
    //     $this->load->model('User_capital_model');
    //     $offest = ($page -1) * $limit;
    //     $capital_list = array();
    //     $capital_list = $this->User_capital_model->capital_list($offest,$limit);
    //     if(!empty($capital_list)){
    //         foreach ($capital_list as $key => &$value) {
    //             $value['create_time'] = date('Y-m-d H:i:s',$value['create_time']); 
    //             if($value['status'] == 0){
    //                 $value['status_type'] = '未处理';
    //             } elseif($value['status'] == 1){
    //                 $value['status_type'] = '处理中';
    //             } elseif($value['status'] == 2){
    //                 $value['status_type'] = '成功';
    //             } elseif($value['status'] == 3){
    //                 $value['status_type'] = '失败';
    //             } 
    //         }
    //     }
    //     return $capital_list;
    // }


    /**
     * 资金流水列表加搜索
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      每页条数
     * @param    [type]       $name       关键词
     * @param    [type]       $start_time 开始时间
     * @param    [type]       $end_time   结束时间
     * @param    [type]       $site_id    站点id
     * @return   [type]                   [description]
     */
    public function capital_list($offset,$limit,$name,$start_time,$end_time,$site_id,$status){
        $object = $this->db->select("b_user_capital.id,site.name as site_name,user.mobile,user.email,user.truename,b_user_capital.create_time,b_user_capital.type,b_user_capital.amount,b_user_capital.value,b_user_capital.status")
            ->from('b_user_capital')
            ->join('site','site.id=b_user_capital.site_id','left')
            ->join('user','user.id=b_user_capital.user_id','left');

        if(!empty($name)){
            // if('user.mobile' == ''){
            // $object =$this->db->where('user.email =',$name);
            // }elseif('user.email' == ''){
            $object =$this->db->where('user.mobile =',$name);
            //}
        }
        
        if($status != 'all'){
            $object =$this->db->where('b_user_capital.status =',$status);
        }
        if(!empty($start_time)){
            $object =$this->db->where('b_user_capital.create_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('b_user_capital.create_time <',$end_time);
        }
        if(!empty($site_id)){
            $object =$this->db->where('b_user_capital.site_id =',$site_id);
        }

        $list = $object->limit($limit,$offset)->order_by('create_time','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;

        foreach ($list as &$val){
        //对时间戳的处理    
        $val['create_time'] = date('Y-m-d H:i',$val['create_time']);
        //对支付状态的处理
        if($val['status'] == 0){
            $val['status_type'] = '未处理';
        } elseif($val['status'] == 1){
            $val['status_type'] = '处理中';
        } elseif($val['status'] == 2){
             $val['status_type'] = '成功';
        } elseif($val['status'] == 3){
            $val['status_type'] = '失败';
        } 
        
        //对支付类型的处理
        if($val['type'] == 1){
            $val['pay_type'] = '充值';
        } elseif($val['type'] == 2){
            $val['pay_type'] = '提现';
        } elseif($val['type'] == 3){
             $val['pay_type'] = '矿机购买';
        } elseif($val['type'] == 4){
            $val['pay_type'] = '算力租用';
        } elseif($val['type'] == 5){
            $val['pay_type'] = '购买实体矿机';
        } 

        //手机号和邮箱合起来展示
        if($val['mobile'] == ''){
            $val['user_account'] = $val['email'];
        }elseif($val['email'] == ''){
            $val['user_account'] = $val['mobile'];
        }
       
        }
        return $list;
    }

    // //资金流水列表总数
    // public function capital_list_count()
    // {
    //     $this->load->model('User_capital_model');
    //     $res = $this->User_capital_model->capital_list_count();
    //     return $res;
    // }


    /**
     * 资金流水记录的条数
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $name       [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function capital_list_count($name,$start_time,$end_time,$site_id,$status){
        $this->db->from('b_user_capital')
                 ->join('user','user.id=b_user_capital.user_id','left');

        if(!empty($name)){
            //if($val['mobile'] == ''){
            //$object =$this->db->where('user.email =',$name);
            //}elseif($val['email'] == ''){
             $object =$this->db->where('user.mobile =',$name);
            //}
        }
        if($status != 'all'){
            $object =$this->db->where('b_user_capital.status =',$status);
        }
        if(!empty($start_time)){
            $this->db->where('b_user_capital.create_time >=',$start_time);
        }
        if(!empty($end_time)){
            $this->db->where('b_user_capital.create_time <',$end_time);
        }
        if(!empty($site_id)){
            $this->db->where('b_user_capital.site_id =',$site_id);
        }
        return $this->db->count_all_results();
    }






}
