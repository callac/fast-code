<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Identity_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Country_model');    
        $this->load->model('Zjys_user_model');    
    }  

    public function get_country_list($show=1,$deleted_at=null)
    {
        return $this->Country_model->get_list($show,$deleted_at);
    }

    public function user_recomend_list($offset,$limit,$site_id,$uid,$top_uid,$iiid,$user_identity_auth,$start_time,$end_time)
    {
        $object = $this->db->select("a.user_id as iiid,user_recommends.recommend_user_id,user_recommends.user_id,users.created_at,users.register_ip,users.last_login,users.last_ip,users.email,users.phone,users.user_identity_auth,users.identity_success_time,user_vips.vip_level,b_site.name as site_name,users.recommend_code")
        ->join('users','user_recommends.recommend_user_id=users.id','left')
        ->join('user_vips','user_vips.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->join('user_recommends as a','a.recommend_user_id=user_recommends.user_id','left')
        ->from('user_recommends');
        $object =$this->db->where('user_recommends.deleted_at is null');

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('users.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.created_at <',$end_time);
        }
        
        if(!empty($uid)){
            $object =$this->db->where('user_recommends.recommend_user_id =',$uid);
        }
        if(!empty($top_uid)){
            $object =$this->db->where('user_recommends.user_id =',$top_uid);
        }

        if(!empty($iiid)){
            $object =$this->db->where('a.user_id =',$iiid);
        }

        if(!empty($user_identity_auth)){
            $object =$this->db->where('users.user_identity_auth =',$user_identity_auth);
        }
        
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        foreach ($list as &$value) {
            //获取最后充值时间、最后交易时间（成交时间）
            $value['last_recharge_time'] = $this->get_user_last_recharge_time($value['recommend_user_id']);
            $value['last_trade_time'] = $this->get_user_last_trade_time($value['recommend_user_id']);
        }
        return $list;
    }

    public function get_user_last_recharge_time($user_id)
    {
        
        $db = $this->load->database('default',true);
        $sql = 'SELECT created_at from user_recharge_logs WHERE user_id ='.$user_id.' and status =1 ORDER BY id desc limit 1';
        $result = object_to_array($db->query($sql)->result());
        if(is_array($result) && !empty($result))
        {
            return $result[0]['created_at'];
        }else{
            return '';
        }
        
    }

    public function get_user_last_trade_time($user_id)
    {
        $DB = $this->load->database('trade_history',true);
        $id_index = $user_id%100;
        $sql = 'select time from user_deal_history_'.$id_index.' where user_id='.$user_id.' order by id desc limit 1';
        $result = object_to_array($DB->query($sql)->result());
        if(is_array($result) && !empty($result))
        {
            return get_microtime_format($result[0]['time']);
        }else{
            return '';
        }
    }

    public function user_recomend_list_count($site_id,$uid,$top_uid,$iiid,$user_identity_auth,$start_time,$end_time)
    {
        $object = $this->db->select("a.user_id as iiid,user_recommends.recommend_user_id,user_recommends.user_id,users.created_at,users.register_ip,users.last_login,users.last_ip,users.email,users.phone,users.user_identity_auth,user_vips.vip_level,b_site.name as site_name,users.recommend_code")
        ->join('users','user_recommends.recommend_user_id=users.id','left')
        ->join('user_vips','user_vips.user_id=users.id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->join('user_recommends as a','a.recommend_user_id=user_recommends.user_id','left')
        ->from('user_recommends');
        $object =$this->db->where('user_recommends.deleted_at is null');

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);

        if(!empty($start_time)){
            $object =$this->db->where('users.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.created_at <',$end_time);
        }
        
        if(!empty($uid)){
            $object =$this->db->where('user_recommends.recommend_user_id =',$uid);
        }
        if(!empty($top_uid)){
            $object =$this->db->where('user_recommends.user_id =',$top_uid);
        }

        if(!empty($iiid)){
            $object =$this->db->where('a.user_id =',$iiid);
        }
        if(!empty($user_identity_auth)){
            $object =$this->db->where('users.user_identity_auth =',$user_identity_auth);
        }

        return $this->db->count_all_results();
    }

    //重置用户登录密码，资金密码
    public function reset_password($status,$user_id)
    {
        // $password = $this->config->item('INITIAL_PASSWORD');
        $password = '$2a$04$AXAxbErODKEBQ.Hekf44XOQ3/x3Lwigb1pcf0F18kDHhuEfhUzMtq';
        return $this->Country_model->reset_password($status,$password,$user_id);
    }



}
