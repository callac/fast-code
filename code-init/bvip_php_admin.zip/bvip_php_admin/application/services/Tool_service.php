<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tool_service extends MY_Service {

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * 比特币实时成交价格缓存
	 * @return [type] [description]
	 */
	public function ticker()
	{
		$ticker_sell = 0;
		$ticket_json = APPPATH.'cache/ticket.json';
		// if(file_exists($ticket_json))
		// {
		// 	$ticket_content = file_get_contents($ticket_json);
		// 	$ticket_arr = json_decode($ticket_content,true);
		// 	if($ticket_arr['now'] + 21600 < time()){
		// 		//超过缓存5分钟
		// 		$this->load->library('service/okcoin_service');
		// 		$ticket_output = $this->okcoin_service->getTicker();
		// 		$ticket = json_decode(json_encode($ticket_output),true);
		// 		$ticker_sell = $ticket['ticker']['sell'];
		// 		$cache_arr = array('sell_buy'=>$ticker_sell,'now'=>time());
		// 		file_put_contents($ticket_json, json_encode($cache_arr));
		// 	}else{
		// 		$ticker_sell = $ticket_arr['sell_buy'];
		// 	}
		// }else{
		// 	//不存在缓存
		// 	$this->load->library('service/okcoin_service');
		// 	$ticket_output = $this->okcoin_service->getTicker();
		// 	$ticket = json_decode(json_encode($ticket_output),true);
		// 	$ticker_sell = $ticket['ticker']['sell'];
		// 	$cache_arr = array('sell_buy'=>$ticker_sell,'now'=>time());
		// 	file_put_contents($ticket_json, json_encode($cache_arr));
		// }

		if(file_exists($ticket_json)){
			$income_content = file_get_contents($ticket_json);
			$btcfans = json_decode($income_content,true);
			if($btcfans['now'] + 3600*6 < time() || empty($btcfans)){
				// 超过缓存6小时
				$this->load->library('curl');
				$this->curl->init();
				$btcfans_output=$this->curl->get('http://mining.btcfans.com/difficulty.php?act=json');
				$btcfans = json_decode($btcfans_output,true);
				$btcfans['now'] = time();
				file_put_contents($ticket_json, json_encode($btcfans));
				
				$ticker_sell = $btcfans['price'][0]['lastPriceCNY'];
			}else{
				
				$ticker_sell = $btcfans['price'][0]['lastPriceCNY'];

			}
		}else{
			//不存在缓存
			$this->load->library('curl');
			$this->curl->init();
			$btcfans_output=$this->curl->get('http://mining.btcfans.com/difficulty.php?act=json');
			$btcfans = json_decode($btcfans_output,true);
			$btcfans['now'] = time();
			file_put_contents($ticket_json, json_encode($btcfans));
			
			$ticker_sell = $btcfans['price'][0]['lastPriceCNY'];

		}

		return $this->result($ticker_sell);
	}

	/**
	 * okcoin数据获取
	 * @return [type] [description]
	 */
	public function okcoin_common_data(){
		$this->load->library('curl');
		$this->curl->init();
		$okcoin_output = $this->curl->get('https://www.1hash.com/user/api?apikey=0887e3d9a59f345e8b274859');
		$res = json_decode($okcoin_output, true);

		// 获取总的算力规模
		$this->load->model('Product_hash_model');
		$time = time();

		$product_res = $this->Product_hash_model->get_selling_product();//获取最新算力宝 当前在售算力规模  base_id是5，商品状态不为9，且商品开售日期大于当前日期减一天

		$total_amount = 0.00;
		$bitcoin = 0.00;
		foreach ($product_res as $key => $value) {
			$t = $time - $value['sell_start_time'];

			if( $t >= 86400 ){
				$total_amount += $value['total_amount'];
			}else{
				$bitcoin = $res['user']['payout_history'][0]['payout_amount'];
			}
		}

		if( $bitcoin <= 0 ){
			// $bitcoin = $res['user']['last_24h_reward']['bitcoin'];
			$bitcoin = $res['user']['payout_history'][0]['payout_amount'];
		}

		$data = array(
			'bitcoin' => $bitcoin,
			'total_amount' => $total_amount - 2700 - 540 + 720,
			);
		return $this->result($data);
	}

	/**
	 * btc123数据抓取
	 * @return [type] [description]
	 */
	public function btc123_common_data()
	{
		$income_per_byte = 0;
		$income_per_byte_json = APPPATH.'cache/income_per.json';
		if(file_exists($income_per_byte_json)){
			$income_content = file_get_contents($income_per_byte_json);
			$income_arr = json_decode($income_content,true);
			if($income_arr['now'] + 3600*6 < time() || empty($income_arr['datas'])){
				// 超过缓存6小时
				$this->load->library('curl');
				$this->curl->init();
				$btc123_output=$this->curl->get('https://www.btc123.com/getCommonData');
				$btc123 = json_decode($btc123_output,true);
				$btc123['now'] = time();
				file_put_contents($income_per_byte_json, json_encode($btc123));
				$income_per_byte = $btc123['datas']['footerData']['CNY_IncomePerTerabyte'];
			}else{
				$income_per_byte = $income_arr['datas']['footerData']['CNY_IncomePerTerabyte'];
			}
		}else{
			//不存在缓存
			$this->load->library('curl');
			$this->curl->init();
			$btc123_output=$this->curl->get('https://www.btc123.com/getCommonData');
			$btc123 = json_decode($btc123_output,true);
			$btc123['now'] = time();
			file_put_contents($income_per_byte_json, json_encode($btc123));
			$income_per_byte = $btc123['datas']['footerData']['CNY_IncomePerTerabyte'];
		}
		return $this->result($income_per_byte);
	}

	/**
	 * mining.btcfans.com数据抓取
	 * @return [type] [description]
	 */
	public function btcfans_common_data()
	{
		$common_data = array();
		$btc_difficulty_byte_json = APPPATH.'cache/btc_difficulty.json';
		if(file_exists($btc_difficulty_byte_json)){
			$income_content = file_get_contents($btc_difficulty_byte_json);
			$btcfans = json_decode($income_content,true);
			if($btcfans['now'] + 3600*6 < time() || empty($btcfans)){
				// 超过缓存6小时
				$this->load->library('curl');
				$this->curl->init();
				$btcfans_output=$this->curl->get('http://mining.btcfans.com/difficulty.php?act=json');
				$new_btcfans = json_decode($btcfans_output,true);
				if(empty($new_btcfans)){
					$btcfans['now'] = time();
					file_put_contents($btc_difficulty_byte_json, json_encode($btcfans));
					$common_data['hashrate'] = $btcfans['base']['hashRate'];#全网算力
					$common_data['difficulty'] = $btcfans['base']['difficulty'];#当前难度
					$common_data['leavetime'] = $btcfans['base']['leavetime'];#难度调整计时
					$common_data['btc_price'] = $btcfans['price'][0]['lastPriceCNY'];
					$common_data['usd_price'] = $btcfans['price'][0]['lastPrice'];
					$difficulty = str_replace(',','',$common_data['difficulty']);
					$common_data['btc_output'] = sprintf("%.5f",1000/($difficulty*7.158*0.001)*1800);
				}else{
					$new_btcfans['now'] = time();
					file_put_contents($btc_difficulty_byte_json, json_encode($new_btcfans));
					$common_data['hashrate'] = $new_btcfans['base']['hashRate'];#全网算力
					$common_data['difficulty'] = $new_btcfans['base']['difficulty'];#当前难度
					$common_data['leavetime'] = $new_btcfans['base']['leavetime'];#难度调整计时
					$common_data['btc_price'] = $new_btcfans['price'][0]['lastPriceCNY'];
					$common_data['usd_price'] = $new_btcfans['price'][0]['lastPrice'];
					$difficulty = str_replace(',','',$common_data['difficulty']);
					$common_data['btc_output'] = sprintf("%.5f",1000/($difficulty*7.158*0.001)*1800);
				}
					
			}else{
				
				$common_data['hashrate'] = $btcfans['base']['hashRate'];#全网算力
				$common_data['difficulty'] = $btcfans['base']['difficulty'];#当前难度
				$common_data['leavetime'] = $btcfans['base']['leavetime'];#难度调整计时
				$common_data['btc_price'] = $btcfans['price'][0]['lastPriceCNY'];
				$common_data['usd_price'] = $btcfans['price'][0]['lastPrice'];
				$difficulty = str_replace(',','',$common_data['difficulty']);
				$common_data['btc_output'] = sprintf("%.5f",1000/($difficulty*7.158*0.001)*1800);
				
			}
		}else{
			//不存在缓存
			$this->load->library('curl');
			$this->curl->init();
			$btcfans_output=$this->curl->get('http://mining.btcfans.com/difficulty.php?act=json');
			$btcfans = json_decode($btcfans_output,true);
			$btcfans['now'] = time();
			
			file_put_contents($btc_difficulty_byte_json, json_encode($btcfans));
			$common_data['hashrate'] = $btcfans['base']['hashRate'];#全网算力
			$common_data['difficulty'] = $btcfans['base']['difficulty'];#当前难度
			$common_data['leavetime'] = $btcfans['base']['leavetime'];#难度调整计时
			$common_data['btc_price'] = $btcfans['price'][0]['lastPriceCNY'];
			$common_data['usd_price'] = $btcfans['price'][0]['lastPrice'];
			$difficulty = str_replace(',','',$common_data['difficulty']);
			$common_data['btc_output'] = sprintf("%.5f",1000/($difficulty*7.158*0.001)*1800);
			
		}
		$currency = get_site_info()['paypal_currency'];
        $currency = !empty($currency) ? $currency : 'CNY';//默认人民币
		$juhe_json  = APPPATH.'cache/'.$currency.'juhe.json';
        if(file_exists($juhe_json)){
            $juhe_content = file_get_contents($juhe_json);
            $juhe_content = json_decode($juhe_content,true);
            if($juhe_content['now'] + 3600*24 < time() || empty($juhe_content)){
                //汇率实时变动较小缓存24小时
                $new_juhe['juhe'] = juhe_helper::juhe_from_to('1','USD',$currency);
                if(!empty($new_juhe)){
                    $new_juhe['now'] =time();
                    file_put_contents($juhe_json, json_encode($new_juhe));
                    $juhe_rate = $new_juhe['juhe'];
                }else{
                    $juhe_content['now'] = time();
                    file_put_contents($juhe_json, json_encode($juhe_content));
                    $juhe_rate = $juhe_content['juhe'];
                }

            }else{
                $juhe_rate = $juhe_content['juhe'];
            }
        }else{
            $juhe['juhe'] = juhe_helper::juhe_from_to('1','USD',$currency);
            $juhe['now'] =time();
            file_put_contents($juhe_json, json_encode($juhe));
            $juhe_rate =  $juhe['juhe'];
        }
         $common_data['price'] = $common_data['usd_price'] * $juhe_rate['balance']*$common_data['btc_output']; //实时每T收益
         $common_data['now_price'] = round($common_data['usd_price'] * $juhe_rate['balance'],2);//实时币价
         $data['data'] = $common_data;
		return $data;
	}


	/**
	 * 爬虫抓取彩云网数据
	 * @return [type] [description]
	 */
	public function caiyun_api()
	{
		$caiyun_data_json = APPPATH.'cache/caiyun.json';
		if(file_exists($caiyun_data_json)){
			$output_data_json = file_get_contents($caiyun_data_json);
			$output_data = json_decode($output_data_json,true);
			if($output_data['now'] + 3600*6 < time() || empty($output_data['list'])){
				//超过缓存6小时
				$this->load->library('curl');
				$this->curl->init();
				//交易数据
				$home_data_output = $this->curl->get('https://www.cybtc.net/api/home');	
				$home_data = json_decode($home_data_output,true);
				if(!empty($home_data)){
					//btc_info
					$btc_data_output = $this->curl->get('https://www.cybtc.net/api/dig/data/btc/blockchain/info');	
					$btc_data = json_decode($btc_data_output,true);
					$btc_qwsl = round($btc_data['difficulty'] * 7.158 * 0.001 / 1000000,0);
					$btc_output = $btc_data['difficulty'] > 0.1 ? round(1000/($btc_data['difficulty']*7.158*0.001)*1800,5) : 0;
					$btc_income = round($home_data['btc']['cny'] * $btc_output,2);
					$data['BTC'] = array('price'=>$home_data['btc']['cny'],'qwsl'=>$btc_qwsl,'unit'=>'(PH/S)','output'=>sprintf("%.5f",$btc_output).' ฿/1T/天（￥'.$btc_income.')','market_cap_usd'=>$home_data['btc']['market_cap_usd'],'name'=>'BTC','chinese_name'=>'比特币','difficulty'=>$btc_data['difficulty']);
					
					//达世币
					$dash_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/cryptoid/dash');	
					$dash_data = json_decode($dash_data_output,true);
					$dash_qwsl = round($dash_data ,2);
					$dash_block = $dash_data*1000;
					$dash_output = $dash_block > 0 ? round(100/$dash_block*576*1.80,5) : 0;
					$dash_income = round($home_data['dash']['cny'] * $dash_output,2);
					$data['DASH'] = array('price'=>$home_data['dash']['cny'],'qwsl'=>$dash_qwsl,'unit'=>'(GH/S)','output'=>sprintf("%.5f",$dash_output*10).' dash/1G/天（￥'.sprintf("%.2f",$dash_income * 10).')','market_cap_usd'=>$home_data['dash']['market_cap_usd'],'name'=>'DASH','chinese_name'=>'达世币','difficulty'=>$dash_block);

					//莱特币
					$ltc_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/cryptoid/ltc');	
					$ltc_data = json_decode($ltc_data_output,true);
					$ltc_qwsl = round($ltc_data ,2);
					$ltc_block = $ltc_data*1000;
					$ltc_output = $ltc_block > 0 ? round(100/$ltc_block*14400,5) : 0;
					$ltc_income = round($home_data['ltc']['cny'] * $ltc_output,2);
					$data['LTC'] = array('price'=>$home_data['ltc']['cny'],'qwsl'=>$ltc_qwsl,'unit'=>'(GH/S)','output'=>sprintf("%.5f",$ltc_output/10).' ltc/10M/天（￥'.sprintf("%.2f",$ltc_income / 10).')','market_cap_usd'=>$home_data['ltc']['market_cap_usd'],'name'=>'LTC','chinese_name'=>'莱特币','difficulty'=>$ltc_block);

					//以太经典
					$etc_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/etcchain/etc');	
					$etc_data = json_decode($etc_data_output,true);
					$etc_qwsl = round($etc_data['hashrate'] ,2);
					$etc_output = $etc_data['hashrate'] > 0.1 ? round(0.1/$etc_data['hashrate']*24000,5) : 0;
					$etc_income = round($home_data['etc']['cny'] * $etc_output,2);
					$data['ETC'] = array('price'=>$home_data['etc']['cny'],'qwsl'=>$etc_qwsl,'unit'=>'(GH/S)','output'=>sprintf("%.5f",$etc_output/10).' etc/10M/天（￥'.sprintf("%.2f",$etc_income / 10).')','market_cap_usd'=>$home_data['etc']['market_cap_usd'],'name'=>'ETC','chinese_name'=>'以太经典','difficulty'=>$etc_data['hashrate']);

					//ZCash
					$zcash_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/zcha/zcash');	
					$zcash_data = json_decode($zcash_data_output,true);
					$zcash_qwsl = round($zcash_data['hashrate']/1000,2);
					$zcash_output = $zcash_data['hashrate'] > 0.1 ? round(1000/($zcash_data['hashrate'])*5760,5) : 0;
					$zcash_income = round($home_data['zcash']['cny'] * $zcash_output,2);
					$data['ZEC'] = array('price'=>$home_data['zcash']['cny'],'qwsl'=>$zcash_qwsl,'unit'=>'(KSol/S)','output'=>sprintf("%.5f",$zcash_output).' zcash/1K/天（￥'.$zcash_income.')','market_cap_usd'=>$home_data['zcash']['market_cap_usd'],'name'=>'ZEC','chinese_name'=>'ZCash','difficulty'=>$zcash_data['hashrate']);

					//ETH
					$eth_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/etcchain/eth');	
					$eth_data = json_decode($eth_data_output,true);
					$eth_qwsl = round($eth_data['hashrate'] ,2);
					$eth_output = $eth_data['hashrate'] > 0.1 ? round(0.1/$eth_data['hashrate']*20743,5) : 0;
					$eth_income = round($home_data['eth']['cny'] * $eth_output,2);
					$data['ETH'] = array('price'=>$home_data['eth']['cny'],'qwsl'=>$eth_qwsl,'unit'=>'(GH/S)','output'=>sprintf("%.5f",$eth_output/10).' eth/10M/天（￥'.sprintf("%.2f",$eth_income / 10).')','market_cap_usd'=>$home_data['eth']['market_cap_usd'],'name'=>'ETH','chinese_name'=>'以太坊','difficulty'=>$eth_data['hashrate']);

					$out_put = $data;
					$arr['now'] = time();
					$arr['list'] = $data;
					file_put_contents($caiyun_data_json, json_encode($arr));
				}
			}else{
				$out_put = $output_data['list'];
			}
		}else{
			$this->load->library('curl');
			$this->curl->init();
			//交易数据
			$home_data_output = $this->curl->get('https://www.cybtc.net/api/home');	
			$home_data = json_decode($home_data_output,true);

			//btc_info
			$btc_data_output = $this->curl->get('https://www.cybtc.net/api/dig/data/btc/blockchain/info');	
			$btc_data = json_decode($btc_data_output,true);
			$btc_qwsl = round($btc_data['difficulty'] * 7.158 * 0.001 / 1000000,0);
			$btc_output = $btc_data['difficulty'] > 0.1 ? round(1000/($btc_data['difficulty']*7.158*0.001)*1800,5) : 0;
			$btc_income = round($home_data['btc']['cny'] * $btc_output,2);
			$data['BTC'] = array('price'=>$home_data['btc']['cny'],'qwsl'=>$btc_qwsl,'unit'=>'(PH/S)','output'=>sprintf("%.5f",$btc_output).' ฿/1T/天（￥'.$btc_income.')','market_cap_usd'=>$home_data['btc']['market_cap_usd'],'name'=>'BTC','chinese_name'=>'比特币','difficulty'=>$btc_data['difficulty']);
			
			//达世币
			$dash_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/cryptoid/dash');	
			$dash_data = json_decode($dash_data_output,true);
			$dash_qwsl = round($dash_data ,2);
			$dash_block = $dash_data*1000;
			$dash_output = round(100/$dash_block*576*1.80,5);
			$dash_income = round($home_data['dash']['cny'] * $dash_output,2);
			$data['DASH'] = array('price'=>$home_data['dash']['cny'],'qwsl'=>$dash_qwsl,'unit'=>'(GH/S)','output'=>sprintf("%.5f",$dash_output*10).' dash/1G/天（￥'.sprintf("%.2f",$dash_income * 10).')','market_cap_usd'=>$home_data['dash']['market_cap_usd'],'name'=>'DASH','chinese_name'=>'达世币','difficulty'=>$dash_block);

			//莱特币
			$ltc_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/cryptoid/ltc');	
			$ltc_data = json_decode($ltc_data_output,true);
			$ltc_qwsl = round($ltc_data ,2);
			$ltc_block = $ltc_data*1000;
			$ltc_output = round(100/$ltc_block*14400,5);
			$ltc_income = round($home_data['ltc']['cny'] * $ltc_output,2);
			$data['LTC'] = array('price'=>$home_data['ltc']['cny'],'qwsl'=>$ltc_qwsl,'unit'=>'(GH/S)','output'=>sprintf("%.5f",$ltc_output/10).' ltc/10M/天（￥'.sprintf("%.2f",$ltc_income / 10).')','market_cap_usd'=>$home_data['ltc']['market_cap_usd'],'name'=>'LTC','chinese_name'=>'莱特币','difficulty'=>$ltc_block);

			//以太经典
			$etc_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/etcchain/etc');	
			$etc_data = json_decode($etc_data_output,true);
			$etc_qwsl = round($etc_data['hashrate'] ,2);
			$etc_output = $etc_data['hashrate'] > 0.1 ? round(0.1/$etc_data['hashrate']*24000,5) : 0;
			$etc_income = round($home_data['etc']['cny'] * $etc_output,2);
			$data['ETC'] = array('price'=>$home_data['etc']['cny'],'qwsl'=>$etc_qwsl,'unit'=>'(GH/S)','output'=>sprintf("%.5f",$etc_output/10).' etc/10M/天（￥'.sprintf("%.2f",$etc_income / 10).')','market_cap_usd'=>$home_data['etc']['market_cap_usd'],'name'=>'ETC','chinese_name'=>'以太经典','difficulty'=>$etc_data['hashrate']);

			
			//ZCash
			$zcash_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/zcha/zcash');	
			$zcash_data = json_decode($zcash_data_output,true);
			$zcash_qwsl = round($zcash_data['hashrate']/1000,2);
			$zcash_output = $zcash_data['hashrate'] > 0.1 ? round(1000/($zcash_data['hashrate'])*5760,5) : 0;
			$zcash_income = round($home_data['zcash']['cny'] * $zcash_output,2);
			$data['ZEC'] = array('price'=>$home_data['zcash']['cny'],'qwsl'=>$zcash_qwsl,'unit'=>'(KSol/S)','output'=>sprintf("%.5f",$zcash_output).' zcash/1K/天（￥'.$zcash_income.')','market_cap_usd'=>$home_data['zcash']['market_cap_usd'],'name'=>'ZEC','chinese_name'=>'ZCash','difficulty'=>$zcash_data['hashrate']);

			//ETH
			$eth_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/etcchain/eth');	
			$eth_data = json_decode($eth_data_output,true);
			$eth_qwsl = round($eth_data['hashrate'] ,2);
			$eth_output = $eth_data['hashrate'] > 0.1 ? round(0.1/$eth_data['hashrate']*20743,5) : 0;
			$eth_income = round($home_data['eth']['cny'] * $eth_output,2);
			$data['ETH'] = array('price'=>$home_data['eth']['cny'],'qwsl'=>$eth_qwsl,'unit'=>'(GH/S)','output'=>sprintf("%.5f",$eth_output/10).' eth/10M/天（￥'.sprintf("%.2f",$eth_income / 10).')','market_cap_usd'=>$home_data['eth']['market_cap_usd'],'name'=>'ETH','chinese_name'=>'以太坊','difficulty'=>$eth_data['hashrate']);

			$out_put = $data;
			$arr['now'] = time();
			$arr['list'] = $data;
			file_put_contents($caiyun_data_json, json_encode($arr));	
		}
		return $out_put;
	
	}

	/**
	 * 矿池数据处理
	 * @return [type] [description]
	 */
	public function mining_pool_api()
	{
		$mining_pool_out_json =APPPATH.'cache/mining_pool.json';
		$this->load->library('curl');
		$this->curl->init();
		if(file_exists($mining_pool_out_json)){
			$output_data_json = file_get_contents($mining_pool_out_json);
			$output_data = json_decode($output_data_json,true);
			if($output_data['now'] + 3600*1000000 < time() || empty($output_data['list'])){
				//超过缓存6小时				
				//交易数据
				$mining_out_data = $this->curl->get('https://pool.btcc.com/pool/api?api_key=54afdd675e834350b5f52e4550ba2206');	

				$mining_out = json_decode($mining_out_data,true);
				
				foreach ($mining_out['data']['diff_history'] as &$v) {
					$flag[] = $v['timestamp'];
					$temp = explode(' - ',$v['difficulty']);
					$v['difficulty'] = str_replace(',','',$temp[0]);
					$temp1 = explode(' ',$v['avg_network_hashrate']);
					if($temp1[1] == 'EH/s'){
						$temp1[0] = $temp1[0] * 1000;
						$temp1[1] = 'PH/s';
					}
					$v['avg_network_hashrate'] = $temp1;
					$v['timestamp'] = date("Y-m-d",strtotime($v['timestamp']));
				}
				array_multisort($flag, SORT_DESC, $mining_out['data']['diff_history']);
				
				$arr = array('list'=>$mining_out,'now'=>time());
				file_put_contents($mining_pool_out_json, json_encode($arr));
			}else{
			    if(!$output_data['list']['data']['diff_history']){
                    $mining_out['list'] = null;
                }else{
                    foreach ($output_data['list']['data']['diff_history'] as &$v) {
                        $flag[] = $v['timestamp'];
                        $temp = explode(' - ',$v['difficulty']);
                        $v['difficulty'] = str_replace(',','',$temp[0]);
                        // $v['avg_network_hashrate'] = $v['avg_network_hashrate'];
                        if($v['avg_network_hashrate'][1] == 'EH/s'){
                            $v['avg_network_hashrate'][1] = 'PH/s';
                        }
                        $v['timestamp'] = date("Y-m-d",strtotime($v['timestamp']));
                    }
                    array_multisort($flag, SORT_DESC, $output_data['list']['data']['diff_history']);
                    $mining_out = $output_data['list'];
                }

			}
		}else{
			//交易数据
			$mining_out_data = $this->curl->get('https://pool.btcc.com/pool/api?api_key=54afdd675e834350b5f52e4550ba2206');
			$mining_out = json_decode($mining_out_data,true);

			foreach ($mining_out['data']['diff_history'] as &$v) {
				$flag[] = $v['timestamp'];
				$temp = explode(' - ',$v['difficulty']);
				$v['difficulty'] = str_replace(',','',$temp[0]);
				$temp1 = explode(' ',$v['avg_network_hashrate']);
				if($temp1[1] == 'EH/s'){
					$temp1[0] = $temp1[0] * 1000;
					$temp1[1] = 'PH/s';
				}
				$v['avg_network_hashrate'] = $temp1;
				$v['timestamp'] = date("Y-m-d",strtotime($v['timestamp']));
			}
			array_multisort($flag, SORT_DESC, $mining_out['data']['diff_history']);

			$arr = array('list'=>$mining_out,'now'=>time());

			file_put_contents($mining_pool_out_json, json_encode($arr));	
		}
		return $mining_out;
	
	}
	
	/**
	 * 省市区单条信息
	 * @param integer $region_id id
	 */
	public function region_info($args)
	{
		list($region_id) = $args;
		$this->load->model('Region_model');
		$region_id = (int)$region_id;
		$region = $this->Region_model->info($region_id);
		return $this->result($region);
	}

	/**
	 * 省市区列表信息
	 * @param  [type] $args [description]
	 * @return [type]       [description]
	 */
	public function region_get_list($args)
	{
		list($region_pid) = $args;
		$this->load->model('Region_model');
		$region_pid = (int)$region_pid;
		$region_list = $this->Region_model->get_list($region_pid);
		return $this->result($region_list);
	}

	/**
	 * 告警工具
	 * @param  string $alarm_name 告警标题
	 * @param string $alarm_content 告警详情
	 * @param string $event_id 事件id
	 * @param int $priority 告警级别 告警级别；提醒 1，警告 2，严重 3
	 * 
	 * @return [type]       [description]
	 */
	public function onealert($args){
		list($alarm_name,$alarm_content,$event,$priority) = $args;
		$this->load->library('one_alert');
		$this->one_alert->create_trigger_alert($alarm_name,$alarm_content,$event,$priority);
	}

	/**
	 * 快递物流
	 * @param  [type] $args [description]
	 * @return [type]       [description]
	 */
	public function kuaidi($args)
	{
		@list($com, $nu, $muti) = $args;
		$this->load->library('kuaidi');
		$result_arr = $this->kuaidi->run($com, $nu, $muti);
		return $this->result($result_arr);
	}

	public function platform_deal_detail($symbol,$uid,$start_time,$end_time,$offset,$limit)
    {
        if(isset($symbol) && !empty($symbol))   $where = " AND `market`='$symbol'";
        if(isset($uid) && !empty($uid)){
            $where1 = ' AND `user_id`='.$uid;
        }else{
            $where1 = ' AND 1=1';
        } 

        $ztreadonly = $this->load->database('zt_tradehistory_onlyread',true);
        $res = [];
        for ($i=0; $i <100 ; $i++) { 
            $sql = "select * from user_deal_history_".$i." where `time` > ".$start_time." AND `time` < ".$end_time.$where.$where1;
            // var_dump($sql);die;
            $object = object_to_array($ztreadonly->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $date = array_column($new, 'time');
        $result = array_multisort($date,SORT_DESC,$new);

        foreach ($new as &$value) {
            $value['time'] = get_microtime_format($value['time']);
        }
        return $new;
    }

    public function platform_people($time)
    {
    	$zgreadonly = $this->load->database('exchange_onlyread',true);
    	for ($i=0; $i <100 ; $i++) { 
            $sql = "select user_id from order_history_".$i." where `finish_time` < ".$time." and `finish_time`>=1534521600 group by user_id";
            $object = object_to_array($zgreadonly->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $trade_history_onlyread = $this->load->database('trade_history_onlyread',true);
        foreach ($new as &$value) {
            $value['user_id'] = $value['user_id'];
            $sql1 = "select phone from users where id=".$value['user_id'];
            $res = object_to_array($trade_history_onlyread->query($sql1)->result());
            $value['phone'] = $res[0]['phone'];
        }
        return $new;
    }



}

/* End of file Tool_service.php */
/* Location: ./application/controllers/Tool_service.php */
