<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;


class Zjys_c2corder_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_user_withdraw_model');
        // $this->load->model('Zjys_user_withdraw_freezes_model');    
        $this->load->model('Zjys_c2corder_model');    
        $this->load->model('Zjys_user_operationmoney_model');
        $this->load->model('Zjys_merchantbank_model');
        $this->load->service('Zjys_user_service');
    }

    //获取merchant_banks表中和管理员相关的卡号
    public function get_link_cardnumber($admin_id)
    {
        return $this->Zjys_merchantbank_model->get_link_cardnumber($admin_id);
    }   

    //买入卖出列表
    public function inout($offset,$limit,$type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchanta_card_number,$start_time_update,$end_time_update){
        //查看当前管理员是否关联平台银行卡信息
        $admin_link_cardnumber = $this->get_link_cardnumber($this->user_id);
        $arr = array();
        foreach ($admin_link_cardnumber as $key => $value) {
            array_push($arr,$value['id']);
        }

        $object = $this->db->select("c2c_orders.*,users.phone,users.email,users.realname as real_name,users.id as uid,user_banks.card_number as user_card_number,user_banks.name,user_banks.pre_phone,user_banks.bank as user_bank,user_banks.sub_bank as user_sub_bank,merchant_banks.card_number as merchanta_card_number,merchant_banks.bank as merchant_bank,merchant_banks.sub_bank as merchant_sub_bank,b_site.name as site_name")
            ->from('c2c_orders')
            ->join('user_banks','user_banks.id=c2c_orders.user_bank_id','left')
            ->join('merchant_banks','merchant_banks.id=c2c_orders.merchant_bank_id','left')
            ->join('b_site','b_site.id = c2c_orders.site_id','left')
            ->join('users','users.id=c2c_orders.user_id','left');
        $object =$this->db->where('c2c_orders.type =',$type);
        //,admin_operation_logs.description
        if($site_id!='') $object =$this->db->where('c2c_orders.site_id = ',$site_id);

        if(!empty($name)){ //按姓名查询
            $object =$this->db->where('users.realname =',$name);
        }

        if(!empty($uid)){ //按姓名查询
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($useraccount)){ //按账户查询
            if(WSTIsPhone($useraccount)){
                $object =$this->db->where('users.phone = ',$useraccount);
            }else{
                $object =$this->db->where('users.email = ',$useraccount);
            }
        }

        if(!empty($status)){
            $object =$this->db->where('c2c_orders.status =',$status);
        }
        if(!empty($order_no)){
            $object =$this->db->where('c2c_orders.order_no =',$order_no);
        }
        if(!empty($merchanta_card_number)){
            $object =$this->db->where('merchant_banks.card_number =',$merchanta_card_number);
        }
        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.created_at <',$end_time);
        }

        if(!empty($start_time_update)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time_update);
        }
        if(!empty($end_time_update)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time_update);
        }

        // if(is_array($arr) && !empty($arr)){
        //     $object = $this->db->where_in('c2c_orders.merchant_bank_id',$arr);
        // }
        
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
       // var_dump($this->db->last_query());die;
        foreach ($list as &$value) {
            //数量会计格式输出展示 
            $a = explode('.',$value['amount']);
            if(count($a)==2)
                $value['amount'] = number_format($a[0]).'.'.$a[1];
            else
                $value['amount'] = number_format($a[0]);

            if($value['pay_method'] == 0){
                $value['pay_method'] = '银行卡';
            }else{
                $value['pay_method'] = 0;
            }

            if($value['type'] == 1){
                $value['type'] = '买入';
            }else{
                $value['type'] = '卖出';
            }
            if($value['status'] == 1){
                $value['status_type'] = '未成交';
            }elseif ($value['status'] == 2) {
                $value['status_type'] = '已支付';
            }elseif ($value['status'] == 3){
                $value['status_type'] = '已成功';
            }elseif ($value['status'] == 4){
                $value['status_type'] = '已取消';
            }elseif ($value['status'] == 5){
                $value['status_type'] = '处理中';
            }

            if($type==1){
                $value['card_number']=$this->get_user_bankcard($value['user_id']);
            }
        }
        return $list;
    }


    // public function inout_printexcel($offset,$limit,$type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchanta_card_number,$start_time_update,$end_time_update)
    // {
    //     //查看当前管理员是否关联平台银行卡信息
    //     // $admin_link_cardnumber = $this->get_link_cardnumber($this->user_id);
    //     // $arr = array();
    //     // foreach ($admin_link_cardnumber as $key => $value) {
    //     //     array_push($arr,$value['id']);
    //     // }

    //     $object = $this->db->select("c2c_orders.*,users.phone,users.email,users.realname as real_name,users.id as uid,user_banks.card_number as user_card_number,user_banks.name,user_banks.pre_phone,user_banks.bank as user_bank,user_banks.sub_bank as user_sub_bank,merchant_banks.card_number as merchanta_card_number,merchant_banks.bank as merchant_bank,merchant_banks.sub_bank as merchant_sub_bank,b_site.name as site_name")
    //         ->from('c2c_orders')
    //         ->join('user_banks','user_banks.id=c2c_orders.user_bank_id','left')
    //         ->join('merchant_banks','merchant_banks.id=c2c_orders.merchant_bank_id','left')
    //         ->join('b_site','b_site.id = c2c_orders.site_id','left')
    //         ->join('users','users.id=c2c_orders.user_id','left');
    //     $object =$this->db->where('c2c_orders.type =',$type);

    //     if($site_id!='') $object =$this->db->where('c2c_orders.site_id = ',$site_id);

    //     if(!empty($name)){ //按姓名查询
    //         $object =$this->db->where('users.realname =',$name);
    //     }

    //     if(!empty($uid)){ //按姓名查询
    //         $object =$this->db->where('users.id =',$uid);
    //     }

    //     if(!empty($useraccount)){ //按账户查询
    //         if(WSTIsPhone($useraccount)){
    //             $object =$this->db->where('users.phone = ',$useraccount);
    //         }else{
    //             $object =$this->db->where('users.email = ',$useraccount);
    //         }
    //     }

    //     if(!empty($status)){
    //         $object =$this->db->where('c2c_orders.status =',$status);
    //     }
    //     if(!empty($order_no)){
    //         $object =$this->db->where('c2c_orders.order_no =',$order_no);
    //     }
    //     if(!empty($merchanta_card_number)){
    //         $object =$this->db->where('merchant_banks.card_number =',$merchanta_card_number);
    //     }
    //     if(!empty($start_time)){
    //         $object =$this->db->where('c2c_orders.created_at >=',$start_time);
    //     }
    //     if(!empty($end_time)){
    //         $object =$this->db->where('c2c_orders.created_at <',$end_time);
    //     }

    //     if(!empty($start_time_update)){
    //         $object =$this->db->where('c2c_orders.updated_at >=',$start_time_update);
    //     }
    //     if(!empty($end_time_update)){
    //         $object =$this->db->where('c2c_orders.updated_at <',$end_time_update);
    //     }

    //     // if(is_array($arr) && !empty($arr)){
    //     //     $object = $this->db->where_in('c2c_orders.merchant_bank_id',$arr);
    //     // }
        
    //     //基本订单结果
    //     $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
    //     print_r($list);
    //     //求取对应操作人
    //     $object1 = $this->db->select("c2c_orders.*,users.phone,users.email,users.realname as real_name,users.id as uid,user_banks.card_number as user_card_number,user_banks.name,user_banks.pre_phone,user_banks.bank as user_bank,user_banks.sub_bank as user_sub_bank,merchant_banks.card_number as merchanta_card_number,merchant_banks.bank as merchant_bank,merchant_banks.sub_bank as merchant_sub_bank,b_site.name as site_name")
    //         ->from('c2c_orders')
    //         ->join('user_banks','user_banks.id=c2c_orders.user_bank_id','left')
    //         ->join('merchant_banks','merchant_banks.id=c2c_orders.merchant_bank_id','left')
    //         ->join('b_site','b_site.id = c2c_orders.site_id','left')
    //         ->join('users','users.id=c2c_orders.user_id','left');
    //         // ->join('admin_operation_logs','admin_operation_logs.business_id=c2c_orders.id','left');
    //     $object1 =$this->db->where('c2c_orders.type =',$type);
    //     // if($type=1){
    //     //     $object1 = $this->db->where('admin_operation_logs.operation_type=',4);
    //     //     $object1 = $this->db->or_where('admin_operation_logs.operation_type=',5);
    //     //     $object1 = $this->db->or_where('admin_operation_logs.operation_type=',10);
    //     // }else{
    //     //     $object1 = $this->db->where('admin_operation_logs.operation_type=',6);
    //     //     $object1 = $this->db->or_where('admin_operation_logs.operation_type=',7);
    //     //     $object1 = $this->db->or_where('admin_operation_logs.operation_type=',11);
    //     // }

    //     if($site_id!='') $object1 =$this->db->where('c2c_orders.site_id = ',$site_id);

    //     if(!empty($name)){ //按姓名查询
    //         $object1 =$this->db->where('users.realname =',$name);
    //     }

    //     if(!empty($uid)){ //按姓名查询
    //         $object1 =$this->db->where('users.id =',$uid);
    //     }

    //     if(!empty($useraccount)){ //按账户查询
    //         if(WSTIsPhone($useraccount)){
    //             $object1 =$this->db->where('users.phone = ',$useraccount);
    //         }else{
    //             $object1 =$this->db->where('users.email = ',$useraccount);
    //         }
    //     }

    //     if(!empty($status)){
    //         $object1 =$this->db->where('c2c_orders.status =',$status);
    //     }
    //     if(!empty($order_no)){
    //         $object1 =$this->db->where('c2c_orders.order_no =',$order_no);
    //     }
    //     if(!empty($merchanta_card_number)){
    //         $object1 =$this->db->where('merchant_banks.card_number =',$merchanta_card_number);
    //     }
    //     if(!empty($start_time)){
    //         $object1 =$this->db->where('c2c_orders.created_at >=',$start_time);
    //     }
    //     if(!empty($end_time)){
    //         $object1 =$this->db->where('c2c_orders.created_at <',$end_time);
    //     }

    //     if(!empty($start_time_update)){
    //         $object1 =$this->db->where('c2c_orders.updated_at >=',$start_time_update);
    //     }
    //     if(!empty($end_time_update)){
    //         $object1 =$this->db->where('c2c_orders.updated_at <',$end_time_update);
    //     }
        
    //     $list1 = $object1->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        

    //     foreach ($list1 as $key=>$value) {
    //         $arr[$key]['user_id'] = $value['user_id'];
    //         $arr[$key]['id'] = $value['id'];
    //     }

    //     print_r($arr);die;

    //     foreach ($list as &$value) {
    //         //数量会计格式输出展示 
    //         $a = explode('.',$value['amount']);
    //         if(count($a)==2)
    //             $value['amount'] = number_format($a[0]).'.'.$a[1];
    //         else
    //             $value['amount'] = number_format($a[0]);

    //         if($value['pay_method'] == 0){
    //             $value['pay_method'] = '银行卡';
    //         }else{
    //             $value['pay_method'] = 0;
    //         }

    //         if($value['type'] == 1){
    //             $value['type'] = '买入';
    //         }else{
    //             $value['type'] = '卖出';
    //         }
    //         if($value['status'] == 1){
    //             $value['status_type'] = '未成交';
    //         }elseif ($value['status'] == 2) {
    //             $value['status_type'] = '已支付';
    //         }elseif ($value['status'] == 3){
    //             $value['status_type'] = '已成功';
    //         }elseif ($value['status'] == 4){
    //             $value['status_type'] = '已取消';
    //         }elseif ($value['status'] == 5){
    //             $value['status_type'] = '处理中';
    //         }

    //         if($type==1){
    //             $value['card_number']=$this->get_user_bankcard($value['user_id']);
    //         }
    //     }
    //     return $list;
    // }


    //根据姓名和平台卡号获取财务信息
    public function get_bank_flow($name,$m_bank_id,$type,$status){

        $a = $this->Zjys_merchantbank_model->get_info_per_user($m_bank_id,$type,$status,$name);
        return $this->Zjys_merchantbank_model->get_info_per_user($m_bank_id,$type,$status,$name);
    }

    //获取用户银行卡号和银行名称
    function get_user_bankcard($user_id)
    {
        $object = $this->db->select("user_banks.card_number,user_banks.bank")
            ->from('user_banks');
        $object =$this->db->where('user_banks.user_id = ',(int)$user_id);
        $list = $object->get()->result_array();
        $ss = [];
        foreach ($list as $key => $value) {
            $ss[$key] = $value['card_number'].'-'.$value['bank'];
        }
        return implode(' ', $ss);
    }
    


    //买入卖出列表
    public function inout_count($type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchanta_card_number,$start_time_update,$end_time_update){
        //查看当前管理员是否关联平台银行卡信息
        $admin_link_cardnumber = $this->get_link_cardnumber($this->user_id);
        $arr = array();
        foreach ($admin_link_cardnumber as $key => $value) {
            array_push($arr,$value['id']);
        }

        $object = $this->db->select("c2c_orders.*,users.phone,users.email,users.realname as real_name,user_banks.card_number as user_card_number,user_banks.name,user_banks.pre_phone,user_banks.bank as user_bank,user_banks.sub_bank as user_sub_bank,merchant_banks.card_number as merchanta_card_number,merchant_banks.bank as merchant_bank,merchant_banks.sub_bank as merchant_sub_bank")
            ->from('c2c_orders')
            // ->join('user_identities','user_identities.user_id=c2c_orders.user_id','left')
            ->join('user_banks','user_banks.id=c2c_orders.user_bank_id','left')
            ->join('merchant_banks','merchant_banks.id=c2c_orders.merchant_bank_id','left')
            ->join('users','users.id=c2c_orders.user_id','left');
         // $object =$this->db->where('user_identities.status =',2); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);

        if($site_id!='') $object =$this->db->where('c2c_orders.site_id = ',$site_id);
        // $object =$this->db->where('user_identities.deleted_at is null');

        if(!empty($name)){ //按姓名查询
            $object =$this->db->where('users.realname =',$name);
        }

        if(!empty($uid)){ //按姓名查询
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($useraccount)){ //按账户查询
            if(WSTIsPhone($useraccount)){
                $object =$this->db->where('users.phone = ',$useraccount);
            }else{
                $object =$this->db->where('users.email = ',$useraccount);
            }
        }


        if(!empty($status)){
            $object =$this->db->where('c2c_orders.status =',$status);
        }
        if(!empty($order_no)){
            $object =$this->db->where('c2c_orders.order_no =',$order_no);
        }

      	if(!empty($merchanta_card_number)){

            $object =$this->db->where('merchant_banks.card_number =',$merchanta_card_number);
        }
        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.created_at <',$end_time);
        }
        //最后操作时间条件筛选
        if(!empty($start_time_update)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time_update);
        }
        if(!empty($end_time_update)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time_update);
        }
        // if(is_array($arr) && !empty($arr)){
        //     $object = $this->db->where_in('c2c_orders.merchant_bank_id',$arr);
        // }        
        return $this->db->count_all_results();
    }

    //法币买入卖出审核（5：初次审核成功状态，状态变处理中 4：审核不通过）
    public function c2c_verify_first($id,$status,$description,$caiwu_id)
    {
        $detail = $this->Zjys_c2corder_model->get_c2corder_info($id);
        $asset = $detail['asset'];
        $user_id = $detail['user_id'];
        $price = $detail['price'];
        $site_id = $detail['site_id'];
        $created_at = $process_time = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        $type = $detail['type']==1 ? '买入':'卖出';
        $true_status = (int)$detail['status'];
        $amount = $detail['amount'];
        $real_amount = $detail['real_amount'];
        $totalamount = $price*$amount;
        $ss = '审核';
        $this->db->trans_begin();
        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset,$user_id);
        if($detail['type']==1){ //买入
            if($true_status != 1 && $true_status != 2) return false;
            if($status == 4){ //审核不通过（取消状态）
                $business = $this->config->item('C2C_TRADE_BUY_CHECK_NO');
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
            }else{
                // if($caiwu_id==''){
                //     returnJson('402','没选中财务信息无法审核通过');
                // }
                $business = $this->config->item('C2C_TRADE_BUY_CHECK_YES_FIRST');
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
                // if($caiwu_id!='')
                // {
                //     //将财务信息记录的状态置为待处理已通过状态。 $caiwu_id = '1,2';
                //     $caiwu_id = explode(',', $caiwu_id);
                //     // $status = 7; //bank_inout中的状态：初审通过
                //     for($i = 0;$i<count($caiwu_id);$i++)
                //     {
                //         $this->Zjys_merchantbank_model->update_caiwu_status($caiwu_id[$i],7);
                //     }
                // }
            }
        }else{
            // 卖出
            if($true_status != 1 && $true_status != 2) return false;
            if($status == 4){ //审核不通过（取消状态）
                $ss = array('info'=>$ss);
                $result = update_user_balance_bycurl($user_id,$asset,$amount,$id,$ss,$busi='cancel_c2c_sell_freeze');
                if($result['error']['code']==10){
                    returnJson('402','解冻资金失败');
                }else{
                    $balance = $last_balance['balance']-$amount;
                    $business = $this->config->item('C2C_TRADE');
                    //写入user_asset_freeze表
                    $detail1 = json_encode(array('id'=>(int)$id));
                    $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);

                    $business = $this->config->item('C2C_TRADE_SELL_CHECK_NO');
                    // $description = '法币卖出审核不通过';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
                }
            }else{
                    $business = $this->config->item('C2C_TRADE_SELL_CHECK_YES_FIRST');
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);                
            }
        }
        $result = $this->Zjys_c2corder_model->update_status($id,$status,$created_at,$process_time); 
        //关键位置操作日志记录
        // key_logs($this->user_id,$desc,$method,$detail);
        
        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            returnJson('402','Transaction failed');
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    //法币买入卖出审核（3：审核通过，状态变已成功 4：审核不通过）
    public function c2c_verify($id,$status,$description,$caiwu_id)
    {
        $detail = $this->Zjys_c2corder_model->get_c2corder_info($id);
      	$queue_status = 'success';

        $asset = $detail['asset'];
        $user_id = $detail['user_id'];
        $price = $detail['price'];
        $site_id = $detail['site_id'];
        $created_at = $process_time = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        $type = $detail['type']==1 ? '买入':'卖出';
        $true_status = (int)$detail['status'];
        $amount = $detail['amount'];
        $real_amount = $detail['real_amount'];
        $totalamount = $price*$amount;
        $ss = '审核';
        $this->db->trans_begin();
        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset,$user_id);
        if($detail['type']==1){ //买入
            if($true_status != 5) return false;
            if($status == 4){ //审核不通过（取消状态）
                // if($caiwu_id==''){
                //     returnJson('402','请选中财务信息！');
                // }
                // $balance = $last_balance['balance']-$amount;
                $business = $this->config->item('C2C_TRADE');
                //写入user_asset_freeze表
                // $detail1 = json_encode(array('id'=>(int)$id));
                // $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);
                
                $business = $this->config->item('C2C_TRADE_BUY_CHECK_NO');
                //$description = '法币买入审核拒绝';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
                // if($caiwu_id!='')
                // {
                //     //将财务信息记录的状态置为待处理已通过状态
                //     // $caiwu_id = '1,2';
                //     $caiwu_id = explode(',', $caiwu_id);
                //     for($i = 0;$i<count($caiwu_id);$i++)
                //     {
                //         $this->Zjys_merchantbank_model->update_caiwu_status($caiwu_id[$i],8);
                //     }
                // }
            }else{
                // if($caiwu_id==''){
                //     returnJson('402','没选中财务信息无法审核通过');
                // }
                // 修改用户账户资金
                $ss = array('info'=>$ss);
                $result = update_user_balance_bycurl($user_id,$asset,$real_amount,$id,$ss,$busi='c2c_deposit');
                // var_dump($result);die;
                if($result['error']!==NULL){
                    log_message('debug',$result['error']['message']);
                    returnJson('402',$result['error']['message']);
                }elseif($result['result']['status']=='success'){
                    //打入消息队列
                    require_once './vendor/autoload.php';
                    $connection = new AMQPStreamConnection($this->config->item('rabbitmq_host'), $this->config->item('rabbitmq_port'), $this->config->item('rabbitmq_user'), $this->config->item('rabbitmq_pwd'));
                    // $connection = new AMQPStreamConnection('localhost', 5672, 'guest', 'guest');
                    $channel = $connection->channel();
                    $channel->queue_declare('task_queue', false, true, false, false);
                    $iid = array($id);
                    $arr = array(
                        'name'=>'c2c_recharge',
                        'ip'=>$_SERVER['REMOTE_ADDR'],
                        'endpoint'=>'admin',
                        // 'params'=> '['.$id.']',
                        'params'=> array((int)$id),
                        'time'=>$_SERVER['REQUEST_TIME'],
                    );

                    $detail = json_encode($arr);
                    $msg = new AMQPMessage($detail,array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
                    $cc = $channel->basic_publish($msg, '', 'task_queue');
                    // echo " [x] Sent 'Hello World!'\n";
                    $channel->close();
                    $connection->close();
                    if($cc != NULL){
                        $queue_status = 'failed';
                    }else{
                        $queue_status = 'success';
                    }
                    $iid = '['.$id.']';

                    $this->Zjys_c2corder_model->add_event($created_at,$updated_at,$arr['name'],$arr['ip'],$arr['endpoint'],$iid);

                    $business = $this->config->item('C2C_TRADE_BUY_CHECK_YES');
                    // $description = '法币买入审核通过';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
                        // if($caiwu_id!='')
                        // {
                        //     //将财务信息记录的状态置为待处理已通过状态
                        //     // $caiwu_id = '1,2';
                        //     $caiwu_id = explode(',', $caiwu_id);
                        //     for($i = 0;$i<count($caiwu_id);$i++)
                        //     {
                        //         $this->Zjys_merchantbank_model->update_caiwu_status($caiwu_id[$i],2);
                        //     }
                        // }
                    }
                }
        }else{
            // 卖出
            if($true_status != 5) return false;
            if($status == 4){ //审核不通过（取消状态）
                $ss = array('info'=>$ss);
                $result = update_user_balance_bycurl($user_id,$asset,$amount,$id,$ss,$busi='cancel_c2c_sell_freeze');
                if($result['error']['code']==10){
                    returnJson('402','解冻资金失败');
                }else{
                    $balance = $last_balance['balance']-$amount;
                    $business = $this->config->item('C2C_TRADE');
                    //写入user_asset_freeze表
                    $detail1 = json_encode(array('id'=>(int)$id));
                    $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);

                    $business = $this->config->item('C2C_TRADE_SELL_CHECK_NO');
                    // $description = '法币卖出审核不通过';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
                }
            }else{
                    $business = $this->config->item('C2C_TRADE');
                    $balance = $last_balance['balance']-$amount;
                    $detail1 = json_encode(array('id'=>(int)$id));
                    $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);
                
                    $business = $this->config->item('C2C_TRADE_SELL_CHECK_YES');
                    // $description = '法币买入审核通过';
                    admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);                
            }
        }
        $result = $this->Zjys_c2corder_model->update_status($id,$status,$created_at,$process_time);
        $trans_status = $this->db->trans_status(); 
        if($queue_status == 'failed' && $trans_status == false)
        {
            $trans_status = false;
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            returnJson('402','Transaction failed');
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    //后台解冻资金
    public function admin_unfreeze_asset($uid,$asset,$amount,$remark)
    {
        //查看当前用户是否有锁仓记录
        $args=array('uid'=>$uid,'asset'=>$asset);
        $site_id = $this->db->query("select site_id from users where id=$uid")->row_array();
        $list = $this->Zjys_user_service->is_lockposition($args);
        if(is_array($list) && !empty($list)) returnJson('402','当前用户有锁仓记录，请先解仓');
        
        //解冻资金
        if(!is_numeric($amount) || $amount<=0) returnJson('402','金额非法');
        $created_at = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        $business = $this->config->item('ADMIN_UNFREEZE');
        $this->db->trans_start();
        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset,$uid);
        if(is_array($last_balance) && empty($last_balance)) returnJson('402','当前币种没有冻结资金');
        if(bcsub($last_balance['balance'], $amount,16)<0){
            returnJson('402','调整冻结非法');
        }
        $balance = bcsub($last_balance['balance'],$amount);
        $detail1 = json_encode(array('uid'=>(int)$uid));

        $result = $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$uid,$asset,-$amount,$business,$balance,$detail1);
        // var_dump($result);die;
        if($result){
            // 更改用户资金
            $ss = array('info'=>$business);
            $res = update_user_balance_bycurl_unfreeze($uid,$asset,$amount,$result,$ss);
            // var_dump($res);die;
            if($res['error']!==NULL){
                returnJson('402','充值系统错误');
            }elseif($res['result']['status']=='success'){
                $business_type = $this->config->item('ADMIN_UNFREEZE_ASSET');
                admin_operation_logs($this->user_id,$uid,$business_type,$remark,$created_at,$result);
                $this->Zjys_user_operationmoney_model->add($this->user_id,$created_at,$asset,$amount,$uid,$remark,$site_id['site_id'],$type=2);
            }
        }else{
            return false;
        }

        $this->db->trans_complete();      
        return $result;
    }   


    //根据用户和币种查找冻结的C2C资金
    public function get_c2c_freezen_by_assets_and_userid($assets,$user_id)
    {
        $sql = 'select balance from user_asset_freezes where asset="'.$assets.'" and user_id='.$user_id.' and business in ("c2c_sell_freeze","cancel_c2c_sell_freeze","admin_c2c_unfreeze") order by id desc limit 1';
        $result = object_to_array($this->db->query($sql)->result());
        // var_dump($this->db->last_query());
        // var_dump($result);die;
        if(is_array($result) && !empty($result)){
            return $result[0]['balance'];
        }else{
            return '0';
        }
    }

    /*
     * 法币买入卖出统计
     */
    public function get_in_total($start_time,$end_time,$offset,$limit,$type,$site_id){
        return $this->Zjys_c2corder_model->in_total($start_time,$end_time,$offset,$limit,$type,$site_id);
    }

    public function get_in_total_count($start_time,$end_time,$type,$site_id){
        return $this->Zjys_c2corder_model->in_total_count($start_time,$end_time,$type,$site_id);
    }

    //
    public function total($type,$site_id,$stime,$etime,$offset,$limit)
    {
        return $this->Zjys_c2corder_model->total($type,$site_id,$stime,$etime,$offset,$limit);
    }


    public function total_reality($type,$site_id,$stime,$etime,$offset,$limit)
    {
        return $this->Zjys_c2corder_model->total_reality($type,$site_id,$stime,$etime,$offset,$limit);
    }
    //买入卖出应收、理论指出
    public function get_totalamount_per_merchantbank($m_bank_id,$type,$start_time,$end_time,$offset,$limit)
    {
        $object = $this->db->select("DATE_FORMAT(updated_at,'%Y-%m-%d') days,sum(total_amount) total")
            ->from('c2c_orders');
        $object =$this->db->group_by('days');  
        $object =$this->db->where('c2c_orders.merchant_bank_id =',$m_bank_id); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);
        $object =$this->db->where('c2c_orders.status !=',4);

        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time);
        }        

        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        return $list;
    }

    //买入卖出应收、理论指出
    public function get_totalamount_per_merchantbank_count($m_bank_id,$type,$start_time,$end_time,$offset,$limit)
    {

        $object = $this->db->select("DATE_FORMAT(updated_at,'%Y-%m-%d') days,sum(total_amount) total")
            ->from('c2c_orders');
            // ->('c2c_orders')
        $object =$this->db->group_by('days');  
        $object =$this->db->where('c2c_orders.merchant_bank_id =',$m_bank_id); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);
        $object =$this->db->where('c2c_orders.status !=',4);

        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time);
        }        

        return $this->db->count_all_results();         
    }


    //买入卖出实际收入、实际支出
    public function get_totalamount_per_merchantbank_reality($m_bank_id,$type,$start_time,$end_time,$offset,$limit)
    {
        $object = $this->db->select("DATE_FORMAT(updated_at,'%Y-%m-%d') days,sum(total_amount) total")
            ->from('c2c_orders');
            // ->('c2c_orders')
        $object =$this->db->group_by('days');  
        $object =$this->db->where('c2c_orders.merchant_bank_id =',6); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);
        $object =$this->db->where('c2c_orders.status =',3);

        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time);
        }        

        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        return $list;
    }

    //买入卖出实际收入、实际支出
    public function get_totalamount_per_merchantbank_reality_count($m_bank_id,$type,$start_time,$end_time,$offset,$limit)
    {
        $object = $this->db->select("DATE_FORMAT(updated_at,'%Y-%m-%d') days,sum(total_amount) total")
            ->from('c2c_orders');
            // ->('c2c_orders')
        $object =$this->db->group_by('days');  
        $object =$this->db->where('c2c_orders.merchant_bank_id =',6); //实名过的
        $object =$this->db->where('c2c_orders.type =',$type);
        $object =$this->db->where('c2c_orders.status =',3);

        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <',$end_time);
        }        

        return $this->db->count_all_results();
    }



 public function get_c2corder()
    {
        $result = $this->Zjys_c2corder_model->get_c2corder($id);
        return $result;
    }
    






    
   




}
