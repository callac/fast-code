<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Ticket_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Ticket_model');    
    }   

    //币资产种类
    public function ticket_list($offset,$limit,$user_id,$phone,$email,$site_id,$status,$start_time,$end_time){
        $object = $this->db->select("tickets.*,b_site.name as site_name")
            ->join('user_identities','tickets.user_id=user_identities.user_id','left')
            ->join('b_site','b_site.id=tickets.site_id','left')
            ->from('tickets');
        if($site_id!='') $object =$this->db->where('tickets.site_id = ',$site_id);

            $object =$this->db->where('tickets.deleted_at is null');
        if(!empty($phone)){
            $object =$this->db->where('tickets.phone =',$phone);
        }
        if(!empty($email)){
            $object =$this->db->where('tickets.email =',$email);
        }
        if($status!=''){
            $object =$this->db->where('tickets.status =',$status);
        }
        if(!empty($start_time)){
            $object =$this->db->where('tickets.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('tickets.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        $oss = new \App\Helpers\oss_helper();
        foreach ($list as &$value) {
            if($value['attach']){
                $img = explode(',',$value['attach']);
                for($i=0;$i<count($img);$i++){
                    $value['attach_img'][$i] = $oss->getSignedUrlForGettingObject($img[$i]);
                }
            }
        }
        return $list;
    }

    public function ticket_reply_list($args){
        $ticket_id = $args['ticket_id'];
        $object = $this->db->select("ticket_messages.*")
            ->from('ticket_messages');
        if(!empty($ticket_id)){
            $object =$this->db->where('ticket_messages.ticket_id =',$ticket_id);
        }   
        $list = $object->order_by('created_at','desc')->get()->result_array();
        $oss = new \App\Helpers\oss_helper();
        foreach ($list as &$value) {
            if($value['attach']){
                $img = explode(',',$value['attach']);
                for($i=0;$i<count($img);$i++){
                    $value['attach_img'][$i] = $oss->getSignedUrlForGettingObject($img[$i]);
                }
            }
        }
        return $list;
    }
    

    
    public function ticket_list_count($user_id,$phone,$email,$site_id,$status,$start_time,$end_time){
        $object = $this->db->select("tickets.id")
            ->join('user_identities','tickets.user_id=user_identities.user_id','left')
            ->join('b_site','b_site.id=tickets.site_id','left')
            ->from('tickets');
        if($site_id!='') $object =$this->db->where('tickets.site_id = ',$site_id);

            $object =$this->db->where('tickets.deleted_at is null');
        if(!empty($phone)){
            $object =$this->db->where('tickets.phone =',$phone);
        }
        if(!empty($email)){
            $object =$this->db->where('tickets.email =',$email);
        }
        if($status!=''){
            $object =$this->db->where('tickets.status =',$status);
        }
        if(!empty($start_time)){
            $object =$this->db->where('tickets.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('tickets.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }



    public function ticket_message_reply($args)
    {
        $ticket_id = $args['ticket_id'];
        $message = $args['message'];
        $created_at = $updated_at = date('Y-m-d H:i:s',time());

        $attach = isset($args['attach']) ? $args['attach'] : false;
        $detail = $this->Ticket_model->ticket_detail($ticket_id);
        if($detail['status']==0){
            $this->Ticket_model->ticket_status(1,$ticket_id);
        }
        return $this->Ticket_model->ticket_message_reply($args['ticket_id'],$args['message'],$attach,$created_at,$updated_at);
        
    }

    /**
     * 关闭会话
     */
    public function ticket_close($args)
    {
        $id = $args['id'];
        $time = date('Y-m-d H:i:s',time());
        return $this->Ticket_model->ticket_close($id,$time);
    }
}
