<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_merchantbank_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_merchantbank_model');    
        $this->load->model('Site_model');    
    }   

    //币资产种类
    public function merchantbank_list($offset,$limit,$name,$code,$start_time,$end_time,$site_id){
        $admin_link_cardnumber = $this->get_link_cardnumber($this->user_id);
        $arr = array();
        foreach ($admin_link_cardnumber as $key => $value) {
            array_push($arr,$value['card_number']);
        }

        // var_dump($arr);die;
        $object = $this->db->select("merchant_banks.*,b_site.name as site_name")
            ->join('b_site','b_site.id=merchant_banks.site_id','left')
            ->from('merchant_banks');
        // $object =$this->db->where('merchant_banks.status =',1);
        if($site_id!='') $object =$this->db->where('merchant_banks.site_id = ',$site_id);
        if(!empty($name)){
            $object =$this->db->where('merchant_banks.name =',$name);
        }

        if(!empty($start_time)){
            $object =$this->db->where('merchant_banks.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('merchant_banks.created_at <',$end_time);
        }

        if(is_array($arr) && !empty($arr)){
            // $object = $this->db->where_in('merchant_banks.card_number',$arr);
        }else{
            if(!empty($code)){
                $object =$this->db->where('merchant_banks.card_number =',$code);
            }
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        return $list;
    }
    //获取merchant_banks表中和管理员相关的卡号
    public function get_link_cardnumber($admin_id)
    {
        return $this->Zjys_merchantbank_model->get_link_cardnumber($admin_id);
    }



    public function merbank_inout_list($offset,$limit,$name,$code,$start_time,$end_time,$site_id,$m_bank_id,$status){
        $object = $this->db->select("bank_inout.*,b_site.name as site_name")
            ->join('merchant_banks','merchant_banks.id=bank_inout.m_bank_id','left')
            ->join('b_site','b_site.id=merchant_banks.site_id','left')
            ->from('bank_inout');
        $object =$this->db->where('bank_inout.m_bank_id =',$m_bank_id);
        if($site_id!='') $object =$this->db->where('merchant_banks.site_id = ',$site_id);

        if(!empty($name)){
            $object =$this->db->where('bank_inout.user_name =',$name); //客户姓名
        }

        if(!empty($code)){
            $object =$this->db->where('bank_inout.user_bank_number =',$code); //客户卡号
        }

        if(!empty($status)){
            $object =$this->db->where('bank_inout.status =',$status); //客户卡号
        }

        if(!empty($start_time)){
            $object =$this->db->where('bank_inout.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('bank_inout.updated_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('updated_at','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        return $list;
    }


    public function get_total_money($m_bank_id,$status,$type){
        return $this->Zjys_merchantbank_model->get_total_money($m_bank_id,$status,$type);
    }

    public function merbank_inout_list_count($name,$code,$start_time,$end_time,$site_id,$m_bank_id,$status){
        $object = $this->db->select("bank_inout.*,b_site.name as site_name")
            ->join('merchant_banks','merchant_banks.id=bank_inout.m_bank_id','left')
            ->join('b_site','b_site.id=merchant_banks.site_id','left')
            ->from('bank_inout');
        // $object =$this->db->where('merchant_banks.status =',1);
        $object =$this->db->where('bank_inout.m_bank_id =',$m_bank_id);
        if($site_id!='') $object =$this->db->where('merchant_banks.site_id = ',$site_id);

        if(!empty($name)){
            $object =$this->db->where('bank_inout.user_name =',$name); //客户姓名
        }

        if(!empty($code)){
            $object =$this->db->where('bank_inout.user_bank_number =',$code); //客户卡号
        }

        if(!empty($status)){
            $object =$this->db->where('bank_inout.status =',$status); //客户卡号
        }


        if(!empty($start_time)){
            $object =$this->db->where('bank_inout.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('bank_inout.updated_at <',$end_time);
        }
        return $this->db->count_all_results();
    }
    


    public function merchantbank_count($name,$code,$start_time,$end_time,$site_id){
        $admin_link_cardnumber = $this->get_link_cardnumber($this->user_id);
        $arr = array();
        foreach ($admin_link_cardnumber as $key => $value) {
            array_push($arr,$value['card_number']);
        }

        $object = $this->db->select("merchant_banks.*,b_site.name as site_name")
            ->join('b_site','b_site.id=merchant_banks.site_id','left')
            ->from('merchant_banks');
        // $object =$this->db->where('merchant_banks.status =',1);
            if($site_id!='') $object =$this->db->where('merchant_banks.site_id = ',$site_id);
        if(!empty($name)){
            $object =$this->db->where('merchant_banks.name =',$name);
        }
        if(!empty($code)){
            $object =$this->db->where('merchant_banks.card_number =',$code);
        }

        if(!empty($start_time)){
            $object =$this->db->where('merchant_banks.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('merchant_banks.created_at <',$end_time);
        }
        if(is_array($arr) && !empty($arr)){
            // $object = $this->db->where_in('merchant_banks.card_number',$arr);
        }else{
            if(!empty($code)){
                $object =$this->db->where('merchant_banks.card_number =',$code);
            }
        }
        return $this->db->count_all_results();
        return $list;
    }



    //添加、编辑币种类
    public function addbank($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $name = isset($args['name']) ? $args['name']: '';//资产码
        $bank = isset($args['bank']) ? $args['bank']: '';//资产名称
        $sub_bank = isset($args['sub_bank']) ? $args['sub_bank']: '';
        $card_number = isset($args['card_number']) ? $args['card_number']: '';

        $type = isset($args['type']) ? $args['type']: 3;
        $limit_money = isset($args['limit_money']) ? $args['limit_money']: 0; //额度
        $cash_deposit = isset($args['cash_deposit']) ? $args['cash_deposit']: 0; //保证金数量
        $contact_way = isset($args['contact_way']) ? $args['contact_way']: ''; //联系方式
        $admin_id = isset($args['admin_id']) ? $args['admin_id']: 0;

        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $card_true = $this->Zjys_merchantbank_model->is_true_card($card_number);
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());
        if(!$id){
            if(is_array($card_true) && !empty($card_true)) returnJson('402','银行卡不能重复添加');
            //新增
            $result = $this->Zjys_merchantbank_model->addbank($name,$bank,$sub_bank,$card_number,$created_at,$updated_at,$site_id,$type,$limit_money,$cash_deposit,$contact_way,$admin_id);
            // var_dump($result);die;
        }else{
            //修改
            $this->Zjys_merchantbank_model->editbank($name,$bank,$sub_bank,$card_number,$updated_at,$id,$site_id,$type,$limit_money,$cash_deposit,$contact_way,$admin_id);
        }
        return true;
    }

    //删除银行卡
    public function deletebank($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $status = isset($args['status']) ? $args['status']: '';
        if($status==0) $stat=1;
        if($status==1) $stat=0;
        return $this->Zjys_merchantbank_model->deletebank($stat,$id);
    }

    //后台添加财务 录入
    public function add_merbank_inout_flows($args)
    {
        $created_at = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        $id = isset($args['id']) ? (int)$args['id']: '';
        // var_dump($id);die;
        $m_bank_id = isset($args['m_bank_id']) ? $args['m_bank_id']: '';
        $user_name = isset($args['user_name']) ? $args['user_name']: '';
        $user_bank_number = isset($args['user_bank_number']) ? $args['user_bank_number']: '';
        $amount = isset($args['amount']) ? $args['amount']: '';
        if(!is_numeric($amount)) returnJson('402','金额格式非法');
        $type = isset($args['type']) ? $args['type']: '';//1、进账 2、出账
        $trans_remark = isset($args['trans_remark']) ? $args['trans_remark']: ''; //用户转账备注
        $remark = isset($args['remark']) ? $args['remark']: ''; //财务备注
        $status = isset($args['status']) ? $args['status']: ''; //状态
        $site_id = isset($args['site_id']) ? $args['site_id']: ''; //站点
        $this->db->trans_begin();
        if(!$id){
            //新增
            $result = $this->Zjys_merchantbank_model->addflows($m_bank_id,$user_bank_number,$user_name,$amount,$type,$created_at,$updated_at,$trans_remark,$remark,1,$site_id);
            //添加银行卡操作记录
            $description = '银行卡财务新增：'.$user_name.'卡号为'.$user_bank_number.'金额：'.$amount.'，备注：'.$remark;
            admin_banks_logs($this->user_id,$m_bank_id,1,$description,$created_at);
        }else{
            $detail = $this->Zjys_merchantbank_model->get_bankinout_detail($id);
            if($detail['status']==2) return false;//通过状态下不允许编辑
            $result = $this->Zjys_merchantbank_model->editflows($m_bank_id,$user_bank_number,$user_name,$amount,$type,$updated_at,$trans_remark,$remark,$status,$id,$site_id);
            $description = '银行卡财务编辑：'.$user_name.'卡号为'.$user_bank_number.'金额：'.$amount.'，备注：'.$remark;
            admin_banks_logs($this->user_id,$m_bank_id,2,$description,$created_at);
        }

        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            log_message('err','订单id为'.$id.'的订单充值失败');
            return false;
        } else {
            $this->db->trans_commit();
            return $result;
        }
    }

    //用户统计
    public function statistics_c2c_inout($args)
    {
        $start_time = !empty($args['start_time']) ? strtotime($args['start_time']) : strtotime('2018-08-18');
        $end_time = !empty($args['end_time']) ? strtotime($args['end_time']) : time();
        $site_id = isset($args['site_id']) ? $args['site_id'] : '';
        if($site_id === ''){
            $siteList = $this->Site_model->site_all();  
        }else{
            $siteList = $this->Site_model->site_one($site_id);
        }
        $newarr = [];
        
        //循环按日期来排序，默认时最后的站点覆盖了其他子站，查询其他子站要指定站点
        foreach ($siteList as $k => $v) {
            $arr = get_timearea_by_day($start_time,$end_time);
            if($arr == false) returnJson('402','时间区域无效');
            for ($i=0; $i < count($arr); $i++) { 
                $newarr[$i]['name'] = $v['name'];
                $newarr[$i]['time_area'] = date('Y-m-d',$arr[$i]);
                $newarr[$i]['time'] = $arr[$i];
                $result = $this->get_inmoney(date('Y-m-d',$arr[$i]),date('Y-m-d H:i:s',$arr[$i]+86399),$v['id']);
                $newarr[$i]['inmoney'] = isset($result['amount']) ? str_replace(',', '', $result['amount']) : '0';
                $newarr[$i]['inmoney_count'] = $result['inmoney_count'];//入账笔数
                if($result['inmoney_count'] == 0){
                    $newarr[$i]['inmoney_avg'] = 0;//平均单比入账
                }else{
                    $newarr[$i]['inmoney_avg'] = bcdiv((string)$result['amount'], $result['inmoney_count'],3);
                }
                $out_result = $this->get_outmoney(date('Y-m-d',$arr[$i]),date('Y-m-d H:i:s',$arr[$i]+86399),$v['id']);
                $newarr[$i]['outmoney'] = isset($out_result[0]['amount']) ? str_replace(',','',$out_result[0]['amount']) : '0';
                $newarr[$i]['outmoney_count'] = $out_result[0]['outmoney_count'];//入账笔数
                if($out_result[0]['outmoney_count'] == 0){
                    $newarr[$i]['outmoney_avg'] = 0;//平均单比入账
                }else{
                    $newarr[$i]['outmoney_avg'] = bcdiv((string)$out_result[0]['amount'], $out_result[0]['outmoney_count'],3);
                }
            }
        }
        $date = array_column($newarr, 'time');
        $result = array_multisort($date,SORT_DESC,$newarr);
        return $newarr;
    }



    public function statistics_c2c_inout_printexcel($args)
    {
        $start_time = !empty($args['start_time']) ? strtotime($args['start_time']) : strtotime('2018-08-18');
        $end_time = !empty($args['end_time']) ? strtotime($args['end_time']) : time();
        $site_id = isset($args['site_id']) ? $args['site_id'] : '';
        // $siteList = $this->Site_model->site_all();
        $siteList = $this->Site_model->site_one($site_id);
        $newarr = [];
        foreach ($siteList as $k => $v) {
            $arr = get_timearea_by_day($start_time,$end_time);
            if($arr == false) returnJson('402','时间区域无效');
            for ($i=0; $i < count($arr); $i++) { 
                $newarr[$i]['name'] = $v['name'];
                $newarr[$i]['time_area'] = date('Y-m-d',$arr[$i]);
                $newarr[$i]['time'] = $arr[$i];
                $result = $this->get_inmoney(date('Y-m-d',$arr[$i]),date('Y-m-d H:i:s',$arr[$i]+86399),$v['id']);
                $newarr[$i]['inmoney'] = isset($result['amount']) ? str_replace(',', '', $result['amount']) : '0';
                $newarr[$i]['inmoney_count'] = $result['inmoney_count'];//入账笔数
                if($result['inmoney_count'] == 0){
                    $newarr[$i]['inmoney_avg'] = 0;//平均单比入账
                }else{
                    $newarr[$i]['inmoney_avg'] = bcdiv((string)$result['amount'], $result['inmoney_count'],3);
                }
                $out_result = $this->get_outmoney(date('Y-m-d',$arr[$i]),date('Y-m-d H:i:s',$arr[$i]+86399),$v['id']);
                $newarr[$i]['outmoney'] = isset($out_result[0]['amount']) ? str_replace(',','',$out_result[0]['amount']) : '0';
                $newarr[$i]['outmoney_count'] = $out_result[0]['outmoney_count'];//入账笔数
                if($out_result[0]['outmoney_count'] == 0){
                    $newarr[$i]['outmoney_avg'] = 0;//平均单比入账
                }else{
                    $newarr[$i]['outmoney_avg'] = bcdiv((string)$out_result[0]['amount'], $out_result[0]['outmoney_count'],3);
                }
            }
        }
        $date = array_column($newarr, 'time');
        $result = array_multisort($date,SORT_DESC,$newarr);


        $data = [];
        foreach ($newarr as $key => $val) {
            $data[$key]['time_area'] = $val['time_area'];
            $data[$key]['name'] = $val['name'];
            $data[$key]['inmoney_count'] = $val['inmoney_count'];
            $data[$key]['inmoney'] = $val['inmoney'];
            $data[$key]['inmoney_avg'] = $val['inmoney_avg'];
            $data[$key]['outmoney_count'] = $val['outmoney_count'];
            $data[$key]['outmoney'] = $val['outmoney'];
            $data[$key]['outmoney_avg'] = $val['outmoney_avg'];
        }

        // $title = array('日期','站点','入账笔数', '入账金额','平均单笔入账', '出账笔数', '出账金额','平均单笔出账');

        if(is_array($data) && empty($data)) returnJson('402','当前条件下无数据可导出'); 

        $csvpath = APPPATH.'cache/excel/c2c'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '入账笔数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '入账金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '平均单笔入账' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '出账笔数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '出账金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '平均单笔出账' ),
        );
        fputcsv( $handle, $header );
        foreach($data as $value){
            $fields =   [           
                            $value['time_area'],              
                            $value['name'],              
                            $value['inmoney_count'],   
                            $value['inmoney'],   
                            $value['inmoney_avg'], 
                            $value['outmoney_count'],   
                            $value['outmoney'],
                            $value['outmoney_avg'],  
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);       
        $filePath = strstr($csvpath,'application');        
        $oss = new \App\Helpers\oss_helper();       
        $data1['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data1);
    }




    //获取时间段内bank_inout表中状态为2 和 状态为 5的记录
    public function get_inmoney($start_time,$end_time,$site_id)
    {
        // $site_id = 1;
        // $start_time = '2018-08-31';
        // $end_time = '2018-12-01';

        $object = $this->db->select("bank_inout.amount")
        // $object = $this->db->select("count(bank_inout.id) as inmoney_count,sum(`amount`) as amount")
        ->from('bank_inout');
        $object =$this->db->where('bank_inout.site_id =',$site_id);
        $object =$this->db->where('bank_inout.type =',1);
        if(!empty($start_time)){
            $object =$this->db->where('bank_inout.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('bank_inout.created_at <=',$end_time);
        }
        $result = $object->get()->result_array();
        // var_dump($this->db->last_query());
        // var_dump($result);die;
        if(is_array($result) && !empty($result)){
            $res = array('amount'=>'0');
            foreach ($result as $key => $value) {
                $res['amount'] = bcadd($res['amount'] , $value['amount']);
                // $res['amount'] = $res['amount'] + str_replace(',', '', $value['amount']);
            }
            $res['inmoney_count'] = count($result);
        }else{
            $res['inmoney_count'] = '0';
            $res['amount'] = '0';
        }
        return $res;
    }


    //获取时间段内bank_inout表中状态为2 和 状态为 5的记录
    public function get_outmoney($start_time,$end_time,$site_id)
    {
        $object = $this->db->select("count(c2c_orders.id) as outmoney_count,sum(`real_amount`) as amount")
        ->from('c2c_orders');
        $object =$this->db->where('c2c_orders.site_id =',$site_id);
        $object =$this->db->where('c2c_orders.type =',2); //卖出类型
        $object =$this->db->where('c2c_orders.status =',3); //已完成状态
        if(!empty($start_time)){
            $object =$this->db->where('c2c_orders.updated_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('c2c_orders.updated_at <=',$end_time);
        }
        return $object->get()->result_array();
    }



}
