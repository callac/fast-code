<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Logs_service extends MY_Service {


    public function __construct()
    {
        parent::__construct();
        $this->load->model('Logs_model');
    }
    public function add_logs($user_id,$priv_id,$desc,$time,$ip,$site_id){
        $this->Logs_model->add_logs($user_id,$priv_id,$desc,$time,$ip,$site_id);
    }

}