<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_recharge_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Account_capital_racharge_model');
        $this->load->model('Account_capital_withdraw_model');
        $this->load->model('Security_bulid_hash_model');
        $this->load->model('User_capital_model');
        $this->load->model('User_model');
        $this->load->model('Zjys_recharge_logs_model');
        $this->load->service('Sys_grpc_service');
    }   

    /**
     * 充值列表加搜索
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     *
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      每页条数
     * @param    [type]       $name       关键词
     * @param    [type]       $start_time 开始时间
     * @param    [type]       $end_time   结束时间
     * @param    [type]       $site_id    站点id
     * @return   [type]                   [description]
     */
    public function recharge_list($offset,$limit,$name,$start_time,$end_time,$asset,$site_id,$uid,$status){
        $object = $this->db->select("user_recharge_logs.*,users.email,users.phone,users.realname as name,b_site.name as site_name")
            ->from('user_recharge_logs')
            // ->join('user_identities','user_identities.user_id=user_recharge_logs.user_id','left')
            ->join('users','users.id=user_recharge_logs.user_id','left')
            ->join('b_site','b_site.id=users.site_id','left');

        // $object =$this->db->where('user_identities.deleted_at is null');

        
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }
        if(!empty($asset)){
            $object =$this->db->where('user_recharge_logs.asset =',$asset);
        }
        if(!empty($status)){
            $object =$this->db->where('user_recharge_logs.status =',$status);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_logs.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_logs.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        return $list;
    }





    public function recharge_address_list($offset,$limit,$name,$start_time,$end_time,$asset,$site_id,$uid,$address){
        $object = $this->db->select("user_recharge_addresses.*,users.email,users.phone,b_site.name as site_name")
            ->from('user_recharge_addresses')
            //->join('user_identities','user_identities.user_id=user_recharge_addresses.user_id','left')
            ->join('users','users.id=user_recharge_addresses.user_id','left')
            ->join('b_site','b_site.id=users.site_id','left');


        // $object =$this->db->where('user_identities.deleted_at is null'); //实名过的

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($asset)){
            $object =$this->db->where('user_recharge_addresses.asset =',$asset);
        }
        if(!empty($address)){
            $object =$this->db->where('user_recharge_addresses.address =',$address);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_addresses.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_addresses.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        // foreach ($list as &$val) {
        //     if(!empty($val['phone'])) $val['phone'] = substr_replace($val['phone'],'****', 3,4);
        //     if(!empty($val['email'])) $val['email'] = substr_replace($val['email'],'****', 1,2);
        // }

        return $list;
    }


    public function recharge_list_count($name,$start_time,$end_time,$asset,$site_id,$uid,$status){
        $object = $this->db->select("user_recharge_logs.*,users.email,users.phone,users.realname as name")
            ->from('user_recharge_logs')
            // ->join('user_identities','user_identities.user_id=user_recharge_logs.user_id','left')
            ->join('users','users.id=user_recharge_logs.user_id','left')
            ->join('b_site','b_site.id=users.site_id','left');

        // $object =$this->db->where('user_identities.deleted_at is null'); //实名过的

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }
        if(!empty($status)){
            $object =$this->db->where('user_recharge_logs.status =',$status);
        }
        if(!empty($asset)){
            $object =$this->db->where('user_recharge_logs.asset =',$asset);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_logs.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_logs.created_at <',$end_time);
        }        
        return $this->db->count_all_results();
    }


    public function recharge_address_list_count($name,$start_time,$end_time,$asset,$site_id,$uid,$address)
    {
        $object = $this->db->select("user_recharge_addresses.*,users.email,users.phone")
            ->from('user_recharge_addresses')

            //->join('user_identities','user_identities.user_id=user_recharge_addresses.user_id','left')
            ->join('users','users.id=user_recharge_addresses.user_id','left')
            ->join('b_site','b_site.id=users.site_id','left');
       // $object =$this->db->where('user_identities.status =',2); //实名过的

        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }


        if(!empty($asset)){
            $object =$this->db->where('user_recharge_addresses.asset =',$asset);
        }
        if(!empty($address)){
            $object =$this->db->where('user_recharge_addresses.address =',$address);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_recharge_addresses.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_recharge_addresses.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 审核
     * User: 张哲
     * Date: 2018/12/20
     * Time: 10:41
     */
    public function recharge_review($args){
        $status = 1;
        $data = $this->Sys_grpc_service->VerifyRecharge(intval($args['recharge_id']),$status);
        if($data == true){
            $status = 1;
            $this->Zjys_recharge_logs_model->recharge_review($args['recharge_id'],$status);
            return true;
        }else {
            $status = 3;
             $this->Zjys_recharge_logs_model->recharge_review($args['recharge_id'],$status);
            return false;
        }


    }
}
