<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//set_time_limit(0);
//ini_set('memory_limit','2048M');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/1/4
 * Time: 16:20
 */
global  $machine_id;
$machine_id = 2;
$GLOBALS['$machine_id'] = $machine_id;

class Data_visualization_service extends MY_Service
{


    public function __construct()
    {
        parent::__construct();

        $this->load->model('Data_visualzation_model');
        $this->load->model('Zjys_user_model');
        $this->load->model('Zjys_c2corder_model');
        $this->load->model('Zjys_assets_model');
        $this->load->model('Zjys_recharge_logs_model');
        $this->load->model('Zjys_user_withdraw_model');
        $this->load->model('Zjys_symbols_model');
        $this->load->model('User_truename_valid_model');
        //$this->trade_db = $this->load->database('trade_history',true);
    }


    /**
     * Notes: 处理交易对
     * User: 张哲
     * Date: 2019-04-17
     * Time: 14:53
     * @param $symbol
     * @return mixed
     */
    function symbol_combine($symbol){

        $ci =& get_instance();
        //$symbol = trim(strrchr($symbol, '_'));

        $symbol_last =  substr($symbol,strripos($symbol,"_")+1); //后
        $symbol_fir =  substr($symbol,0,strripos($symbol,"_")); //前

        if ($symbol_last == $ci->config->item('C2C_ASSET')) {
            $price_trans = get_market_last($symbol);
        } else {
            $price_trans = get_market_last($symbol_fir . '_' . $ci->config->item('C2C_ASSET'));
        }
        return $price_trans;

    }


    /**
     * Notes: 实时数据定时任务
     * User: 张哲
     * Date: 2019-04-16
     * Time: 17:22
     */
    public function real_data_time()
    {
        $tongi_arr = $this->get_tongji_config_by_type(TONGJI_TYPE_COIN_POSITION);
        if(count($tongi_arr) == 0){
            $tongi_arr = 0;
        }else{
            $tongi_arr = implode(',',$tongi_arr);
        }



        //按站点、时间来
        $siteList = $this->Site_model->site_all();
        //  var_dump($siteList);die;
        $end_time = time();
        $start_time = $end_time - 3600;
        foreach ($siteList as $site) {
            $site_id = $site['id'];
            $DB1 = $this->load->database('trade_history', true);
//            $start_time = strtotime('yesterday') + 86400;
//            $end_time = time();
//            $yesterday_start_time = strtotime('yesterday');
//            $yesterday_end_time = $end_time - 86400;

            $sum = 0;
            $amount = 0;
            $bid_fee = 0;
            $ask_fee = 0;
            $res = array();
            //按天来，从币币交易表获取数据，需要换算每个交易对对饮币种的价格换算成法币

            for ($i = 0; $i < 100; $i++) {
                //交易用户、交易金额
                $sql = "select market,count(distinct user_id) as count,sum(deal_stock) as amount from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and  source='web,".$site_id."' and user_id not in($tongi_arr) ";
                $object = object_to_array($DB1->query($sql)->result());
                $new = array_merge(array(), $object);
                $sum += $new[0]['count'];
                $deal_stock = $new[0]['amount'];
                $market = $new[0]['market'];
                $price = $this->symbol_combine($market);
                $amount += intval($deal_stock) * intval($price);


                //BID手续费  bid为交易对前者的手续费
                $sql_bid = "select market,sum(deal_fee) as bid_fee from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and side = 2  and  source='web," . $site_id . "' and user_id not in($tongi_arr) ";
                $object_bid = object_to_array($DB1->query($sql_bid)->result());
                $new_bid = array_merge(array(), $object_bid);
                $bid_fee = $new_bid[0]['bid_fee'];
                $market1 = $new_bid[0]['market'];
                $price1 = $this->symbol_combine($market1);
                $bid_fee += intval($bid_fee) * intval($price1);


                //ASK手续费
                $sql_ask = "select market,sum(deal_fee) as ask_fee from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and side = 1 and  source='web," . $site_id . "' and user_id not in($tongi_arr) ";
                $object_ask = object_to_array($DB1->query($sql_ask)->result());
                $new_ask = array_merge(array(), $object_ask);

                $ask_fee = $new_ask[0]['ask_fee'];
                $market2 = $new_ask[0]['market'];
                $price2 = $this->symbol_combine($market2);
                $ask_fee += intval($ask_fee) * intval($price2);


            }

            $res['sum'] = $sum;

            $res['amount'] = $amount;

            $res['bid_fee'] = $bid_fee;

            $res['ask_fee'] = $ask_fee;

            $res['site_id'] = $site_id;


            //注册用户
            $user = $this->Zjys_user_model->real_data_user($start_time, $end_time,$site_id);
            if (empty($user['count'])) $user['count'] = 0;
            $res['user_count'] = $user['count'];

            //认证用户
            $identities = $this->Zjys_user_model->real_data_identities($start_time, $end_time,$site_id);
            if (empty($identities['count'])) $identities['count'] = 0;
            $res['identities_count'] = $identities['count'];

            //C2C买入
            $c2c_buy = $this->Zjys_c2corder_model->real_data_c2c_order($start_time, $end_time, 1,$site_id);
            if (empty($c2c_buy['count'])) $c2c_buy['count'] = 0;
            $res['c2c_buy_count'] = $c2c_buy['count'];

            //C2C买入
            $c2c_sale = $this->Zjys_c2corder_model->real_data_c2c_order($start_time, $end_time, 2,$site_id);
            if (empty($c2c_sale['count'])) $c2c_sale['count'] = 0;
            $res['c2c_sale_count'] = $c2c_sale['count'];


            $created_at = date("Y-m-d H:i:s", time());
            $start_time1 = date("Y-m-d H:i:s", $start_time);
            $end_time1 = date("Y-m-d H:i:s", $end_time);
            $res ['created_at'] = $created_at;
            $res ['start_time'] = $start_time1;
            $res ['end_time'] = $end_time1;
             //var_dump($res);die();
            //新增
            $this->db->insert('user_real_data', $res);
            // return $res;
        }
    }


    /**
     * Notes: 实时数据
     * User: 张哲
     * Date: 2019-04-16
     * Time: 17:22
     */
    public function real_data($site_id)
    {
        $data = array();
        $start_time1 = strtotime('yesterday') + 86400;
        $start_time = date("Y-m-d H:i:s", $start_time1);
        $end_time1 = $start_time1 + 86400;
        $end_time = date("Y-m-d H:i:s", $end_time1);


        $yesterday_start_time1 = strtotime('yesterday');
        $yesterday_start_time = date("Y-m-d H:i:s", $yesterday_start_time1);
        $yesterday_end_time1 = $end_time1 - 86400;
        $yesterday_end_time = date("Y-m-d H:i:s", $yesterday_end_time1);

        $object = $this->db->select("sum(sum) as sum,sum(amount) as amount,sum(bid_fee) as bid_fee,sum(ask_fee) as ask_fee,sum(user_count) as user_count,sum(identities_count) as identities_count,sum(c2c_buy_count) as c2c_buy_count,sum(c2c_sale_count) as c2c_sale_count")
            ->from('user_real_data');

        $object = $this->db->where('user_real_data.deleted_at is null');

        if (!empty($start_time)) {
            $object = $this->db->where('user_real_data.created_at >=', $start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('user_real_data.created_at <', $end_time);
        }

        if (!empty($order_no)) {
            $object = $this->db->where('user_real_data.site_id =', $site_id);
        }
        $list = $object->order_by('created_at', 'desc')->get()->result_array();
        if(empty($list[0]['sum'])){
            $sum = 0;
            $amount = 0;
            $bid_fee = 0;
            $ask_fee = 0;
            $user_count = 0;
            $identities_count = 0;
            $c2c_buy_count = 0;
            $c2c_sale_count = 0;
        }else{
            $sum = $list[0]['sum'];
            $amount = $list[0]['amount'];
            $bid_fee = $list[0]['bid_fee'];
            $ask_fee = $list[0]['ask_fee'];
            $user_count = $list[0]['user_count'];
            $identities_count  = $list[0]['identities_count'];
            $c2c_buy_count = $list[0]['c2c_buy_count'];
            $c2c_sale_count = $list[0]['c2c_sale_count'];
        }

        $object = $this->db->select("sum(sum) as sum,sum(amount) as amount,sum(bid_fee) as bid_fee,sum(ask_fee) as ask_fee,sum(user_count) as user_count,sum(identities_count) as identities_count,sum(c2c_buy_count) as c2c_buy_count,sum(c2c_sale_count) as c2c_sale_count")
            ->from('user_real_data');

        $object = $this->db->where('user_real_data.deleted_at is null');

        if (!empty($start_time)) {
            $object = $this->db->where('user_real_data.created_at >=', $yesterday_start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('user_real_data.created_at <', $yesterday_end_time);
        }

        if (!empty($order_no)) {
            $object = $this->db->where('user_real_data.site_id =', $site_id);
        }
        $list_yes = $object->order_by('created_at', 'desc')->get()->result_array();
        if(empty($list_yes[0]['sum'])){
            $yesterday_sum = 0;
            $yesterday_amount = 0;
            $yesterday_bid_fee = 0;
            $yesterday_ask_fee = 0;
            $yesterday_user_count = 0;
            $yesterday_identities_count = 0;
            $yesterday_c2c_buy_count = 0;
            $yesterday_c2c_sale_count = 0;
        }else{
            $yesterday_sum = $list_yes[0]['sum'];
            $yesterday_amount = $list_yes[0]['amount'];
            $yesterday_bid_fee = $list_yes[0]['bid_fee'];
            $yesterday_ask_fee = $list_yes[0]['ask_fee'];
            $yesterday_user_count = $list_yes[0]['user_count'];
            $yesterday_identities_count = $list_yes[0]['identities_count'];
            $yesterday_c2c_buy_count = $list_yes[0]['c2c_buy_count'];
            $yesterday_c2c_sale_count = $list_yes[0]['c2c_sale_count'];
        }

        $sum_pro = round(floatval(($sum - $yesterday_sum) / $sum* 100), 2) . '%';
        $amount_pro = round(floatval(($amount - $yesterday_amount) / $amount* 100), 2) . '%';
        $bid_fee_pro = round(floatval(($bid_fee - $yesterday_bid_fee) / $bid_fee* 100), 2) . '%';
        $ask_fee_pro = round(floatval(($ask_fee - $yesterday_ask_fee) / $ask_fee* 100), 2) . '%';
        $user_count_pro = round(floatval(($user_count - $yesterday_user_count) / $user_count* 100), 2) . '%';
        $identities_count_pro = round(floatval(($identities_count - $yesterday_identities_count) / $identities_count* 100), 2) . '%';
        $c2c_buy_count_pro = round(floatval(($c2c_buy_count - $yesterday_c2c_buy_count) / $c2c_buy_count* 100), 2) . '%';
        $c2c_sale_count_pro = round(floatval(($c2c_sale_count - $yesterday_c2c_sale_count) / $c2c_sale_count* 100), 2) . '%';


        $data['sum'] = $sum;
        $data['sum_pro'] = $sum_pro;
        $data['amount'] = $amount;
        $data['amount_pro'] = $amount_pro;
        $data['bid_fee'] = $bid_fee;
        $data['bid_fee_pro'] = $bid_fee_pro;
        $data['ask_fee'] = $ask_fee;
        $data['ask_fee_pro'] = $ask_fee_pro;
        $data['user_count'] = $user_count;
        $data['user_count_pro'] = $user_count_pro;
        $data['identities_count'] = $identities_count;
        $data['identities_count_pro'] = $identities_count_pro;
        $data['c2c_buy_count'] = $c2c_buy_count;
        $data['c2c_buy_count_pro'] = $c2c_buy_count_pro;
        $data['c2c_sale_count'] = $c2c_sale_count;
        $data['c2c_sale_count_pro'] = $c2c_sale_count_pro;
        return $data;

    }

    /**
     * Notes: 实时数据曲线图
     * User: 张哲
     * Date: 2019/1/9
     * Time: 12:56
     * @param $args
     */
    public function real_draw($site_id)
    {
        $data = array();
        $start_time = strtotime('yesterday') + 86400;
        $end_time = $start_time + 86400;
        $yesterday_start_time = strtotime('yesterday');
        $yesterday_end_time = $end_time - 86400;
        $user_arr = array();
        $yesterday_user_arr = array();
        $cishu = ($end_time - $start_time) / 7200;

        for ($j = 0; $j < $cishu; $j++) {
            $one_time1 = $start_time + 7200 * ($j);
            $one_time = date("Y-m-d H:i:s", $one_time1);
            $two_time = $one_time1 + 7200;
            $two_time = date("Y-m-d H:i:s", $two_time);

            $object = $this->db->select("sum(sum) as sum,sum(amount) as amount,sum(bid_fee) as bid_fee,sum(ask_fee) as ask_fee,sum(user_count) as user_count,sum(identities_count) as identities_count,sum(c2c_buy_count) as c2c_buy_count,sum(c2c_sale_count) as c2c_sale_count")
                ->from('user_real_data');

            $object = $this->db->where('user_real_data.deleted_at is null');

            if (!empty($start_time)) {
                $object = $this->db->where('user_real_data.created_at >=', $one_time);
            }

            if (!empty($end_time)) {
                $object = $this->db->where('user_real_data.created_at <', $two_time);
            }

            if (!empty($order_no)) {
                $object = $this->db->where('user_real_data.site_id =', $site_id);
            }
            $list = $object->order_by('created_at', 'desc')->get()->result_array();
            if(!empty($list[0]['sum'])){
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['time1'] = $two_time;
                $user_arr[$j]['sum'] = $list[0]['sum'];
                $user_arr[$j]['amount'] = $list[0]['amount'];
            }else{
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['time1'] = $two_time;
                $user_arr[$j]['sum'] = 0;
                $user_arr[$j]['amount'] = 0;
            }


        }

        foreach ($user_arr as $key => $value){
            $now_time = strtotime($value['time']);
            $now_time1 = strtotime($value['time1']);
            $draw_arr[$key]['time'] = $now_time;
            $draw_arr[$key]['time1'] = $now_time1;
            $draw_arr[$key]['sum'] = $value['sum'];
            $draw_arr[$key]['amount'] = $value['amount'];
        }


        for ($j = 0; $j < 12; $j++) {
            $one_time1 = $yesterday_start_time + 7200 * ($j);
            $one_time = date("Y-m-d H:i:s", $one_time1);
            $two_time = $one_time1 + 7200;
            $two_time = date("Y-m-d H:i:s", $two_time);

            $object = $this->db->select("sum(sum) as sum,sum(amount) as amount,sum(bid_fee) as bid_fee,sum(ask_fee) as ask_fee,sum(user_count) as user_count,sum(identities_count) as identities_count,sum(c2c_buy_count) as c2c_buy_count,sum(c2c_sale_count) as c2c_sale_count")
                ->from('user_real_data');

            $object = $this->db->where('user_real_data.deleted_at is null');

            if (!empty($start_time)) {
                $object = $this->db->where('user_real_data.created_at >=', $one_time);
            }

            if (!empty($end_time)) {
                $object = $this->db->where('user_real_data.created_at <', $two_time);
            }

            if (!empty($order_no)) {
                $object = $this->db->where('user_real_data.site_id =', $site_id);
            }
            $list_yes = $object->order_by('created_at', 'desc')->get()->result_array();
            if(!empty($list_yes[0]['sum'])){
                $yesterday_user_arr[$j]['time'] = $one_time;
                $yesterday_user_arr[$j]['time1'] = $two_time;
                $yesterday_user_arr[$j]['sum'] = $list_yes[0]['sum'];
                $yesterday_user_arr[$j]['amount'] = $list_yes[0]['amount'];
            }else{
                $yesterday_user_arr[$j]['time'] = $one_time;
                $yesterday_user_arr[$j]['time1'] = $two_time;
                $yesterday_user_arr[$j]['sum'] = 0;
                $yesterday_user_arr[$j]['amount'] = 0;
            }


        }

        foreach ($yesterday_user_arr as $key => $value){
            $now_time = strtotime($value['time']);
            $now_time1 = strtotime($value['time1']);
            $draw_arr[$key]['time'] = $now_time;
            $draw_arr[$key]['time1'] = $now_time1;
            $draw_arr[$key]['yesterday_sum'] = $value['sum'];
            $draw_arr[$key]['yesterday_amount'] = $value['amount'];
        }

        return $draw_arr;
    }


    /**
     * Notes: 用户总览
     * User: 张哲
     * Date: 2019/1/9
     * Time: 15:14
     */
    public function user_data($args){

        $site_id = $args['site_id'];
        $res = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));
        if (!empty($site_id)) {


            /**
             * 交易用户
             */
            $trade= $this->Data_visualzation_model->trade_user_amount($start_time, $end_time,$site_id);
            if (empty($trade['count'])) $trade['count'] = 0;
            $res['sum']  = $trade['count'];
            $trade_all= $this->Data_visualzation_model->trade_user_amount_all($site_id);
            if (empty($trade_all['count'])) $trade_all['count'] = 0;
            $res['sum_all']  = $trade_all['count'];

                /**
                 * 注册用户
                 */
                //注册用户
                $user = $this->Zjys_user_model->real_data_user($start_time, $end_time,$site_id);
                //累计用户
                $user_all = $this->Zjys_user_model->real_data_user_all($site_id);
                if (empty($user['count'])) $user['count'] = 0;
                if (empty($user_all['count'])) $user_all['count'] = 0;
                $res['user_count'] = $user['count'];
                $res['user_count_all'] = $user_all['count'];

                /**
                 * 认证用户
                 */
                //认证用户
                $identities = $this->Zjys_user_model->real_data_identities($start_time, $end_time,$site_id);
                //累计认证用户
                $identities_all = $this->Zjys_user_model->real_data_identities_all($site_id);
                if (empty($identities['count'])) $identities['count'] = 0;
                if (empty($identities_all['count'])) $identities_all['count'] = 0;

                $res['identities_count'] = $identities['count'];
                $res['identities_count_all'] = $identities_all['count'];

                /**
                 * C2C买入
                 */
                //C2C买入
                $c2c_buy = $this->Zjys_c2corder_model->c2c_order_time($start_time, $end_time, $site_id);
                //累计C2C买入
                $c2c_buy_all = $this->Zjys_c2corder_model->c2c_order_all($site_id);
                //var_dump($c2c_buy,$c2c_buy_all);die();
                if (empty($c2c_buy['c2c_amount'])) $c2c_buy['c2c_amount'] = 0;
                if (empty($c2c_buy_all['c2c_amount'])) $c2c_buy_all['c2c_amount'] = 0;
                $res['c2c_buy_count'] = $c2c_buy['c2c_amount'];
                $res['c2c_buy_count_all'] = $c2c_buy_all['c2c_amount'];

                /**
                 * C2C卖出
                 */
                //C2C卖出
                $c2c_sale = $this->Zjys_c2corder_model->c2c_order_sell($start_time, $end_time, $site_id);
                //累计C2C卖出
                $c2c_sale_all = $this->Zjys_c2corder_model->c2c_order_all_sell($site_id);
                //var_dump($c2c_buy,$c2c_buy_all);die();
                if (empty($c2c_sale['c2c_amount'])) $c2c_sale['c2c_amount'] = 0;
                if (empty($c2c_sale_all['c2c_amount'])) $c2c_sale_all['c2c_amount'] = 0;
                $res['c2c_sale_count'] = $c2c_sale['c2c_amount'];
                $res['c2c_sale_count_all'] = $c2c_sale_all['c2c_amount'];


        } else {
            /**
             * 交易用户
             */
            $trade= $this->Data_visualzation_model->trade_user_amount_no($start_time,$end_time);
            $trade_all= $this->Data_visualzation_model->trade_user_amount_all_no();

            if($trade['count'] === null){
                $res['sum']  = 0;
            }else{
                $res['sum']  = $trade['count'];
            }

            if($trade_all['count'] === null){
                $res['sum_all']  = 0;
            }else{
                $res['sum_all']  = $trade_all['count'];
            }

                /**
                 * 注册用户
                 */
                //注册用户
                $user = $this->Zjys_user_model->real_data_user1($start_time, $end_time);
                //累计用户
                $user_all = $this->Zjys_user_model->real_data_user_all1();
                if (empty($user['count'])) $user['count'] = 0;
                if (empty($user_all['count'])) $user_all['count'] = 0;
                $res['user_count'] = $user['count'];
                $res['user_count_all'] = $user_all['count'];

                /**
                 * 认证用户
                 */
                //认证用户
                $identities = $this->Zjys_user_model->real_data_identities1($start_time, $end_time);
                //累计认证用户
                $identities_all = $this->Zjys_user_model->real_data_identities_all1();
                if (empty($identities['count'])) $identities['count'] = 0;
                if (empty($identities_all['count'])) $identities_all['count'] = 0;

                $res['identities_count'] = $identities['count'];
                $res['identities_count_all'] = $identities_all['count'];

                /**
                 * C2C买入
                 */
                //C2C买入
                $c2c_buy = $this->Zjys_c2corder_model->c2c_order_time1($start_time, $end_time);
                //累计C2C买入
                $c2c_buy_all = $this->Zjys_c2corder_model->c2c_order_all1();
                //var_dump($c2c_buy,$c2c_buy_all);die();
                if (empty($c2c_buy['c2c_amount'])) $c2c_buy['c2c_amount'] = 0;
                if (empty($c2c_buy_all['c2c_amount'])) $c2c_buy_all['c2c_amount'] = 0;
                $res['c2c_buy_count'] = $c2c_buy['c2c_amount'];
                $res['c2c_buy_count_all'] = $c2c_buy_all['c2c_amount'];

                /**
                 * C2C卖出
                 */
                //C2C卖出
                $c2c_sale = $this->Zjys_c2corder_model->c2c_order_sell1($start_time, $end_time);
                //累计C2C卖出
                $c2c_sale_all = $this->Zjys_c2corder_model->c2c_order_all_sell1();
                if (empty($c2c_sale['c2c_amount'])) $c2c_sale['c2c_amount'] = 0;
                if (empty($c2c_sale_all['c2c_amount'])) $c2c_sale_all['c2c_amount'] = 0;
                $res['c2c_sale_count'] = $c2c_sale['c2c_amount'];
                $res['c2c_sale_count_all'] = $c2c_sale_all['c2c_amount'];

        }
        return $res;
    }

    /**
     * Notes:  用户总揽-曲线
     * User: 张哲
     * Date: 2019/1/10
     * Time: 16:43
     * @param $args
     * @return array
     */
    public function user_data_draw($args)
    {

        $site_id = $args['site_id'];
        $res = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time - 29*86400;
            //$end_time = $start_time + 86400;

            $frequency = 30;
        }else if($args['type'] == 2) {
            //mktime 为上周起始时间戳
            $end_time =  $check_time + 86400;
            $start_time = $end_time - 86400*7*11;

            $frequency = 12;
        }else if($args['type'] == 3){
            $cyear = floor(date("Y",$args['time']));
            $cMonth = floor(date("m",$args['time']));
            $frequency = 6;
        }

        $draw_arr = array();
        $user_arr = array();
        if(!empty($site_id)){
            /**
             * 交易用户
             */


            for ($j = 0; $j < $frequency; $j++) {

                if($args['type'] == 1){
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                }else if($args['type'] == 2){
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400*7;
                }else if($args['type'] == 3){
                    $nMonth = $cMonth-$j;
                    $cyear = $nMonth == 0 ? ($cyear-1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12+$nMonth : $nMonth;
                    $date = $cyear."-".$nMonth."-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));
                    $one_time =strtotime( $firstday." 00:00:00") ;
                    $two_time = strtotime($lastday." 00:00:00");
                }

                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                /**
                 * 交易用户
                 */
                $trade= $this->Zjys_user_model->trade_user_amount($one_time,$two_time,$site_id);
                if (empty($trade['count'])) $trade['count'] = 0;
                $user_trade  = $trade['count'];

                /**
                 * 注册用户
                 */
                $user= $this->Zjys_user_model->real_data_user($one_time, $two_time,$site_id);
                if (empty($user['count'])) $user['count'] = 0;
                //$res['user_register'] = $user['count'];
                $user_register  = $user['count'];
                /**
                 * 认证用户
                 */
                $identities = $this->Zjys_user_model->real_data_identities($one_time, $two_time,$site_id);
                if (empty($identities['count'])) $identities['count'] = 0;
                //$res['user_identities'] = $identities['count'];
                $user_identities = $identities['count'];

                /**
                 * C2C买入
                 */
                $c2c_buy = $this->Zjys_c2corder_model->c2c_order_time($one_time, $two_time, $site_id);
                if (empty($c2c_buy['c2c_amount'])) $c2c_buy['c2c_amount'] = 0;
                //$res['c2c_buy_count'] = $c2c_buy['c2c_amount'];
                $c2c_buy_count = $c2c_buy['c2c_amount'];


                /**
                 * C2C卖出
                 */
                $c2c_sale = $this->Zjys_c2corder_model->c2c_order_sell($one_time, $two_time,$site_id);
                if (empty($c2c_sale['c2c_amount'])) $c2c_sale['c2c_amount'] = 0;
                //$res['c2c_sale_count'] = $c2c_sale['c2c_amount'];
                $c2c_sale_count = $c2c_sale['c2c_amount'];

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['time1'] = $two_time;
                $user_arr[$j]['user_trade'] = $user_trade;
                $user_arr[$j]['user_register'] = $user_register;
                $user_arr[$j]['user_identities'] = $user_identities;
                $user_arr[$j]['c2c_buy_count'] = $c2c_buy_count;
                $user_arr[$j]['c2c_sale_count'] = $c2c_sale_count;

            }


            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $now_time1 = strtotime($value['time1']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['time1'] = $now_time1;
                $draw_arr[$key]['user_trade'] = $value['user_trade'];
                $draw_arr[$key]['user_register'] = $value['user_register'];
                $draw_arr[$key]['user_identities'] = $value['user_identities'];
                $draw_arr[$key]['c2c_buy_count'] = $value['c2c_buy_count'];
                $draw_arr[$key]['c2c_sale_count'] = $value['c2c_sale_count'];
            }
        }else {
            /**
             * 交易用户
             */
            for ($j = 0; $j < $frequency; $j++) {

                if($args['type'] == 1){
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                }else if($args['type'] == 2){
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400*7;
                }else if($args['type'] == 3){
                    $nMonth = $cMonth-$j;
                    $cyear = $nMonth == 0 ? ($cyear-1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12+$nMonth : $nMonth;
                    $date = $cyear."-".$nMonth."-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));
                    $one_time =strtotime( $firstday." 00:00:00") ;
                    $two_time = strtotime($lastday." 00:00:00");
                }

                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                /**
                 * 交易用户
                 */
                $trade= $this->Zjys_user_model->trade_user_amount_no($one_time, $two_time);

                if (empty($trade['count'])) $trade['count'] = 0;
                $user_trade  = $trade['count'];


                /**
                 * 注册用户
                 */
                $user= $this->Zjys_user_model->real_data_user1($one_time, $two_time);
                if (empty($user['count'])) $user['count'] = 0;
                //$res['user_register'] = $user['count'];
                $user_register  = $user['count'];
                /**
                 * 认证用户
                 */
                $identities = $this->Zjys_user_model->real_data_identities1($one_time, $two_time);
                if (empty($identities['count'])) $identities['count'] = 0;
                //$res['user_identities'] = $identities['count'];
                $user_identities = $identities['count'];

                /**
                 * C2C买入
                 */
                $c2c_buy = $this->Zjys_c2corder_model->c2c_order_time1($one_time, $two_time);
                if (empty($c2c_buy['c2c_amount'])) $c2c_buy['c2c_amount'] = 0;
                //$res['c2c_buy_count'] = $c2c_buy['c2c_amount'];
                $c2c_buy_count = $c2c_buy['c2c_amount'];


                /**
                 * C2C卖出
                 */
                $c2c_sale = $this->Zjys_c2corder_model->c2c_order_sell1($one_time, $two_time);
                if (empty($c2c_sale['c2c_amount'])) $c2c_sale['c2c_amount'] = 0;
                //$res['c2c_sale_count'] = $c2c_sale['c2c_amount'];
                $c2c_sale_count = $c2c_sale['c2c_amount'];

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['time1'] = $two_time;
                $user_arr[$j]['user_trade'] = $user_trade;
                $user_arr[$j]['user_register'] = $user_register;
                $user_arr[$j]['user_identities'] = $user_identities;
                $user_arr[$j]['c2c_buy_count'] = $c2c_buy_count;
                $user_arr[$j]['c2c_sale_count'] = $c2c_sale_count;

            }


            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $now_time1 = strtotime($value['time1']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['time1'] = $now_time1;
                $draw_arr[$key]['user_trade'] = $value['user_trade'];
                $draw_arr[$key]['user_register'] = $value['user_register'];
                $draw_arr[$key]['user_identities'] = $value['user_identities'];
                $draw_arr[$key]['c2c_buy_count'] = $value['c2c_buy_count'];
                $draw_arr[$key]['c2c_sale_count'] = $value['c2c_sale_count'];
            }
        }

        if($args['type'] == 3){
            $draw_arr =   array_reverse($draw_arr);
            return $draw_arr;
        }else{
            return $draw_arr;
        }
    }


    /**
     * Notes: 币币交易
     * User: 张哲
     * Date: 2019/1/14
     * Time: 09:29
     * @param $args
     * @return array
     */
    public function trade_data($args){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $res = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time = $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }

        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));

        if (!empty($site_id)) {
            if(!empty($asset)){
                    /**
                     * 交易用户
                     */
                    $trade= $this->Data_visualzation_model->trade_asset_site_left($start_time, $end_time,$site_id,$asset);
                    $trade_all= $this->Data_visualzation_model->trade_asset_site_all_left($site_id,$asset);
                    $trade_right= $this->Data_visualzation_model->trade_asset_site_right($start_time, $end_time,$site_id,$asset);
                    $trade_all_right= $this->Data_visualzation_model->trade_asset_site_all_right($site_id,$asset);

                if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                if (empty($trade_right['trading_number'])) $trade_right['trading_number'] = 0;
                $res['sum']  = $trade['trading_number'] + $trade_right['trading_number'];
                if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                if (empty($trade_all_right['trading_number'])) $trade_all_right['trading_number'] = 0;
                $res['sum_all']  = $trade_all['trading_number'] + $trade_all_right['trading_number'];


                if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                if (empty($trade_right['trading_amount'])) $trade_right['trading_amount'] = 0;
                $res['amount']  = $trade['trading_amount'] + $trade_right['trading_amount'];
                $price = $this->symbol_combine($trade['symbols']);
                $res['amount'] = $res['amount'] * $price;
                if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                if (empty($trade_all_right['trading_amount'])) $trade_all_right['trading_amount'] = 0;
                $res['amount_all']  = $trade_all['trading_amount'] + $trade_all_right['trading_amount'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $res['amount_all'] = $res['amount_all'] * $price1;

            }else{

                /**
                 * 交易用户
                 */
                $trade= $this->Data_visualzation_model->trade_user_amount($start_time, $end_time,$site_id);
                $trade_all= $this->Data_visualzation_model->trade_user_amount_all($site_id);
                if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                $res['sum']  = $trade['trading_number'];
                if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                $res['sum_all']  = $trade_all['trading_number'];


                if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                $res['amount']  = $trade['trading_amount'];
                $price = $this->symbol_combine($trade['symbols']);
                $res['amount'] = $res['amount'] * $price;
                if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                $res['amount_all']  = $trade_all['trading_amount'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $res['amount_all'] = $res['amount_all'] * $price1;
            }
        } else {
            if(!empty($asset)) {

                $trade= $this->Data_visualzation_model->trade_asset_left($start_time, $end_time,$asset);
                $trade_all= $this->Data_visualzation_model->trade_asset_all_left($asset);
                $trade_right= $this->Data_visualzation_model->trade_asset_right($start_time, $end_time,$asset);
                $trade_all_right= $this->Data_visualzation_model->trade_asset_all_right($asset);

                if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                if (empty($trade_right['trading_number'])) $trade_right['trading_number'] = 0;
                $res['sum']  = $trade['trading_number'] + $trade_right['trading_number'];
                if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                if (empty($trade_all_right['trading_number'])) $trade_all_right['trading_number'] = 0;
                $res['sum_all']  = $trade_all['trading_number'] + $trade_all_right['trading_number'];

                if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                if (empty($trade_right['trading_amount'])) $trade_right['trading_amount'] = 0;
                $res['amount']  = $trade['trading_amount'] + $trade_right['trading_amount'];
                if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                $price = $this->symbol_combine($trade['symbols']);
                $res['amount'] = $res['amount'] * $price;
                if (empty($trade_all_right['trading_amount'])) $trade_all_right['trading_amount'] = 0;
                $res['amount_all']  = $trade_all['trading_amount'] + $trade_all_right['trading_amount'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $res['amount_all'] = $res['amount_all'] * $price1;
            }else{

                $trade= $this->Data_visualzation_model->trade_user_amount_no($start_time, $end_time);
                $trade_all= $this->Data_visualzation_model->trade_user_amount_all_no();

                if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                $res['sum']  = $trade['trading_number'];
                if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                $res['sum_all']  = $trade_all['trading_number'];


                if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                $res['amount']  = $trade['trading_amount'];
                $price = $this->symbol_combine($trade['symbols']);
                $res['amount'] = $res['amount'] * $price;
                if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                $res['amount_all']  = $trade_all['trading_amount'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $res['amount_all'] = $res['amount_all'] * $price1;
            }
        }
        return $res;
    }


    /**
     * Notes: 币币交易曲线
     * User: 张哲
     * Date: 2019/1/14
     * Time: 14:45
     * @param $args
     */
    public function trade_data_draw($args)
    {

        $site_id = $args['site_id'];
        $check_time = $args['time'] - 86400;
        if ($args['type'] == 1) {
            $start_time = $check_time - 29 * 86400;
            $end_time = $start_time + 86400;
            $frequency = 30;
        } else if ($args['type'] == 2) {
            $end_time =  $check_time + 86400;
            $start_time = $end_time - 86400*7*11;
            $frequency = 12;
        } else if ($args['type'] == 3) {
            $cyear = floor(date("Y", $args['time']));
            $cMonth = floor(date("m", $args['time']));
            $frequency = 6;
        }


        $draw_arr = array();
        if (!empty($site_id)) {
            /**
             * 交易订单/交易金额
             */
            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }

                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));

                if(!empty($asset)){
                    $trade= $this->Data_visualzation_model->trade_asset_site_left($one_time, $two_time,$site_id,$asset);
                    $trade_right= $this->Data_visualzation_model->trade_asset_site_right($one_time, $two_time,$site_id,$asset);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    if (empty($trade_right['trading_number'])) $trade_right['trading_number'] = 0;
                    $trade_amount  = $trade['trading_number'] + $trade_right['trading_number'];

                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    if (empty($trade_right['trading_amount'])) $trade_right['trading_amount'] = 0;
                    $trade_sum  = $trade['trading_amount'] + $trade_right['trading_amount'];
                    $price = $this->symbol_combine($trade['symbols']);
                    $res['amount'] = $trade_sum * $price;
                }else{

                    $trade= $this->Data_visualzation_model->trade_user_amount($one_time, $two_time,$site_id);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $trade_amount  = $trade['trading_number'];

                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    $trade_sum  = $trade['trading_amount'];
                    $price = $this->symbol_combine($trade['symbols']);
                    $res['amount'] = $trade_sum * $price;
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['trade_amount'] = $trade_amount;
                $user_arr[$j]['trade_sum'] = $trade_sum;
            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['trade_amount'] = $value['trade_amount'];
                $draw_arr[$key]['trade_sum'] = $value['trade_sum'];
            }
        }else{
            /**
             * 交易订单/交易金额
             */

            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400*7;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }

                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));

                if(!empty($asset)){
                    $trade= $this->Data_visualzation_model->trade_asset_left($one_time, $two_time,$asset);
                    $trade_right= $this->Data_visualzation_model->trade_asset_right($one_time, $two_time,$asset);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    if (empty($trade_right['trading_number'])) $trade_right['trading_number'] = 0;
                    $trade_amount  = $trade['trading_number'] + $trade_right['trading_number'];

                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    if (empty($trade_right['trading_amount'])) $trade_right['trading_amount'] = 0;
                    $trade_sum = $trade['trading_amount'] + $trade_right['trading_amount'];
                    $price = $this->symbol_combine($trade['symbols']);
                    $res['amount'] = $trade_sum * $price;
                }else{
                    $trade= $this->Zjys_user_model->trade_user_amount_no($one_time, $two_time);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $trade_amount  = $trade['trading_number'];

                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    $trade_sum  = $trade['trading_amount'];
                    $price = $this->symbol_combine($trade['symbols']);
                    $res['amount'] = $trade_sum * $price;
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['trade_amount'] = $trade_amount;
                $user_arr[$j]['trade_sum'] = $trade_sum;
            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['trade_amount'] = $value['trade_amount'];
                $draw_arr[$key]['trade_sum'] = $value['trade_sum'];
            }

        }
        if($args['type'] == 3){
            $draw_arr =   array_reverse($draw_arr);
            return $draw_arr;
        }else{
            return $draw_arr;
        }

    }

    /**
     * Notes: 交易手续费
     * User: 张哲
     * Date: 2019/1/14
     * Time: 15:29
     * @param $args
     * @return array
     */
    public function trade_fee_data($args){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $res = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));
        if (!empty($site_id)) {
            if(!empty($asset)){


                    $trade= $this->Data_visualzation_model->trade_asset_site_left($start_time, $end_time,$site_id,$asset);
                    $trade_right= $this->Data_visualzation_model->trade_asset_site_right($start_time, $end_time,$site_id,$asset);

                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    if (empty($trade_right['BID_fee'])) $trade_right['BID_fee'] = 0;
                    $res['bid_sum']  = $trade['BID_fee'] + $trade_right['BID_fee'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $res['bid_sum'] =  $res['bid_sum'] * $price1;

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    if (empty($trade_right['ASK_fee'])) $trade_right['ASK_fee'] = 0;
                    $res['ask_sum']  = $trade['ASK_fee'] + $trade_right['traASK_feeding_amount'];
                $price = $this->symbol_combine($trade['symbols']);
                $res['ask_sum'] =  $res['ask_sum'] * $price;


            }else{
                $trade= $this->Data_visualzation_model->trade_user_amount($start_time, $end_time,$site_id);

                if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                $res['bid_sum']  = $trade['BID_fee'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $res['bid_sum'] =  $res['bid_sum'] * $price1;

                if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                $res['ask_sum']  = $trade['ASK_fee'];
                $price = $this->symbol_combine($trade['symbols']);
                $res['ask_sum'] =  $res['ask_sum'] * $price;



            }
        } else {
            if(!empty($asset)) {
                $trade= $this->Data_visualzation_model->trade_asset_left($start_time, $end_time,$asset);

                $trade_right= $this->Data_visualzation_model->trade_asset_right($start_time, $end_time,$asset);


                if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                if (empty($trade_right['BID_fee'])) $trade_right['BID_fee'] = 0;
                $res['bid_sum']  = $trade['BID_fee'] + $trade_right['BID_fee'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $res['bid_sum'] =  $res['bid_sum'] * $price1;


                if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                if (empty($trade_right['ASK_fee'])) $trade_right['ASK_fee'] = 0;
                $res['ask_sum']  = $trade['ASK_fee'] + $trade_right['ASK_fee'];
                $price = $this->symbol_combine($trade['symbols']);
                $res['ask_sum'] =  $res['ask_sum'] * $price;


            }else{
                $trade= $this->Data_visualzation_model->trade_user_amount_no($start_time, $end_time);


                if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                $res['bid_sum']  = $trade['BID_fee'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $res['bid_sum'] =  $res['bid_sum'] * $price1;

                if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                $res['ask_sum']  = $trade['ASK_fee'];
                $price = $this->symbol_combine($trade['symbols']);
                $res['ask_sum'] =  $res['ask_sum'] * $price;

            }
        }
        return $res;
    }

    /**
     * Notes: 交易手续费曲线图
     * User: 张哲
     * Date: 2019/1/14
     * Time: 16:02
     * @param $args
     * @return array
     */
    public function trade_fee_data_draw($args)
    {

        $site_id = $args['site_id'];
        $check_time = $args['time'] - 86400;
        if ($args['type'] == 1) {
            $start_time = $check_time - 6 * 86400;
            $end_time = $start_time + 86400;
            $frequency = 7;
        } else if ($args['type'] == 2) {
            //mktime 为上周起始时间戳
//            $start_time = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1 - 7, date('Y')) - 86400 * 7 * 10;
//            $end_time = $args['time'] + 86400;
            $end_time =  $check_time + 86400;
            $start_time = $end_time - 86400*7*3;
            $frequency = 4;
        } else if ($args['type'] == 3) {
            $cyear = floor(date("Y", $args['time']));
            $cMonth = floor(date("m", $args['time']));
            $frequency = 3;
        }

        $draw_arr = array();
        if (!empty($site_id)) {
            /**
             * 交易订单/交易金额
             */
            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400*7;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                if(!empty($asset)){
                    $trade= $this->Data_visualzation_model->trade_asset_site_left($one_time, $two_time,$site_id,$asset);
                    $trade_right= $this->Data_visualzation_model->trade_asset_site_right($one_time, $two_time,$site_id,$asset);

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    if (empty($trade_right['ASK_fee'])) $trade_right['ASK_fee'] = 0;
                    $ask_sum  = $trade['ASK_fee'] + $trade_right['ASK_fee'];
                    $price1 = $this->symbol_combine($trade['symbols']);
                    $ask_sum =  $ask_sum * $price1;

                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    if (empty($trade_right['BID_fee'])) $trade_right['BID_fee'] = 0;
                    $bid_sum  = $trade['BID_fee'] + $trade_right['BID_fee'];
                    $price = $this->symbol_combine($trade['symbols']);
                    $bid_sum =  $bid_sum * $price;

                }else{
                    $trade= $this->Data_visualzation_model->trade_user_amount($one_time, $two_time,$site_id);
                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    $ask_sum  = $trade['ASK_fee'];
                    $price1 = $this->symbol_combine($trade['symbols']);
                    $ask_sum =  $ask_sum * $price1;

                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    $bid_sum  = $trade['BID_fee'];
                    $price = $this->symbol_combine($trade['symbols']);
                    $bid_sum =  $bid_sum * $price;
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['ask_sum'] = $ask_sum;
                $user_arr[$j]['bid_sum'] = $bid_sum;

            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['ask_sum'] = $value['ask_sum'];
                $draw_arr[$key]['bid_sum'] = $value['bid_sum'];
            }
        }else{
            /**
             * 交易订单/交易金额
             */

            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                if(!empty($asset)){
                    $trade= $this->Data_visualzation_model->trade_asset_left($one_time, $two_time,$asset);
                    $trade_right= $this->Data_visualzation_model->trade_asset_right($one_time, $two_time,$asset);

                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    if (empty($trade_right['BID_fee'])) $trade_right['BID_fee'] = 0;
                    $bid_sum  = $trade['BID_fee'] + $trade_right['BID_fee'];
                    $price1 = $this->symbol_combine($trade['symbols']);
                    $bid_sum =  $bid_sum * $price1;

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    if (empty($trade_right['ASK_fee'])) $trade_right['ASK_fee'] = 0;
                    $ask_sum = $trade['ASK_fee'] + $trade_right['ASK_fee'];
                    $price = $this->symbol_combine($trade['symbols']);
                    $ask_sum =  $ask_sum * $price;

                }else{
                    $trade= $this->Zjys_user_model->trade_user_amount_no($one_time, $two_time);
                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    $bid_sum  = $trade['BID_fee'];
                    $price1 = $this->symbol_combine($trade['symbols']);
                    $bid_sum =  $bid_sum * $price1;

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    $ask_sum  = $trade['ASK_fee'];
                    $price = $this->symbol_combine($trade['symbols']);
                    $ask_sum =  $ask_sum * $price;

                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['bid_sum'] = $bid_sum;
                $user_arr[$j]['ask_sum'] = $ask_sum;

            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['ask_sum'] = $value['ask_sum'];
                $draw_arr[$key]['bid_sum'] = $value['bid_sum'];
            }
        }
        if($args['type'] == 3){
            $draw_arr =   array_reverse($draw_arr);
            return $draw_arr;
        }else{
            return $draw_arr;
        }
    }


    /**
     * Notes: 排名
     * User: 张哲
     * Date: 2019/1/14
     * Time: 16:26
     * @param $args
     * @return array
     */
    public function trade_money_rank($args,$offset,$limit){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $res = array();
        $data_arr = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));

        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id(1);
        } else if(!empty($site_id)){
            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id($site_id);
        }else{
            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id1();
        }

        foreach ($symbolsList as $key => $value1) {
            $symbols = $value1['symbol'];
            if(empty($site_id)){
                /**
                 * 交易金额排名
                 */
                $trade= $this->Data_visualzation_model->trade_asset_symblos($start_time, $end_time,$symbols);

                if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                $deal_money = $trade['trading_amount'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $deal_money = $deal_money * $price1;
                $amount = $trade['trading_number'];

                $data_arr[$key]['symbol'] = $symbols;
                $data_arr[$key]['deal_money'] = $deal_money;
                $data_arr[$key]['amount'] = $amount;
            }else{
                /**
                 * 交易金额排名
                 */
                $trade= $this->Data_visualzation_model->trade_asset_site_symblos($start_time, $end_time,$site_id,$symbols);

                if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                $deal_money = $trade['trading_amount'];
                $price1 = $this->symbol_combine($trade['symbols']);
                $deal_money = $deal_money * $price1;
                $amount = $trade['trading_number'];

                $data_arr[$key]['symbol'] = $symbols;
                $data_arr[$key]['deal_money'] = $deal_money;
                $data_arr[$key]['amount'] = $amount;
            }


        }
        $distance = array();
        foreach ($data_arr as $key => $row) {
            $distance[$key] = $row['deal_money'];
        }
        if(is_array($distance)){
            array_multisort( $distance, SORT_DESC, $data_arr);
        }

        $data_arr = array_slice($data_arr,0,10);
        return $data_arr;
    }


    /**
     * Notes: 交易订单排名
     * User: 张哲
     * Date: 2019/1/16
     * Time: 16:03
     * @param $args
     * @param $offset
     * @param $limit
     * @return array
     */
    public function trade_order_rank($args,$offset,$limit){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $small = array();
        $res = array();
        $data_arr = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));
        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id(1);
        } else if(!empty($site_id)){
            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id($site_id);
        }else{
            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id1();
        }

        foreach ($symbolsList as $key => $value1) {
            $symbols = $value1['symbol'];

                if(empty($site_id)){
                    /**
                     * 交易订单排名
                     */
                    $trade= $this->Data_visualzation_model->trade_asset_symblos($start_time, $end_time,$symbols);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $order_count = $trade['trading_number'];

                    /**
                     * 放入数组
                     */
                    $res[$key]['symbol'] = $symbols;
                    $res[$key]['order_count'] = $order_count;
                }else{
                    /**
                     * 交易订单排名
                     */
                    $trade= $this->Data_visualzation_model->trade_asset_site_symblos($start_time, $end_time,$site_id,$symbols);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $order_count = $trade['trading_number'];

                    /**
                     * 放入数组
                     */
                    $res[$key]['symbol'] = $symbols;
                    $res[$key]['order_count'] = $order_count;
                }



        }
        $sum_order_all = 0;
        foreach ($res as $key => $value){
            $sum_order_all +=  $value['order_count'];
        }
        foreach ($res as $key => $value){
            $data_arr[$key]['symbol'] = $value['symbol'];
            $data_arr[$key]['order_count'] = $value['order_count'];
            if($sum_order_all == 0){
                $data_arr[$key]['order_count_pro'] = "0".'%';
            }else{
                $data_arr[$key]['order_count_pro'] = round($value['order_count']/$sum_order_all *100,2).'%';
            }
        }

        $distance = array();
        foreach ($data_arr as $key => $row) {
            $distance[$key] = $row['order_count'];
        }
        if(is_array($distance)){
            array_multisort( $distance, SORT_DESC, $data_arr);
        }
        $data_arr = array_slice($data_arr,0,10);
        return $data_arr;
    }

    /**
     * Notes: 交易用户排名
     * User: 张哲
     * Date: 2019/1/16
     * Time: 16:19
     */
    public function trade_user_rank($args,$offset,$limit){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $rank = $args['rank'];
        $res = array();
        $small = array();
        $data_arr = array();
        if($args['type'] == 1) {
            $start_time = $args['time'];
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $args['time'] - 86400*6;
            $end_time =  $args['time'] + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $args['time'] + 86400;
        }
//        if ($this->config->item('SITE') === 'priv_one') {
//            //获取所有币种
//            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id(1);
//        } else if(!empty($site_id)){
//            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id($site_id);
//        }else{
//            $symbolsList = $this->Zjys_symbols_model->get_symbols_by_site_id1();
//        }
        $DB1 = $this->load->database('trade_history', true);

                if (!empty($site_id)) {
                    if(!empty($asset)){
                        /**
                         * 交易用户排名
                         */
                        for ($i = 0; $i < 100; $i++) {
                            $sql = "select market,user_id,sum(deal_money) as deal_money,count(id) as trade_count from  order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and  source='web," . $site_id . "' and LEFT(market,length('" . $asset . "')) = '" . $asset . "' group by user_id ";
                            $object = object_to_array($DB1->query($sql)->result());
                            $new = array_merge(array(), $object);

                            $sql1 = "select market,user_id,sum(deal_money) as deal_money,count(id) as trade_count from  order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and  source='web," . $site_id . "' and RIGHT(market,length('" . $asset . "')) = '" . $asset . "' group by user_id ";
                            $object1 = object_to_array($DB1->query($sql1)->result());
                            $new1 = array_merge(array(), $object1);
                            $small = array_merge($new, $new1);

                        }
                        foreach ($small as $key => $value){
                            $data_arr[$key]['user_id'] = $value['user_id'];
                            $data_arr[$key]['deal_money'] = $value['deal_money'];
                            $data_arr[$key]['trade_count'] = $value['trade_count'];
                        }
                    }else{

                        /**
                         * 交易用户排名
                         */
                        for ($i = 0; $i < 100; $i++) {
                            $sql = "select market,user_id,sum(deal_money) as deal_money,count(id) as trade_count from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and  source='web," . $site_id . "'  group by user_id ";
                            $object = object_to_array($DB1->query($sql)->result());
                            $new = array_merge(array(), $object);
                            $small = array_merge($new);
                        }
                        foreach ($small as $key => $value){
                            $data_arr[$key]['user_id'] = $value['user_id'];
                            $data_arr[$key]['deal_money'] = $value['deal_money'];
                            $data_arr[$key]['trade_count'] = $value['trade_count'];
                        }
                    }
                } else {
                    if(!empty($asset)) {

                        /**
                         * 交易用户排名
                         */
                        for ($i = 0; $i < 100; $i++) {
                            $sql = "select  market,user_id,sum(deal_money) as deal_money,count(id) as trade_count from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and LEFT(market,length('" . $asset . "')) = '" . $asset . "' group by user_id ";
                            $object = object_to_array($DB1->query($sql)->result());
                            $new = array_merge(array(), $object);

                            $sql1 = "select  market,user_id,sum(deal_money) as deal_money,count(id) as trade_count from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and RIGHT(market,length('" . $asset . "')) = '" . $asset . "' group by user_id ";
                            $object1 = object_to_array($DB1->query($sql1)->result());
                            $new1 = array_merge(array(), $object1);
                            $small = array_merge($new, $new1);
                        }
                        foreach ($small as $key => $value){
                            $data_arr[$key]['user_id'] = $value['user_id'];
                            $data_arr[$key]['deal_money'] = $value['deal_money'];
                            $data_arr[$key]['trade_count'] = $value['trade_count'];
                        }
                    }else{

                        /**
                         *交易用户排名
                         */
                        for ($i = 0; $i < 100; $i++) {
                            $sql = "select  market,user_id,sum(deal_money) as deal_money,count(id) as trade_count from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . "  group by user_id ";
                            $object = object_to_array($DB1->query($sql)->result());
                            $new = array_merge(array(), $object);
                            $small = $new;
                        }
                        foreach ($small as $key => $value){
                            $data_arr[$key]['user_id'] = $value['user_id'];
                            $data_arr[$key]['deal_money'] = $value['deal_money'];
                            $data_arr[$key]['trade_count'] = $value['trade_count'];
                        }
                    }
                }
        if(!empty($data_arr)){
            $distance = array();
            if($rank == 1){
                foreach ($data_arr as $key => $row) {
                    $distance[$key] = $row['deal_money'];
                }
                if(is_array($distance)){
                    array_multisort( $distance, SORT_DESC, $data_arr);
                }

                $data_arr = array_slice($data_arr,0,10);
            }else if($rank == 2){
                //排序
                foreach ($data_arr as $key => $row) {
                    $distance[$key] = $row['trade_count'];
                }
                if(is_array($distance)){
                    array_multisort( $distance, SORT_DESC, $data_arr);
                }
                $data_arr = array_slice($data_arr,0,10);
            }
            return $data_arr;
        }else{
            return $data_arr;
        }

    }

    /**
     * Notes: 排名数量
     * User: 张哲
     * Date: 2019/1/14
     * Time: 17:32
     * @param $args
     * @return array
     */
    public function trade_rank_count($args){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $res = array();
        if($args['type'] == 1) {
            $start_time = $args['time'];
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $args['time'] - 86400*6;
            $end_time =  $args['time'] + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $args['time'] + 86400;
        }
        $DB1 = $this->load->database('trade_history', true);
        $count = 0; //ask总数
        if (!empty($site_id)) {
            if(!empty($asset)){
                for ($i = 0; $i < 100; $i++) {
                    /**
                     * 交易金额排名
                     */
                    $sql = "select count(*) as amount  from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and  source='web," . $site_id . "' and LEFT(market,3) = '".$asset."'  order by deal_money desc";
                    $object = object_to_array($DB1->query($sql)->result());
                    $new = array_merge(array(), $object);

                    $sql1 = "select count(*) as amount from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and  source='web," . $site_id . "' and RIGHT(market,3) = '".$asset."'  order by deal_money desc ";
                    $object1 = object_to_array($DB1->query($sql1)->result());
                    $new1 = array_merge(array(), $object1);
                    $count += $new[0]['amount'] + $new1[0]['amount'];
                }
                $res['count'] = intval($count);
            }else{
                for ($i = 0; $i < 100; $i++) {
                    /**
                     * 交易金额排名
                     */
                    //交易金额排名
                    $sql = "select count(*) as amount from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and  source='web," . $site_id . "' order by deal_money desc ";
                    $object = object_to_array($DB1->query($sql)->result());
                    $new = array_merge(array(), $object);
                    $count = $new[0]['amount'];

                }
                $res['count'] = intval($count);
            }
        } else {
            if(!empty($asset)) {
                for ($i = 0; $i < 100; $i++) {
                    /**
                     * 交易金额排名
                     */
                    //
                    $sql = "select count(*) as amount from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and LEFT(market,3) = '".$asset."'  order by deal_money desc";
                    $object = object_to_array($DB1->query($sql)->result());
                    $new = array_merge(array(), $object);

                    $sql1 = "select count(*) as amount from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . " and RIGHT(market,3) = '".$asset."'  order by deal_money desc ";
                    $object1 = object_to_array($DB1->query($sql1)->result());
                    $new1 = array_merge(array(), $object1);
                    $count += $new[0]['amount'] + $new1[0]['amount'];
                }
                $res['count'] = intval($count);

            }else{
                for ($i = 0; $i < 100; $i++) {
                    /**
                     * 交易金额排名
                     */
                    //交易金额排名
                    $sql = "select count(*) as amount from order_history_" . $i . "  where finish_time > " . $start_time . " and finish_time < " . $end_time . "  order by deal_money desc ";
                    $object = object_to_array($DB1->query($sql)->result());
                    $new = array_merge(array(), $object);
                    $count = $new[0]['amount'];
                }
                $res['count'] = intval($count);
            }
        }
        return $count;
    }


    /**
     * Notes: c2c交易
     * User: 张哲
     * Date: 2019/1/15
     * Time: 09:33
     * @param $args
     * @return array
     */
    public function trade_c2c_data($args){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $res = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time =$check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));
        if (!empty($site_id)) {
                /**
                 * C2C买入
                 */
                //C2C买入金额、买入订单、买入人数
                $c2c_buy = $this->Zjys_c2corder_model->c2c_trade_buy($start_time,$end_time,$site_id);
                if (empty($c2c_buy['user_count'])) $c2c_buy['user_count'] = 0;
                if (empty($c2c_buy['trade_count'])) $c2c_buy['trade_count'] = 0;
                if (empty($c2c_buy['amount_money'])) $c2c_buy['amount_money'] = 0;
                $res['trade_buy_count'] = $c2c_buy['trade_count'];
                $res['amount_buy_money'] = $c2c_buy['amount_money'];
                if($c2c_buy['user_count'] == 0){
                    $res['user_buy_ave'] = 0;
                }else{
                    $res['user_buy_ave'] = round($c2c_buy['amount_money'] / $c2c_buy['user_count'],2);
                }

                /**
                 * C2C卖出
                 */
                //C2C卖出金额、买入订单、买入人数
                $c2c_sale = $this->Zjys_c2corder_model->c2c_trade_sell($start_time,$end_time,$site_id);
                if (empty($c2c_sale['user_count'])) $c2c_sale['user_count'] = 0;
                if (empty($c2c_sale['trade_count'])) $c2c_sale['trade_count'] = 0;
                if (empty($c2c_sale['amount_money'])) $c2c_sale['amount_money'] = 0;
                $res['trade_sale_count'] = $c2c_sale['trade_count'];
                $res['amount_sale_money'] = $c2c_sale['amount_money'];
                if($c2c_sale['user_count'] == 0){
                    $res['user_sale_ave'] = 0;
                }else{
                    $res['user_sale_ave'] = round($c2c_sale['amount_money'] / $c2c_sale['user_count'],2);
                }

        } else {
                /**
                 * C2C买入
                 */
                //C2C买入金额、买入订单、买入人数
                $c2c_buy = $this->Zjys_c2corder_model->c2c_trade_buy_bol($start_time,$end_time,1);
                if (empty($c2c_buy['user_count'])) $c2c_buy['user_count'] = 0;
                if (empty($c2c_buy['trade_count'])) $c2c_buy['trade_count'] = 0;
                if (empty($c2c_buy['amount_money'])) $c2c_buy['amount_money'] = 0;
                $res['trade_buy_count'] = $c2c_buy['trade_count'];
                $res['amount_buy_money'] = $c2c_buy['amount_money'];
                if($c2c_buy['user_count'] == 0){
                    $res['user_buy_ave'] = 0;
                }else {
                    $res['user_buy_ave'] = round($c2c_buy['amount_money'] / $c2c_buy['user_count'], 2);
                }

                /**
                 * C2C卖出
                 */
                //C2C卖出金额、买入订单、买入人数
                $c2c_sale = $this->Zjys_c2corder_model->c2c_trade_sell_nol($start_time,$end_time,2);
                if (empty($c2c_sale['user_count'])) $c2c_sale['user_count'] = 0;
                if (empty($c2c_sale['trade_count'])) $c2c_sale['trade_count'] = 0;
                if (empty($c2c_sale['amount_money'])) $c2c_sale['amount_money'] = 0;
                $res['trade_sale_count'] = $c2c_sale['trade_count'];
                $res['amount_sale_money'] = $c2c_sale['amount_money'];
                if($c2c_sale['user_count'] == 0){
                    $res['user_sale_ave'] = 0;
                }else{
                    $res['user_sale_ave'] = round($c2c_sale['amount_money'] / $c2c_sale['user_count'],2);
                }
        }
        return $res;
    }


    /**
     * Notes: c2c交易曲线
     * User: 张哲
     * Date: 2019/1/15
     * Time: 10:54
     * @param $args
     * @return array
     */
    public function trade_c2c_data_draw($args)
    {

        $site_id = $args['site_id'];
        $check_time = $args['time'] - 86400;
        if ($args['type'] == 1) {
            $start_time = $check_time - 6 * 86400;
            $end_time = $start_time + 86400;
            $frequency = 7;
        } else if ($args['type'] == 2) {
            //mktime 为上周起始时间戳
            $start_time = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1 - 7, date('Y')) - 86400 * 7 * 10;
            $end_time = $check_time + 86400;
            $frequency = 4;
        } else if ($args['type'] == 3) {
            $cyear = floor(date("Y", $args['time']));
            $cMonth = floor(date("m", $args['time']));
            $frequency = 3;
        }
        $draw_arr = array();
        if (!empty($site_id)) {
            /**
             * 交易订单/交易金额
             */

            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));

                    /**
                     * c2c交易
                     */
                    /**
                     * C2C买入
                     */
                    //C2C买入金额、买入订单、买入人数
                    $c2c_buy = $this->Zjys_c2corder_model->c2c_trade_buy($one_time, $two_time,$site_id,1);
                    if (empty($c2c_buy['user_count'])) $c2c_buy['user_count'] = 0;
                    if (empty($c2c_buy['trade_count'])) $c2c_buy['trade_count'] = 0;
                    if (empty($c2c_buy['amount_money'])) $c2c_buy['amount_money'] = 0;
                    $trade_buy_count = $c2c_buy['trade_count'];
                    $amount_buy_money = $c2c_buy['amount_money'];
                    if($c2c_buy['user_count'] == 0){
                        $user_buy_ave = 0;
                    }else{
                        $user_buy_ave = round($c2c_buy['amount_money'] / $c2c_buy['user_count'],2);
                    }
                    /**
                     * C2C卖出
                     */
                    //C2C卖出金额、买入订单、买入人数
                    $c2c_sale = $this->Zjys_c2corder_model->c2c_trade_sell($one_time, $two_time,$site_id,2);
                    if (empty($c2c_sale['user_count'])) $c2c_sale['user_count'] = 0;
                    if (empty($c2c_sale['trade_count'])) $c2c_sale['trade_count'] = 0;
                    if (empty($c2c_sale['amount_money'])) $c2c_sale['amount_money'] = 0;
                    $trade_sale_count = $c2c_sale['trade_count'];
                    $amount_sale_money = $c2c_sale['amount_money'];
                    if($c2c_sale['user_count'] == 0){
                        $user_sale_ave = 0;
                    }else{
                        $user_sale_ave = round($c2c_sale['amount_money'] / $c2c_sale['user_count'],2);
                    }

                    /**
                     * 放入数组
                     */
                    $user_arr[$j]['time'] = $one_time;
                    $user_arr[$j]['trade_buy_count'] = $trade_buy_count;
                    $user_arr[$j]['amount_buy_money'] = $amount_buy_money;
                    $user_arr[$j]['user_buy_ave'] = $user_buy_ave;
                    $user_arr[$j]['trade_sale_count'] = $trade_sale_count;
                    $user_arr[$j]['amount_sale_money'] = $amount_sale_money;
                    $user_arr[$j]['user_sale_ave'] = $user_sale_ave;

                }
                foreach ($user_arr as $key => $value){
                    $now_time = strtotime($value['time']);
                    $draw_arr[$key]['time'] =$now_time;
                    $draw_arr[$key]['trade_buy_count'] = $value['trade_buy_count'];
                    $draw_arr[$key]['amount_buy_money'] = $value['amount_buy_money'];
                    $draw_arr[$key]['user_buy_ave'] = $value['user_buy_ave'];
                    $draw_arr[$key]['trade_sale_count'] = $value['trade_sale_count'];
                    $draw_arr[$key]['amount_sale_money'] = $value['amount_sale_money'];
                    $draw_arr[$key]['user_sale_ave'] = $value['user_sale_ave'];
                }


        }else{
            /**
             * 交易订单/交易金额
             */

            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));

                    /**
                     * c2c交易
                     */
                    /**
                     * C2C买入
                     */
                    //C2C买入金额、买入订单、买入人数
                    $c2c_buy = $this->Zjys_c2corder_model->c2c_trade_buy_bol($one_time, $two_time,1);
                    if (empty($c2c_buy['user_count'])) $c2c_buy['user_count'] = 0;
                    if (empty($c2c_buy['trade_count'])) $c2c_buy['trade_count'] = 0;
                    if (empty($c2c_buy['amount_money'])) $c2c_buy['amount_money'] = 0;
                    $trade_buy_count = $c2c_buy['trade_count'];
                    $amount_buy_money = $c2c_buy['amount_money'];
                    if($c2c_buy['user_count'] == 0){
                        $user_buy_ave = 0;
                    }else{
                        $user_buy_ave = round($c2c_buy['amount_money'] / $c2c_buy['user_count'],2);
                    }
                    /**
                     * C2C卖出
                     */
                    //C2C卖出金额、买入订单、买入人数
                    $c2c_sale = $this->Zjys_c2corder_model->c2c_trade_sell_nol($one_time, $two_time,2);
                    if (empty($c2c_sale['user_count'])) $c2c_sale['user_count'] = 0;
                    if (empty($c2c_sale['trade_count'])) $c2c_sale['trade_count'] = 0;
                    if (empty($c2c_sale['amount_money'])) $c2c_sale['amount_money'] = 0;
                    $trade_sale_count = $c2c_sale['trade_count'];
                    $amount_sale_money = $c2c_sale['amount_money'];
                    if($c2c_sale['user_count'] == 0){
                        $user_sale_ave = 0;
                    }else{
                        $user_sale_ave = round($c2c_sale['amount_money'] / $c2c_sale['user_count'],2);
                    }

                    /**
                     * 放入数组
                     */
                    $user_arr[$j]['time'] = $one_time;
                    $user_arr[$j]['trade_buy_count'] = $trade_buy_count;
                    $user_arr[$j]['amount_buy_money'] = $amount_buy_money;
                    $user_arr[$j]['user_buy_ave'] = $user_buy_ave;
                    $user_arr[$j]['trade_sale_count'] = $trade_sale_count;
                    $user_arr[$j]['amount_sale_money'] = $amount_sale_money;
                    $user_arr[$j]['user_sale_ave'] = $user_sale_ave;
                }
                foreach ($user_arr as $key => $value){
                    $now_time = strtotime($value['time']);
                    $draw_arr[$key]['time'] = $now_time;
                    $draw_arr[$key]['trade_buy_count'] = $value['trade_buy_count'];
                    $draw_arr[$key]['amount_buy_money'] = $value['amount_buy_money'];
                    $draw_arr[$key]['user_buy_ave'] = $value['user_buy_ave'];
                    $draw_arr[$key]['trade_sale_count'] = $value['trade_sale_count'];
                    $draw_arr[$key]['amount_sale_money'] = $value['amount_sale_money'];
                    $draw_arr[$key]['user_sale_ave'] = $value['user_sale_ave'];
                }
        }
        if($args['type'] == 3){
            $draw_arr =   array_reverse($draw_arr);
            return $draw_arr;
        }else{
            return $draw_arr;
        }
    }


    /**
     * Notes: 提币排名
     * User: 张哲
     * Date: 2019/1/15
     * Time: 11:49
     * @param $args
     * @return array
     */
    public function withdraws_coin_rank($args,$offset,$limit){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $rank = $args['rank'];
        $arr = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time =$check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
//        $start_time = (date('Y-m-d H:i:s', $start_time));
//        $end_time = (date('Y-m-d H:i:s', $end_time));
        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
        } else if(!empty($site_id)){
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id($site_id);
        }else{
            $assetList = $this->Zjys_assets_model->get_systemassets();
        }

        foreach ($assetList as $key => $value) {

            $object = $this->db->select("symbols,sum(withdraw_total) as recharge_total,sum(number) as number")
                ->from('perday_withdraw_statistics');
            if($site_id!='') $object =$this->db->where('perday_withdraw_statistics.site_id = ',$site_id);
            $ass = 'WWB';
           // if($value['asset_code']!='')
             $object =$this->db->where('perday_withdraw_statistics.symbols = ',$ass);
            if(!empty($start_time)){

                //$start_time = date("Y-m-d H:i:s", $start_time);

                $object =$this->db->where('perday_withdraw_statistics.time >=',$start_time);
            }
            if(!empty($end_time)){
               // $end_time = date("Y-m-d H:i:s", $end_time);
                $object =$this->db->where('perday_withdraw_statistics.time <',$end_time);
            }
            $list = $object->limit($limit,$offset)->order_by('recharge_total','desc')->get()->result_array();

            if(empty($list[0]['recharge_total'])) $list[0]['withdraw_total'] = 0;
            if(empty($list[0]['number'])) $list[0]['number'] = 0;
            $arr[$key]['withdraw_total'] = $list[0]['withdraw_total'];
            $arr[$key]['number'] = $list[0]['number'];
            $arr[$key]['asset'] = $value['asset_code'];
        }


        if($rank == 1){
            //排序
            foreach ($arr as $key => $row) {
                $distance[$key] = $row['withdraw_total'];
            }
            array_multisort( $distance, SORT_DESC, $arr);
        }else if($rank == 2){
            //排序
            foreach ($arr as $key => $row) {
                $number[$key] = $row['number'];
            }
            array_multisort( $number, SORT_DESC, $arr);
        }


        return $arr;
    }

    /**
     * Notes: 提币排名-数量
     * User: 张哲
     * Date: 2019/1/15
     * Time: 16:02
     * @param $args
     * @return int
     */
    public function withdraws_coin_rank_count($args){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
//        $start_time = (date('Y-m-d H:i:s', $start_time));
//        $end_time = (date('Y-m-d H:i:s', $end_time));
        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
        } else if(!empty($site_id)){
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id($site_id);
        }else{
            $assetList = $this->Zjys_assets_model->get_systemassets();
        }
        $i = 0;
       //var_dump($start_time,$end_time);die();
        foreach ($assetList as $key => $value) {
            $object = $this->db->select("sum(withdraw_total) as recharge_total,sum(number) as number")
                ->from('perday_withdraw_statistics');
            if($site_id!='') $object =$this->db->where('perday_withdraw_statistics.site_id = ',$site_id);
            if($value['asset_code']!='') $object =$this->db->where('perday_withdraw_statistics.asset_code = ',$value['asset_code']);
            if(!empty($start_time)){
               // $start_time = date("Y-m-d H:i:s", $start_time);
                $object =$this->db->where('perday_withdraw_statistics.time >=',$start_time);
            }
            if(!empty($end_time)){
               // $end_time = date("Y-m-d H:i:s", $end_time);
                $object =$this->db->where('perday_withdraw_statistics.time <',$end_time);
            }
            $i ++;
        }
        return $i;
    }

    /**
     * Notes: 充币排名
     * User: 张哲
     * Date: 2019/1/15
     * Time: 16:06
     * @param $args
     * @param $offset
     * @param $limit
     * @return array
     */
    public function recharge_coin_rank($args,$offset,$limit){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $rank = $args['rank'];
        $arr = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
//        $start_time = (date('Y-m-d H:i:s', $start_time));
//        $end_time = (date('Y-m-d H:i:s', $end_time));
        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
        } else if(!empty($site_id)){
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id($site_id);
        }else{
            $assetList = $this->Zjys_assets_model->get_systemassets();
        }

        foreach ($assetList as $key => $value) {
            $object = $this->db->select("sum(recharge_total) as recharge_total,sum(number) as number")
                ->from('perday_recharge_statistics');
            if($site_id!='') $object =$this->db->where('perday_recharge_statistics.site_id = ',$site_id);
            if($value['asset_code']!='') $object =$this->db->where('perday_recharge_statistics.asset_code = ',$value['asset_code']);
            if(!empty($start_time)){
                $object =$this->db->where('UNIX_TIMESTAMP(perday_recharge_statistics.time) >=',$start_time);
            }
            if(!empty($end_time)){
                $object =$this->db->where('UNIX_TIMESTAMP(perday_recharge_statistics.time) <',$end_time);
            }
            $list = $object->limit($limit,$offset)->order_by('recharge_total','desc')->get()->result_array();
            if(empty($list[0]['recharge_total'])) $list[0]['recharge_total'] = 0;
            if(empty($list[0]['number'])) $list[0]['number'] = 0;
            $arr[$key]['recharge_total'] = $list[0]['recharge_total'];
            $arr[$key]['number'] = $list[0]['number'];
            $arr[$key]['asset'] = $value['asset_code'];
        }

        if($rank == 1){
            //排序
            foreach ($arr as $key => $row) {
                $distance[$key] = $row['recharge_total'];
            }
            array_multisort( $distance, SORT_DESC, $arr);
        }else if($rank == 2){
            //排序
            foreach ($arr as $key => $row) {
                $number[$key] = $row['number'];
            }
            array_multisort( $number, SORT_DESC, $arr);
        }


        return $arr;
    }

    /**
     * Notes: 充币排名-数量
     * User: 张哲
     * Date: 2019/1/15
     * Time: 16:02
     * @param $args
     * @return int
     */
    public function recharge_coin_rank_count($args){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
//        $start_time = (date('Y-m-d H:i:s', $start_time));
//        $end_time = (date('Y-m-d H:i:s', $end_time));
        if ($this->config->item('SITE') === 'priv_one') {
            //获取所有币种
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
        } else if(!empty($site_id)){
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id($site_id);
        }else{
            $assetList = $this->Zjys_assets_model->get_systemassets();
        }
        $i = 0;
        foreach ($assetList as $key => $value) {
            $object = $this->db->select("sum(recharge_total) as recharge_total,sum(number) as number")
                ->from('perday_recharge_statistics');
            if($site_id!='') $object =$this->db->where('perday_recharge_statistics.site_id = ',$site_id);
            if($value['asset_code']!='') $object =$this->db->where('perday_recharge_statistics.asset_code = ',$value['asset_code']);
            if(!empty($start_time)){
                $object =$this->db->where('UNIX_TIMESTAMP(perday_recharge_statistics.time) >=',$start_time);
            }
            if(!empty($end_time)){
                $object =$this->db->where('UNIX_TIMESTAMP(perday_recharge_statistics.time) <',$end_time);
            }
            $i ++;
        }
        return $i;
    }


    /**
     * Notes: 币币详情数据
     * User: 张哲
     * Date: 2019/1/15
     * Time: 16:35
     * @param $args
     * @return array
     */
    public function coin_details_data($args){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $symblos = $args['market'];
        $res = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time =  $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));

        if (!empty($site_id)) {
            if(!empty($asset)){
                if(!empty($symblos)){

                    $trade= $this->Data_visualzation_model->trade_asset_site_symblos($start_time, $end_time,$site_id,$symblos);

                    if (empty($trade['count'])) $trade['count'] = 0;
                    $user_count  = $trade['count'];
                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $trade_count  = $trade['trading_number'];
                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    $money_count  = $trade['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count = intval($money_count) * intval($price);
                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $amount  = $trade['count'];

                    $trade_all= $this->Data_visualzation_model->trade_asset_site_all_symblos($site_id,$symblos);
                    if (empty($trade_all['count'])) $trade_all['count'] = 0;
                    $user_count_all  = $trade_all['count'];
                    if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                    $trade_count_all  = $trade_all['trading_number'];
                    if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                    $money_count_all  = $trade_all['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count_all = intval($money_count_all) * intval($price);
                    if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                    $amount_all  = $trade_all['count'];


                }else{

                    $trade= $this->Data_visualzation_model->trade_asset_site_left($start_time, $end_time,$site_id,$asset);
                    $trade_all= $this->Data_visualzation_model->trade_asset_site_all_left($asset,$site_id);
                    $trade_right= $this->Data_visualzation_model->trade_asset_site_right($start_time, $end_time,$site_id,$asset);
                    $trade_all_right= $this->Data_visualzation_model->trade_asset_site_all_right($asset,$site_id);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    if (empty($trade_right['trading_number'])) $trade_right['trading_number'] = 0;
                    $trade_count  = $trade['trading_number'] + $trade_right['trading_number'];
                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    if (empty($trade_right['trading_amount'])) $trade_right['trading_amount'] = 0;
                    $money_count  = $trade['trading_amount'] + $trade_right['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count = intval($money_count) * intval($price);
                    if (empty($trade['count'])) $trade['count'] = 0;
                    if (empty($trade_right['count'])) $trade_right['count'] = 0;
                    $user_count  = $trade['count'] + $trade_right['count'];
                    $amount  = $trade['count'] + $trade_right['count'];

                    if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                    if (empty($trade_all_right['trading_number'])) $trade_all_right['trading_number'] = 0;
                    $trade_count_all  = $trade_all['trading_number'] + $trade_all_right['trading_number'];
                    if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                    if (empty($trade_all_right['trading_amount'])) $trade_all_right['trading_amount'] = 0;
                    $money_count_all  = $trade_all['trading_amount'] + $trade_all_right['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count_all = intval($money_count_all) * intval($price);
                    if (empty($trade_all['count'])) $trade_all['count'] = 0;
                    if (empty($trade_all_right['count'])) $trade_all_right['count'] = 0;
                    $user_count_all  = $trade_all['count'] + $trade_all_right['count'];
                    $amount_all  = $trade_all['count'] + $trade_all_right['count'];

                }

                $res['user_count'] = $user_count;
                $res['trade_count'] = $trade_count;
                $res['money_count'] = $money_count;
                $res['amount'] = $amount;
                $res['user_count_all'] = $user_count_all;
                $res['trade_count_all'] = $trade_count_all;
                $res['money_count_all'] = $money_count_all;
                $res['amount_all'] = $amount_all;
            }else{

                $trade= $this->Data_visualzation_model->trade_user_amount($start_time, $end_time,$site_id);
                $trade_all= $this->Data_visualzation_model->trade_user_amount_all($site_id);
                if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                $trade_count  = $trade['trading_number'];
                if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                $money_count  = $trade['trading_amount'];
                $market = $trade['symbols'];
                $price = $this->symbol_combine($market);
                $money_count = intval($money_count) * intval($price);
                if (empty($trade['count'])) $trade['count'] = 0;
                $user_count  = $trade['count'];
                $amount  = $trade['count'];

                if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                $trade_count_all  = $trade_all['trading_amount'];
                if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                $money_count_all  = $trade_all['trading_number'];
                $market = $trade['symbols'];
                $price = $this->symbol_combine($market);
                $money_count_all = intval($money_count_all) * intval($price);
                if (empty($trade_all['count'])) $trade_all['count'] = 0;
                $user_count_all  = $trade_all['count'];
                $amount_all  = $trade_all['count'];


                $res['user_count'] = $user_count;
                $res['trade_count'] = $trade_count;
                $res['money_count'] = $money_count;
                $res['amount'] = $amount;
                $res['user_count_all'] = $user_count_all;
                $res['trade_count_all'] = $trade_count_all;
                $res['money_count_all'] = $money_count_all;
                $res['amount_all'] = $amount_all;
            }
        } else {
            if(!empty($asset)) {
                if(!empty($symblos)){
                    $trade= $this->Data_visualzation_model->trade_asset_symblos($start_time, $end_time,$symblos);

                    if (empty($trade['count'])) $trade['count'] = 0;
                    $user_count  = $trade['count'];
                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $trade_count  = $trade['trading_number'];
                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    $money_count  = $trade['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count = intval($money_count) * intval($price);
                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $amount  = $trade['count'];

                    $trade_all= $this->Data_visualzation_model->trade_asset_all_symblos($symblos);
                    if (empty($trade_all['count'])) $trade_all['count'] = 0;
                    $user_count_all  = $trade_all['count'];
                    if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                    $trade_count_all  = $trade_all['trading_number'];
                    if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                    $money_count_all  = $trade_all['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count_all = intval($money_count_all) * intval($price);
                    if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                    $amount_all  = $trade_all['count'];

                }else{
                    $trade= $this->Data_visualzation_model->trade_asset_left($start_time, $end_time,$asset);
                    $trade_all= $this->Data_visualzation_model->trade_asset_all_left($asset);
                    $trade_right= $this->Data_visualzation_model->trade_asset_right($start_time, $end_time,$asset);
                    $trade_all_right= $this->Data_visualzation_model->trade_asset_all_right($asset);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    if (empty($trade_right['trading_number'])) $trade_right['trading_number'] = 0;
                    $trade_count  = $trade['trading_number'] + $trade_right['trading_number'];
                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    if (empty($trade_right['trading_amount'])) $trade_right['trading_amount'] = 0;
                    $money_count  = $trade['trading_amount'] + $trade_right['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count = intval($money_count) * intval($price);
                    if (empty($trade['count'])) $trade['count'] = 0;
                    if (empty($trade_right['count'])) $trade_right['count'] = 0;
                    $user_count  = $trade['count'] + $trade_right['count'];
                    $amount  = $trade['count'] + $trade_right['count'];

                    if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                    if (empty($trade_all_right['trading_number'])) $trade_all_right['trading_number'] = 0;
                    $trade_count_all  = $trade_all['trading_number'] + $trade_all_right['trading_number'];
                    if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                    if (empty($trade_all_right['trading_amount'])) $trade_all_right['trading_amount'] = 0;
                    $money_count_all  = $trade_all['trading_amount'] + $trade_all_right['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count_all = intval($money_count_all) * intval($price);
                    if (empty($trade_all['count'])) $trade_all['count'] = 0;
                    if (empty($trade_all_right['count'])) $trade_all_right['count'] = 0;
                    $user_count_all  = $trade_all['count'] + $trade_all_right['count'];
                    $amount_all  = $trade_all['count'] + $trade_all_right['count'];

                }

                $res['user_count'] = $user_count;
                $res['trade_count'] = $trade_count;
                $res['money_count'] = $money_count;
                $res['amount'] = $amount;
                $res['user_count_all'] = $user_count_all;
                $res['trade_count_all'] = $trade_count_all;
                $res['money_count_all'] = $money_count_all;
                $res['amount_all'] = $amount_all;
            }else{
                $trade= $this->Data_visualzation_model->trade_user_amount_no($start_time, $end_time);

                if (empty($trade['count'])) $trade['count'] = 0;
                $user_count  = $trade['count'];
                if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                $trade_count  = $trade['trading_number'];
                if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                $money_count  = $trade['trading_amount'];
                $market = $trade['symbols'];
                $price = $this->symbol_combine($market);
                $money_count = intval($money_count) * intval($price);
                if (empty($trade['count'])) $trade['count'] = 0;
                $amount  = $trade['count'];

                $trade_all= $this->Data_visualzation_model->trade_user_amount_all_no();
                if (empty($trade_all['count'])) $trade_all['count'] = 0;
                $user_count_all  = $trade_all['count'];
                if (empty($trade_all['trading_number'])) $trade_all['trading_number'] = 0;
                $trade_count_all  = $trade_all['trading_number'];
                if (empty($trade_all['trading_amount'])) $trade_all['trading_amount'] = 0;
                $money_count_all  = $trade_all['trading_amount'];
                $market = $trade['symbols'];
                $price = $this->symbol_combine($market);
                $money_count_all = intval($money_count_all) * intval($price);
                if (empty($trade_all['count'])) $trade_all['count'] = 0;
                $amount_all  = $trade_all['count'];

                $res['user_count'] = $user_count;
                $res['trade_count'] = $trade_count;
                $res['money_count'] = $money_count;
                $res['amount'] = $amount;
                $res['user_count_all'] = $user_count_all;
                $res['trade_count_all'] = $trade_count_all;
                $res['money_count_all'] = $money_count_all;
                $res['amount_all'] = $amount_all;
            }
        }
        return $res;
    }

    /**
     * Notes: 币币详情交易费数据
     * User: 张哲
     * Date: 2019/1/15
     * Time: 18:57
     * @param $args
     * @return array
     */
    public function coin_details_fee_data($args){
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $symblos = $args['market'];
        $res = array();
        $check_time = $args['time'] - 86400;
        if($args['type'] == 1) {
            $start_time = $check_time;
            $end_time = $start_time + 86400;
        }else if($args['type'] == 2) {
            $start_time = $check_time - 86400*6;
            $end_time = $check_time + 86400;
        }else if($args['type'] == 3){
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time =  $check_time + 86400;
        }
        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));

        if (!empty($site_id)) {
            if(!empty($asset)){
                if(!empty($symblos)){
                    $trade= $this->Data_visualzation_model->trade_asset_site_symblos($start_time, $end_time,$site_id,$symblos);

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    $ask_count  = $trade['ASK_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $ask_count = intval($ask_count) * intval($price);
                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    $bid_count  = $trade['BID_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $bid_count = intval($bid_count) * intval($price);
                }else{

                    $trade= $this->Data_visualzation_model->trade_asset_site_left($start_time, $end_time,$site_id,$asset);

                    $trade_right= $this->Data_visualzation_model->trade_asset_site_right($start_time, $end_time,$site_id,$asset);

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    if (empty($trade_right['ASK_fee'])) $trade_right['ASK_fee'] = 0;
                    $ask_count  = $trade['ASK_fee'] + $trade_right['ASK_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $ask_count = intval($ask_count) * intval($price);
                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    if (empty($trade_right['BID_fee'])) $trade_right['tradBID_feeing_amount'] = 0;
                    $bid_count  = $trade['BID_fee'] + $trade_right['BID_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $bid_count = intval($bid_count) * intval($price);
                }

                $res['ask_count'] = $ask_count;
                $res['bid_count'] = $bid_count;

            }else{
                $trade= $this->Data_visualzation_model->trade_user_amount($start_time, $end_time,$site_id);

                if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                $ask_count  = $trade['ASK_fee'];
                $market = $trade['symbols'];
                $price = $this->symbol_combine($market);
                $ask_count = intval($ask_count) * intval($price);
                if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                $bid_count  = $trade['BID_fee'];
                $market = $trade['symbols'];
                $price = $this->symbol_combine($market);
                $bid_count = intval($bid_count) * intval($price);
                $res['ask_count'] = $ask_count;
                $res['bid_count'] = $bid_count;
            }
        } else {
            if(!empty($asset)) {
                if(!empty($symblos)){
                    $trade= $this->Data_visualzation_model->trade_asset_symblos($start_time, $end_time,$symblos);

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    $ask_count  = $trade['ASK_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $ask_count = intval($ask_count) * intval($price);
                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    $bid_count  = $trade['BID_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $bid_count = intval($bid_count) * intval($price);
                }else{
                    $trade= $this->Data_visualzation_model->trade_asset_left($start_time, $end_time,$asset);
                    $trade_right= $this->Data_visualzation_model->trade_asset_right($start_time, $end_time,$asset);

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    if (empty($trade_right['ASK_fee'])) $trade_right['ASK_fee'] = 0;
                    $ask_count  = $trade['ASK_fee'] + $trade_right['ASK_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $ask_count = intval($ask_count) * intval($price);
                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    if (empty($trade_right['BID_fee'])) $trade_right['BID_fee'] = 0;
                    $bid_count  = $trade['BID_fee'] + $trade_right['BID_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $bid_count = intval($bid_count) * intval($price);
                }

                $res['ask_count'] = $ask_count;
                $res['bid_count'] = $bid_count;
            }else{
                $trade= $this->Data_visualzation_model->trade_user_amount_no($start_time, $end_time);
                if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                $ask_count  = $trade['ASK_fee'];
                $market = $trade['symbols'];
                $price = $this->symbol_combine($market);
                $ask_count = intval($ask_count) * intval($price);
                if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                $bid_count  = $trade['BID_fee'];
                $market = $trade['symbols'];
                $price = $this->symbol_combine($market);
                $bid_count = intval($bid_count) * intval($price);
                $res['ask_count'] = $ask_count;
                $res['bid_count'] = $bid_count;
            }
        }
        return $res;
    }

    /**
     * Notes: 币币详情数-交易数据📈
     * User: 张哲
     * Date: 2019/1/16
     * Time: 09:59
     * @param $args
     * @return array
     */
    public function coin_details_trade_draw($args)
    {

        $site_id = $args['site_id'];
        $market = $args['market'];
        $check_time = $args['time'] - 86400;
        if ($args['type'] == 1) {
            $start_time = $check_time - 29 * 86400;
            $end_time = $start_time + 86400;
            $frequency = 30;
        } else if ($args['type'] == 2) {
            //mktime 为上周起始时间戳
            $start_time = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1 - 7, date('Y')) - 86400 * 7 * 10;
            $end_time = $check_time + 86400;
            $frequency = 12;
        } else if ($args['type'] == 3) {
            $cyear = floor(date("Y", $args['time']));
            $cMonth = floor(date("m", $args['time']));
            $frequency = 6;
        }
        $draw_arr = array();
        if (!empty($site_id)) {
            /**
             * 交易订单/交易金额
             */

            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400*7;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                if(!empty($asset)){
                    if(!empty($market)){
                        $trade= $this->Data_visualzation_model->trade_asset_site_symblos($one_time, $two_time,$site_id,$market);

                        if (empty($trade['count'])) $trade['count'] = 0;
                        $user_count  = $trade['count'];
                        if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                        $trade_count  = $trade['trading_number'];
                        if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                        $money_count  = $trade['trading_amount'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $money_count = intval($money_count) * intval($price);
                        if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                        $amount  = $trade['count'];

                    }else{

                        $trade= $this->Data_visualzation_model->trade_asset_site_left($one_time, $two_time,$site_id,$asset);
                        $trade_right= $this->Data_visualzation_model->trade_asset_site_right($one_time, $two_time,$site_id,$asset);


                        if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                        if (empty($trade_right['trading_number'])) $trade_right['trading_number'] = 0;
                        $trade_count  = $trade['trading_number'] + $trade_right['trading_number'];
                        if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                        if (empty($trade_right['trading_amount'])) $trade_right['trading_amount'] = 0;
                        $money_count  = $trade['trading_amount'] + $trade_right['trading_amount'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $money_count = intval($money_count) * intval($price);
                        if (empty($trade['count'])) $trade['count'] = 0;
                        if (empty($trade_right['count'])) $trade_right['count'] = 0;
                        $user_count  = $trade['count'] + $trade_right['count'];
                        $amount  = $trade['count'] + $trade_right['count'];
                    }
                }else{
                    $trade= $this->Data_visualzation_model->trade_user_amount($one_time, $two_time,$site_id);

                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $trade_count  = $trade['trading_number'];
                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    $money_count  = $trade['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count = intval($money_count) * intval($price);
                    if (empty($trade['count'])) $trade['count'] = 0;
                    $user_count  = $trade['count'];
                    $amount  = $trade['count'];
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['user_count'] = $user_count;
                $user_arr[$j]['trade_count'] = $trade_count;
                $user_arr[$j]['money_count'] = $money_count;
                $user_arr[$j]['amount'] = $amount;
            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['user_count'] = $value['user_count'];
                $draw_arr[$key]['trade_count'] = $value['trade_count'];
                $draw_arr[$key]['money_count'] = $value['money_count'];
                $draw_arr[$key]['amount'] = $value['amount'];
            }
        }else{
            /**
             * 交易订单/交易金额
             */
            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                if(!empty($asset)) {
                    if (!empty($market)) {
                        $trade= $this->Data_visualzation_model->trade_asset_symblos($one_time, $two_time,$market);

                        if (empty($trade['count'])) $trade['count'] = 0;
                        $user_count  = $trade['count'];
                        if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                        $trade_count  = $trade['trading_number'];
                        if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                        $money_count  = $trade['trading_amount'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $money_count = intval($money_count) * intval($price);
                        if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                        $amount  = $trade['count'];
                    } else {
                        $trade= $this->Data_visualzation_model->trade_asset_left($one_time, $two_time,$asset);
                        $trade_right= $this->Data_visualzation_model->trade_asset_right($one_time, $two_time,$asset);


                        if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                        if (empty($trade_right['trading_number'])) $trade_right['trading_number'] = 0;
                        $trade_count  = $trade['trading_number'] + $trade_right['trading_number'];
                        if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                        if (empty($trade_right['trading_amount'])) $trade_right['trading_amount'] = 0;
                        $money_count  = $trade['trading_amount'] + $trade_right['trading_amount'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $money_count = intval($money_count) * intval($price);
                        if (empty($trade['count'])) $trade['count'] = 0;
                        if (empty($trade_right['count'])) $trade_right['count'] = 0;
                        $user_count  = $trade['count'] + $trade_right['count'];
                        $amount  = $trade['count'] + $trade_right['count'];

                    }
                }else{
                    $trade= $this->Data_visualzation_model->trade_user_amount_no($one_time, $two_time);

                    if (empty($trade['count'])) $trade['count'] = 0;
                    $user_count  = $trade['count'];
                    if (empty($trade['trading_number'])) $trade['trading_number'] = 0;
                    $trade_count  = $trade['trading_number'];
                    if (empty($trade['trading_amount'])) $trade['trading_amount'] = 0;
                    $money_count  = $trade['trading_amount'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $money_count = intval($money_count) * intval($price);
                    if (empty($trade['count'])) $trade['count'] = 0;
                    $amount  = $trade['count'];
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['user_count'] = $user_count;
                $user_arr[$j]['trade_count'] = $trade_count;
                $user_arr[$j]['money_count'] = $money_count;
                $user_arr[$j]['amount'] = $amount;
            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['user_count'] = $value['user_count'];
                $draw_arr[$key]['trade_count'] = $value['trade_count'];
                $draw_arr[$key]['money_count'] = $value['money_count'];
                $draw_arr[$key]['amount'] = $value['amount'];
            }
        }
        if($args['type'] == 3){
            $draw_arr =   array_reverse($draw_arr);
            return $draw_arr;
        }else{
            return $draw_arr;
        }
    }

    /**
     * Notes: 币币详情数-手续费数据图表
     * User: 张哲
     * Date: 2019/1/16
     * Time: 10:01
     * @param $args
     * @return array
     */
    public function coin_details_fee_draw($args)
    {
        $site_id = $args['site_id'];
        $check_time = $args['time'] - 86400;
        if ($args['type'] == 1) {
            $start_time = $check_time - 6 * 86400;
            $end_time = $start_time + 86400;
            $frequency = 7;
        } else if ($args['type'] == 2) {
            //mktime 为上周起始时间戳
            $start_time = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1 - 7, date('Y')) - 86400 * 7 * 10;
            $end_time = $check_time + 86400;
            $frequency = 4;
        } else if ($args['type'] == 3) {
            $cyear = floor(date("Y", $args['time']));
            $cMonth = floor(date("m", $args['time']));
            $frequency = 3;
        }
        $draw_arr = array();
        if (!empty($site_id)) {
            /**
             * 交易订单/交易金额
             */
            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400*7;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                if(!empty($asset)){
                    if(!empty($market)){
                        $trade= $this->Data_visualzation_model->trade_asset_site_symblos($one_time, $two_time,$site_id,$market);

                        if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                        $ask_count  = $trade['ASK_fee'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $ask_count = intval($ask_count) * intval($price);
                        if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                        $bid_count  = $trade['BID_fee'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $bid_count = intval($bid_count) * intval($price);
                    }else{
                        $trade= $this->Data_visualzation_model->trade_asset_site_left($one_time, $two_time,$site_id,$asset);

                        $trade_right= $this->Data_visualzation_model->trade_asset_site_right($one_time, $two_time,$site_id,$asset);

                        if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                        if (empty($trade_right['ASK_fee'])) $trade_right['ASK_fee'] = 0;
                        $ask_count  = $trade['ASK_fee'] + $trade_right['ASK_fee'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $ask_count = intval($ask_count) * intval($price);
                        if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                        if (empty($trade_right['BID_fee'])) $trade_right['tradBID_feeing_amount'] = 0;
                        $bid_count  = $trade['BID_fee'] + $trade_right['BID_fee'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $bid_count = intval($bid_count) * intval($price);
                    }

                }else{
                    $trade= $this->Data_visualzation_model->trade_user_amount($one_time, $two_time,$site_id);

                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    $ask_count  = $trade['ASK_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $ask_count = intval($ask_count) * intval($price);
                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    $bid_count  = $trade['BID_fee'];
                    $market = $trade['symbols'];
                    $price = $this->symbol_combine($market);
                    $bid_count = intval($bid_count) * intval($price);
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['ask_count'] = $ask_count;
                $user_arr[$j]['bid_count'] = $bid_count;
            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] =$now_time;
                $draw_arr[$key]['ask_count'] = $value['ask_count'];
                $draw_arr[$key]['bid_count'] = $value['bid_count'];
            }
        }else{
            /**
             * 交易订单/交易金额
             */
            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                if(!empty($asset)) {
                    if (!empty($market)) {
                        $trade= $this->Data_visualzation_model->trade_asset_symblos($one_time, $two_time,$market);

                        if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                        $ask_count  = $trade['ASK_fee'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $ask_count = intval($ask_count) * intval($price);
                        if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                        $bid_count  = $trade['BID_fee'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $bid_count = intval($bid_count) * intval($price);
                    } else {
                        $trade= $this->Data_visualzation_model->trade_asset_left($one_time, $two_time,$asset);
                        $trade_right= $this->Data_visualzation_model->trade_asset_right($one_time, $two_time,$asset);

                        if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                        if (empty($trade_right['ASK_fee'])) $trade_right['ASK_fee'] = 0;
                        $ask_count  = $trade['ASK_fee'] + $trade_right['ASK_fee'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $ask_count = intval($ask_count) * intval($price);
                        if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                        if (empty($trade_right['BID_fee'])) $trade_right['BID_fee'] = 0;
                        $bid_count  = $trade['BID_fee'] + $trade_right['BID_fee'];
                        $market = $trade['symbols'];
                        $price = $this->symbol_combine($market);
                        $bid_count = intval($bid_count) * intval($price);
                    }
                }else{
                    $trade= $this->Data_visualzation_model->trade_user_amount_no($one_time, $two_time);
                    if (empty($trade['ASK_fee'])) $trade['ASK_fee'] = 0;
                    $ask_count  = $trade['ASK_fee'];
                    if (empty($trade['BID_fee'])) $trade['BID_fee'] = 0;
                    $bid_count  = $trade['BID_fee'];
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['ask_count'] = $ask_count;
                $user_arr[$j]['bid_count'] = $bid_count;
            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['ask_count'] = $value['ask_count'];
                $draw_arr[$key]['bid_count'] = $value['bid_count'];
            }
        }
        if($args['type'] == 3){
            $draw_arr =   array_reverse($draw_arr);
            return $draw_arr;
        }else{
            return $draw_arr;
        }
    }

    /**
     * Notes: 币币详情-充提币数据
     * User: 张哲
     * Date: 2019/1/16
     * Time: 10:43
     * @param $args
     * @param $offset
     * @param $limit
     * @return array
     */
    public function coin_recharge_withdraws_data($args)
    {
        //站点、日 周 月、交易区
        $site_id = $args['site_id'];
        $asset = $args['asset'];
        $res = array();
        if ($args['type'] == 1) {
            $start_time = $args['time'];
            $end_time = $start_time + 86400;
        } else if ($args['type'] == 2) {
            $start_time = $args['time'] - 86400 * 6;
            $end_time = $args['time'] + 86400;
        } else if ($args['type'] == 3) {
            $start_time = mktime(0, 0, 0, date('m'), 1, date('Y'));
            $end_time = $args['time'] + 86400;
        }
        $start_time = (date('Y-m-d H:i:s', $start_time));
        $end_time = (date('Y-m-d H:i:s', $end_time));
        if (!empty($site_id)) {
            if (!empty($asset)) {
                $recharge_sum_asset = $this->Zjys_recharge_logs_model->recharge_sum_asset($start_time, $end_time, $site_id, $asset);
                $withdraws_sum_asset = $this->Zjys_user_withdraw_model->withdraws_sum_asset($start_time, $end_time, $site_id, $asset);
                if (empty($recharge_sum_asset[0]['recharge_sum'])) $recharge_sum_asset[0]['recharge_sum'] = 0;
                if (empty($withdraws_sum_asset[0]['withdraw_sum'])) $withdraws_sum_asset[0]['withdraw_sum'] = 0;
                $res['recharge_sum'] = $recharge_sum_asset[0]['recharge_sum'];
                $res['withdraw_sum'] = $withdraws_sum_asset[0]['withdraw_sum'];
            } else {
                $recharge_sum_site = $this->Zjys_recharge_logs_model->recharge_sum_site($start_time, $end_time, $site_id);
                $withdraws_sum_site = $this->Zjys_user_withdraw_model->withdraws_sum_site($start_time, $end_time, $site_id);
                if (empty($recharge_sum_site[0]['recharge_sum'])) $recharge_sum_site[0]['recharge_sum'] = 0;
                if (empty($withdraws_sum_site[0]['withdraw_sum'])) $withdraws_sum_site[0]['withdraw_sum'] = 0;
                $res['recharge_sum'] = $recharge_sum_site[0]['recharge_sum'];
                $res['withdraw_sum'] = $withdraws_sum_site[0]['withdraw_sum'];
            }
        } else {
            if (!empty($asset)) {
                $recharge_sum_asset = $this->Zjys_recharge_logs_model->recharge_sum_nol($start_time, $end_time, $asset);
                $withdraws_sum_asset = $this->Zjys_user_withdraw_model->withdraws_sum_nol($start_time, $end_time, $asset);
                if (empty($recharge_sum_asset[0]['recharge_sum'])) $recharge_sum_asset[0]['recharge_sum'] = 0;
                if (empty($withdraws_sum_asset[0]['withdraw_sum'])) $withdraws_sum_asset[0]['withdraw_sum'] = 0;
                $res['recharge_sum'] = $recharge_sum_asset[0]['recharge_sum'];
                $res['withdraw_sum'] = $withdraws_sum_asset[0]['withdraw_sum'];
            } else {
                $recharge_sum_site = $this->Zjys_recharge_logs_model->recharge_sum($start_time, $end_time);
                $withdraws_sum_site = $this->Zjys_user_withdraw_model->withdraws_sum($start_time, $end_time);
                if (empty($recharge_sum_site[0]['recharge_sum'])) $recharge_sum_site[0]['recharge_sum'] = 0;
                if (empty($withdraws_sum_site[0]['withdraw_sum'])) $withdraws_sum_site[0]['withdraw_sum'] = 0;
                $res['recharge_sum'] = $recharge_sum_site[0]['recharge_sum'];
                $res['withdraw_sum'] = $withdraws_sum_site[0]['withdraw_sum'];
            }

        }
        return $res;
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/1/16
     * Time: 13:40
     * @param $args
     * @return array
     */
    public function coin_recharge_withdraws_draw($args)
    {
        $site_id = $args['site_id'];
        if ($args['type'] == 1) {
            $start_time = $args['time'] - 6 * 86400;
            $end_time = $start_time + 86400;
            $frequency = 7;
        } else if ($args['type'] == 2) {
            //mktime 为上周起始时间戳
            $start_time = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1 - 7, date('Y')) - 86400 * 7 * 10;
            $end_time = $args['time'] + 86400;
            $frequency = 4;
        } else if ($args['type'] == 3) {
            $cyear = floor(date("Y", $args['time']));
            $cMonth = floor(date("m", $args['time']));
            $frequency = 3;
        }
        $draw_arr = array();
        if (!empty($site_id)) {
            /**
             * 交易订单/交易金额
             */

            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                if(!empty($asset)){
                    $recharge_sum_asset = $this->Zjys_recharge_logs_model->recharge_sum_asset($one_time, $two_time, $site_id, $asset);
                    $withdraws_sum_asset = $this->Zjys_user_withdraw_model->withdraws_sum_asset($one_time, $two_time, $site_id, $asset);
                    if (empty($recharge_sum_asset[0]['recharge_sum'])) $recharge_sum_asset[0]['recharge_sum'] = 0;
                    if (empty($withdraws_sum_asset[0]['withdraw_sum'])) $withdraws_sum_asset[0]['withdraw_sum'] = 0;
                    $recharge_sum = $recharge_sum_asset[0]['recharge_sum'];
                    $withdraw_sum = $withdraws_sum_asset[0]['withdraw_sum'];
                }else{
                    $recharge_sum_site = $this->Zjys_recharge_logs_model->recharge_sum_site($one_time, $two_time, $site_id);
                    $withdraws_sum_site = $this->Zjys_user_withdraw_model->withdraws_sum_site($one_time, $two_time, $site_id);
                    if (empty($recharge_sum_site[0]['recharge_sum'])) $recharge_sum_site[0]['recharge_sum'] = 0;
                    if (empty($withdraws_sum_site[0]['withdraw_sum'])) $withdraws_sum_site[0]['withdraw_sum'] = 0;
                    $recharge_sum = $recharge_sum_site[0]['recharge_sum'];
                    $withdraw_sum = $withdraws_sum_site[0]['withdraw_sum'];
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['recharge_sum'] = $recharge_sum;
                $user_arr[$j]['withdraw_sum'] = $withdraw_sum;
            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['recharge_sum'] = $value['recharge_sum'];
                $draw_arr[$key]['withdraw_sum'] = $value['withdraw_sum'];
            }
        }else{
            /**
             * 交易订单/交易金额
             */
            $recharge_sum = 0; //充币
            $withdraw_sum = 0; //提币
            $user_arr = array();
            for ($j = 0; $j < $frequency; $j++) {

                if ($args['type'] == 1) {
                    $one_time = $start_time + 86400 * ($j);
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 2) {
                    $one_time = $start_time + 86400 * ($j) * 7;
                    $two_time = $one_time + 86400;
                } else if ($args['type'] == 3) {
                    $nMonth = $cMonth - $j;
                    $cyear = $nMonth == 0 ? ($cyear - 1) : $cyear;
                    $nMonth = $nMonth <= 0 ? 12 + $nMonth : $nMonth;
                    $date = $cyear . "-" . $nMonth . "-1";
                    $firstday = date('Y-m-01', strtotime($date));
                    $lastday = date('Y-m-t', strtotime($date));

                    $one_time = strtotime($firstday . " 00:00:00");
                    $two_time = strtotime($lastday . " 00:00:00");
                }
                $one_time = (date('Y-m-d H:i:s', $one_time));
                $two_time = (date('Y-m-d H:i:s', $two_time));
                if(!empty($asset)) {
                    $recharge_sum_asset = $this->Zjys_recharge_logs_model->recharge_sum_nol($one_time, $two_time, $asset);
                    $withdraws_sum_asset = $this->Zjys_user_withdraw_model->withdraws_sum_nol($one_time, $two_time, $asset);
                    if (empty($recharge_sum_asset[0]['recharge_sum'])) $recharge_sum_asset[0]['recharge_sum'] = 0;
                    if (empty($withdraws_sum_asset[0]['withdraw_sum'])) $withdraws_sum_asset[0]['withdraw_sum'] = 0;
                    $res['recharge_sum'] = $recharge_sum_asset[0]['recharge_sum'];
                    $res['withdraw_sum'] = $withdraws_sum_asset[0]['withdraw_sum'];
                }else{
                    $recharge_sum_site = $this->Zjys_recharge_logs_model->recharge_sum($one_time, $two_time);
                    $withdraws_sum_site = $this->Zjys_user_withdraw_model->withdraws_sum($one_time, $two_time);
                    if (empty($recharge_sum_site[0]['recharge_sum'])) $recharge_sum_site[0]['recharge_sum'] = 0;
                    if (empty($withdraws_sum_site[0]['withdraw_sum'])) $withdraws_sum_site[0]['withdraw_sum'] = 0;
                    $res['recharge_sum'] = $recharge_sum_site[0]['recharge_sum'];
                    $res['withdraw_sum'] = $withdraws_sum_site[0]['withdraw_sum'];
                }

                /**
                 * 放入数组
                 */
                $user_arr[$j]['time'] = $one_time;
                $user_arr[$j]['recharge_sum'] = $recharge_sum;
                $user_arr[$j]['withdraw_sum'] = $withdraw_sum;
                $recharge_sum = 0; //充币
                $withdraw_sum = 0; //提币
            }
            foreach ($user_arr as $key => $value){
                $now_time = strtotime($value['time']);
                $draw_arr[$key]['time'] = $now_time;
                $draw_arr[$key]['recharge_sum'] = $value['recharge_sum'];
                $draw_arr[$key]['withdraw_sum'] = $value['withdraw_sum'];
            }
        }
        if($args['type'] == 3){
            $draw_arr =   array_reverse($draw_arr);
            return $draw_arr;
        }else{
            return $draw_arr;
        }
    }

    /**
     * Notes: 根据币种给出交易对
     * User: 张哲
     * Date: 2019/1/17
     * Time: 11:49
     * @param $args
     *
     */
    public function asset_symbols($args){
        $asset = $args['asset'];
        $site_id = $args['site_id'];
        if ($this->config->item('SITE') === 'priv_one') {
            if(!empty($site_id) && !empty($asset)){
                $data = $this->Zjys_symbols_model->asset_symbols($asset,1);
            }else if(!empty($asset)){
                $data = $this->Zjys_symbols_model->asset_symbols_nol($asset);
            }else if(!empty($site_id)){
                $data = $this->Zjys_symbols_model->get_symbols_by_site_id(1);
            }else{
                $data = $this->Zjys_symbols_model->get_symbols_by_site_id1();
            }
        }else {
            if(!empty($site_id) && !empty($asset)){
                $data = $this->Zjys_symbols_model->asset_symbols($asset,$site_id);
            }else if(!empty($asset)){
                $data = $this->Zjys_symbols_model->asset_symbols_nol($asset);
            }else if(!empty($site_id)){
                $data = $this->Zjys_symbols_model->get_symbols_by_site_id($site_id);
            }else{
                $data = $this->Zjys_symbols_model->get_symbols_by_site_id1();
            }
        }
        return $data;
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/1/18
     * Time: 12:47
     * @param $args
     * @return mixed
     */
    public function site_asset($args){
        $site_id = $args['site_id'];
        if ($this->config->item('SITE') === 'priv_one') {
           if(!empty($site_id)){
                $data = $this->Zjys_assets_model->get_assets_by_site_id(1);
            }else{
                $data = $this->Zjys_assets_model->get_systemassets();
            }
        }else {
            if(!empty($site_id)){
                $data = $this->Zjys_assets_model->get_assets_by_site_id($site_id);
            }else{
                $data = $this->Zjys_assets_model->get_systemassets();
            }
        }
        return $data;
    }


    public function get_tongji_config_by_type($type){
        $arr = array(0);
        $result = $this->db->get_where('mail_tongji_config',array('tongji_type'=>$type))->row_array();
        if($result){
            $arr = explode(',',$result['uid']);
        }
        return $arr;
    }

    /**
     * Notes: 提币待审核（累计）；认证待审核（累计）；C2C买入待处理（累计）；C2C卖出待处理（累计)
     * User: 张哲
     * Date: 2019/2/19
     * Time: 10:44
     * @param $args
     */
    public function wait_review($site_id){
        $res = array();
        if (!empty($site_id)) {
            //提币
            $withdraw_no_review_site_id = $this->Zjys_user_withdraw_model->withdraw_no_review_site_id($site_id);
            $withdraw_site_id = $this->Zjys_user_withdraw_model->withdraw_site_id($site_id);
            $res['withdraw_no_review'] = $withdraw_no_review_site_id['0']['amount'];
            $res['withdraw_all'] = $withdraw_site_id['0']['amount'];
            //认证
            $identities_no_review_site_id = $this->User_truename_valid_model->identities_no_review_site_id($site_id);
            $identities_site_id = $this->User_truename_valid_model->identities_site_id($site_id);
            $res['identities_no_review'] = $identities_no_review_site_id['0']['amount'];
            $res['identities_all'] = $identities_site_id['0']['amount'];
            //c2c买入
            $c2c_buy_no_review_site_id = $this->Zjys_c2corder_model->c2c_buy_no_review_site_id($site_id,1);
            $c2c_buy_site_id = $this->Zjys_c2corder_model->c2c_buy_site_id($site_id,1);
            $res['c2c_buy_no_review'] = $c2c_buy_no_review_site_id['0']['amount'];
            $res['c2c_buy_all'] = $c2c_buy_site_id['0']['amount'];
            //c2c卖出
            $c2c_sale_no_review_site_id = $this->Zjys_c2corder_model->c2c_buy_no_review_site_id($site_id,2);
            $c2c_sale_site_id = $this->Zjys_c2corder_model->c2c_buy_site_id($site_id,2);
            $res['c2c_sale_no_review'] = $c2c_sale_no_review_site_id['0']['amount'];
            $res['c2c_sale_all'] = $c2c_sale_site_id['0']['amount'];
        }else{
            //提币
            $withdraw_no_review = $this->Zjys_user_withdraw_model->withdraw_no_review();
            $withdraw = $this->Zjys_user_withdraw_model->withdraw();
            $res['withdraw_no_review'] = $withdraw_no_review['0']['amount'];
            $res['withdraw_all'] = $withdraw['0']['amount'];
            //认证
            $identities_no_review = $this->User_truename_valid_model->identities_no_review();
            $identities = $this->User_truename_valid_model->identities();
            $res['identities_no_review'] = $identities_no_review['0']['amount'];
            $res['identities_all'] = $identities['0']['amount'];
            //c2c买入
            $c2c_buy_no_review = $this->Zjys_c2corder_model->c2c_buy_no_review(1);
            $c2c_buy = $this->Zjys_c2corder_model->c2c_buy(1);
            $res['c2c_buy_no_review'] = $c2c_buy_no_review['0']['amount'];
            $res['c2c_buy_all'] = $c2c_buy['0']['amount'];
            //c2c卖出
            $c2c_sale_no_review = $this->Zjys_c2corder_model->c2c_buy_no_review(2);
            $c2c_sale = $this->Zjys_c2corder_model->c2c_buy(2);
            $res['c2c_sale_no_review'] = $c2c_sale_no_review['0']['amount'];
            $res['c2c_sale_all'] = $c2c_sale['0']['amount'];
        }
        return $res;
    }
}

