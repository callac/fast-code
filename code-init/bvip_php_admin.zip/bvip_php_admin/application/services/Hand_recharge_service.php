<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-06-25
 * Time: 09:40
 */

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Hand_recharge_service extends MY_Service
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('Hand_recharge_model');
        $this->load->service('Sys_grpc_service');
    }

    /**
     * Notes: 推送通知
     * User: 张哲
     * Date: 2019-06-25
     * Time: 09:49
     */
    public function handrecharge_list($offset,$limit,$start_time,$end_time,$asset,$recharge_hash,$status)
    {
        $object = $this->db->select("hand_recharge.*")
            ->from('hand_recharge');
        $object = $this->db->where('hand_recharge.deleted_at is null');

        if (!empty($asset)) {
            $object = $this->db->where('hand_recharge.asset =', $asset);
        }

        if (!empty($recharge_hash)) {
            $object = $this->db->where('hand_recharge.recharge_hash =', $recharge_hash);
        }

        if (!empty($status)) {
            $object = $this->db->where('hand_recharge.status =', $status);
        }

        if (!empty($start_time)) {
            $object = $this->db->where('hand_recharge.created_at >=', $start_time);
        }

        if (!empty($end_time)) {
            $object = $this->db->where('hand_recharge.created_at <', $end_time);
        }


        $list = $object->limit($limit, $offset)->order_by('id', 'desc')->get()->result_array();


        // foreach ($list as &$val){
        //     $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
        //     if(!empty($site_name['name'])){
        //         $val['site_name'] = $site_name['name'];
        //     }
        //     if($val['status'] == 0){
        //         $val['status_code'] = '';
        //     }else  if($val['status'] == 2){
        //         $val['status_code'] = '推送成功';
        //     }else{
        //         $val['status_code'] = '推送失败';
        //     }
        // }
        return $list;
    }

    /**
     * Notes: 推送通知
     * User: 张哲
     * Date: 2019-06-25
     * Time: 09:51
     */
    public function handrecharge_list_count($start_time,$end_time,$asset,$recharge_hash,$status)
    {
        $object = $this->db->select("hand_recharge.*")
            ->from('hand_recharge');
        $object = $this->db->where('hand_recharge.deleted_at is null');

        if (!empty($asset)) {
            $object = $this->db->where('hand_recharge.asset =', $asset);
        }

        if (!empty($recharge_hash)) {
            $object = $this->db->where('hand_recharge.recharge_hash =', $recharge_hash);
        }

        if (!empty($status)) {
            $object = $this->db->where('hand_recharge.status =', $status);
        }

        if (!empty($start_time)) {
            $object = $this->db->where('hand_recharge.created_at >=', $start_time);
        }

        if (!empty($end_time)) 
            $object = $this->db->where('hand_recharge.created_at <', $end_time);

        return $this->db->count_all_results();
    }

    /**
     * Notes: 新增编辑通知
     * User: 张哲
     * Date: 2019-06-25
     * Time: 10:19
     */
    public function add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        if (!$id) {
            $created_at = date("Y-m-d H:i:s", time());
            $args ['created_at'] = $created_at;
            $args ['updated_at'] = $created_at;
            //验证用户合法性（1、交易系统验证，2、钱包系统验证）
            //1、交易系统验证（2、用户币种地址是否存在）
            $asset = $args['asset'];
            $recharge_address = $args['recharge_address'];
            $user_id = $args['user_id'];

            $checkonly = $this->db->query("select id from user_recharge_addresses where deleted_at is null and user_id=$user_id and asset='".$asset."' and address='".$recharge_address."'")->row_array();
            if(empty($checkonly)) returnJson('402','当前参数校验不通过，请核对参数');
            // var_dump($this->db->last_query());die;
            //2、钱包系统验证（调用gprc接口）
            $walletReq = $this->Sys_grpc_service->FirstCheckRecharge($args['asset'],$args['recharge_hash'],$args['recharge_address'],$args['amount']);
            var_dump($walletReq);die;
            if($walletReq !== true) returnJson('402','当前参数，钱包校验非法');
            //新增
            $business_id = $this->db->insert('hand_recharge', $args);
            admin_operation_logs($this->user_id,$user_id,49,'新增手动充值记录',$_SERVER['REQUEST_TIME'],$business_id);
        } else {
            // if($status)
            $detail = $this->db->query("select * from hand_recharge where id=$id")->row_array();
            if(detail['status'] != 0) returnJson('402','当前状态非法，无法编辑');
            $updated_at = date("Y-m-d H:i:s", time());
            $args ['updated_at'] = $updated_at;
            //验证用户合法性（1、交易系统验证，2、钱包系统验证）
            //1、交易系统验证（2、用户币种地址是否存在）
            //2、钱包系统验证（调用gprc接口）
            $this->db->where('id', $id);
            $this->db->update('hand_recharge', $args);
            admin_operation_logs($this->user_id,$user_id,54,'编辑手动充值记录',$_SERVER['REQUEST_TIME'],$id);
        }
        return true;
    }
    //再次审核
    public function handrecharge_verify($id,$status,$remark)
    {
        $detail = $this->db->query("select * from hand_recharge where id=$id")->row_array();
        if($detail['status'] != 1) returnJson('402','当前状态非法，无法进行再次审核');
        if($status==3){
            admin_operation_logs($this->user_id,$user_id,52,'手动充值复审通过',$_SERVER['REQUEST_TIME'],$id);
            //钱包系统再次校验
            $walletReq = $this->Sys_grpc_service->CheckRecharge($detail['asset'],$detail['recharge_hash'],$detail['recharge_address'],$detail['amount'],$detail['remark']);
            if($walletReq !== true) returnJson('402','当前参数，钱包校验非法');
        }
        if($status==4){
            admin_operation_logs($this->user_id,$user_id,53,'手动充值复审失败',$_SERVER['REQUEST_TIME'],$id);
        }

        $args['updated_at'] = date("Y-m-d H:i:s", $_SERVER['REQUEST_TIME']);
        $args['status'] = $status;
        $args['second_check_remark'] = $remark;
        $this->db->where('id',$id);
        $this->db->update('hand_recharge',$args);
    }


    //初次审核
    public function handrecharge_verify_first($id,$status,$remark)
    {
        $detail = $this->db->query("select * from hand_recharge where id=$id")->row_array();
        if($detail['status'] != 0) returnJson('402','当前状态非法，无法进行初次审核');
        if($status==1){
            admin_operation_logs($this->user_id,$user_id,50,'手动充值初审通过',$_SERVER['REQUEST_TIME'],$id);
        }
        if($status==2){
            admin_operation_logs($this->user_id,$user_id,51,'手动充值初审不通过',$_SERVER['REQUEST_TIME'],$id);
        }

        $args['updated_at'] = date("Y-m-d H:i:s", $_SERVER['REQUEST_TIME']);
        $args['status'] = $status;
        $args['first_check_remark'] = $remark;
        $this->db->where('id',$id);
        $this->db->update('hand_recharge',$args);
    }

    //查看详情
    public function detail($id)
    {
        $detail = $this->db->query("select * from hand_recharge where id=$id")->row_array();
        //获取审核信息和关键日志
        $keylog = $this->db->query("select A.description,A.created_at,B.user_name from admin_operation_logs A left join b_admin B on A.admin_id=B.user_id where A.operation_type in (50,51,52,53) and business_id=$id")->result_array();
        $detail['keylog']= $keylog;
        return $detail;
    }

}