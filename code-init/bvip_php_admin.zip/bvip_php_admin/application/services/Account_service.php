<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Account_model');
    }

    // ------------------------- 数字货币类型---------------------------------
    public function get_currency_list($offset,$limit,$site_id){
        $list =  $this->Account_model->get_currency_list($offset,$limit,$site_id);
        foreach ($list as &$val){
            $val['created_time'] = isset($val['created_time']) ? date('Y-m-d H:i:s',$val['created_time']) : '';
        }
        return $list;
    }
    public function get_currency_count($site_id){
        return $this->Account_model->get_currency_count($site_id);
    }
    public function currency_update($args){
        $id = isset($args['id']) ? $args['id'] : false;
        if($id){
            return $this->Account_model->currency_update($args['id'],$args['name'],$args['site_id']);
        }else{
            return $this->Account_model->currency_add($args['name'],time(),$args['site_id']);
        }
    }
    public function currency_delete($id){
        return $this->Account_model->currency_delete($id);
    }

    // ------------------------- 操作日志---------------------------------
    public function get_logs_list($offset,$limit,$site_id,$name,$ip,$start_time,$end_time){
        $list =  $this->Account_model->get_logs_list($offset,$limit,$site_id,$name,$ip,$start_time,$end_time);
        foreach ($list as &$val){
            $val['time'] = date('Y-m-d H:i:s',$val['time']);
            if($val['site_id'] == 0){
                $val['site_name'] = '总站';
            }
        }
        return $list;
    }
    public function get_logs_count($site_id,$name,$ip,$start_time,$end_time){
        return $this->Account_model->get_logs_count($site_id,$name,$ip,$start_time,$end_time);
    }
    public function logs_delete($id){
        return $this->Account_model->logs_delete($id);
    }

    // ------------------------- 电子合同---------------------------------
    public function get_contract_list($offset,$limit,$site_id,$type){
        $info =  $this->Account_model->get_contract_list($offset,$limit,$site_id,$type);
        foreach ($info as &$val){
            $val['modify_time'] = date('Y-m-d H:i:s',$val['modify_time']);
        }
        return $info;
    }
    public function get_contract_count($site_id,$type){
        return $this->Account_model->get_contract_count($site_id,$type);
    }
    public function get_contract_detail($id){
        return $this->Account_model->get_contract_detail($id);
    }
    public function contract_update($args){
        $id = isset($args['id']) ? $args['id'] : false;
        if($id){
            return $this->Account_model->contract_update($args['id'],$args['title_buy'],$args['desc'],$args['content'],$args['site_id'],$args['type']);
        }else{
            return $this->Account_model->contract_add($args['title_buy'],$args['desc'],$args['content'],'飞',time(),$args['site_id'],$args['type']);
        }
    }
    public function contract_delete($id){
        return $this->Account_model->contract_delete($id);
    }

}