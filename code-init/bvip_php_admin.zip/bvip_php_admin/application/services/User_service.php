<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 * 
 * 需要修改，
 * 用户管理
 * 登录注册是用的admin还要做权限控制
 * 
 */


class User_service extends MY_Service {

//
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }
    //获取用户详情
    public function get_info($user_id){
        $list                             =  $this->User_model->get_info($user_id);
        if(!$list) return false;
        $user_info['email']               = $list['email'];
        $user_info['mobile']              = $list['mobile'];
        $user_info['user_account']        = !empty( $list['email']) ?  $list['email'] :  $list['mobile'];
        $user_info['register_time']       = date('Y-m-d H:i:s',$list['register_time']);
        $user_info['ip']                  = $list['last_login_ip'];
        $user_info['last_login_time']     =  date('Y-m-d H:i:s',$list['last_login_time']);
        $user_info['user_verified']       = empty($list['user_verified']) ? '未认证': '已认证';;
        $user_info['truename']            = $list['truename'];
        $user_info['idcard']              = $list['idcard'];
        $user_info['card_type']           =  empty($list['bank']) ? '未绑定': '已绑定';
        $user_info['bank']                = $list['bank'];
        $user_info['card_no']             = $list['card_no'];
        $user_info['balance_account']     = $list['balance_account'];
        $user_info['user_status']         = '正常';
        $user_info['invite_email']        = $list['invite_email'];
        $user_info['invite_mobile']       = $list['invite_mobile'];
        $user_info['site_id']             = $list['site_id'];
        $user_info['site_name']           = $list['site_name'];
        
        $user_info['invite_user_account'] = !empty($list['invite_mobile']) ?$list['invite_mobile'] : $list['invite_email'] ;


        $this->load->model('User_post_addr_model');
        $this->load->model('User_ext_model');
        $this->load->model('Account_btc_bind_address_model');
        $this->load->model('Deposit_model');
        $this->load->model('Order_model');
        $this->load->model('Order_miner_model');
        $this->load->model('User_hash_income_details_model');
        //提币地址
        $user_info['account_btc_list'] = $this->Account_btc_bind_address_model->get_info_by_user_id($user_id);

        //邮寄地址
        $user_info['address_list'] =$this->User_post_addr_model->get_info_by_user_id($user_id);
        //累计托管
        $user_info['deposit_num'] = $this->Deposit_model->get_count_by_user_id($user_id);
        //累计交易笔数  算力+矿机
        $product_order_info = $this->Order_model->get_info_by_user_id($user_id,7); //交易成功的算力
        $miner_order_info = $this->Order_miner_model->get_info_by_user_id($user_id,6); //交易成功的矿机
        $user_info['trading_count'] = $product_order_info['count'] + $miner_order_info['count']; //累计交易笔数
        $user_info['trading_price'] = $product_order_info['pay_value'] + $miner_order_info['pay_value'];//累计交易金额
        //累计收益  算力 b_user_hash_income_details
        $user_info['user_hash_income'] = $this->User_hash_income_details_model->get_info_by_user_id($user_id,1);
        //可提取收益
        $user_ext_list = $this->User_ext_model->get_info_by_user_id($user_id);
        foreach ($user_ext_list as &$val){
            $val['user_account'] = $val['coin_account'] - $val['freeze_coin_withdraw_account'];
            unset($val['coin_account'], $val['freeze_coin_withdraw_account']);
        }
        $user_info['user_ext_list'] = $user_ext_list;
        return $user_info;
    }

    //eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJjb25zdW1lcktleSI6IllPVVJfS0VZIiwidXNlcklkIjoiMjEiLCJpc3N1ZWRBdCI6IjIwMTgtMDQtMjBUMTA6MjM6MjArMDgwMCIsInR0bCI6ODY0MDB9.22TR2j5SsvML_EvebhYq790vbQSoQQ30phRcDHvZHAk

    //获取列表
    public function get_list($offset,$limit,$name,$start_time,$end_time,$site_id){
        $object = $this->db->select("user.forbid_login,user.forbid_withdraw,user.forbid_trade,user.id,user.email,user.mobile,site.name as site_name,user.register_time,user.last_login_time,user.truename,user.user_verified,user.invite_user_id,invite_user.email as invite_email,invite_user.mobile as invite_mobile,b.status as truename_status")
            ->from('user')
            ->join('site','site.id=user.site_id','left')
            ->join('user as invite_user','user.invite_user_id=invite_user.id','left')
            ->join('b_user_truename_valid_log as b','user.id=b.user_id','left');
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('user.mobile = ',$name);
            }else{
                $object =$this->db->where('user.email = ',$name);
            }
        }
        if(!empty($start_time)){
            $object =$this->db->where('user.last_login_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user.last_login_time <=',$end_time);
        }
        if(!empty($site_id)){
            $object =$this->db->where('user.site_id =',$site_id);
        }
        $list = $object->limit($limit,$offset)->order_by('last_login_time','desc')->get()->result_array();
        foreach ($list as &$val){
            $val['last_login_time'] = date('Y-m-d H:i:s',$val['last_login_time']);
            $val['register_time'] = date('Y-m-d H:i:s',$val['register_time']);
            if($val['truename_status'] == 0){
                $val['user_verified'] = '未认证';
            }elseif ($val['truename_status'] == 1){
                $val['user_verified'] = '认证一致';
            }elseif ($val['truename_status'] == 2){
                $val['user_verified'] = '认证不一致';
            }elseif ($val['truename_status'] == 3){
                $val['user_verified'] = '无结果';
            }else{
                $val['user_verified'] = '未定义的状态';
            }
            $val['user_account'] = !empty($val['email']) ? $val['email'] : $val['mobile'];
        }
        return $list;
    }

    //统计条数
    public function get_count($name,$start_time,$end_time,$site_id){
        $this->db->from('user');
        if(!empty($name)){
            $this->db->where('user.truename',$name);
        }
        if(!empty($start_time)){
            $this->db->where('user.register_time >=',$start_time);
        }
        if(!empty($end_time)){
            $this->db->where('user.register_time <',$end_time);
        }
        if(!empty($site_id)){
            $this->db->where('user.site_id =',$site_id);
        }
        return $this->db->count_all_results();
    }

    //禁止登陆/允许登陆
    public function update_forbid_login($user_id,$type){
        $this->User_model->update_forbid_login($user_id,$type);
        $this->User_model->update_user_token($user_id,0);
    }
    //禁止交易/允许交易
    public function update_forbid_withdraw($user_id,$type){
        $this->User_model->update_forbid_withdraw($user_id,$type);
    }
    //禁止提现/允许提现
    public function update_forbid_trade($user_id,$type){
        $this->User_model->update_forbid_trade($user_id,$type);
    }

    //根據手機號獲取用戶信息
    public function get_info_by_mobile($str){
        return $this->User_model->get_info_by_mobile($str);
    }
    //根據郵箱號獲取用戶信息
    public function get_info_by_email($str){
        return $this->User_model->get_info_by_email($str);
    }
    //  //资金解冻
    // public function capital_unfreeze($user_id,$amount){
    //     $this->User_model->capital_unfreeze($user_id,$amount);
    // }




}
