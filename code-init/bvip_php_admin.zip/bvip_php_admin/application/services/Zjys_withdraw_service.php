<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

class Zjys_withdraw_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Account_capital_racharge_model');
        $this->load->model('Account_capital_withdraw_model');
        $this->load->model('Security_bulid_hash_model');
        $this->load->model('User_capital_model');
        $this->load->model('User_model');
        $this->load->model('Zjys_user_withdraw_model');
        $this->load->model('Zjys_c2corder_model');
        $this->load->model('Zjys_user_withdraw_freezes_model');
        $this->load->service('Sys_grpc_service');
        // $this->load->model('Zjys_user_withdraw_address_model');
    }  

    public function get_withdraw_freezen_by_assets_and_userid($assets,$user_id){
        $sql = 'select balance from user_asset_freezes where asset="'.$assets.'" and user_id='.$user_id.' and business in ("withdraw","admin_withdraw_unfreeze","withdraw_cancel") order by id desc limit 1';
        $result = object_to_array($this->db->query($sql)->result());
        // var_dump($this->db->last_query());
        // var_dump($result);die;
        if(is_array($result) && !empty($result)){
            return $result[0]['balance'];
        }else{
            return '0';
        }
    } 

    public function get_lock_freezen_by_assets_and_userid($assets,$user_id){
        $sql = 'select balance from user_asset_freezes where asset="'.$assets.'" and user_id='.$user_id.' and business in ("admin_freeze","admin_unfreeze") order by id desc limit 1';
        $result = object_to_array($this->db->query($sql)->result());
        // var_dump($this->db->last_query());
        if(is_array($result) && !empty($result)){
            if(bcsub($result[0]['balance'], 0,16)>0){
                return $result[0]['balance'];
            }else{
                return '0';
            }
        }else{
            return '0';
        }
    } 

    public function get_other_freezen_by_assets_and_userid($assets,$user_id){
        $sql = 'select balance from user_asset_freezes where asset="'.$assets.'" and user_id='.$user_id.' order by id desc limit 1';
        $result = object_to_array($this->db->query($sql)->result());
        if(is_array($result) && !empty($result)){
            if(bcsub($result[0]['balance'], 0,16)>0){
                return $result[0]['balance'];
            }else{
                return '0';
            }
        }else{
            return '0';
        }
    } 


    // public function get_activity_freezen_by_assets_and_userid($assets,$user_id){
    //     //TODO:此处以后可能要分不同种类的活动
    //     //当前：ZG活动冻结有 空投活动(airdrop、airdrop_release)保荐活动(bao_jian、bj_unfreeze)
    //     //ZT活动冻结有 注册活动(register_award、recommend_top_award、recommend_top_two_award) 认证活动(identity_award、identity_top_award、identity_top_two_award)
    //     $freeze_business = array(
    //         // 'c2c'=>array(
    //         //     'cancel_c2c_sell_freeze',
    //         //     'c2c_sell_freeze',
    //         //     'admin_c2c_unfreeze'
    //         // ),
    //         // 'withdraw'=>array(
    //         //     'withdraw',
    //         //     'withdraw_cancel',
    //         //     'admin_withdraw_unfreeze'
    //         // ),
    //         // 'lock'=>array(
    //         //     'admin_freeze',
    //         //     'admin_unfreeze'
    //         // ),
    //         'register'=>array(
    //             'register_award',
    //             'register_award_out',
    //             'register_award_out_admin'
    //         ),
    //         'register_top'=>array(
    //             'recommend_top_award',
    //             'recommend_top_award_out',
    //             'recommend_top_award_out_admin'
    //         ),
    //         'register_top_two'=>array(
    //             'recommend_top_two_award',
    //             'recommend_top_two_award_out', //活动解冻
    //             'recommend_top_two_award_out_admin' //后台主动解冻
    //         ),
    //         'identity'=>array(
    //             'identity_award',
    //             'identity_award_out',
    //             'identity_award_out_admin'
    //         ),
    //         'identity_top'=>array(
    //             'identity_top_award',
    //             'identity_top_award_out',
    //             'identity_top_award_out_admin'
    //         ),
    //         'identity_top_two'=>array(
    //             'identity_top_two_award',
    //             'identity_top_two_award_out', //活动解冻
    //             'identity_top_two_award_out_admin' //后台主动解冻
    //         ),
    //         'airdrop'=>array(
    //             'airdrop',
    //             'airdrop_release', //空投活动发放解冻
    //             'airdrop_release_admin' //后台主动发放解冻
    //         ),
    //         'vote'=>array(
    //             'vote_freeze', //投票活动冻结
    //             'vote_unfreeze' //投票活动解冻
    //         ),

    //     );
    //     $balance = array();
    //     //注册奖励冻结
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("register_award","recommend_top_award_out","register_award_out_admin","activity_trad_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['register'] = $result[0]['balance'];
    //     }else{
    //         $balance['register'] = '0';
    //     }
    //     //上级注册奖励冻结
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("recommend_top_award","register_award_out","recommend_top_award_out_admin","activity_trad_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['register_top'] = $result[0]['balance'];
    //     }else{
    //         $balance['register_top'] = '0';
    //     }
    //     //二级注册奖励冻结
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("recommend_top_two_award","recommend_top_two_award_out","recommend_top_two_award_out_admin","activity_trad_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['register_top_two'] = $result[0]['balance'];
    //     }else{
    //         $balance['register_top_two'] = '0';
    //     }
    //     //认证奖励冻结
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("identity_award","identity_award_out","identity_award_out_admin","activity_trad_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['identity'] = $result[0]['balance'];
    //     }else{
    //         $balance['identity'] = '0';
    //     }
    //     //认证上级奖励冻结
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("identity_top_award","identity_top_award_out","identity_top_award_out_admin","activity_trad_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['identity_top'] = $result[0]['balance'];
    //     }else{
    //         $balance['identity_top'] = '0';
    //     }
    //     //认证二级奖励冻结
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("identity_top_two_award","identity_top_two_award_out","identity_top_two_award_out_admin","activity_trad_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['identity_top_two'] = $result[0]['balance'];
    //     }else{
    //         $balance['identity_top_two'] = '0';
    //     }
    //     //空投奖励冻结
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("airdrop","airdrop_release","airdrop_release_admin","activity_trad_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['airdrop'] = $result[0]['balance'];
    //     }else{
    //         $balance['airdrop'] = '0';
    //     }

    //     //投票奖励冻结
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("vote_freeze","vote_unfreeze","activity_trad_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['vote'] = $result[0]['balance'];
    //     }else{
    //         $balance['vote'] = '0';
    //     }

    //     //活动赠币
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("admin_gift_activity_money","admin_activity_unlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['gift'] = $result[0]['balance'];
    //     }else{
    //         $balance['gift'] = '0';
    //     }
    //     //资产兑换
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("assetconvert_lock","assetconvert_timelock","assetconvert_timeunlock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['convert'] = $result[0]['balance'];
    //     }else{
    //         $balance['convert'] = '0';
    //     }

    //     //资产兑换
    //     $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' and business in ("moneytolive_timeunlock","moneytolive_timelock") order by id desc limit 1';
    //     $result = object_to_array($this->db->query($sql)->result());
    //     if(is_array($result) && !empty($result)){
    //         $balance['moneytolive'] = $result[0]['balance'];
    //     }else{
    //         $balance['moneytolive'] = '0';
    //     }



    //     return $balance;
    // } 

    /**
     * 获取活动冻结（不区分活动，所有类型的活动在一起）
     * @param  [type] $assets  [币种]
     * @param  [type] $user_id [用户id]
     * @return [type]          [description]
     */
    public function get_activity_freezen_by_assets_and_userid($assets,$user_id){
        $sql = 'select balance from user_asset_operatings where asset="'.$assets.'" and user_id='.$user_id.' order by id desc limit 1';
        $result = object_to_array($this->db->query($sql)->result());
        if(is_array($result) && !empty($result)){
            $balance['activity_freeze'] = $result[0]['balance'];
        }else{
            $balance['activity_freeze'] = '0';
        }
        return $balance;
    }


    /**
     * 充值列表加搜索
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      每页条数
     * @param    [type]       $name       关键词
     * @param    [type]       $start_time 开始时间
     * @param    [type]       $end_time   结束时间
     * @param    [type]       $site_id    站点id
     * @return   [type]                   [description]
     */
    public function withdraw_list($offset,$limit,$name,$start_time,$end_time,$asset,$status,$site_id,$uid,$wallet_status){

        $object = $this->db->select("user_withdraws.*,users.email,users.phone,users.realname as name,b_site.name as site_name")
            ->from('user_withdraws')
            // ->join('user_identities','user_identities.user_id=user_withdraws.user_id','left')
            ->join('b_site','b_site.id=user_withdraws.site_id','left')
            // ->join('user_withdraw_addresses','user_withdraw_addresses.id=user_withdraws.user_withdraw_address_id','left')
            ->join('users','users.id=user_withdraws.user_id','left');
        // $object =$this->db->where('user_identities.status =',2); //实名过的
        // $object =$this->db->where('user_identities.status =',2); //实名过的
        if($site_id!='') $object =$this->db->where('user_withdraws.site_id = ',$site_id);

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        if($status != '') {
            $object = $this->db->where('user_withdraws.status =', $status);
        }
        if(!empty($asset)){
            $object =$this->db->where('user_withdraws.asset =',$asset);
        }

        if(!empty($start_time)){
            $object =$this->db->where('user_withdraws.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_withdraws.created_at <',$end_time);
        }
        if(!empty($wallet_status)){
            $object =$this->db->where('user_withdraws.wallet_status =',$wallet_status);
        }

        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        foreach ($list as &$value) {
            if($value['wallet_status'] == 'PENDING')
                $value['wallet_status'] == '初始化';
            if($value['wallet_status'] == 'INIT')
                $value['wallet_status'] == '提交至钱包';
            if($value['wallet_status'] == 'PROXY')
                $value['wallet_status'] == '转发中';
            if($value['wallet_status'] == 'DONE')
                $value['wallet_status'] == '已完成';
            if($value['wallet_status'] == 'FAILED')
                $value['wallet_status'] == '失败';
            if($value['wallet_status'] == 'SENDING')
                $value['wallet_status'] == '发送中';
            if($value['wallet_status'] == 'PREAUTH')
                $value['wallet_status'] == '预授权';
            if($value['wallet_status'] == 'QUEUEING')
                $value['wallet_status'] == '队列中';
            if($value['wallet_status'] == 'FailedNotRepeat')
                $value['wallet_status'] == '失败不可重发';
            if($value['wallet_status'] == 'FailedCanRepeat')
                $value['wallet_status'] == '失败可重发';
            if($value['wallet_status'] == 'SENDING')
                $value['wallet_status'] == '发送中';
            if($value['restart_status'] == 'SENDING')
                $value['restart_status'] == '重发-发送中';
            if($value['restart_status'] == 'DONE')
                $value['restart_status'] == '重发-完成';
            if($value['restart_status'] == 'FAILED')
                $value['restart_status'] == '重发-失败';
        }
        // var_dump($this->db->last_query($list));die;
        return $list;
    }



    //提币地址列表
    public function withdraw_address_list($offset,$limit,$name,$start_time,$end_time,$asset,$site_id,$uid){
        $object = $this->db->select("user_withdraw_addresses.*,users.phone,users.email")
            ->from('user_withdraw_addresses')
            // ->join('b_site','b_site.id=user_withdraw_addresses.site_id','left')
            // ->join('user_identities','user_identities.user_id=user_withdraws.user_id','left')
            // ->join('user_withdraw_addresses','user_withdraw_addresses.id=user_withdraws.user_id','left')
            ->join('users','users.id=user_withdraw_addresses.user_id','left');
        // $object =$this->db->where('user_identities.status =',2); //实名过的
        $object =$this->db->where('user_withdraw_addresses.deleted_at is null');
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        
        if(!empty($asset)){
            $object =$this->db->where('user_withdraw_addresses.asset =',$asset);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_withdraw_addresses.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_withdraw_addresses.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        foreach ($list as &$value) {
            if(!empty($val['phone'])) $val['phone'] = substr_replace($val['phone'],'****', 3,4);
            if(!empty($val['email'])) $val['email'] = substr_replace($val['email'],'****', 1,2);
        }
        // var_dump($this->db->last_query());die;
        // var_dump($list);die;
        return $list;
    }

    /**
     * 提现记录查询计数
     * @Author   左俊
     * @DateTime 2018-07-12
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $name       [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function withdraw_list_count($name,$start_time,$end_time,$asset,$status,$site_id,$uid,$wallet_status){
        $object = $this->db->select("user_withdraws.*,users.email,users.phone,users.realname as name")
            ->from('user_withdraws')
            // ->join('user_identities','user_identities.user_id=user_withdraws.user_id','left')
            ->join('b_site','b_site.id=user_withdraws.site_id','left')
            // ->join('user_withdraw_addresses','user_withdraw_addresses.id=user_withdraws.user_id','left')
            ->join('users','users.id=user_withdraws.user_id','left');
        // $object =$this->db->where('user_identities.status =',2); //实名过的
        if($site_id!='') $object =$this->db->where('user_withdraws.site_id = ',$site_id);
        
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }
        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }
        if(!empty($asset)){
            $object =$this->db->where('user_withdraws.asset =',$asset);
        }
        if($status != '') {
            $object = $this->db->where('user_withdraws.status =', $status);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_withdraws.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_withdraws.created_at <',$end_time);
        }
        if(!empty($wallet_status)){
            $object =$this->db->where('user_withdraws.wallet_status =',$wallet_status);
        }
        return $this->db->count_all_results();
    }


    public function withdraw_address_list_count($name,$start_time,$end_time,$asset,$site_id,$uid){
        $object = $this->db->select("user_withdraw_addresses.*,users.phone,users.email")
            ->from('user_withdraw_addresses')
            // ->join('b_site','b_site.id=user_withdraw_addresses.site_id','left')
            // ->join('user_identities','user_identities.user_id=user_withdraws.user_id','left')
            // ->join('user_withdraw_addresses','user_withdraw_addresses.id=user_withdraws.user_id','left')
            ->join('users','users.id=user_withdraw_addresses.user_id','left');
        // $object =$this->db->where('user_identities.status =',2); //实名过的
        $object =$this->db->where('user_withdraw_addresses.deleted_at is null');
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }
        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }
        
        if(!empty($asset)){
            $object =$this->db->where('user_withdraw_addresses.asset =',$asset);
        }
        if(!empty($start_time)){
            $object =$this->db->where('user_withdraw_addresses.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('user_withdraw_addresses.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }

    //提现初次审核（2：审核通过，状态变为处理中 4：审核不通过）
    public function withdraw_verify($id,$status,$description=null)
    {
        if($status!=2 && $status!=4) returnJson('402','error');

        $detail = $this->Zjys_user_withdraw_model->get_withdraw_info($id);
        $asset = $detail['asset'];
        $user_id = $detail['user_id'];
        $amount = $detail['amount'];
        
        $created_at = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        $text = '提币审核'; //消息内容
        $true_status = (int)$detail['status'];
        if($true_status == 5 || $true_status == 3 || $true_status == 1) return false;
        $this->db->trans_start();
        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset,$user_id);
        if($status == 4){ //审核不通过
            $ss = array('info'=>$text);
            $result = update_user_balance_bycurl($user_id,$asset,$amount,$id,$ss,$busi='withdraw_cancel');
            if($result['error']!==NULL){
                    returnJson('402','系统错误');
            }elseif($result['result']['status']=='success'){

                $balance = $last_balance['balance']-$amount;
                $business = $this->config->item('WITHDRAW_CANCEL');  //冻结表的business
                //写入user_asset_freeze表
                $detail1 = json_encode(array('id'=>(int)$id));

                $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);
                // $this->Zjys_user_withdraw_model->update_remark($id,$description);
                $business = $this->config->item('WITHDRAW_CANCEL_CHECK_NO_STEPONE'); //后台操作记录表的operation_type
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
            }
        }else{
            $business = $this->config->item('WITHDRAW_CANCEL_CHECK_YSE_STEPONE');
            admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
            // // $result = $this->Zjys_user_withdraw_freezes_model->unfreezen_asset($asset,$user_id,$amount);
            // $title = '提币申请'; //消息标题
            // $time = date('Y-m-d H:i:s',time());
            // // $text = lang('catital_fail_text1').$amount.lang('catital_fail_text2'); //消息内容
            // $text = '您申请的提现金额为：'.$amount.'的请求审核成功，正在处理中！'; //消息内容
            // send_notification($user_id,$title,$text,99);//暂时定99 ，表示是交易所的用户消息
        }

        $result = $this->Zjys_user_withdraw_model->update_status($id,$status,$created_at,$description);  
        $this->db->trans_complete();      
        return $result;
    }

    //提现再次审核（3：审核通过，状态变为处理中 4：审核不通过）
    public function withdraw_sure_verify($id,$status,$description)
    {
        if($status!=3 && $status!=4) returnJson('402','error');
        $detail = $this->Zjys_user_withdraw_model->get_withdraw_info($id);
        $asset = $detail['asset'];
        $user_id = $detail['user_id'];
        $amount = $detail['amount'];
        $true_status = $detail['status'];
        $true_wallet_status = $detail['wallet_status'];
        $created_at = date('Y-m-d H:i:s',time());
        $updated_at = date('Y-m-d H:i:s',time());
        // var_dump($true_status);die;

        $text = '提币再次审核';
        if($true_status !=2) return false;

        $this->db->trans_start();
        $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($asset,$user_id);
        if($status == 4){ //审核不通过
            // $result = $this->Zjys_user_withdraw_freezes_model->unfreezen_asset($asset,$user_id,$amount);
            //  调用接口解冻资产
            $ss = array('info'=>$text);
            $result = update_user_balance_bycurl($user_id,$asset,$amount,$id,$ss,$busi='withdraw_cancel');
            if($result['error']!==NULL){
                    returnJson('402','系统错误');
            }elseif($result['result']['status']=='success'){
                $balance = $last_balance['balance']-$amount;
                $business = $this->config->item('WITHDRAW_CANCEL');
                //写入user_asset_freeze表
                // $extra = '';
                $detail1 = json_encode(array('id'=>(int)$id));
                $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);
                $business = $this->config->item('WITHDRAW_CANCEL_CHECK_NO_STEPTWO');
                // $description = '提币再次审核不通过';
                admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);
            }
        }else{
            //判断钱包状态，如果不为PENDING状态，不打消息入队列
            //if($true_wallet_status !== 'PENDING') returnJson('402','钱包状态值非法，请确认！');
            //打入消息队列
            require_once './vendor/autoload.php';
            $connection = new AMQPStreamConnection($this->config->item('rabbitmq_host'), $this->config->item('rabbitmq_port'), $this->config->item('rabbitmq_user'), $this->config->item('rabbitmq_pwd'));
            // $connection = new AMQPStreamConnection('localhost', 5672, 'guest', 'guest');
            $channel = $connection->channel();
            $channel->queue_declare('task_queue', false, true, false, false);
            $iid = array($id);
            $arr = array(
                'name'=>'withdraw_verify_success',
                'ip'=>$_SERVER['REMOTE_ADDR'],
                'endpoint'=>'admin',
                // 'params'=> '['.$id.']',
                'params'=> array((int)$id),
                'time'=>$_SERVER['REQUEST_TIME'],
            );

            $detail = json_encode($arr);
            $msg = new AMQPMessage($detail,array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
            $sss = $channel->basic_publish($msg, '', 'task_queue');
            // echo " [x] Sent 'Hello World!'\n";
            // var_dump($sss);die;
            $channel->close();
            $connection->close();
            $iid = '['.$id.']';
            // die;
            $this->Zjys_c2corder_model->add_event($created_at,$updated_at,$arr['name'],$arr['ip'],$arr['endpoint'],$iid);


            $business = $this->config->item('WITHDRAW_CANCEL_CHECK_YSE_STEPTWO');
            // $description = '提币再次审核通过';
            admin_operation_logs($this->user_id,$user_id,$business,$description,$created_at,$id);

            $business = $this->config->item('WITHDRAW_CANCEL');
            $balance = $last_balance['balance']-$amount;
            $detail1 = json_encode(array('id'=>(int)$id));
            $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$user_id,$asset,-$amount,$business,$balance,$detail1);
         }

        $result = $this->Zjys_user_withdraw_model->update_status($id,$status,$created_at,$description); 

        $this->db->trans_complete();
        // var_dump($result);die;
        return $result;
    }



    // //资金流水列表
    // public function capital_list($page = 1,$limit = 10){
    //     $this->load->model('User_capital_model');
    //     $offest = ($page -1) * $limit;
    //     $capital_list = array();
    //     $capital_list = $this->User_capital_model->capital_list($offest,$limit);
    //     if(!empty($capital_list)){
    //         foreach ($capital_list as $key => &$value) {
    //             $value['create_time'] = date('Y-m-d H:i:s',$value['create_time']); 
    //             if($value['status'] == 0){
    //                 $value['status_type'] = '未处理';
    //             } elseif($value['status'] == 1){
    //                 $value['status_type'] = '处理中';
    //             } elseif($value['status'] == 2){
    //                 $value['status_type'] = '成功';
    //             } elseif($value['status'] == 3){
    //                 $value['status_type'] = '失败';
    //             } 
    //         }
    //     }
    //     return $capital_list;
    // }


    /**
     * 资金流水列表加搜索
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $offset     [description]
     * @param    [type]       $limit      每页条数
     * @param    [type]       $name       关键词
     * @param    [type]       $start_time 开始时间
     * @param    [type]       $end_time   结束时间
     * @param    [type]       $site_id    站点id
     * @return   [type]                   [description]
     */
    public function capital_list($offset,$limit,$name,$start_time,$end_time,$site_id,$status){
        $object = $this->db->select("b_user_capital.id,site.name as site_name,user.mobile,user.email,user.truename,b_user_capital.create_time,b_user_capital.type,b_user_capital.amount,b_user_capital.value,b_user_capital.status")
            ->from('b_user_capital')
            ->join('site','site.id=b_user_capital.site_id','left')
            ->join('user','user.id=b_user_capital.user_id','left');

        if(!empty($name)){
            // if('user.mobile' == ''){
            // $object =$this->db->where('user.email =',$name);
            // }elseif('user.email' == ''){
            $object =$this->db->where('user.mobile =',$name);
            //}
        }
        
        if($status != 'all'){
            $object =$this->db->where('b_user_capital.status =',$status);
        }
        if(!empty($start_time)){
            $object =$this->db->where('b_user_capital.create_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('b_user_capital.create_time <',$end_time);
        }
        if(!empty($site_id)){
            $object =$this->db->where('b_user_capital.site_id =',$site_id);
        }

        $list = $object->limit($limit,$offset)->order_by('create_time','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;

        foreach ($list as &$val){
        //对时间戳的处理    
        $val['create_time'] = date('Y-m-d H:i',$val['create_time']);
        //对支付状态的处理
        if($val['status'] == 0){
            $val['status_type'] = '未处理';
        } elseif($val['status'] == 1){
            $val['status_type'] = '处理中';
        } elseif($val['status'] == 2){
             $val['status_type'] = '成功';
        } elseif($val['status'] == 3){
            $val['status_type'] = '失败';
        } 
        
        //对支付类型的处理
        if($val['type'] == 1){
            $val['pay_type'] = '充值';
        } elseif($val['type'] == 2){
            $val['pay_type'] = '提现';
        } elseif($val['type'] == 3){
             $val['pay_type'] = '矿机购买';
        } elseif($val['type'] == 4){
            $val['pay_type'] = '算力租用';
        } elseif($val['type'] == 5){
            $val['pay_type'] = '购买实体矿机';
        } 

        //手机号和邮箱合起来展示
        if($val['mobile'] == ''){
            $val['user_account'] = $val['email'];
        }elseif($val['email'] == ''){
            $val['user_account'] = $val['mobile'];
        }
       
        }
        return $list;
    }

    // //资金流水列表总数
    // public function capital_list_count()
    // {
    //     $this->load->model('User_capital_model');
    //     $res = $this->User_capital_model->capital_list_count();
    //     return $res;
    // }


    /**
     * 资金流水记录的条数
     * @Author   张哲
     * @DateTime 2018-04-18
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @param    [type]       $name       [description]
     * @param    [type]       $start_time [description]
     * @param    [type]       $end_time   [description]
     * @param    [type]       $site_id    [description]
     * @return   [type]                   [description]
     */
    public function capital_list_count($name,$start_time,$end_time,$site_id,$status){
        $this->db->from('b_user_capital')
                 ->join('user','user.id=b_user_capital.user_id','left');

        if(!empty($name)){
            //if($val['mobile'] == ''){
            //$object =$this->db->where('user.email =',$name);
            //}elseif($val['email'] == ''){
             $object =$this->db->where('user.mobile =',$name);
            //}
        }
        if($status != 'all'){
            $object =$this->db->where('b_user_capital.status =',$status);
        }
        if(!empty($start_time)){
            $this->db->where('b_user_capital.create_time >=',$start_time);
        }
        if(!empty($end_time)){
            $this->db->where('b_user_capital.create_time <',$end_time);
        }
        if(!empty($site_id)){
            $this->db->where('b_user_capital.site_id =',$site_id);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 将提现审核成功的手动设置成失败
     * User: 张哲
     * Date: 2019/2/14
     * Time: 14:18
     * @param $args
     * @return bool
     */
    public function withdraw_failure($args){
        $id = $args['WithdrawId'];
        $sql = "select user_id from user_withdraws where id=$id";
        $user_id = $this->db->query($sql)->row_array();
        $data = $this->Sys_grpc_service->SetWithdrawStatusToFail(intval($args['WithdrawId']),$args['remark']);

        $created_at = date('Y-m-d H:i:s',time());
        $business = $this->config->item('WITHDRAW_FAILURE'); 
        $description = isset($args['remark']) ? $args['remark'] : '未填写备注'; 
        $this->Zjys_user_withdraw_model->update_remark($id,$created_at,$description);
        admin_operation_logs($this->user_id,$user_id['user_id'],$business,$description,$created_at,$args['WithdrawId']);
        return $data;
    }

    public function waitcheckamount()
    {
        $sql = "select count(*) as number from user_withdraws where status=0 or status=2";
        return $this->db->query($sql)->row_array();
    }
}
