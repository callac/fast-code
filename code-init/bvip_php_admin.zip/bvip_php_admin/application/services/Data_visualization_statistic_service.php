<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/2/15
 * Time: 11:36
 */

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/1/4
 * Time: 16:20
 */
global  $machine_id;
$machine_id = 2;
$GLOBALS['$machine_id'] = $machine_id;

class Data_visualization_service extends MY_Service
{


    public function __construct()
    {
        parent::__construct();

        //$this->load->model('Data_visualzation_model');
        $this->load->model('Zjys_user_model');
        $this->load->model('Zjys_c2corder_model');
        $this->load->model('Zjys_assets_model');
        $this->load->model('Zjys_recharge_logs_model');
        $this->load->model('Zjys_user_withdraw_model');
        $this->load->model('Zjys_symbols_model');
        $this->trade_db = $this->load->database('trade_history', true);
    }

//    public function user_week_data(){
//        $start_time = "";
//        $end_time = time();
//
//        $one_time = $start_time + 86400 * ($j) * 7;
//        $two_time = $one_time + 86400;
//    }

}