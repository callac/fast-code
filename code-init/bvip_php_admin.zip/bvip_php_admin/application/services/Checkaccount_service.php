<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Checkaccount_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Checkaccount_model');
        $this->load->model('Zjys_assets_model');
        $this->load->service('Sys_grpc_service');
        $this->load->model('Wallet_snapshot_model');
        $this->load->model('Platfrom_transfer_record_model');
    }   


    public function platform_asset_list($offset,$limit,$start_time,$end_time,$asset){
        $object = $this->db->select("asset_snapshots.*")
        ->from('asset_snapshots');
        if(!empty($asset)){
            $object =$this->db->where('asset_snapshots.asset =',$asset);
        }
        if(!empty($start_time)){
            $object =$this->db->where('asset_snapshots.snapshot_time >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('asset_snapshots.snapshot_time <=',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('snapshot_time','desc')->order_by('asset','desc')->get()->result_array();
        // var_dump($this->db->last_query());die;
        // var_dump($list);die;
        foreach ($list as &$value) {
            $snapshot_time = $value['snapshot_time'];
            $lastday_time = date('Y-m-d',strtotime($snapshot_time)-86400);
            $lastdaytotal = $this->get_lastday($value['asset'],$lastday_time);
            $value['total_change'] = bcsub($value['total'],$lastdaytotal,12); //系统资产变动
            $change1 = bcadd($value['recharge'],$value['system'],12); //充值+系统调整
            $change2 = bcadd($value['asset_freeze'],$value['withdraw'],12); //冻结资产+提现
            $change3 = bcadd($value['trade_fee'],$value['activity_award'],12); //交易手续费+活动奖励
            $change4 = bcadd($change2,$change3,12);
            $value['day_change'] = bcsub($change1,$change4,12); //当日资金变动
            $value['system_change'] = bcsub($value['total_change'],$value['day_change'],12); //系统差额
        }
        return $list;
    }

    function get_lastday($asset,$snapshot_time)
    {
        $result = $this->Checkaccount_model->get_lastday($asset,$snapshot_time);
        if(is_array($result) && !empty($result))
            return $result['total'];
        else
            return '0';
    }

    
    public function platform_asset_list_count($start_time,$end_time,$asset){
        $object = $this->db->select("asset_snapshots.*")
        ->from('asset_snapshots');
        if(!empty($asset)){
            $object =$this->db->where('asset_snapshots.asset =',$asset);
        }

        if(!empty($start_time)){
            $object =$this->db->where('asset_snapshots.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('asset_snapshots.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }

    public function Checkaccount_list($args)
    {
        $asset = !empty($args['asset']) ? $args['asset'] : ""; //币资产
        $stime = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : date('Y-m-d',time()); //开始时间，没传就默认
        $etime = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : date('Y-m-d',time()-86400); //偏移量
        $stime1 = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])+86400) : date('Y-m-d',time()-86400); //偏移量
        $etime1 = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])+86400) : date('Y-m-d',time()-86400); //偏移量
        // if(strtotime($etime)-strtotime($stime)>259200) returnJson('402',lang('threeday_more')); //规定三天不能超过三天
        $snapshot_stime = date('Y-m-d H:i:s',strtotime($stime1)+86400); //算，前后时间断内的数据，去掉起初的那一天。然后运算累计变更
        //由于钱包充值提币快照时间并非取整点，为查找相应记录，后移etime
        $snapshot_etime = date('Y-m-d H:i:s',strtotime($etime1)+86400);
        if($asset == ''){
            if($this->config->item('SITE') === 'priv_one'){
                //获取所有币种
                $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
            }else{
                $assetList = $this->Zjys_assets_model->get_systemassets();
            }
            foreach ($assetList as $key => $value) {
                //获取初始快照资产
                $sResult = $this->Checkaccount_model->get_lastday($value['asset_code'],$stime1);
                $eResult = $this->Checkaccount_model->get_lastday($value['asset_code'],$etime1);

                if(empty($sResult)){
                    $sResult['total']='0';
                    $eResult['total']='0';
                }elseif(empty($eResult)){
                    $eResult['total']='0';
                }
                if($value['asset_code']!='ZG' && $value['asset_code']!='CNZ' && $value['asset_code']!='ZT' && $value['asset_code']!='CNT'){
                    //获取钱包充值提币详细
                    
                    $sql = "select sum(rechargeAmount) wallet_recharge,sum(withdrawAmount) wallet_withdraw from wallet_snapshot where asset='".$value['asset_code']."' and created_at>'".$stime1."' and created_at <'".$snapshot_etime."'";
                    $wallet_result = $this->db->query($sql)->row_array();
                    $newArray[$key]['wallet_recharge'] = $wallet_result['wallet_recharge'];
                    $newArray[$key]['wallet_withdraw'] = $wallet_result['wallet_withdraw'];
                }else{
                    $newArray[$key]['wallet_recharge'] = '0';
                    $newArray[$key]['wallet_withdraw'] = '0';
                }
                $newArray[$key]['asset'] =  $value['asset_code'];//资产
                $newArray[$key]['s_total'] =  $sResult['total'];//期初
                $newArray[$key]['e_total'] =  $eResult['total'];//期末
                $newArray[$key]['total_change'] =  bcsub($eResult['total'], $sResult['total'],12);//资产变动

                $data_timearea_list = $this->Checkaccount_model->get_area_list($value['asset_code'],$snapshot_stime,$etime1);
                if(empty($data_timearea_list)){
                    $newArray[$key]['lj_recharge'] = '0';
                    $newArray[$key]['lj_withdraw'] = '0';
                    $newArray[$key]['lj_system'] = '0';
                    $newArray[$key]['lj_tradefee'] = '0';
                }else{
                    $newArray[$key]['lj_recharge'] = '0';
                    $newArray[$key]['lj_withdraw'] = '0';
                    $newArray[$key]['lj_system'] = '0';
                    $newArray[$key]['lj_tradefee'] = '0';
                    foreach ($data_timearea_list as $kk => $vv) {
                        $newArray[$key]['lj_recharge'] = bcadd($newArray[$key]['lj_recharge'], $vv['recharge'],12);
                        $newArray[$key]['lj_withdraw'] = bcadd($newArray[$key]['lj_withdraw'], $vv['withdraw'],12);
                        $newArray[$key]['lj_system'] = bcadd($newArray[$key]['lj_system'], $vv['system'],12);
                        $newArray[$key]['lj_tradefee'] = bcadd($newArray[$key]['lj_tradefee'], $vv['trade_fee'],12);
                    }
                }
            }
            return $newArray;
        }else{
            $sResult = $this->Checkaccount_model->get_lastday($asset,$stime1);
            $eResult = $this->Checkaccount_model->get_lastday($asset,$etime1);
            if(empty($sResult)){
                $sResult['total']='0';
                $eResult['total']='0';
            }elseif(empty($eResult)){
                $eResult['total']='0';
            }
            if($asset!='ZG' && $asset!='CNZ' && $asset!='ZT' && $asset!='CNT'){
                    //获取钱包充值提币详细
                $snapshot_etime = date('Y-m-d H:i:s',strtotime($etime1)+86400);
                $sql = "select sum(rechargeAmount) wallet_recharge,sum(withdrawAmount) wallet_withdraw from wallet_snapshot where asset='".$asset."' and created_at>'".$stime1."' and created_at <'".$snapshot_etime."'";
                $wallet_result = $this->db->query($sql)->row_array();
                $newArray[0]['wallet_recharge'] = $wallet_result['wallet_recharge'];
                $newArray[0]['wallet_withdraw'] = $wallet_result['wallet_withdraw'];
            }else{
                $newArray[0]['wallet_recharge'] = '0';
                $newArray[0]['wallet_withdraw'] = '0';
            }
                $newArray[0]['asset'] =  $asset;//资产
                $newArray[0]['s_total'] =  $sResult['total'];//期初
                $newArray[0]['e_total'] =  $eResult['total'];//期末
                $newArray[0]['total_change'] =  bcsub($eResult['total'], $sResult['total'],12);//资产变动
                $data_timearea_list = $this->Checkaccount_model->get_area_list($asset,$snapshot_stime,$etime1);
                // var_dump($key);
                // var_dump($data_timearea_list);die;
                if(empty($data_timearea_list)){
                    $newArray[0]['lj_recharge'] = '0';
                    $newArray[0]['lj_withdraw'] = '0';
                    $newArray[0]['lj_system'] = '0';
                    $newArray[0]['lj_tradefee'] = '0';
                }else{
                    $newArray[0]['lj_recharge'] = '0';
                    $newArray[0]['lj_withdraw'] = '0';
                    $newArray[0]['lj_system'] = '0';
                    $newArray[0]['lj_tradefee'] = '0';
                    foreach ($data_timearea_list as $kk => $vv) {
                        $newArray[0]['lj_recharge'] = bcadd($newArray[0]['lj_recharge'], $vv['recharge'],12);
                        $newArray[0]['lj_withdraw'] = bcadd($newArray[0]['lj_withdraw'], $vv['withdraw'],12);
                        $newArray[0]['lj_system'] = bcadd($newArray[0]['lj_system'], $vv['system'],12);
                        $newArray[0]['lj_tradefee'] = bcadd($newArray[0]['lj_tradefee'], $vv['trade_fee'],12);
                    }
                }
                return $newArray;
            }
        }

    /**
     * Notes: 查询钱包余额
     * User: 张哲
     * Date: 2018/12/19
     * Time: 11:07
     * @param $args
     */
    public function checkWalletBalance($args)
    {
        $res = array();
        $stime = !empty($args['start_time']) ? date('Y-m-d', strtotime($args['start_time'])) : date('Y-m-d', time());
       // $stime =  date('Y-m-d', 1553018400) ;
        $asset = !empty($args['asset']) ? $args['asset'] : ""; //币资产
        if ($asset == '') {
            if ($this->config->item('SITE') === 'priv_one') {
                //获取所有币种
                $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
            } else {
                $assetList = $this->Zjys_assets_model->get_systemassets();
            }
            foreach ($assetList as $key => $value) {

                if ($value['asset_code'] != 'ZG' && $value['asset_code'] != 'CNZ' && $value['asset_code'] != 'ZT' && $value['asset_code'] != 'CNT') {
                    $result = $this->Sys_grpc_service->QueryWalletBalance($value['asset_code'], $stime);

                    if (!empty($result)) {
                        $arr = json_decode($result[0]['data'], true);
                        $time = date('Y-m-d H:i:s',time());
                        $this->Wallet_snapshot_model->add($result[0]['dateline'], $result[0]['coin_code'], $result[0]['id'], $arr['balance'], $arr['amount'], $arr['collectAmount'], $arr['collectCount'], $arr['freeze'], $arr['plaform'],$arr['rechargeAmount'],$arr['rechargeCount'],$arr['withdrawAmount'],$arr['withdrawCount'],$arr['platFeeAmount'],$arr['platRechargeAmount']);
                    }else{
                        $time = date('Y-m-d H:i:s',time());
                        $this->Wallet_snapshot_model->add($time, $value['asset_code'], 0, 0, 0, 0, 0, 0,0,0,0,0,0,0,0);
                    }
                } else {

                }
            }
        } else {
            $result = $this->Sys_grpc_service->QueryWalletBalance($asset, $stime);
            if (!empty($result)) {
                $arr = json_decode($result[0]['data'], true);
//                $time = date('Y-m-d H:i:s',time());
//                $res['key']['dateline'] = $time;
//                $res['key']['id'] = $result[0]['id'];
//                $res['key']['amount'] = $arr['amount']; //可用余额
//                $res['key']['balance'] = $arr['balance']; //总金额
//                $res['key']['coin_code'] = $arr['coin_code']; //币种
//                $res['key']['collectAmount'] = $arr['collectAmount']; //待归集金额 collectAmount
//                $res['key']['collectCount'] = $arr['collectCount']; //待归集笔数 collectCount
//                $res['key']['date'] = $arr['date'];
//                $res['key']['freeze'] = $arr['freeze']; //冻结金额 freeze
//                $res['key']['plaform'] = $arr['plaform'];
//                $res['key']['rechargeAmount'] = $arr['rechargeAmount'];
//                $res['key']['rechargeCount'] = $arr['rechargeCount'];
//                $res['key']['withdrawAmount'] = $arr['withdrawAmount'];
//                $res['key']['withdrawCount'] = $arr['withdrawCount'];
//                $res['key']['platFeeAmount'] = $arr['platFeeAmount']; //手续费
//                $res['key']['platRechargeAmount'] = $arr['platRechargeAmount']; //平台充值金额
                $this->Wallet_snapshot_model->add($result[0]['dateline'], $result[0]['coin_code'], $result[0]['id'], $arr['balance'], $arr['amount'], $arr['collectAmount'], $arr['collectCount'], $arr['freeze'], $arr['plaform'],$arr['rechargeAmount'],$arr['rechargeCount'],$arr['withdrawAmount'],$arr['withdrawCount'],$arr['platFeeAmount'],$arr['platRechargeAmount']);
            }else{
                $time = date('Y-m-d H:i:s',time());
                $this->Wallet_snapshot_model->add($time, $asset, 0, 0, 0, 0, 0, 0,0,0,0,0,0,0,0);
            }

        }
    }


    /**
     * Notes: 获取所有的一段时间的钱包快照
     * User: 张哲
     * Date: 2019/1/18
     * Time: 14:36
     * @param $args
     */
    public function checkWalletBalance_all($args)
    {
        $start_time = strtotime('2018-12-29 00:00:00');
        $time = time();
        $fre = intval(($time - $start_time) / 86400) ;
        //$start_time = strtotime(date('Y-m-d',time())) - 23 * 86400;
        for($i =0 ;$i<$fre;$i++){
            $sstime = $start_time + 86400*$i;
            $stime =  date('Y-m-d', $sstime);
            if ($this->config->item('SITE') === 'priv_one') {
                //获取所有币种
                $assetList = $this->Zjys_assets_model->get_assets_by_site_id(1);
            } else {
                $assetList = $this->Zjys_assets_model->get_systemassets();
            }
            foreach ($assetList as $key => $value) {

                if ($value['asset_code'] != 'ZG' && $value['asset_code'] != 'CNZ' && $value['asset_code'] != 'ZT' && $value['asset_code'] != 'CNT') {
                    $result = $this->Sys_grpc_service->QueryWalletBalance($value['asset_code'], $stime);

                    if (!empty($result)) {
                        $arr = json_decode($result[0]['data'], true);
                        $time = date('Y-m-d H:i:s',time());
                        $this->Wallet_snapshot_model->add($stime, $result[0]['coin_code'], $result[0]['id'], $arr['balance'], $arr['amount'], $arr['collectAmount'], $arr['collectCount'], $arr['freeze'], $arr['plaform'],$arr['rechargeAmount'],$arr['rechargeCount'],$arr['withdrawAmount'],$arr['withdrawCount'],$arr['platFeeAmount'],$arr['platRechargeAmount']);
                    }else{
                        $time = date('Y-m-d H:i:s',time());
                        $this->Wallet_snapshot_model->add($stime, $value['asset_code'], 0, 0, 0, 0, 0, 0,0,0,0,0,0,0,0);
                    }
                } else {

                }
            }
        }
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/12/19
     * Time: 16:24
     * @param $offset
     * @param $limit
     * @param $start_time
     * @param $end_time
     * @param $site_id
     * @param $user_id
     * @param $type
     * @return mixed
     */
    public function wallet_snapshot_list($offset,$limit,$start_time,$end_time,$asset){

//        if($asset!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `asset` = '$asset' limit ".$offset.",".$limit."  ";
//        }else if($start_time!='' && $end_time!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `created_at` >= '$start_time' and `created_at` <= '$end_time' limit ".$offset.",".$limit."  ";
//        }elseif($asset!='' && $start_time!='' && $end_time!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `created_at` >= '$start_time' and `created_at` <= '$end_time' and `asset` = '$asset' limit ".$offset.",".$limit."  ";
//        }else{
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` limit ".$offset.",".$limit."  ";
//        }
//        $object = object_to_array($this->db->query($sql)->result());
//
//        return $object;


//        $object = $this->db->distinct('wallet_snapshot.asset,wallet_snapshot.created_at,wallet_snapshot.wallet_id,wallet_snapshot.balance,wallet_snapshot.amount,wallet_snapshot.collectAmount,wallet_snapshot.collectCount,wallet_snapshot.date,wallet_snapshot.freeze,wallet_snapshot.plaform,wallet_snapshot.rechargeAmount,wallet_snapshot.rechargeCount,wallet_snapshot.withdrawAmount,wallet_snapshot.withdrawAmount,wallet_snapshot.platFeeAmount,wallet_snapshot.platRechargeAmount')
//            ->from('wallet_snapshot');
//
////        $object = $this->db->distinct("wallet_snapshot.asset,wallet_snapshot.created_at,wallet_snapshot.wallet_id,wallet_snapshot.balance,wallet_snapshot.amount,wallet_snapshot.collectAmount,wallet_snapshot.collectCount,wallet_snapshot.date,wallet_snapshot.freeze,wallet_snapshot.plaform,wallet_snapshot.rechargeAmount,wallet_snapshot.rechargeCount,wallet_snapshot.withdrawAmount,wallet_snapshot.withdrawAmount,platFeeAmount,platRechargeAmount");
//        if(!empty($start_time)){
//            $object =$this->db->where('wallet_snapshot.created_at >=',$start_time);
//        }
//        if(!empty($end_time)){
//            $object =$this->db->where('wallet_snapshot.created_at <=',$end_time);
//        }
//
//        if($asset!='') $object =$this->db->where('wallet_snapshot.asset = ',$asset);
//
//        $list = $object->limit($limit,$offset)->get()->result_array();
//
//        return $list;




        $object = $this->db->select("wallet_snapshot.*")
        ->from('wallet_snapshot');
        if($asset!='') $object =$this->db->where('wallet_snapshot.asset = ',$asset);

        if(!empty($start_time)){
            $object =$this->db->where('wallet_snapshot.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('wallet_snapshot.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        return $list;
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2018/11/28
     * Time: 10:51
     * @param $start_time
     * @param $end_time
     * @param $site_id
     * @param $user_id
     * @return mixed
     */
    public function wallet_snapshot_list_count($start_time,$end_time,$asset){
//        if($asset!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `asset` = '$asset'  ";
//
//        }else if($start_time!='' && $end_time!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `created_at` >= '$start_time' and `created_at` <= '$end_time' limit  ";
//        }elseif($asset!='' && $start_time!='' && $end_time!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `created_at` >= '$start_time' and `created_at` <= '$end_time' and `asset` = '$asset' ";
//        }else{
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot`  ";
//        }
//        $object = object_to_array($this->db->query($sql)->result());
//        $arr = count($object);
//        return $arr;


//        $object = $this->db->distinct('wallet_snapshot.asset,wallet_snapshot.created_at,wallet_snapshot.wallet_id,wallet_snapshot.balance,wallet_snapshot.amount,wallet_snapshot.collectAmount,wallet_snapshot.collectCount,wallet_snapshot.date,wallet_snapshot.freeze,wallet_snapshot.plaform,wallet_snapshot.rechargeAmount,wallet_snapshot.rechargeCount,wallet_snapshot.withdrawAmount,wallet_snapshot.withdrawAmount,wallet_snapshot.platFeeAmount,wallet_snapshot.platRechargeAmount')
//            ->from('wallet_snapshot');
//        $object = $this->db->distinct("wallet_snapshot.asset,wallet_snapshot.created_at,wallet_snapshot.wallet_id,wallet_snapshot.balance,wallet_snapshot.amount,wallet_snapshot.collectAmount,wallet_snapshot.collectCount,wallet_snapshot.date,wallet_snapshot.freeze,wallet_snapshot.plaform,wallet_snapshot.rechargeAmount,wallet_snapshot.rechargeCount,wallet_snapshot.withdrawAmount,wallet_snapshot.withdrawAmount,platFeeAmount,platRechargeAmount");
//        if(!empty($start_time)){
//            $object =$this->db->where('wallet_snapshot.created_at >=',$start_time);
//        }
//        if(!empty($end_time)){
//            $object =$this->db->where('wallet_snapshot.created_at <=',$end_time);
//        }
//        if($asset!='') $object =$this->db->where('wallet_snapshot.asset = ',$asset);
//
//
//        return $this->db->count_all_results();


        $object = $this->db->select("wallet_snapshot.*")
        ->from('wallet_snapshot');
        if($asset!='') $object =$this->db->where('wallet_snapshot.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('wallet_snapshot.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('wallet_snapshot.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    /**
     * Notes: 快照导出
     * User: 张哲
     * Date: 2018/12/19
     * Time: 16:29
     * @return mixed
     */
    public function wallet_snapshot_list_csv($start_time,$end_time,$asset){
//        if($asset!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `asset` = '$asset'  ";
//
//        }else if($start_time!='' && $end_time!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `created_at` >= '$start_time' and `created_at` <= '$end_time' limit  ";
//        }elseif($asset!='' && $start_time!='' && $end_time!=''){
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot` where `created_at` >= '$start_time' and `created_at` <= '$end_time' and `asset` = '$asset' ";
//        }else{
//            $sql = "select distinct asset,created_at,wallet_id,balance,amount,collectAmount,collectCount,date,freeze,plaform,rechargeAmount,rechargeCount,withdrawAmount,withdrawAmount,platFeeAmount,platRechargeAmount FROM `wallet_snapshot`  ";
//        }
//        $object = object_to_array($this->db->query($sql)->result());
//        return $object;



        $object = $this->db->select("wallet_snapshot.*")
        ->from('wallet_snapshot');

        if($asset!='') $object =$this->db->where('wallet_snapshot.asset = ',$asset);

        if(!empty($start_time)){
            $object =$this->db->where('wallet_snapshot.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('wallet_snapshot.created_at <=',$end_time);
        }

        $list = $object->order_by('created_at','desc')->get()->result_array();
        return $list;
    }

    public function system_checkamount($start_time,$end_time,$asset)
    {
        // var_dump($start_time);
        // var_dump($end_time);die;
        if($asset == ''){
            //不指定币种，取所有币种
            $sql = "select * from asset_snapshots where snapshot_time='".$start_time."'";
            $sql1 = "select * from asset_snapshots where snapshot_time='".$end_time."'";
            $res_start = $this->db->query($sql)->result_array();
            $res_end = $this->db->query($sql1)->result_array();

            $s_assetList = array(); 
            foreach ($res_start as $key => $value) {
                array_push($s_assetList,$value['asset']);
            }
            $sql = "select asset,sum(recharge) recharge,sum(withdraw) withdraw,sum(trade_fee) trade_fee,sum(activity_award) activity_award,sum(system) system from asset_snapshots where snapshot_time>'".$start_time."' and snapshot_time<='".$end_time."' group by asset";
            $group_result = $this->db->query($sql)->result_array();

            if(count($res_start)==0){
                returnJson('402',lang('snapshot_start_error'));
            }elseif(count($res_end)==0){
                returnJson('402',lang('snapshot_end_error'));
            }else{
                if(count($res_start)==count($res_end)){ //币种不变
                    foreach ($res_start as $k => $v) {
                        foreach ($res_end as $kk => $vv) {
                            if($v['asset']==$vv['asset']){
                                $a[$k]['s_total'] = $v['total']; //期初
                                $a[$k]['e_total'] = $vv['total']; //期末
                                $a[$k]['asset'] = $v['asset']; //币种
                                $a[$k]['difference'] = bcsub((string)$vv['total'], (string)$v['total'],16); //期初期末差值
                                if($v['asset']!='ZG' && $v['asset']!='CNZ' && $v['asset']!='ZT' && $v['asset']!='CNT'){
                                    //取钱包快照数据
                                    $sql = "select sum(rechargeAmount) wallet_recharge,sum(withdrawAmount) wallet_withdraw from wallet_snapshot where asset='".$v['asset']."' and created_at>'".$start_time."' and created_at <='".$end_time."'";
                                    $wallet_result = $this->db->query($sql)->row_array();
                                    $a[$k]['wallet_recharge'] = $wallet_result['wallet_recharge'];
                                    $a[$k]['wallet_withdraw'] = $wallet_result['wallet_withdraw'];
                                }else{
                                    $a[$k]['wallet_recharge'] = '0';
                                    $a[$k]['wallet_withdraw'] = '0';
                                }
                            }
                        }
                    }

                    foreach ($a as $b => $c) {
                        foreach ($group_result as $d => $f) {
                            if($c['asset'] == $f['asset']){
                                $result[$b]['asset'] = $c['asset'];
                                $result[$b]['s_total'] = $c['s_total'];
                                $result[$b]['e_total'] = $c['e_total'];
                                $result[$b]['difference'] = $c['difference'];
                                $result[$b]['wallet_recharge'] = $c['wallet_recharge'];
                                $result[$b]['wallet_withdraw'] = $c['wallet_withdraw'];
                                $result[$b]['recharge'] = $f['recharge'];
                                $result[$b]['withdraw'] = $f['withdraw'];
                                $result[$b]['trade_fee'] = $f['trade_fee'];
                                $result[$b]['activity_award'] = $f['activity_award'];
                                $result[$b]['system'] = $f['system'];
                                $result[$b]['cha'] = $f['recharge']-$f['withdraw']-$f['trade_fee']+$f['system']+$f['activity_award']-$c['difference'];
                            }
                        }
                    }
                }elseif(count($res_start)>count($res_end)){ //期初资产类型多于期末资产类型。币种种类减少的情况
                    returnJson('402',lang('snapshot_error'));
                }else{
                    // var_dump($res_end);
                    // var_dump($s_assetList);die;
                    foreach ($res_end as $k => $v) {
                        if(in_array($v['asset'],$s_assetList)){
                            foreach ($res_start as $kk => $vv) {
                                if($vv['asset'] == $v['asset']){
                                    $a[$k]['s_total'] = $vv['total']; //期初
                                    $a[$k]['e_total'] = $v['total']; //期末
                                    $a[$k]['asset'] = $v['asset']; //币种
                                    $a[$k]['difference'] = bcsub((string)$v['total'], (string)$vv['total'],16); //期初期末差值
                                    if($v['asset']!='ZG' && $v['asset']!='CNZ' && $v['asset']!='ZT' && $v['asset']!='CNT'){
                                        //取钱包快照数据
                                        $sql = "select sum(rechargeAmount) wallet_recharge,sum(withdrawAmount) wallet_withdraw from wallet_snapshot where asset='".$v['asset']."' and created_at>'".$start_time."' and created_at <='".$end_time."'";
                                        $wallet_result = $this->db->query($sql)->row_array();
                                        $a[$k]['wallet_recharge'] = $wallet_result['wallet_recharge'];
                                        $a[$k]['wallet_withdraw'] = $wallet_result['wallet_withdraw'];
                                    }else{
                                        $a[$k]['wallet_recharge'] = '0';
                                        $a[$k]['wallet_withdraw'] = '0';
                                    }
                                }
                            }
                        }else{
                            // var_dump($v['asset']);
                            $b[$k]['s_total'] = 0; //期初
                            $b[$k]['e_total'] = $v['total']; //期末
                            $b[$k]['asset'] = $v['asset']; //币种
                            $b[$k]['difference'] = bcsub((string)$v['total'], '0'); //期初期末差值
                            if($v['asset']!='ZG' && $v['asset']!='CNZ' && $v['asset']!='ZT' && $v['asset']!='CNT'){
                                //取钱包快照数据
                                $sql = "select sum(rechargeAmount) wallet_recharge,sum(withdrawAmount) wallet_withdraw from wallet_snapshot where asset='".$v['asset']."' and created_at>'".$start_time."' and created_at <='".$end_time."'";
                                $wallet_result = $this->db->query($sql)->row_array();
                                $b[$k]['wallet_recharge'] = $wallet_result['wallet_recharge'];
                                $b[$k]['wallet_withdraw'] = $wallet_result['wallet_withdraw'];
                            }else{
                                $b[$k]['wallet_recharge'] = '0';
                                $b[$k]['wallet_withdraw'] = '0';
                            }
                        }

                    }
                    $b = array_values($b);
                    $ab = array_merge($a,$b);
                    foreach ($ab as $b => $c) {
                        foreach ($group_result as $d => $f) {
                            if($c['asset'] == $f['asset']){
                                $result[$b]['asset'] = $c['asset'];
                                $result[$b]['s_total'] = $c['s_total'];
                                $result[$b]['e_total'] = $c['e_total'];
                                $result[$b]['difference'] = $c['difference'];
                                $result[$b]['wallet_recharge'] = $c['wallet_recharge'];
                                $result[$b]['wallet_withdraw'] = $c['wallet_withdraw'];
                                $result[$b]['recharge'] = $f['recharge'];
                                $result[$b]['withdraw'] = $f['withdraw'];
                                $result[$b]['trade_fee'] = $f['trade_fee'];
                                $result[$b]['activity_award'] = $f['activity_award'];
                                $result[$b]['system'] = $f['system'];
                                $result[$b]['cha'] = $f['recharge']-$f['withdraw']-$f['trade_fee']+$f['system']+$f['activity_award']-$c['difference'];
                            }
                        }
                    }
                }
                return $result;
            }
        }else{
            //指定币种
            $sql = "select * from asset_snapshots where asset = '".$asset."' and snapshot_time='".$start_time."'";
            $sql1 = "select * from asset_snapshots where asset = '".$asset."' and snapshot_time='".$end_time."'";
            $res_start = $this->db->query($sql)->row_array();
            $res_end = $this->db->query($sql1)->row_array();
            
            if($res_start==NULL) $res_start = [];
            if($res_end==NULL) $res_end = [];

            if(count($res_start)==0 || count($res_end)==0){
                returnJson('402',lang('snapshot_data_error'));
            }

            if($asset!='ZG' && $asset!='CNZ' && $asset!='ZT' && $asset!='CNT'){
                //取钱包快照数据
                $sql = "select sum(rechargeAmount) wallet_recharge,sum(withdrawAmount) wallet_withdraw from wallet_snapshot where asset='".$asset."' and created_at>'".$start_time."' and created_at <='".$end_time."'";
                $wallet_result = $this->db->query($sql)->row_array();
                $a['wallet_recharge'] = $wallet_result['wallet_recharge'];
                $a['wallet_withdraw'] = $wallet_result['wallet_withdraw'];
            }else{
                $a['wallet_recharge'] = '0';
                $a['wallet_withdraw'] = '0';
            }

            $a['asset'] = $asset;
            $a['s_total'] = $res_start['total'];
            $a['e_total'] = $res_end['total'];
            $a['difference'] = bcsub((string)$res_end['total'], (string)$res_start['total'],16);



            $sql = "select asset,sum(recharge) recharge,sum(withdraw) withdraw,sum(trade_fee) trade_fee,sum(activity_award) activity_award,sum(system) system from asset_snapshots where asset = '".$asset."' and snapshot_time>'".$start_time."' and snapshot_time<='".$end_time."' group by asset";
            $group_result = $this->db->query($sql)->row_array();
            $group_result['cha'] = $group_result['recharge']-$group_result['withdraw']-$group_result['trade_fee']+$group_result['system']+$group_result['activity_award']-$a['difference'];

            return array(array_merge($a,$group_result));
        }
    }


    public function settlement_list($month,$admin_id,$asset,$site_id)
    {
        if(date('Y-m',time()) == $month) returnJson(402,'不能选择当月');
        $thismonth = date('m',strtotime($month));
        $thisyear = date('Y',strtotime($month));
        if ($thismonth == 12) {
            $nextmonth = '01';
            $nextyear = $thisyear + 1;
        } else {
            if($thismonth<10){
                $nextmonth = '0'.($thismonth + 1);
            }else{
                $nextmonth = $thismonth + 1;
            }
            $nextyear = $thisyear;
        }

        $stime = $month.'-01';
        $etime = $nextyear.'-'.$nextmonth.'-01';

        $jyq = $this->config->item('trade_area');

        $this->db->trans_begin();
        $where = " and 1=1";
        if($asset!=''){
            $where .= " and A.asset='".$asset."'";
        }
        if($site_id!=''){
            $where .= " and A.site_id=$site_id";
        }

        $xtime = $_SERVER['REQUEST_TIME'];
        $dtime = strtotime($etime);

        // var_dump($asset);
        // var_dump($site_id);
        // var_dump($month);die;

        //返回列表已生成好的列表
        $sql = "select A.*,B.`name`,B.settlement_percent,B.ts_status,B.ws_status from settlement_fee A left join b_site B on A.site_id=B.id where A.settlement_time='".$stime."--".$etime."'".$where ;
        // var_dump($sql);die;
        $list = $this->db->query($sql)->result_array();
        
        if(count($list)>0){
            foreach ($list as &$t) {
                $t['tfee'] = $t['t_fee']*$t['ts_status'];
                $t['wfee'] = $t['w_fee']*$t['ws_status'];
                $t['settlement_fee'] = bcadd((string)$t['tfee'], (string)$t['wfee'],12) * $t['settlement_percent'];
                if($t['status'] ==0)
                    $t['status_m'] = '否';
                else
                    $t['status_m'] = '是';
            }
            return $list;
        }else{
            // echo 11;die;
            if($site_id=='' && $asset=='' && $month!=''){
                $sql = "select site_id from perday_coin_trade_statistics_all where time_area>='".$stime."' and time_area<'".$etime."' group by site_id";
                $siteIds = $this->db->query($sql)->result_array();
                if(count($siteIds)==0) return array('list'=>array());

                foreach ($siteIds as $m => $n) {
                    //获取当前站点的配置信息
                    $sql = "select settlement_percent,ts_status,ws_status from b_site where id=$n[site_id]";
                    $siteInfo = $this->db->query($sql)->row_array();

                    $sql = "select symbols from perday_coin_trade_statistics_all where time_area>='".$stime."' and time_area<'".$etime."' and site_id=$n[site_id] group by symbols";
                    $list = $this->db->query($sql)->result_array();
                    $asset = array();
                    $result = '';
                    foreach ($list as $key => $value) {
                        $a = str_replace('_', ',', $value['symbols']);
                        array_push($asset,$a);
                    }
                    foreach ($asset as $k => $v) {
                        $result .= $v.',';
                    }

                    $result = explode(',', $result);
                    unset($result[count($result)-1]);
                    $result = array_unique($result);
                    $result = array_values($result);
                    // var_dump($result);die;//每个站点的有交易手续费的币种

                    for($i=0;$i<count($result);$i++){
                        if(in_array($result[$i],$jyq)){
                        //是交易区内币种，要计算 BID_fee和ASK_fee
                            $sql1 = "select sum(BID_fee) fee from perday_coin_trade_statistics_all where time_area>='".$stime."' and time_area<'".$etime."' and site_id=$n[site_id] and symbols like '".$result[$i]."_%'";
                            $sql2 = "select sum(ASK_fee) fee from perday_coin_trade_statistics_all where time_area>='".$stime."' and time_area<'".$etime."' and site_id=$n[site_id] and symbols like '%_".$result[$i]."'";
                            $fee1 = $this->db->query($sql1)->row_array();
                            if($fee1['fee']==null){
                                $fee1 = '0';
                            }else{
                                $fee1 = $fee1['fee'];
                            }
                            $fee2 = $this->db->query($sql2)->row_array();
                            if($fee2['fee']==null){
                                $fee2 = '0';
                            }else{
                                $fee2 = $fee2['fee'];
                            }
                            $fee = bcadd($fee1, $fee2,12);  
                        }else{
                            //不是交易区内的币种，只计算BID_fee
                            $sql = "select sum(BID_fee) fee from perday_coin_trade_statistics_all where time_area>='".$stime."' and time_area<'".$etime."' and site_id=$n[site_id] and symbols like '".$result[$i]."_%'";
                            $fee = $this->db->query($sql)->row_array();
                            if($fee['fee']==null){
                                $fee = '0';
                            }else{
                                $fee = $fee['fee'];
                            }
                        }

                        //计算这个时间段,当前站点，当前币种的提币手续费
                        $sql = "select sum(fee) withdraw_fee from user_withdraws where wallet_status='DONE' and arrive_time>='".$stime."' and arrive_time<'".$etime."' and site_id=$n[site_id] and asset='".$result[$i]."'";
                        $withdraw_fee = $this->db->query($sql)->row_array();
                        if($withdraw_fee['withdraw_fee']==null){
                            $withdraw_fee = '0';
                        }else{
                            $withdraw_fee = $withdraw_fee['withdraw_fee'];
                        }
                        
                        $settlement_time = $stime.'--'.$etime;
                        $created_at = $updated_at = date('Y-m-d H:i:s',time());
                        //入库
                        // var_dump($n['site_id'],$result[$i],$fee,$withdraw_fee,$stime,$etime);
                        $sql = "INSERT INTO `settlement_fee` (`site_id`,`asset`,`t_fee`,`w_fee`,`settlement_time`,`settlement_percent`,`created_at`,`updated_at`) VALUES ($n[site_id],'$result[$i]',$fee,$withdraw_fee,'$settlement_time',1,'$created_at','$updated_at')";

                        $this->db->query($sql);
                    }
                    
                }

                $trans_status = $this->db->trans_status(); 
                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    returnJson('402','Transaction failed');
                } else {
                    $this->db->trans_commit();
                    // return true;
                }
            }

            $sql = "select A.*,B.`name`,B.settlement_percent,B.ts_status,B.ws_status from settlement_fee A left join b_site B on A.site_id=B.id where A.settlement_time='".$stime."--".$etime."'".$where;
            $list = $this->db->query($sql)->result_array();
            foreach ($list as &$s) {
                $s['tfee'] = $s['t_fee']*$s['ts_status'];
                $s['wfee'] = $s['w_fee']*$s['ws_status'];
                $s['settlement_fee'] = bcadd((string)$s['tfee'], (string)$s['wfee'],12) * $s['settlement_percent'];
                if($s['status'] == 0)
                    $s['status_m'] = '否';
                else
                    $s['status_m'] = '是';
            }
            if(count($list)==0) return array('list'=>array());
            return $list;
        }
    }

    public function day_settlement_list($day,$admin_id,$asset,$site_id)
    {
        //不能选择在4月之前
        if(strtotime($day)<strtotime('2019-04-01')) returnJson(402,'不能选择4月之前的数据,若要结算请至手续费月结进行结算');
        //不能选择当日结算
        if(date('Y-m-d',time()) == $day) returnJson(402,'不能选择当日');
        //获取配置文件的交易区
        $jyq = $this->config->item('trade_area');

        $this->db->trans_begin();
        $where = " and 1=1";
        if($asset!=''){
            $where .= " and A.asset='".$asset."'";
        }
        if($site_id!=''){
            $where .= " and A.site_id=$site_id";
        }

        $day_format = $day.' 00:00:00';
        $day_format_next = date('Y-m-d',strtotime($day_format)+86400);
        // var_dump($asset);
        // var_dump($site_id);
        // var_dump($month);die;

        //返回列表已生成好的列表
        $sql = "select A.*,B.`name`,B.settlement_percent,B.ts_status,B.ws_status from day_settlement_fee A left join b_site B on A.site_id=B.id where A.settlement_time='".$day."'$where";
        // var_dump($sql);die;
        $list = $this->db->query($sql)->result_array();
        
        if(count($list)>0){
            foreach ($list as &$t) {
                $t['tfee'] = $t['t_fee']*$t['ts_status'];
                $t['wfee'] = $t['w_fee']*$t['ws_status'];
                $t['settlement_fee'] = bcadd((string)$t['tfee'], (string)$t['wfee'],12) * $t['settlement_percent'];
                if($t['status'] ==0)
                    $t['status_m'] = '否';
                else
                    $t['status_m'] = '是';
            }
            return $list;
        }else{
            if($site_id=='' && $asset=='' && $day!=''){
                $sql = "select site_id from perday_coin_trade_statistics_all where time_area='".$day_format."' group by site_id";
                $siteIds = $this->db->query($sql)->result_array();
                if(count($siteIds)==0) return array('list'=>array());

                foreach ($siteIds as $m => $n) {
                    //获取当前站点的配置信息
                    $sql = "select settlement_percent,ts_status,ws_status from b_site where id=$n[site_id]";
                    $siteInfo = $this->db->query($sql)->row_array();

                    $sql = "select symbols from perday_coin_trade_statistics_all where time_area='".$day_format."' and site_id=$n[site_id] group by symbols";
                    $list = $this->db->query($sql)->result_array();
                    $asset = array();
                    $result = '';
                    foreach ($list as $key => $value) {
                        $a = str_replace('_', ',', $value['symbols']);
                        array_push($asset,$a);
                    }
                    foreach ($asset as $k => $v) {
                        $result .= $v.',';
                    }

                    $result = explode(',', $result);
                    unset($result[count($result)-1]);
                    $result = array_unique($result);
                    $result = array_values($result);
                    // var_dump($result);die;//每个站点的有交易手续费的币种

                    for($i=0;$i<count($result);$i++){
                        if(in_array($result[$i],$jyq)){
                        //是交易区内币种，要计算 BID_fee和ASK_fee
                            $sql1 = "select sum(BID_fee) fee from perday_coin_trade_statistics_all where time_area='".$day_format."' and site_id=$n[site_id] and symbols like '".$result[$i]."_%'";
                            $sql2 = "select sum(ASK_fee) fee from perday_coin_trade_statistics_all where time_area='".$day_format."' and site_id=$n[site_id] and symbols like '%_".$result[$i]."'";

                            $fee1 = $this->db->query($sql1)->row_array();
                            if($fee1['fee']==null){
                                $fee1 = '0';
                            }else{
                                $fee1 = $fee1['fee'];
                            }
                            $fee2 = $this->db->query($sql2)->row_array();
                            if($fee2['fee']==null){
                                $fee2 = '0';
                            }else{
                                $fee2 = $fee2['fee'];
                            }
                            $fee = bcadd($fee1, $fee2,12);  
                        }else{
                            //不是交易区内的币种，只计算BID_fee
                            $sql = "select sum(BID_fee) fee from perday_coin_trade_statistics_all where time_area='".$day_format."' and site_id=$n[site_id] and symbols like '".$result[$i]."_%'";
                            $fee = $this->db->query($sql)->row_array();
                            if($fee['fee']==null){
                                $fee = '0';
                            }else{
                                $fee = $fee['fee'];
                            }
                        }

                        //计算这个时间段,当前站点，当前币种的提币手续费
                        $sql = "select sum(fee) withdraw_fee from user_withdraws where wallet_status='DONE' and arrive_time>='".$day_format."' and arrive_time<'".$day_format_next."' and site_id=$n[site_id] and asset='".$result[$i]."'";
                        $withdraw_fee = $this->db->query($sql)->row_array();
                        if($withdraw_fee['withdraw_fee']==null){
                            $withdraw_fee = '0';
                        }else{
                            $withdraw_fee = $withdraw_fee['withdraw_fee'];
                        }
                        
                        $settlement_time = $day;
                        $created_at = $updated_at = date('Y-m-d H:i:s',time());
                        //入库
                        // var_dump($n['site_id'],$result[$i],$fee,$withdraw_fee,$stime,$etime);
                        $sql = "INSERT INTO `day_settlement_fee` (`site_id`,`asset`,`t_fee`,`w_fee`,`settlement_time`,`settlement_percent`,`created_at`,`updated_at`) VALUES ($n[site_id],'$result[$i]',$fee,$withdraw_fee,'$settlement_time',1,'$created_at','$updated_at')";
                        // var_dump($sql);die;
                        $this->db->query($sql);
                    }
                    
                }

                $trans_status = $this->db->trans_status(); 
                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    returnJson('402','Transaction failed');
                } else {
                    $this->db->trans_commit();
                }
            }

            $sql = "select A.*,B.`name`,B.settlement_percent,B.ts_status,B.ws_status from day_settlement_fee A left join b_site B on A.site_id=B.id where A.settlement_time='".$day."'$where";
            $list = $this->db->query($sql)->result_array();
            foreach ($list as &$s) {
                $s['tfee'] = $s['t_fee']*$s['ts_status'];
                $s['wfee'] = $s['w_fee']*$s['ws_status'];
                $s['settlement_fee'] = bcadd((string)$s['tfee'], (string)$s['wfee'],12) * $s['settlement_percent'];
                if($s['status'] == 0)
                    $s['status_m'] = '否';
                else
                    $s['status_m'] = '是';
            }
            if(count($list)==0) return array('list'=>array());
            return $list;
        }
    }

    /**
     * 给子站增加手续费，手续费凭空增加。单独结算
     * @param  [type] $args [description]
     * @return [type]       [description]
     */
    public function settlement($args)
    {
        //获取子站要结算的用户id.取自转账管理里面的各个平台的id
        $site_id = $args['transfer_in_uid'];  //实质是站点id 
        $site_info = $this->db->query("select * from b_site where id=$site_id")->row_array();

        $sql = "select user_id from platform_account where site_id=$site_id and deleted_at is null and status=1 limit 1";
        $user_id1 = $this->db->query($sql)->row_array();
        $user_id1 = $user_id1['user_id'];//子站平台账户
        if($user_id1==NULL)   returnJson('300',lang('transfer_in_uid not exist'));

        $settlement_percent = $site_info['settlement_percent'];

        $ts_status = (string)$site_info['ts_status'];
        $ws_status = (string)$site_info['ws_status'];

        $id = $args['id'];
        $sql = "select * from settlement_fee where id = $id";
        $result = $this->db->query($sql)->row_array();

        if($result['status']==1) returnJson('402','状态异常，无法结算');

        $asset = $result['asset'];
        $t_fee = (string)$result['t_fee'];
        $w_fee = (string)$result['w_fee'];
        $trade_amount = bcmul($ts_status, $t_fee,12);
        $withdraw_amount = bcmul($ws_status, $w_fee,12);
        $pre_amount = bcadd($trade_amount,$withdraw_amount,12);
        $amount = bcmul($pre_amount, (string)$settlement_percent,12);//子站账户进账 手续费分成
        // $platform_percent = 1-$settlement_percent;
        $platform_amount = bcadd(bcmul((string)$result['t_fee'], $ts_status,12), bcmul((string)$result['w_fee'], $ws_status,12),12);
        $platform_amount = bcsub($platform_amount, $amount,12);

        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());
        $this->db->trans_begin();
        //插入转账记录表
        $bussness_id = $this->Platfrom_transfer_record_model->settlement_add($operation_admin_id,$time,$asset,$amount,0,$remark,$site_id, $user_id1); //记录，并给其增加对应资产
        $bussness_id1 = $this->Platfrom_transfer_record_model->settlement_add($operation_admin_id,$time,$asset,$platform_amount,33,$remark,$site_id,0);//只是记录
        $bussness = 'admin_settlement_fee'; //手续费结转
        $remark = array('info'=>$remark);
        $remark = json_encode($remark);
        // var_dump($user_id1,$asset,$amount,$bussness_id,$remark,$bussness);die;
        // $res1 = update_user_balance_bycurl($user_id1,$asset,$amount,$bussness_id,$remark,$bussness);
        $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id1,0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark,$remark);
        // $res2 = update_user_balance_bycurl(33,$asset,$platform_amount,$bussness_id1,$remark,$bussness);
        //更改结算表settlement_fee表的status
        $sql = "update settlement_fee set status=1 where id =$id";
        $this->db->query($sql);
        $trans_status = $this->db->trans_status();

        $data = $res1['details'];
        if($res1['code'] != 0)
        {
            $trans_status = false;
        }else{
            $res2 = $this->Sys_grpc_service->ActivityBalanceUpdate(33,0,$asset,$bussness,$bussness_id1,$platform_amount,1,$remark,$remark);
            if($res2['code'] != 0){
                $trans_status = false;
                $data = $res2['details'];
            }
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return $data;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    /**
     * 给子站增加手续费，手续费凭空增加。单独结算
     * @param  [type] $args [description]
     * @return [type]       [description]
     */
    public function day_settlement($args)
    {
        //获取子站要结算的用户id.取自转账管理里面的各个平台的id
        $site_id = $args['transfer_in_uid'];  //实质是站点id 
        $site_info = $this->db->query("select * from b_site where id=$site_id")->row_array();

        $sql = "select user_id from platform_account where site_id=$site_id and deleted_at is null and status=1 limit 1";
        $user_id1 = $this->db->query($sql)->row_array();
        $user_id1 = $user_id1['user_id'];//子站平台账户
        if($user_id1==NULL)   returnJson('300',lang('transfer_in_uid not exist'));

        $settlement_percent = $site_info['settlement_percent'];

        $ts_status = (string)$site_info['ts_status'];
        $ws_status = (string)$site_info['ws_status'];

        $id = $args['id'];
        $sql = "select * from day_settlement_fee where id = $id";
        $result = $this->db->query($sql)->row_array();
        // var_dump($result);die;

        if($result===NULL || $result['status']==1) returnJson('402','状态异常，无法结算');
        
        $asset = $result['asset'];
        $t_fee = (string)$result['t_fee'];
        $w_fee = (string)$result['w_fee'];
        $trade_amount = bcmul($ts_status, $t_fee,12);
        $withdraw_amount = bcmul($ws_status, $w_fee,12);
        $pre_amount = bcadd($trade_amount,$withdraw_amount,12);
        $amount = bcmul($pre_amount, (string)$settlement_percent,12);//子站账户进账 手续费分成
        // $platform_percent = 1-$settlement_percent;
        $platform_amount = bcadd(bcmul((string)$result['t_fee'], $ts_status,12), bcmul((string)$result['w_fee'], $ws_status,12),12);
        $platform_amount = bcsub($platform_amount, $amount,12);

        $remark = isset($args['remark']) ? $args['remark'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());
        $this->db->trans_begin();
        //插入转账记录表
        $bussness_id = $this->Platfrom_transfer_record_model->day_settlement_add($operation_admin_id,$time,$asset,$amount,0,$remark,$site_id, $user_id1); //记录，并给其增加对应资产
        $bussness_id1 = $this->Platfrom_transfer_record_model->day_settlement_add($operation_admin_id,$time,$asset,$platform_amount,33,$remark,$site_id,0);//只是记录
        $bussness = 'admin_settlement_fee'; //手续费结转
        $remark = array('info'=>$remark);
        $remark = json_encode($remark);
        // var_dump($user_id1,$asset,$amount,$bussness_id,$remark,$bussness);die;
        // $res1 = update_user_balance_bycurl($user_id1,$asset,$amount,$bussness_id,$remark,$bussness);
        $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id1,0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark,$remark);
        // var_dump($res1);
        // $res2 = update_user_balance_bycurl(33,$asset,$platform_amount,$bussness_id1,$remark,$bussness);
        //更改结算表settlement_fee表的status
        $sql = "update day_settlement_fee set status=1 where id =$id";
        $this->db->query($sql);

        $trans_status = $this->db->trans_status();

        $data = $res1['details'];
        if($res1['code'] != 0)
        {
            $trans_status = false;
        }else{
            $res2 = $this->Sys_grpc_service->ActivityBalanceUpdate('33',0,$asset,$bussness,$bussness_id1,$platform_amount,1,$remark,$remark);
            if($res2['code'] != 0){
                $trans_status = false;
                $data = $res2['details'];
            }
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return $data;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }
    /**
     * [手续费日结批量结算]
     * @param  [type] $args [description]
     * @return [type]       [description]
     */
    public function day_settlement_all($args)
    {
        //批量结算时间 ‘2019-04-15’
        $settlement_time = $args['settlement_time'];
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        if($site_id===''){
            $sql = "select * from day_settlement_fee where settlement_time='".$settlement_time."' and status=0";
        }else{
            $sql = "select * from day_settlement_fee where settlement_time='".$settlement_time."' and status=0 and site_id=$site_id";
        }
        // var_dump($sql);die; 
        $list = $this->db->query($sql)->result_array();
        // var_dump($list);die;
        foreach ($list as $k => $v) {
            $site_id = $v['site_id'];  //实质是站点id 
            $site_info = $this->db->query("select * from b_site where id=$site_id")->row_array();

            $sql = "select A.user_id,B.name from platform_account A left join b_site B on A.site_id=B.id where A.site_id=$site_id and A.deleted_at is null and A.status=1 limit 1";
            $info = $this->db->query($sql)->row_array();
            $user_id1 = $info['user_id'];//子站平台用户ID
            $site_name = $info['name'];//子站名称
            $response = '站点"'.$site_name.'"的平台账户不存在，请设置好再进行操作';
            if($user_id1==NULL)   returnJson('300',$response);
        }

        foreach ($list as $k => $v) {
            //获取子站要结算的用户id.取自转账管理里面的各个平台的id
            $site_id = $v['site_id'];  //实质是站点id 
            $site_info = $this->db->query("select * from b_site where id=$site_id")->row_array();

            $sql = "select user_id from platform_account where site_id=$site_id and deleted_at is null and status=1 limit 1";
            $user_id1 = $this->db->query($sql)->row_array();
            $user_id1 = $user_id1['user_id'];//子站平台账户
            if($user_id1==NULL)   returnJson('300',lang('transfer_in_uid not exist'));

            $settlement_percent = $site_info['settlement_percent'];

            $ts_status = (string)$site_info['ts_status'];
            $ws_status = (string)$site_info['ws_status'];

            $id = $v['id'];
            $sql = "select * from day_settlement_fee where id = $id";
            $result = $this->db->query($sql)->row_array();
            // var_dump($result);die;

            if($result===NULL || $result['status']==1) returnJson('402','状态异常，无法结算');
            
            $asset = $result['asset'];
            $t_fee = (string)$result['t_fee'];
            $w_fee = (string)$result['w_fee'];
            $trade_amount = bcmul($ts_status, $t_fee,12);
            $withdraw_amount = bcmul($ws_status, $w_fee,12);
            $pre_amount = bcadd($trade_amount,$withdraw_amount,12);
            $amount = bcmul($pre_amount, (string)$settlement_percent,12);//子站账户进账 手续费分成
            // $platform_percent = 1-$settlement_percent;
            $platform_amount = bcadd(bcmul((string)$result['t_fee'], $ts_status,12), bcmul((string)$result['w_fee'], $ws_status,12),12);
            $platform_amount = bcsub($platform_amount, $amount,12);

            $remark = isset($args['remark']) ? $args['remark'] : '';
            $operation_admin_id = $this->user_id;
            $time = date('Y-m-d H:i:s',time());
            $this->db->trans_begin();
            //插入转账记录表
            $bussness_id = $this->Platfrom_transfer_record_model->day_settlement_add($operation_admin_id,$time,$asset,$amount,0,$remark,$site_id, $user_id1); //记录，并给其增加对应资产
            $bussness_id1 = $this->Platfrom_transfer_record_model->day_settlement_add($operation_admin_id,$time,$asset,$platform_amount,33,$remark,$site_id,0);//只是记录
            $bussness = 'admin_settlement_fee'; //手续费结转
            $remark = array('info'=>$remark);
            $remark = json_encode($remark);
            // var_dump($user_id1,$asset,$amount,$bussness_id,$remark,$bussness);die;
            // $res1 = update_user_balance_bycurl($user_id1,$asset,$amount,$bussness_id,$remark,$bussness);
            $res1 = $this->Sys_grpc_service->ActivityBalanceUpdate($user_id1,0,$asset,$bussness,$bussness_id,$amount,$site_id,$remark,$remark);
            // usleep(20000);
            // $res2 = update_user_balance_bycurl(33,$asset,$platform_amount,$bussness_id1,$remark,$bussness);
            //更改结算表settlement_fee表的status
            $sql = "update day_settlement_fee set status=1 where id =$id";
            $this->db->query($sql);

            $trans_status = $this->db->trans_status();


            $data = $res1['details'];
            if($res1['code'] != 0)
            {
                $trans_status = false;
            }else{
                $res2 = $this->Sys_grpc_service->ActivityBalanceUpdate(33,0,$asset,$bussness,$bussness_id1,$platform_amount,1,$remark,$remark);
                if($res2['code'] != 0){
                    $trans_status = false;
                    $data = $res2['details'];
                }
            }

            if ($trans_status === false) {
                $this->db->trans_rollback();
                // return $args;
            } else {
                $this->db->trans_commit();
                // return true;
            }
        }
        return true;
    }

    public function settlement_record_list($start_time,$end_time,$offset,$limit,$asset)
    {
        $object = $this->db->select("platfrom_settlement_record.*")
        ->from('platfrom_settlement_record');
        $object =$this->db->where('platfrom_settlement_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_settlement_record.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_settlement_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_settlement_record.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    public function settlement_record_list_count($start_time,$end_time,$asset)
    {
        $object = $this->db->select("platfrom_settlement_record.*")
        ->from('platfrom_settlement_record');
        $object =$this->db->where('platfrom_settlement_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_settlement_record.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_settlement_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_settlement_record.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    public function day_settlement_record_list($start_time,$end_time,$offset,$limit,$asset)
    {
        $object = $this->db->select("platfrom_daysettlement_record.*")
        ->from('platfrom_daysettlement_record');
        $object =$this->db->where('platfrom_daysettlement_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_daysettlement_record.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_daysettlement_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_daysettlement_record.created_at <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        foreach ($list as &$val){
            $site_name = $this->Zjys_symbols_model->get_symbols_name($val['site_id']);
            if(!empty($site_name['name'])){
                $val['site_name'] = $site_name['name'];
            }
            $admin_operator = $this->Admin_model->get_admin_name($val['operator']);
            if(!empty($admin_operator['true_name'])){
                $val['true_name'] = $admin_operator['true_name'];
            }
        }
        return $list;
    }

    public function day_settlement_record_list_count($start_time,$end_time,$asset)
    {
        $object = $this->db->select("platfrom_daysettlement_record.*")
        ->from('platfrom_daysettlement_record');
        $object =$this->db->where('platfrom_daysettlement_record.deleted_at is null');
        if($asset!='') $object =$this->db->where('platfrom_daysettlement_record.asset = ',$asset);
        if(!empty($start_time)){
            $object =$this->db->where('platfrom_daysettlement_record.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('platfrom_daysettlement_record.created_at <=',$end_time);
        }
        return $this->db->count_all_results();
    }
    /**
     * 手续费收入
     * @return [type] [description]
     */
    public function platform_balacne_payment($start_time,$end_time)
    {
        // var_dump($start_time);
        // var_dump($end_time);die;
        //获取生成好的列表数据即可
        $arr = array();
        $sql = "select * from platform_inout_detail where time_area>='".$start_time."' and time_area<'".$end_time."'";
        $data = $this->db->query($sql)->result_array();
        if(empty($data))
            return $data;
        // var_dump($sql);
        // var_dump($this->db->last_query());
        // var_dump($data);die;

        foreach($data as $k=>$v){
            if(!isset($item[$v['time_area']])){
                $item[$v['time_area']]=$v;
            }else{
                $item[$v['time_area']]['trade_fee']=bcadd($v['trade_fee'],$item[$v['time_area']]['trade_fee'],12);
                $item[$v['time_area']]['withdraw_fee']=bcadd($v['withdraw_fee'],$item[$v['time_area']]['withdraw_fee'],12);
                //$item[$v['time_area']]['activity_in']=bcadd($v['activity_in'],$item[$v['time_area']]['activity_in'],12);
                // $item[$v['time_area']]['activity_out']=bcadd($v['activity_out'],$item[$v['time_area']]['activity_out'],12);
                // $a = bcadd($item[$v['time_area']]['trade_fee'],$item[$v['time_area']]['withdraw_fee'],12);
                $item[$v['time_area']]['unit'] = bcadd($item[$v['time_area']]['trade_fee'],$item[$v['time_area']]['withdraw_fee'],12);
                // $b = bcsub($a,-$item[$v['time_area']]['activity_in'],12);
                // $item[$v['time_area']]['unit'] = bcsub($b,$item[$v['time_area']]['activity_out'],12);
            }
        }
        $item = array_values($item);
        return $item;
    }


    public function platform_balacne_payment_detail($time_area)
    {
        $arr = array();
        $sql = "select * from platform_inout_detail where time_area like '".$time_area."'";
        // var_dump($sql);die;
        $data = $this->db->query($sql)->result_array();
        foreach ($data as &$v) {
            // $a = bcadd($v['trade_fee'],$v['withdraw_fee'],12);
            // $b = bcsub($a,-$v['activity_in'],12);
            $v['unit'] = bcadd($v['trade_fee'],$v['withdraw_fee'],12);
        }
        return $data;
    }
}
