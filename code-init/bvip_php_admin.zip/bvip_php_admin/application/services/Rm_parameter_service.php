<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rm_parameter_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
      
    }

    // ------------------------- 数字货币类型---------------------------------
    public function get_currency_list($offset,$limit,$site_id){
        $list =  $this->Rm_parameter->get_currency_list($offset,$limit,$site_id);
        foreach ($list as &$val){
            $val['created_time'] = isset($val['created_time']) ? date('Y-m-d H:i:s',$val['created_time']) : '';
        }
        return $list;
    }
    

}