<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_symbols_service extends MY_Service{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_symbols_model');
        $this->load->model('Zjys_assets_model');
        $this->load->model('Site_model');
    }   

    //交易对列表
    public function symbol_list($offset,$limit,$symbol,$start_time,$end_time,$site_id){
        $object = $this->db->select("symbols.*,total_symbols.limit_taker_fee as max_limit_taker_fee,total_symbols.limit_maker_fee as max_limit_maker_fee,total_symbols.market_taker_fee as max_market_taker_fee,b_site.name")
        ->join('b_site','b_site.id=symbols.site_id','left')
        ->join('total_symbols','total_symbols.symbol=symbols.symbol','left')
        ->from('symbols');
        if($site_id!='') $object =$this->db->where('symbols.site_id = ',$site_id);
        if(!empty($symbol)){
            $object =$this->db->where('symbols.symbol =',$symbol);
        }
        if(!empty($start_time)){
            $object =$this->db->where('symbols.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('symbols.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        foreach($list as &$value) {
            # code...
            if($value['status'] == 1){
                $value['status'] = '1';
            }else{
                $value['status'] = '0';
            }
            if($value['recommend'] == 1){
                $value['recommend'] = '1';
            }else{
                $value['recommend'] = '0';
            }
        }
        return $list;
    }

     //交易对列表
    public function system_symbol_list($offset,$limit,$symbol,$start_time,$end_time){
        $object = $this->db->select("total_symbols.*")
            ->from('total_symbols');
        if(!empty($symbol)){
            $object =$this->db->where('total_symbols.symbol =',$symbol);
        }
        if(!empty($start_time)){
            $object =$this->db->where('total_symbols.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('total_symbols.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        foreach($list as &$value) {
            # code...
            if($value['status'] == 1){
                $value['status'] = '1';
            }else{
                $value['status'] = '0';
            }
            if($value['recommend'] == 1){
                $value['recommend'] = '1';
            }else{
                $value['recommend'] = '0';
            }
        }
        return $list;
    }


    public function system_symbol_list_count($symbol,$start_time,$end_time){
        $object = $this->db->select("total_symbols.*")
            ->from('total_symbols');
        if(!empty($symbol)){
            $object =$this->db->where('total_symbols.symbol =',$symbol);
        }
        if(!empty($start_time)){
            $object =$this->db->where('total_symbols.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('total_symbols.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }

     //交易对列表
    public function symbol_list_totalsite($offset,$limit,$symbol,$start_time,$end_time,$site_id){
        if($this->config->item('SITE') === 'priv_one'){
            $object = $this->db->select("symbol,status,recommend,is_exclusive")
            ->from('symbols');
            $object =$this->db->where('symbols.site_id =',$site_id);
            if(!empty($symbol)){
                $object =$this->db->where('symbols.symbol =',$symbol);
            }
            if(!empty($start_time)){
                $object =$this->db->where('symbols.created_at >=',$start_time);
            }
            if(!empty($end_time)){
                $object =$this->db->where('symbols.created_at <',$end_time);
            }
            $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
            foreach($list as &$value) {
                # code...
                if($value['status'] == 1){
                    $value['status'] = 1;
                }else{
                    $value['status'] = 0;
                }
                if($value['recommend'] == 1){
                    $value['recommend'] = 1;
                }else{
                    $value['recommend'] = 0;
                }
            }
            return $list;
        }else{
            $object = $this->db->select("symbol,status,recommend,is_exclusive")
            ->from('total_symbols');
            if(!empty($symbol)){
                $object =$this->db->where('total_symbols.symbol =',$symbol);
            }

            if(!empty($site_id)){
                $object =$this->db->where('total_symbols.sub_true = 0 and is_exclusive=0');
                $object =$this->db->or_where('total_symbols.sub_true =',1);
                $object =$this->db->or_where('total_symbols.sub_true = 0 and is_exclusive=',$site_id);
                
            }

            if(!empty($start_time)){
                $object =$this->db->where('total_symbols.created_at >=',$start_time);
            }
            if(!empty($end_time)){
                $object =$this->db->where('total_symbols.created_at <',$end_time);
            }
            $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
            foreach($list as &$value) {
                # code...
                if($value['status'] == 1){
                    $value['status'] = 1;
                }else{
                    $value['status'] = 0;
                }
                if($value['recommend'] == 1){
                    $value['recommend'] = 1;
                }else{
                    $value['recommend'] = 0;
                }
            }
            return $list;
        }
        
    }

    //交易对列表查询总数
    public function symbol_list_count($symbol,$start_time,$end_time,$site_id){
        $object = $this->db->select("symbols.*,b_site.name")
            ->join('b_site','b_site.id=symbols.site_id','left')
            ->from('symbols');
            if($site_id!='') $object =$this->db->where('symbols.site_id = ',$site_id);
        if(!empty($symbol)){
            $object =$this->db->where('symbols.symbol =',$symbol);
        }
        if(!empty($start_time)){
            $object =$this->db->where('symbols.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('symbols.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }


    //添加币种类
    public function add_symbol($args)
    {

        $id = isset($args['id']) ? $args['id']: '';
        $base_asset = isset($args['base_asset']) ? $args['base_asset']: '';
        $base_asset_name = isset($args['base_asset_name']) ? $args['base_asset_name']: '';
        $quote_asset = isset($args['quote_asset']) ? $args['quote_asset']: '';
        $quote_asset_name = isset($args['quote_asset_name']) ? $args['quote_asset_name']: '';
        if($base_asset === $quote_asset) returnJson('402','目标资产和基准资产不能相同');
        $symbol = isset($args['symbol']) ? $args['symbol']: '';
        $tick_size = isset($args['tick_size']) ? $args['tick_size']: '';
        $min_quantity = isset($args['min_quantity']) ? $args['min_quantity']: '';
        $status = isset($args['status']) ? $args['status']: '';
        $recommend = isset($args['recommend']) ? $args['recommend']: '';
        $limit_taker_fee = isset($args['limit_taker_fee']) ? $args['limit_taker_fee']: '';
        $limit_maker_fee = isset($args['limit_maker_fee']) ? $args['limit_maker_fee']: '';
        $market_taker_fee = isset($args['market_taker_fee']) ? $args['market_taker_fee']: '';
        $base_asset_precision = isset($args['base_asset_precision']) ? $args['base_asset_precision']: '';
        $quote_asset_precision = isset($args['quote_asset_precision']) ? $args['quote_asset_precision']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: 1; //不传默认为1，总站
        $is_display = isset($args['is_display']) ? $args['is_display']: 1; //是否前台显示

        // $site_id = isset($args['site_id']) ? $args['site_id']: 1; //不传默认为1，总站
        if($this->config->item('SITE') === 'priv_one') $site_id = 1;
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());

        $this->db->trans_begin();

        if(!$id){
            //新增
            $is_true = $this->Zjys_symbols_model->symbol_true($symbol,$site_id);
            if(is_array($is_true) && !empty($is_true)) returnJson('402','该交易对已存在,不能重复添加！');
            $this->Zjys_symbols_model->add_symbol($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$site_id,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$is_display,$base_asset_name,$quote_asset_name);
            // return true;
        }else{
            //修改
            $this->Zjys_symbols_model->edit_symbol($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$site_id,$updated_at,$base_asset_precision,$quote_asset_precision,$id,$is_display,$base_asset_name,$quote_asset_name);
        }

        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }


    public function system_symbol_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $base_asset = isset($args['base_asset']) ? $args['base_asset']: '';
        $base_asset_name = isset($args['base_asset_name']) ? $args['base_asset_name']: '';
        $quote_asset = isset($args['quote_asset']) ? $args['quote_asset']: '';
        $quote_asset_name = isset($args['quote_asset_name']) ? $args['quote_asset_name']: '';
        $symbol = isset($args['symbol']) ? $args['symbol']: '';
        $tick_size = isset($args['tick_size']) ? $args['tick_size']: '';
        $min_quantity = isset($args['min_quantity']) ? $args['min_quantity']: '';
        $status = isset($args['status']) ? $args['status']: '';
        $recommend = isset($args['recommend']) ? $args['recommend']: '';
        $limit_taker_fee = isset($args['limit_taker_fee']) ? $args['limit_taker_fee']: '';
        $limit_maker_fee = isset($args['limit_maker_fee']) ? $args['limit_maker_fee']: '';
        $market_taker_fee = isset($args['market_taker_fee']) ? $args['market_taker_fee']: '';
        $base_asset_precision = isset($args['base_asset_precision']) ? $args['base_asset_precision']: '';
        $quote_asset_precision = isset($args['quote_asset_precision']) ? $args['quote_asset_precision']: '';
        $sub_true = isset($args['sub_true']) ? $args['sub_true']: 0;
        $created_at = date("Y-m-d H:i:s",time());
        $updated_at = date("Y-m-d H:i:s",time());
        $is_exclusive = isset($args['is_exclusive']) ? $args['is_exclusive']: 0;
        $alert_percent = isset($args['alert_percent']) ? $args['alert_percent']: 0;

        $this->db->trans_begin();
        $site_all = $this->Site_model->site_all();

        if(!$id){
            //新增交易对
            $is_true = $this->Zjys_symbols_model->get_sys_symbol_detail($symbol);
            if(is_array($is_true) && !empty($is_true)) returnJson('402','该交易对已经存在');

            if($sub_true == 1){ //子站默认（添加系统成功之后，所有子站都会生成此交易对）
                $is_baseasset_true = $this->Zjys_assets_model->get_sys_asset_detail($base_asset);
                $is_quoteasset_true = $this->Zjys_assets_model->get_sys_asset_detail($quote_asset);
                if($is_baseasset_true['sub_true'] == 0 || $is_quoteasset_true['sub_true'] == 0) returnJson('402','当前有币资产处于非默认状态，请修改之后再添加');

                $insert_id = $this->Zjys_symbols_model->system_symbol_add($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,0,$base_asset_name,$quote_asset_name,$alert_percent);
                // var_dump($site_all);die;
                foreach ($site_all as $key => $value) {
                    $result = $this->Zjys_symbols_model->add_symbol_true($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$value['id'],$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$sub_true,$base_asset_name,$quote_asset_name,$alert_percent);
                }
            }else{
                if($is_exclusive == 1){ //子站专属
                    $site_id = trim($args['site_id']); 
                    if(empty($site_id)) returnJson('402','请选择站点');
                    $is_true = $this->Site_model->site_one($site_id); 
                    if(is_array($is_true) && empty($is_true)) returnJson('402','无该站点');

                    $insert_id = $this->Zjys_symbols_model->system_symbol_add($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$site_id,$base_asset_name,$quote_asset_name,$alert_percent);
                }else{
                    $insert_id = $this->Zjys_symbols_model->system_symbol_add($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,0,$base_asset_name,$quote_asset_name,$alert_percent);
                }
            }
            admin_operation_logs($this->user_id,0,41,'新增系统交易对',date('Y-m-d H:i:s',time()),$insert_id);
        }else{
            $detail = $this->Zjys_symbols_model->get_system_asset_detail_byid($id);
            if($detail['sub_true'] == 1){
                if($sub_true ==1){
                    $this->Zjys_symbols_model->system_symbol_edit($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$updated_at,$base_asset_precision,$quote_asset_precision,$id,0,$base_asset_name,$quote_asset_name,$alert_percent);

                    foreach ($site_all as $key => $value) {
                        $this->Zjys_symbols_model->symbol_delete($value['id'],$detail['symbol']);
                    }

                    foreach ($site_all as $key => $value) {
                        $result = $this->Zjys_symbols_model->add_symbol_true($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$value['id'],$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$sub_true,$base_asset_name,$quote_asset_name,$alert_percent);
                    }
                }else{
                    foreach ($site_all as $key => $value) {
                        $this->Zjys_symbols_model->system_symbol_edit($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$updated_at,$base_asset_precision,$quote_asset_precision,$id,0,$base_asset_name,$quote_asset_name,$alert_percent);
                    }
                    foreach ($site_all as $key => $value) {
                        $this->Zjys_symbols_model->symbol_delete($value['id'],$detail['symbol']);
                    }
                    if($is_exclusive == 1){
                        $site_id = trim($args['site_id']); 
                        if(empty($site_id)) returnJson('402','请选择站点');
                        $is_true = $this->Site_model->site_one($site_id); 
                        if(is_array($is_true) && empty($is_true)) returnJson('402','无该站点');

                        $this->Zjys_symbols_model->system_symbol_edit($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$updated_at,$base_asset_precision,$quote_asset_precision,$id,$site_id,$base_asset_name,$quote_asset_name,$alert_percent);
                    }else{
                        $this->Zjys_symbols_model->system_symbol_edit($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$updated_at,$base_asset_precision,$quote_asset_precision,$id,0,$base_asset_name,$quote_asset_name,$alert_percent);
                    }
                }
            }else{
                if($sub_true ==1){
                    $is_baseasset_true = $this->Zjys_assets_model->get_sys_asset_detail($base_asset);
                    $is_quoteasset_true = $this->Zjys_assets_model->get_sys_asset_detail($quote_asset);
                    if($is_baseasset_true['sub_true'] == 0 || $is_quoteasset_true['sub_true'] == 0) returnJson('402','当前有币资产处于非默认状态，请修改之后再添加');

                    $this->Zjys_symbols_model->system_symbol_edit($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$updated_at,$base_asset_precision,$quote_asset_precision,$id,0,$base_asset_name,$quote_asset_name,$alert_percent);
                    foreach ($site_all as $key => $value) {
                        $result = $this->Zjys_symbols_model->add_symbol_true($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$value['id'],$created_at,$updated_at,$base_asset_precision,$quote_asset_precision,$sub_true,$base_asset_name,$quote_asset_name,$alert_percent);
                    }
                }else{
                    if($is_exclusive == 1){
                        $site_id = trim($args['site_id']); 
                        if(empty($site_id)) returnJson('402','请选择站点');
                        $is_true = $this->Site_model->site_one($site_id); 
                        if(is_array($is_true) && empty($is_true)) returnJson('402','无该站点');

                        $this->Zjys_symbols_model->system_symbol_edit($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$updated_at,$base_asset_precision,$quote_asset_precision,$id,$site_id,$base_asset_name,$quote_asset_name,$alert_percent);
                    }else{
                        $this->Zjys_symbols_model->system_symbol_edit($base_asset,$quote_asset,$symbol,$tick_size,$min_quantity,$status,$recommend,$limit_taker_fee,$limit_maker_fee,$market_taker_fee,$sub_true,$updated_at,$base_asset_precision,$quote_asset_precision,$id,0,$base_asset_name,$quote_asset_name,$alert_percent);
                    }
                }
            }
            
            admin_operation_logs($this->user_id,0,42,'编辑系统交易对',date('Y-m-d H:i:s',time()),$id);
            $this->Zjys_symbols_model->correct_symbols($symbol,$alert_percent);

            $data = array();
            $data['type'] = 0;
            $this->db->where('id', $id);
            $record_id =  $this->db->update('total_symbols', $data);

        }
        
        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();

            return true;
        }
    }

    //获取所有交易对
    public function list_all(){
        // echo 5;die;
        return $this->Zjys_symbols_model->list_all();
    }



    //交易区块配置相关
    public function symbolblock_list($offset,$limit,$shorthand,$site_id,$start_time,$end_time)
    {
        $object = $this->db->select("symbol_classes.*,b_site.name as site_name")
            ->join('b_site','b_site.id=symbol_classes.site_id','left')
            ->where('deleted_at is null')
            ->from('symbol_classes');

        if($site_id!='') $object =$this->db->where('symbol_classes.site_id = ',$site_id);

        if(!empty($shorthand)){
            $object =$this->db->where('symbol_classes.shorthand =',$shorthand);
        }
        if(!empty($start_time)){
            $object =$this->db->where('symbol_classes.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('symbol_classes.created_at <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('display_order','asc')->get()->result_array();
        foreach ($list as &$value) {
            $value['symbol_ids'] = $this->get_relation($value['id']);
            $value['name_zh_hans'] = $this->get_name_exp($value['id'],'zh-hans');
            $value['name_zh_hant'] = $this->get_name_exp($value['id'],'zh-hant');
            $value['name_en'] = $this->get_name_exp($value['id'],'en');
            $value['name_ja'] = $this->get_name_exp($value['id'],'ja');
            $value['statement_zh_hans'] = $this->get_statement_exp($value['id'],'zh-hans');
            $value['statement_zh_hant'] = $this->get_statement_exp($value['id'],'zh-hant');
            $value['statement_en'] = $this->get_statement_exp($value['id'],'en');
            $value['statement_ja'] = $this->get_statement_exp($value['id'],'ja');
        }
        return $list;
    }
    //获取交易板块对应多语言名称
    public function get_name_exp($symbol_classes_id,$lang)
    {
        $result = $this->Zjys_symbols_model->get_name_exp($symbol_classes_id,$lang);
        if(count($result)==0)
            return '';
        else
            return $result['name'];
    }

    //获取交易板块对应多语言声明
    public function get_statement_exp($symbol_classes_id,$lang)
    {
        $result = $this->Zjys_symbols_model->get_statement_exp($symbol_classes_id,$lang);
        if(count($result)==0)
            return '';
        else
            return $result['statement'];
    }

    public function symbolblock_list_count($shorthand,$site_id,$start_time,$end_time)
    {
        $object = $this->db->select("symbol_classes.*")
            ->where('deleted_at is null')
            ->from('symbol_classes');

        if($site_id!='') $object =$this->db->where('symbol_classes.site_id = ',$site_id);

        if(!empty($shorthand)){
            $object =$this->db->where('symbol_classes.shorthand =',$shorthand);
        }
        if(!empty($start_time)){
            $object =$this->db->where('symbol_classes.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('symbol_classes.created_at <',$end_time);
        }
        return $this->db->count_all_results();
    }

    public function symbolblock_list_noauth($site_id)
    {
        return $this->Zjys_symbols_model->symbolblock_list_noauth($site_id);
    }


    public function symbolblock_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';

        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $lang = isset($args['lang']) ? $args['lang']: 'zh-hans';

        $name_zh_hans = isset($args['name_zh_hans']) ? $args['name_zh_hans']: '';
        $name_zh_hant = isset($args['name_zh_hant']) ? $args['name_zh_hant']: '';
        $name_en = isset($args['name_en']) ? $args['name_en']: '';
        $name_ja = isset($args['name_ja']) ? $args['name_ja']: '';
        $statement_zh_hans = isset($args['statement_zh_hans']) ? $args['statement_zh_hans']: '';
        $statement_zh_hant = isset($args['statement_zh_hant']) ? $args['statement_zh_hant']: '';
        $statement_en = isset($args['statement_en']) ? $args['statement_en']: '';
        $statement_ja = isset($args['statement_ja']) ? $args['statement_ja']: '';
        $icon = isset($args['icon']) ? $args['icon']: '';

        $unique_id = isset($args['unique_id']) ? $args['unique_id']: '';
        $display_order = isset($args['display_order']) ? $args['display_order']: '';
        $shorthand = isset($args['shorthand']) ? $args['shorthand']: '';
        $symbol_ids = isset($args['symbol_ids']) ? $args['symbol_ids']: '';
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $symbol_ids_array = explode(',',$symbol_ids);
        $count = count($symbol_ids_array);

        

        
        $this->db->trans_begin();

        if(!$id){
            if($this->Zjys_symbols_model->is_name_true($site_id,$name_zh_hans)) returnJson('402','已有站点存在该名称');
            if($this->Zjys_symbols_model->is_unique_true($site_id,$unique_id)) returnJson('402','已有站点存在该名称');
            if($this->Zjys_symbols_model->is_shorthand_true($site_id,$shorthand)) returnJson('402','已有站点存在该名称');
            //新增
            $insert_id = $this->Zjys_symbols_model->add_symbolblock($site_id,$name_zh_hans,$unique_id,$display_order,$shorthand,$created_at,$updated_at,$count,$lang,$icon);
            $this->Zjys_symbols_model->add_symbolclasses_exp($name_zh_hans,$insert_id,$statement_zh_hans,'zh-hans');
            $this->Zjys_symbols_model->add_symbolclasses_exp($name_zh_hant,$insert_id,$statement_zh_hant,'zh-hant');
            $this->Zjys_symbols_model->add_symbolclasses_exp($name_en,$insert_id,$statement_en,'en');
            $this->Zjys_symbols_model->add_symbolclasses_exp($name_ja,$insert_id,$statement_ja,'ja');
            //新增关联表数据
            // var_dump($insert_id);die;
            for($i=0;$i<$count;$i++){
                $this->Zjys_symbols_model->add_symbols_relation($created_at,$updated_at,$symbol_ids_array[$i],$insert_id);
            }

        }else{

            //修改
            $this->Zjys_symbols_model->edit_symbolblock($site_id,$name_zh_hans,$unique_id,$display_order,$shorthand,$updated_at,$id,$count,$lang,$icon);
            //删除原有关联表
            $this->Zjys_symbols_model->delete_relations($id,$created_at);
            $this->Zjys_symbols_model->delete_symbolclasses_exp($id);
            //新增标题、申明的语言
            $this->Zjys_symbols_model->add_symbolclasses_exp($name_zh_hans,$id,$statement_zh_hans,'zh-hans');
            $this->Zjys_symbols_model->add_symbolclasses_exp($name_zh_hant,$id,$statement_zh_hant,'zh-hant');
            $this->Zjys_symbols_model->add_symbolclasses_exp($name_en,$id,$statement_en,'en');
            $this->Zjys_symbols_model->add_symbolclasses_exp($name_ja,$id,$statement_ja,'ja');
            //新增关联
            for($i=0;$i<$count;$i++){
                $this->Zjys_symbols_model->add_symbols_relation($created_at,$updated_at,$symbol_ids_array[$i],$id);
            }

        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }

    public function symbolblock_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        $this->Zjys_symbols_model->delete_relations($id,$time);
        $this->Zjys_symbols_model->delete_symbolclasses_exp($id);
        return $this->Zjys_symbols_model->symbolblock_delete($id,$time);
    }

    public function get_relation($id)
    {
        $res = $this->Zjys_symbols_model->get_relation($id);
        if(is_array($res) && empty($res)) return '';

        foreach ($res as $key => $value) {
            $symbol_ids[$key] = $value['symbol_id'];
        }
        return implode(',', $symbol_ids);
    }


    /**
     * Notes: 交易对配置审核
     * User: 张哲
     * Date: 2019-07-22
     * Time: 15:48
     * @param $args
     */
    public function systemSymbolAddVerity($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $type = isset($args['type']) ? $args['type']: '';
        $object = $this->db->select("total_symbols.*")
            ->from('total_symbols');
        $object =$this->db->where('total_symbols.id =',$id);
        $list1 = $object->order_by('id','desc')->get()->result_array();
        if(empty($list1)) returnJson('402','没有该记录');

        if($type == 0){
            $id = isset($args['id']) ? $args['id']: '';
            $data = array();
            $data['type'] = 2;
            $data['remark'] = $args['remark'];
            $updated_at = date("Y-m-d H:i:s",time());
            $data['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $record_id =  $this->db->update('total_symbols', $data);
        }else{
            $id = isset($args['id']) ? $args['id']: '';
            $data = array();
            $data['type'] = 1;
            $data['remark'] = $args['remark'];
            $updated_at = date("Y-m-d H:i:s",time());
            $data['updated_at'] = $updated_at;
            $this->db->where('id', $id);
            $record_id =  $this->db->update('total_symbols', $data);
        }



        if(!empty($record_id))
            $business_id = $id;
        $user_id = '';
        $time = date('Y-m-d H:i:s',time());
        $business = '29'; //o
        $description = '交易对审核';
        admin_operation_logs($this->user_id,$user_id,$business,$description,$time,$business_id);
    }

    /**
     * Notes: 交易对日志
     * User: 张哲
     * Date: 2019-07-23
     * Time: 17:54
     */
    public function systemSymbolDetailsLogs($args)
    {
        $id = isset($args['id']) ? $args['id'] : '';

        //先查看是否有次用户
        $object = $this->db->select("admin_operation_logs.*")
            ->from('admin_operation_logs');
        $object = $this->db->where('admin_operation_logs.business_id =', $id);
        $names = array('28','29');
        $object = $this->db->where_in('admin_operation_logs.operation_type', $names);
        $list = $object->order_by('id', 'desc')->get()->result_array();
        return $list;

    }

}
