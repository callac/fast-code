<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ini_set('display_errors', 1);
/**
 * 
 * 
 * 需要修改，
 * 用户管理
 * 登录注册是用的admin还要做权限控制
 * 
 */

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
class Zjys_trade_service extends MY_Service {

//
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Zjys_user_model');
        $this->load->model('Site_model');
        $this->load->model('Zjys_assets_model');
        $this->load->model('Zjys_symbols_model');
        $this->load->model('Zjys_user_operationmoney_model');
        $this->load->model('Zjys_tradelogstask_model');
    }

    //获取列表
    public function get_list($offset,$limit,$name,$start_time,$end_time,$site_id,$uid){
        $object = $this->db->select("users.*,users.realname as name,b_site.name as site_name")
        // ->join('user_identities','user_identities.user_id=users.id','left')
        ->join('b_site','users.site_id=b_site.id','left')
        ->from('users');
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        // $object =$this->db->where('user_identities.deleted_at is null');
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }
        
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();

        // var_dump($this->db->last_query());die;
        
        // $list = $object->order_by('last_login','desc')->get()->result_array();
        
        foreach ($list as &$val){
            if($val['register_method'] == 0){
                $val['register_method'] = '邮箱';
            }elseif ($val['register_method'] == 1){
                $val['register_method'] = '手机';
            }
            if ($val['user_identity_auth'] == 1){
                $val['user_identity_auth'] = '已认证';
            }else{
                $val['user_identity_auth'] = '未认证';
            }
            if($val['two_step_bound'] == 1){
                $val['two_step_bound'] = '通过';
            }else{
                $val['two_step_bound'] = '不通过';
            }
            //获取每个用户各个币种的资产情况(可用资金和交易冻结资金)
            // var_dump($list);die;
            if($site_id == '') $site_id = 1; //若是总账号登录，site_id默认为1，ZT站
            $totalassets = get_user_assets_by_curl($val['id'],$val['site_id']);
            // var_dump($totalassets);die;

            $val['total_available'] = $totalassets['available'];
            $val['total_freeze'] = $totalassets['freeze'];
            $val['other_freeze'] = $totalassets['other_freeze'];
            $val['total_trans'] = $totalassets['total_trans'];
            
            unset($val['password']);
            unset($val['withdraw_password']);
            unset($val['deleted_at']);
        }
        // var_dump($list);die;
        return $list;
    }

    /**
     * Notes: 用户资产-全部币种
     * User: 张哲
     * Date: 2019/1/17
     * Time: 15:42
     * @param $offset
     * @param $limit
     * @param $name
     * @param $start_time
     * @param $end_time
     * @param $site_id
     * @param $uid
     * @return mixed
     */
    public function get_list_all($offset,$limit,$name,$start_time,$end_time,$site_id,$uid){
        $object = $this->db->select("users.*,user_identities.name,b_site.name as site_name")
            ->join('user_identities','user_identities.user_id=users.id','left')
            ->join('b_site','users.site_id=b_site.id','left')
            ->from('users');
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        $object =$this->db->where('user_identities.deleted_at is null');
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        // $list = $object->order_by('last_login','desc')->get()->result_array();

        foreach ($list as &$val){
            if($val['register_method'] == 0){
                $val['register_method'] = '邮箱';
            }elseif ($val['register_method'] == 1){
                $val['register_method'] = '手机';
            }
            if ($val['user_identity_auth'] == 1){
                $val['user_identity_auth'] = '已认证';
            }else{
                $val['user_identity_auth'] = '未认证';
            }
            if($val['two_step_bound'] == 1){
                $val['two_step_bound'] = '通过';
            }else{
                $val['two_step_bound'] = '不通过';
            }
            //获取每个用户各个币种的资产情况(可用资金和交易冻结资金)
            // var_dump($list);die;
            if($site_id == '') $site_id = 1; //若是总账号登录，site_id默认为1，ZT站
            $totalassets = get_user_assets_by_curl_all($val['id'],$val['site_id']);

            $val['total_available'] = $totalassets['available'];
            $val['total_freeze'] = $totalassets['freeze'];
            $val['other_freeze'] = $totalassets['other_freeze'];
            $val['total_trans'] = $totalassets['total_trans'];

            unset($val['password']);
            unset($val['withdraw_password']);
            unset($val['deleted_at']);
        }
        // var_dump($list);die;
        return $list;
    }
    /**
     * [user_correctassetitem description]
     * @param  [int] $offset     [description]
     * @param  [int] $limit      [description]
     * @param  [string] $name       [description]
     * @param  [string] $realname   [description]
     * @param  [string] $start_time [description]
     * @param  [string] $end_time   [description]
     * @param  [int] $site_id    [description]
     * @param  [int] $uid        [description]
     * @return [array]             [description]
     */
    public function user_correctassetitem($offset,$limit,$name,$realname,$start_time,$end_time,$site_id,$uid)
    {
        $where = ' where 1=1';
        if($site_id!='')
            $where .= " and o.site_id = $site_id";
        if(!empty($name))
            $where .= " and ba.user_name ='".$name."'";
        if(!empty($realname))
            $where .= " and ui.realname = '".$realname."'";
        if(!empty($uid))
            $where .= " and o.user_id = $uid";
        if(!empty($start_time))
            $where .= " and o.created_time >= '".$start_time."'";
        if(!empty($end_time))
            $where .= " and o.created_time < '".$end_time."'";

        $other_where = " order by o.id desc";
        
        if(isset($offset) && $offset!=='' && $limit!=''){
            $other_where.= " limit $offset,$limit";
        }else{
            $other_where.= "";
        }

        $sql = "select o.*,ba.user_name,ba.true_name,ui.realname as name,bs.name as site_name from operation_money_logs o left join 
        b_admin ba on ba.user_id=o.admin_id left join users ui on ui.id=o.user_id left join 
        b_site bs on o.site_id=bs.id".$where.$other_where;

        $list = $this->db->query($sql)->result_array();
        foreach ($list as &$value) {
            $a = explode('.',$value['amount']);
            if(count($a)==2){
                if(bcsub($value['amount'], '0',12)<0){
                    if($a[0]==0)
                    {
                        $value['amount'] = '-'.number_format($a[0]).'.'.$a[1];
                    }else{
                        $value['amount'] = number_format($a[0]).'.'.$a[1];
                    }
                }else{
                    $value['amount'] = number_format($a[0]).'.'.$a[1];
                }
            }else{
                $value['amount'] = number_format($a[0]);
            }
        }
        return $list;
    }

    public function user_correctassetitem_count($name,$realname,$start_time,$end_time,$site_id,$uid)
    {
        $where = ' where 1=1';
        if($site_id!='')
            $where .= " and o.site_id = $site_id";
        if(!empty($name))
            $where .= " and ba.user_name ='".$name."'";
        if(!empty($realname))
            $where .= " and ui.realname = '".$realname."'";
        if(!empty($uid))
            $where .= " and o.user_id = $uid";
        if(!empty($start_time))
            $where .= " and o.created_time >= '".$start_time."'";
        if(!empty($end_time))
            $where .= " and o.created_time < '".$end_time."'";

        $other_where = " order by o.id desc";

        if(isset($offset) && $offset!=='' && $limit!=''){
            $other_where.= " limit $offset,$limit";
        }else{
            $other_where.= "";
        }

        $sql = "select count(1) as numrows from operation_money_logs o left join 
        b_admin ba on ba.user_id=o.admin_id left join users ui on ui.id=o.user_id left join 
        b_site bs on o.site_id=bs.id".$where.$other_where;

        $res = $this->db->query($sql)->result_array();
        if(is_array($res) && !empty($res))
            return $res[0]['numrows'];
        else
            return '0';
    }


    public function get_info_per_asset($id,$site_id){
        return get_per_user_assets_by_curl($id,$site_id);
    }


    /**
     * Notes: 所有
     * User: 张哲
     * Date: 2019/1/17
     * Time: 16:29
     * @param $id
     * @param $site_id
     * @return array
     */
    public function get_info_per_asset_all($id,$site_id){
        return get_per_user_assets_by_curl_all($id,$site_id);
    }

    //统计条数
    public function get_count($name,$start_time,$end_time,$site_id,$uid){
        $object = $this->db->select("users.*,users.realname as name")
        // ->join('user_identities','user_identities.user_id=users.id','left')
        ->join('b_site','users.site_id=b_site.id','left')
        ->from('users');
        // $object =$this->db->where('user_identities.status =',2); //实名过的
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        // $object =$this->db->where('user_identities.deleted_at is null');
        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }
        return $this->db->count_all_results();
    }

    //获取用户的委托记录
    public function get_entrustedrecords_list($offset,$limit,$symbol,$user_id)
    {
        $url = $this->config->item('VIABTC_API_URL');
            //指定交易对的委托记录
            $post_data = array(
                'id' => 0,
                'method' => 'order.pending', //未成交的记录
                // 'method' => 'order.finished', //已成交的记录  
                'params' => array(
                    (int)$user_id,$symbol,$offset,$limit
                )         
            );

            $post_data = json_encode($post_data);
            // var_dump($post_data);die;
            //调用curl
            $ch = curl_init();
            // 设置请求为post类型
            curl_setopt($ch, CURLOPT_POST, 1);
            // 添加post数据到请求中
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
            // 2. 设置请求选项, 包括具体的url
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            // 3. 执行一个cURL会话并且获取相关回复
            $response = curl_exec($ch);
            // 4. 释放cURL句柄,关闭一个cURL会话
            curl_close($ch);
            $response = object_to_array(json_decode($response));
            // var_dump($response);die;
            $variable = $response['result']['records'];
            foreach ($variable as &$value) {
                $value['ctime'] = get_microtime_format($value['ctime']);
                $value['mtime'] = get_microtime_format($value['mtime']);
                if($value['side'] == 1) $value['side'] = 'ASK卖出'; 
                if($value['side'] == 2) $value['side'] = 'BID买入'; 
                if($value['type'] == 1) $value['type'] = '限价'; 
                if($value['type'] == 2) $value['type'] = '市价'; 
            }
            // var_dump($variable);die;
            return $variable;
    }


    /**
     * [用户资产》资金流水》分为两个部分的组合，1、balance.history接口返回 2、user_asset_oprating表返回]
     * @param  [type] $offset     [description]
     * @param  [type] $limit      [description]
     * @param  [type] $asset      [description]
     * @param  [type] $start_time [description]
     * @param  [type] $end_time   [description]
     * @param  [type] $user_id    [description]
     * @param  [type] $type       [description]
     * @return [type]             [description]
     */
    public function user_assetsflow($offset,$limit,$asset,$start_time,$end_time,$user_id,$type)
    {
        $url = $this->config->item('VIABTC_API_URL');
        $post_data = array(
            'id' => 0,
            'method' => 'balance.history',
            'params' => array(
                (int)$user_id,$asset,$type,$start_time,$end_time,$offset,$limit
            )
        );
        $post_data = json_encode($post_data);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $response = curl_exec($ch);
        curl_close($ch);
        $response = object_to_array(json_decode($response));

        $take_arr = $response['result']['records'];

        if(count($take_arr)>0){
            foreach ($take_arr as &$value) {
                if($value['business']=='identity_auth')
                    $value['business'] = '实名认证奖励';
                if($value['business']=='identity_top_award')
                    $value['business'] = '实名认证一级奖励';
                if($value['business']=='identity_top_two_award')
                    $value['business'] = '实名认证二级奖励';
                if($value['business']=='register_award')
                    $value['business'] = '注册奖励';
                if($value['business']=='recommend_top_award')
                    $value['business'] = '注册一级奖励';
                if($value['business']=='recommend_top_two_award')
                    $value['business'] = '注册二级奖励';
                if($value['business']=='c2c_sell_freeze')
                    $value['business'] = 'c2c卖出冻结';
                if($value['business']=='cancel_c2c_sell_freeze')
                    $value['business'] = '取消c2c卖出解冻';
                if($value['business']=='deposit')
                    $value['business'] = '充值';
                if($value['business']=='withdraw')
                    $value['business'] = '提现冻结';
                if($value['business']=='withdraw_cancel')
                    $value['business'] = '取消提现解冻';
                if($value['business']=='admin_updatemoney')
                    $value['business'] = '后台更新资金';
                if($value['business']=='c2c_deposit')
                    $value['business'] = '法币购入';
                if($value['business']=='deposit_migrate')
                    $value['business'] = '资金流入';
                if($value['business']=='trade')
                    $value['business'] = '交易';
                if($value['business']=='recharge_award')
                    $value['business'] = '充值奖励';
                if($value['business']=='c2c_recharge_award')
                    $value['business'] = 'c2c充值奖励';
                if($value['business']=='activity_award')
                    $value['business'] = '活动奖励';
                if($value['business']=='activity_treasure')
                    $value['business'] = '夺宝活动';
                if($value['business']=='lock_position')
                    $value['business'] = '锁仓';
                if($value['business']=='unlock_position')
                    $value['business'] = '解锁锁仓';
                if($value['business']=='hold_award')
                    $value['business'] = '持仓奖励';
                if($value['business']=='admin_tranfsermoney')
                    $value['business'] = '转账';
                if($value['business']=='admin_loanmoney')
                    $value['business'] = '系统借款';
                if($value['business']=='admin_giftmoney')
                    $value['business'] = '系统赠币';
                if($value['business']=='otc_sell_freeze')
                    $value['business'] = 'OTC冻结';
                if($value['business']=='cancel_otc_sell_freeze')
                    $value['business'] = '取消OTC冻结';
                if($value['business']=='otc_deposit')
                    $value['business'] = 'OTC购入';
                if($value['business']=='admin_gift_activity_money')
                    $value['business'] = '活动赠币';
                if($value['business']=='admin_activity_unlock')
                    $value['business'] = '活动管理活动解锁';
                if($value['business']=='activity_trad_unlock')
                    $value['business'] = '交易解锁的活动解锁';
                if($value['business']=='airdrop')
                    $value['business'] = '空投';
                if($value['business']=='airdrop_release')
                    $value['business'] = '空投释放';
                if($value['business']=='identity_award_out')
                    $value['business'] = '实名奖励释放';
                if($value['business']=='identity_top_award_out')
                    $value['business'] = '实名认证一级奖励释放';
                if($value['business']=='identity_top_two_award_out')
                    $value['business'] = '实名认证二级奖励释放';
                if($value['business']=='register_award_out')
                    $value['business'] = '注册奖励释放';
                if($value['business']=='recommend_top_award_out')
                    $value['business'] = '注册一级奖励释放';
                if($value['business']=='recommend_top_two_award_out')
                    $value['business'] = '注册二级奖励释放';
                if($value['business']=='activity_trad_unlock')
                    $value['business'] = '交易统一解锁';
                if($value['business']=='admin_settlement_fee')
                    $value['business'] = '后台手续费结算';
                if($value['business']=='withdraw_fail')
                    $value['business'] = '提现置为失败';
                if($value['business']=='explorer_activity')
                    $value['business'] = 'Explorer';
                if($value['business']=='explorer_plus_activity')
                    $value['business'] = 'ExplorerPlus';
                if($value['business']=='otc_transfer_out')
                    $value['business'] = 'OTC转出';
                if($value['business']=='otc_transfer_in')
                    $value['business'] = 'OTC转入';
                if($value['business']=='activity_invite_commission')
                    $value['business'] = '邀请返佣';
                if($value['business']=='activityconvert')
                    $value['business'] = '资产兑换';
                if($value['business']=='moneytolive_timelock')
                    $value['business'] = '持币生息冻结';
                if($value['business']=='moneytolive_timeunlock')
                    $value['business'] = '持币生息解冻';
                if($value['business']=='payout_in')
                    $value['business'] = '派息收入';
                if($value['business']=='payout_out')
                    $value['business'] = '派息支出';
                if($value['business']=='ranking_reward_deduction')
                    $value['business'] = '交易大赛扣除';
                if($value['business']=='ranking_reward')
                    $value['business'] = '交易大赛奖励';
                if($value['business']=='activity_ccp_freeze')
                    $value['business'] = '云算力余额冻结';
                if($value['business']=='activity_ccp_unfreeze')
                    $value['business'] = '云算力余额解冻';
                if($value['business']=='activity_ccp_buy')
                    $value['business'] = '云算力购买';
                if($value['business']=='activity_ccp_sell')
                    $value['business'] = '云算力卖出';
                if($value['business']=='activity_ccp_cancel')
                    $value['business'] = '云算力取消';
                if($value['business']=='activity_lock_position')
                    $value['business'] = '活动冻结';
                if($value['business']=='thousand_activity')
                    $value['business'] = '千倍活动-扣除';
                if($value['business']=='thousand_bonus_activity')
                    $value['business'] = '千倍活动-奖励';
                if($value['business']=='admin_freeze')
                    $value['business'] = '后台操作冻结';
                if($value['business']=='admin_unfreeze')
                    $value['business'] = '后台操作解除冻结';
                if($value['business']=='miming_dividend_log')
                    $value['business'] = '云算力派息';
                if($value['business']=='assetconvert_timeunlock')
                    $value['business'] = '资产兑换-到期解锁';


                if(empty($value['time'])){
                    $value['time'] = $value['created_at'];
                }else if(empty($value['created_at'])){
                    $value['time'] = get_microtime_format($value['time']);
                }
            }
            return  $take_arr;
        }else{
            return array();
        }
    }


    public function print_userassetflow($asset,$start_time,$end_time,$user_id,$type)
    {
        $posix = (int)$user_id%100;
        $DB2 = $this->load->database('trade_history',true);
        $sql = "select * from balance_history_".$posix." where user_id='".$user_id."' and time>'".$start_time."' and time<='".$end_time."' order by time desc";
        $object = object_to_array($DB2->query($sql)->result());
        if(is_array($object) && !empty($object)){
            foreach ($object as &$value) {
                if($value['business']=='identity_auth')
                    $value['business'] = '实名认证奖励';
                if($value['business']=='identity_top_award')
                    $value['business'] = '实名认证一级奖励';
                if($value['business']=='identity_top_two_award')
                    $value['business'] = '实名认证二级奖励';
                if($value['business']=='register_award')
                    $value['business'] = '注册奖励';
                if($value['business']=='recommend_top_award')
                    $value['business'] = '注册一级奖励';
                if($value['business']=='recommend_top_two_award')
                    $value['business'] = '注册二级奖励';
                if($value['business']=='c2c_sell_freeze')
                    $value['business'] = 'c2c卖出冻结';
                if($value['business']=='cancel_c2c_sell_freeze')
                    $value['business'] = '取消c2c卖出解冻';
                if($value['business']=='deposit')
                    $value['business'] = '充值';
                if($value['business']=='withdraw')
                    $value['business'] = '提现冻结';
                if($value['business']=='withdraw_cancel')
                    $value['business'] = '取消提现解冻';
                if($value['business']=='admin_updatemoney')
                    $value['business'] = '后台更新资金';
                if($value['business']=='c2c_deposit')
                    $value['business'] = '法币购入';
                if($value['business']=='deposit_migrate')
                    $value['business'] = '资金流入';
                if($value['business']=='trade')
                    $value['business'] = '交易';
                if($value['business']=='recharge_award')
                    $value['business'] = '充值奖励';
                if($value['business']=='c2c_recharge_award')
                    $value['business'] = 'c2c充值奖励';
                if($value['business']=='activity_award')
                    $value['business'] = '活动奖励';
                if($value['business']=='activity_treasure')
                    $value['business'] = '夺宝活动';
                if($value['business']=='lock_position')
                    $value['business'] = '锁仓';
                if($value['business']=='unlock_position')
                    $value['business'] = '解锁锁仓';
                if($value['business']=='hold_award')
                    $value['business'] = '持仓奖励';
                if($value['business']=='admin_tranfsermoney')
                    $value['business'] = '转账';
                if($value['business']=='admin_loanmoney')
                    $value['business'] = '系统借款';
                if($value['business']=='admin_giftmoney')
                    $value['business'] = '系统赠币';
                if($value['business']=='otc_sell_freeze')
                    $value['business'] = 'OTC冻结';
                if($value['business']=='cancel_otc_sell_freeze')
                    $value['business'] = '取消OTC冻结';
                if($value['business']=='otc_deposit')
                    $value['business'] = 'OTC购入';
                if($value['business']=='admin_gift_activity_money')
                    $value['business'] = '活动赠币';
                if($value['business']=='admin_activity_unlock')
                    $value['business'] = '活动管理活动解锁';
                if($value['business']=='activity_trad_unlock')
                    $value['business'] = '交易解锁的活动解锁';
                if($value['business']=='airdrop')
                    $value['business'] = '空投';
                if($value['business']=='airdrop_release')
                    $value['business'] = '空投释放';
                if($value['business']=='identity_award_out')
                    $value['business'] = '实名奖励释放';
                if($value['business']=='identity_top_award_out')
                    $value['business'] = '实名认证一级奖励释放';
                if($value['business']=='identity_top_two_award_out')
                    $value['business'] = '实名认证二级奖励释放';
                if($value['business']=='register_award_out')
                    $value['business'] = '注册奖励释放';
                if($value['business']=='recommend_top_award_out')
                    $value['business'] = '注册一级奖励释放';
                if($value['business']=='recommend_top_two_award_out')
                    $value['business'] = '注册二级奖励释放';
                if($value['business']=='activity_trad_unlock')
                    $value['business'] = '交易统一解锁';
                if($value['business']=='admin_settlement_fee')
                    $value['business'] = '后台手续费结算';
                if($value['business']=='withdraw_fail')
                    $value['business'] = '提现置为失败';
                if($value['business']=='explorer_activity')
                    $value['business'] = 'Explorer';
                if($value['business']=='explorer_plus_activity')
                    $value['business'] = 'ExplorerPlus';
                if($value['business']=='otc_transfer_out')
                    $value['business'] = 'OTC转出';
                if($value['business']=='otc_transfer_in')
                    $value['business'] = 'OTC转入';
                if($value['business']=='activity_invite_commission')
                    $value['business'] = '邀请返佣';
                if($value['business']=='activityconvert')
                    $value['business'] = '资产兑换';
                if($value['business']=='moneytolive_timelock')
                    $value['business'] = '持币生息冻结';
                if($value['business']=='moneytolive_timeunlock')
                    $value['business'] = '持币生息解冻';
                if($value['business']=='payout_in')
                    $value['business'] = '派息收入';
                if($value['business']=='payout_out')
                    $value['business'] = '派息支出';
                if($value['business']=='ranking_reward_deduction')
                    $value['business'] = '交易大赛扣除';
                if($value['business']=='ranking_reward')
                    $value['business'] = '交易大赛奖励';
                if($value['business']=='activity_ccp_freeze')
                    $value['business'] = '云算力余额冻结';
                if($value['business']=='activity_ccp_unfreeze')
                    $value['business'] = '云算力余额解冻';
                if($value['business']=='activity_ccp_buy')
                    $value['business'] = '云算力购买';
                if($value['business']=='activity_ccp_sell')
                    $value['business'] = '云算力卖出';
                if($value['business']=='activity_ccp_cancel')
                    $value['business'] = '云算力取消';
                if($value['business']=='activity_lock_position')
                    $value['business'] = '活动冻结';
                if($value['business']=='thousand_activity')
                    $value['business'] = '千倍活动-扣除';
                if($value['business']=='thousand_bonus_activity')
                    $value['business'] = '千倍活动-奖励';
                if($value['business']=='admin_freeze')
                    $value['business'] = '后台操作冻结';
                if($value['business']=='admin_unfreeze')
                    $value['business'] = '后台操作解除冻结';
                if($value['business']=='miming_dividend_log')
                    $value['business'] = '云算力派息';
                if($value['business']=='assetconvert_timeunlock')
                    $value['business'] = '资产兑换-到期解锁';


                $value['time'] = get_microtime_format($value['time']);
            }
        }
        return $object;
    }

    //获取用户的成交记录
    public function get_dealrecords_list($offset,$limit,$symbol,$start_time,$end_time,$user_id,$side=0)
    {
        // $url = 'http://localhost:8080';
        $url = $this->config->item('VIABTC_API_URL');
            //指定币种的成交记录
            $post_data = array(
                'id' => 0,
                'method' => 'order.finished', //已成交的记录   
                'params' => array(
                    (int)$user_id,$symbol,(int)$start_time,(int)$end_time,$offset,$limit,(int)$side
                )
            );
            // var_dump($post_data);die;
            $post_data = json_encode($post_data);
            // var_dump($post_data);die;
            //调用curl
            $ch = curl_init();
            // 设置请求为post类型
            curl_setopt($ch, CURLOPT_POST, 1);
            // 添加post数据到请求中
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
            // 2. 设置请求选项, 包括具体的url
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            // 3. 执行一个cURL会话并且获取相关回复
            $response = curl_exec($ch);
            // 4. 释放cURL句柄,关闭一个cURL会话
            curl_close($ch);
            $response = object_to_array(json_decode($response));
            // var_dump($response);die;
            $arr = $response['result']['records'];
            foreach ($arr as &$value) {
                $value['ctime'] = get_microtime_format($value['ctime']);
                $value['ftime'] = get_microtime_format($value['ftime']);
            }
            // var_dump($arr);die;
            // return $response['result']['records'];
            return $arr;
        
    }


    /**
     * Notes: 调整用户资金
     * User: 张哲
     * Date: 2019-08-17
     * Time: 16:51
     */
    public function updateusermoney($args)
    {
        $user_id = $args['uid'];
        $detail = $this->Zjys_user_model->get_info($user_id);
        if(empty($detail)) return $args;
        
        $site_id = $detail['site_id'];
        $asset = $args['asset'];
        $amount = trim($args['amount']);
        $extra = isset($args['extra']) ? $args['extra'] : '';
        $operation_admin_id = $this->user_id;
        $time = date('Y-m-d H:i:s',time());

        $this->db->trans_begin();

        $bussness_id = $this->Zjys_user_operationmoney_model->add($operation_admin_id,$time,$asset,$amount,$user_id,$extra,$site_id,$type=1);
        $bussness = 'admin_updatemoney';
        $extra = array('info'=>$extra);
        $res = update_user_balance_bycurl($user_id,$asset,$amount,$bussness_id,$extra,$bussness);

        $trans_status = $this->db->trans_status();


        if($res['result']['status'] != 'success')
        {
            $trans_status = false;
        }
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return $args;
        } else {
            $this->db->trans_commit();
            return true;
        }        
    }


    //定时任务获取用户总资产（按时间）
    public function get_site_totalassets($args)
    {
        $start_time = isset($args['start_time']) ? $args['start_time']: 0;
        $end_time = isset($args['end_time']) ? $args['end_time']: time();
        $DB1 = $this->load->database('trade_history',true);
        $siteList = $this->Site_model->site_all();
        // var_dump($siteList);die;
        foreach ($siteList as $site) {
            // $userList  = $this->Zjys_user_model->get_userid_by_site($site['id']);
            $assetList = $this->Zjys_assets_model->get_assets_by_site_id($site['id']);
            // var_dump($userList);die;
            $res = [];
            // $t1 = microtime(true);
            for ($i=0; $i < 100; $i++) { 
                $sql = "select SUM(balance) as balance,asset from balance_history_".$i." WHERE id in(SELECT  
                                SUBSTRING_INDEX(  
                                    GROUP_CONCAT(id ORDER BY id desc),  
                                    ',',  
                                    1  
                                )
                            FROM  
                                balance_history_".$i." where `time` > ".$start_time." AND `time` < ".$end_time."
                            GROUP BY  
                                user_id,asset) GROUP BY asset";
                // var_dump($sql);die;
                $object = object_to_array($DB1->query($sql)->result());
                // var_dump($object);
                $newArray = array_reduce($object,function(&$newArray,$v){
                    $newArray[$v['asset']] = $v['balance'];
                    return $newArray;
                });
                // var_dump($newArray);die;
                array_push($res,$newArray);
            }
            // var_dump($res);die;
            foreach ($assetList as $key => $value) {
                $new[$site['name']][$value['asset_code']] = $this->getcc($value['asset_code'],$res);
            }
            return $new;
            // $t2 = microtime(true);
            // $a = $t2-$t1;
            // var_dump($a);
            // var_dump($new);die;
        }
    }


    public function getcc($i,$res)
    {
        $total = 0;
        foreach ($res as $key => $value) {
            if($value !== NULL){
                foreach ($value as $k => $v) {
                    if($i == $k){
                        $total += $v;
                    }
                }
            }
        }
        return $total;
    }

    /**
     * /平台成交记录（没有时间参数默认是平台近24小时的成交记录、数据表以用户纬度来分）
     * 取的是用户成交记录表user_deal_history_index
     * @param  [type] $symbol     [description]
     * @param  [type] $uid        [description]
     * @param  [type] $start_time [description]
     * @param  [type] $end_time   [description]
     * @param  [type] $offset     [description]
     * @param  [type] $limit      [description]
     * @return [type]             [description]
     */
    public function platform_deal_detail($symbol,$uid,$start_time,$end_time,$offset,$limit)
    {
        if(isset($symbol) && !empty($symbol))   $where = " AND `market`='$symbol'";
        if(isset($uid) && !empty($uid)){
            $where1 = ' AND `user_id`='.$uid;
        }else{
            $where1 = ' AND 1=1';
        } 

        $DB1 = $this->load->database('trade_history',true);

        $res = [];
        for ($i=0; $i <100 ; $i++) { 
            $sql = "select * from order_history_".$i." where `finish_time` > ".$start_time." AND `finish_time` < ".$end_time.$where.$where1;
            $object = object_to_array($DB1->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $date = array_column($new, 'finish_time');
        $result = array_multisort($date,SORT_DESC,$new);
        // var_dump($new);die;

        foreach ($new as &$value) {
            $value['time'] = get_microtime_format($value['finish_time']);
        }
        return $new;
    }

    public function platform_deal_detail_day($symbol,$uid,$day,$offset,$limit){
        $time = strtotime($day)+86400;
        $where = " where 1=1";
        if($symbol)
            $where .= " and market='".$symbol."'";
        if($uid)
            $where .= " and user_id=$uid";
        
        $trade_history_snap_db = $this->load->database('trade_history_snap',true);
        $sql = "show tables like 'order_history_$time'";
        // var_dump($trade_history_snap_db->query($sql)->result_array());die;
        if(! $trade_history_snap_db->query($sql)->result_array()) returnJson('402','table order_history_'.$time.' not exit');
        
        $sql = "SELECT * from order_history_$time $where order by finish_time desc limit $offset,$limit";
        
        $list = $trade_history_snap_db->query($sql)->result_array();

        if(count($list)>0){
            foreach ($list as &$value) {
                $value['time'] = get_microtime_format($value['finish_time']);
            }
            return $list;
        }else{
            return $list;
        }
    }

    public function platform_deal_detail_day_count($symbol,$uid,$day,$offset,$limit){
        $time = strtotime($day)+86400;
        $where = " where 1=1";
        if($symbol)
            $where .= " and market='".$symbol."'";
        if($uid)
            $where .= " and user_id=$uid";
        
        $trade_history_snap_db = $this->load->database('trade_history_snap',true);
        $sql = "SELECT count(*) as numrows from order_history_$time $where";
        $count = $trade_history_snap_db->query($sql)->row_array();
        return $count['numrows'];
    }

    //平台委托记录
    public function platform_order_detail($symbol,$uid,$start_time,$end_time,$offset,$limit,$side)
    {
        $url       = $this->config->item('VIABTC_API_URL');
        $post_data = array(
            'id'       => 1,
            'method'   => 'order.book', //委托记录
            'params'   => array(
            $symbol,(int)$side,(int)$offset,(int)$limit),
        );
        
        $post_data = json_encode($post_data);
        // var_dump($post_data);die;
        $ch        = curl_init();
        // 设置请求为post类型
        curl_setopt($ch, CURLOPT_POST, 1);
        // 添加post数据到请求中
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        // 2. 设置请求选项, 包括具体的url
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        // 3. 执行一个cURL会话并且获取相关回复
        $response  = curl_exec($ch);
        // 4. 释放cURL句柄,关闭一个cURL会话
        curl_close($ch);
        $response  = object_to_array(json_decode($response));
        // var_dump($response);die;
        if(!empty($response['result']['orders'])){
            foreach ($response['result']['orders'] as &$value) {
                $value['create_time'] = get_microtime_format($value['ctime']);
                $value['mtime'] = get_microtime_format($value['mtime']);
                $value['user_id'] = $value['user'];
            }
            return $response['result']['orders'];
        }else{
            return array();
        }
    }
    
    //
    function get_source(){
        
        $site_id = substr($source,strpos($source,',')+1);
        $sql = "select name from b_site where id = ".$site_id;
        $site_name = $this->db->query($sql)->row_array();
        return $site_name['name'];
    }
    

    //根据类型统计不同币种的金额
    public function get_c2c_freeze($type)
    {
        if($this->config->item('SITE') === 'priv_one'){
            if($type==1){
                $where1 = " where business='c2c_sell_freeze' or business='cancel_c2c_sell_freeze' or business='admin_c2c_unfreeze' ";
                $where2 = " where BB.business='c2c_sell_freeze' or BB.business='cancel_c2c_sell_freeze' or BB.business='admin_c2c_unfreeze' ";
            }
            if($type==2){
                $where1 = " where business='withdraw' or business='withdraw_cancel' or business='admin_withdraw_unfreeze'";
                $where2 = " where BB.business='withdraw' or BB.business='withdraw_cancel' or BB.business='admin_withdraw_unfreeze'";
            }
            // $DB1 = $this->load->database('trade_history',true);
            $siteList = $this->Site_model->site_one(1);
            foreach ($siteList as $site) {
                $assetList = $this->Zjys_assets_model->get_assets_by_site_id($site['id']);
                $res = [];
                for ($i=0; $i < 1; $i++) { 
                    $sql = "select  sum(balance) as balance,asset from user_asset_freezes as BB INNER JOIN (SELECT  
                                    SUBSTRING_INDEX(  
                                        GROUP_CONCAT(id ORDER BY id desc),  
                                        ',',  
                                        1  
                                    ) as cc
                                FROM  
                                    user_asset_freezes ".$where1."

                                GROUP BY  
                                    user_id,asset) as AA ON AA.cc=BB.id ".$where2." GROUP BY asset";
                    // var_dump($sql);
                    // $object = ;
                    $object = object_to_array($this->db->query($sql)->result());
                    // var_dump($object);
                    $newArray = array_reduce($object,function(&$newArray,$v){
                        $newArray[$v['asset']] = $v['balance'];
                        return $newArray;
                    });
                    array_push($res,$newArray);
                }

                foreach ($assetList as $key => $value) {
                    $new[$site['name']][$value['asset_code']] = $this->getcc($value['asset_code'],$res);
                }
                return $new;
            }
        }else{
            if($type==1){
                $where1 = " where business='c2c_sell_freeze' or business='cancel_c2c_sell_freeze' or business='admin_c2c_unfreeze' ";
                $where2 = " where BB.business='c2c_sell_freeze' or BB.business='cancel_c2c_sell_freeze' or BB.business='admin_c2c_unfreeze' ";
            }
            if($type==2){
                $where1 = " where business='withdraw' or business='withdraw_cancel' or business='admin_withdraw_unfreeze'";
                $where2 = " where BB.business='withdraw' or BB.business='withdraw_cancel' or BB.business='admin_withdraw_unfreeze'";
            }
            $assetList = $this->Zjys_assets_model->get_systemassets();
            $res = [];
            for ($i=0; $i < 1; $i++) { 
                $sql = "select  sum(balance) as balance,asset from user_asset_freezes as BB INNER JOIN (SELECT  
                                SUBSTRING_INDEX(  
                                    GROUP_CONCAT(id ORDER BY id desc),  
                                    ',',  
                                    1  
                                ) as cc
                            FROM  
                                user_asset_freezes ".$where1."

                            GROUP BY  
                                user_id,asset) as AA ON AA.cc=BB.id ".$where2." GROUP BY asset";
                // var_dump($sql);
                // $object = ;
                $object = object_to_array($this->db->query($sql)->result());
                // var_dump($object);
                $newArray = array_reduce($object,function(&$newArray,$v){
                    $newArray[$v['asset']] = $v['balance'];
                    return $newArray;
                });
                array_push($res,$newArray);
            }

            foreach ($assetList as $key => $value) {
                $new['总平台'][$value['asset_code']] = $this->getcc($value['asset_code'],$res);
            }
            return $new;
        }
    }

    //财务统计-币资产统计
    public function get_trade_freeze($site_id)
    {
        if($this->config->item('SITE') === 'priv_one'){

            $siteList = $this->Site_model->site_one($site_id);
            $res = [];
            foreach ($siteList as $key => $site) {
                $assetList = $this->Zjys_assets_model->get_assets_by_site_id($site['id']);
                foreach ($assetList as $kk => $vv) {
                    $newsiteList[] = $vv['asset_code'];
                }
                $url       = $this->config->item('VIABTC_API_URL');
                $post_data = array(
                    'id'       => 1,
                    'method'   => 'asset.summary', //列表中的每个币种在交易系统中的信息，包括 交易系统总量、交易系统冻结、交易系统可用
                    'params'   => $newsiteList,
                );

                $post_data = json_encode($post_data);
                $ch        = curl_init();
                // 设置请求为post类型
                curl_setopt($ch, CURLOPT_POST, 1);
                // 添加post数据到请求中
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
                // 2. 设置请求选项, 包括具体的url
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                // 3. 执行一个cURL会话并且获取相关回复
                $response  = curl_exec($ch);
                // 4. 释放cURL句柄,关闭一个cURL会话
                curl_close($ch);
                $response  = object_to_array(json_decode($response));
                array_push($res, $response['result']);
                $newarray = array();
                foreach ($res as $k => $v){
                    foreach ($v as $kkk=>$vvv) {
                        $newarray[$site['name']][$vvv['name']] = $vvv;
                    }
                }
            }
        }else{
                $res = [];
                $assetList = $this->Zjys_assets_model->get_systemassets();
                foreach ($assetList as $kk => $vv) {
                    $newsiteList[] = trim($vv['asset_code']);
                }
                $url       = $this->config->item('VIABTC_API_URL');
                $post_data = array(
                    'id'       => 1,
                    'method'   => 'asset.summary', //汇总
                    'params'   => [],
                );

                $post_data = json_encode($post_data);
                $ch        = curl_init();
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                $response  = curl_exec($ch);
                curl_close($ch);
                $response  = object_to_array(json_decode($response));
                array_push($res, $response['result']);
                $newarray = array();
                foreach ($res as $k => $v){
                    foreach ($v as $kkk=>$vvv) {
                        $newarray['总平台'][$vvv['name']] = $vvv;
                    }
                }
            }
        return $newarray;
    }

    public function get_wallet_logs($limit,$page,$offset,$start_time,$end_time)
    {
        $object = $this->db->select("wallet_request_logs.*")
        // ->join('b_admin','b_admin.user_id=operation_money_logs.admin_id','left')
        // ->join('user_identities','operation_money_logs.user_id=user_identities.user_id','left')
        // ->join('b_site','operation_money_logs.site_id=b_site.id','left')
        ->from('wallet_request_logs');

        $object =$this->db->where('wallet_request_logs.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('wallet_request_logs.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('wallet_request_logs.created_at <=',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        return $list;
    }



    public function get_wallet_logs_count($limit,$page,$offset,$start_time,$end_time)
    {
        $object = $this->db->select("wallet_request_logs.id")
        // ->join('b_admin','b_admin.user_id=operation_money_logs.admin_id','left')
        // ->join('user_identities','operation_money_logs.user_id=user_identities.user_id','left')
        // ->join('b_site','operation_money_logs.site_id=b_site.id','left')
        ->from('wallet_request_logs');

        $object =$this->db->where('wallet_request_logs.deleted_at is null');

        if(!empty($start_time)){
            $object =$this->db->where('wallet_request_logs.created_at >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('wallet_request_logs.created_at <=',$end_time);
        }
        
        return $this->db->count_all_results();
    }

    //请求时间段内的所有交易额（不包括正在委托的状态中国的订单）
    public function get_trade_statistic($start_time,$end_time,$time_area)
    {
        $DB1 = $this->load->database('trade_history',true);
        $res = [];
        // $symbol = 'ZG_CNZ';
        //获取站点交易对，
        $symbolList = $this->Zjys_symbols_model->get_symbols_by_site_id(1); //只有总站有的交易对
        foreach ($symbolList as $key => $value) {
            for ($i=0; $i < 100; $i++) { 
                $sql = "select  sum(deal_money) as totalmoney,user_id,market from order_history_".$i." where market='".$value['symbol']."' and finish_time >".$start_time." and finish_time <".$end_time." group by user_id";
                $object = object_to_array($DB1->query($sql)->result());
                if($i==0){
                    $new = array_merge(array(),$object);
                }else{
                    @$new = &array_merge($new,$object);
                }
            }
            // var_dump($new);
            $sum = 0;
            foreach($new as $ii => $item){
              $sum += $item['totalmoney'];
            } 
            // var_dump($sum);die;
            $res[$key]['time_area'] =  $time_area;
            $res[$key]['symbol'] =  $value['symbol'];
            $res[$key]['total'] =  $sum;//总交易量
            $res[$key]['number'] =  count($new);//总交易笔数
            $res[$key]['BID_fee'] =  $this->get_bid_fee($value['symbol'],2,$start_time,$end_time,1);//BID买入手续费（收ZG）
            $res[$key]['ASK_fee'] =  $this->get_bid_fee($value['symbol'],1,$start_time,$end_time,1);//ASK卖出（收CNZ）
        }
        $time = date('Y-m-d H:i:s',time());
        foreach ($res as $key => $val) {
            $this->Zjys_tradelogstask_model->add($val['time_area'],$val['symbol'],$start_time,$end_time,$val['total'],$val['number'],$val['BID_fee'],$val['ASK_fee'],$time);
        }
    }
    //获取BID 购买手续费
    public function get_bid_fee($symbol,$side,$start_time,$end_time,$site_id)
    {
        $DB1 = $this->load->database('trade_history',true);
        for ($i=0; $i < 100; $i++) { 
            $sql = "select  sum(deal_fee) as totalfee,user_id,market from order_history_".$i." where market='".$symbol."' and `side`=".$side." and source='web,".$site_id."' and finish_time >=".$start_time." and finish_time <=".$end_time."";
            $object = object_to_array($DB1->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }

        $sum = 0;
        foreach($new as $ii => $item){
            $sum += $item['totalfee'];
        }
        return $sum; 
    }


    //交易统计
    public function get_trade_statistic_total($limit,$offset,$start_time,$end_time,$site_id)
    {
        $object = $this->db->select("perday_coin_trade_statistics.*,b_site.name as site_name")
        ->join('b_site','perday_coin_trade_statistics.site_id=b_site.id','left')
        ->from('perday_coin_trade_statistics');
        if($site_id!='') {
            $object =$this->db->where('perday_coin_trade_statistics.site_id = ',$site_id);
        }
        if($start_time !=''){
            $object =$this->db->where('perday_coin_trade_statistics.time_area >=',$start_time);
        }
        if($end_time !=''){
            $object =$this->db->where('perday_coin_trade_statistics.time_area <',$end_time);
        }
        $list = $object->limit($limit,$offset)->order_by('time_area','desc')->get()->result_array();
        return $list;
    }

    public function get_trade_statistic_total_count($limit,$offset,$start_time,$end_time,$site_id)
    {
        $object = $this->db->select("perday_coin_trade_statistics.*,b_site.name as site_name")
        ->join('b_site','perday_coin_trade_statistics.site_id=b_site.id','left')
        ->from('perday_coin_trade_statistics');

        if($site_id!='') {
            $object =$this->db->where('perday_coin_trade_statistics.site_id = ',$site_id);
        }

        if($start_time !=''){
            $object =$this->db->where('perday_coin_trade_statistics.time_area >=',$start_time);
        }
        if($end_time !=''){
            $object =$this->db->where('perday_coin_trade_statistics.time_area <',$end_time);
        }
        
        return $this->db->count_all_results();
    }

    public function sssssinsert($url){
        return $this->Zjys_tradelogstask_model->sssssinsert($url);
    }

    public function transaction_number($offset,$limit,$start_time,$end_time,$market,$where,$order,$user_id)
    {
        // var_dump(strtotime('2019-10-11 10:12:56'));die;
        // var_dump(date('Y-m-d ',strtotime($start_time)));die;
        //取的是每日成交记录
        $trade_history_snap_db = $this->load->database('trade_history_snap',true);
        $timestamp = strtotime(date('Y-m-d',strtotime($start_time)))+86400; //获取快照表时间戳后缀
        // var_dump($timestamp);die;
        $sql = "show tables like 'order_history_$timestamp'";
        // var_dump(!$trade_history_snap_db->query($sql)->result_array());die;
        if(! $trade_history_snap_db->query($sql)->result_array())
             returnJson('402','table not exit');

        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        if($end_time-$start_time>86400) returnJson('402','时间范围能超过24小时');
        if($user_id==''){
            $sql = "select user_id from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' group by user_id";
            // var_dump($sql);die;
            $useridList = $trade_history_snap_db->query($sql)->result_array();
            $useridList = array_column($useridList,'user_id');
            if(!$useridList) returnJson('402','该条件下无交易数据');
            // var_dump(array_column($useridList,'user_id'));
            $sql = "select sum(deal_money) as deal_money_buy,user_id from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=2 group by user_id";
            $buyList = $trade_history_snap_db->query($sql)->result_array(); 
            $sql = "select sum(deal_money) as deal_money_sell,user_id from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=1 group by user_id";
            $sellList = $trade_history_snap_db->query($sql)->result_array(); 
            //最低卖出成交价
            $sql = "select user_id,min(price) as sell_min_price from (select * from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=1 order by price asc) A group by user_id";
            $sellminPrice = $trade_history_snap_db->query($sql)->result_array();
            //最高卖出成交价
            $sql = "select user_id,max(price) as sell_max_price from (select * from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=1 order by price desc) A group by user_id";
            $sellmaxPrice = $trade_history_snap_db->query($sql)->result_array();

            //最低买入成交价
            $sql = "select user_id,min(price) as buy_min_price from (select * from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=2 order by price asc) A group by user_id";
            $buyminPrice = $trade_history_snap_db->query($sql)->result_array();
            //最高买入成交价
            $sql = "select user_id,max(price) as buy_max_price from (select * from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=2 order by price desc) A group by user_id";
            $buymaxPrice = $trade_history_snap_db->query($sql)->result_array();
        }else{
            $sql = "select user_id from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and user_id=$user_id group by user_id";
            // var_dump($sql);die;
            $useridList = $trade_history_snap_db->query($sql)->result_array();
            $useridList = array_column($useridList,'user_id'); 
            if(!$useridList) returnJson('402','该条件下无交易数据');
            // var_dump(array_column($useridList,'user_id'));
            $sql = "select sum(deal_money) as deal_money_buy,user_id from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=2 and user_id=$user_id group by user_id";
            $buyList = $trade_history_snap_db->query($sql)->result_array(); 
            $sql = "select sum(deal_money) as deal_money_sell,user_id from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=1  and user_id=$user_id group by user_id";
            $sellList = $trade_history_snap_db->query($sql)->result_array(); 
            //最低卖出成交价
            $sql = "select user_id,min(price) as sell_min_price from (select * from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=1  and user_id=$user_id order by price asc) A group by user_id";
            $sellminPrice = $trade_history_snap_db->query($sql)->result_array();
            //最高卖出成交价
            $sql = "select user_id,max(price) as sell_max_price from (select * from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=1  and user_id=$user_id order by price desc) A group by user_id";
            $sellmaxPrice = $trade_history_snap_db->query($sql)->result_array();

            //最低买入成交价
            $sql = "select user_id,min(price) as buy_min_price from (select * from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=2  and user_id=$user_id order by price asc) A group by user_id";
            $buyminPrice = $trade_history_snap_db->query($sql)->result_array();
            //最高买入成交价
            $sql = "select user_id,max(price) as buy_max_price from (select * from order_history_$timestamp where finish_time>=$start_time and finish_time<$end_time and market = '$market' and side=2  and user_id=$user_id order by price desc) A group by user_id";
            $buymaxPrice = $trade_history_snap_db->query($sql)->result_array();
        }
        


        // var_dump($sellList);die;
        foreach ($buyList as $k => $v) {
            $arr1[$v['user_id']] = $v;
        }
        foreach ($sellList as $k => $v) {
            $arr2[$v['user_id']] = $v;
        }

        foreach ($sellminPrice as $k => $v) {
            $arr3[$v['user_id']] = $v;
        }
        foreach ($sellmaxPrice as $k => $v) {
            $arr4[$v['user_id']] = $v;
        }

        foreach ($buyminPrice as $k => $v) {
            $arr5[$v['user_id']] = $v;
        }
        foreach ($buymaxPrice as $k => $v) {
            $arr6[$v['user_id']] = $v;
        }
        //合并组装
        for($i=0;$i<count($useridList);$i++)
        {
            // var_dump($arr1[$useridList[$i]]);
            $arr[$i]['market'] = $market;
            $arr[$i]['user_id'] = $useridList[$i];
            $arr[$i]['deal_money_buy'] = isset($arr1[$useridList[$i]]) ? $arr1[$useridList[$i]]['deal_money_buy'] : 0; //买入成交额
            $arr[$i]['deal_money_sell'] = isset($arr2[$useridList[$i]]) ? $arr2[$useridList[$i]]['deal_money_sell'] : 0;//卖出成交额
            $arr[$i]['deal_money_total'] = bcadd($arr[$i]['deal_money_sell'],$arr[$i]['deal_money_buy'],12);
            $arr[$i]['sell_min_price'] = isset($arr3[$useridList[$i]]) ? $arr3[$useridList[$i]]['sell_min_price'] : 0;//卖出成交额
            $arr[$i]['sell_max_price'] = isset($arr4[$useridList[$i]]) ? $arr4[$useridList[$i]]['sell_max_price'] : 0;//卖出成交额
            $arr[$i]['buy_min_price'] = isset($arr5[$useridList[$i]]) ? $arr5[$useridList[$i]]['buy_min_price'] : 0;//卖出成交额
            $arr[$i]['buy_max_price'] = isset($arr6[$useridList[$i]]) ? $arr6[$useridList[$i]]['buy_max_price'] : 0;//卖出成交额
        }

        // var_dump($arr);die;//所有的结果
        //根据条件来排序
        
        if(isset($where) && $where=='deal_money_buy'){
            if($order==='desc'){
                $last_names = array_column($arr,'deal_money_buy');
                array_multisort($last_names,SORT_DESC,$arr);
            }else{
                $last_names = array_column($arr,'deal_money_buy');
                array_multisort($last_names,SORT_ASC,$arr);
            }

        }
        if(isset($where) && $where=='deal_money_sell'){
            if($order==='desc'){
                $last_names = array_column($arr,'deal_money_sell');
                array_multisort($last_names,SORT_DESC,$arr);
            }else{
                $last_names = array_column($arr,'deal_money_sell');
                array_multisort($last_names,SORT_ASC,$arr);
            }

        }
        if(isset($where) && $where=='buy_min_price'){
            if($order==='desc'){
                $last_names = array_column($arr,'buy_min_price');
                array_multisort($last_names,SORT_DESC,$arr);
            }else{
                $last_names = array_column($arr,'buy_min_price');
                array_multisort($last_names,SORT_ASC,$arr);
            }

        }
        if(isset($where) && $where=='buy_max_price'){
            if($order==='desc'){
                $last_names = array_column($arr,'buy_max_price');
                array_multisort($last_names,SORT_DESC,$arr);
            }else{
                $last_names = array_column($arr,'buy_max_price');
                array_multisort($last_names,SORT_ASC,$arr);
            }
        }
        if(isset($where) && $where=='sell_min_price'){
            if($order==='desc'){
                $last_names = array_column($arr,'sell_min_price');
                array_multisort($last_names,SORT_DESC,$arr);
            }else{
                $last_names = array_column($arr,'sell_min_price');
                array_multisort($last_names,SORT_ASC,$arr);
            }
        }
        if(isset($where) && $where=='sell_max_price'){
            if($order==='desc'){
                $last_names = array_column($arr,'sell_max_price');
                array_multisort($last_names,SORT_DESC,$arr);
            }else{
                $last_names = array_column($arr,'sell_max_price');
                array_multisort($last_names,SORT_ASC,$arr);
            }
        }
        if(isset($where) && $where=='deal_money_total'){
            if($order==='desc'){
                $last_names = array_column($arr,'deal_money_total');
                array_multisort($last_names,SORT_DESC,$arr);
            }else{
                $last_names = array_column($arr,'deal_money_total');
                array_multisort($last_names,SORT_ASC,$arr);
            }
        }
        // var_dump($arr);die;
       // 手动分页
        $sum = $offset + $limit;
        for($i=$offset;$i<$sum;$i++){
            if($i<count($arr))
                $result[$i] = $arr[$i];
        }

        // for($j=0;$j<count($result);$j++){
        //     $result[$k]=$j;
        // }
        $result1 =  array_values($result);
        $result['list'] = $result1;
        $result['count'] = count($arr);

        // var_dump($result);die;

        return $result;
        //主动做分页
    }

    public function user_order_all($user_id,$symbol,$offset,$limit)
    {
        $url       = $this->config->item('VIABTC_API_URL');
        if($symbol === '')
        {
            //获取所有交易市场
            if($this->config->item('SITE') === 'priv_one'){
                $sql = "select symbol from symbols";
            }else{
                $sql = "select symbol from total_symbols";
            }
            $symbolList = $this->db->query($sql)->result_array();
            $arr = array();
            foreach ($symbolList as $k => $v) {
                $post_data = array(
                    'id'       => 1,
                    'method'   => 'order.pending', //委托记录
                    'params'   => array(
                    (int)$user_id,$v['symbol'],(int)$offset,(int)$limit),
                );
                
                $post_data = json_encode($post_data);
                $ch        = curl_init();
                // 设置请求为post类型
                curl_setopt($ch, CURLOPT_POST, 1);
                // 添加post数据到请求中
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
                // 2. 设置请求选项, 包括具体的url
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                // 3. 执行一个cURL会话并且获取相关回复
                $response  = curl_exec($ch);
                // 4. 释放cURL句柄,关闭一个cURL会话
                curl_close($ch);
                $response  = object_to_array(json_decode($response));
                // var_dump($response);
                // var_dump($response['result']['records']);
                if(!empty($response['result']['records']))
                    $arr = array_merge($arr, $response['result']['records']);
            }
            $last_names = array_column($arr,'mtime');
            array_multisort($last_names,SORT_DESC,$arr);
        }else{
            $post_data = array(
                    'id'       => 1,
                    'method'   => 'order.pending', //委托记录
                    'params'   => array(
                    (int)$user_id,(string)$symbol,(int)$offset,(int)$limit),
                );
                
            $post_data = json_encode($post_data);
            $ch        = curl_init();
            // 设置请求为post类型
            curl_setopt($ch, CURLOPT_POST, 1);
            // 添加post数据到请求中
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
            // 2. 设置请求选项, 包括具体的url
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            // 3. 执行一个cURL会话并且获取相关回复
            $response  = curl_exec($ch);
            // 4. 释放cURL句柄,关闭一个cURL会话
            curl_close($ch);
            $response  = object_to_array(json_decode($response));
            // var_dump($response);
            // var_dump($response['result']['records']);
            if(!empty($response['result']['records']))
                $arr = $response['result']['records'];
        }
        
        if(empty($arr))
            return array();

        foreach ($arr as &$value) {
            $value['mtime'] = get_microtime_format($value['mtime']);
            $value['ctime'] = get_microtime_format($value['ctime']);
        }
        return $data['list'] = $arr;
        // var_dump($arr);die;
        return $arr;
    }
    /**
     * [flow_business_type description]
     * @return [type] [description]
     */
    public function flow_business_type()
    {
        $sql = "select business,business_desc from balance_business_descs where deleted_at is null and lang='zh-hans'";
        return $list = $this->db->query($sql)->result_array();
    }
}
//开始是：1.站点 2.交易对 3.表
//1.表 2.站点、币种、   交易总量
