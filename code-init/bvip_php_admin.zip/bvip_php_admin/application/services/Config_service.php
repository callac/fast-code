<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



date_default_timezone_set('PRC');
class Config_service extends MY_Service {


    function __construct()
    {
        parent::__construct();
        $this->load->model('Config_model');
    }

    public function get_list($offset,$limit,$site_id){
        return $this->Config_model->get_list($offset,$limit,$site_id);
    }

    public function get_count($site_id){
        return $this->Config_model->get_count($site_id);
    }

    public function c2c_param_config_list($offset,$limit,$site_id){
        $object = $this->db->select("options.*,b_site.name as site_name")
        ->join('b_site','b_site.id=options.site_id','left')
        ->from('options');
        if($site_id!='') $object =$this->db->where('options.site_id = ',$site_id);
        return $object->limit($limit,$offset)->get()->result_array();

        // return $this->Config_model->c2c_param_config_list($offset,$limit,$site_id);
    }

    public function c2c_param_config_list_count($site_id){
        $object = $this->db->select("options.*,b_site.name as site_name")
        ->join('b_site','b_site.id=options.site_id','left')
        ->from('options');
        if($site_id!='') $object =$this->db->where('options.site_id = ',$site_id);
        return $this->db->count_all_results();
        // return $this->Config_model->c2c_param_config_list_count($site_id);
    }

    public function c2c_config_update($args)
    {
        $id = isset($args['id']) ?$args['id'] : false;
        $varname = $args['var_name'];
        if($this->config->item('SITE')==='priv_one'){
            $site_id = 1;
        }else{
            $site_id = isset($args['site_id']) ? $args['site_id'] : '';
        }
        $value = $args['value'];
        $memo = $args['memo'];
        if($id){
            return $this->Config_model->c2c_config_update($id,$value,$memo,$site_id);
        }else{
            return $this->Config_model->c2c_config_add($varname,$value,$memo,$site_id);
        }
    }

    public function config_update($args){
        $id = isset($args['id']) ?$args['id'] : false;
        $varname = $args['varname'];
        $site_id = $args['site_id'];
        $config_info = $this->Config_model->get_info_by_va($varname,$site_id);
        if($id){
            if($config_info['id'] != $id && $config_info){
                return false;
            }
            return $this->Config_model->config_update($args['id'],$args['varname'],$args['value'],$args['remark'],$args['site_id']);
        }else{
            if($config_info){
                return false;
            }
            return $this->Config_model->config_add($args['varname'],$args['value'],$args['remark'],$args['site_id']);
        }
    }

    public function config_delete($id){
        return $this->Config_model->config_delete($id);
    }

    public function news_list($type,$offset,$limit,$site_id)
    {
        $data =  $this->Config_model->news_list($type,$offset,$limit,$site_id);
        foreach ($data as &$value)
        {
            $value['dateline'] = date("Y-m-d H:i:s",$value['dateline']);
        }
        return $data;
    }

    public function news_count($type,$site_id)
    {
        return $this->Config_model->news_count($type,$site_id);
    }

    public function newsUpdate($args)
    {
        $id = isset($args['id']) ? $args['id'] : false;
        $title = isset($args['title']) ? $args['title'] : false;
        $content = isset($args['content']) ? $args['content'] : false;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $news_class_id = isset($args['news_class_id']) ? $args['news_class_id'] : false;
        $resume = isset($args['resume']) ? $args['resume'] : '';
        $image = isset($args['image']) ? $args['image'] : '';
        $lang = isset($args['lang']) ? $args['lang'] : 'zh-hans';
        $dateline = time();
        if(!$id || !$title || !$content || !$site_id || !$news_class_id){
            returnJson('402',lang('missing_parameters'));
        }
        return $this->Config_model->newsUpdate($title,$content,$site_id,$id,$news_class_id,$resume,$image,$dateline,$lang);
    }

    public function newsAdd($args)
    {
        $title = isset($args['title']) ? $args['title'] : false;
        $content = isset($args['content']) ? $args['content'] : false;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : 2;
        $news_class_id = isset($args['news_class_id']) ? $args['news_class_id'] : false;
        $resume = isset($args['resume']) ? $args['resume'] : '';
        $image = isset($args['image']) ? $args['image'] : '';
        $lang = isset($args['lang']) ? $args['lang'] : 'zh-hans';
        $dateline = time();
        if(!$title || !$content || !$site_id || !$news_class_id){
            returnJson('402',lang('missing_parameters'));
        }
        // var_dump($image);die;
        return $this->Config_model->newsAdd($title,$content,$dateline,$site_id,$news_class_id,$resume,$image,$lang);
    }

    public function newsDelete($id){
        return $this->Config_model->newsDelete($id);
    }

    public function bdc_update($args){
        $args['created_at'] = date("Y-m-d H:i:s",time());
        $args['id'] = isset($args['id']) ? $args['id'] : false;
        $args['site_id'] = !empty($args['site_id']) ? $args['site_id'] : 1;
        if($args['id']){
            return $this->Config_model->bdc_update($args['bdc_name'],$args['content'],$args['site_id'],$args['id']);
        }else{
            return $this->Config_model->bdc_add($args['bdc_name'],$args['content'],$args['created_at'],$args['site_id']);
        }
    }

    public function bdc_list($offset,$limit,$site_id){
        return $this->Config_model->bdc_list($offset,$limit,$site_id);
    }

    public function bdc_count($site_id){
        return $this->Config_model->bdc_count($site_id);
    }

    public function bdc_delete($id){
        return $this->Config_model->bdc_delete($id);
    }

    public function help_update($args){
        $args['id'] = isset($args['id']) ? $args['id'] : false;
        $args['dateline'] = time();
        $args['site_id'] = !empty($args['site_id']) ? $args['site_id'] : 1;
        $args['lang'] = !empty($args['lang']) ? $args['lang'] : '';
        $args['title'] = !empty($args['title']) ? $args['title'] : '';
        $args['content'] = !empty($args['content']) ? $args['content'] : '';
        if($args['id']){
            return $this->Config_model->help_update($args['help_class_id'],$args['title'],$args['content'],$args['site_id'],$args['id'],$args['lang']);
        }else{
            return $this->Config_model->help_add($args['help_class_id'],$args['title'],$args['content'],$args['dateline'],$args['site_id'],$args['lang']);
        }
    }

    public function agreement_update($args){
        $args['id'] = isset($args['id']) ? $args['id'] : false;
        $args['dateline'] = time();
        $args['site_id'] = !empty($args['site_id']) ? $args['site_id'] : 1;
        $args['lang'] = !empty($args['lang']) ? $args['lang'] : 'zh-hans';
        if($args['id']){
            return $this->Config_model->agreement_update($args['unique_id'],$args['title'],$args['content'],$args['dateline'],$this->user_id,$args['site_id'],$args['id'],$args['lang']);
        }else{
            return $this->Config_model->agreement_add($args['unique_id'],$args['title'],$args['content'],$args['dateline'],$this->user_id,$args['site_id'],$args['lang']);
        }
    }

    public function help_class_add($args){
        $id = isset($args['id']) ? $args['id'] : false;
        $args['name'] = isset($args['name']) ? $args['name'] : false;
        $args['display_order'] = isset($args['display_order']) ? $args['display_order'] : " ";
        $args['site_id'] = !empty($args['site_id']) ? $args['site_id'] : 1;
        $args['lang'] = !empty($args['lang']) ? $args['lang'] : 'zh-hans';
        if($id){
            return $this->Config_model->help_class_update($args['name'],$args['display_order'],$args['site_id'],$args['id'],$args['lang']);
        }
        else{
            return $this->Config_model->help_class_add($args['name'],$args['display_order'],$args['site_id'],$args['lang']);
        }
    }


    public function help_class_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("b_help_class.*,b_site.name as site_name")
        ->join('b_site','b_site.id=b_help_class.site_id','left')
        ->from('b_help_class');
        
        if($site_id!=='') $object =$this->db->where('b_help_class.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->get()->result_array();

        // foreach ($list as  &$value) {
        //     $value[''] =  
        // }
        return $list;
    }

    public function help_class_count($offset,$limit,$site_id)
    {
        $object = $this->db->select("b_help_class.*,b_site.name")
        ->join('b_site','b_site.id=b_help_class.site_id','left')
        ->from('b_help_class');
        if($site_id!=='') $object =$this->db->where('b_help_class.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function app_update_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("app_upgrades.*,b_site.name as site_name")
        ->join('b_site','b_site.id=app_upgrades.site_id','left')
        ->from('app_upgrades');
        $object =$this->db->where('app_upgrades.deleted_at is null');
        if($site_id!='') $object =$this->db->where('app_upgrades.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->get()->result_array();
        return $list;
    }

    public function labelconfiglist($offset,$limit,$type,$site_id)
    {
        $object = $this->db->select("labelconfig.*,b_site.name as site_name")
        ->join('b_site','b_site.id=labelconfig.site_id','left')
        ->from('labelconfig');
        $object =$this->db->where('labelconfig.deleted_at is null');
        if($type!==null) $object =$this->db->where('labelconfig.type',$type);
        if($site_id!='') $object =$this->db->where('labelconfig.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->get()->result_array();
        return $list;
    }

    public function activityholdinglist($offset,$limit,$status,$site_id)
    {
        $object = $this->db->select("activity_holding_config.*,b_site.name as site_name")
        ->join('b_site','b_site.id=activity_holding_config.site_id','left')
        ->from('activity_holding_config');

        $object =$this->db->where('activity_holding_config.deleted_at is null');
        if($status!==null) $object =$this->db->where('activity_holding_config.status',$status);
        if($site_id!='') $object =$this->db->where('activity_holding_config.site_id =',$site_id);
        $list = $object->limit($limit,$offset)->get()->result_array();
        return $list;
    }

    public function user_lottery_logs($offset,$limit,$site_id,$level)
    {
        $object = $this->db->select("user_lottery_logs.*,b_site.name as site_name")
        ->join('users','users.id=user_lottery_logs.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_lottery_logs');

        $object =$this->db->where('user_lottery_logs.deleted_at is null');
        $object =$this->db->where('user_lottery_logs.award_level!=',0);
        if($level!==null) $object =$this->db->where('user_lottery_logs.award_level',$level);
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->get()->result_array();
        return $list;
    }

    public function user_lottery_logscount($site_id,$level)
    {
        $object = $this->db->select("user_lottery_logs.*,b_site.name as site_name")
        ->join('users','users.id=user_lottery_logs.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_lottery_logs');

        $object =$this->db->where('user_lottery_logs.deleted_at is null');
        $object =$this->db->where('user_lottery_logs.award_level!=',0);
        if($level!==null) $object =$this->db->where('user_lottery_logs.award_level',$level);
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function user_treasure_logslist($offset,$limit,$site_id,$is_win,$user_id)
    {
        $object = $this->db->select("user_treasure_logs.*,b_site.name as site_name")
        ->join('users','users.id=user_treasure_logs.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_treasure_logs');

        $object =$this->db->where('user_treasure_logs.deleted_at is null');
        if($is_win!==null) $object =$this->db->where('user_treasure_logs.is_winning',$is_win);
        if($user_id!==null) $object =$this->db->where('user_treasure_logs.user_id',$user_id);
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        // print_r($list);die;
        return $list;
    }

    public function user_treasure_logscount($site_id,$is_win,$user_id)
    {
        $object = $this->db->select("user_treasure_logs.*,b_site.name as site_name")
        ->join('users','users.id=user_treasure_logs.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_treasure_logs');

        $object =$this->db->where('user_treasure_logs.deleted_at is null');
        if($is_win!==null) $object =$this->db->where('user_treasure_logs.is_winning',$is_win);
        if($user_id!==null) $object =$this->db->where('user_treasure_logs.user_id',$user_id);
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function treasure_sessionslist($offset,$limit,$site_id,$status)
    {
        $object = $this->db->select("treasure_sessions.*,b_site.name as site_name")
        ->join('b_site','b_site.id=treasure_sessions.site_id','left')
        ->from('treasure_sessions');

        $object =$this->db->where('treasure_sessions.deleted_at is null');
        if($status!==null) $object =$this->db->where('treasure_sessions.status',$status);
        if($site_id!='') $object =$this->db->where('treasure_sessions.site_id = ',$site_id);

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        return $list;
    }

    public function treasure_sessionscount($site_id,$status)
    {
        $object = $this->db->select("treasure_sessions.*,b_site.name as site_name")
        ->join('b_site','b_site.id=treasure_sessions.site_id','left')
        ->from('treasure_sessions');

        $object =$this->db->where('treasure_sessions.deleted_at is null');
        if($status!==null) $object =$this->db->where('treasure_sessions.status',$status);
        if($site_id!='') $object =$this->db->where('treasure_sessions.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function apptradelist($offset,$limit,$site_id,$user_id,$status,$api_key)
    {
        $object = $this->db->select("user_apps.id,user_apps.created_at,user_apps.admin_id,user_apps.user_id,user_apps.remark,user_apps.bind_ips,user_apps.api_key,user_apps.status,user_apps.expire_time,b_site.name as site_name,users.realname,b_admin.user_name")
        ->join('users','users.id=user_apps.user_id','left')
        ->join('b_admin','user_apps.admin_id=b_admin.user_id','left')
        ->join('b_site','b_site.id=users.site_id','left')
        ->from('user_apps');
        $object =$this->db->where('user_apps.deleted_at is null');
        if($user_id!==null) $object =$this->db->where('user_apps.user_id =',$user_id);
        if($status!==null) $object =$this->db->where('user_apps.status =',$status);
        if($api_key!==null) $object =$this->db->where('user_apps.api_key =',$api_key);
        if($site_id!='') $object =$this->db->where('user_apps.site_id =',$site_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        foreach ($list as &$value) {
            if($value['expire_time']){
                if(strtotime($value['expire_time'])-$_SERVER['REQUEST_TIME']<0){
                    $value['expire_day'] = '已失效';
                }else{
                    $day_mo = floor((strtotime($value['expire_time']) - $_SERVER['REQUEST_TIME'])/86400);
                    $day_yu = (strtotime($value['expire_time']) - $_SERVER['REQUEST_TIME'])%86400;
                    $hour_mo = floor($day_yu/3600);
                    $hour_yu = $day_yu%3600;
                    $min_mo = floor($hour_yu/60);
                    $min_yu = $hour_yu%60;
                    // var_dump($day_mo,$day_yu,$hour_mo,$hour_yu,$min_mo,$min_yu);die;
                    $value['expire_day'] = $day_mo.'天'.$hour_mo.'小时'.$min_mo.'分'.$min_yu.'秒';
                }
                // $value['expire_day'] = ceil((strtotime($value['expire_time']) - $_SERVER['REQUEST_TIME'])/86400);
            }
            else{
                $value['expire_day'] = '永久';
            }
        }
        return $list;
    }

    public function apptradecount($site_id,$user_id,$status,$api_key)
    {
        $object = $this->db->select("user_apps.id,user_apps.created_at,user_apps.admin_id,user_apps.user_id,user_apps.remark,b_site.name as site_name,users.realname,b_admin.user_name")
            ->join('users','users.id=user_apps.user_id','left')
            ->join('b_admin','user_apps.admin_id=b_admin.user_id','left')
            ->join('b_site','b_site.id=users.site_id','left')
            ->from('user_apps');
        $object =$this->db->where('user_apps.deleted_at is null');
        if($user_id!==null) $object =$this->db->where('user_apps.user_id =',$user_id);
        if($status!==null) $object =$this->db->where('user_apps.status =',$status);
        if($api_key!==null) $object =$this->db->where('user_apps.api_key =',$api_key);
        if($site_id!='') $object =$this->db->where('user_apps.site_id =',$site_id);
        return $this->db->count_all_results();
    }


    /**
     * Notes: api的详情
     * User: 张哲
     * Date: 2019-07-20
     * Time: 14:18
     */
    public function appTradeDetails($api_id)
    {

        $object = $this->db->select("user_apps.api_key,user_apps.secret_key")
            ->from('user_apps');

        $object =$this->db->where('user_apps.id =',$api_id);

        $list = $object->get()->result_array();
        return $list;
    }

    public function appTradestatus($args)
    {
        $id = $args['id'];
        $status = $args['status'];
        $record_status = $this->db->query("select status from user_apps where id=$id")->row_array()['status'];
        if($record_status == $status) returnJson('402','所传状态非法');
        return $this->Config_model->appTradestatus($id,$status);
    }

    public function mailconfiglist($offset,$limit,$site_id)
    {
        $list =$this->db->select("mail_tongji_config.*,b_site.name as site_name")
            ->join('b_site','b_site.id=mail_tongji_config.site_id','left')
            ->limit($limit,$offset)
            ->get('mail_tongji_config')
            ->result_array();
        return $list;
    }



    public function mailconfigcount($site_id)
    {
        $count =$this->db->select("mail_tongji_config.*,b_site.name as site_name")
            ->join('b_site','b_site.id=mail_tongji_config.site_id','left')
            ->get('mail_tongji_config')
            ->num_rows();
        return $count;
    }

    public function statisticmailsentrecords($offset,$limit,$site_id)
    {
        $object = $this->db->select("mail_tongji_logs.*,b_site.name as site_name")
        ->join('b_site','b_site.id=mail_tongji_logs.site_id','left')
        ->from('mail_tongji_logs');
        // $object =$this->db->where('mail_tongji_logs.deleted_at is null');
        if($site_id!='') $object =$this->db->where('mail_tongji_logs.site_id =',$site_id);
        $list = $object->limit($limit,$offset)->get()->result_array();
        return $list;
    }

    public function statisticmailsentrecordscount($site_id)
    {
        $object = $this->db->select("mail_tongji_logs.*,b_site.name as site_name")
        ->join('b_site','b_site.id=mail_tongji_logs.site_id','left')
        ->from('mail_tongji_logs');
        // $object =$this->db->where('mail_tongji_logs.deleted_at is null');
        if($site_id!='') $object =$this->db->where('mail_tongji_logs.site_id =',$site_id);
        return $this->db->count_all_results();
    }

    public function csv_logs_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("csv_logs.*")
        ->from('csv_logs');
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        foreach ($list as $key => $value) {
            if($value['tongji_type']==1)
                $value['type'] = '用户统计';
            if($value['tongji_type']==2)
                $value['type'] = '币币交易';
            if($value['tongji_type']==3)
                $value['type'] = '充值';
            if($value['tongji_type']==4)
                $value['type'] = '提现';
            if($value['tongji_type']==5)
                $value['type'] = '法币买入';
            if($value['tongji_type']==6)
                $value['type'] = '法币卖出';
        }
        return $list;
    }

    public function csv_logs_count($site_id)
    {
        $object = $this->db->select("csv_logs.*")
        ->from('csv_logs');
        return $this->db->count_all_results();
    }







    public function apptradeadd($args)
    {
        $utime = date('Y-m-d H:i:s',time());
        $ctime = date('Y-m-d H:i:s',time());
        if(!is_numeric($args['user_id'])) returnJson('402','用户ID非法');
        $user_true = $this->Config_model->is_true_user($args['user_id']);
        if(is_array($user_true) && empty($user_true)) returnJson('403','该用户不存在！');
        $args['id'] = isset($args['id']) ? $args['id'] : false;
        $user_id = $args['user_id'];
        //判断当前用户是否有配置数量的api个数
        //获取参数配置的api-key个数
        $apikeynums = $this->db->query("select value from options where var_name='api_max_bind'")->row_array()['value'];
        

        $remark = $args['remark'];
        $admin_id = $this->user_id;
        $site_id = $this->db->query("select site_id from users where id=$user_id")->row_array()['site_id'];
        $args['api_key'] = getRandChar(36);
        $args['secret_key'] = getRandChar(36);
        $bind_ips = isset($args['bind_ips']) ? $args['bind_ips'] : '';

        $is_true = $this->Config_model->is_true_apikey($args['api_key']);
        // $is_user_true = $this->Config_model->is_true_userid($args['user_id']);
        if(is_array($is_true) && !empty($is_true)) returnJson('402','api_key已存在！');
        // if($is_user_true['numrows']!='0') returnJson('402','该用户ID交易API已存在！');

        $this->db->trans_begin();
        if($args['id']){
            if(empty($bind_ips)){
                $second = $this->db->query("select value from options where var_name='api_expire_time'")->row_array()['value'];
                $expire_time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']+$second);
                $this->Config_model->apptrade_update($args['user_id'],$args['api_key'],$args['secret_key'],$utime,$args['id'],$bind_ips,$remark,$expire_time);
            }else{
                $this->Config_model->apptrade_update_bind_ips($args['user_id'],$args['api_key'],$args['secret_key'],$utime,$args['id'],$bind_ips,$remark,$expire_time=NULL);
            }
            //admin_operation_logs表中operation_type=21表示 API添加 operation_type=22 API删除.人为规定
            admin_operation_logs($admin_id,$args['user_id'],32,'修改用户API',$utime,$args['id']);
        }else{
            //获取当前用户已经添加api-key的个数
            $user_apinums = $this->db->query("select count(*) as numrows from user_apps where deleted_at is null and user_id=$user_id")->row_array()['numrows'];
            if($user_apinums>=$apikeynums) returnJson('402','已超过单个用户api_key配置上限');
            if($bind_ips){
                $insert_id = $this->Config_model->apptrade_add($args['user_id'],$args['api_key'],$args['secret_key'],$ctime,$utime,$admin_id,$remark,$bind_ips,$site_id,$expire_time=NULL);
            }else{
                $second = $this->db->query("select value from options where var_name='api_expire_time'")->row_array()['value'];
                $expire_time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']+$second);
                $insert_id = $this->Config_model->apptrade_add($args['user_id'],$args['api_key'],$args['secret_key'],$ctime,$utime,$admin_id,$remark,$bind_ips,$site_id,$expire_time);
            }
            
            admin_operation_logs($admin_id,$args['user_id'],31,'添加用户API',$utime,$insert_id);
        }
        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    public function mailconfigadd($args)
    {
        $ctime = $utime = date('Y-m-d H:i:s',time());
        $args['id'] = isset($args['id']) ? $args['id'] : ''; //展示不配置站点

        $this->db->trans_begin();

        if($args['id']){
            $this->Config_model->mailconfigadd_update($args['site_id'],$args['uid'],$args['email'],$args['tongji_type'],$utime,$args['id']);
        }else{
            $detail = $this->Config_model->is_tongji_type($args['tongji_type']);
            if(is_array($detail) && !empty($detail)) returnJson('402','类型已存在不能重复添加');
            $this->Config_model->mailconfigadd_add($args['site_id'],$args['uid'],$args['email'],$args['tongji_type'],$ctime,$utime);
        }
        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    public function mail_config_add($args){
        $uid = $args['uid'];
        $tongji_type = $args['tongji_type'];
        $id =isset($args['id']) ? $args['id'] : 0 ;
        $site_id = 0;
        $result = $this->db->select('uid')->order_by('id desc')->get_where('mail_tongji_config',array('tongji_type'=>$tongji_type))->row_array();
        if($result){
            if($id){
                $uid =  implode(',',array_unique(explode(',',$uid)));
            }else{
                $uid =implode(',',array_unique(array_merge(explode(',',$result['uid']),explode(',',$uid))));
            }
            $res = $this->db->where('tongji_type',$tongji_type)->update('mail_tongji_config',array(
                'uid'=>$uid,
                'updated_at' => date('Y-m-d H:i:s',time())
            ));
        }else{
            $mail_tongji_config['tongji_type'] = $tongji_type;
            $mail_tongji_config['uid'] = implode(',',array_unique(explode(',',$uid)));
            $mail_tongji_config['created_at'] = date('Y-m-d H:i:s',time());
            $mail_tongji_config['updated_at'] = date('Y-m-d H:i:s',time());
            $mail_tongji_config['site_id'] = $site_id;
            $res = $this->db->insert('mail_tongji_config',$mail_tongji_config);
        }
        return $res;
    }

    public function activityholdingawardlist($offset,$limit,$id,$status)
    {
        $object = $this->db->select("activity_holding_award.*")
        ->from('activity_holding_award');

        $object =$this->db->where('activity_holding_award.deleted_at is null');
        if(!empty($id)){
            $object =$this->db->where('activity_holding_award.h_c_id=',$id);
        }
        if(!empty($status)){
            $object =$this->db->where('activity_holding_award.status=',$status);
        }
        $list = $object->limit($limit,$offset)->get()->result_array();
        // var_dump($list);die;
        foreach ($list as &$value) {
            $value['snapshot'] = date('Y-m-d H:i:s',(int)$value['snapshot']);
        }
        return $list;
    }

    public function activityholdingawardcount($id,$status)
    {
        $object = $this->db->select("activity_holding_award.*")
        ->from('activity_holding_award');
        $object =$this->db->where('activity_holding_award.deleted_at is null');
        if(!empty($status)){
            $object =$this->db->where('activity_holding_award.status=',$status);
        }
        if(!empty($id)){
            $object =$this->db->where('activity_holding_award.h_c_id=',$id);
        }

        return $this->db->count_all_results();
    }



    public function activityholdingcount($status,$site_id)
    {
        $object = $this->db->select("activity_holding_config.*,b_site.name as site_name")
        ->join('b_site','b_site.id=activity_holding_config.site_id','left')
        ->from('activity_holding_config');
        $object =$this->db->where('activity_holding_config.deleted_at is null');
        if($status!==null) $object =$this->db->where('activity_holding_config.status',$status);
        if($site_id!='') $object =$this->db->where('activity_holding_config.site_id =',$site_id);
        return $this->db->count_all_results();
    }

    public function activityholdingadd($args){
        $args['id'] = isset($args['id']) ? $args['id'] : false;
        $ctime = date('Y-m-d H:i:s',time());
        $utime = date('Y-m-d H:i:s',time());
        $args['site_id'] = !empty($args['site_id']) ? $args['site_id'] : 1;
        if($args['id']){
            $status = $this->Config_model->activityholdingdetail($args['id']);
            if($status['status']==2 || $status['status']==3) returnJson('403','当前活动不能编辑！');
            if(time()>strtotime($status['snapshot'])) returnJson('403','活动进行中不能编辑！');
            return $this->Config_model->activityholdingupdate($args['asset'],$args['hold_area'],$args['award_get'],$args['snapshot'],$args['site_id'],$utime,$args['id']);
        }else{
            return $this->Config_model->activityholdingadd($args['asset'],$args['hold_area'],$args['award_get'],$args['snapshot'],$args['site_id'],$ctime,$utime);
        }
    }


    public function labelconfigcount($type,$site_id)
    {
        $object = $this->db->select("labelconfig.*,b_site.name as site_name")
        ->join('b_site','b_site.id=labelconfig.site_id','left')
        ->from('labelconfig');
        $object =$this->db->where('labelconfig.deleted_at is null');
        if($type!==null) $object =$this->db->where('labelconfig.type',$type);
        if($site_id!='') $object =$this->db->where('labelconfig.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function labelconfigadd($args){
        $args['id'] = isset($args['id']) ? $args['id'] : false;
        $args['class_id'] = isset($args['class_id']) ? $args['class_id'] : '';
        $args['label_name'] = isset($args['label_name']) ? $args['label_name'] : '';
        // var_dump($args['class_id']);die;
        $args['api_url'] = isset($args['api_url']) ? $args['api_url'] : '';
        // $args['order'] = isset($args['order']) ? $args['order'] : 0;
        $args['icon'] = isset($args['icon']) ? $args['icon'] : '';
        $args['qrcode'] = isset($args['qrcode']) ? $args['qrcode'] : '';
        $args['lang'] = isset($args['lang']) ? $args['lang'] : 'zh-hans';
        $ctime = date('Y-m-d H:i:s',time());
        $utime = date('Y-m-d H:i:s',time());
        $args['site_id'] = !empty($args['site_id']) ? $args['site_id'] : 1;
        if($args['id']){
            // echo 11;die;
            return $this->Config_model->labelconfigupdate($args['label_name'],$args['api_url'],$args['order'],$args['type'],$args['site_id'],$utime,$args['id'],$args['class_id'],$args['icon'],$args['qrcode'],$args['lang']);
        }else{
            return $this->Config_model->labelconfigadd($args['label_name'],$args['api_url'],$args['order'],$args['type'],$args['site_id'],$ctime,$utime,$args['class_id'],$args['icon'],$args['qrcode'],$args['lang']);
        }
    }



    public function app_update_count($site_id)
    {
        $object = $this->db->select("app_upgrades.*,b_site.name as site_name")
        ->join('b_site','b_site.id=app_upgrades.site_id','left')
        ->from('app_upgrades');
        $object =$this->db->where('app_upgrades.deleted_at is null');
        if($site_id!='') $object =$this->db->where('app_upgrades.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function app_update_add($args)
    {
        $args['id'] = isset($args['id']) ? $args['id'] : false;
        if(!is_numeric($args['version_id'])) return false;
        if(!is_numeric($args['version_major'])) return false;
        if(!is_numeric($args['version_minor'])) return false;

        $ctime = date('Y-m-d H:i:s',time());
        $utime = date('Y-m-d H:i:s',time());
        $args['site_id'] = !empty($args['site_id']) ? $args['site_id'] : 1;

        $version_code = $args['version_id'].'_'.$args['version_major'].'_'.$args['version_minor'];
        $args['status'] = 1;

        if($args['id']){
            return $this->Config_model->app_update_update($args['app_endpoint'],$args['version_id'],$args['version_major'],$args['version_minor'],$version_code,$args['type'],$args['apk_url'],$args['upgrade_point'],$args['status'],$args['site_id'],$this->user_id,$args['remark'],$utime,$args['id']);
        }else{
            $this->db->trans_start();

            $this->Config_model->update_appupgrades($args['app_endpoint'],0,$args['site_id']);
            $this->Config_model->app_update_add($args['app_endpoint'],$args['version_id'],$args['version_major'],$args['version_minor'],$version_code,$args['type'],$args['apk_url'],$args['upgrade_point'],$args['status'],$args['site_id'],$this->user_id,$args['remark'],$ctime,$utime);
            
            if($this->db->trans_complete()){
                return true;
            }else{
                return false;
            }
        }
    }

    public function app_update_delete($id,$time){
        return $this->Config_model->app_update_delete($id,$time);
    }

    public function labelconfigdelete($id,$time){
        return $this->Config_model->labelconfigdelete($id,$time);
    }

    public function activityholdingdelete($id,$time){
        return $this->Config_model->activityholdingdelete($id,$time);
    }

    public function apptrade_delete($id,$time){
        $admin_id = $this->user_id;
        $utime = date('Y-m-d H:i:s',time());
        admin_operation_logs($admin_id,$id,32,'删除api配置',$utime,$id);
        return $this->Config_model->apptrade_delete($id,$time);
    }

    public function mailconfigdelete($id,$time){
        return $this->Config_model->mailconfigdelete($id,$time);
    }










    public function help_class_delete($id){
        return $this->Config_model->help_class_delete($id);
    }




    public function friendlink_update($args){
        $args['id'] = isset($args['id']) ? $args['id'] : false;
        // $args['dateline'] = time();
        $args['site_id'] = !empty($args['site_id']) ? $args['site_id'] : 1;
        $args['lang'] = !empty($args['lang']) ? $args['lang'] : 'lang';
        if($args['id']){
            return $this->Config_model->friendlink_update($args['image'],$args['url'],$args['remark'],$args['site_id'],$args['id'],$args['lang']);
        }else{
            return $this->Config_model->friendlink_add($args['image'],$args['url'],$args['remark'],$args['site_id'],$args['lang']);
        }
    }


    public function help_list($offset,$limit,$site_id,$help_class_id){
        return $this->Config_model->help_list($offset,$limit,$site_id,$help_class_id);
    }

    public function agreement_list($offset,$limit,$site_id){
        return $this->Config_model->agreement_list($offset,$limit,$site_id);
    }


    public function friendlink_list($offset,$limit,$site_id){
        return $this->Config_model->friendlink_list($offset,$limit,$site_id);
    }


    public function help_class(){
        return $this->Config_model->help_class();
    }

    public function help_count($site_id,$help_class_id){
        return $this->Config_model->help_count($site_id,$help_class_id);
    }

    public function agreement_count($site_id){
        return $this->Config_model->agreement_count($site_id);
    }

    public function friendlink_count($site_id){
        return $this->Config_model->friendlink_count($site_id);
    }

    public function help_delete($id){
        return $this->Config_model->help_delete($id);
    }

    public function agreement_delete($id){
        return $this->Config_model->agreement_delete($id);
    }

    public function friendlink_delete($id){
        return $this->Config_model->friendlink_delete($id);
    }


    public function version_list($offset,$limit,$site_id){
        $data =  $this->Config_model->version_list($offset,$limit,$site_id);
        foreach ($data as &$values){
            $values['created_at'] = date("Y-m-d H:i:s",$values['created_at']);
        }
        return $data;
    }

    public function version_count($site_id){
        return $this->Config_model->version_count($site_id);
    }

    public function version_update($args){
        $device_id = $args['device_id'];
        $version_number = $args['version_number'];
        $download_url = $args['download_url'];
        $site_id = $args['site_id'];
        $id = isset($args['id']) ? $args['id'] : '' ;
        $time = time();
        if($id){
            return $this->Config_model->version_update($device_id,$version_number,$download_url,$site_id,$id);
        }else{
            return $this->Config_model->version_add($device_id,$version_number,$download_url,$site_id,$time);
        }

    }

    public function version_delete($id){
        return $this->Config_model->version_delete($id);
    }


    public function banner_friend_list($type,$offset,$limit,$site_id){
        $data =  $this->Config_model->banner_friend_list($type,$offset,$limit,$site_id);
        foreach ($data as &$value) {
            if($value['type'] == 1){
                $value['type_status'] = 'banner';
            }
            if($value['type'] == 2){
                $value['type_status'] = 'popup';
            }
        }
        return $data;
    }

    public function banner_friend_count($type,$site_id){
        return $this->Config_model->banner_friend_count($type,$site_id);
    }

    //首页轮播图 新增/更新
    public function banner_update($args){
        $id = isset($args['id']) ? $args['id'] : false;//id
        $image = isset($args['image']) ? $args['image'] : '';//图片地址
        $title = isset($args['title']) ? $args['title'] : '';//图片标题
        $url = isset($args['url']) ? $args['url'] : '';//链接地址
        $url_type = isset($args['url_type']) ? $args['url_type'] : '';//链接的类型 enum('normal','product','transfer','outlink')
        $endpoint = isset($args['endpoint']) ? $args['endpoint'] : '';//终端类型 enum('web','wap','app','pc')
        $position = isset($args['position']) ? $args['position'] : '';//所属位置
        $type = isset($args['type']) ? $args['type'] : 1;//显示类型
        $lang = isset($args['lang']) ? $args['lang'] : 'zh-hans';//显示类型
        $display_order = isset($args['display_order']) ? $args['display_order'] : '';//排序顺序，0表示不显示
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        if($id){
            return $this->Config_model->banner_update($title,$image,$url,$url_type,$endpoint,$position,$display_order,$id,$site_id,$type,$lang);
        }else{
            //判断当前站点下是否有多个
            if($type == 2){
                $popup = $this->Config_model->get_popup_num_by_id($site_id,$endpoint);
                // var_dump($popup);die;
                if($popup[0]['num'] >= 1) returnJson('402','最多只能添加一个弹窗');
            }
            return $this->Config_model->banner_add($title,$image,$url,$url_type,$endpoint,$position,$display_order,$site_id,$type,$lang);
        }
    }

    //友情链接 新增/更新
    public function friend_update($args)
    {
        $id = isset($args['id']) ? $args['id'] : false;//id
        $title = isset($args['title']) ? $args['title'] : '';//图片标题
        $url = isset($args['url']) ? $args['url'] : '';//链接地址
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';//链接地址
        if($id){
            return $this->Config_model->friend_update($title,$url,$id);
        }else{
            return $this->Config_model->friend_add($title,$url,$site_id);
        }
    }

    public function banner_friend_delete($id){
        return $this->Config_model->banner_friend_delete($id);
    }

    //--------------------新闻资讯分类-------------------------
    public function news_class(){
        $data = $this->input->post();
        $limit = isset($data['limit']) ? intval($data['limit']) : 15;//条数限制
        $page = isset($data['page']) ? intval($data['page']) : 1;
        $site_id =  !empty($data['site_id']) ? intval($data['site_id']) : null;
        $offset = ($page-1)*$limit;
        $news_list = $this->Config_model->news_class_list($site_id,$offset,$limit);
        $news_count = $this->Config_model->news_class_count($site_id);
        $list['total'] = $news_count;
        $list['pageSize'] = $limit;
        $list['curPage'] = $page;
        $list['totalPage'] = ceil($news_count/$limit);
        $list['list'] = $news_list;
        returnJson('200',lang('operation_successful'),$list);
    }
    public function news_class_update(){
        $data = $this->input->post();
        $remark = isset($data['remark']) ? $data['remark'] : '';
        $id = isset($data['id']) ? $data['id'] : '';
        $site_id = isset($data['site_id']) ? $data['site_id'] : 0;
        $lang = isset($data['lang']) ? $data['lang'] : 'zh-hans';
        // var_dump($lang);die;
        if($id){
            $res = $this->Config_model->news_class_update($id,$data['name'],$remark,$data['display_order'],$site_id,$lang);
        }else{
            $res = $this->Config_model->news_class_add($data['name'],$remark,$data['display_order'],$site_id,$lang);
        }
        if($res) returnJson('200',lang('operation_successful'));
        returnJson('402',lang('operation_failed'));
    }
    public function news_class_delete(){
        $id = $this->input->post('id');
        $res = $this->Config_model->news_class_delete($id);
        if($res) returnJson('200',lang('operation_successful'));
        returnJson('402',lang('missing_parameters'));
    }


    public function about_list($offset,$limit,$site_id){
        $data =  $this->Config_model->about_list($offset,$limit,$site_id);

        foreach ($data as &$values){
            $values['about_us'] = $this->Config_model->about_us_by_site($values['site_id']);
            $values['dateline'] = date("Y-m-d H:i:s",$values['dateline']);
        }
        return $data;
    }
    public function about_count($site_id){
        return $this->Config_model->about_count($site_id);
    }

    public function about_update($args){
        $banner_title = $args['banner_title'];
        $banner_content = $args['banner_content'];
        $banner_up_title = $args['banner_up_title'];
        $banner_up_resume = $args['banner_up_resume'];
        $map_title = $args['map_title'];
        $map_des = $args['map_des'];
        $slogan = $args['slogan'];
        $slogn_content = $args['slogn_content'];
        $site_id = isset($args['site_id']) ? $args['site_id'] : '' ;
        $id = isset($args['id']) ? $args['id'] : '' ;
        $about_us = isset($args['about_us']) ? $args['about_us'] : array();//关于我们
        $this->Config_model->delete_about_us($site_id);
        foreach ($about_us as $val){
            $this->Config_model->add_about_us($val['center_block_title'],$val['center_block_content'],$val['center_block_image'],time(),$site_id,$val['bottom_block_image'],$val['bottom_block_word']);
        }
        $time = time();
        if($id){
            return $this->Config_model->about_update($banner_title,$banner_content,$banner_up_title,$banner_up_resume,$map_title,$map_des,$slogan,$slogn_content,$site_id,$id);
        }else{
            //禁止新增
            $res = $this->Config_model->get_about_by_site($site_id);
            if($res){
                return false;
            }

            return $this->Config_model->about_add($banner_title,$banner_content,$banner_up_title,$banner_up_resume,$map_title,$map_des,$slogan,$slogn_content,$time,$site_id);
        }

    }

    public function about_delete($site_id){
        $this->Config_model->about_delete($site_id);
        $this->Config_model->delete_about_us($site_id);
        return true;
    }


    public function question_list($offset,$limit,$site_id){
        $data =  $this->Config_model->question_list($offset,$limit,$site_id);
        foreach ($data as &$values){
            $values['create_time'] = date("Y-m-d H:i:s",$values['create_time']);
        }
        return $data;
    }

    public function question_count($site_id){
        return $this->Config_model->question_count($site_id);
    }

    //交易区块配置相关
    public function smsconfig_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("b_site_sms.*,b_site.name as site_name")
            ->join('b_site','b_site.id=b_site_sms.site_id','left')
            ->where('deleted_at is null')
            ->from('b_site_sms');

        if($site_id!='') $object =$this->db->where('b_site_sms.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function smsconfig_list_count($site_id)
    {
        $object = $this->db->select("b_site_sms.*")
            ->join('b_site','b_site.id=b_site_sms.site_id','left')
            ->where('deleted_at is null')
            ->from('b_site_sms');

        if($site_id!='') $object =$this->db->where('b_site_sms.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function smsconfig_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';

        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $is_default = isset($args['is_default']) ? $args['is_default']: 0;
        $account = isset($args['account']) ? $args['account']: '';
        $password = isset($args['password']) ? $args['password']: '';
        $sign_name = isset($args['sign_name']) ? $args['sign_name']: '';
        $channel = isset($args['channel']) ? $args['channel']: '';
        $template_code = '';
        if($channel == 'dysms'){
            $template_code = isset($args['dy_template_code']) ? $args['dy_template_code'] : false;
            if(!$template_code) returnJson('402','选择dysms时候缺少模版码参数');
        }

        $internal = isset($args['internal']) ? $args['internal']: '';

        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->add_smsconfig($site_id,$is_default,$account,$password,$sign_name,$channel,$template_code,$internal,$created_at,$updated_at);
        }else{
            //修改
            $this->Config_model->edit_smsconfig($site_id,$is_default,$account,$password,$sign_name,$channel,$template_code,$internal,$updated_at,$id);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }

    public function smsconfig_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->smsconfig_delete($id,$time);
    }

    public function smsconfig_used($args)
    {
        $this->db->trans_begin();
        //获取当前的配置信息
        $detail = $this->Config_model->get_smsconfig_info($args['id']);
        //将当前站点的is_used全部改为0 ，当前的id 除外
        $this->Config_model->smsconfig_is_used($detail['site_id'],$args['id']);
        $this->Config_model->smsconfig_is_used_byid($args['id']);
        
        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }





    public function emailconfig_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("b_site_email.*,b_site.name as site_name")
            ->join('b_site','b_site.id=b_site_email.site_id','left')
            ->where('deleted_at is null')
            ->from('b_site_email');

        if($site_id!='') $object =$this->db->where('b_site_email.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function emailconfig_list_count($site_id)
    {
        $object = $this->db->select("b_site_email.*,b_site.name as site_name")
            ->join('b_site','b_site.id=b_site_email.site_id','left')
            ->where('b_site_email.deleted_at is null')
            ->from('b_site_email');

        if($site_id!='') $object =$this->db->where('b_site_email.site_id = ',$site_id);
        return $this->db->count_all_results();
    }


    public function emailconfig_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';

        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $is_default = isset($args['is_default']) ? $args['is_default']: 0;
        $account = isset($args['account']) ? $args['account']: '';
        $password = isset($args['password']) ? $args['password']: '';
        $sign_name = isset($args['sign_name']) ? $args['sign_name']: '';
        $channel = isset($args['channel']) ? $args['channel']: '';
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->add_emailconfig($site_id,$is_default,$account,$password,$channel,$created_at,$updated_at);
        }else{
            //修改
            $this->Config_model->edit_emailconfig($site_id,$is_default,$account,$password,$channel,$updated_at,$id);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }

    public function emailconfig_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->emailconfig_delete($id,$time);
    }

    public function emailconfig_used($args)
    {
        $this->db->trans_begin();
        //获取当前的配置信息
        $detail = $this->Config_model->get_emailconfig_info($args['id']);
        //将当前站点的is_used全部改为0 ，当前的id 除外
        $this->Config_model->emailconfig_is_used($detail['site_id'],$args['id']);
        $this->Config_model->emailconfig_is_used_byid($args['id']);
        
        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }










    public function inviteconfig_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("b_inviteimg_config.*,b_site.name as site_name")
            ->join('b_site','b_site.id=b_inviteimg_config.site_id','left')
            ->where('deleted_at is null')
            ->from('b_inviteimg_config');

        if($site_id!='') $object =$this->db->where('b_inviteimg_config.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function inviteconfig_list_count($site_id)
    {
        $object = $this->db->select("b_inviteimg_config.*,b_site.name as site_name")
            ->join('b_site','b_site.id=b_inviteimg_config.site_id','left')
            ->where('b_inviteimg_config.deleted_at is null')
            ->from('b_inviteimg_config');

        if($site_id!='') $object =$this->db->where('b_inviteimg_config.site_id = ',$site_id);
        return $this->db->count_all_results();
    }


    public function inviteconfig_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';

        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $image = isset($args['image']) ? $args['image']: '';
        $qrcode_x = isset($args['qrcode_x']) ? $args['qrcode_x']: '';
        $qrcode_y = isset($args['qrcode_y']) ? $args['qrcode_y']: '';
        $qrcode_w = isset($args['qrcode_w']) ? $args['qrcode_w']: '';
        $qrcode_h = isset($args['qrcode_h']) ? $args['qrcode_h']: '';

        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->add_inviteconfig($site_id,$image,$qrcode_x,$qrcode_y,$qrcode_w,$qrcode_h,$created_at,$updated_at);
        }else{
            //修改
            $this->Config_model->edit_inviteconfig($site_id,$image,$qrcode_x,$qrcode_y,$qrcode_w,$qrcode_h,$updated_at,$id);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }

    public function inviteconfig_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->inviteconfig_delete($id,$time);
    }


    public function ip_list($offset,$limit,$site_id,$type)
    {
        $object = $this->db->select("b_site_ip.*,b_site.name as site_name")
            ->join('b_site','b_site.id=b_site_ip.site_id','left')
            ->where('b_site_ip.deleted_at is null')
            ->from('b_site_ip');

        if($site_id!='') $object =$this->db->where('b_site_ip.site_id = ',$site_id);
        if($type!='') $object =$this->db->where('b_site_ip.type = ',$type);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function ip_list_count($site_id,$type)
    {
        $object = $this->db->select("b_site_ip.*,b_site.name as site_name")
            ->join('b_site','b_site.id=b_site_ip.site_id','left')
            ->where('b_site_ip.deleted_at is null')
            ->from('b_site_ip');

        if($site_id!='') $object =$this->db->where('b_site_ip.site_id = ',$site_id);
        if($type!='') $object =$this->db->where('b_site_ip.type = ',$type);
        return $this->db->count_all_results();
    }

    public function ip_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        // $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $ip = isset($args['ip']) ? $args['ip']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $type = isset($args['type']) ? $args['type']: ''; //1:白名单 2:黑名单
        $expire_time = isset($args['expire_time']) ? $args['expire_time']: null;
        $remark = isset($args['remark']) ? $args['remark']: '';
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->add_ip($ip,$type,$expire_time,$remark,$created_at,$updated_at,$site_id);
        }else{
            //修改
            $this->Config_model->edit_ip($ip,$type,$expire_time,$remark,$updated_at,$id,$site_id);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }

    public function ip_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->ip_delete($id,$time);
    }



    public function advert_place_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("advert_place.*,b_site.name as site_name")
            ->join('b_site','b_site.id=advert_place.site_id','left')
            ->where('advert_place.deleted_at is null')
            ->from('advert_place');

        if($site_id!='') $object =$this->db->where('advert_place.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function advert_place_list_count($site_id)
    {
        $object = $this->db->select("advert_place.id")
            ->join('b_site','b_site.id=advert_place.site_id','left')
            ->where('advert_place.deleted_at is null')
            ->from('advert_place');

        if($site_id!='') $object =$this->db->where('advert_place.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function advert_place_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $title = isset($args['title']) ? $args['title']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $img = isset($args['img']) ? $args['img']: ''; 
        $url = isset($args['url']) ? $args['url']: null;
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->advert_place_add($title,$site_id,$img,$url,$created_at,$updated_at);
        }else{
            //修改
            $this->Config_model->advert_place_edit($title,$site_id,$img,$url,$updated_at,$id);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }

    public function advert_place_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->advert_place_delete($id,$time);
    }

    public function advert_place_updown($args)
    {
        return $this->Config_model->advert_place_updown($args['id'],$args['status']);
    }



    public function fingerpost_list($offset,$limit,$site_id)
    {
        $object = $this->db->select("fingerpost.*,b_site.name as site_name")
            ->join('b_site','b_site.id=fingerpost.site_id','left')
            ->where('fingerpost.deleted_at is null')
            ->from('fingerpost');

        if($site_id!='') $object =$this->db->where('fingerpost.site_id = ',$site_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        foreach ($list as &$value) {
            $value['video'] = $value['vedio'];
        }
        return $list;
    }

    public function fingerpost_list_count($site_id)
    {
        $object = $this->db->select("fingerpost.id")
            ->join('b_site','b_site.id=fingerpost.site_id','left')
            ->where('fingerpost.deleted_at is null')
            ->from('fingerpost');

        if($site_id!='') $object =$this->db->where('fingerpost.site_id = ',$site_id);
        return $this->db->count_all_results();
    }

    public function fingerpost_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $title = isset($args['title']) ? $args['title']: '';
        $desc = isset($args['desc']) ? $args['desc']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $img = isset($args['img']) ? $args['img']: ''; 
        $vedio = isset($args['video']) ? $args['video']: null;
        $order = isset($args['order']) ? $args['order']: null;
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->fingerpost_add($title,$desc,$site_id,$img,$vedio,$order,$created_at,$updated_at);
        }else{
            //修改
            $this->Config_model->fingerpost_edit($title,$desc,$site_id,$img,$vedio,$order,$updated_at,$id);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }

        return true;
    }

    public function fingerpost_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->fingerpost_delete($id,$time);
    }

    public function fingerpost_updown($args)
    {
        return $this->Config_model->fingerpost_updown($args['id'],$args['status']);
    }


    public function news_content_list($offset,$limit,$news_id)
    {
        $object = $this->db->select("b_news_content.*")
            ->where('b_news_content.deleted_at is null')
            ->from('b_news_content');
        if($news_id!='') $object =$this->db->where('b_news_content.news_id = ',$news_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function news_content_list_count($news_id)
    {
        $object = $this->db->select("b_news_content.*")
            ->where('b_news_content.deleted_at is null')
            ->from('b_news_content');
        if($news_id!='') $object =$this->db->where('b_news_content.news_id = ',$news_id);
        return $this->db->count_all_results();
    }
    //资讯多语言内容新增
    public function news_content_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $title = isset($args['title']) ? $args['title']: '';
        $resume = isset($args['resume']) ? $args['resume']: '';
        $news_id = isset($args['news_id']) ? $args['news_id']: '';
        $lang = isset($args['lang']) ? $args['lang']: '';
        $content = isset($args['content']) ? $args['content']: '';
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->add_news_content($title,$news_id,$content,$created_at,$updated_at,$lang,$resume);
        }else{
            //修改
            $this->Config_model->edit_news_content($title,$news_id,$content,$updated_at,$id,$lang,$resume);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
        return true;
    }

    public function news_content_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->news_content_delete($id,$time);
    }



    public function help_content_list($offset,$limit,$help_id)
    {
        $object = $this->db->select("b_help_content.*")
            ->where('b_help_content.deleted_at is null')
            ->from('b_help_content');
        if($help_id!='') $object =$this->db->where('b_help_content.help_id = ',$help_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function help_content_list_count($help_id)
    {
        $object = $this->db->select("b_help_content.*")
            ->where('b_help_content.deleted_at is null')
            ->from('b_help_content');
        if($help_id!='') $object =$this->db->where('b_help_content.help_id = ',$help_id);
        return $this->db->count_all_results();
    }


    public function help_content_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $title = isset($args['title']) ? $args['title']: '';
        $help_id = isset($args['help_id']) ? $args['help_id']: '';
        $lang = isset($args['lang']) ? $args['lang']: '';
        $content = isset($args['content']) ? $args['content']: '';
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->add_help_content($title,$help_id,$content,$created_at,$updated_at,$lang);
        }else{
            //修改
            $this->Config_model->edit_help_content($title,$help_id,$content,$updated_at,$id,$lang);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
        return true;
    }


    public function help_content_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->help_content_delete($id,$time);
    }



    public function help_class_content_list($offset,$limit,$help_class_id)
    {
        $object = $this->db->select("b_help_class_content.*")
            ->where('b_help_class_content.deleted_at is null')
            ->from('b_help_class_content');
        if($help_class_id!='') $object =$this->db->where('b_help_class_content.help_class_id = ',$help_class_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function help_class_content_list_count($help_class_id)
    {
        $object = $this->db->select("b_help_class_content.*")
            ->where('b_help_class_content.deleted_at is null')
            ->from('b_help_class_content');
        if($help_class_id!='') $object =$this->db->where('b_help_class_content.help_class_id = ',$help_class_id);
        return $this->db->count_all_results();
    }

    public function help_class_content_add($args)
    {
        $id = isset($args['id']) ? $args['id']: '';
        $name = isset($args['name']) ? $args['name']: '';
        $help_class_id = isset($args['help_class_id']) ? $args['help_class_id']: '';
        $lang = isset($args['lang']) ? $args['lang']: 'z-hans'; //默认中文简体
        $display_order = isset($args['display_order']) ? $args['display_order']: '';
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

        $this->db->trans_begin();

        if(!$id){
            //新增
            $this->Config_model->add_help_class_content($name,$help_class_id,$lang,$display_order,$created_at,$updated_at);
        }else{
            //修改
            $this->Config_model->edit_help_class_content($name,$help_class_id,$lang,$display_order,$updated_at,$id);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
        return true;
    }


    public function help_class_content_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->help_class_content_delete($id,$time);
    }


    public function inviteconfig_used($args)
    {
        $this->db->trans_begin();
        //获取当前的配置信息
        $detail = $this->Config_model->get_inviteimg_info($args['id']);
        //将当前站点的is_used全部改为0 ，当前的id 除外
        $this->Config_model->is_used($detail['site_id'],$args['id']);
        $this->Config_model->is_used_byid($args['id']);

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    public function admin_whiteip_list($offset,$limit,$admin_id)
    {
        $object = $this->db->select("admin_white_ip.*")
            ->where('admin_white_ip.deleted_at is null')
            ->from('admin_white_ip');
        if($admin_id!='') $object =$this->db->where('admin_white_ip.admin_id = ',$admin_id);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function admin_whiteip_list_count($admin_id)
    {
        $object = $this->db->select("admin_white_ip.*")
        ->where('admin_white_ip.deleted_at is null')
        ->from('admin_white_ip');
        if($admin_id!='') $object =$this->db->where('admin_white_ip.admin_id = ',$admin_id);
        return $this->db->count_all_results();
    }

    public function admin_whiteip_add($args)
    {
        $admin_id= isset($args['admin_id']) ? $args['admin_id']: '';
        $id= isset($args['id']) ? $args['id']: '';
        $ip = isset($args['ip']) ? $args['ip']: '';
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $updated_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);


        $this->db->trans_begin();
        if(!$id){
            //新增
            //判断是否已经存在当前这个admin_id
            $is_true = $this->Config_model->is_adminid_true($admin_id);
            if(count($is_true)>=1) returnJson('402','admin_id already exit');
            $this->Config_model->admin_whiteip_add($admin_id,$ip,$created_at,$updated_at);
        }else{
            //修改
            $this->Config_model->admin_whiteip_edit($admin_id,$ip,$updated_at,$id);
        }

        $trans_status = $this->db->trans_status();
        if ($trans_status === false) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
        return true;
    }

    public function admin_whiteip_delete($args)
    {
        $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $id = isset($args['id']) ? $args['id']: '';
        return $this->Config_model->admin_whiteip_delete($id,$time);
    }


    /**
     * Notes: APP上传列表
     * User: 张哲
     * Date: 2019-08-12
     * Time: 13:41
     */
    public function appConfigList($offset,$limit,$type)
    {
        $object = $this->db->select("b_app_version_new.*")
            ->from('b_app_version_new');
        if($type!='') $object =$this->db->where('b_app_version_new.device_id = ',$type);
        $list = $object->limit($limit,$offset)->order_by('created_at','desc')->get()->result_array();
        return $list;
    }

    public function appConfigListCount($type)
    {
        $object = $this->db->select("b_app_version_new.*")
            ->from('b_app_version_new');
        if($type!='') $object =$this->db->where('b_app_version_new.device_id = ',$type);
        return $this->db->count_all_results();
    }


    /**
     * Notes: 下载列表
     * User: 张哲
     * Date: 2019-08-12
     * Time: 13:57
     */
    public function appDownloadDetails($offset,$limit,$type)
    {
        $object = $this->db->select("b_app_version_new.*")
            ->from('b_app_version_new');
        if($type!='') $object =$this->db->where('b_app_version_new.device_id = ',$type);
        $list = $object->limit($limit,$offset)->order_by('created_at','asc')->get()->result_array();
        return $list;
    }

    public function appDownloadDetailsCount($type)
    {
        $object = $this->db->select("b_app_version_new.*")
            ->from('b_app_version_new');
        if($type!='') $object =$this->db->where('b_app_version_new.device_id = ',$type);
        return $this->db->count_all_results();
    }


}