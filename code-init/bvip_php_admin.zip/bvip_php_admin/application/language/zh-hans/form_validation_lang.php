<?php

$lang['form_validation_required']			= "{field}必须填写";
$lang['form_validation_isset']				= "{field}值未设置";
$lang['form_validation_valid_email']		= "{field}格式无效";
$lang['form_validation_valid_emails']		= "{field}必须包含全部正确的邮箱地址";
$lang['form_validation_valid_url']			= "{field}不是有效的URL地址";
$lang['form_validation_valid_ip']			= "{field}不是有效的IP地址";
$lang['form_validation_valid_seccode']		= "{field}验证错误";
$lang['form_validation_valid_ga']			= "{field}验证错误";
$lang['form_validation_valid_tp']			= "{field}验证错误";
$lang['form_validation_valid_sms']			= "{field}验证错误";
$lang['form_validation_valid_pwd']			= "{field}验证错误";
$lang['form_validation_valid_stronger']		= "{field}不够强壮";
$lang['form_validation_min_length']			= "{field}长度不能少于{param}位";
$lang['form_validation_max_length']			= "{field}长度不能大于{param}位";
$lang['form_validation_in']					= "{field}不在指定的参数内";
$lang['form_validation_exact_length']		= "{field}长度必须为{param}位";
$lang['form_validation_alpha']				= "{field}只能含有字母";
$lang['form_validation_alpha_numeric']		= "{field}只能含有字母和数字";
$lang['form_validation_alpha_dash']			= "{field}只能含有字母、数字和标点符号";
$lang['form_validation_numeric']			= "{field}只能含有数字";
$lang['form_validation_is_numeric']			= "{field}只能含有数字";
$lang['form_validation_is_string']			= "{field}只能是字符串";
$lang['form_validation_integer']			= "{field}需为整数";
$lang['form_validation_regex_match']		= "{field}格式不正确";
$lang['form_validation_matches']			= "{field}与{param}不匹配";
$lang['form_validation_is_unique'] 			= "{field}已经存在";
$lang['form_validation_is_natural']			= "{field}必须为大于等于0的整数";
$lang['form_validation_is_natural_no_zero']	= "{field}必须为大于0的整数";
$lang['form_validation_decimal']			= "{field}必须为一个浮点数";
$lang['form_validation_less_than']			= "{field}必须小于{param}";
$lang['form_validation_greater_than']		= "{field}必须大于{param}";


/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */