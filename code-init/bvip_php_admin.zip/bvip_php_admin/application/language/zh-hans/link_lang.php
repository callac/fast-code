<?php

#语言种类
$lang['category'] = "simplified-chinese";

#底部
$lang['footer_matter'] = "images/matter.png";

#首页banner图片
$lang['homepage_banner_1'] = "images/banner_1.jpg";
$lang['homepage_banner_2'] = "images/banner_2.jpg";
$lang['homepage_banner_3'] = "images/banner_3.jpg";
$lang['homepage_banner_4'] = "images/banner_4.jpg";