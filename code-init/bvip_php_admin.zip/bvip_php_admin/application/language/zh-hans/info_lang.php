<?php

$lang['threeday_more'] ='不能超出三天';
$lang['zjys_statistics_users_task'] ='zjys_statistics_users_task';
$lang['unopen_site'] ='我们暂未开启此站点，请您耐心等待';
$lang['close_site'] ='该站已被关闭，不可访问';
$lang['balance_low'] = '账户余额不足';
$lang['cancel_order_failed'] = '撤单失败';
$lang['cancel_order_success'] = '撤单成功';
$lang['operation_successful'] = '操作成功';
$lang['operation_failed'] = '操作失败';
$lang['missing_parameters'] = '参数缺失';
$lang['The original password is not fought for'] = '原始密码不正确';
$lang['The passwords don‘t match twice'] = '两次密码不一致';

//登录
$lang['registered'] = '已注册';
$lang['unregistered'] = '未注册';
$lang['token_valid'] = 'token有效';
$lang['token_failed'] = 'token失效';
$lang['user_exist'] = '用户不存在';//用户不存在
$lang['password_error'] = '密码错误';//密码错误
$lang['email_exist'] = '邮箱不存在';//邮箱不存在
$lang['email_isset'] = '邮箱已被注册';//邮箱已被注册
$lang['register_failed'] = '注册失败';//注册失败
$lang['mobile_isset'] = '手机号已被注册';//手机号已被注册
$lang['mobile_exist'] = '手机号不存在';//手机号不存在
$lang['not_authority'] = '没有权限';  //没有权限
$lang['mobile_preg_match'] = '手机号校验失败';
$lang['SMS'] = '发送验证码';
$lang['double_email'] = '该邮箱已经绑定';
$lang['double_mobile'] = '该手机号已经绑定';
//登录模块提示语  2019-03-18
$lang['username or password error'] = '用户名或密码错误';
$lang['code error'] = '验证码错误';
$lang['more than five minutes, please resend'] = '超过五分钟，请重新发送';
$lang['The account and contact information you entered do not match. Please check and re-enter'] = '您输入的账号和联系方式不匹配，请检查后重新输入';
$lang['Your login has expired, please log in again'] = '您的登录已过期，请重新登录';

$lang['There are too many failures, please contact the administrator'] = '失败次数太多，请联系管理员';
$lang['modify_frequency'] = '管理员登录解锁';
$lang['Too many login failures, the account has been frozen, please contact the site administrator'] = '登录失败过多，账号已冻结，请联系站点总管理员处理';
$lang['code is use'] = '验证码已经被使用';
$lang['The username you entered is incorrect. Please re-enter'] = '您输入的用户名错误，请重新输入';
$lang['forbid login'] = '您已被禁止登陆，请联系管理员';

$lang['message incorrect. Please re-enter'] = '信息输入有误，请重新输入';

//订单 order_hash
$lang['order_generation_failed'] = '订单生成失败';
//撤销订单 2019-01-10
$lang['cancel_order_record_list'] = '撤销订单列表';
$lang['cancel_order_record_list1'] = '撤销订单单个用户列表';
$lang['bid_buy'] = 'BID买入';
$lang['ask_sale'] = 'ASK卖出';
$lang['limit_price'] = '限价';
$lang['market_price'] = '市价';


//购买 product_hash
$lang['buy_success'] = '购买成功';
$lang['buy_failure'] = '购买失败';

//注册 register
$lang['send_success'] = '发送成功';
$lang['send_failure'] = '发送失败';
/**
 * 个人中心
 */
//消息
$lang['data_success'] = '返回数据成功';

$lang['income_invest'] = '邀请收益';
$lang['freeze_withdraw'] = '对不起，您暂时不能提现';
$lang['withdraw_amount'] = '提现数额应该大于最小提现额度';

//设置
$lang['address_save'] = '该地址已保存，无需重复提交';
$lang['address_save_success'] = '地址保存成功';
$lang['original_password_error'] = '原密码错误';
$lang['password_same'] = '新密码与原密码相同';
$lang['modify_define'] = '修改失败';


$lang['being_check'] = '正在审核';
$lang['being_do'] = '正在处理';
$lang['have_finsh'] = '已完成';
$lang['have_cancel'] = '已取消';

// $lang['truename_error01'] = '您已经提交，无需重复提交';
// $lang['truename_error02'] = '您已实名通过，无需重复提交';

// $lang['bankcard_error01'] = '未实名，请先实名，然后绑定银行卡';
// $lang['bankcard_error02'] = '您已绑定银行卡，无需重复提交';
// $lang['bankcard_error03'] = '未绑定银行卡，无法提现';

// $lang['postaddr_error01'] = '绑定数量超过限制，请您删除后重新添加';


//充值、提现、提币 字段中文对照
//充值
// $lang['top-up_success'] = '充值成功';
// $lang['top-up_success_text2_for_bankcard'] = '恭喜您，您通过支付宝充值的 ¥';
// $lang['top-up_success_text1_for_bankcard'] = '恭喜您，您通过银行卡充值的 ¥';
// $lang['top-up_success_text2'] = '已到账，当前账户可用余额';
// $lang['top-up_fail'] = '充值失败';
// $lang['top-up_fail_text1_for_bankcard'] = '非常遗憾的通知您，您提交的 ¥';
// $lang['top-up_fail_text2_for_alipay'] = '非常遗憾的通知您，您提交的 ¥';
// $lang['top-up_fail_text2'] = '充值申请，充值失败，请您仔细确认后再次提交申请，如有疑问，请联系客服';
// //提现
// $lang['catital_success'] = '提现成功';
// $lang['catital_success_text1'] = '恭喜您，您申请提现的¥ ';
// $lang['catital_success_text2'] = '已通过，注意查收您的银行卡账户';
// $lang['catital_fail'] = '提现失败';
// $lang['catital_fail_text1'] = '非常遗憾的通知您，您提交的 ¥ ';
// $lang['catital_fail_text2'] = '提现申请，提现失败，请您仔细确认后再次提交申请，如有疑问，请联系客服';
// //提币
// $lang['withdraw_success'] = '提币成功';
// $lang['withdraw_success_text1'] = '恭喜您，您申请的';
// $lang['withdraw_success_text2'] = '提币申请，已通过审核，具体到账时间根据区块拥堵程度，可能会有延迟';
// $lang['withdraw_fail'] = '提币失败';
// $lang['withdraw_fail_text1'] = '非常遗憾的通知您，您提交的';
// $lang['withdraw_fail_text2'] = '提币申请，未通过审核。请您仔细确认后再次提交申请，如有疑问，请联系客服';

//货币单位
$lang['yuan'] = '元';//元
$lang['mei_yuan'] = '美元';//美元
$lang['ri_yuan'] = '日元';//日元

//权限名称对照表
$lang['account_d'] = '操作日志列表';
$lang['account_j'] = '退出登录';//

$lang['config_a'] = '参数管理--列表';//
$lang['config_b'] = '参数管理--编辑/新增';//
$lang['config_c'] = '参数管理--删除';//
$lang['config_d'] = '版本管理--列表';//
$lang['config_e'] = '版本管理--删除';//
$lang['config_f'] = '版本管理--新增/编辑';//
$lang['config_g'] = '资讯类型';//
$lang['config_h'] = '关于我们--更新/新增';//
$lang['config_i'] = '关于我们--删除';//
$lang['config_j'] = '新闻资讯分类--列表';//
$lang['config_k'] = '新闻资讯分类--删除';//
$lang['config_l'] = '新闻资讯分类--新增/编辑';//

$lang['operation_a'] = '资讯管理--编辑';//
$lang['operation_b'] = '资讯管理--列表';//
$lang['operation_c'] = '资讯管理--删除';//
$lang['operation_d'] = '资讯管理--新增';//
$lang['operation_e'] = 'BDC管理--列表';//
$lang['operation_f'] = 'BDC管理--删除';//
$lang['operation_g'] = 'BDC管理--新增/编辑';//
$lang['operation_h'] = '帮助中心管理--列表';//
$lang['operation_i'] = '帮助中心管理--删除';//
$lang['operation_j'] = '帮助中心管理--新增/编辑';//
$lang['operation_k'] = '帮助中心管理--类型';//
$lang['operation_l'] = 'banner管理--列表';//
$lang['operation_m'] = 'banner管理--删除';//
$lang['operation_n'] = 'banner管理--新增/编辑';//
// $lang['operation_o'] = '友情链接--新增/编辑';//

$lang['site_a'] = '获取子站基础信息';//
$lang['site_b'] = '子站管理-新增';//
$lang['site_c'] = '子站管理-列表';//
$lang['site_d'] = '子站管理-更新';//
$lang['site_e'] = '新增域名';//
$lang['site_f'] = '编辑域名';//
$lang['site_g'] = '删除域名';//
$lang['site_h'] = '获取站点信息列表';//
$lang['site_i'] = '关闭/开启 站点';//
$lang['site_j'] = '配置基础信息列表';//
$lang['site_k'] = '子站管理-删除';//


//权限管理
$lang['roles_a'] = '获取部门或岗位信息';//
$lang['roles_b'] = '更新或新增 部门/岗位信息';//
$lang['roles_c'] = '岗位/部门权限列表';//
$lang['roles_d'] = '管理员列表';//
$lang['roles_e'] = '管理员 禁用/启用';//
$lang['roles_f'] = '管理员 新增/编辑';//
$lang['roles_g'] = '管理员删除';//
$lang['roles_h'] = '登陆';//
$lang['roles_i'] = '管理员修改密码';//
$lang['roles_j'] = '更新权限';//
$lang['roles_k'] = '根据站点获取部门/岗位';//
$lang['roles_l'] = '删除部门/岗位';//






//交易所
$lang['update_repeat'] = '法币买入接口调用balance.update时id重复调用了';

$lang['jys_user_list'] = '用户列表接口';
$lang['jys_reset_password'] = '重置用户登录、资金密码';
$lang['jys_recharge_log_list'] = '充值记录列表';
$lang['jys_withdraw_list'] = '提现记录';
$lang['jys_valids_list'] = '验证码记录';
$lang['jys_withdraw_verify'] = '提币初次审核';
$lang['jys_withdraw_sure_verify'] = '提币再次审核';
$lang['jys_withdraw_failure'] = '将提现审核成功的手动设置成失败';
$lang['jys_withdraw_address_list'] = '提币地址列表';
$lang['jys_asset_list'] = '币资产管理';
$lang['jys_add_asset'] = '增加/编辑资产种类';
$lang['jys_symbol_list'] = '交易对列表';
$lang['jys_add_symbol'] = '增加/编辑交易对';
$lang['jys_user_totalassets'] = '用户资产';
$lang['jys_user_totalassets_all'] = '用户资产全部';
$lang['jys_user_assetsdetail'] = '用户资金明细';
$lang['jys_user_assetsdetail_all'] = '用户资金明细全部';
$lang['jys_user_assetsflow'] = '用户资产流水';
$lang['jys_user_dealrecords'] = '用户成交记录';
$lang['jys_user_entrustedrecords'] = '用户委托记录';
$lang['jys_merchantbank_list'] = '银行卡配置';
$lang['jys_merchantbank_add'] = '银行卡新增与编辑';
$lang['jys_add_admin_merbank_inout_flows'] = '添加/编辑财务进出帐记录';
$lang['jys_add_admin_merbank_inout_list'] = '财务进出帐记录列表';
$lang['jys_c2c_inout'] = 'C2C买入卖出列表';
$lang['jys_c2c_verify'] = '后台法币买入卖出审核';
$lang['jys_c2c_verify_first'] = '后台法币买入卖出初次审核';
$lang['jys_userbank_list'] = '后台用户银行卡列表';
$lang['jys_merchantbank'] = '禁用/启用银行卡';
$lang['jys_unfreezeip'] = '解冻ip';
$lang['jys_activity_info'] = '获取活动详情';
$lang['jys_activity_list'] = '活动列表';
$lang['jys_activity_add'] = '添加活动';
$lang['jys_activity_delete'] = '删除活动';
$lang['jys_trade_totalcount'] = '市场交易量排行';
$lang['jys_trade_totalfee'] = '市场交易手续费排行';
$lang['jys_upload_img'] = '上传文件';
$lang['jys_subsite_list'] = '子站列表';
$lang['jys_subsite_addsadmin'] = '添加/编辑子站超管';
$lang['jys_subsite_sadminlist'] = '子站超管列表';
$lang['jys_subsite_user_statistics'] = '子站用户统计';
$lang['jys_subsite_trade_statistics'] = '子站交易统计';

$lang['config_agreement_update'] = '新增/编辑基本设置';
$lang['config_agreement_list'] = '基本设置列表';
$lang['config_agreement_delete'] = '删除基本设置';
$lang['config_friendlink_update'] = '新增/编辑友情链接';
$lang['config_friendlink_list'] = '友情链接列表';
$lang['config_friendlink_delete'] = '删除友情链接';

$lang['jys_edit_updateusermoney'] = '调整用户资金';
$lang['jys_admin_unfreeze_asset'] = '调整用户解冻币资产';

$lang['jys_user_identity'] = '用户认证信息列表';
$lang['jys_useridentity_reset'] = '用户认证重置';
$lang['jys_recharge_address_list'] = '用户充值地址列表';
$lang['jys_user_safeinfo'] = '用户安全信息列表';
$lang['jys_user_editphoneemail'] = '编辑用户邮箱验证码';
$lang['jys_user_reset_two_step'] = '重置谷歌验证器';
$lang['jys_user_correctassetitem'] = '调整用户资金列表';
$lang['jys_user_correctassetitem_csv'] = '调整用户资金列表导出';
$lang['jys_vip_list'] = 'vip等级管理列表';
$lang['jys_vip_edit'] = '新增/编辑vip等级信息';
$lang['jys_vip_adduser'] = '添加vip账户';
$lang['jys_user_forbidden_login'] = '禁止账户登陆';
$lang['jys_user_forbidden_withdraw'] = '禁止账户提现';
$lang['jys_user_forbidden_trade'] = '禁止账户交易';

$lang['jys_timetask_totalsiteassets'] = '站点资产统计列表';
$lang['jys_user_get_info'] = '用户详情';
$lang['jys_withdraw_address_user_list'] = '用户提币地址';
$lang['jys_withdraw_address_user_logs'] = '用户提币记录';
$lang['jys_recharge_address_user_list'] = '用户充币地址';
$lang['jys_recharge_address_user_logs'] = '用户充值记录';

$lang['jys_get_userbank'] = '指定用户的银行卡列表';
$lang['jys_params_config_c2c'] = 'c2c参数设置列表';
$lang['jys_params_config_c2c_update'] = 'c2c参数设置新增/编辑';
// $lang['jys_get_intotal'] = '银行卡收支';
// $lang['jys_get_outtotal'] = '获取c2c卖出对账';
$lang['jys_total_c2c'] = 'c2c对账';
$lang['jys_get_c2cwithdraw_freeze'] = '获取c2c、提现冻结';
$lang['jys_get_trade_freeze'] = '获取平台币种的交易冻结';
$lang['zjys_wallet_request_logs'] = '钱包请求日志';
$lang['jys_get_bank_statistic'] = '平台单卡统计买入卖出的应收和应支';
$lang['jys_get_bank_statistic_reality'] = '平台单卡统计买入卖出的实收和实支';
$lang['jys_get_platform_deal'] = '平台成交记录（截止24小时前）';
$lang['jys_get_platform_deal_printcsv'] = '平台成交记录（指定条件）导出csv文件';
$lang['jys_get_platform_order'] = '平台的委托记录';
$lang['jys_get_platform_order_printcsv'] = '平台委托记录导出';
$lang['zjys_print_user_assets'] = '分页导出用户资产';
$lang['zjys_print_user_assets_all'] = '分页导出用户资产全部';
$lang['jys_c2c_printexcel'] = 'C2C买入卖出导出Excel';
$lang['jys_withdraw_printexcel'] = '提现管理导出Excel';
$lang['jys_recharge_printexcel'] = '充值管理导出Excel';

$lang['jys_user_statistics'] = '用户统计';
$lang['jys_merchant_inout_list_printexcel'] = '平台卡明细导出';
$lang['jys_statistics_users_printexcel'] = '用户统计导出';
$lang['jys_statistics_c2c_inout'] = '法币统计';
$lang['jys_statistics_c2c_inout_printexcel'] = '法币统计导出';
$lang['operation_k'] = '帮助分类列表';
$lang['operation_kadd'] = '帮助分类新增/编辑';
$lang['operation_kdelete'] = '帮助分类删除';
$lang['jys_get_trade_statistic'] = '交易统计列表';
$lang['jys_get_trade_statistic_print'] = '交易统计列表导出';

$lang['config_appconfig_list'] = 'app更新配置列表';
$lang['config_appconfig_add'] = 'app更新配置添加/更新';
$lang['config_appconfig_delete'] = 'app更新配置删除';

$lang['jys_lockposition_list'] = '锁仓列表';
$lang['jys_lockposition_add'] = '锁仓新增/编辑';
$lang['jys_lockposition_delete'] = '锁仓删除';
$lang['jys_unlockposition'] = '手动解仓';

$lang['config_labelconfiglist'] = '导航栏配置列表';
$lang['config_labelconfigadd'] = '添加/编辑导航栏配置';
$lang['config_labelconfigdelete'] = '导航栏删除';

$lang['jys_activityholding_list'] = '持仓活动列表';
$lang['jys_activityholding_add'] = '持仓活动新增/编辑';
$lang['jys_activityholding_delete'] = '持仓活动删除';
$lang['jys_activityholdingaward_list'] = '持仓活动奖励列表';
$lang['jys_user_lottery_logs'] = '抽奖活动列表';
$lang['jys_user_treasure_logs'] = '夺宝活动用户夺宝列表';
$lang['jys_treasure_sessions'] = '夺宝活动场次信息列表';

$lang['jys_activity_treasurelist'] = '夺宝-配置列表';
$lang['jys_activity_treasureadd'] = '夺宝-活动配置添加/编辑';
$lang['jys_activity_treasuredelete'] = '夺宝-删除';
$lang['jys_activity_treasurenext'] = '夺宝-开启下一场';
$lang['jys_activity_treasureend'] = '夺宝-结束';
$lang['jys_activity_treasure_session_list'] = '夺宝-往期记录列表';
$lang['jys_activity_treasure_logs_list'] = '夺宝-中奖信息';

$lang['new_year_add'] = '新年活动-新增';
$lang['new_year_pool_balance'] = '新年活动-调整奖池金额';
$lang['new_year_state'] = '新年活动-活动状态';
$lang['new_year_user_log'] = '新年活动-用户投奖记录';
$lang['new_year_pool_info'] = '新年活动-奖池信息';
$lang['new_year_pool_log'] = '新年活动-奖池调整日志';
/**
 * 2019-02-28  活动解锁
 */
$lang['activity_unlock'] = '活动解锁';
$lang['batch_activity_file'] = '活动批量解锁获取文件';
$lang['batch_activity_unlock'] = '活动批量解锁';
$lang['activity_unlock_list'] = '活动解锁列表';
$lang['activity_unlock_list_csv'] = '活动解锁列表导出';
$lang['activity_unlock_sample_csv'] = '活动解锁实例文件';
$lang['unlock successful'] = '解锁成功';
$lang['unlock failed'] = '解锁失败';
$lang['unlock money is not'] = '活动解锁余额不够';
$lang['unlock activity is not'] = '无该用户解锁数据';


$lang['jys_app_trade_config_list'] = 'api交易配置列表';
$lang['jys_app_trade_config_add'] = 'api交易配置添加';
$lang['jys_app_trade_config_delete'] = 'api交易配置删除';

$lang['jys_statistics_mail_config_list'] = '运营邮件配置列表';
$lang['jys_statistics_mail_config_add'] = '运营邮件配置新增/编辑';
$lang['jys_statistics_mail_config_delete'] = '运营邮件配置删除';
$lang['jys_statistics_mail_sent_records'] = '运营邮件发送记录';

$lang['jys_csv_insert_updatemoney'] = '导入csv文件批量调整用户资金';
$lang['jys_user_assetsflow_csv'] = '导出用户资产流水记录';
$lang['jys_activity_userawards'] = '活动的用户奖励列表';
$lang['jys_activity_award_priv'] = '基础活动奖励列表导出';
$lang['jys_user_identity_check'] = '用户认证审核';
$lang['jys_correct_identity_info'] = '手动修改认证信息';
$lang['jys_assetintro_list'] = '币种详情列表';
$lang['jys_assetintro_add'] = '币种详情增加/编辑';
$lang['jys_assetintro_del'] = '币种详情删除';

$lang['jys_symbolblock_list'] = '区块配置列表';
$lang['jys_symbolblock_add'] = '区块配置增加/编辑';
$lang['jys_symbolblock_del'] = '区块配置删除';

$lang['jys_smsconfig_list'] = '短信通道列表';
$lang['jys_smsconfig_add'] = '短信通道新增/编辑';
$lang['jys_smsconfig_del'] = '短信通道删除';
$lang['jys_smsconfig_used'] = '启用短信通道';

$lang['jys_emailconfig_list'] = '邮件通道列表';
$lang['jys_emailconfig_add'] = '邮件通道新增/编辑';
$lang['jys_emailconfig_del'] = '邮件通道删除';
$lang['jys_emailconfig_used'] = '启用邮件通道';

$lang['jys_inviteconfig_list'] = '邀请好友配置列表';
$lang['jys_inviteconfig_add'] = '邀请好友配置新增/编辑';
$lang['jys_inviteconfig_del'] = '邀请好友配置删除';
$lang['jys_inviteconfig_used'] = '启用邀请好友配置';

$lang['jys_ip_list'] = 'ip黑白名单列表';
$lang['jys_ip_add'] = 'ip黑白名单添加';
$lang['jys_ip_del'] = 'ip黑白名单删除';

$lang['config_news_content_list'] = '资讯多语言内容列表';
$lang['config_news_content_add'] = '资讯多语言内容新增/编辑';
$lang['config_news_content_delete'] = '资讯多语言内容删除';


$lang['jys_platformAsset'] = '平台资产快照';
$lang['jys_platformAsset_csv'] = '平台资产快照导出';
$lang['jys_checkaccount'] = '平台对账';
$lang['jys_checkaccount_csv'] = '平台对账导出';
$lang['jys_system_checkaccount'] = '系统内对账';
$lang['jys_system_checkaccount_csv'] = '系统内对账导出';

$lang['jys_cancel_order_single'] = '撤销单个订单';
$lang['jys_cancel_order_market'] = '撤销市场订单';
$lang['jys_cancel_order_user_market'] = '撤销指定用户市场订单';
$lang['jys_QueryWalletBalance'] = '查询币种钱包余额';

$lang['cardnumber_true'] = '该证件号已存在';


//风控管理
$lang['alarm'] = '风险控制';
$lang['symbols'] = '交易对';
$lang['transaction_alarm_list'] = '异常交易警报';
$lang['profit_loss_alarm_list'] = '异常盈亏监控';
$lang['account_alarm_list'] = '异常账目监控';
$lang['transaction_param'] = '获取异常交易参数设置';
$lang['account_param'] = '获取异常账目参数设置';
$lang['modify_transaction_param'] = '修改异常交易参数设置';
$lang['modify_account_param'] = '修改异常账目参数设置';
$lang['get_profit_param'] = '获取盈亏参数设置';
$lang['modify_profit_param'] = '修改盈亏参数设置';
$lang['add_target_roles'] = '增加和修改预警用户';
$lang['delete_target_roles'] = '删除预警用户';
$lang['target_people_list'] = '预警用户列表';
$lang['large_amount_list'] = '大额充提';
$lang['withdraws_wallet_list'] = '提币时间监控';
$lang['large_amount_deal'] = '大额充提处理';
$lang['withdraws_wallet_deal'] = '提币时间监控处理';
$lang['large_amount_par'] = '大额充提参数';
$lang['withdraws_wallet_par'] = '提币时间监控参数';
$lang['get_new_par'] = '获取当前配置参数';

//运营数据统计
$lang['asset_list'] = '去重数据';
$lang['asset_list_csv'] = '去重数据导出';
$lang['register_list'] = '注册数据';
$lang['register_list_csv'] = '注册数据导出';
$lang['recharge_list'] = '充值数据';
$lang['recharge_list_csv'] = '充值数据导出';
$lang['withdraws_list'] = '提现数据';
$lang['withdraws_list_csv'] = '提现数据导出';
$lang['c2cbuy_list'] = 'c2c买入数据';
$lang['c2cbuy_list_csv'] = 'c2c买入数据导出';
$lang['c2csell_list'] = 'c2c卖出数据';
$lang['c2csell_list_csv'] = 'c2c卖出数据导出';
$lang['cointrade_list'] = '币币交易数据';
$lang['cointrade_list_csv'] = '币币交易数据导出';
$lang['hold_coin_list'] = '持币占比数据';
$lang['hold_coin_csv'] = '持币占比数据导出';
$lang['deal_fee_platform'] = '平台手续费结算';

//白名单
$lang['user_white_list'] = '白名单列表';
$lang['user_white_add'] = '增加白名单';
$lang['user_white_delete'] = '删除白名单';
$lang['no_account'] = '无该账号';
$lang['account_exist'] = '该账号已存在';

$lang['jys_user_recommendlist'] = '用户邀请注册列表';
$lang['jys_user_recommendlist_csv'] = '用户邀请注册列表导出';
$lang['jys_get_user_recommend_statistic'] = '下载用户交易数据';
$lang['cancel_order_user_market'] = '撤销单个用户单个市场订单';


/**
 * 转账管理
 */
$lang['get_account_list'] = '账户列表';
$lang['add_account'] = '增加账户';
$lang['delete_account'] = '删除账户';
$lang['generate_total_account'] = '生成总账户';
$lang['total_account_assets'] = '总账户资产';
$lang['transfer_user_money'] = '转账';
$lang['check_balance'] = '查询用户余额';
$lang['transfer_list'] = '转账列表';
$lang['transfer_list_csv'] = '转账列表导出';
$lang['Transfer failed'] = '转账失败';
$lang['Transfer successful'] = '转账成功';
$lang['loan'] = '借款';
$lang['loan successful'] = '借款成功';
$lang['loan failed'] = '借款失败';
$lang['repayment'] = '还款';
$lang['repayment successful'] = '还款成功';
$lang['repayment failed'] = '还款失败';
$lang['loan_list'] = '借款列表';
$lang['repayment_list'] = '还款列表';
$lang['loan_list_csv'] = '借款导出';
$lang['repayment_list_csv'] = '还款导出';
$lang['transfer_out_uid not exist'] = '转出账户不存在';
$lang['transfer_in_uid not exist'] = '转入账户不存在';
$lang['user_id not exist'] = '账户不存在';
$lang['payer_id not exist'] = '转账用户不存在';
$lang['transfer_out_uid not asset'] = '账户没有该币种';
$lang['Insufficient balance'] = '账户余额不足';
$lang['Insufficient balance_all'] = '平台账户余额不足';
$lang['not total account'] = '该账户不是总账户';
$lang['can not'] = '还款数不能大于借款数减去已还款';
$lang['gift_coin_list'] = '赠币管理';
$lang['gift_coin_list_csv'] = '赠币管理导出';
$lang['gift_coin'] = '单个用户新增赠币';
$lang['batch_gift_coin'] = '批量用户新增赠币';
$lang['gift successful'] = '赠币成功';
$lang['gift failed'] = '赠币失败';
$lang['total_account_assets_csv'] = '总资产导出';
$lang['Account name already exists'] = '账户名称已存在';
$lang['Total account cannot be deleted'] = '总账户不可删除';
$lang['withdraws_alarm_list'] = '充提监控';
$lang['withdraws_alarm'] = 'withdraws_alarm';
$lang['address_alarm'] = 'address_alarm';
$lang['sys_service_wallet_recharge'] = 'sys_service_wallet_recharge';
$lang['zjys_get_trade_statistic'] = 'zjys_get_trade_statistic';
$lang['wallet_snapshot'] = 'wallet_snapshot';
$lang['deal_status'] = '处理充提';
$lang['not site_id account'] = '不是本站点账户';
$lang['not transfer account'] = '同一个账户不可转账';
$lang['add_total_account'] = '增加总账户';
$lang['add_asset_record'] = '增加总账户币种';
$lang['not edit'] = '不可编辑';
$lang['Already a general account'] = '该账户已经是总账户';
$lang['No address'] = '无地址';
$lang['repayment_address'] = '充值地址';
$lang['recharge_address_list'] = '充值重复地址列表';
$lang['address_deal_status'] = '充值地址状态处理';
$lang['batch_gift_file'] = '赠币文件';
$lang['not site_id account'] = '不是该站点账户';
$lang['site_id not totalaccount'] = '改站点没有总账户，请去创建';
$lang['not give it to yourself'] = '不能赠送给自己';
$lang['gift_sample_csv'] = '赠币示例导出';
$lang['loan_verity'] = '借款审核';
$lang['transfer_user_money_verity'] = '转账审核';
$lang['gift_coin_verity'] = '赠币审核';
$lang['batch_gift_coin_verity'] = '批量赠币审核';
$lang['submit success'] = '提交成功';


$lang['batch_user_file'] = '批量生成用户';
$lang['address is null'] = '地址为空';

$lang['account is exist'] = '该账户已存在';
$lang['address is failure'] = '生成地址失败或者该币种无法生成地址';

//钱包对账
$lang['wallet_snapshot_list'] = '钱包快照';
$lang['wallet_snapshot_list_csv'] = '钱包快照导出';
$lang['wallet_snapshot'] = 'wallet_snapshot';
$lang['wallet_snapshot_all'] = 'wallet_snapshot_all';
//充值
$lang['recharge_review'] = '充值审核';

$lang['workorders_list'] = '工单列表';
$lang['workorders_reply'] = '工单回复';
$lang['workorders_delete'] = '工单删除';
$lang['workorders_close'] = '工单关闭';
$lang['workorders_reply_list'] = '工单回复列表';

$lang['config_help_content_list'] = '帮助多语言内容配置列表';
$lang['config_help_content_add'] = '帮助多语言内容配置新增/编辑';
$lang['config_help_content_delete'] = '帮助多语言内容配置删除';

$lang['config_help_class_content_list'] = '帮助分类多语言内容配置列表';
$lang['config_help_class_content_add'] = '帮助分类多语言内容配置新增/编辑';
$lang['config_help_class_content_delete'] = '帮助分类多语言内容配置删除';

/**
 * 未定义语言
 */
$lang['jys_user_country'] = 'jys_user_country';
$lang['jys_asset_list_totalsite'] = 'jys_asset_list_totalsite';
$lang['jys_symbol_list_totalsite'] = 'jys_symbol_list_totalsite';
$lang['jys_list_ajaxsearch'] = 'jys_list_ajaxsearch';
$lang['jys_check_detail'] = 'jys_check_detail';
$lang['jys_sys_asset_list'] = 'jys_sys_asset_list';
$lang['jys_sys_asset_add'] = 'jys_sys_asset_add';
$lang['jys_sys_asset_delete'] = 'jys_sys_asset_delete';
$lang['jys_sys_symbol_list'] = 'jys_sys_symbol_list';
$lang['jys_sys_symbol_add'] = 'jys_sys_symbol_add';
$lang['jys_sys_symbol_delete'] = 'jys_sys_symbol_delete';
$lang['jys_check_detail'] = 'jys_check_detail';
$lang['symbolblock_list_list_noauth'] = 'symbolblock_list_list_noauth';
$lang['getdata_deduplication_data'] = 'getdata_deduplication_data';


/**
 * 数据可视化
 */

$lang['real_draw'] = '实时数据图表';
$lang['real_data'] = '实时数据';
$lang['user_data'] = '用户总览';
$lang['user_data_draw'] = '用户总览图表';
$lang['trade_data'] = '币币交易统计';
$lang['trade_data_draw'] = '币币交易图表';
$lang['trade_fee_data'] = '手续费统计';
$lang['trade_fee_data_draw'] = '手续费图表';
$lang['trade_c2c_data'] = 'C2C交易';
$lang['trade_c2c_data_draw'] = 'C2C交易图表';
$lang['withdraws_coin_rank'] = '提币排名';
$lang['recharge_coin_rank'] = '充币排名';
$lang['coin_details_data'] = '币种详情数据';
$lang['coin_details_fee_data'] = '币种详情手续费数据';
$lang['coin_details_trade_draw'] = '币种详情图表';
$lang['coin_details_fee_draw'] = '币种详情手续费图表';
$lang['coin_recharge_withdraws_data'] = '币种详情充提币';
$lang['coin_recharge_withdraws_draw'] = '币种详情充提币图表';
$lang['trade_money_rank'] = '交易金额排名';
$lang['trade_order_rank'] = '交易订单排名';
$lang['trade_user_rank'] = '交易用户排名';
$lang['asset_symbols'] = '获取交易对';
$lang['site_asset'] = '获取币种';
$lang['wait_review'] = '等待审核';

$lang['time is null'] = '锁仓时间为空';
$lang['recharge failure'] = '充值审核失败';


$lang['modify failure'] = '修改失败';

$lang['jys_statistics_asset_general'] = '用户币种概况';
$lang['jys_statistics_asset_general_form'] = '平台币种概况';

/**
 * OTC
 */
$lang['otc_inout'] = 'otc买入卖出列表';
$lang['inout_printexcel'] = 'otc买入卖出列表导出';
$lang['otc_verify_first'] = 'otc第一次审核';
$lang['c2c_verify'] = 'otc再次审核';
$lang['otc_user_account'] = 'otc用户收付款设置';
$lang['sort_value'] = '获取商家排序值';
$lang['mer_sort'] = '修改商家排序值';
$lang['modify_trade_count'] = '修改商家交易笔数';
$lang['modify_sort'] = '修改排序';
$lang['foreign_otc_transfers'] = '第三方转账记录表';
$lang['foreign_otc_transfers_export'] = '第三方转账记录表导出';
$lang['update_otc_assets'] = 'otc资产';



$lang['merchant_account_list'] = '商家列表';
$lang['merchant_account_add_edit'] = '商家新增和编辑';
$lang['merchant_account_delete'] = '商家启用与禁用';
$lang['otc_inout_add_edit'] = 'otc明细新增和编辑';
$lang['otc_inout_list'] = 'otc明细列表';
$lang['otc_inout_list_csv'] = 'otc明细列表导出';
$lang['mer_forbid'] = '该商户已被禁用';
$lang['first'] = '已经是最后一条了';
$lang['last'] = '已经第一条了';
$lang['snapshot_start_error'] = '期初时间的快照缺失';
$lang['snapshot_end_error'] = '期末时间的快照缺失';
$lang['snapshot_error'] = '资产快照非法';
$lang['snapshot_data_error'] = '快照数据非法';

$lang['trade_detail'] = '当天交易市场明细';

// 手续费结算（月结）
$lang['jys_settlement_list'] = '手续费结算列表';
$lang['jys_settlement_csv'] = '手续费结算列表导出';
$lang['jys_settlement'] = '手续费结算';
$lang['jys_perday_detail_list'] = '每日币种手续费明细';
$lang['jys_perday_detail_csv'] = '每日币种手续费明细导出';
$lang['jys_settlement_all'] = '批量结算';
$lang['jys_checkbalance'] = '校验用户资金';
$lang['jys_settlement_record_list'] = '结算记录列表';
$lang['jys_settlement_record_list_csv'] = '结算记录列表导出';

//手续费结算（日结）
$lang['jys_day_settlement_list'] = '（日结）手续费结算列表';
$lang['jys_day_settlement_csv'] = '（日结）手续费结算列表导出';
$lang['jys_day_settlement'] = '（日结）手续费结算';
$lang['jys_day_settlement_all'] = '（日结）手续费批量结算';
$lang['jys_day_settlement_record_list'] = '（日结）结算记录列表';
$lang['jys_day_settlement_record_list_csv'] = '（日结）结算记录列表导出';
//新增邀请关系
$lang['jys_add_recommend'] = '添加邀请关系';
$lang['zjys_resend_withdraw'] = '后台重新发起提币';


$lang['InOutMoneyQuery'] = '出入金查询';
$lang['symbols_price_list'] = '交易对0点币价';
$lang['symbols_price_csv'] = '交易对0点币价导出';

$lang['sys_key_log'] = '系统关键日志记录列表';

$lang['jys_amdin_whiteip_list'] = '后台管理员ip白名单列表';
$lang['jys_amdin_whiteip_add'] = '后台管理员ip白名单新增/编辑';
$lang['jys_amdin_whiteip_del'] = '后台管理员ip白名单删除';

$lang['transaction_number'] = '交易排名';

$lang['jys_websafe_login_logs'] = '客户端登录历史列表';
$lang['jys_websafe_operation_logs'] = '客户端操作历史列表';


//知识库
$lang['knowledge_base_list'] = '知识库列表';
$lang['knowledge_base_add'] = '知识库新增编辑';
$lang['knowledge_base_delete'] = '知识删除';

//push
$lang['push_list'] = '推送列表';
$lang['push_add'] = '推送新增编辑';
$lang['push_delete'] = '推送删除';
$lang['push'] = '推送';

$lang['platform_balacne_payment'] = '平台收支列表';
$lang['platform_balacne_payment_detail'] = '平台收支每日明细';

$lang['otc_transfer_list'] = 'otc转账记录列表';
$lang['otc_transfer_list_csv'] = 'otc转账记录导出';

$lang['jys_get_user_order'] = '用户所有委托订单';
$lang['jjys_get_user_order_printcsv'] = '用户所有委托订单导出';

$lang['zjys_withdraw_waitcheck_amount'] = '提币待审核等待数量';

$lang['Administrator change password self'] = '管理员自修改密码';
$lang['Old and new passwords should be inconsistent'] = '新旧密码应该不一致';



//new
$lang['appTradeDetails'] = 'API详情';

$lang['vipRecord'] = 'VIP记录';
$lang['vipAddEdit'] = 'VIP新增编辑';
$lang['vipAddEditVerity'] = 'VIP审核';

$lang['vipDelete'] = 'VIP删除';
$lang['systemAssetAddVerity'] = '系统资产配置审核';
$lang['systemAssetDetailsLogs'] = '系统资产操作日志';
$lang['systemSymbolAddVerity'] = '系统交易对配置审核';
$lang['systemSymbolDetailsLogs'] = '系统交易对操作日志';

$lang['tradeAmount'] = '交易额';
$lang['tradeZoneDetails'] = '交易区明细';
$lang['symbolDetails'] = '交易对明细';

$lang['addAppFile'] = '新增APP版本';
$lang['appConfigList'] = 'APP配置列表';
$lang['appDownloadDetails'] = 'APP下载列表';

$lang['jys_statistics_newaddasset_list'] = '新增资产统计列表详细';
$lang['jys_statistics_newaddasset_list_total'] = '新增资产统计列表累计';
$lang['jys_lockposition_check'] = '锁仓审核';
$lang['jys_unlockposition_check'] = '解仓审核';

$lang['update_money_apply_list'] = '调账申请列表';
$lang['update_money_apply'] = '调账申请';
$lang['update_money_check'] = '调账申请审核';
$lang['batch_updatemoney_apply'] = '批量调账申请';
$lang['batch_update_money_check'] = '批量调账申请审核';

$lang['advert_place_list'] = '广告位列表';
$lang['advert_place_add'] = '广告位新增/编辑';
$lang['advert_place_del'] = '广告位删除';
$lang['advert_place_updown'] = '广告位上下架';

$lang['fingerpost_list'] = '新手指南列表';
$lang['fingerpost_add'] = '新手指南添加';
$lang['fingerpost_del'] = '新手指南删除';
$lang['fingerpost_updown'] = '新手指南上下架';

$lang['appTradestatus'] = '用户api-key状态切换';

$lang['handrecharge_list'] = '手动充值列表';
$lang['handrecharge_add'] = '新增充值';
$lang['handrecharge_verify_first'] = '手动充值初审';
$lang['handrecharge_verify'] = '手动充值复审';
$lang['handrecharge_detail'] = '手动充值详情';







