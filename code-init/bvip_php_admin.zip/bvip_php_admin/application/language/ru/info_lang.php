<?php

#头部区域
$lang['header_login'] = "Login";
$lang['zjys_statistics_users_task'] ='zjys_statistics_users_task';
$lang['header_register'] = "Register";
$lang['header_logout'] = "Logout";
$lang['header_market'] = "Exchange";
$lang['header_order'] = "Order";
$lang['header_balance'] = "Balance";
$lang['header_setup'] = "Setup";
$lang['header_invitation'] = "Invite";
$lang['header_exchange'] = "Exchange";
$lang['header_income'] = "Profit";
$lang['header_help'] = "Help";
$lang['header_title'] = "51BTC - Digital Assets trading platform";
$lang['header_keywords'] = "51BTC,Digital assets, altcoin, altcoin exchange,bitcoin, litecoin, dogecoin";
$lang['header_description'] = "51BTC is an exchange platform for bitcoin and other digital assets, focusing on exchange of multiple digital assets. 51BTC strives to privide best diversified services in the industry for multiple digital assets exchange.";

#底部区域
$lang['footer_about_us'] = "About us";
$lang['footer_about_51btc'] = "About 51BTC";
$lang['footer_contact_us'] = "Contact us";
$lang['footer_help'] = "Help";
$lang['footer_faq'] = "FAQ";
$lang['footer_fee'] = "Fee";
$lang['footer_statement'] = "Statement";
$lang['footer_protocol'] = "Protocol";
$lang['footer_terms'] = "Terms";
$lang['footer_copyright'] = "Copyright";
$lang['footer_social_contact'] = "Social";
$lang['footer_weibo'] = "Weibo";
$lang['footer_qq_group'] = "QQ Group";
$lang['footer_counsel'] = "Counsel";
$lang['footer_counsel_detail'] = "ZHEJIANG KING CITY LAW FIRM";
$lang['footer_warning'] = "Digital Assets trading has high risk, global market, 24-hour trading, no price limits. Price of digital assets is easily affected by the policies of global government and is volatility depends on some breaking news. We strongly recommend that you participate in the digital assets trading within the scope of risk you can afford.";

#登录后首页
$lang['homepage_logged_in_hello'] = "Hello";
$lang['homepage_logged_in_logout'] = "Log out";
$lang['homepage_logged_in_balance'] = "Balance";
$lang['homepage_logged_in_available'] = "Available";
$lang['homepage_logged_in_held'] = "Frozen";
$lang['homepage_logged_in_value'] = "Value";

#首页
$lang['homepage_announcement'] = "Announcement";
$lang['homepage_more'] = "More";
$lang['homepage_login_51btc'] = "LOGIN";
$lang['homepage_have_no_account'] = "Have no account?";
$lang['homepage_register_now'] = "Register";
$lang['homepage_email'] = "Email";
$lang['homepage_go_to_market'] = "Market";
$lang['homepage_email_data_alert'] = "Please enter your valid address";
$lang['homepage_password'] = "Password";
$lang['homepage_password_data_alert'] = "Please enter your password";
$lang['homepage_forget_password'] = "Forgot your password?";
$lang['homepage_business_process'] = "51BTC Business Process";
$lang['homepage_register_or_login'] = "Register/Login 51BTC";
$lang['homepage_finish_profile'] = "Finish your profile";
$lang['homepage_trading'] = "Trading";
$lang['homepage_market_profile'] = "51BTC Market Overview";
$lang['homepage_exchange'] = "Exchange";
$lang['homepage_exchange_coin'] = "Coin";
$lang['homepage_price'] = "Price";
$lang['homepage_range'] = "Range";
$lang['homepage_24h_volume'] = "24H Volume";
$lang['homepage_24h_min_price'] = "24H Min Price";
$lang['homepage_24h_max_price'] = "24H Max Price";
$lang['homepage_bid_1'] = "Bid 1";
$lang['homepage_ask_1'] = "Ask 1";
$lang['homepage_professional'] = "Professional";
$lang['homepage_research'] = "Research";
$lang['homepage_justice'] = "Justice";
$lang['homepage_transparent'] = "Transparent";
$lang['homepage_Acme'] = "Acme";
$lang['homepage_simple'] = "Simple";
$lang['homepage_exclusive'] = "Exclusive";
$lang['homepage_silver_fish_shares_sfs'] = "Silver Fish Shares/SFS";

#common.js
$lang['common_info_title'] = "Information";
$lang['common_confirm'] = "OK";
$lang['common_close'] = "Close";

#注册页
$lang['register_title'] = "51BTC - Register";
$lang['register_verify'] = "Successfully verified, please login.";
$lang['register_account'] = "Register";
$lang['register_already_have'] = "Already have one";
$lang['register_login'] = "Login";
$lang['register_country'] = "Country";
$lang['register_email'] = "Email";
$lang['register_email_data_alert'] = "Please input a valid email address";
$lang['register_password'] = "Password";
$lang['register_at_least_8'] = "At least 8 characters, use letters or Numbers";
$lang['register_password_confirm'] = "Confirm password";
$lang['register_password_confirm_placeholder'] = "Please input your password again";
$lang['register_password_confirm_data_alert'] = "Please input the same password";
$lang['register_invitation_code'] = "invitation code";
$lang['register_input_code'] = "please input your invitation code";
$lang['register_get_code'] = "How to get an invitation code?";
$lang['register_verify_code'] = "Verification code";
$lang['register_input_verify_code'] = "Please input the verification code";
$lang['register_agree'] = "I have read and agree to ";
$lang['register_contact'] = "<<51BTC USER PROTOCOL>>";
$lang['register_button'] = "Register";
$lang['register_recommend'] = "It's strongly recommended that you use different account/password from other trading platforms.";
$lang['register_failed'] = "Failed, database error.";
$lang['register_success'] = "Successfully Registered";
$lang['register_success_info_1'] = "Registered Successfully!";
$lang['register_success_info_2'] = "Active link has been send to";
$lang['register_success_info_3'] = "Please check the email trash in case it's spammed.";
$lang['register_email_exist'] = "This email has already been registered!";

#登录页
$lang['login_title'] = "51BTC - LOGIN";
$lang['login_account'] = "LOGIN";
$lang['login_have_no_account'] = "Have no account?";
$lang['login_register_now'] = "Create one now!";
$lang['login_email'] = "Email";
$lang['login_input_email'] = "Please input your email";
$lang['login_input_email_data_alert'] = "Please input your valid email";
$lang['login_password'] = "Password";
$lang['login_input_password'] = "Please input your password";
$lang['login_input_password_data_alert'] = "Please input your valid password";
$lang['login_forget_password'] = "Forgot your password?";
$lang['login_button'] = "Login";
$lang['login_double_auth'] = "Google Authentication";
$lang['login_please_input_auth'] = "Please input the code on Google Authenticator";
$lang['login_input_auth_number'] = "Auth code for 51btc.com on your phone.";
$lang['login_already_login'] = "You have already logged in";
$lang['login_frozen'] = "Account frozen for wrong password more than 6 times.";
$lang['login_confirm'] = "Confirm";
$lang['login_password_error'] = "Password is invalid. You have %s chances remain.";
$lang['login_email_inverify'] = "Verify email has been sent to you again, please check.";
$lang['login_input_ga'] = "Please input google auth code.";
$lang['login_ga_error'] = "Google auth code is invalid";
$lang['login_error'] = "Account and password does not match.";

#市场页
$lang['market_title'] = "51BTC-Market";
$lang['market_balance'] = "Balance";
$lang['market_available'] = "Available";
$lang['market_frozen'] = "frozen";
$lang['market_restricted'] = "restricted";
$lang['market_exchange'] = "Exchange";
$lang['market_trading'] = " trading";
$lang['market_24_trading'] = "24H volume";
$lang['market_max'] = "Max";
$lang['market_min'] = "Min";
$lang['market_new'] = "New";
$lang['market_bid'] = " Buy ";
$lang['market_bid_price'] = "Price";
$lang['market_bid_ratio'] = "Ratio";
$lang['market_bid_volume'] = "Amount";
$lang['market_volume'] = "Total";
$lang['market_fee'] = "FEE";
$lang['market_pay'] = "Pay";
$lang['market_all'] = "All";
$lang['market_ask_price'] = "Price";
$lang['market_ask_ratio'] = "Ratio";
$lang['market_ask_volume'] = "Amount";
$lang['market_fund_to_account'] = "Receive";
$lang['market_ask'] = " Sell ";
$lang['market_bid_ask'] = "Buy Orders/Sell Orders";
$lang['market_trade_history'] = "Market Trade History";
$lang['market_amount_limit'] = "Total can not be less than";
#卖单标签
$lang['market_sell_label_1'] = "Sell";
$lang['market_sell_label_2'] = "Price";
$lang['market_sell_label_3'] = "Sell";
#买单标签
$lang['market_buy_label_1'] = "Buy";
$lang['market_buy_label_2'] = "Price";
$lang['market_buy_label_3'] = "Buy";
#市场交易历史标签
$lang['market_trade_history_label_1'] = "Date";
$lang['market_trade_history_label_2'] = "Type";
$lang['market_trade_history_label_3'] = "Price";
$lang['market_trade_history_label_4'] = "Amount";
$lang['market_trade_history_label_5'] = "Total";
#个人正在挂单
$lang['market_your_open_orders_tab_1'] = "Date";
$lang['market_your_open_orders_tab_2'] = "Type";
$lang['market_your_open_orders_tab_3'] = "Amount";
$lang['market_your_open_orders_tab_4'] = "Order Price";
$lang['market_your_open_orders_tab_5'] = "Trading Amount";
$lang['market_your_open_orders_tab_6'] = "Unfilled Amount";
$lang['market_your_open_orders_tab_7'] = "Total";
$lang['market_your_open_orders_tab_8'] = "Operation";
#个人交易历史
$lang['market_your_trade_history_tab_1'] = "Deal Amount";
$lang['market_your_trade_history_tab_2'] = "Deal Price";
$lang['market_your_trade_history_tab_3'] = "Trading Amount";
$lang['market_your_trade_history_tab_4'] = "Total";
$lang['market_your_trade_history_average'] = "AVG";
#市场公用
$lang['market_type_1'] = "Buy";
$lang['market_type_2'] = "Sell";
$lang['market_date'] = "Date";
$lang['market_type'] = "Type";
$lang['market_amount'] = "Amount";
$lang['market_price'] = "Price";
$lang['market_status'] = "Status";
$lang['market_cancel'] = "Cancel";
$lang['market_canceled'] = "Canceled";
$lang['market_overview'] = "Overview";

$lang['market_pending'] = "Your Open Orders";
$lang['market_order_done'] = "Your Trade history";
$lang['market_order_canceled'] = "Your Canceled Orders";
$lang['market_order_volume'] = "Order volume";
$lang['market_order_price'] = "Order price";
$lang['market_done'] = "done";
$lang['market_open_orders'] = "Open Orders";
$lang['market_held_volumn'] = "held volume";
$lang['market_operation'] = "Operation";

$lang['market_safety_info_1'] = "Please trade 48 hours later after your assets password is changed.";
$lang['market_safety_info_2'] = "Please trade 1 week later after your GA is canceled.";

$lang['market_alert_buy_vol'] = "Please enter buy amount.";
$lang['market_alert_sell_vol'] = "Please enter sell amount.";
$lang['market_alert_1'] = "Please input a valid value.";
$lang['market_price_no_less'] = "Price can not be less than";
$lang['market_amount_no_less'] = "Amount can not be less than";
$lang['market_on_pending'] = "Pending...";

$lang['market_huge_amount'] = "Trading Amout is too huge";
$lang['market_huge_price'] = "Trading Price is too huge";
$lang['market_price_division_1'] = "Price should be divided by";
$lang['market_price_division_2'] = "";
$lang['market_amount_division_1'] = "Amount should be divided by";
$lang['market_amount_division_2'] = "";
$lang['market_insufficient'] = " is insufficient.";

#订单页
$lang['order_title'] = "51BTC-Order";

#设置页
$lang['option_title'] = "51BTC-Setting";
$lang['option_basic_info'] = "Account Profile";
$lang['option_account'] = "Email";
$lang['option_full_name'] = "RealName";
$lang['option_login_pwd'] = "Password";
$lang['option_mobile'] = "Mobile";
$lang['option_modify'] = "Modify";
$lang['option_set'] = "Set";
$lang['option_security_setup'] = "Security Setup";
$lang['option_low'] = "low";
$lang['option_medium'] = "medium";
$lang['option_high'] = "high";
$lang['option_email'] = "E-mail";
$lang['option_bind_mobile'] = "Binding Mobile";
$lang['option_trade'] = "Trade";
$lang['option_trade_pwd'] = "Assets Password";
$lang['option_login'] = "Login";
$lang['option_open'] = "Open";
$lang['option_setted'] = "Setted";
$lang['option_delete'] = "Delete";
$lang['option_google_auth'] = "google authentication";
$lang['option_withdraw'] = "Withdraw";
$lang['option_withdraw_limit'] = "Withdraw Limit";
$lang['option_item'] = "item";
$lang['option_security'] = "security";
$lang['option_security_level_1'] = "Email Setted";
$lang['option_security_level_2'] = "Mobile Setted";
$lang['option_security_level_3'] = "All Setted";
$lang['option_day'] = "day";
$lang['option_your_withdraw_limit'] = "Your withdraw limit currently is:";
$lang['option_your_withdraw_limit_unit'] = "BTC/day";
$lang['option_your_withdraw_limit_notify'] = "Note: Contact our customer survices if you want to raise your withdraw limit.";
$lang['option_password_input'] = "Password must be the same.";
$lang['option_include_letter_number'] = "length at lease 8. Must contain letters and digits.";
$lang['option_popup_sms_verify'] = "SMS Code";
$lang['option_popup_voive_verify'] = "Voice";
#设置页修改登录密码窗口
$lang['option_window_modify_pwd_title'] = "Modify Login Password";
$lang['option_window_modify_pwd_tab_1'] = "Current Password";
$lang['option_window_modify_pwd_tab_2'] = "New Password";
$lang['option_window_modify_pwd_tab_3'] = "Confirm Password";
$lang['option_window_modify_pwd_submit'] = "Submit";
$lang['option_window_modify_pwd_no_need'] = "No need to change since new password is the same with old password.";
$lang['option_window_modify_pwd_wrong'] = "Current Password is wrong.";
$lang['option_window_modify_pwd_success'] = "Update Password successfully.";
#设置页资金密码窗口
$lang['option_window_assets_pwd_title'] = "Set Assets Password";
$lang['option_window_assets_pwd_tab_1'] = "Assets Password";
$lang['option_window_assets_pwd_tab_1_placeholder'] = "Length at least eight";
$lang['option_window_assets_pwd_tab_2'] = "Confirm Password";
$lang['option_window_assets_pwd_tab_2_placeholder'] = "Length at least eight";
$lang['option_window_assets_pwd_tab_3'] = "Verify Code";
$lang['option_window_assets_pwd_tab_3_button'] = "Send Verify Code";
$lang['option_window_assets_pwd_tab_4'] = "Google Auth";
$lang['option_window_assets_pwd_submit'] = "Submit";
$lang['option_window_assets_pwd_no_need'] = "No need to change since new password is the same with old password.";
$lang['option_window_assets_pwd_success'] = "Set Assets Password successfully.";
#设置页解绑ga窗口
$lang['option_window_delete_ga_title'] = "Delete Google Authenticator";
$lang['option_window_delete_ga_tab'] = "Google Authenticator";
$lang['option_window_delete_ga_button'] = "Delete";
$lang['option_window_delete_ga_text_1'] = "Please input the code on your Google Authenticator.";
$lang['option_window_delete_ga_text_2'] = "If you can't use your Google Authenticator, please contact customer service.";
#设置页设置ga窗口
$lang['option_window_ga_title'] = "Set Google Authenticator";
$lang['option_window_ga_text_1'] = "Step 1: Install Google Authenticator On Your Smart Phone";
$lang['option_window_ga_text_2'] = "WindowsPhone";
$lang['option_window_ga_text_3'] = "Download From App Store";
$lang['option_window_ga_text_4'] = "Download From Android Market";
$lang['option_window_ga_text_5'] = "Download From WindowsPhone Market";
$lang['option_window_ga_text_6'] = "Note: Search 'Google Authenticator' on App Store or Android Market to Find the App.";
$lang['option_window_ga_text_7'] = "Step 2: Scan the QR code or Input Manually";
$lang['option_window_ga_text_8'] = "Note:";
$lang['option_window_ga_text_9'] = "1. Open Google Authenticator, click icon or text on the right top, add verify code by either way.";
$lang['option_window_ga_text_10'] = "2. Some times App may crash where andriod user scan the  QR code. if this happen, you can input the code manually.";
$lang['option_window_ga_text_11'] = "3. We suggest you write the key down in case it's lost.";
$lang['option_window_ga_text_12'] = "Step 3: Input the Verify Code on Google Authenticator";
$lang['option_window_ga_text_13'] = "Note: After App added, please don't delete this account, otherwise account on our website may encounter problem.";
$lang['option_window_ga_placeholder'] = "Enter the Verify Code";
$lang['option_window_ga_button'] = "Complete the Verify";
#安全设置窗口
$lang['option_window_safety_config_warning'] = "Please set your google authenticator first.";
$lang['option_window_safety_config_title'] = "Safety Config";
$lang['safety_config_failed'] = "Safety Config Failed";
$lang['safety_config_msg_1'] = "SMS Withdraw";
$lang['safety_config_msg_2'] = "Assets password for trade";
$lang['safety_config_msg_3'] = "Assets password for withdraw";
$lang['safety_config_msg_4'] = "Google auth for login";
$lang['safety_config_msg_5'] = "Google auth for withdraw";
$lang['safety_config_msg_6'] = "Email notify";
$lang['safety_config_msg_7'] = "Sms notify";
$lang['safety_config_close'] = " close";
$lang['safety_config_open'] = " open";
$lang['safety_config_success'] = " successfully";

#钱包页
$lang['wallet_title'] = "51BTC-Wallet";
$lang['wallet_warning'] = "Please set your google authenticator first.";
$lang['wallet_balance'] = "Account Balance";
$lang['wallet_total_balance'] = "Total Balance";
$lang['wallet_stay_tuned'] = "Stay tuned";
$lang['wallet_deposit'] = "Deposit";
$lang['wallet_withdraw'] = "Withdraw";
$lang['wallet_select'] = "Select";
$lang['wallet_cur'] = "Currently ";
$lang['wallet_available'] = " available";
$lang['wallet_please'] = "";
$lang['wallet_deposit_to'] = " Deposit Address";
$lang['wallet_check_blockchain'] = "Check the blockchain";
$lang['wallet_create_address'] = "Generate New deposite Address";
$lang['wallet_deposit_note'] = "- The deposit will be success after 3 confirmations, it needs approximately half an hour. Minimum amount of despoit: ";
$lang['wallet_use_phone_wallet'] = "Use your phone";
$lang['wallet_scan_qr_code'] = "Scan the QR code: ";
$lang['wallet_deposit_history'] = "Deposit history";
$lang['wallet_withdraw_history'] = "Withdraw history";
$lang['wallet_check_address'] = "check address";
$lang['wallet_withdraw_address'] = "Withdraw Address";
$lang['wallet_withdraw_address_lock'] = "lock";
$lang['wallet_withdraw_amount'] = "Withdraw Amount";
$lang['wallet_min_withdraw'] = "Minimum Amount";
$lang['wallet_daily_max_withdraw'] = "Today's Remaining";
$lang['wallet_trade_pwd'] = "Assets Password";
$lang['wallet_sms_verify'] = "SMS verification";
$lang['wallet_send_verify_code'] = "Send verification code";
$lang['wallet_voice_verify_code'] = "Voice verification";
$lang['wallet_double_auth'] = "Google Auth";
$lang['wallet_withdraw_button'] = "Apply to Withdraw";
$lang['wallet_attention_info'] = "Please note a small fee of ฿0.0001 will be charged per withdrawal to cover default Bitcoin Network fees. ";
#钱包账户通用
$lang['wallet_all'] = "All";
$lang['wallet_date'] = "Date";
$lang['wallet_amount'] = "Amount";
$lang['wallet_status'] = "Status";
$lang['wallet_deposit_status_1'] = " confirmations";
$lang['wallet_deposit_status_2'] = "Success";
$lang['wallet_withdraw_status_0'] = "Pending";
$lang['wallet_withdraw_status_1'] = "Doing";
$lang['wallet_withdraw_status_2'] = "Done";
$lang['wallet_withdraw_status_3'] = "Confirming";
$lang['wallet_withdraw_status_4'] = "Canceled";
$lang['wallet_operation'] = "Operation";
$lang['wallet_operation_1'] = "Cancel";
$lang['wallet_operation_2'] = "Recheck";
$lang['wallet_fee'] = "Fee";
$lang['wallet_check'] = "Check";
$lang['wallet_coin'] = "Coin";
#钱包提现提示信息
$lang['wallet_withdraw_info_1'] = "Beyond Today's limit";
$lang['wallet_withdraw_info_2'] = "Assets password is invalid";
$lang['wallet_withdraw_info_3'] = "SMS code is invalid";
$lang['wallet_withdraw_info_4'] = "SMS code is expired";
$lang['wallet_withdraw_info_5'] = "Google auth code is invalid";
$lang['wallet_withdraw_info_6'] = "Apply withdraw confirming mail has been sent, please check.";
$lang['wallet_withdraw_info_7'] = "Apply withdraw failed";
$lang['wallet_withdraw_info_8'] = "Insufficient Balance";
$lang['wallet_withdraw_info_9'] = "Withdraw Amount can be less than ";
$lang['wallet_withdraw_info_10'] = "Please withdraw 48 hours later after your assets password is changed.";
$lang['wallet_withdraw_info_11'] = "Please withdraw 1 week later after your GA is canceled.";
#钱包提现取消信息
$lang['withdraw_cancel_info_1'] = "Withdraw record not exist";
$lang['withdraw_cancel_info_2'] = "You have no access";
$lang['withdraw_cancel_info_3'] = "Status wrong, can not cancel.";
$lang['withdraw_cancel_info_4'] = "Successfully Canceled.";
$lang['withdraw_cancel_info_5'] = "Cancel failed.";
#钱包提现锁定信息
$lang['withdraw_lock_info_1'] = "Unlock successfully!";
$lang['withdraw_lock_info_2'] = "Lock successfully!";
$lang['withdraw_lock_info_3'] = "Unlock failed!";
$lang['withdraw_lock_info_4'] = "Lock failed!";
#钱包提现验证邮件重新发送
$lang['wallet_withdraw_reconfirm_info_1'] = "Reconfirm Mailed is Sent, please check.";

#邀请页
$lang['invitation_code_generated'] = "Invite code generated";
$lang['invitation_used'] = "Used";

#帮助页面
$lang['help_title'] = "51BTC - Help";
$lang['help_center'] = "Help Center";
$lang['help_find_by_category'] = "Category";
$lang['help_common_issues'] = "Common Issues";
$lang['help_still'] = "Still Got Stuck?";
$lang['help_gg_mm'] = "More Ways";
#帮助反馈窗口
$lang['help_mail_feedback'] = "Feedback";
$lang['help_choose_type'] = "Type";
$lang['help_choose_type_1'] = "Trade";
$lang['help_choose_type_2'] = "Deposit";
$lang['help_choose_type_3'] = "Withdraw";
$lang['help_choose_type_4'] = "Network";
$lang['help_choose_type_5'] = "Others";
$lang['help_feedback_title'] = "Title";
$lang['help_feedback_content'] = "Content";
$lang['help_feedback_user_info'] = "User Info";
$lang['help_feedback_contact'] = "Contact";
$lang['help_feedback_address'] = "Address";
$lang['help_feedback_operator'] = "Operator";
$lang['help_feedback_operator_1'] = "please choose";
$lang['help_feedback_operator_2'] = "Telecom";
$lang['help_feedback_operator_3'] = "Mobile";
$lang['help_feedback_operator_4'] = "Unicom";
$lang['help_feedback_operator_5'] = "Netcom";
$lang['help_feedback_operator_6'] = "Education Net";
$lang['help_feedback_operator_7'] = "other";
$lang['help_feedback_submit'] = "Submit";

$lang['help_mail_online_service'] = "Online Service";
#帮助详情页
$lang['help_submit_success'] = "Submit successfully!";
$lang['help_update_date'] = "Update Date";
$lang['help_author'] = "Author";
$lang['help_is_help'] = "Is this solution helpful?";
$lang['help_is_help_answer_1'] = "yes";
$lang['help_is_help_answer_2'] = "not really";
$lang['help_announcements'] = "Announcements";
$lang['help_activities'] = "Activities";
$lang['help_more'] = "more";
#帮助页新闻公告
$lang['article_title'] = "51BTC-News and Announcements";
$lang['article_announcement'] = "News and Announcements";
$lang['article_latest'] = "Latest";
#帮助在线反馈页
$lang['help_matter_title'] = "51BTC-Feedback";
$lang['help_online_feedback'] = "Feedback";
$lang['help_question_type'] = "Question Type";
$lang['help_work_num'] = "Work Number";

#找回密码页
$lang['forget_title'] = "51BTC-Forget Password";
$lang['forget_find_password'] = "Forget Password";
$lang['forget_email'] = "Email";
$lang['forget_email_placeholder'] = "Please enter your email";
$lang['forget_email_data_alert'] = "Please enter a valid email address";
$lang['forget_next_step'] = "Next Step";
$lang['forget_email_find'] = "Email to find password back";
$lang['forget_email_send_success'] = "successfully send, please check your email!";
$lang['forget_email_notify'] = "Please check your email, Operate under the instruction。";
$lang['forget_email_link'] = "Login Email";

#重置密码页
$lang['reset_title'] = "51BTC-Reset Password";
$lang['reset_password'] = "Reset Password";
$lang['reset_new_password'] = "New Password";
$lang['reset_new_password_placeholder'] = "Please enter your new password";
$lang['reset_new_password_data_alert'] = "Please enter your new password";
$lang['reset_confirm_new_password'] = "Confirm Password";
$lang['reset_confirm_new_password_placeholder'] = "Please confirm your new password";
$lang['reset_confirm_new_password_data_alert'] = "Please confirm your new password";
$lang['reset_button'] = "Submit";
$lang['reset_code_invalid'] = "Reset Code is invalid";
$lang['reset_code_expired'] = "Reset code is expired";
$lang['reset_success'] = "Reset password successfully";
$lang['reset_failed'] = "Reset password failed";

#server user.php
$lang['email_used'] = "Email has already been used.";
$lang['account_not_exist'] = "Account do not exist!";
$lang['account_not_login'] = "Not logged in yet!";
$lang['account_have_logged_in'] = "You have already logged in!";
$lang['qr_code'] = "QR Code";
$lang['google_auth_code'] = "Google Verify Code";
$lang['google_auth_code_error'] = "Google Verify Code is invalid!";
$lang['google_auth_set_success'] = "Google Auth is successfully setted!";
$lang['google_auth_delete_success'] = "Google Auth is successfully deleted!";

#server trade.php
$lang['market_not_exist'] = "Market does not exist";
$lang['pending_success'] = "Pending Successfully";
#K线
$lang['kline_5min']='5 min';
$lang['kline_hourly']='Hourly';
$lang['kline_daily']='Daily';
#用户
$lang['user_forbid_trade']='You have been forbidden for trading';
$lang['user_forbid_login']='You have been forbidden for login';
$lang['user_forbid_withdraw']='You have been forbidden for withdraw';

#收益
$lang['profit_your_silver_fish'] = "Your Silverfish Shares";
$lang['profit_total'] = "Total:";
$lang['profit_announcement'] = "Announcements";
$lang['profit_info'] = "Profit information";

$lang['profit_shares_snapshot'] = "Shares Snapshot";
$lang['profit_my_profit'] = "My Profit";
$lang['profit_type'] = "Type";
$lang['profit_snapshot_time'] = "Snapshot Time";
$lang['profit_your_shares'] = "Your shares";
$lang['profit_all_shares'] = "All Shares";
$lang['profit_weekly_profit'] = "Weekly Profit";
$lang['profit_my_all_profit'] = "My Profit Total";
$lang['profit_till'] = "Till";
$lang['profit_no_profit'] = "Current none";
$lang['profit_note'] = "Note: ";
$lang['profit_note_text'] = "Your profit will be add to your account's wallet after Silverfish transfer the total profit into 51BTC's receiving address.";
$lang['profit_date'] = "Date";
$lang['profit_coin'] = "Coin";
$lang['profit_51btc_profit'] = "51BTC Profit";
$lang['profit_per_share'] = "Porfit Per Share";
$lang['profit_share_num'] = "Your Shares Num";
$lang['profit_share_num_total'] = "Shares Num Total";
$lang['profit_cur_profit'] = "Your Profit";
$lang['profit_address'] = "Address";

#用户 caokl
$lang['phone_has_exist']="手机号码已注册";
$lang['register_failed']="注册失败";
$lang['login_failed']	="登录账号或密码错误";
$lang['login_times_out']="错误次数过多,账户将被冻结24小时。如有疑问,请联系客服";
$lang['login_last_time']="密码错误,你还有1次机会";
$lang['login_succ']		="登陆成功";
$lang['logout']			="退出成功";
$lang['logout_fail']	="已退出";

#操作 caokl
$lang['c_op_succ']		="修改成功";
$lang['c_op_fail']		="修改失败";
$lang['c_op_send_succ']	="发送成功";
$lang['c_op_send_fail']	="发送失败";
$lang['c_op_sms_succ']	="短信发送成功";
$lang['c_op_sms_fail']	="短信发送失败";
$lang['c_op_get_succ']	="数据获取成功";
$lang['c_op_get_fail']	="数据获取失败";
$lang['c_op_get_data_fail']="数据获取失败,请联系客服";
$lang['c_op_add_succ']	="添加成功";
$lang['c_op_add_fail']	="添加失败";
$lang['c_op_update_succ']="更新成功";
$lang['c_op_update_fail']="更新失败";
$lang['c_op_bind_succ']="绑定成功";
$lang['c_op_bind_fail']="绑定失败";
$lang['c_op_with_succ']="提现申请成功";

#验证 caokl
$lang['valid_succ']		="验证成功";
$lang['valid_fail']		="验证错误";
$lang['valid_image_fail']="图片验证码不正确";
$lang['new_phone_vcode_fail']="新手机与验证码不匹配";
$lang['old_phone_vcode_fail']="原手机验证码不正确";
$lang['phone_exist']		="手机号码已存在";
$lang['mail_valided']		="邮箱已认证";
$lang['vcode_valid_fail']	="手机验证码不正确";
$lang['new_old_pass_same']	="新密码与原密码一致";
$lang['old_pass_fail']		="原密码错误";
$lang['old_pass_trade_fail']="原交易密码错误";
$lang['trade_pass_not_empty']="您已经填写交易密码";
$lang['new_old_pass_trade_same']="新交易密码与原交易密码一致";
$lang['truename_not_empty']="您已实名认证，不能被修改";
$lang['idcard_has_correct']="您已实名认证，不可修改身份证号";
$lang['truename_has_correct']="您已实名认证，不可修改真实姓名";

$lang['btc_add_not_empty']="您已绑定btc地址";
$lang['bind_fail']			="已经绑定";
$lang['ga_valid_fail']		="ga码不正确";
$lang['post_bind_fail']		="您已绑定邮寄地址";
$lang['unionpay_card_valid']="绑定银行卡未通过银联认证,如有疑问请联系客服";
$lang['unionpay_not_empty'] ="您已添加实名认证与银行卡信息";
$lang['withdow_balance_err']="超过账户余额";
$lang['send_over_times']	="发送太频繁，休息一下。60秒内只能发送一次。";

//资产快照相关返回
$lang['snapshot_start_error'] = '期初时间的快照缺失';
$lang['snapshot_end_error'] = '期末时间的快照缺失';
$lang['snapshot_error'] = '资产快照非法';
$lang['snapshot_data_error'] = '快照数据非法';

$lang['update_money_apply_list'] = '调账申请列表';
$lang['update_money_apply'] = '调账申请';
$lang['update_money_check'] = '调账申请审核';
$lang['batch_updatemoney_apply'] = '批量调账申请';
$lang['batch_update_money_check'] = '批量调账申请审核';