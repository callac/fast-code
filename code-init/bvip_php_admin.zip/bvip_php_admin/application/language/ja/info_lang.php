<?php
/**
 * 公共
 */
$lang['zjys_statistics_users_task'] ='zjys_statistics_users_task';
$lang['unopen_site'] = 'サイトを準備中です。しばらくお待ちください';
$lang['close_site'] = 'そのサイトは終了しておりますので、アクセスできません';
$lang['balance_low'] = 'アカウントの残高不足です';
$lang['cancel_order_failed'] = '撤单失败';

$lang['operation_successful'] = '操作成功';
$lang['operation_failed'] = '操作失敗';
$lang['missing_parameters'] = 'パラメータが足りません';
$lang['The original password is not fought for'] = '原始密码不正确';
$lang['The passwords don‘t match twice'] = '两次密码不一致';

//登录
$lang['registered'] = '登録しました';
$lang['unregistered'] = '未登録';
$lang['token_valid'] = 'token有効';
$lang['token_failed'] = 'token失敗';
$lang['user_exist'] = 'ユーザーが存在しません';//用户不存在
$lang['password_error'] = 'パスワード間違い';//密码错误
$lang['email_exist'] = 'メールアドレスが存在しません';//邮箱不存在
$lang['email_isset'] = 'メールアドレスはすでに登録されています';//邮箱已被注册
$lang['register_failed'] = '登録失敗';//注册失败
$lang['mobile_isset'] = '携帯番号は登録されました';//手机号已被注册
$lang['mobile_exist'] = '携帯番号は存在しません';//手机号不存在
$lang['not_authority'] = '権限がありません';  //没有权限
$lang['mobile_preg_match'] = '手机号校验失败'; 



//订单 order_hash
$lang['order_generation_failed'] = 'オーダー生成失敗';

//购买 product_hash
$lang['buy_success'] = '購入成功';
$lang['buy_failure'] = '購入失敗';

//注册 register
$lang['send_success'] = '発送しました';
$lang['send_failure'] = '発送失敗';
/**
 * 个人中心
 */
//消息
$lang['data_success'] = 'データ呼び戻し成功';

$lang['income_invest'] = '招待収益';
$lang['freeze_withdraw'] = 'ごめんなさい、現在は出金できません';
$lang['withdraw_amount'] = '出金金額は最小出金額より大きくなければなりません';

//设置
$lang['address_save'] = 'アドレスは保存しましたので、最提出する必要はありません';
$lang['address_save_success'] = 'アドレスを保存しました';
$lang['original_password_error'] = '元パスワードが間違っています';
$lang['password_same'] = '新しいパスワードと元パスワードが同じです';
$lang['modify_define'] = '修正失敗';


$lang['being_check'] = '審査中';
$lang['being_do'] = '処理中';
$lang['have_finsh'] = '完成しました';
$lang['have_cancel'] = 'キャンセルしました';

// $lang['truename_error01'] = '您已经提交，无需重复提交';
// $lang['truename_error02'] = '您已实名通过，无需重复提交';

// $lang['bankcard_error01'] = '未实名，请先实名，然后绑定银行卡';
// $lang['bankcard_error02'] = '您已绑定银行卡，无需重复提交';
// $lang['bankcard_error03'] = '未绑定银行卡，无法提现';

// $lang['postaddr_error01'] = '绑定数量超过限制，请您删除后重新添加';


//充值、提现、提币 字段中文对照
//充值
// $lang['top-up_success'] = '充值成功';
// $lang['top-up_success_text2_for_bankcard'] = '恭喜您，您通过支付宝充值的 ¥';
// $lang['top-up_success_text1_for_bankcard'] = '恭喜您，您通过银行卡充值的 ¥';
// $lang['top-up_success_text2'] = '已到账，当前账户可用余额';
// $lang['top-up_fail'] = '充值失败';
// $lang['top-up_fail_text1_for_bankcard'] = '非常遗憾的通知您，您提交的 ¥';
// $lang['top-up_fail_text2_for_alipay'] = '非常遗憾的通知您，您提交的 ¥';
// $lang['top-up_fail_text2'] = '充值申请，充值失败，请您仔细确认后再次提交申请，如有疑问，请联系客服';
// //提现
// $lang['catital_success'] = '提现成功';
// $lang['catital_success_text1'] = '恭喜您，您申请提现的¥ ';
// $lang['catital_success_text2'] = '已通过，注意查收您的银行卡账户';
// $lang['catital_fail'] = '提现失败';
// $lang['catital_fail_text1'] = '非常遗憾的通知您，您提交的 ¥ ';
// $lang['catital_fail_text2'] = '提现申请，提现失败，请您仔细确认后再次提交申请，如有疑问，请联系客服';
// //提币
// $lang['withdraw_success'] = '提币成功';
// $lang['withdraw_success_text1'] = '恭喜您，您申请的';
// $lang['withdraw_success_text2'] = '提币申请，已通过审核，具体到账时间根据区块拥堵程度，可能会有延迟';
// $lang['withdraw_fail'] = '提币失败';
// $lang['withdraw_fail_text1'] = '非常遗憾的通知您，您提交的';
// $lang['withdraw_fail_text2'] = '提币申请，未通过审核。请您仔细确认后再次提交申请，如有疑问，请联系客服';

//货币单位
$lang['yuan'] = '元';//元
$lang['mei_yuan'] = 'ドル';//美元
$lang['ri_yuan'] = '円';//日元







//权限名称对照表
$lang['account_d'] = '操作履歴';
$lang['account_j'] = 'ログアウト';//

$lang['config_a'] = 'パラメータ管理ーーリスト';//
$lang['config_b'] = 'パラメータ管理ーー編集/添加';//
$lang['config_c'] = 'パラメータ管理ーー削除';//
$lang['config_d'] = 'バージョン管理--リスト';//
$lang['config_e'] = 'バージョン管理--削除';//
$lang['config_f'] = 'バージョン管理—添加/編集';//
$lang['config_g'] = 'メッセージタイプ';//
$lang['config_h'] = '私達について--更新/添加';//
$lang['config_i'] = '私達について--削除';//
$lang['config_j'] = '新聞メッセージ分類--リスト';//
$lang['config_k'] = '新聞メッセージ分類--削除';//
$lang['config_l'] = '新聞メッセージ分類--添加/編集';//

$lang['operation_a'] = 'メッセージ管理--編集';//
$lang['operation_b'] = 'メッセージ管理--リスト';//
$lang['operation_c'] = 'メッセージ管理--削除';//
$lang['operation_d'] = 'メッセージ管理--添加';//
$lang['operation_e'] = 'BDC管理--リスト';//
$lang['operation_f'] = 'BDC管理--削除';//
$lang['operation_g'] = 'BDC管理--添加/編集';//
$lang['operation_h'] = 'ヘルプセンター管理--リスト';//
$lang['operation_i'] = 'ヘルプセンター管理--削除';//
$lang['operation_j'] = 'ヘルプセンター管理-添加/編集-';//
$lang['operation_k'] = 'ヘルプセンター管理--タイプ';//
$lang['operation_l'] = 'banner管理--リス';//
$lang['operation_m'] = 'banner管理--削除';//
$lang['operation_n'] = 'banner管理-添加/編集-';//
// $lang['operation_o'] = '友情链接--新增/编辑';//

$lang['site_a'] = '子局の基礎情報を取得';//
$lang['site_b'] = '子局管理--添加';//
$lang['site_c'] = '子局管理--リスト';//
$lang['site_d'] = '子局管理--更新';//
$lang['site_e'] = 'ドメインを添加';//
$lang['site_f'] = 'ドメインを編集';//
$lang['site_g'] = 'ドメインを削除';//
$lang['site_h'] = 'サイトの情報リストを取得';//
$lang['site_i'] = 'サイトをクローズ/オープン';//
$lang['site_j'] = '基礎情報リストを設置';//
$lang['site_k'] = '子局管理--削除';//


//权限管理
$lang['roles_a'] = '部門/役職の情報を取得';//
$lang['roles_b'] = '部門/役職の情報を更新/添加';//
$lang['roles_c'] = '役職/部門権限リスト';//
$lang['roles_d'] = '管理員リスト';//
$lang['roles_e'] = '管理員　禁止/使用';//
$lang['roles_f'] = '管理員　添加/編集';//
$lang['roles_g'] = '管理員を削除';//
$lang['roles_h'] = 'ログイン';//
$lang['roles_i'] = 'パスワードを修正';//
$lang['roles_i'] = '管理员自修改密码';//
$lang['roles_j'] = '権限を更新';//
$lang['roles_k'] = 'サイトで部門/役職を取得';//
$lang['roles_l'] = '部門/役職を削除';//






//交易所
$lang['update_repeat'] = '法定通貨購入インタフェースのbalance.update時、ｉｄが重複して呼び出された';

$lang['jys_user_list'] = 'ユーザーリストインタフェース';   
$lang['jys_reset_password'] = 'ユーザーのログイン、取引パスワードをリセット';
$lang['jys_recharge_log_list'] = '入金履歴リスト';
$lang['jys_withdraw_list'] = '出金履歴';
$lang['jys_valids_list'] = '認証コード履歴';
$lang['jys_withdraw_verify'] = '初回出金審査';
$lang['jys_withdraw_sure_verify'] = '出金再審査';
$lang['jys_withdraw_address_list'] = '出金アドレスリスト';
$lang['jys_asset_list'] = 'コイン資産管理';
$lang['jys_add_asset'] = '資産種類を添加/編集';
$lang['jys_symbol_list'] = '取引ペアリスト';
$lang['jys_add_symbol'] = '取引ペアを添加/編集';
$lang['jys_user_totalassets'] = 'ユーザー資産';
$lang['jys_user_assetsdetail'] = 'ユーザーの資金明細';
$lang['jys_user_assetsflow'] = 'ユーザーの資産流動';
$lang['jys_user_dealrecords'] = 'ユーザーの成約履歴';
$lang['jys_user_entrustedrecords'] = 'ユーザーのオーダー履歴';
$lang['jys_merchantbank_list'] = '銀行口座を設定';
$lang['jys_merchantbank_add'] = '銀行口座を添加、編集';
$lang['jys_add_admin_merbank_inout_flows'] = '財務の出入り記録を添加/編集';
$lang['jys_add_admin_merbank_inout_list'] = '財務の出入り記録リスト';
$lang['jys_c2c_inout'] = 'C2C売買リスト';
$lang['jys_c2c_verify'] = 'バックヤード法定通貨売買審査';
$lang['jys_c2c_verify_first'] = 'バックヤード初回の法定通貨売買審査';
$lang['jys_userbank_list'] = 'バックヤードユーザー銀行口座リスト';
$lang['jys_merchantbank'] = '銀行口座を禁止/使用';
$lang['jys_unfreezeip'] = 'ipを解凍';
$lang['jys_activity_info'] = '活動詳細を取得';
$lang['jys_activity_list'] = '活動リスト';
$lang['jys_activity_add'] = '活動を添加';
$lang['jys_activity_delete'] = '活動を削除';
$lang['jys_trade_totalcount'] = '市場取引量ランキング';
$lang['jys_trade_totalfee'] = '市場取引手数料ランキング';
$lang['jys_upload_img'] = 'ファイルをアップロード';
$lang['jys_subsite_list'] = '子局リスト';
$lang['jys_subsite_addsadmin'] = '子局超管を添加/編集';
$lang['jys_subsite_sadminlist'] = '子局超管リスト';
$lang['jys_subsite_user_statistics'] = '子局のユーザー統計';
$lang['jys_subsite_trade_statistics'] = '子局の取引統計';

$lang['config_agreement_update'] = '基本設置を添加/編集';
$lang['config_agreement_list'] = '基本設置リスト';
$lang['config_agreement_delete'] = '基本設置を削除';
$lang['config_friendlink_update'] = '友情リンクを添加/編集';
$lang['config_friendlink_list'] = '友情リンクリスト';
$lang['config_friendlink_delete'] = '友情リンクを削除';

$lang['jys_edit_updateusermoney'] = 'ユーザー資金を調整';
$lang['jys_admin_unfreeze_asset'] = 'ユーザー解凍コイン資産を調整';

$lang['jys_user_identity'] = 'ユーザー認証情報リスト';
$lang['jys_useridentity_reset'] = 'ユーザー認証をリセット';
$lang['jys_recharge_address_list'] = 'ユーザー入金アドレスリスト';
$lang['jys_user_safeinfo'] = 'ユーザー安全情報リスト';
$lang['jys_user_editphoneemail'] = 'ユーザーメールアドレスの認証コードを編集';
$lang['jys_user_reset_two_step'] = 'GOOGLE２次認証をリセッ';
$lang['jys_user_correctassetitem'] = 'ユーザーの資金リストを調整';
$lang['jys_user_correctassetitem_csv'] = 'ユーザーの資金リスト転出を調整';
$lang['jys_vip_list'] = 'vip管理リスト';
$lang['jys_vip_edit'] = 'vip情報を編集';
$lang['jys_vip_adduser'] = 'vipアカウントを添加';
$lang['jys_user_forbidden_login'] = 'アカウントログイン禁止';
$lang['jys_user_forbidden_withdraw'] = 'アカウント出金禁止';
$lang['jys_user_forbidden_trade'] = 'アカウント取引禁止';

$lang['jys_timetask_totalsiteassets'] = 'サイトの資産統計リスト';
$lang['jys_user_get_info'] = 'ユーザー詳細';
$lang['jys_withdraw_address_user_list'] = 'ユーザー出金アドレス';
$lang['jys_withdraw_address_user_logs'] = 'ユーザー出金履歴';
$lang['jys_recharge_address_user_list'] = 'ユーザーチャージアドレス';
$lang['jys_recharge_address_user_logs'] = 'ユーザーチャージ履歴';

$lang['jys_get_userbank'] = '指定されたユーザーの銀行口座リスト';
$lang['jys_params_config_c2c'] = 'c2cパラメータ設置リスト';
$lang['jys_params_config_c2c_update'] = 'c2cパラメータ設置を添加/編集';
// $lang['jys_get_intotal'] = '银行卡收支';
// $lang['jys_get_outtotal'] = '获取c2c卖出对账';
$lang['jys_total_c2c'] = 'c2c勘定';
$lang['jys_get_c2cwithdraw_freeze'] = 'c2cを取得、出金を凍結';
$lang['jys_get_trade_freeze'] = 'プラットフォームコインの取引を凍結';
$lang['zjys_wallet_request_logs'] = 'ウォレット請求日記';
$lang['jys_get_bank_statistic'] = 'プラットフォームシングル売買の売掛金を統計します';
$lang['jys_get_bank_statistic_reality'] = 'プラットフォームングル売買の実際収入と支出を統計します';
$lang['jys_get_platform_deal'] = 'プラットフォームの成約記録（24時間前まで）';
$lang['jys_get_platform_deal_printcsv'] = 'プラットフォーム取引記録csvファイル出力';
$lang['jys_get_platform_order'] = 'プラットフォーム委託記録';
$lang['zjys_print_user_assets'] = 'ページを分けてユーザーの資産を出力';
$lang['jys_c2c_printexcel'] = 'C2C売買をExcelに出力';
$lang['jys_withdraw_printexcel'] = '出金管理をExcelに出力';
$lang['jys_recharge_printexcel'] = '入金管理をExcelに出力';

$lang['jys_user_statistics'] = 'ユーザー統計';
$lang['jys_merchant_inout_list_printexcel'] = 'プラットフォームカードの明細を出力';
$lang['jys_statistics_users_printexcel'] = 'ユーザー統計を出力';
$lang['jys_statistics_c2c_inout'] = '法定通貨統計';
$lang['jys_statistics_c2c_inout_printexcel'] = '法定通貨統計を出力';
$lang['operation_k'] = 'ヘルプ分類リスト';
$lang['operation_kadd'] = 'ヘルプ分類を添加/編集';
$lang['operation_kdelete'] = 'ヘルプ分類を削除';
$lang['jys_get_trade_statistic'] = '取引統計リスト';
$lang['jys_get_trade_statistic_print'] = '取引統計リストを出力';

$lang['config_appconfig_list'] = 'app更新配置リスト';
$lang['config_appconfig_add'] = 'app更新配置を添加/更新';
$lang['config_appconfig_delete'] = 'app更新配置を削除';

$lang['jys_lockposition_list'] = 'ロックリスト';
$lang['jys_lockposition_add'] = 'ロック添加/編集';
$lang['jys_lockposition_delete'] = 'ロック削除';
$lang['jys_unlockposition'] = '手動ロック解除';

$lang['config_labelconfiglist'] = 'ガイドラインの配置リスト';
$lang['config_labelconfigadd'] = 'ガイドライン配置を添加/編集';
$lang['config_labelconfigdelete'] = 'ガイドラインを削除';

$lang['jys_activityholding_list'] = 'ホールド活動リスト';
$lang['jys_activityholding_add'] = 'ホールド活動を添加/編集';
$lang['jys_activityholding_delete'] = 'ホールド活動を削除';
$lang['jys_activityholdingaward_list'] = 'ホールド活動の奨励リスト';
$lang['jys_user_lottery_logs'] = '抽選イベントリスト';
$lang['jys_user_treasure_logs'] = '争奪戦イベントのユーザー活動リスト';
$lang['jys_treasure_sessions'] = '争奪戦イベントの回数情報リスト';

$lang['jys_activity_treasurelist'] = '争奪戦-イベント配置リスト';
$lang['jys_activity_treasureadd'] = '争奪戦-イベント配置を添加/編集';
$lang['jys_activity_treasuredelete'] = '争奪戦-削除';
$lang['jys_activity_treasurenext'] = '争奪戦-次回をオープン';
$lang['jys_activity_treasureend'] = '争奪戦-終わり';
$lang['jys_activity_treasure_session_list'] = '争奪戦-前回記録リスト';
$lang['jys_activity_treasure_logs_list'] = '争奪戦-当たり情報';

$lang['jys_app_trade_config_list'] = 'api取引配置リスト';
$lang['jys_app_trade_config_add'] = 'api取引配置を添加';
$lang['jys_app_trade_config_delete'] = 'api取引配置を削除';

$lang['jys_statistics_mail_config_list'] = '運営配置リスト';
$lang['jys_statistics_mail_config_add'] = '運営配置を添加/編集';
$lang['jys_statistics_mail_config_delete'] = '運営配置を削除';
$lang['jys_statistics_mail_sent_records'] = '運営の発送履歴';

$lang['jys_csv_insert_updatemoney'] = 'csvファイルを出力しユーザー資金をまとめて調整';
$lang['jys_user_assetsflow_csv'] = 'ユーザー資金流動記録を出力';
$lang['jys_activity_userawards'] = 'アクティブユーザー奨励リスト';
$lang['jys_activity_award_priv'] = '基礎アクティブ奨励リストを導出';
$lang['jys_user_identity_check'] = 'ユーザー認証を審査';
$lang['jys_assetintro_list'] = 'コイン詳細のリスト';
$lang['jys_assetintro_add'] = 'コイン詳細を添加/編集';
$lang['jys_assetintro_del'] = 'コイン詳細を削除';

$lang['jys_symbolblock_list'] = 'ブロック配置リスト';
$lang['jys_symbolblock_add'] = 'ブロック配置を添加/編集';
$lang['jys_symbolblock_del'] = 'ブロック配置を削除';

$lang['jys_smsconfig_list'] = 'メッセージチャネルリスト';
$lang['jys_smsconfig_add'] = 'メッセージチャネルを添加/編集';
$lang['jys_smsconfig_del'] = 'メッセージチャネルを削除';
$lang['jys_smsconfig_used'] = 'メッセージチャネルを使い始める  ';

$lang['jys_emailconfig_list'] = 'メールチャネルリスト';
$lang['jys_emailconfig_add'] = 'メールチャネルを添加/編集';
$lang['jys_emailconfig_del'] = 'メールチャネルを削除';
$lang['jys_emailconfig_used'] = 'メールチャネルを使い始め';

$lang['jys_inviteconfig_list'] = '友達招待配置リスト';
$lang['jys_inviteconfig_add'] = '友達招待配置を添加/編集';
$lang['jys_inviteconfig_del'] = '友達招待配置を削除';
$lang['jys_inviteconfig_used'] = '友達招待配置を使い始める';

$lang['jys_ip_list'] = 'ip黑白名单列表';
$lang['jys_ip_add'] = 'ip黑白名单添加';
$lang['jys_ip_del'] = 'ip黑白名单删除';

$lang['config_news_content_list'] = '资讯多语言内容列表';
$lang['config_news_content_add'] = '资讯多语言内容新增/编辑';
$lang['config_news_content_delete'] = '资讯多语言内容删除';

$lang['jys_platformAsset'] = 'プラットフォームの資産スナップショット';
$lang['jys_platformAsset_csv'] = 'プラットフォームの資産スナップショットを出力';
$lang['jys_checkaccount'] = 'プラットフォーム勘定';
$lang['jys_checkaccount_csv'] = 'プラットフォーム勘定を出力';

$lang['jys_system_checkaccount'] = 'jys_system_checkaccount';
$lang['jys_system_checkaccount_csv'] = 'jys_system_checkaccount_csv';


$lang['jys_cancel_order_single'] = '撤销单个订单';
$lang['jys_cancel_order_market'] = '撤销市场订单';
$lang['jys_cancel_order_user_market'] = '撤销指定用户市场订单';







//风控管理
$lang['alarm'] = 'リスクコントロール';
$lang['symbols'] = '取引ペア';
$lang['transaction_alarm_list'] = '異常取引アラーム';
$lang['profit_loss_alarm_list'] = '異常損益監視';
$lang['account_alarm_list'] = '異常帳簿監視';
$lang['transaction_param'] = '異常取引パラメータ設定を取得';
$lang['account_param'] = '異常帳簿パラメータ設定を取得';
$lang['modify_transaction_param'] = '異常取引パラメータ設定を修正';
$lang['modify_account_param'] = '異常帳簿パラメータ設定を修正';
$lang['get_profit_param'] = '損益パラメータ設定を取得';
$lang['modify_profit_param'] = '損益パラメータ設定を修正';


//运营数据统计
$lang['asset_list'] = 'データを再構成する．';
$lang['asset_list_csv'] = '再構成するデータを出力';
$lang['register_list'] = '登録データ';
$lang['register_list_csv'] = '登録データを出力';
$lang['recharge_list'] = '入金データ';
$lang['recharge_list_csv'] = '入金データを出力';
$lang['withdraws_list'] = '出金データ';
$lang['withdraws_list_csv'] = '出金データを出力';
$lang['c2cbuy_list'] = 'C2C購入データ';
$lang['c2cbuy_list_csv'] = 'C2C購入データを出力';
$lang['c2csell_list'] = 'C2C売却データ';
$lang['c2csell_list_csv'] = 'C2C売却データを出力';
$lang['cointrade_list'] = 'コイン取引データ';
$lang['cointrade_list_csv'] = 'コイン取引データを出力';

//白名单
$lang['user_white_list'] = 'ホワイトリストリスト';
$lang['user_white_add'] = 'ホワイトリストを添加';
$lang['user_white_delete'] = 'ホワイトリストを削除';
$lang['no_account'] = 'アカウントが存在しません';
$lang['account_exist'] = 'アカウントはすでに存在しています';

$lang['jys_user_recommendlist'] = 'ユーザ招待登録リスト';
$lang['jys_user_recommendlist_csv'] = 'ユーザ招待登録リストを出力';

/**
 * 转账管理
 */
$lang['get_account_list'] = 'アカウントリスト';
$lang['add_account'] = 'アカウントを添加';
$lang['delete_account'] = 'アカウントを削除';
$lang['generate_total_account'] = '総アカウントを生成';
$lang['total_account_assets'] = '総アカウント資産';
$lang['transfer_user_money'] = '振替';
$lang['check_balance'] = '残高を調べる';
$lang['transfer_list'] = '振替リスト';
$lang['transfer_list_csv'] = '振替リストを出力';
$lang['Transfer failed'] = '振替失敗';
$lang['Transfer successful'] = '振替成功';
$lang['loan'] = '借金';
$lang['loan successful'] = '借金成功';
$lang['loan failed'] = '借金失敗';
$lang['repayment'] = '返却';
$lang['repayment successful'] = '返却成功';
$lang['repayment failed'] = '返却失敗';
$lang['loan_list'] = '貸借リスト';
$lang['repayment_list'] = '返却リスト';
$lang['loan_list_csv'] = '借金出力';
$lang['repayment_list_csv'] = '返却出力';
$lang['transfer_out_uid not exist'] = '転出されたアカウントは存在しません';
$lang['transfer_in_uid not exist'] = '転入されたアカウントは存在しません';
$lang['user_id not exist'] = 'アカウントは存在しません';
$lang['payer_id not exist'] = '振替ユーザーは存在しません';
$lang['transfer_out_uid not asset'] = 'アカウントには当該コインはありません';
$lang['Insufficient balance'] = '残高不足';
$lang['not total account'] = '当該アカウントは総アカウントではありません';
$lang['can not'] = '返済数は借りた金額から返済済み金額を引いた額より大きくしてはいけない';
$lang['gift_coin_list'] = '贈与コインを管理';
$lang['gift_coin_list_csv'] = '贈与コインを出力';
$lang['gift_coin'] = '単独ユーザー贈与コインを増加';
$lang['batch_gift_coin'] = '大量ユーザー贈与コインを増加';
$lang['gift successful'] = 'コインを贈与成功';
$lang['gift failed'] = 'コインを贈与失敗';
$lang['total_account_assets_csv'] = '総資産を導出';
$lang['Account name already exists'] = 'アカウント名称は既に存在しています';
$lang['Total account cannot be deleted'] = '総アカウントは削除できません';
$lang['withdraws_alarm_list'] = '入出金を監視';
$lang['withdraws_alarm'] = 'withdraws_alarm';
$lang['address_alarm'] = 'address_alarm';
$lang['sys_service_wallet_recharge'] = 'sys_service_wallet_recharge';
$lang['zjys_get_trade_statistic'] = 'zjys_get_trade_statistic';
$lang['wallet_snapshot'] = 'wallet_snapshot';
$lang['deal_status'] = '入出金を処理します';
$lang['not site_id account'] = '本サイトのアカウントではありません';
$lang['not transfer account'] = '同じアカウントなら振替できません';
$lang['add_total_account'] = '総アカウントを添加';
$lang['add_asset_record'] = '総アカウントコインを添加';
$lang['not edit'] = '編集できません';
$lang['Already a general account'] = '当アカウントは既に総アカウントです';
$lang['No address'] = 'アドレスはありません';
$lang['repayment_address'] = '入金アドレス';
$lang['recharge_address_list'] = '重複した入金アドレスリスト';
$lang['address_deal_status'] = '入金アドレスの状態処理';
$lang['batch_gift_file'] = '贈与コインファイル';
$lang['not site_id account'] = '当該サイトのアカウントではありません';
$lang['site_id not totalaccount'] = 'サイトには総アカウントがありませんので、作成してください';


$lang['batch_user_file'] = '批量生成用户';
$lang['address is null'] = '地址为空';


$lang['account is exist'] = '该账户已存在';
$lang['address is failure'] = '生成地址失败或者该币种无法生成地址';

//钱包对账
$lang['wallet_snapshot_list'] = '钱包快照';
$lang['wallet_snapshot_list_csv'] = '钱包快照导出';
$lang['wallet_snapshot'] = 'wallet_snapshot';
$lang['wallet_snapshot_all'] = 'wallet_snapshot_all';
//充值
$lang['recharge_review'] = '充值审核';

$lang['workorders_list'] = '工单列表';
$lang['workorders_reply'] = '工单回复';
$lang['workorders_delete'] = '工单删除';
$lang['workorders_close'] = '工单关闭';
$lang['workorders_reply_list'] = '工单回复列表';

$lang['config_help_content_list'] = '帮助多语言内容配置列表';
$lang['config_help_content_add'] = '帮助多语言内容配置新增/编辑';
$lang['config_help_content_delete'] = '帮助多语言内容配置删除';

$lang['config_help_class_content_list'] = '帮助分类多语言内容配置列表';
$lang['config_help_class_content_add'] = '帮助分类多语言内容配置新增/编辑';
$lang['config_help_class_content_delete'] = '帮助分类多语言内容配置删除';


/**
 * 未定义语言
 */
$lang['jys_user_country'] = 'jys_user_country';
$lang['jys_asset_list_totalsite'] = 'jys_asset_list_totalsite';
$lang['jys_symbol_list_totalsite'] = 'jys_symbol_list_totalsite';
$lang['jys_list_ajaxsearch'] = 'jys_list_ajaxsearch';
$lang['jys_check_detail'] = 'jys_check_detail';
$lang['jys_sys_asset_list'] = 'jys_sys_asset_list';
$lang['jys_sys_asset_add'] = 'jys_sys_asset_add';
$lang['jys_sys_asset_delete'] = 'jys_sys_asset_delete';
$lang['jys_sys_symbol_list'] = 'jys_sys_symbol_list';
$lang['jys_sys_symbol_add'] = 'jys_sys_symbol_add';
$lang['jys_sys_symbol_delete'] = 'jys_sys_symbol_delete';
$lang['jys_check_detail'] = 'jys_check_detail';
$lang['symbolblock_list_list_noauth'] = 'symbolblock_list_list_noauth';
$lang['getdata_deduplication_data'] = 'getdata_deduplication_data';
$lang['deal_fee_platform'] = 'deal_fee_platform';




/**
 * 数据可视化
 */

$lang['real_draw'] = '实时数据图表';
$lang['real_data'] = '实时数据';
$lang['user_data'] = '用户总览';
$lang['user_data_draw'] = '用户总览图表';
$lang['trade_data'] = '币币交易统计';
$lang['trade_data_draw'] = '币币交易图表';
$lang['trade_fee_data'] = '手续费统计';
$lang['trade_fee_data_draw'] = '手续费图表';
$lang['trade_c2c_data'] = 'C2C交易';
$lang['trade_c2c_data_draw'] = 'C2C交易图表';
$lang['withdraws_coin_rank'] = '提币排名';
$lang['recharge_coin_rank'] = '充币排名';
$lang['coin_details_data'] = '币种详情数据';
$lang['coin_details_fee_data'] = '币种详情手续费数据';
$lang['coin_details_trade_draw'] = '币种详情图表';
$lang['coin_details_fee_draw'] = '币种详情手续费图表';
$lang['coin_recharge_withdraws_data'] = '币种详情充提币';
$lang['coin_recharge_withdraws_draw'] = '币种详情充提币图表';
$lang['trade_money_rank'] = '交易金额排名';
$lang['trade_order_rank'] = '交易订单排名';
$lang['trade_user_rank'] = '交易用户排名';
$lang['asset_symbols'] = '获取交易对';
$lang['site_asset'] = '获取币种';


$lang['time is null'] = '锁仓时间为空';
$lang['recharge failure'] = '充值审核失败';

/**
 * OTC
 */

$lang['otc_inout'] = 'otc买入卖出列表';
$lang['inout_printexcel'] = 'otc买入卖出列表导出';
$lang['otc_verify_first'] = 'otc第一次审核';

$lang['merchant_account_list'] = '商家列表';
$lang['merchant_account_add_edit'] = '商家新增和编辑';
$lang['merchant_account_delete'] = '商家启用与禁用';
$lang['otc_inout_add_edit'] = 'otc明细新增和编辑';
$lang['otc_inout_list'] = 'otc明细列表';
$lang['otc_inout_list_csv'] = 'otc明细列表导出';


//资产快照相关返回
$lang['snapshot_start_error'] = '期初时间的快照缺失';
$lang['snapshot_end_error'] = '期末时间的快照缺失';
$lang['snapshot_error'] = '资产快照非法';
$lang['snapshot_data_error'] = '快照数据非法';

$lang['trade_detail'] = '当天交易市场明细';

$lang['jys_settlement_list'] = '手续费结算列表';
$lang['jys_settlement_csv'] = '手续费结算列表导出';
$lang['jys_settlement'] = '手续费结算';
$lang['jys_perday_detail_list'] = '每日币种手续费明细';
$lang['jys_perday_detail_csv'] = '每日币种手续费明细导出';
$lang['jys_settlement_all'] = '批量结算';
$lang['jys_checkbalance'] = '校验币种资金';
$lang['jys_settlement_record_list'] = '结算记录列表';
$lang['jys_settlement_record_list_csv'] = '结算记录列表导出';

//手续费结算（日结）
$lang['jys_day_settlement_list'] = '（日结）手续费结算列表';
$lang['jys_day_settlement_csv'] = '（日结）手续费结算列表导出';
$lang['jys_day_settlement'] = '（日结）手续费结算';
$lang['jys_day_settlement_all'] = '（日结）手续费批量结算';
$lang['jys_day_settlement_record_list'] = '（日结）结算记录列表';
$lang['jys_day_settlement_record_list_csv'] = '（日结）结算记录列表导出';


$lang['jys_add_recommend'] = '添加邀请关系';
$lang['zjys_resend_withdraw'] = '后台重新发起提币';

$lang['sys_key_log'] = '系统关键日志记录列表';

$lang['jys_amdin_whiteip_list'] = '后台管理员ip白名单列表';
$lang['jys_amdin_whiteip_add'] = '后台管理员ip白名单新增/编辑';
$lang['jys_amdin_whiteip_del'] = '后台管理员ip白名单删除';
$lang['transaction_number'] = '交易排名';
$lang['jys_websafe_login_logs'] = '客户端登录历史列表';
$lang['jys_websafe_operation_logs'] = '客户端操作历史列表';

$lang['platform_balacne_payment'] = '平台收支列表';
$lang['platform_balacne_payment_detail'] = '平台收支每日明细';

$lang['otc_transfer_list'] = 'otc转账记录列表';
$lang['otc_transfer_list_csv'] = 'otc转账记录导出';

$lang['jys_get_user_order'] = '用户所有委托订单';
$lang['jjys_get_user_order_printcsv'] = '用户所有委托订单导出';

$lang['zjys_withdraw_waitcheck_amount'] = '提币待审核等待数量';

$lang['Administrator change password self'] = '管理员自修改密码';
$lang['Old and new passwords should be inconsistent'] = '新旧密码应该不一致';


$lang['jys_statistics_newaddasset_list'] = '新增资产统计列表';
$lang['jys_lockposition_check'] = '锁仓审核';
$lang['jys_unlockposition_check'] = '解仓审核';

$lang['update_money_apply_list'] = '调账申请列表';
$lang['update_money_apply'] = '调账申请';
$lang['update_money_check'] = '调账申请审核';
$lang['batch_updatemoney_apply'] = '批量调账申请';
$lang['batch_update_money_check'] = '批量调账申请审核';


$lang['advert_place_list'] = '广告位列表';
$lang['advert_place_add'] = '广告位新增/编辑';
$lang['advert_place_del'] = '广告位删除';
$lang['advert_place_updown'] = '广告位上下架';

$lang['fingerpost_list'] = '新手指南列表';
$lang['fingerpost_add'] = '新手指南添加';
$lang['fingerpost_del'] = '新手指南删除';
$lang['fingerpost_updown'] = '新手指南上下架';

$lang['appTradestatus'] = '用户api-key状态切换';

$lang['handrecharge_list'] = '手动充值列表';
$lang['handrecharge_add'] = '新增充值';
$lang['handrecharge_verify_first'] = '手动充值初审';
$lang['handrecharge_verify'] = '手动充值复审';



















































