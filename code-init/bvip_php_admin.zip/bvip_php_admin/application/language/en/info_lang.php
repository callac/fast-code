<?php
/**
 * 公共
 */

// $lang['unopen_site'] ='We have not opened this site for the time being, please be patient';//我们暂未开启此站点，请您耐心等待
// $lang['close_site'] ='The station has been closed and cannot be accessed';//该站已被关闭，不可访问
// $lang['balance_low'] = 'Insufficient account balance';//账户余额不足
// $lang['operation_successful'] = 'Submitted successfully'; //操作成功
// $lang['operation_failed'] = 'Submission Failed';//操作失败
// $lang['missing_parameters'] = 'Missing parameters';//参数缺失
// $lang['user_exist'] = 'The user does not exist';//用户不存在
// $lang['password_error'] = 'Password mistake';//密码错误
// $lang['email_exist'] = 'Email does not exist';//邮箱不存在
// $lang['mobile_exist'] = 'Mobile number does not exist';//手机号不存在
// $lang['email_isset'] = 'The mailbox has been registered';//邮箱已被注册
// $lang['register_failed'] = 'Registration failed';//注册失败
// $lang['mobile_isset'] = 'The phone number has been registered.';//手机号已被注册
// $lang['not_authority'] = 'Not authority';  //没有权限





// //登录
// $lang['registered'] = 'registered';//已注册
// $lang['unregistered'] = 'unregistered';//未注册
// $lang['token_valid'] = 'token valid';//token有效
// $lang['token_failed'] = 'token failed';//token失效


// //订单 order_hash
// $lang['order_generation_failed'] = 'Order generation failed';//订单生成失败

// //购买 product_hash
// $lang['buy_success'] = 'buy success';//购买成功
// $lang['buy_failure'] = 'buy failure';//购买失败

// //注册 register
// $lang['send_success'] = 'send success';//发送成功
// $lang['send_failure'] = 'send failure';//发送失败
// /**
//  * 个人中心
//  */
// //消息 
// $lang['data_success'] = 'Return data success';  //返回数据成功
// $lang['income_invest'] = 'Income from investment';//投资收益
// $lang['freeze_withdraw'] = 'I am sorry, you can not make it for the time being';//对不起，您暂时不能提现
// $lang['withdraw_amount'] = 'The amount to be raised should be greater than the minimum amount of cash';//提现数量应该大于最小提现额度

// //设置
// $lang['address_save'] = 'This address has been saved without repeated submission'; //该地址已保存，无需重复提交
// $lang['address_save_success'] = 'Save the address successfully'; //地址保存成功
// $lang['original_password_error'] = 'Original password error'; //原密码错误
// $lang['password_same'] = 'The new password is the same as the original password'; //新密码与原密码相同
// $lang['modify_define'] = 'Failure to modify'; //修改失败

// $lang['being_check'] =  'Being audited';//正在审核
// $lang['being_do'] =  'Being dealt with'; //正在处理
// $lang['have_finsh'] = 'Completed';//'已完成
// $lang['have_cancel'] = 'Have been cancelled';//'已取消
// $lang['product_sell'] = '算力出售';//算力出售
// $lang['reward_income'] = '奖励收益';//奖励收益
// $lang['user_msg_desc'] = '推荐人购买算力所发放的奖励收益';//推荐人购买算力所发放的奖励收益
// $lang['user_msg_text1'] = '您邀请的好友';//您邀请的好友
// $lang['user_msg_text2'] = '已成功投资';//已成功投资
// $lang['user_msg_text3'] = 'T算力,给您的推荐收益为';//T算力,给您的推荐收益为
// $lang['product_buy'] = '算力购买';//算力购买
// $lang['notification_msg_text1'] = '算力购买时间为';//算力购买时间为
// $lang['notification_msg_text2'] = '购买了';//购买了
// $lang['notification_msg_text3'] = '购买金额为';//购买金额为
// $lang['product_transfer'] = '算力转让';//算力转让
// $lang['product_transfer_fee'] = '算力转让手续费';//算力转让手续费
// $lang['product_transfer_fee'] = '算力转让手续费';//算力转让手续费
// $lang['product_transfer_fee'] = '矿机购买';//矿机购买
// $lang['miner_sell'] = '矿机出售';//矿机出售

// //充值提现提币

// $lang['top-up_success'] = '充值成功';
// $lang['top-up_success_text2_for_bankcard'] = '恭喜您，您通过支付宝充值的 ¥';
// $lang['top-up_success_text1_for_bankcard'] = '恭喜您，您通过银行卡充值的 ¥';
// $lang['top-up_success_text2'] = '已到账，当前账户可用余额';
// $lang['top-up_fail'] = '充值失败';
// $lang['top-up_fail_text1_for_bankcard'] = '非常遗憾的通知您，您提交的 ¥';
// $lang['top-up_fail_text2_for_alipay'] = '非常遗憾的通知您，您提交的 ¥';
// $lang['top-up_fail_text2'] = '充值申请，充值失败，请您仔细确认后再次提交申请，如有疑问，请联系客服';
// //提现
// $lang['catital_success'] = '提现成功';
// $lang['catital_success_text1'] = '恭喜您，您申请提现的¥ ';
// $lang['catital_success_text2'] = '已通过，注意查收您的银行卡账户';
// $lang['catital_fail'] = '提现失败';
// $lang['catital_fail_text1'] = '非常遗憾的通知您，您提交的 ¥ ';
// $lang['catital_fail_text2'] = '提现申请，提现失败，请您仔细确认后再次提交申请，如有疑问，请联系客服';
// //提币
// $lang['withdraw_success'] = '提币成功';
// $lang['withdraw_success_text1'] = '恭喜您，您申请的';
// $lang['withdraw_success_text2'] = '提币申请，已通过审核，具体到账时间根据区块拥堵程度，可能会有延迟';
// $lang['withdraw_fail'] = '提币失败';
// $lang['withdraw_fail_text1'] = '非常遗憾的通知您，您提交的';
// $lang['withdraw_fail_text2'] = '提币申请，未通过审核。请您仔细确认后再次提交申请，如有疑问，请联系客服';



// $lang['truename_error01'] = 'You have submitted, without repeated submission';
// $lang['truename_error01'] = 'You have passed the real name, and there is no need to repeat the submission';

// $lang['bankcard_error01'] = 'No real name, first real name, and then bind the bank card';
// $lang['bankcard_error02'] = 'You have bound the bank card without repeated submission';
// $lang['bankcard_error03'] = 'Unbound bank card can not be presented';

// $lang['postaddr_error01'] = 'The number of bindings exceeds the limit, please delete it and add it again';

// //权限
// $lang['user_a'] = '用户列表';//
// $lang['user_b'] = '用户详情';//
// $lang['user_c'] = '用户导出';//
// $lang['user_d'] = '禁止/允许登陆';//
// $lang['user_e'] = '禁止交易/允许交易';//
// $lang['user_f'] = '禁止提现/允许提现';//
// $lang['user_g'] = '图片上传';//
// $lang['user_h'] = '实名列表';//
// $lang['user_i'] = '实名详情';//
// $lang['user_j'] = '实名审核';//
// $lang['user_k'] = '银行卡列表';//
// $lang['user_l'] = '银行卡审核详情';//
// $lang['user_m'] = '银行卡审核';//

// $lang['product_a'] = '云算力--产品列表';//
// $lang['product_b'] = '云算力--新增产品/编辑产品';//
// $lang['product_c'] = '云算力--获取产品基本信息';//
// $lang['product_d'] = '云算力--根据站点id获取算力类型';//
// $lang['product_e'] = '云算力--可售/售罄';//
// $lang['product_f'] = '云算力--详情';//
// $lang['product_g'] = '矿机--列表';//
// $lang['product_h'] = '矿机--新增';//
// $lang['product_i'] = '详情类型-算力，矿机，站点，首页显示，显示，状态';//
// $lang['product_j'] = '矿机--更新';//
// $lang['product_k'] = '矿机--售罄按钮';//
// $lang['product_l'] = '矿机--详情';//

// $lang['money_a'] = '充值列表';//
// $lang['money_b'] = '充值详情';//
// $lang['money_c'] = '充值初步审核';//
// $lang['money_d'] = '充值再次审核';//
// $lang['money_e'] = '充值再次确认审核详情';//
// $lang['money_f'] = '提现列表';//
// $lang['money_g'] = '提现详情';//
// $lang['money_h'] = '提现初步审核';//
// $lang['money_i'] = '提现再次审核';//
// $lang['money_j'] = '提现再次审核详情';//
// $lang['money_k'] = '资金流水';//
// $lang['money_l'] = '充值管理列表導出數據';//
// $lang['money_m'] = '體現列表導出數據';//
// $lang['money_n'] = '資金流水';//

// $lang['btcMoney_b'] = '提币列表';//
// $lang['btcMoney_c'] = '提币详情';//
// $lang['btcMoney_d'] = '提币初步审核';//
// $lang['btcMoney_e'] = '提币确认审核';//
// $lang['btcMoney_f'] = '再次审核详情';//
// $lang['btcMoney_g'] = '提币导出';//
// $lang['btcMoney_h'] = '资产流水';//
// $lang['btcMoney_i'] = '资产流水导出';//
// $lang['btcMoney_j'] = '分配方式列表';//
// $lang['btcMoney_k'] = '货币类型列表';//
// $lang['btcMoney_l'] = '收益列表';//
// $lang['btcMoney_m'] = '录入收益页面信息';//
// $lang['btcMoney_n'] = '录入收益';//
// $lang['btcMoney_o'] = '允许分配';//
// $lang['btcMoney_p'] = '分配收益';//
// $lang['btcMoney_q'] = '派币审核';//
// $lang['btcMoney_r'] = '转账';//
// $lang['btcMoney_s'] = '按照时间显示的币总览列表';//
// $lang['btcMoney_g'] = '按照时间查看币资产';//
// $lang['btcMoney_u'] = '按日期获取派发收益信息';//
// $lang['btcMoney_v'] = '生成当天的数据';//
// $lang['btcMoney_w'] = '后台派发币产品列表';//
// $lang['btcMoney_x'] = '后台派发币用户列表';//
// $lang['btcMoney_aa'] = '后台币收益列表导出';//
// $lang['btcMoney_bb'] = '币资产总账户导出';//
// $lang['btcMoney_cc'] = '币资产BTC收益详情导出';//
// $lang['btcMoney_dd'] = '币资产LTC收益详情导出';//
// $lang['btcMoney_ee'] = '根据时间获取对应说明';//

// $lang['order_a'] = '获取订单详情';//
// $lang['order_b'] = '获取订单列表';//
// $lang['order_c'] = '获取订单基础信息';//
// $lang['order_d'] = '获取订单状态';//
// $lang['order_e'] = '订单导出';//

// $lang['deposit_a'] = '托管--列表';//
// $lang['deposit_b'] = '获取BDC名称';//
// $lang['deposit_c'] = '托管--新增';//
// $lang['deposit_d'] = '托管--更新';//
// $lang['deposit_e'] = '托管--删除';//
// $lang['deposit_f'] = 'BDC--列表';//
// $lang['deposit_g'] = '托管审核列表';//
// $lang['deposit_h'] = '托管审核';//
// $lang['deposit_i'] = '托管管理列表';//
// $lang['deposit_j'] = '托管详情';//

// $lang['message_a'] = '消息分类';//
// $lang['message_b'] = '消息列表';//
// $lang['message_c'] = '添加消息模板';//
// $lang['message_d'] = '群发消息';//
// $lang['message_e'] = '消息分类-编辑';//
// $lang['message_f'] = '消息分类-删除';//

// $lang['account_a'] = '数字货币类型列表';//
// $lang['account_b'] = '新增/编辑数字货币类型';//
// $lang['account_c'] = '删除算力类型';//
// $lang['account_d'] = '操作日志列表';//
// $lang['account_e'] = '删除日志';//
// $lang['account_f'] = '电子合同列表';//
// $lang['account_g'] = '电子合同 编辑/新增';//
// $lang['account_h'] = '删除电子合同';//
// $lang['account_i'] = '账户总览';//
// $lang['account_j'] = '退出登录';//

// $lang['config_a'] = '参数管理--列表';//
// $lang['config_b'] = '参数管理--编辑/新增';//
// $lang['config_c'] = '参数管理--删除';//
// $lang['config_d'] = '版本管理--列表';//
// $lang['config_e'] = '版本管理--删除';//
// $lang['config_f'] = '版本管理--新增/编辑';//
// $lang['config_g'] = '关于我们--列表';//
// $lang['config_h'] = '关于我们--更新/新增';//
// $lang['config_i'] = '关于我们--删除';//
// $lang['config_j'] = '新闻资讯分类--列表';//
// $lang['config_k'] = '新闻资讯分类--删除';//
// $lang['config_l'] = '新闻资讯分类--新增/编辑';//

// $lang['operation_a'] = '资讯管理--编辑';//
// $lang['operation_b'] = '资讯管理--列表';//
// $lang['operation_c'] = '资讯管理--删除';//
// $lang['operation_d'] = '资讯管理--新增';//
// $lang['operation_e'] = 'BDC管理--列表';//
// $lang['operation_f'] = 'BDC管理--删除';//
// $lang['operation_g'] = 'BDC管理--新增/编辑';//
// $lang['operation_h'] = '帮助中心管理--列表';//
// $lang['operation_i'] = '帮助中心管理--删除';//
// $lang['operation_j'] = '帮助中心管理--新增/编辑';//
// $lang['operation_k'] = '帮助中心管理--类型';//
// $lang['operation_l'] = 'banner管理/友情链接--列表';//
// $lang['operation_m'] = 'banner管理/友情链接--删除';//
// $lang['operation_n'] = 'banner管理--新增/编辑';//
// $lang['operation_o'] = '友情链接--新增/编辑';//

// $lang['site_a'] = '获取子站基础信息';//
// $lang['site_b'] = '子站管理-新增';//
// $lang['site_c'] = '子站管理-列表';//
// $lang['site_d'] = '子站管理-更新';//
// $lang['site_e'] = '新增域名';//
// $lang['site_f'] = '编辑域名';//
// $lang['site_g'] = '删除域名';//
// $lang['site_h'] = '获取站点信息列表';//
// $lang['site_i'] = '关闭/开启 站点';//
// $lang['site_j'] = '配置基础信息列表';//
// $lang['site_k'] = '子站管理-删除';//

// $lang['invite_a'] = '邀请--列表';//
// $lang['invite_b'] = '邀请--详情';//


// $lang['baoquan_a'] = '保全管理';//

// $lang['opinion_a'] = '意见反馈--列表';//

// $lang['roles_a'] = '获取部门或岗位信息';//
// $lang['roles_b'] = '更新或新增 部门/岗位信息';//
// $lang['roles_c'] = '岗位/部门权限列表';//
// $lang['roles_d'] = '管理员列表';//
// $lang['roles_e'] = '管理员 禁用/启用';//
// $lang['roles_f'] = '管理员 新增/编辑';//
// $lang['roles_g'] = '管理员删除';//
// $lang['roles_h'] = '登陆';//
// $lang['roles_i'] = '修改密码';//
// $lang['roles_j'] = '更新权限';//
// $lang['roles_k'] = '根据站点获取部门/岗位';//
// $lang['roles_l'] = '删除部门/岗位';//






