<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 资产快照、对账
 */
class Checkaccount extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Checkaccount_service');
        $this->load->service('Sys_grpc_service');
        $this->load->service('Transfer_service');

    }

    //平台快照
    public function platform_asset_list(){
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Checkaccount_service->platform_asset_list($offset,$limit,$start_time,$end_time,$asset);
        $count = $this->Checkaccount_service->platform_asset_list_count($start_time,$end_time,$asset);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //平台
    public function platform_asset_list_csv()
    {
        $args = $this->input->post(); 
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $list= $this->Checkaccount_service->platform_asset_list(0,'',$start_time,$end_time,$asset);
        // var_dump($list);die;
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/platform_asset_list'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易系统总额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易系统可用' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易系统冻结' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '冻结资产' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '充值' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '提现' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '活动奖励' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '系统调整' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '系统资产变动' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当日资金变动' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '系统差额' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                $value['snapshot_time'],        
                $value['asset'],        
                $value['total'],        
                $value['available'],        
                $value['freeze'],        
                $value['asset_freeze'],        
                $value['recharge'],        
                $value['withdraw'],        
                $value['trade_fee'],        
                $value['activity_award'],        
                $value['system'],        
                $value['total_change'],        
                $value['day_change'],        
                $value['system_change'],        
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);

        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }


    //资产对账列表接口
    public function Checkaccount_list()
    {
        //获取时间
        $args =$this->input->post();
        // $this->form_validation->set_rules('start_time','开始时间','required');
        // $this->form_validation->set_rules('end_time','结束时间','required');

        // if($this->form_validation->run() == FALSE){
        //     returnJson('402',lang('missing_parameters'));
        // }
        $result = $this->Checkaccount_service->Checkaccount_list($args);
        if(!empty($result)){
            returnJson('200',lang('operation_successful'),$result);
        }
    }

    public function Checkaccount_list_csv()
    {
        //获取时间
        $args =$this->input->post();
        // $this->form_validation->set_rules('stime','开始时间','required');
        // $this->form_validation->set_rules('etime','结束时间','required');

        // if($this->form_validation->run() == FALSE){
        //     returnJson('402',lang('missing_parameters'));
        // }
        $list = $this->Checkaccount_service->Checkaccount_list($args);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/checkaccount'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期初总额'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期末总额'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '资金变动'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期间充值'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期间提币' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期间系统调整' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期间手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期间钱包充值' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期间钱包提现' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                $value['asset'],        
                $value['s_total'],        
                $value['e_total'],        
                $value['total_change'],        
                $value['lj_recharge'],        
                $value['lj_withdraw'],        
                $value['lj_system'],        
                $value['lj_tradefee'],        
                $value['wallet_recharge'],        
                $value['wallet_withdraw'],        
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);

        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 钱包快照
     * User: 张哲
     * Date: 2018/12/18
     * Time: 14:55
     */
//    public function wallet_snapshot()
//    {
//        $args =$this->input->post();
//        $result = $this->Checkaccount_service->checkWalletBalance($args);
//    }

    /**
     * Notes: 快照列表
     * User: 张哲
     * Date: 2018/12/19
     * Time: 16:25
     */
    public function wallet_snapshot_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Checkaccount_service->wallet_snapshot_list($offset,$limit,$start_time,$end_time,$asset);
        $count = $this->Checkaccount_service->wallet_snapshot_list_count($start_time,$end_time,$asset);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 快照列表导出
     * User: 张哲
     * Date: 2018/12/19
     * Time: 16:27
     */
    public function wallet_snapshot_list_csv()
    {
        //获取时间
        $args =$this->input->post();
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $list = $this->Checkaccount_service->wallet_snapshot_list_csv($start_time,$end_time,$asset);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/checkaccount'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '总额'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '余额'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '待归集笔数'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '待归集金额'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '冻结金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '充值笔数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '充值金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '提币笔数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '提币金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '平台充值金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['asset'],
                $value['balance'],
                $value['amount'],
                $value['collectCount'],
                $value['collectAmount'],
                $value['freeze'],
                $value['rechargeCount'],
                $value['rechargeAmount'],
                $value['withdrawCount'],
                $value['withdrawAmount'],
                $value['platFeeAmount'],
                $value['platRechargeAmount'],
                $value['created_at'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);

        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 财务统计》系统对账
     * 交易系统内对账
     * @return 
     */
    public function system_checkamount()
    {
        $args = $this->input->post();
        $start_time = isset($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = isset($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        if($start_time == '' && $end_time == ''){
            $end_time = date('Y-m-d',time());
            $start_time = date('Y-m-d',time()-86400*7);
        }
        if(strtotime($start_time)>strtotime($end_time))
            returnJson('402',lang('operation_failed'));
        
        $asset = isset($args['asset']) ? $args['asset'] : '';
        $list = $this->Checkaccount_service->system_checkamount($start_time,$end_time,$asset);

        returnJson('200',lang('operation_successful'),$list);
    }


    public function system_checkamount_csv()
    {
        $args = $this->input->post();
        $start_time = isset($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = isset($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        if($start_time == '' && $end_time == ''){
            $end_time = date('Y-m-d',time());
            $start_time = date('Y-m-d',time()-86400*7);
        }
        if(strtotime($start_time)>strtotime($end_time))
            returnJson('402',lang('operation_failed'));
        
        $asset = isset($args['asset']) ? $args['asset'] : '';
        $list = $this->Checkaccount_service->system_checkamount($start_time,$end_time,$asset);

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/sys_checkaccount'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期初'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '期末'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '资产变动'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '充值'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '提币' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '资金调整' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '活动收支' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '差值' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '提币金额' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '手续费' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '平台充值金额' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['asset'],
                $value['s_total'],
                $value['e_total'],
                $value['difference'],
                $value['recharge'],
                $value['withdraw'],
                $value['trade_fee'],
                $value['system'],
                $value['activity_award'],
                $value['cha'],
                // $value['withdrawAmount'],
                // $value['platFeeAmount'],
                // $value['platRechargeAmount'],
                // $value['created_at'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);

        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);

        returnJson('200',lang('operation_successful'),$list);
    }

    //子站手续费结算列表(月结)
    public function settlement_list()
    {
        $thismonth = date('m');
        $thisyear = date('Y');
        if ($thismonth == 1) {
           $lastmonth = 12;
           $lastyear = $thisyear - 1;
       } else {
           $lastmonth = $thismonth - 1;
           $lastyear = $thisyear;
       }
       $lastStartDay = $lastyear . '-' . $lastmonth . '-1';
       $lastEndDay = $lastyear . '-' . $lastmonth . '-' . date('t', strtotime($lastStartDay));
        $b_time = strtotime($lastStartDay);//上个月的月初时间戳
        $e_time = strtotime($lastEndDay); 

        $admin_id = $this->user_id;

        $args = $this->input->post();
        $asset = isset($args['asset']) ? $args['asset'] : '';
        $site_id = isset($args['site_id']) ? $args['site_id'] : '';
        $month = isset($args['month']) ? $args['month'] : '';//月份 string类型 格式：'2019-03'

        $list = $this->Checkaccount_service->settlement_list($month,$admin_id,$asset,$site_id);
        if(count($list)>0){
            returnJson('200',lang('operation_successful'),$list);
        }else{
            returnJson('402',lang('operation_failed'),$list);
        }
        
    }

    //子站手续费结算列表(日结)
    public function day_settlement_list()
    {
        $admin_id = $this->user_id;
        $args = $this->input->post();
        $asset = isset($args['asset']) ? $args['asset'] : '';
        $site_id = isset($args['site_id']) ? $args['site_id'] : '';
        $day = isset($args['day']) ? $args['day'] : '';//日期 string类型 格式：'2019-03-01'

        $list = $this->Checkaccount_service->day_settlement_list($day,$admin_id,$asset,$site_id);
        if(count($list)>0){
            returnJson('200',lang('operation_successful'),$list);
        }else{
            returnJson('402',lang('operation_failed'),$list);
        }
        
    }

    public function settlement_list_csv()
    {
        $thismonth = date('m');
        $thisyear = date('Y');
        if ($thismonth == 1) {
           $lastmonth = 12;
           $lastyear = $thisyear - 1;
       } else {
           $lastmonth = $thismonth - 1;
           $lastyear = $thisyear;
       }
       $lastStartDay = $lastyear . '-' . $lastmonth . '-1';
       $lastEndDay = $lastyear . '-' . $lastmonth . '-' . date('t', strtotime($lastStartDay));
        $b_time = strtotime($lastStartDay);//上个月的月初时间戳
        $e_time = strtotime($lastEndDay); 
        
        $admin_id = $this->user_id;

        $args = $this->input->post();
        $asset = isset($args['asset']) ? $args['asset'] : '';
        $site_id = isset($args['site_id']) ? $args['site_id'] : '';
        $month = isset($args['month']) ? $args['month'] : '';//月份 string类型 格式：'2019-03'

        $list = $this->Checkaccount_service->settlement_list($month,$admin_id,$asset,$site_id);

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/settlement'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '结算区间'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易手续费'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '提币手续费'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '结算比例'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '应结手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '是否已经结算' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['name'] ),
                $value['settlement_time'],
                $value['asset'],
                $value['t_fee'],
                $value['w_fee'],
                $value['settlement_percent'],
                $value['settlement_fee'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['status_m'] ),
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);

        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 日结手续费结算导出
     * @return [type] [description]
     */
    public function day_settlement_list_csv()
    {
        $admin_id = $this->user_id;
        $args = $this->input->post();
        $asset = isset($args['asset']) ? $args['asset'] : '';
        $site_id = isset($args['site_id']) ? $args['site_id'] : '';
        $day = isset($args['day']) ? $args['day'] : '';//日期 string类型 格式：'2019-03-01'

        $list = $this->Checkaccount_service->day_settlement_list($day,$admin_id,$asset,$site_id);

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/settlement'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '结算区间'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易手续费'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '提币手续费'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '结算比例'),
            iconv( 'UTF-8', 'GB2312//IGNORE', '应结手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '是否结算' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['name'] ),
                $value['settlement_time'],
                $value['asset'],
                $value['t_fee'],
                $value['w_fee'],
                $value['settlement_percent'],
                $value['settlement_fee'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['status_m'] ),
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);

        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 手续费结账，相当于转账
     * @return [type] [description]
     */
    public function settlement()
    {
        $args = $this->input->post();
        
        if($this->Checkaccount_service->settlement($args)===true){
            returnJson('200',lang('Transfer successful'));
        }else{
            returnJson('403',lang('Transfer failed'));
        }
    }

    /**
     * 手续费结账，相当于转账
     * @return [type] [description]
     */
    public function day_settlement()
    {
        $args = $this->input->post();
        
        if($this->Checkaccount_service->day_settlement($args)===true){
            returnJson('200',lang('Transfer successful'));
        }else{
            returnJson('403',lang('Transfer failed'));
        }
    }

    /**
     * 批量日结手续费
     */
    
    public function day_settlement_all()
    {
        $args = $this->input->post();
        if($this->Checkaccount_service->day_settlement_all($args)===true){
            returnJson('200',lang('Transfer successful'));
        }else{
            returnJson('403',lang('Transfer failed'));
        }
    }


    //校验转账
    public function check_balance()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('transfer_out_uid','转出用户id','required');
        $this->form_validation->set_rules('asset','币种','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $transfer_out_uid = isset($args['transfer_out_uid']) ? $args['transfer_out_uid'] : '';
        $asset = isset($args['asset']) ? $args['asset'] : '';

        $data = $this->Transfer_service->check_balance($transfer_out_uid,$asset);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 结算记录列表
     * @return [type] [description]
     */
    public function settlement_record_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Checkaccount_service->settlement_record_list($start_time,$end_time,$offset,$limit,$asset);
        $count = $this->Checkaccount_service->settlement_record_list_count($start_time,$end_time,$asset);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);

    }

    public function settlement_record_list_csv()
    {
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $list = $this->Checkaccount_service->settlement_record_list($start_time,$end_time,$offset,$limit,$asset);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/settlement_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '转出账户uid' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '转入账户uid' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '操作人' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['asset'],
                $value['transfer_out_uid'],
                $value['transfer_in_uid'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['true_name'] ),
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * 结算记录列表
     * @return [type] [description]
     */
    public function day_settlement_record_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Checkaccount_service->day_settlement_record_list($start_time,$end_time,$offset,$limit,$asset);
        $count = $this->Checkaccount_service->day_settlement_record_list_count($start_time,$end_time,$asset);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);

    }

    public function day_settlement_record_list_csv()
    {
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $list = $this->Checkaccount_service->day_settlement_record_list($start_time,$end_time,0,'',$asset);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/settlement_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '转出账户uid' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '转入账户uid' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '操作人' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['asset'],
                $value['transfer_out_uid'],
                $value['transfer_in_uid'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['true_name'] ),
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * 平台收支利润表（交易产生手续费+活动收入+活动支出）
     */
    public function platform_balacne_payment()
    {
        $args = $this->input->post();
        // $start_time = '2019-05-21';
        $start_time = isset($args['start_time']) ? $args['start_time'] : '';
        // $ent_time = '2019-05-23';
        $end_time = isset($args['end_time']) ? $args['end_time'] : '';
        if($start_time == '')
            $start_time = date('Y-m-d',strtotime(date('Y-m-d',time()-86400)));

        if($end_time == '')
            $end_time = date('Y-m-d',strtotime(date('Y-m-d',time())));

        $list = $this->Checkaccount_service->platform_balacne_payment($start_time,$end_time);
        returnJson('200',lang('operation_successful'),$list);
    }
    /**
     * 平台收支每日明细
     * @return [type] [description]
     */
    public function platform_balacne_payment_detail()
    {
        $args = $this->input->post();
        // $time_area = '2019-05-21 00:00:00';
        $time_area = $args['time_area'];
        $list = $this->Checkaccount_service->platform_balacne_payment_detail($time_area);
        returnJson('200',lang('operation_successful'),$list);
    }
    
}
