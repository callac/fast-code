<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-06-24
 * Time: 16:37
 */

class Push extends Web_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->service('Push_service');
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019-06-25
     * Time: 09:37
     */
    public function push()
    {
        $this->form_validation->set_rules('id', 'ID', 'required');
        if ($this->form_validation->run() == FALSE) {
            returnJson('402', lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Push_service->push($args);
        if ($res === false) {
            returnJson('402', lang('operation_failed'));
        } else {
            returnJson('200', lang('operation_successful'));
        }
    }

    /**
     * Notes: 推送通知列表
     * User: 张哲
     * Date: 2019-06-25
     * Time: 09:51
     */
    public function push_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $title = isset($args['title']) ? $args['title'] : ''; //标题
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Push_service->push_list($offset, $limit, $start_time, $end_time,$title,$site_id);
        $count = $this->Push_service->push_count( $start_time, $end_time,$title,$site_id);
        $data['total'] = $count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($count / $limit);
        returnJson('200', lang('operation_successful'), $data);
    }

    /**
     * Notes: 新增编辑推送
     * User: 张哲
     * Date: 2019-06-25
     * Time: 10:11
     */
    public function push_add()
    {
        $this->form_validation->set_rules('title', '标题', 'required');
        $this->form_validation->set_rules('site_id', '站点', 'required');
        if ($this->form_validation->run() == FALSE) {
            returnJson('402', lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Push_service->push_add($args);
        if ($res === false) {
            returnJson('402', lang('operation_failed'));
        } else {
            returnJson('200', lang('operation_successful'));
        }
    }

    public function push_delete()
    {
        $this->form_validation->set_rules('id','ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args = $this->input->post();
        $res = $this->Push_service->push_delete($args);
        if($res === false){
            returnJson('402',lang('operation_failed'));
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
}