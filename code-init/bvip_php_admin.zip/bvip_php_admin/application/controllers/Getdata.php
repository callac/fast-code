<?php
defined('BASEPATH') OR exit('No direct script access allowed');
set_time_limit(0);

class Getdata extends Base_Controller
{
    public $zt_exchange_db;

    public $zt_tradehistory_db;

    public $local_exchange_db;

    public $local_tradehistory_db;

    function __construct() {
        //初始化数据库连接对象
        parent::__construct();
        //真机环境
        $this->exchange = $this->load->database('default',true); 
        $this->tradehistory = $this->load->database('trade_history',true);
        $this->local_exchange = $this->load->database('default',true);
        $this->trade_log = $this->load->database('trade_log',true);
        $this->otc_trade = $this->load->database('otc_trade',true);
        // $this->activity = $this->load->database('activity',true);
        $this->activity = TRUE;
        
        //ZT线上环境
        // $this->exchange = $this->load->database('zt_exchange_onlyread',true);
        // $this->tradehistory = $this->load->database('zt_tradehistory_onlyread',true);
        // $this->exchange = $this->load->database('zt_exchange_onlyread',true);



         
        //本地环境
        // $this->exchange = $this->load->database('local_exchange',true); 
        // $this->tradehistory = $this->load->database('local_trade_history',true);
        // $this->local_exchange = $this->load->database('local_exchange',true);

        $this->load->service('Getdata_service');
    }

    /**
     * recycle循环统计方法
     * @return [type] [description]
     */
    public function recycle_method_curl()
    {
        $args = $this->input->get();
        // var_dump($args['method']);die;
        if((isset($args['method']) ? trim($args['method']) : FALSE) === FALSE) returnJson('403','missing_parameters1');
        if((isset($args['ctime']) ? trim($args['ctime']) : FALSE) === FALSE) returnJson('403','missing_parameters2');
        if((isset($args['etime']) ? trim($args['etime']) : FALSE) === FALSE) returnJson('403','missing_parameters3');
        // if((isset($args['site_id']) ? trim($args['site_id']) : FALSE) === FALSE) returnJson('403','missing_parameters4');
        
        // $site_id = $args['site_id'];
        $method =$args['method'];
        $ctime =strtotime($args['ctime']);
        $etime =strtotime($args['etime']);

        $url = 'http://localhost:9085/index.php/getdata/'.$method;

        $arr = get_timearea_by_day($ctime,$etime);
        
        for($i=0;$i<count($arr);$i++)
        {
            $params = '?time='.date('Y-m-d H:i:s',$arr[$i]);
            $get_url = $url.$params;
            // var_dump($get_url);die;
            $ch = curl_init();
            // 设置请求为post类型
            curl_setopt($ch, CURLOPT_POST, 0);
            // 2. 设置请求选项, 包括具体的url
            curl_setopt($ch, CURLOPT_URL, $get_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            // 3. 执行一个cURL会话并且获取相关回复
            $response = curl_exec($ch);
            curl_close($ch);
        }
    }


    /**
     * 去重数据写入数据库
     * @return 
     */
    function deduplication_data()
    {
        // echo 11;die;
        $args = $this->input->get();
        $this->Getdata_service->deduplication_data($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }
    
    function usertotal()
    {
        $args = $this->input->get();
        $this->Getdata_service->usertotal($args,$this->zt_exchange_db,$this->zt_tradehistory_db,$this->local_exchange);
    }
    //币币交易（真实的币币交易数据，去除配置中存在的机器人，作市方）
    function tradetotal()
    {
        $args = $this->input->get();
        $this->Getdata_service->tradetotal($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }
    //币币交易（所有币币交易数据，包括机器人，作市方）
    function tradetotal_all()
    {
        $args = $this->input->get();
        $this->Getdata_service->tradetotal_all($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }


    function tradetotal_test()
    {

        $args = $this->input->get();
        $this->Getdata_service->tradetotal_test($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }


    function recharge_logs_csv()
    {
        $args = $this->input->get();
        $this->Getdata_service->rechargelogs($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }

    function user_withdraw_csv()
    {
        $args = $this->input->get();
        $this->Getdata_service->withdrawlogs($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }

    function deal_fee()
    {
        $args = $this->input->get();
        $args['jyq'] = $this->config->item('trade_area');
        $data = $this->Getdata_service->deal_fee($args,$this->exchange,$this->tradehistory);
        returnJson('200',lang('operation_successful'),$data);
    }

    function get_payment()
    {
        $args = $this->input->get();
        $this->Getdata_service->get_payment($args,$this->exchange,$this->activity);
    }

    

    function data_text()
    {
        $args = $this->input->get();
        $result = $this->Getdata_service->data_text($args,$this->exchange,$this->tradehistory,$this->trade_log,$this->otc_trade);
        //获取平台资产统计
        $similar_com_one = '';
        
            $similar_com_one .= "<tr>";
            $similar_com_one.="<td>当日</td>";
            $similar_com_one.="<td>{$result['qcdata']['register_amount']}</td>";
            $similar_com_one.="<td>{$result['qcdata']['trunname_amount']}</td>";
            $similar_com_one.="<td>{$result['qcdata']['invite_register_amount']}</td>";
            $similar_com_one.="<td>{$result['qcdata']['c2c_trade_amount']}</td>";
            $similar_com_one.="<td>{$result['qcdata']['coin_trade_amount']}</td>";
            $similar_com_one.="<td>{$result['qcdata']['otc_trade_amount']}</td>";
            $similar_com_one.="<td>{$result['qcdata']['recharge_amount']}</td>";
            $similar_com_one.="<td>{$result['qcdata']['withdraw_amount']}</td>";
            $similar_com_one.= "</tr>";

        $similar_com_all = '';
        
            $similar_com_all .= "<tr>";
            $similar_com_all.="<td>累计</td>";
            $similar_com_all.="<td>{$result['qcdata']['register_total']}</td>";
            $similar_com_all.="<td>{$result['qcdata']['trunname_total']}</td>";
            $similar_com_all.="<td>{$result['qcdata']['invite_register_total']}</td>";
            $similar_com_all.="<td>{$result['qcdata']['c2c_trade_total']}</td>";
            $similar_com_all.="<td>{$result['qcdata']['coin_trade_total']}</td>";
            $similar_com_all.="<td>{$result['qcdata']['otc_trade_total']}</td>";
            $similar_com_all.="<td>{$result['qcdata']['recharge_total']}</td>";
            $similar_com_all.="<td>{$result['qcdata']['withdraw_total']}</td>";
            $similar_com_all.= "</tr>";
        
        $platform_balance = '';
        if($result['platform_balance'] != '')
        {
            for($i=0;$i<count($result['platform_balance']);$i++)
            {
                $platform_balance .= "<tr>";
                $platform_balance.="<td>{$result['platform_balance'][$i]['asset']}</td>";
                $platform_balance.="<td>{$result['platform_balance'][$i]['balance']}</td>";
                $platform_balance.="<td>{$result['platform_balance'][$i]['tran_balance']}</td>";
                $platform_balance.= "</tr>";
            }
        }
        

        $user_platform_balance = '';
        if($result['user_platform_balance']!=''){
            for($i=0;$i<count($result['user_platform_balance']);$i++)
            {
                $user_platform_balance .= "<tr>";
                $user_platform_balance.="<td>{$result['user_platform_balance'][$i]['asset']}</td>";
                $user_platform_balance.="<td>{$result['user_platform_balance'][$i]['916']}</td>";
                $user_platform_balance.="<td>{$result['user_platform_balance'][$i]['1081115']}</td>";
                $user_platform_balance.="<td>{$result['user_platform_balance'][$i]['1088016']}</td>";
                $user_platform_balance.="<td>{$result['user_platform_balance'][$i]['33']}</td>";
                $user_platform_balance.="<td>{$result['user_platform_balance'][$i]['1100035']}</td>";
                $user_platform_balance.= "</tr>";
            }
        }

        //币币统计new_coin_total
        $new_coin_total = '';
        if($result['new_coin_total']!=''){
            for($i=0;$i<count($result['new_coin_total']);$i++)
            {
                $new_coin_total.= "<tr>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['asset']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['system']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['true_amount']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['true_money']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['recharge']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['withdraw']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['operation_in']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['operation_out']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['transfer_in']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['transfer_out']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['fee']}</td>";
                $new_coin_total.="<td>{$result['new_coin_total'][$i]['price']}</td>";
                $new_coin_total.= "</tr>";
            }
        }
        
        //otc统计
        $otc_data_result = '';
        if($result['otc_data_result']!=''){
            for($i=0;$i<count($result['otc_data_result']);$i++)
            {
                $otc_data_result.= "<tr>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['asset']}</td>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['total']}</td>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['true_amount']}</td>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['true_money']}</td>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['buy']}</td>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['sell']}</td>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['transfer_in']}</td>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['transfer_out']}</td>";
                $otc_data_result.="<td>{$result['otc_data_result'][$i]['fee']}</td>";
                $otc_data_result.= "</tr>";
            }
        }


        // $user_ids = '';
        // if($result['user_ids']!=''){
        //     for($i=0;$i<count($result['user_ids']);$i++)
        //     {
        //         $user_ids.="<td>{$user_ids['user_ids'][$i]['asset']}</td>";
        //     }
        // }

        

        $new_otc_data = '';
        for($i=0;$i<count($result['new_otc_data']);$i++)
        {
            $new_otc_data .= "<tr>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['asset']}</td>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['buy_amount']}</td>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['buy_amount_cny']}</td>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['buy_number']}</td>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['buy_people']}</td>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['sell_amount']}</td>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['sell_amount_cny']}</td>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['sell_number']}</td>";
            $new_otc_data.="<td>{$result['new_otc_data'][$i]['sell_people']}</td>";
            $new_otc_data.= "</tr>";
        }

        $tradedata = '';
        for($i=0;$i<count($result['trade_data']);$i++)
        {
            $tradedata .= "<tr>";
            $tradedata.="<td>{$result['trade_data'][$i]['symbols']}</td>";
            $tradedata.="<td>{$result['trade_data'][$i]['unit_price']}</td>";
            $tradedata.="<td>{$result['trade_data'][$i]['people']}</td>";
            $tradedata.="<td>{$result['trade_data'][$i]['trading_number']}</td>";
            $tradedata.="<td>{$result['trade_data'][$i]['trading_amount']}</td>";
            $tradedata.="<td>{$result['trade_data'][$i]['BID_fee']}</td>";
            $tradedata.="<td>{$result['trade_data'][$i]['ASK_fee']}</td>";
            $tradedata.="<td>{$result['trade_data'][$i]['per_trading_amount']}</td>";
            $tradedata.= "</tr>";
        }

        // $otc_fee = '';
        // for($i=0;$i<count($result['otc_fee']);$i++)
        // {
        //     $otc_fee .= "<tr>";
        //     $otc_fee.="<td>{$result['otc_fee'][$i]['asset']}</td>";
        //     $otc_fee.="<td>{$result['otc_fee'][$i]['fee']}</td>";
        //     $otc_fee.="<td>{$result['otc_fee'][$i]['in_cny']}</td>";
        //     $otc_fee.= "</tr>";
        // }

        $trade_fee = '';
        for($i=0;$i<count($result['trade_fee']);$i++)
        {
            $trade_fee .= "<tr>";
            $trade_fee.="<td>{$result['trade_fee'][$i]['asset']}</td>";
            $trade_fee.="<td>{$result['trade_fee'][$i]['fee']}</td>";
            $trade_fee.="<td>{$result['trade_fee'][$i]['in_cny']}</td>";
            $trade_fee.= "</tr>";
        }

        $chongti_day = '';
        for($i=0;$i<count($result['chongti_day']);$i++)
        {
            $chongti_day .= "<tr>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['asset']}</td>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['recharge_total']}</td>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['per_recharge_amount']}</td>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['recharge_number']}</td>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['withdraw_total']}</td>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['per_withdraw_amount']}</td>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['withdraw_number']}</td>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['in']}</td>";
            $chongti_day.="<td>{$result['chongti_day'][$i]['in_cny']}</td>";
            $chongti_day.= "</tr>";
        }

        $chongti_all = '';
        for($i=0;$i<count($result['chongti_all']);$i++)
        {
            $chongti_all .= "<tr>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['asset']}</td>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['recharge_total']}</td>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['per_recharge_amount']}</td>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['recharge_number']}</td>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['withdraw_total']}</td>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['per_withdraw_amount']}</td>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['withdraw_number']}</td>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['in']}</td>";
            $chongti_all.="<td>{$result['chongti_all'][$i]['in_cny']}</td>";
            $chongti_all.= "</tr>";
        }

        $correct_balance_data = '';
        for($i=0;$i<count($result['correct_balance_data']);$i++)
        {
            $correct_balance_data .= "<tr>";
            $correct_balance_data.="<td>{$result['correct_balance_data'][$i]['user_id']}</td>";
            $correct_balance_data.="<td>{$result['correct_balance_data'][$i]['asset_code']}</td>";
            $correct_balance_data.="<td>{$result['correct_balance_data'][$i]['amount']}</td>";
            $correct_balance_data.="<td>{$result['correct_balance_data'][$i]['extra']}</td>";
            $correct_balance_data.="<td>{$result['correct_balance_data'][$i]['created_time']}</td>";
            $correct_balance_data.="<td>{$result['correct_balance_data'][$i]['true_name']}</td>";
            $correct_balance_data.= "</tr>";
        }

        $new_symbols = '';
        for($i=0;$i<count($result['new_symbols']);$i++)
        {
            $new_symbols .= "<tr>";
            $new_symbols.="<td style=>{$result['new_symbols'][$i]['symbol']}</td>";
            $new_symbols.="<td style=>{$result['new_symbols'][$i]['true_name']}</td>";
            $new_symbols.="<td style=>{$result['new_symbols'][$i]['created_at']}</td>";
            $new_symbols.= "</tr>";
        }
        $content = "
        <div>{$result['time']}日数据</div>
        <style type='text/css'>
            table tr td{
                text-align:center;
                border-right:1px solid #000;
                text-align:center;
                padding:2px 10px;
                border-bottom:1px solid #000;
                margin:0;
            }
            table tr td:last-child{
                border-right:none;
            }

            table {
                text-align:center;
                border:1px solid #000;
                text-align:center;
                border-spacing:0;
                border-bottom:none;
            }

            div {
                font-weight:600;
            }            
        </style>
        <div>用户</div>
        <table>
            <tr>
                <td>时间</td><td>注册人数</td><td>实名人数</td><td>被邀请注册数</td><td>C2C交易人数</td><td>币币交易人数</td><td>OTC交易人数</td><td>充值人数</td><td>提现人数</td>
            </tr>
            {$similar_com_one}
            {$similar_com_all}
        </table>
        <br>
        <div>平台资产统计（截至{$result['time_area_end']}）</div>
        <table style='text-align:center'>
            <tr>
                <td>币种</td><td>数量</td><td>折合</td>
            </tr>
            {$platform_balance}
        </table>
        

        <br>
        <div>币币统计（截至{$result['time_area_end']}）</div>
        <table style='text-align:center'>
            <tr>
                <td>资产</td><td>账面数量</td><td>真实数量</td><td>真实数量折合</td><td>充值</td><td>提现</td><td>人工调账增加</td><td>人工调账减少</td><td>OTC转入</td><td>OTC转出</td><td>手续费</td><td>对应价格</td>
            </tr>
            {$new_coin_total}
        </table>

        <br>
        <div>OTC统计（截至{$result['time_area_end']}）</div>
        <table style='text-align:center'>
            <tr>
                <td>资产</td><td>账面数量</td><td>真实数量</td><td>真实数量折合</td><td>买入</td><td>卖出</td><td>转入</td><td>转出</td><td>手续费</td>
            </tr>
            {$otc_data_result}
        </table>
        

        <br>
        <div>当日OTC统计</div>
        <table style='text-align:center'>
            <tr>
                <td>资产</td><td>买入数量</td><td>买入人民币折合</td><td>买入笔数</td><td>买入人数</td><td>卖出数量</td><td>卖出人民币折合</td><td>卖出笔数</td><td>卖出人数</td>
            </tr>
            {$new_otc_data}
        </table>
        
        <br>
        <div>当日币币交易手续费（剔除后台配置账户）</div>
        <table style='text-align:center'>
            <tr>
                <td>币种</td><td>手续费</td><td>手续费折合</td>
            </tr>
            {$trade_fee}
        </table>

        <br>
        <div>当日币币交易(剔除后台配置账户)</div>
        <table style='text-align:center'>
            <tr>
                <td>市场</td><td>交易总量</td><td>交易人次</td><td>交易笔数</td><td>交易金额</td><td>BID买入手续费</td><td>ASK卖出手续费</td><td>人均交易额</td>
            </tr>
            {$tradedata}
        </table>

        <br>
        <div>当日充提</div>
        <table style='text-align:center'>
            <tr>
                <td>币种</td><td>24h充值数量</td><td>人均充值数量</td><td>充值笔数</td><td>24h提币数量</td><td>人均提币数量</td><td>提币笔数</td><td>资金净流入</td><td>资金净流入折合</td>
            </tr>
            {$chongti_day}
        </table>

        <br>
        <div>历史充提</div>
        <table style='text-align:center'>
            <tr>
                <td>币种</td><td>充值数量</td><td>人均充值数量</td><td>充值笔数</td><td>提币数量</td><td>人均提币数量</td><td>提币笔数</td><td>资金净流入</td><td>资金净流入折合</td>
            </tr>
            {$chongti_all}
        </table>

        <br>
        <div>账号资金监控（{$result['time_area_end']}）</div>
        <table style='text-align:center'>
            <tr>
                <td>币种</td><td>陈蕾(916)</td><td>活动账户(1081115)</td><td>博士账户(1088016)</td><td>孔方(33)</td><td>做市账户(1100035)</td>
            </tr>
            {$user_platform_balance}
        </table>

        <br>
        <div>当日人工调账记录</div>
        <table style='text-align:center'>
            <tr>
                <td>用户ID</td><td>币种</td><td>金额</td><td>备注</td><td>时间</td><td>操作人</td>
            </tr>
            {$correct_balance_data}
        </table>

        <br>
        <div>当日新增交易对</div>
        <table style='text-align:center'>
            {$new_symbols}
        </table>
        ";
        
        // echo $content;die;
        $is_send = $this->Getdata_service->send_email($content,$result['time']);
        if($is_send){
            echo '邮件已发出';
            $this->Getdata_service->add_admin_sendemail($content);
        }

        





    }

    /**
     * 新增资产统计,定时任务生成每一天的。
     * time：2019-08-20
     */
    public function newassetstatistics()
    {
        $args = $this->input->get();
        $start_time = strtotime(date('Y-m-d',$_SERVER['REQUEST_TIME']))-86400;
        $end_time = strtotime(date('Y-m-d',$_SERVER['REQUEST_TIME']));
        $data= $this->Getdata_service->newassetstatistics($args,$this->exchange,$this->trade_log);
    }
}
