<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-05-21
 * Time: 09:26
 */

class  Knowledge_base extends Web_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->service('Knowledge_base_service');
    }

    /**
     * Notes: 知识库列表
     * User: 张哲
     * Date: 2019-05-21
     * Time: 10:13
     */
    public function knowledge_base_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $title = $args['title']; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Knowledge_base_service->knowledge_base_list($offset, $limit,$title);
        $count = $this->Knowledge_base_service->knowledge_base_count();
        $data['total'] = $count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($count / $limit);
        returnJson('200', lang('operation_successful'), $data);
    }

    /**
     * Notes: 知识库编辑
     * User: 张哲
     * Date: 2019-04-02
     * Time: 15:33
     */
    public function knowledge_base_add()
    {
        $this->form_validation->set_rules('title', '标题', 'required');
        $this->form_validation->set_rules('content', '内容', 'required');
        if ($this->form_validation->run() == FALSE) {
            returnJson('402', lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Knowledge_base_service->knowledge_base_add($args);
        if ($res === false) {
            returnJson('402', lang('operation_failed'));
        } else {
            returnJson('200', lang('operation_successful'));
        }
    }

    /**
     * Notes: 知识库删除
     * User: 张哲
     * Date: 2019-05-21
     * Time: 10:15
     */
    public function knowledge_base_delete()
    {
        $this->form_validation->set_rules('id','ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args = $this->input->post();
        $res = $this->Knowledge_base_service->knowledge_base_delete($args);
        if($res === false){
            returnJson('402',lang('operation_failed'));
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }

}