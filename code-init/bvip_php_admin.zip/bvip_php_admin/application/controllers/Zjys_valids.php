<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 /**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_valids extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_valids_service');
    }

   /**
    * 充值新的写法加搜索
    * @Author   张哲
    * @DateTime 2018-04-18
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type] [description]
    */
   public function valids_list(){
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词（对应表中extra）
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $type = isset($args['type']) ? $args['type'] : null; //手机验证码 OR 邮箱验证码
        $use_type = isset($args['user_type']) ? $args['user_type'] : null; //用途
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_valids_service->valids_list($offset,$limit,$name,$start_time,$end_time,$type,$use_type,$site_id);
        $count = $this->Zjys_valids_service->valids_list_count($name,$start_time,$end_time,$type,$use_type,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 充值详情
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function recharge_details(){        
        $data =$this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }        
        $res = $this->Zjys_valids_service->recharge_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }


   /**
     * 初步审核详情
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function recharge_verify_details(){        
        $data =$this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }        
        $res = $this->Zjys_valids_service->recharge_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }



   /**
     * 再次审核详情
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function recharge_sure_verify_details(){        
        $data =$this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }        
        $res = $this->Zjys_valids_service->recharge_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }


   /**
     * 充值初次审核
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @return   status状态：1通过  3是审核失败
     * 需要参数：id，status
     */
   public function recharge_verify(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }    
        $result = $this->Zjys_valids_service->recharge_verify($id,$status);        
        returnJson('200',lang('operation_successful'),$result);
   }


   /**
     * 充值再次审核
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   status状态：2是审核通过  3是审核失败
     * 需要参数：id，status
     */
   public function recharge_sure_verify(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }    
        $result = $this->Zjys_valids_service->recharge_verify($id,$status);        
        returnJson('200',lang('operation_successful'),$result);
   }


    /**
     * 充值数据导出
     * @Author   张哲
     * @DateTime 2018-04-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function print_recharge_excel(){
        $args =$this->input->post();
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点id
        $start_time = isset($args['start_time']) ? intval($args['start_time']) : ''; //注册开始时间
        $end_time = isset($args['end_time']) ? intval($args['end_time']) : ''; //注册结束时间
        $status = isset($args['status']) ? $args['status'] : 'all'; //状态
        $list = $this->Zjys_valids_service->recharge_list(0,'',$name,$start_time,$end_time,$site_id,$status);
        // var_dump($list);die;
        if(empty($list))
        {
          $data['url'] = false;
          returnJson('200',lang('operation_successful'),$data);
        }

        $arr = array();

        foreach ($list as $key => $val){
          $arr[$key]['user_account'] = $val['user_account'];
          $arr[$key]['truename'] = $val['truename'];
          $arr[$key]['amount'] = $val['amount'];
          $arr[$key]['pay_time'] = $val['pay_time'];
          $arr[$key]['pay_way'] = $val['pay_way'];
          $arr[$key]['bank_num'] = $val['bank_num'];
          $arr[$key]['request_id'] = $val['request_id'];
          $arr[$key]['status_type'] = $val['status_type'];
          $arr[$key]['site_name'] = $val['site_name'];
        }
        $title = array('账号','姓名', '充值金额','提交时间', '充值方式', '卡号','流水号','当前状态','充值站点');
        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);
    }


   // /**
   //   * 提现列表
   //   * @Author   张哲
   //   * @DateTime 2018-03-28
   //   * @createby SublimeText3
   //   * @return   [type]       [description]
   //   * 需要参数：page,limit
   //   */
   // public function withdraw_list(){
   //      $data = $this->input->post(); 
   //      if(!isset($data['page']) && empty($data['page'])){
   //          $data['page'] = 1;
   //      }
   //      if(!isset($data['limit']) && empty($data['limit'])){
   //          $data['limit'] = 10;
   //      }
   //      $res = $this->Zjys_valids_service->withdraw_list();
   //      $count = $this->Zjys_valids_service->withdraw_list_count();
   //      $result = array('list'=>$res,'count'=>$count,'pageSize'=>$data['limit'],'curPage'=>$data['page'],'totalPage'=>ceil($count/$data['limit']));
   //      returnJson('200',lang('operation_successful'),$result);
   // }


   /**
    * 提现新的写法加搜索
    * @Author   张哲
    * @DateTime 2018-04-18
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type]       [description]
    */
   // public function withdraw_list(){
   //  echo 44;die;
   //      $args =$this->input->post();
   //      $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
   //      $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
   //      $name = isset($args['name']) ? $args['name'] : ''; //关键词
   //      $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
   //      $status = isset($args['status']) ? $args['status'] : 'all'; //状态
   //      $start_time = isset($args['start_time']) ? strtotime($args['start_time']) : ''; //开始时间
   //      $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : ''; //结束时间
   //      $offset = ($page - 1) * $limit;
   //      $data['list']= $this->Zjys_valids_service->withdraw_list($offset,$limit,$name,$start_time,$end_time,$site_id,$status);
   //      $count = $this->Zjys_valids_service->withdraw_list_count($name,$start_time,$end_time,$site_id,$status);
   //      $data['total']=$count;
   //      $data['pageSize']=$limit;
   //      $data['curPage']=$page;
   //      $data['totalPage']=ceil($count/$limit);
   //      returnJson('200',lang('operation_successful'),$data);
   //  }


    /**
     * 提现数据导出
     * @Author   张哲
     * @DateTime 2018-04-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function print_withdraw_excel(){
        $args =$this->input->post();
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点id
        $start_time = isset($args['start_time']) ? intval($args['start_time']) : ''; //注册开始时间
        $end_time = isset($args['end_time']) ? intval($args['end_time']) : ''; //注册结束时间
        $status = isset($args['status']) ? $args['status'] : 'all'; //状态
        $list = $this->Zjys_valids_service->withdraw_list(0,'',$name,$start_time,$end_time,$site_id,$status);
        if(empty($list))
        {
          $data['url'] = false;
          returnJson('200',lang('operation_successful'),$data);
        }
        $arr = array();
        foreach ($list as $key => $val){
          $arr[$key]['user_account'] = $val['user_account'];
          $arr[$key]['truename'] = $val['truename'];
          $arr[$key]['bank'] = $val['bank'];
          $arr[$key]['pay_time'] = $val['pay_time'];
          $arr[$key]['serial_number'] = $val['serial_number'];
          $arr[$key]['account'] = $val['account'];
          $arr[$key]['amount'] = $val['amount'];
          $arr[$key]['fee'] = $val['fee'];
          $arr[$key]['money'] = $val['money'];
          $arr[$key]['status_type'] = $val['status_type'];
          $arr[$key]['site_name'] = $val['site_name'];
        }
        $title = array('账号','姓名','收款人开户行','提现时间', '流水号', '收款人账号','提现金额','手续费','到账金额','状态','提现站点');
        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);

    }

   /**
     * 提现详情
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function withdraw_details(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        //$security_hash_type = 5;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Zjys_valids_service->withdraw_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }


   /**
     * 提现初次审核详情
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function withdraw_verify_details(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        //$security_hash_type = 5;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Zjys_valids_service->withdraw_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }


   /**
     * 提现再次审核详情
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function withdraw_sure_verify_details(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        //$security_hash_type = 5;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Zjys_valids_service->withdraw_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }

   /**
     * 提现初步审核
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @return   status状态：1是审核通过  3是审核失败
     * 需要参数：id，status
     */
   public function withdraw_verify(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $result = $this->Zjys_valids_service->withdraw_verify($id,$status);        
        returnJson('200',lang('operation_successful'),$result);
   }

   /**
     * 提现再次审核
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   status状态：2是审核通过  3是审核失败
     * 需要参数：id，status
     */
   public function withdraw_sure_verify(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }    
        $result = $this->Zjys_valids_service->withdraw_sure_verify($id,$status);        
        returnJson('200',lang('operation_successful'),$result);
   }

   // /**
   //   * 资金流水
   //   * @Author   张哲
   //   * @DateTime 2018-03-28
   //   * @createby SublimeText3
   //   * @return   [type]       [description]
   //   * 需要参数：page,limit
   //   */
   // public function capital_list(){
   //      $data = $this->input->post(); 
   //      if(!isset($data['page']) && empty($data['page'])){
   //          $data['page'] = 1;
   //      }
   //      if(!isset($data['limit']) && empty($data['limit'])){
   //          $data['limit'] = 10;
   //      }
   //      $res = $this->Zjys_valids_service->capital_list();
   //      $count = $this->Zjys_valids_service->capital_list_count();
   //      $result = array('list'=>$res,'count'=>$count,'pageSize'=>$data['limit'],'curPage'=>$data['page'],'totalPage'=>ceil($count/$data['limit']));
   //      returnJson('200',lang('operation_successful'),$result);
   // }


    /**
    * 资金流水搜索
    * @Author   张哲
    * @DateTime 2018-04-18
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type]       [description]
    */
   public function capital_list(){
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $status = isset($args['status']) ? $args['status'] : 'all'; //状态
        $start_time = isset($args['start_time']) ? strtotime($args['start_time']) : ''; //开始时间
        $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_valids_service->capital_list($offset,$limit,$name,$start_time,$end_time,$site_id,$status);
        $count = $this->Zjys_valids_service->capital_list_count($name,$start_time,$end_time,$site_id,$status);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //资金流水
    public function print_capital_list(){
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $status = isset($args['status']) ? $args['status'] : 'all'; //状态
        $start_time = isset($args['start_time']) ? strtotime($args['start_time']) : ''; //开始时间
        $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : ''; //结束时间
        
        $list= $this->Zjys_valids_service->capital_list(0,'',$name,$start_time,$end_time,$site_id,$status);
        if(empty($list))
        {
          $data['url'] = false;
          returnJson('200',lang('operation_successful'),$data);
        }
        $arr = array();
        foreach ($list as $key => $val){
          $arr[$key]['user_account'] = $val['user_account'];
          $arr[$key]['truename'] = $val['truename'];
          $arr[$key]['create_time'] = $val['create_time'];
          $arr[$key]['value'] = $val['value'];
          $arr[$key]['pay_type'] = $val['pay_type'];
          $arr[$key]['status_type'] = $val['status_type'];
          $arr[$key]['site_name'] = $val['site_name'];
        }
        $title = array('账号','姓名','交易时间','交易金额', '交易类型', '当前状态','站点名称');
        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);
    }



}
