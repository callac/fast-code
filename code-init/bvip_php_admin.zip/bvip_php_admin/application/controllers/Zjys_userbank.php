<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Zjys_userbank extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_userbank_service');
    }

    //商户银行卡列表
    public function userbank_list(){
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //姓名
        $code = isset($args['code']) ? $args['code'] : ''; //号码
        $pre_phone = isset($args['pre_phone']) ? $args['pre_phone'] : ''; //预留手机号
        $realname = isset($args['realname']) ? $args['realname'] : ''; //预留手机号
        $site_id = !empty($args['site_id']) ? $args['site_id'] : ''; //来源
        // $type = isset($args['type']) ? $args['type'] : null; //手机验证码 OR 邮箱验证码
        // $use_type = isset($args['use_type']) ? $args['use_type'] : null; //用途
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_userbank_service->userbank_list($offset,$limit,$name,$code,$pre_phone,$start_time,$end_time,$site_id,$realname);
        $count = $this->Zjys_userbank_service->userbank_list_count($name,$code,$pre_phone,$start_time,$end_time,$site_id,$realname);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //添加银行卡
    public function addbank()
    {
        $this->form_validation->set_rules('name','姓名','required');
        $this->form_validation->set_rules('bank','银行','required');
        $this->form_validation->set_rules('sub_bank', '支行','required');
        $this->form_validation->set_rules('card_number','卡号','required');
        // $this->form_validation->set_rules('trade_status', '交易状态','required');
        // $this->form_validation->set_rules('withdraw_fee','提现费率','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        // echo 444;die;
        $args = $this->input->post();
        $res = $this->Zjys_userbank_service->addbank($args);
        if($res === false){
            returnJson('402','');
        }else{
            returnJson('200','');
        }
    }
    //删除银行卡
    public function deletebank()
    {
        
    }


   




}
