<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/2/26
 * Time: 20:49
 */


class Merchant_account extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Merchant_account_services');
    }

    //商户列表
    public function merchantaccount_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //姓名
        $code = isset($args['code']) ? $args['code'] : ''; //银行卡号
        $type = isset($args['type']) ? $args['type'] : ''; //银行卡号
        $alipay_number = isset($args['alipay_number']) ? $args['alipay_number'] : ''; //支付宝账号
        $wechat_number = isset($args['wechat_number']) ? $args['wechat_number'] : ''; //微信账号
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //
        $sort = isset($args['sort']) ? $args['sort'] : '2'; //1正序 2倒序
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Merchant_account_services->merchantbank_list($offset,$limit,$name,$code,$alipay_number,$wechat_number,$start_time,$end_time,$site_id,$type,$sort);
        $count = $this->Merchant_account_services->merchantbank_count($name,$code,$alipay_number,$wechat_number,$start_time,$end_time,$site_id,$type);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //添加商户
    public function addbank()
    {
        $this->form_validation->set_rules('name','姓名','required');
        $this->form_validation->set_rules('pay_method','pay_method','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        // echo 444;die;
        $args = $this->input->post();
        $res = $this->Merchant_account_services->addbank($args);
        if($res === false){
            returnJson('402',lang('operation_failed'));
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //禁用、启用银行卡
    public function deletebank()
    {
        $this->form_validation->set_rules('id','ID','required');
        $this->form_validation->set_rules('status','status','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args = $this->input->post();
        $res = $this->Merchant_account_services->deletebank($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200','operation_successful');
        }
    }




    //用户委托记录（未完成的订单）
    public function user_entrustedrecords()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = isset($args['symbol']) ? $args['symbol'] : 'ZG_BTC'; //交易对
        $type = isset($args['type']) ? $args['type'] : ''; //委托类型
        $user_id = isset($args['id']) ? $args['id'] : ''; //用户id
        $offset = ($page - 1) * $limit;


        $data['list']= $this->Merchant_account_services->get_entrustedrecords_list($offset,$limit,$symbol,$user_id,$type);
        $count = $this->Merchant_account_services->get_entrustedrecords_count($symbol,$user_id,$type);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);

    }
    //用户成交记录（已成交的记录）
    public function user_dealrecords()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = isset($args['symbol']) ? $args['symbol'] : 'ZG_BTC'; //交易对
        $side = isset($args['side']) ? $args['side'] : 0; //成交类型
        $user_id = isset($args['id']) ? $args['id'] : ''; //用户id
        $offset = ($page - 1) * $limit;


        $data['list']= $this->Merchant_account_services->get_dealrecords_list($offset,$limit,$symbol,$user_id,$side);
        $count = $this->Merchant_account_services->get_dealrecords_count($symbol,$user_id,$side);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //指定银行卡增加银行账目信息

    public function add_merbank_inout_flows()
    {
        $this->form_validation->set_rules('user_name','姓名','required');
        $this->form_validation->set_rules('m_bank_id','平台卡号ID','required');
        $this->form_validation->set_rules('user_bank_number', '用户卡号','required');
        $this->form_validation->set_rules('amount','金额','required');
        $this->form_validation->set_rules('type','类型','required');
        $this->form_validation->set_rules('site_id','站点','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Merchant_account_services->add_merbank_inout_flows($args);
        if($res === false){
            returnJson('402','添加财务异常');
        }else{
            returnJson('200',lang('operation_successful'),$res);
        }
    }


    //商户明细
    public function add_merbank_inout_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['user_name']) ? $args['user_name'] : ''; //姓名
        $code = isset($args['user_bank_number']) ? $args['user_bank_number'] : ''; //号码
        $m_bank_id = isset($args['m_bank_id']) ? $args['m_bank_id'] : ''; //号码
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        // $type = isset($args['type']) ? $args['type'] : null; //手机验证码 OR 邮箱验证码
        // $use_type = isset($args['use_type']) ? $args['use_type'] : null; //用途
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $status = isset($args['status']) ? $args['status'] : ''; //状态
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Merchant_account_services->merbank_inout_list($offset,$limit,$name,$code,$start_time,$end_time,$site_id,$m_bank_id,$status);
        $count = $this->Merchant_account_services->merbank_inout_list_count($name,$code,$start_time,$end_time,$site_id,$m_bank_id,$status);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);

//        $data1['status_1'] = $this->get_total_money($m_bank_id,1); //待处理
//        $data1['status_2'] = $this->get_total_money($m_bank_id,2); //通过
//        $data1['status_3'] = $this->get_total_money($m_bank_id,3); //异常
//        $data1['status_4'] = $this->get_total_money($m_bank_id,4); //已退款
//        $data1['status_5'] = $this->get_total_money($m_bank_id,5); //已收款
//        $data1['status_6'] = $this->get_total_money($m_bank_id,6); //其他
//        $data1['status_7'] = $this->get_total_money($m_bank_id,7); //初审通过
//        $data1['status_8'] = $this->get_total_money($m_bank_id,8); //复审失败
//        $data['status'] = array($data1['status_1'],$data1['status_2'],$data1['status_3'],$data1['status_4'],$data1['status_5'],$data1['status_6'],$data1['status_7'],$data1['status_8']);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function add_merbank_inout_list_printexcel()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['user_name']) ? $args['user_name'] : ''; //姓名
        $code = isset($args['user_bank_number']) ? $args['user_bank_number'] : ''; //号码
        $m_bank_id = isset($args['m_bank_id']) ? $args['m_bank_id'] : ''; //号码
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        // $type = isset($args['type']) ? $args['type'] : null; //手机验证码 OR 邮箱验证码
        // $use_type = isset($args['use_type']) ? $args['use_type'] : null; //用途
        $start_time = isset($args['start_time']) ? $args['start_time'] : date('Y-m-d H:i:s',0); //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : date('Y-m-d H:i:s',time()); //结束时间
        $status = isset($args['status']) ? $args['status'] : ''; //状态
        $site_id = !empty($args['site_id']) ? $args['site_id'] : ''; //
        $offset = ($page - 1) * $limit;
        $list = $this->Merchant_account_services->merbank_inout_list(0,'',$name,$code,$start_time,$end_time,$site_id,$m_bank_id,$status);
        // var_dump($result);die;

        if(empty($list)) returnJson('402','没有数据可导出');

        foreach ($list as $key => $val) {
            $arr[$key]['user_name'] = $val['user_name'];
            $arr[$key]['user_bank_number'] = $val['user_bank_number'];
            $arr[$key]['amount'] = $val['amount'];
            $arr[$key]['trans_remark'] = $val['trans_remark'];
            $arr[$key]['remark'] = $val['user_name'];
            if($val['type'] == 1){
                $arr[$key]['type'] = '进账';
            }else{
                $arr[$key]['type'] = '出账';
            }
            if($val['status'] == 1) $arr[$key]['status'] = '待处理';
            if($val['status'] == 2) $arr[$key]['status'] = '通过';
            if($val['status'] == 3) $arr[$key]['status'] = '异常';
            if($val['status'] == 4) $arr[$key]['status'] = '已退款';
            if($val['status'] == 5) $arr[$key]['status'] = '已收款';
            if($val['status'] == 6) $arr[$key]['status'] = '其他';
            if($val['status'] == 7) $arr[$key]['status'] = '初审通过';
            $arr[$key]['created_at'] = $val['created_at'];
        }
        // print_r($arr);die;
        $title = array('客户姓名','卡号', '金额','客户转账备注', '财务备注', '类型','状态','录入时间');
        $data['url'] = excel_helper::print_excel($title,$arr,'merchantbank_print');
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);

    }

    public function get_total_money($m_bank_id,$status,$type=1){
        return  $this->Merchant_account_services->get_total_money($m_bank_id,$status,$type);
    }



    // 财务统计》法币统计
    public function statistics_c2c_inout()
    {
        $args = $this->input->post();
        $data['list'] = $this->Merchant_account_services->statistics_c2c_inout($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function statistics_c2c_inout_printexcel()
    {
        $args = $this->input->post();
        $data['list'] = $this->Merchant_account_services->statistics_c2c_inout_printexcel($args);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/13
     * Time: 09:43
     */
    public function sort_value(){
        $args = $this->input->post();
        $var_name = 'otc_merchant_sort';
        $data['list'] = $this->Merchant_account_services->sort_value($var_name);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/13
     * Time: 09:32
     */
    public function mer_sort(){
        $args = $this->input->post();
        $sort = $args['sort'];
        $var_name = 'otc_merchant_sort';
        $data['list'] = $this->Merchant_account_services->mer_sort($sort,$var_name);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 修改操作次数
     * User: 张哲
     * Date: 2019/3/13
     * Time: 10:56
     */
    public function modify_trade_count(){
        $args = $this->input->post();
        $trade_account = $args['trade_account'];
        $merchant_id = $args['merchant_id'];
        $data['list'] = $this->Merchant_account_services->modify_trade_count($trade_account,$merchant_id);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 修改排序
     * User: 张哲
     * Date: 2019/3/13
     * Time: 12:49
     */
    public function modify_sort(){
        $args = $this->input->post();
        $sort_id = $args['sort_id'];
        $sort = $args['sort'];

        //1上  2 下
        if($sort == 1){
            $sort_id1 =  $sort_id + 1;
        }else{
            $sort_id1 =  $sort_id - 1;
        }
        $data['list'] = $this->Merchant_account_services->modify_sort($sort_id,$sort_id1,$sort);
        returnJson('200',lang('operation_successful'),$data);
    }







}
