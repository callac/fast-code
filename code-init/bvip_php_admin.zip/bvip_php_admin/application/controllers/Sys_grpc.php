<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sys_grpc extends Base_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Sys__service')
    }
    //获取钱包相关,充值提现
    public function wallet_recharge(){
        // $args =$this->input->post();
        $this->form_validation->set_rules('asset','资产类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $result = $this->Sys_grpc_service->wallet_recharge($args);
    }
}
