<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Keylog extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Keylog_service');
    }

    //关键操作日志列表
    public function keylog_list(){

        $args = $this->input->post();
        $type = $args['type'];

        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页

        $user_id = isset($args['user_id']) ? $args['user_id'] : '';  //操作对象用户id ,若目标日志没有对象用户，表中记录的是0
        $admin_id = !empty($args['admin_id']) ? $args['admin_id'] : '';  //操作人：对应后台管理人员

        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间

        $offset = ($page - 1) * $limit;

        $data['list']= $this->Keylog_service->keylog_list($offset,$limit,$user_id,$admin_id,$start_time,$end_time,$type);
        $count = $this->Keylog_service->keylog_list_count($user_id,$admin_id,$start_time,$end_time,$type);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
}
