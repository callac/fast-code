<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/2/26
 * Time: 20:34
 */

class OTC_order extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_c2corder_service');
        $this->load->service('Config_service');
        $this->load->service('OTC_order_service');
    }

    /**
     * 用户详情
     * @param integer  $user_id
     * @return array
     */
    public function get_info(){
        $this->form_validation->set_rules('user_id','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $data =  $this->Zjys_c2corder_service->get_info($user_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: otc买入卖出
     * User: 张哲
     * Date: 2019/2/26
     * Time: 20:38
     */
    public function inout(){
        $this->form_validation->set_rules('type','类型','required'); //买入或卖出
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $type = !empty($args['type']) ? $args['type'] : ''; //类型：买入1 卖出2
        $order_no = !empty($args['order_no']) ? $args['order_no'] : ''; //订单号
        $name = !empty($args['name']) ? $args['name'] : ''; //姓名（非模糊）
        $useraccount = !empty($args['useraccount']) ? $args['useraccount'] : ''; //账户（非模糊）手机号和邮箱
        $status = !empty($args['status']) ? $args['status'] : ''; //状态：未成交1 已支付2 已成功3 已取消4 处理中6
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';
        $merchant_id = !empty($args['merchant_id']) ? $args['merchant_id'] : '';
        $sort = !empty($args['sort']) ? $args['sort'] : '2'; //1正序 2倒序
        $offset = ($page - 1) * $limit;
        $data['list']= $this->OTC_order_service->inout($offset,$limit,$type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchant_id,$sort);
        $count = $this->OTC_order_service->inout_count($type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchant_id,$sort);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: otc买入卖出导出
     * User: 张哲
     * Date: 2019/2/27
     * Time: 14:33
     */
    public function inout_printexcel(){
        $this->form_validation->set_rules('type','类型','required'); //买入或卖出
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 100; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $type = !empty($args['type']) ? $args['type'] : ''; //类型：买入1 卖出2
        $order_no = !empty($args['order_no']) ? $args['order_no'] : ''; //订单号
        $name = !empty($args['name']) ? $args['name'] : ''; //姓名（非模糊）
        $useraccount = !empty($args['useraccount']) ? $args['useraccount'] : ''; //账户（非模糊）手机号和邮箱
        $status = !empty($args['status']) ? $args['status'] : ''; //状态：未成交1 已支付2 已成功3 已取消4
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';
        $merchant_id = !empty($args['merchant_id']) ? $args['merchant_id'] : '';
        $offset = ($page - 1) * $limit;
        $list= $this->OTC_order_service->inout(0,'',$type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchant_id);
        // $count = $this->Zjys_c2corder_service->inout_count($type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid);


        if(empty($list))
        {
            $data['url'] = false;
            returnJson('200',lang('operation_successful'),$list);
        }

        $arr = array();
        if($type==1){
            foreach ($list as $key => $val){
                $arr[$key]['uid'] = $val['uid'];
                $arr[$key]['order_no'] = $val['order_no'];
                $arr[$key]['real_name'] = $val['real_name'];
                $arr[$key]['user_card_number'] = $val['user_account'];
                $arr[$key]['merchanta_card_number'] = $val['merchanta_card_number'];
                $arr[$key]['price'] = $val['price'];
                $arr[$key]['amount'] = $val['amount'];
                $arr[$key]['remark'] = $val['remark'];
                $arr[$key]['status_type'] = $val['status_type'];
                $arr[$key]['created_at'] = $val['created_at'];
            }
            $title = array('用户id','订单号', '姓名','用户卡号', '平台卡号', '买入价格','买入数量','转账备注','状态','创建时间');
            $data['url'] = excel_helper::print_excel($title,$arr,'user');
            $filePath = strstr($data['url'],'application');
            $oss = new \App\Helpers\oss_helper();
            $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
            returnJson('200',lang('operation_successful'),$data);
        }else{
            foreach ($list as $key => $val){
                // var_dump($val['total_amount']);die;
                $arr[$key]['uid'] = $val['uid'];
                $arr[$key]['order_no'] = $val['order_no'];
                $arr[$key]['real_name'] = $val['real_name'];
                $arr[$key]['user_card_number'] = $val['user_account'];
                $arr[$key]['merchanta_card_number'] = $val['merchanta_card_number'];
                $arr[$key]['price'] = $val['price'];
                $arr[$key]['amount'] = $val['amount'];
                $arr[$key]['real_amount'] = $val['real_amount'];
                $arr[$key]['total_amount'] = $val['total_amount'];
                $arr[$key]['remark'] = $val['remark'];
                $arr[$key]['status_type'] = $val['status_type'];
                $arr[$key]['created_at'] = $val['created_at'];
            }
            $title = array('用户id','订单号', '姓名','用户卡号', '平台卡号', '卖出价格','卖出数量','实际到账','交易总额','转账备注','状态','创建时间');
            $data['url'] = excel_helper::print_excel($title,$arr,'user');
            // var_dump($data);die;
            // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
            $filePath = strstr($data['url'],'application');
            $oss = new \App\Helpers\oss_helper();
            $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
            // var_dump($data);die;
            returnJson('200',lang('operation_successful'),$data);
        }

    }


    /**
     * Notes: 初次审核
     * User: 张哲
     * Date: 2019/2/27otc
     * Time: 14:36
     */
    public function otc_verify_first()
    {
        $data = $this->input->post();
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['remark'];
        $mer_id = isset($data['mer_id']) ? $data['mer_id'] : '';
        //$caiwu_id = !empty($data['caiwu_id']) ? $data['caiwu_id'] : '';

        $result = $this->OTC_order_service->otc_verify_first($id,$status,$remark);
        if($result === false)  returnJson('402','数据异常');
        returnJson('200',lang('operation_successful'),$result);
    }

    /**
     * Notes: 再次审核
     * User: 张哲
     * Date: 2019/2/27
     * Time: 19:53
     */
    public function c2c_verify()
    {
        $data = $this->input->post();
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['remark'];
       // $caiwu_id = !empty($data['caiwu_id']) ? $data['caiwu_id'] : '';

        $result = $this->OTC_order_service->c2c_verify($id,$status,$remark);
        if($result === false)  returnJson('402','数据异常');
        returnJson('200',lang('operation_successful'),$result);
    }


    //后台手动解冻币资产
    public function admin_unfreeze_asset()
    {
        $this->form_validation->set_rules('uid','状态','required');
        $this->form_validation->set_rules('asset','状态','required');
        $this->form_validation->set_rules('amount','状态','required');
        // $this->form_validation->set_rules('asset','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        $uid = !empty($args['uid']) ? $args['uid'] : 1;
        $asset = !empty($args['asset']) ? $args['asset'] : 2;
        $amount = !empty($args['amount']) ? trim($args['amount']) : 0;
        $remark = !empty($args['remark']) ? $args['remark'] : '';
        $result = $this->Zjys_c2corder_service->admin_unfreeze_asset($uid,$asset,$amount,$remark);

        if($result === false)  returnJson('402','数据异常');
        returnJson('200',lang('operation_successful'),$result);
    }



    //新增币资产种类
    public function add_asset(){
        $this->form_validation->set_rules('asset_code','资产码','required');
        $this->form_validation->set_rules('asset_name','资产名称','required');
        $this->form_validation->set_rules('recharge_status', '交易状态','required');
        $this->form_validation->set_rules('withdraw_status','提现状态','required');
        $this->form_validation->set_rules('trade_status', '交易状态','required');
        $this->form_validation->set_rules('withdraw_fee','提现费率','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        // echo 444;die;
        $args = $this->input->post();
        $res = $this->Zjys_c2corder_service->add_asset($args);
        if($res === false){
            returnJson('402','');
        }else{
            returnJson('200','');
        }
    }
    //编辑币种类
    public function edit_asset(){
        $this->form_validation->set_rules('name','产品名','required');
        $this->form_validation->set_rules('product_hash_type','算力类型','required');
        $this->form_validation->set_rules('unit', '单位','required');
        $this->form_validation->set_rules('amount','总量','required');
        $this->form_validation->set_rules('one_amount_value', '单价','required');
        $this->form_validation->set_rules('buy_min_amount','起投数量','required');
        $this->form_validation->set_rules('powerRate','电费','required');
        $this->form_validation->set_rules('maintenance','维护费','required');
        $this->form_validation->set_rules('income_start_time','起息时间','required');
        $this->form_validation->set_rules('income_end_time','结息时间','required');
        $this->form_validation->set_rules('sell_start_time','起售时间','required');
        $this->form_validation->set_rules('sell_end_time','停止销售时间','required');
        $this->form_validation->set_rules('is_top','是否首页展示','required');
        $this->form_validation->set_rules('status','产品状态','required');
        //$this->form_validation->set_rules('is_loan','是否分期','required');
        $this->form_validation->set_rules('description','描述','required');
        $this->form_validation->set_rules('site_id','站点id','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Product_hash_service->add($args);
        if($res === false){
            returnJson('402','');
        }else{
            returnJson('200','');
        }

    }

    /**
     * 禁止登陆/允许登陆
     * @param integer  $user_id     用户ID
     * @param integer  $type        状态
     * @return array
     */
    public function forbid_login(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_c2corder_service->update_forbid_login($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 禁止交易/允许交易
     * @param integer  $user_id     用户ID
     * @param integer  $type        状态
     * @return array
     */
    public function forbid_withdraw(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_c2corder_service->update_forbid_withdraw($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 禁止提现/允许提现
     * @param integer  $user_id     用户ID
     * @param integer  $type        状态
     * @return array
     */
    public function forbid_trade(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_c2corder_service->update_forbid_trade($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }

    /**
     * Notes: 参数列表 options表
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:13
     */
    public function params_config_c2c(){
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $site_id =  !empty($args['site_id']) ? intval($args['site_id']) : '';
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Config_service->c2c_param_config_list($offset,$limit,$site_id);
        // var_dump($data['list']);die;

        $count = $this->Config_service->c2c_param_config_list_count($site_id);
        // var_dump($count);die;
        $data['total']=$count[0]['totalnum'];
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count[0]['totalnum']/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /** 参数设置  options表
     * Notes:
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:10
     */
    public function c2c_config_update(){
        $args = $this->input->post();
        $this->form_validation->set_rules('value','变量值','required' );
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Config_service->c2c_config_update($args);
        // var_dump($this->db->last_query());die;

        if($res !== false){
            //清redis
            $key = 'options';
            $redis = new Redis();
            $redis->connect('127.0.0.1',$this->config->item('REDIS_PORT'));
            // var_dump($redis->connect('127.0.0.1',6379));die;
            $redis->select(15);
            $result = $redis->delete($key);
            if($result){
                returnJson('200',lang('operation_successful'));
            }
        }
        returnJson('200',lang('operation_successful'));
        // returnJson('402','配置参数名已存在');
    }

    /**
     * Notes: 参数删除  options表
     * User: 张哲
     * Date: 2019/2/27
     * Time: 20:13
     */
    public function c2c_config_delete(){
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $this->Config_service->c2c_config_delete($id);
        returnJson('200',lang('operation_successful'));
    }


    /**
     * Notes: otc用户收付款设置
     * User: 张哲
     * Date: 2019/2/28
     * Time: 11:20
     */
    public function otc_user_account(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $type = !empty($args['type']) ? $args['type'] : ''; //类型：买入1 卖出2
        $uid = !empty($args['uid']) ? $args['uid'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->OTC_order_service->otc_user_account($offset,$limit,$type,$uid,$site_id);
        $count1 = $this->OTC_order_service->otc_user_account_count($type,$uid,$site_id);
        $count2 = $this->OTC_order_service->otc_user_account_count1($type,$uid,$site_id);
        $count = $count1+$count2;
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 第三方转入和转出记录
     * User: 张哲
     * Date: 2019/3/20
     * Time: 10:37
     */
    public function foreign_otc_transfers(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : ''; //站点
        $asset = !empty($args['uid']) ? $args['uid'] : ''; //币种
        $uid = !empty($args['merchant_id']) ? $args['merchant_id'] : '';//用户id
        $offset = ($page - 1) * $limit;
        $data['list']= $this->OTC_order_service-> foreign_otc_transfers_list($offset,$limit,$start_time,$end_time,$site_id,$uid,$asset);
        $count = $this->OTC_order_service-> foreign_otc_transfers_count($start_time,$end_time,$site_id,$uid,$asset);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 第三方记录导出
     * User: 张 哲
     * Date: 2019/3/20
     * Time: 10:45
     */
    public function foreign_otc_transfers_export(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : ''; //站点
        $asset = !empty($args['uid']) ? $args['uid'] : ''; //币种
        $uid = !empty($args['merchant_id']) ? $args['merchant_id'] : '';//用户id
        $offset = ($page - 1) * $limit;
        $list= $this->OTC_order_service->foreign_otc_transfers_export($offset,$limit,$start_time,$end_time,$site_id,$uid,$asset);


        if(empty($list))
        {
            $data['url'] = false;
            returnJson('200',lang('operation_successful'),$list);
        }


        foreach ($list as $key => $val){
            $arr[$key]['created_at'] = $val['created_at'];
            $arr[$key]['uid'] = $val['user_id'];
            $arr[$key]['amount'] = $val['amount'];
            $arr[$key]['type'] = $val['type'];
            $arr[$key]['site_id'] = $val['site_id'];
        }

            $title = array('时间','用户id', '数量','类型', '站点');
            $data['url'] = excel_helper::print_excel($title,$arr,'user');
            $filePath = strstr($data['url'],'application');
            $oss = new \App\Helpers\oss_helper();
            $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
            returnJson('200',lang('operation_successful'),$data);


    }

    /**
     * Notes: otc 币种配置
     * User: 张哲
     * Date: 2019/3/22
     * Time: 11:00
     */
    public function otc_assets(){
        $args = $this->input->post();
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->OTC_order_service->otc_assets($site_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 更换币种
     * User: 张哲
     * Date: 2019/3/22
     * Time: 11:29
     */
    public function update_otc_assets(){
        $args = $this->input->post();
        $data = $this->OTC_order_service->update_otc_assets($args);
        returnJson('200',lang('operation_successful'));
    }

}
