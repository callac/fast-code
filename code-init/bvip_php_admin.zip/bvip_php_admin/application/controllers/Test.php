<?php
print >>>EOF
<div>这是一个人</div>
<a href="">lsjdf</a>
EOF;