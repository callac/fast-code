<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ini_set('display_errors', 1);
/**
 * 后台管理
 */

class Admin extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Admin_service');
        $this->load->service('Sys_grpc_service');
    }
    //获取所有角色
    public function roles_all(){
        $data = $this->Admin_service->roles_all();
        returnJson('200',lang('operation_successful'),$data);
    }

    //获取部门列表
    public function roles_list(){
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $offset = ($page - 1) * $limit;
        $role_id =$this->input->post('role_id');
        $site_id =$this->input->post('site_id');
        // var_dump($role_id);

        if(empty($role_id)){
            $list = $this->Admin_service->roles_list_all($offset,$limit,$site_id);
            $count = $this->Admin_service->roles_count_all($site_id);
        }else{
            if($role_id == -1)$role_id =0;
            $list = $this->Admin_service->roles_list($offset,$limit,$role_id,$site_id);
            $count = $this->Admin_service->roles_count($role_id,$site_id);
        }

        $data['list']=$list;
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //角色 禁用/启用
    public function roles_lock(){
        $this->form_validation->set_rules('id','角色ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $type = $this->input->post('type');
        $this->Admin_service->roles_lock($id,$type);
        returnJson('200',lang('operation_successful'));
    }

    //更新部门/岗位
    public function roles_update(){
        $this->form_validation->set_rules('role_name','角色名称','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $site_id = $this->input->post('site_id');
        $parent_id = $this->input->post('parent_id');  //为null是更新部门，否则为更新岗位
        $role_name = $this->input->post('role_name');  //部门或岗位名
        $role_id = $this->input->post('role_id');  //部门或岗位id
        $description = $this->input->post('description'); //描述
        $update_parent_id = $this->input->post('update_parent_id'); //要更新的部门ID
        if($parent_id == false){
            $update_parent_id = 0;
            $description = '';
        }
        $res = $this->Admin_service->roles_update_jobs($role_id,$update_parent_id,$role_name,$description,$site_id);
        if($res === false)returnJson('402','名称重复');
        returnJson('200','');
    }

    //更新部门/岗位权限信息
    public function roles_update_privilages(){
        $this->form_validation->set_rules('id','部门/岗位ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $privilages = $this->input->post('privilages');
        $res = $this->Admin_service->roles_update_privilages($id,$privilages);
        returnJson('200','',$res);
    }


    //权限列表  type=1为部门 type=2为岗位 type=3为子站超管 默认为1
    public function roles_base(){
        $data = $this->input->post();
        $type = !empty($data['type']) ? $data['type'] : 1 ;
        $site_id = !empty($data['site_id']) ? $data['site_id'] : '';
        if($type==3){ //子站管理时
            $this->form_validation->set_rules('role_id','角色ID','required');
            if($this->form_validation->run() == FALSE){
                returnJson('402',lang('missing_parameters'));
            }
        }else{
            $this->form_validation->set_rules('id','部门/岗位ID','required');
            if($this->form_validation->run() == FALSE){
                returnJson('402',lang('missing_parameters'));
            }
        }
        if($type==3){ //子站超管
            $role_id = $this->input->post('role_id');
            if(!$role_id) returnJson('402',lang('missing_parameters')); //没有role_id就返回异常
        }else{
            $role_id = $this->input->post('id');
        }
        $data =$this->Admin_service->roles_base($role_id,$type,$site_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    //单个角色权限列表
    public function roles_details(){
        $this->form_validation->set_rules('id','角色ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $res = $this->Admin_service->roles_details($id);
        returnJson('200','',$res);
    }

    //角色删除
    public function roles_delete(){
        $this->form_validation->set_rules('role_id','岗位id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $role_id = $this->input->post('role_id');
        $res = $this->Admin_service->roles_delete($role_id);
        if($res === false)returnJson('402','删除失败');
        returnJson('200','操作成功');
    }

    //管理员列表
    public function admin_list(){
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $site_id = !empty($args['site_id']) ? $args['site_id'] : null;
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Admin_service->admin_list($offset,$limit,$site_id);
        $count = $this->Admin_service->admin_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //子站超管列表
    public function subadmin_list()
    {
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $site_id = isset($args['site_id']) ? intval($args['site_id']) : null;//偏移量
        $sadmin = 1;
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Admin_service->subadmin_list($offset,$limit,$sadmin,$site_id);
        $count = $this->Admin_service->subadmin_count($sadmin,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //管理员 禁用/启用
    public function admin_lock(){
        $this->form_validation->set_rules('id','管理员ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $type = $this->input->post('type');
        $this->Admin_service->admin_lock($id,$type);
        returnJson('200',lang('operation_successful'));
    }

    //管理员  新增/编辑
    public function admin_update(){
        $this->form_validation->set_rules('user_name','用户名称','required');
        $this->form_validation->set_rules('true_name','真实姓名','required');

        $this->form_validation->set_rules('email','email','required');
        $this->form_validation->set_rules('mobile','手机号','required');

        $this->form_validation->set_rules('roles_id','角色ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Admin_service->admin_update($args);
        if($res === false)returnJson('402','新增失败，账号已存在');
        returnJson('200','');
    }



    //新增/编辑子站超管
    public function subadmin_update()
    {
        $this->form_validation->set_rules('user_name','用户名称','required');
        //$this->form_validation->set_rules('password','密码','required');
        $this->form_validation->set_rules('true_name','真实姓名','required');

        $this->form_validation->set_rules('email','email','required');
        $this->form_validation->set_rules('phone','手机号','required');

        $this->form_validation->set_rules('site_id','子站点id','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Admin_service->subadmin_update($args);
        if($res === false)returnJson('402','新增失败，账号已存在');
        returnJson('200','');
    }

    //管理员  删除
    public function admin_delete(){

        $this->form_validation->set_rules('user_id','用户id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        if($user_id == 1)  returnJson('402','该用户无法删除');
        $res = $this->Admin_service->admin_delete($user_id);
        if($res === false)returnJson('402','删除失败');
        returnJson('200','删除成功');
    }

    //角色基础信息
    public function admin_details(){
        $this->form_validation->set_rules('id','角色ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402','参数错误');
        }
        $id = $this->input->post('id');
        $data = $this->Admin_service->admin_details($id);
        returnJson('200','',$data);
    }

    //权限  新增/编辑
    public function modules_update(){
        $this->form_validation->set_rules('module_name','授权功能','trim|required');
        $this->form_validation->set_rules('module_url','授权url','trim|required');
        $this->form_validation->set_rules('description','描述','required');
        $this->form_validation->set_rules('parent_id','上级权限ID','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402','参数错误');
        }
        $args = $this->input->post();
        $res = $this->Admin_service->modules_update($args);
        if($res === false)returnJson('402','');
        returnJson('200','');
    }



    /**
     * Notes: 获取验证码
     * User: 张哲
     * Date: 2019/3/14
     * Time: 14:32
     */
    public function SMS(){
        $this->form_validation->set_rules('account','账号','required'); //绑定手机号或者邮箱
        $this->form_validation->set_rules('user_name','用户','required'); //
        if($this->form_validation->run() == FALSE){
            returnJson('402','参数错误');
        }
        $account = $this->input->post('account'); //手机号
        $ip = $_SERVER['REMOTE_ADDR'];
        //验证是否是该账户绑定手机号或邮箱
        $user_name =$this->input->post('user_name'); //账号
        $data1 = $this->Admin_service->find($user_name,$account);
        $data2 = $this->Admin_service->find2($user_name,$account);
        if(!empty($data1) || !empty($data2)) {

            //获取验证码
            $data = $this->Sys_grpc_service->AdminSendVerifyMessage($account, $ip);
            if ($data['code'] == 0) {
                returnJson('200', lang('operation_successful'), $data);
            } else {
                returnJson('402', $data['details']);
            }
        }else{
            returnJson('402',lang('The account and contact information you entered do not match. Please check and re-enter'));
        }
    }


    /**
     * Notes: 安全验证
     * User: 张哲
     * Date: 2019/3/19
     * Time: 14:01
     */
    public function verity_login(){
        $this->form_validation->set_rules('user_name','用户名','required'); //账号
        $this->form_validation->set_rules('password','密码','required'); //密码
        $this->form_validation->set_rules('account','账号','required'); //绑定手机号或者邮箱
        $this->form_validation->set_rules('code','验证码','required'); //验证阿妈
        if($this->form_validation->run() == FALSE){
            returnJson('402','参数错误');
        }
        $user_name = $this->input->post('user_name');
        $password = $this->input->post('password');
        $account = $this->input->post('account');
        $code = $this->input->post('code');

        $name = $this->Admin_service->name($user_name);
        // var_dump($name);die;
        // var_dump($this->getRealIp());

        if(empty($name)){
            returnJson('402',lang('message incorrect. Please re-enter'));
        }

        $user_id = $this->Admin_service->login($user_name,$password);

        $info = $this->Admin_service->admin_details($user_id);

        if(!$user_id){
            returnJson('402',lang('message incorrect. Please re-enter'));
        }

        if($user_name == 'zh') {
            $ip = $_SERVER['REMOTE_ADDR'];
            //token过期时间
            $token = jwt_helper::create($user_id . '|' . $ip);
            //更新用户token信息和登陆时间
            $time = time();
            $this->Admin_service->update_user_token($user_id, $token, $time, $ip);
            $user_info = $this->Admin_service->login_roles_all($user_id);
            $data['token'] = $token;
            $data['privs'] = $this->Admin_service->sum_privs($user_id);
            $data['user_info'] = $user_info;
            //次数置为0
            $this->Admin_service->modify_frequency($user_name, 0);
            returnJson('200', '', $data);
        }else{
            //获取修改密码时间
            $update_password_time = $info['update_password_time'];
            if(empty($update_password_time)){
                $update_password_time = time();
            }else{
                $update_password_time = strtotime($update_password_time);
            }

            //获取配置密码修改过期时间
            $expire_date = $this->Admin_service->expire_date();
            $expire_time = $expire_date['value'];
            $expire_time = $expire_time * 86400;
            // var_dump($info['update_password_time'],$expire_date['value']);
            //密码修改过期时间-现在时间-修改密码时间 < 24
            $time = time();
            $intervals_time = $expire_time - $time + $update_password_time;


            if($intervals_time < 0){
                returnJson('402','密码时间过期，请联系管理员');
            }else{
                $hour = intval($intervals_time / 3600);
                if($hour < 0) $hour = 0;
                $minites = $intervals_time % 3600;
                if($minites < 60){
                    $min = 0;
                }else{
                    $min = intval($minites / 60);
                }
                $prompt = '密码有效期还剩'.$hour.'小时'.$min.'分钟'.',请及时修改，过期未修改将限制登录';
                if($intervals_time <= 86400){
                    $prompt = $prompt;
                }else{
                    $prompt = '';
                }

                $failure_frequncy = $this->Admin_service->failure_frequency_count($user_name);

                if($failure_frequncy['locked'] == 0){
                    returnJson('402',lang('forbid login'));
                }

                if($failure_frequncy['frequency'] >= 4){
                    returnJson('402',lang('Too many login failures, the account has been frozen, please contact the site administrator'));
                }

                $verification_code = $this->Admin_service->verification_code($account,$code);
                //获取ip
                $ip = $_SERVER['REMOTE_ADDR'];

                $time = time();
                if(empty($verification_code)){
                    returnJson('402',lang('message incorrect. Please re-enter'));
                }

                if($verification_code['is_used'] != 0){
                    returnJson('402',lang('code is use'));
                }

                //五分钟有效
                //发送时间
                $crete_time = strtotime($verification_code['created_at']);
                $extra_time = $time - $crete_time;
                if($extra_time > 300){
                    returnJson('402',lang('more than five minutes, please resend'));
                }



                //token过期时间
                $token = jwt_helper::create($user_id.'|'.$ip);
                //更新用户token信息和登陆时间
                // $ip = $_SERVER['REMOTE_ADDR'];
                // var_dump($this->getRealIp());die;
                $time = time();
                $this->Admin_service->update_user_token($user_id,$token,$time,$ip);

                $user_info = $this->Admin_service->login_roles_all($user_id);
                $data['token'] = $token;
                $data['privs'] = $this->Admin_service->sum_privs($user_id);
                $data['user_info'] =$user_info;
                $data['prompt'] =$prompt;

                returnJson('200','',$data);
            }


//        if($user_name == 'zh' || $user_name == 'lmx' || $user_name == 'lzp'){
//            $ip = $_SERVER['REMOTE_ADDR'];
//            //token过期时间
//            $token = jwt_helper::create($user_id.'|'.$ip);
//            //更新用户token信息和登陆时间
//            $time = time();
//            $this->Admin_service->update_user_token($user_id,$token,$time,$ip);
//            $user_info = $this->Admin_service->login_roles_all($user_id);
//            $data['token'] = $token;
//            $data['privs'] = $this->Admin_service->sum_privs($user_id);
//            $data['user_info'] =$user_info;
//            //次数置为0
//            $this->Admin_service->modify_frequency($user_name,0);
//            returnJson('200','',$data);
//        }
        }
//        var_dump($expire_time,$time,$update_password_time,$intervals_time);die();



    }


    //获取真实IP
    public static function getRealIp()
    {
        if (isset($_SERVER)) {
            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);

                foreach ($arr as $ip) {
                    $ip = trim($ip);

                    if ($ip != 'unknown') {
                        $realip = $ip;
                        break;
                    }
                }
            } else if (isset($_SERVER['HTTP_CLIENT_IP'])) {
                $realip = $_SERVER['HTTP_CLIENT_IP'];
            } else if (isset($_SERVER['REMOTE_ADDR'])) {
                $realip = $_SERVER['REMOTE_ADDR'];
            } else {
                $realip = '0.0.0.0';
            }
        } else if (getenv('HTTP_X_FORWARDED_FOR')) {
            $realip = getenv('HTTP_X_FORWARDED_FOR');
        } else if (getenv('HTTP_CLIENT_IP')) {
            $realip = getenv('HTTP_CLIENT_IP');
        } else {
            $realip = getenv('REMOTE_ADDR');
        }

        preg_match('/[\\d\\.]{7,15}/', $realip, $onlineip);
        $realip = (!empty($onlineip[0]) ? $onlineip[0] : '0.0.0.0');
        return $realip;
    }


    //管理员退出登陸
    public function quit(){
        $this->Admin_service->quit($this->user_id,0);
        returnJson('200','退出成功');
    }

    //管理员修改密码
    public function update_password(){
        $this->form_validation->set_rules('user_id','用户id','required');
        $this->form_validation->set_rules('password','新密码','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402','参数错误');
        }
        $user_id = $this->input->post('user_id');
        $password = $this->input->post('password');
        $this->Admin_service->update_password($user_id,$password);
        returnJson('200','');
    }
    //管理员自修改密码
    public function update_password_self()
    {
        $this->form_validation->set_rules('user_id','用户id','required');
        $this->form_validation->set_rules('old_password','原始密码','required');
        $this->form_validation->set_rules('password','新密码','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402','参数错误');
        }

        $user_id = $this->input->post('user_id');
        $old_password = $this->input->post('old_password');
        $password = $this->input->post('password');
        $se_password = $this->input->post('se_password');
        if($password === $old_password)
            returnJson('402',lang('Old and new passwords should be inconsistent'));


        $this->Admin_service->update_password_self($user_id,$old_password,$password);
        returnJson('200',lang('operation_successful'));
    }

    //总览
    public function user_overview(){
        $site_id = !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $data =$this->Admin_service->user_overview($site_id);
        returnJson('200','',$data);
    }

    //权限提交
    public function update_priv(){
        $role_id = $this->input->post('role_id');
        $priv_ids = $this->input->post('priv_ids');
        $res = $this->Admin_service->update_priv($role_id,$priv_ids);
        if($res) returnJson('200','');
        returnJson('402','');
    }

    //根据站点获取部门/岗位
    public function get_roles_by_site(){
        $args = $this->input->post();
        $site_id = !empty($args['site_id']) ?  $args['site_id'] : null;
        $is_parent =  !empty($args['is_parent']) ?  $args['is_parent'] : false;
        $res = $this->Admin_service->get_roles_by_site($site_id,$is_parent);
        $list = array();
        foreach ($res as $val){
            $list[$val['site_id']][] = $val;
        }
        $data['list'] = $list;

        if($data) returnJson('200','',$data);
        returnJson('402','',$res);
    }

    //后台前端切换语言
    public function switch_language()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('admin_id','admin_id','trim|required');
        $this->form_validation->set_rules('language','language','trim|required');
        if($this->form_validation->run() == FALSE){
            returnJson('402','参数错误');
        }
        $res = $this->Admin_service->switch_language($args);
        if($res)
            returnJson('200',lang('operation_successful'));
        else
            returnJson('402',lang('operation_failed'));
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019/3/20
     * Time: 15:58
     */
    public function modify_frequency(){
        $admin_id = $this->input->post('admin_id');
        $user_name = $this->input->post('user_name');
        $this->Admin_service->modify_frequency($user_name,0);
        returnJson('200',lang('operation_successful'));
    }

}
