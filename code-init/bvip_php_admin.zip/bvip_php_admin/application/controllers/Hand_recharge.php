<?php
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-06-24
 * Time: 16:37
 */

class Hand_recharge extends Web_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->service('Hand_recharge_service');
    }

    /**
     * Notes: 手动充值补录列表
     */
    public function handrecharge_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $asset = isset($args['asset']) ? $args['asset'] : ''; //资产
        $recharge_hash = isset($args['recharge_hash']) ? $args['recharge_hash'] : ''; //充值哈希
        $status = isset($args['status']) ? $args['status'] : ''; //状态
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Hand_recharge_service->handrecharge_list($offset,$limit,$start_time,$end_time,$asset,$recharge_hash,$status);
        $count = $this->Hand_recharge_service->handrecharge_list_count($start_time, $end_time,$asset,$recharge_hash,$status);
        $data['total'] = $count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($count / $limit);
        returnJson('200', lang('operation_successful'), $data);
    }

    /**
     * Notes:新增/编辑手动充值补录
     * User: 左俊
     * Date: 2019-09-10
     */
    public function add()
    {
        $this->form_validation->set_rules('asset', 'asset', 'required');
        $this->form_validation->set_rules('recharge_hash', 'recharge_hash', 'required');
        $this->form_validation->set_rules('recharge_address', 'recharge_address', 'required');
        $this->form_validation->set_rules('amount', 'amount', 'required');
        $this->form_validation->set_rules('remark', 'remark', 'required');
        $this->form_validation->set_rules('hash_check', 'hash_check', 'required');
        $this->form_validation->set_rules('user_id', 'user_id', 'required');

        if ($this->form_validation->run() == FALSE) {
            returnJson('402', lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Hand_recharge_service->add($args);
        if ($res === false) {
            returnJson('402', lang('operation_failed'));
        } else {
            returnJson('200', lang('operation_successful'));
        }
    }

    //审核
    public function handrecharge_verify()
    {
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['remark'];
        
        $result = $this->Hand_recharge_service->handrecharge_verify($id,$status,$remark); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }


    //初次审核
    public function handrecharge_verify_first()
    {
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['remark'];
        
        $result = $this->Hand_recharge_service->handrecharge_verify_first($id,$status,$remark); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }

    //初次审核
    public function detail()
    {
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $result = $this->Hand_recharge_service->detail($id); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }
}