<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//必须
class Index extends Web_Controller {
    function __construct() {
        parent::__construct();
    }

    function index()
    {

    }
}