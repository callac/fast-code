<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 账户管理
 */

class Account extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Account_service');
    }


    // ------------------------- 数字货币类型---------------------------------
    public function get_currency_list(){
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $site_id =   !empty($args['site_id']) ? $args['site_id'] : null;
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Account_service->get_currency_list($offset,$limit,$site_id);
        $count = $this->Account_service->get_currency_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    public function currency_update(){
        $args = $this->input->post();
        $this->form_validation->set_rules('name','名字','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Account_service->currency_update($args);
        returnJson('200',lang('operation_successful'));
    }
    public function currency_delete(){
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $this->Account_service->currency_delete($id);
        returnJson('200',lang('operation_successful'));
    }

    // ------------------------- 操作日志---------------------------------
    public function get_logs_list(){
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $site_id =  !empty($args['site_id']) ? intval($args['site_id']) : null;
        $name =  !empty($args['name']) ? $args['name'] : null;
        $ip =  !empty($args['ip']) ? $args['ip'] : null;
        $start_time =  !empty($args['start_time']) ? strtotime($args['start_time']) : null;
        $end_time =  !empty($args['end_time']) ? strtotime($args['end_time']) : null;
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Account_service->get_logs_list($offset,$limit,$site_id,$name,$ip,$start_time,$end_time);
        $count = $this->Account_service->get_logs_count($site_id,$name,$ip,$start_time,$end_time);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    public function logs_delete(){
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $this->Account_service->logs_delete($id);
        returnJson('200',lang('operation_successful'));
    }

    // ------------------------- 电子合同---------------------------------
    public function get_contract_list(){
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $site_id =  !empty($args['site_id']) ? intval($args['site_id']) : null;
        $type =  !empty($args['type']) ? intval($args['type']) : null;
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Account_service->get_contract_list($offset,$limit,$site_id,$type);
        $count = $this->Account_service->get_contract_count($site_id,$type);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    public function get_contract_detail(){

    }
    public function contract_update(){
        $args = $this->input->post();
        $this->form_validation->set_rules('title_buy','','required');
        $this->form_validation->set_rules('desc','描述','required' );
        $this->form_validation->set_rules('content', '内容','required');
        $this->form_validation->set_rules('site_id','站点id','required');
        $this->form_validation->set_rules('type','分类','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Account_service->contract_update($args);
        returnJson('200',lang('operation_successful'));
    }
    public function contract_delete(){
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $this->Account_service->contract_delete($id);
        returnJson('200',lang('operation_successful'));
    }

}
