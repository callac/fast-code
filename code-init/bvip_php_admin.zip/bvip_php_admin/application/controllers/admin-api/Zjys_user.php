<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Zjys_user extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_user_service');
        $this->load->service('Identity_service');
        $this->load->service('Sys_grpc_service');
    }

    /**
     * 用户详情
     * @param integer  $user_id
     * @return array
     */
    public function get_info(){
        $this->form_validation->set_rules('id','用户ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('id');
        $data =  $this->Zjys_user_service->get_info($user_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function get_bank_list()
    {
        $this->form_validation->set_rules('id','用户ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('id');
        $data['list'] =  $this->Zjys_user_service->get_bank_list($user_id);
        $count = $this->Zjys_user_service->get_bank_list_count($user_id);
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);

        returnJson('200',lang('operation_successful'),$data);
    }

    public function user_withdraw_address_list(){
        $this->form_validation->set_rules('id','用户ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $id = !empty($args['id']) ? $args['id'] : '';
        $asset_code = !empty($args['asset_code']) ? $args['asset_code'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->user_withdraw_address_list($offset,$limit,$start_time,$end_time,$asset_code,$id);
        $count = $this->Zjys_user_service->user_withdraw_address_list_count($start_time,$end_time,$asset_code,$id);

        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //稍等
    public function user_withdraw_address_logs(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $name = !empty($args['name']) ? $args['name'] : ''; //关键词
        $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->get_list($offset,$limit,$name,$start_time,$end_time,$user_identity_auth,$site_id);
        $count = $this->Zjys_user_service->get_count($name,$start_time,$end_time,$user_identity_auth,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    public function user_recharge_address_list(){
        $this->form_validation->set_rules('id','用户ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $id = !empty($args['id']) ? $args['id'] : '';
        $asset_code = !empty($args['asset_code']) ? $args['asset_code'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->user_recharge_address_list($offset,$limit,$start_time,$end_time,$asset_code,$id);
        $count = $this->Zjys_user_service->user_recharge_address_list_count($start_time,$end_time,$asset_code,$id);

        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function user_recharge_address_logs(){
        $this->form_validation->set_rules('id','用户ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $id = !empty($args['id']) ? $args['id'] : '';
        $asset_code = !empty($args['asset_code']) ? $args['asset_code'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->user_recharge_logs_list($offset,$limit,$start_time,$end_time,$asset_code,$id);
        $count = $this->Zjys_user_service->user_recharge_logs_list_count($start_time,$end_time,$asset_code,$id);

        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }





    //导出
    public function print_user_excel(){
        $args =$this->input->post();
        $name = !empty($args['name']) ? urldecode($args['name']) : ''; //关键词
        $site_id = !empty($args['site_id']) ? $args['site_id'] : null; //站点id
        $start_time = !empty($args['start_time']) ? strtotime($args['start_time']) : ''; //注册开始时间
        $end_time = !empty($args['end_time']) ? strtotime($args['end_time']) : ''; //注册结束时间
        $realname = !empty($args['realname']) ? $args['realname'] : '';
        $list = $this->Zjys_user_service->get_list(0,'',$name,$start_time,$end_time,$site_id);
        $arr = array();
        foreach ($list as $key => $val){
            $arr[$key]['id'] = $val['id'];
            $arr[$key]['truename'] = $val['truename'];
            $arr[$key]['mobile'] = $val['mobile'];
            $arr[$key]['email'] = $val['email'];
            $arr[$key]['register_time'] = $val['register_time'];
            $arr[$key]['last_login_time'] = $val['last_login_time'];
            $arr[$key]['site_name'] = $val['site_name'];
            $arr[$key]['truename_status'] = $val['truename_status'];
            $arr[$key]['invite_email'] = $val['invite_email'];
            $arr[$key]['invite_mobile'] = $val['invite_mobile'];
        }
        $title = array('用户ID', '真实姓名','手机号','邮箱','注册时间','最近一次登录时间','站点来源','认证状态','邀请人邮箱','邀请人手机号');

        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // var_dump($data);die;
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * 获取列表
     *
     * @param integer  $page     当前页，默认值为第1页
     * @param integer  $limit    条数限制，默认值为10
     * @return array
     */
    public function get_list(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $name = !empty($args['name']) ? $args['name'] : ''; //关键词
        $user_identity_auth = isset($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';
        $realname = !empty($args['realname']) ? $args['realname'] : '';
        $vip_level = isset($args['vip_level']) ? $args['vip_level'] : '';


        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->get_list($offset,$limit,$name,$start_time,$end_time,$user_identity_auth,$site_id,$uid,$realname,$vip_level);
        // var_dump($data['list']);
        // $count = count($data[$list]);
        $count = $this->Zjys_user_service->get_count($name,$start_time,$end_time,$user_identity_auth,$site_id,$uid,$realname,$vip_level);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //vip管理列表
    public function vip_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $name = !empty($args['name']) ? $args['name'] : ''; //关键词
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->vip_list($offset,$limit,$site_id);
        $count = $this->Zjys_user_service->vip_list_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function vip_list_noauth(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $name = !empty($args['name']) ? $args['name'] : ''; //关键词
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->vip_list($offset,$limit,$site_id);
        $count = $this->Zjys_user_service->vip_list_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //新增vip级别及相关设置

    public function vip_edit()
    {
        $this->form_validation->set_rules('vip_level','vip等级','required');
        $this->form_validation->set_rules('trade_limit_taker_discount','taker限价费率折扣','required');
        $this->form_validation->set_rules('trade_limit_maker_discount','maker限价费率折扣','required');
        $this->form_validation->set_rules('trade_market_taker_discount','市场限价费率折扣','required');
        $this->form_validation->set_rules('withdraw_discount','提币费率折扣','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_user_service->vip_edit($args);
        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //更改vip_adduser用户
    public function vip_adduser()
    {
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('vip_level','会员等级','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $vip_level = $this->input->post('vip_level');
        $res = $this->Zjys_user_service->vip_adduser($user_id,$vip_level);

        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }

    }





    //安全信息列表
    public function user_safeinfo_list(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $name = !empty($args['name']) ? $args['name'] : ''; //关键词
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->user_safeinfo_list($offset,$limit,$name,$start_time,$end_time,$site_id,$uid);
        $count = $this->Zjys_user_service->safeinfo_list_count($name,$start_time,$end_time,$site_id,$uid);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }



    /**
     * 获取用户认证信息
     */
    public function user_identity_list()
    {
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $name = !empty($args['name']) ? $args['name'] : ''; //关键词(手机号或者邮箱)
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $real_name = !empty($args['real_name']) ? $args['real_name'] : '';//真实姓名
        $code = !empty($args['code']) ? $args['code'] : '';//身份证号
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';
        $status = !empty($args['status']) ? $args['status'] : '';
        $area_code = !empty($args['country_id']) ? $args['country_id'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->user_identity_list($offset,$limit,$name,$real_name,$code,$start_time,$end_time,$site_id,$uid,$status,$area_code);
        $count = $this->Zjys_user_service->user_identity_list_count($name,$start_time,$end_time,$real_name,$code,$site_id,$uid,$status,$area_code);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 修改用户认证信息
     * @return [type] [description]
     */
    public function correct_identity_info()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $id = !empty($args['id']) ? $args['id'] : '';
        $first_name = !empty($args['first_name']) ? $args['first_name'] : '';
        $last_name = !empty($args['last_name']) ? $args['last_name'] : '';
        $number = !empty($args['number']) ? $args['number'] : '';
        $country_id = !empty($args['country_id']) ? $args['country_id'] : '';
        $name = $first_name.$last_name;
        $res = $this->Zjys_user_service->correct_identity_info($id,$first_name,$last_name,$name,$number,$country_id);
        if($res)
            returnJson('200',lang('operation_successful'));
        else
            returnJson('402',lang('operation_failed'));
    }


    public function reset_google_verify()
    {
        $this->form_validation->set_rules('id','用户ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $time = date('Y-m-d H:i:s',time());
        $this->Zjys_user_service->reset_google_verify($id);
        $this->Zjys_user_service->delete_google_verify($id);
        $this->Zjys_user_service->reset_two_factor($id,$time);
        returnJson('200',lang('operation_successful'));
    }

    public function forbid_login(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_user_service->update_forbid_login($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 禁止交易/允许交易
     * @param integer  $user_id     用户ID
     * @param integer  $type        状态
     * @return array
     */
    public function forbid_withdraw(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_user_service->update_forbid_withdraw($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 禁止提现/允许提现
     * @param integer  $user_id     用户ID
     * @param integer  $type        状态
     * @return array
     */
    public function forbid_trade(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_user_service->update_forbid_trade($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 审核详情（获取）
     * @param integer  $id     用户ID
     * @return array
     */
    public function check_detail(){
        $this->form_validation->set_rules('id','ID','required');
        $this->form_validation->set_rules('type','类型','required'); //区分 法币买入1、法币卖出2、提币3
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $type = $this->input->post('type');
        $data = $this->Zjys_user_service->check_detail($id,$type);
        returnJson('200',lang('operation_successful'),$data);
    }


    // 统计用户相关参数
    public function statistics_users()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->statistics_users($offset,$limit,$start_time,$end_time,$site_id);
        $count = $this->Zjys_user_service->statistics_users_count($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //定时任务统计
    // public function statistics_users_task()
    // {
    //     $args = $this->input->get();
    //     $data['list'] = $this->Zjys_user_service->statistics_users_task($args);
    //     returnJson('200',lang('operation_successful'),$data);
    // }

    public function statistics_users_printexcel()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';

        $offset = ($page - 1) * $limit;
        $list= $this->Zjys_user_service->statistics_users(0,'',$start_time,$end_time,$site_id);
        $arr = array();
        foreach ($list as $key => $val){
            $arr[$key]['time_area'] = $val['time_area'];
            $arr[$key]['site_name'] = $val['site_name'];
            $arr[$key]['register_user'] = $val['register_user'];
            $arr[$key]['recommend_user'] = $val['recommend_user'];
            $arr[$key]['identity_user'] = $val['identity_user'];
            // $arr[$key]['login_user'] = $val['login_user'];
            $arr[$key]['last_rate'] = $val['last_rate'];
            $arr[$key]['three_rate'] = $val['three_rate'];
            $arr[$key]['seven_rate'] = $val['seven_rate'];
        }

        $title = array('日期','站点','注册用户数','认证用户数', '推荐用户数', '次日留存率', '三日留存率','七日留存率');
        $data1['url'] = excel_helper::print_excel($title,$arr,'user-statistic');
        // var_dump($data1);die;
        // $data1['url'] = $_SERVER['HTTP_HOST'].strstr($data1['url'],'/application');
        $filePath = strstr($data1['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    //锁仓列表
    public function lockposition_list()
    {
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = !empty($args['asset']) ? $args['asset'] : ''; //币资产
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';
        $status = isset($args['status']) ? $args['status'] : null;

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->lockposition_list($offset,$limit,$asset,$site_id,$uid,$status);
        $count = $this->Zjys_user_service->lockposition_count($asset,$site_id,$uid,$status);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function lockposition_add()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('asset','资产类型','required');
        $this->form_validation->set_rules('uid','用户id','required');
        $this->form_validation->set_rules('amount','数量','required');
        $this->form_validation->set_rules('expire_time','冻结时间点','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $res = $this->Zjys_user_service->lockposition_add($args);
        if($res === false){
            returnJson('402','操作失败');
        }else{
            returnJson('200',lang('operation_successful'));
        }

    }

    //改版增加锁仓
    // public function lockposition_add_new()
    // {
    //     $args = $this->input->post();
    //     $this->form_validation->set_rules('asset','资产类型','required');
    //     $this->form_validation->set_rules('uid','用户id','required');
    //     $this->form_validation->set_rules('amount','数量','required');
    //     $this->form_validation->set_rules('expire_time','冻结时间点','required');
    //     if($this->form_validation->run() == FALSE){
    //         returnJson('402',lang('missing_parameters'));
    //     }

    //     $res = $this->Zjys_user_service->lockposition_add_new($args);
    //     if($res === false){
    //         returnJson('402','操作失败');
    //     }else{
    //         returnJson('200',lang('operation_successful'));
    //     }

    // }

    public function lockposition_delete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $time = date('Y-m-d H:i:s',time());
        $res = $this->Zjys_user_service->lockposition_delete($id,$time);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }
    //  后台解仓
    public function unlockposition()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('asset','资产类型','required');
        $this->form_validation->set_rules('uid','用户id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $list = $this->Zjys_user_service->unlockposition($args);
        if($list === true) returnJson('200',lang('operation_successful'));
        if($list === false) returnJson('403','当前币资产无锁仓记录');
    }

    //重置认证信息
    public function resetidentity()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('id','资产类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $args['id'];
        $time = date('Y-m-d H:i:s',time());
        $list = $this->Zjys_user_service->resetidentity($id,$time);
        returnJson('200',lang('operation_successful'));
    }

    //后台修改账户邮箱和手机号
    public function edit_phoneoremail()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('id','资产类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $phone = !empty($args['phone']) ? intval($args['phone']) : ''; //当前页
        $phone = str_replace(' ','',$phone);
        // $pattern = "/^[0,9]{9,20}$/";
        // if(!preg_match("/^[0-9]{5,20}+$/", $phone)){
        //     returnJson('402',lang('mobile_preg_match'));
        // }
        $email = !empty($args['email']) ? intval($args['email']) : ''; //当前页

        $id = $args['id'];
        $phone = $args['phone'];
        $email = $args['email'];

        // var_dump($id,$phone,$email);die;

        $result = $this->Zjys_user_service->edit_phoneoremail($id,$phone,$email);
        if($result)
            returnJson('200',lang('operation_successful'));
        else
            returnJson('402','修改账户信息失败，请检查合法性！');

    }
    //审核用户认证信息
    public function user_identity_check()
    {
        $data = $this->input->post();
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }

        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['remark'];
        $result = $this->Zjys_user_service->user_identity_checkout($id,$status,$remark);
        returnJson('200',lang('operation_successful'),$result);
    }

    //获取国家的接口
    public function country_list()
    {
        $result = $this->Identity_service->get_country_list();
        returnJson('200',lang('operation_successful'),$result);
    }
    //用户推荐列表
    public function user_recomend_list()
    {
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';//当前用户ID
        $top_uid = !empty($args['top_uid']) ? $args['top_uid'] : '';//上级用户ID
        $iiid = !empty($args['iiid']) ? $args['iiid'] : '';//上上级用户ID
        $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Identity_service->user_recomend_list($offset,$limit,$site_id,$uid,$top_uid,$iiid,$user_identity_auth,$start_time,$end_time);
        $count = $this->Identity_service->user_recomend_list_count($site_id,$uid,$top_uid,$iiid,$user_identity_auth,$start_time,$end_time);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //用户推荐列表导出
    public function user_recomend_list_csv()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $iiid = !empty($args['iiid']) ? $args['iiid'] : '';//上上级用户ID
        $uid = !empty($args['uid']) ? $args['uid'] : '';//当前用户ID
        $top_uid = !empty($args['top_uid']) ? $args['top_uid'] : '';//上级用户ID
        $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : '';

        $offset = ($page - 1) * $limit;
        $list = $this->Identity_service->user_recomend_list(0,'',$site_id,$uid,$top_uid,$iiid,$user_identity_auth,$start_time,$end_time);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/recommend_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '当前用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '上级用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '上上级用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '邮箱' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手机号' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '邀请码' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'vip等级' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '创建时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后登陆时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '注册IP' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后登陆IP' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '实名认证时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后充值时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后交易时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['recommend_user_id'],
                $value['user_id'],
                $value['iiid'],
                $value['email'],
                $value['phone'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['recommend_code'] ),
                $value['vip_level'],
                $value['created_at'],
                $value['last_login'],
                $value['register_ip'],
                $value['last_ip'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['identity_success_time'],
                $value['last_recharge_time'],
                $value['last_trade_time'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    //重置用户登陆密码和资金密码 1:登陆密码。2:资金密码
    public function reset_password()
    {
        $args =$this->input->post();
        $status = isset($args['status']) ? $args['status'] : false;
        $user_id = isset($args['user_id']) ? $args['user_id'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        if(!$user_id){
            returnJson('402',lang('missing_parameters'));
        }

        $this->Identity_service->reset_password($status,$user_id);
        returnJson('200',lang('operation_successful'));
    }


    /**
     * Notes: 批量生成用户
     * User: 张哲
     * Date: 2018/12/17
     * Time: 14:47
     */
    public function batch_user_file()
    {
        $args = $this->input->post();
        $file = $_FILES['file'];
        $filename = $file['tmp_name'];
        $name = substr($file['name'],strpos($file['name'],'.')+1);
        if($name!=='csv') returnJson('402','文件格式错误');
        if (empty ($filename)) returnJson('402','csv文件缺失');
        $handle = fopen($filename, 'r');
        while ($data = fgetcsv($handle)) { //每次读取CSV里面的一行内容
            $list[] = $data;
        }
        if($list[0][0] === null) returnJson('402','没有数据');

        fclose($handle); //关闭指针

        foreach ($list as $key => $value) {

            // if (is_numeric($value[0])){
            $args['mobile'] = $value[0];
            $result[$key] = $args;
//            }
//           else{
//               returnJson('402','格式不对');
//           }
        }

        foreach ($result as $key => $value) {
            $data = $this->Sys_grpc_service->BatchCreateUsers($value['mobile']);

            if($data!==true) returnJson('402','从此条数据'.$value['mobile'].'起（包括此条），下方的数据均未生成');
            usleep(2000);
        }
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 添加邀请关系
     * params:邀请人手机号或邮箱 re_name  邀请人id re_id  被邀请人手机号或邮箱 user_name  被邀请人id user_id
     */
    public function add_recommend()
    {
        $args = $this->input->post();
        $re_name = isset($args['re_name']) ? $args['re_name'] : '';
        $re_id = isset($args['re_id']) ? $args['re_id'] : '';
        $user_name = isset($args['user_name']) ? $args['user_name'] : '';
        $user_id = isset($args['user_id']) ? $args['user_id'] : '';

        $res = $this->Zjys_user_service->add_recommend($re_name,$re_id,$user_name,$user_id);
        if($res)
            returnJson(200,lang('operation_successful'));
        else
            returnJson(200,lang('operation_failed'));

    }
    /**
     * 客户端登录历史列表
     * @return [json] [description]
     */
    public function websafe_login_logs()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('user_id','用户ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $user_id = $args['user_id'];

        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->websafe_login_logs($offset,$limit,$user_id);
        $count = $this->Zjys_user_service->websafe_login_logs_count($user_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);

    }

    /**
     * 客户端操作历史列表
     * @return [json] [description]
     */
    public function websafe_operation_logs()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('user_id','用户ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $user_id = $args['user_id'];

        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->websafe_operation_logs($offset,$limit,$user_id);
        $count = $this->Zjys_user_service->websafe_operation_logs_count($user_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);

    }


    /**
     * Notes: vip记录
     * User: 张哲
     * Date: 2019-07-19
     * Time: 17:01
     * 1.获取记录
     * 2.编辑
     * 3.审核
     * 4.user_vips
     */
    public function vipRecord(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $user_id = !empty($args['user_id']) ? $args['user_id'] : '';
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $vip_level = isset($args['vip_level']) ? $args['vip_level'] : '';
        $status = isset($args['status']) ? $args['status'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_user_service->vipRecord($offset,$limit,$start_time,$end_time,$user_id,$vip_level,$status);
        $count = $this->Zjys_user_service->vipRecordCount($start_time,$end_time,$user_id,$vip_level,$status);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 新增编辑VIP等级
     * User: 张哲
     * Date: 2019-07-20
     * Time: 15:33
     */
    public function vipAddEdit()
    {
        $this->form_validation->set_rules('user_id','id','required');
        $this->form_validation->set_rules('remark','id','required');
        $this->form_validation->set_rules('vip_level','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_user_service->vipAddEdit($args);

        returnJson('200',lang('operation_successful'),$res);
    }


    /**
     * Notes: VIP等级审核
     * User: 张哲
     * Date: 2019-07-20
     * Time: 15:33
     */
    public function vipAddEditVerity()
    {
        $this->form_validation->set_rules('id','id','required');
        $this->form_validation->set_rules('verity_remark','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_user_service->vipAddEditVerity($args);

        returnJson('200',lang('operation_successful'),$res);
    }


    /**
     * Notes: vip等级删除
     * User: 张哲
     * Date: 2019-07-23
     * Time: 13:58
     */
    public function vipDelete()
    {
        $this->form_validation->set_rules('id','id','required');
        $this->form_validation->set_rules('cancel_remark','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_user_service->vipDelete($args);

        returnJson('200',lang('operation_successful'),$res);
    }

}
