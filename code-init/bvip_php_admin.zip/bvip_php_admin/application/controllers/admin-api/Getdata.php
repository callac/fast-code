<?php
defined('BASEPATH') OR exit('No direct script access allowed');
set_time_limit(0);

class Getdata extends Base_Controller
{
    public $zt_exchange_db;

    public $zt_tradehistory_db;

    public $local_exchange_db;

    public $local_tradehistory_db;

    function __construct() {
        //初始化数据库连接对象
        parent::__construct();
        //真机环境
        $this->exchange = $this->load->database('default',true); 
        $this->tradehistory = $this->load->database('trade_history',true);
        $this->local_exchange = $this->load->database('default',true);
        // $this->activity = $this->load->database('activity',true);
        $this->activity = TRUE;
        
        //ZT线上环境
        // $this->exchange = $this->load->database('zt_exchange_onlyread',true);
        // $this->tradehistory = $this->load->database('zt_tradehistory_onlyread',true);
        // $this->exchange = $this->load->database('zt_exchange_onlyread',true);



         
        //本地环境
        // $this->exchange = $this->load->database('local_exchange',true); 
        // $this->tradehistory = $this->load->database('local_trade_history',true);
        // $this->local_exchange = $this->load->database('local_exchange',true);

        $this->load->service('Getdata_service');
    }

    /**
     * recycle循环统计方法
     * @return [type] [description]
     */
    public function recycle_method_curl()
    {
        $args = $this->input->get();
        // var_dump($args['method']);die;
        if((isset($args['method']) ? trim($args['method']) : FALSE) === FALSE) returnJson('403','missing_parameters1');
        if((isset($args['ctime']) ? trim($args['ctime']) : FALSE) === FALSE) returnJson('403','missing_parameters2');
        if((isset($args['etime']) ? trim($args['etime']) : FALSE) === FALSE) returnJson('403','missing_parameters3');
        // if((isset($args['site_id']) ? trim($args['site_id']) : FALSE) === FALSE) returnJson('403','missing_parameters4');
        
        // $site_id = $args['site_id'];
        $method =$args['method'];
        $ctime =strtotime($args['ctime']);
        $etime =strtotime($args['etime']);

        $url = 'http://localhost:9085/index.php/getdata/'.$method;

        $arr = get_timearea_by_day($ctime,$etime);
        
        for($i=0;$i<count($arr);$i++)
        {
            $params = '?time='.date('Y-m-d H:i:s',$arr[$i]);
            $get_url = $url.$params;
            // var_dump($get_url);die;
            $ch = curl_init();
            // 设置请求为post类型
            curl_setopt($ch, CURLOPT_POST, 0);
            // 2. 设置请求选项, 包括具体的url
            curl_setopt($ch, CURLOPT_URL, $get_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            // 3. 执行一个cURL会话并且获取相关回复
            $response = curl_exec($ch);
            curl_close($ch);
        }
    }


    /**
     * 去重数据写入数据库
     * @return 
     */
    function deduplication_data()
    {
        $args = $this->input->get();
        $this->Getdata_service->deduplication_data($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }
    
    function usertotal()
    {
        $args = $this->input->get();
        $this->Getdata_service->usertotal($args,$this->zt_exchange_db,$this->zt_tradehistory_db,$this->local_exchange);
    }
    //币币交易
    function tradetotal()
    {
        $args = $this->input->get();
        $this->Getdata_service->tradetotal($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }

    function tradetotal_test()
    {
        $args = $this->input->get();
        $this->Getdata_service->tradetotal_test($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }


    function recharge_logs_csv()
    {
        $args = $this->input->get();
        $this->Getdata_service->rechargelogs($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }

    function user_withdraw_csv()
    {
        $args = $this->input->get();
        $this->Getdata_service->withdrawlogs($args,$this->exchange,$this->tradehistory,$this->local_exchange);
    }

    function deal_fee()
    {
        $args = $this->input->get();
        $args['jyq'] = $this->config->item('trade_area');
        $data = $this->Getdata_service->deal_fee($args,$this->exchange,$this->tradehistory);
        returnJson('200',lang('operation_successful'),$data);
    }

    function get_payment()
    {
        $args = $this->input->get();
        $this->Getdata_service->get_payment($args,$this->exchange,$this->activity);
    }
}
