<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Zjys_symbols extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_symbols_service');
    }
    //
    public function symbol_list(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = !empty($args['symbol']) ? $args['symbol'] : ''; //资产码
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_symbols_service->symbol_list($offset,$limit,$symbol,$start_time,$end_time,$site_id);
        $count = $this->Zjys_symbols_service->symbol_list_count($symbol,$start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function symbol_list_noauth(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = !empty($args['symbol']) ? $args['symbol'] : ''; //资产码
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_symbols_service->symbol_list($offset,$limit,$symbol,$start_time,$end_time,$site_id);
        $count = $this->Zjys_symbols_service->symbol_list_count($symbol,$start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function system_symbol_list(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = !empty($args['symbol']) ? $args['symbol'] : ''; //资产码
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_symbols_service->system_symbol_list($offset,$limit,$symbol,$start_time,$end_time);
        $count = $this->Zjys_symbols_service->system_symbol_list_count($symbol,$start_time,$end_time);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function symbol_list_totalsite(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 5000; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = !empty($args['symbol']) ? $args['symbol'] : ''; //资产码
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null;
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        // $site_id = 1;
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_symbols_service->symbol_list_totalsite($offset,$limit,$symbol,$start_time,$end_time,$site_id);
        $count = count($data['list']);
        // $count = $this->Zjys_symbols_service->symbol_list_count($symbol,$start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }



    //新增币资产种类
    public function add_symbol(){
        $this->form_validation->set_rules('base_asset','基准资产类型','required');
        $this->form_validation->set_rules('quote_asset','目标资产类型','required');
        $this->form_validation->set_rules('symbol', '交易对','required');
        $this->form_validation->set_rules('tick_size','交易价格步增','required');
        $this->form_validation->set_rules('min_quantity', '最小交易量','required');
        $this->form_validation->set_rules('status','是否可交易','required'); //前台单选框
        $this->form_validation->set_rules('recommend','是否推荐','required');//前台单选框
        $this->form_validation->set_rules('limit_taker_fee','taker限价费率','required');
        $this->form_validation->set_rules('limit_maker_fee','maker限价费率','required');
        $this->form_validation->set_rules('market_taker_fee','市场限价费率','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_symbols_service->add_symbol($args);
        if($res === false){
            returnJson('402',lang('operation_failed'));
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }


    public function system_symbol_add(){
        $this->form_validation->set_rules('base_asset','基准资产类型','required');
        $this->form_validation->set_rules('base_asset_name','基准资产类型名称','required');
        $this->form_validation->set_rules('quote_asset','目标资产类型','required');
        $this->form_validation->set_rules('quote_asset_name','目标资产类型名称','required');
        $this->form_validation->set_rules('symbol', '交易对','required');
        $this->form_validation->set_rules('tick_size','交易价格步增','required');
        $this->form_validation->set_rules('min_quantity', '最小交易量','required');
        $this->form_validation->set_rules('status','是否可交易','required'); //前台单选框
        $this->form_validation->set_rules('recommend','是否推荐','required');//前台单选框
        $this->form_validation->set_rules('limit_taker_fee','taker限价费率','required');
        $this->form_validation->set_rules('limit_maker_fee','maker限价费率','required');
        $this->form_validation->set_rules('market_taker_fee','市场限价费率','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_symbols_service->system_symbol_add($args);
        if($res === false){
            returnJson('402',lang('operation_failed'));
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }

    //交易区块开始
    public function symbolblock_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 5000; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $shorthand = !empty($args['shorthand']) ? $args['shorthand'] : ''; //板块简称
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';

        $offset = ($page - 1) * $limit;

        // var_dump($this->Zjys_symbols_service);die;

        $data['list']= $this->Zjys_symbols_service->symbolblock_list($offset,$limit,$shorthand,$site_id,$start_time,$end_time);
        $count = $this->Zjys_symbols_service->symbolblock_list_count($shorthand,$site_id,$start_time,$end_time);
        // $count = count($data['list']);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function symbolblock_list_noauth()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('site_id','交易区块名','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $data['list']= $this->Zjys_symbols_service->symbolblock_list_noauth($site_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    //添加币种详细介绍
    public function symbolblock_add(){
        // $this->form_validation->set_rules('name','交易区块名','required');
        $this->form_validation->set_rules('unique_id','唯一标示','required');
        $this->form_validation->set_rules('display_order', '排序','required');
        $this->form_validation->set_rules('site_id','站点','required');
        $this->form_validation->set_rules('shorthand', '简称','required');
        $this->form_validation->set_rules('symbol_ids', '简称','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args = $this->input->post();
        $res = $this->Zjys_symbols_service->symbolblock_add($args);
        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //删除币种详细介绍
    public function symbolblock_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Zjys_symbols_service->symbolblock_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','删除失败');

    }


    /**
     * Notes: 交易对配置审核
     * User: 张哲
     * Date: 2019-07-22
     * Time: 15:47
     */
    public function systemSymbolAddVerity()
    {
        $this->form_validation->set_rules('id','id','required');
        $this->form_validation->set_rules('remark','id','required');
        $this->form_validation->set_rules('type','类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_symbols_service->systemSymbolAddVerity($args);

        returnJson('200',lang('operation_successful'),$res);
    }


    /**
     * Notes: 交易对审核记录
     * User: 张哲
     * Date: 2019-07-23
     * Time: 17:52
     */
    public function systemSymbolDetailsLogs()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_symbols_service->systemSymbolDetailsLogs($args);

        returnJson('200',lang('operation_successful'),$res);
    }
}
