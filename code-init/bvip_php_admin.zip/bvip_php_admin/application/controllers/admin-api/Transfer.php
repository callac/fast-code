<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: bq-dev
 * Date: 2018/11/20
 * Time: 10:14
 */

class Transfer extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Transfer_service');
        $this->load->service('Zjys_user_service');
    }

    /**
     * Notes: 生成子站总账户列表
     * User: 张哲
     * Date: 2018/11/20
     * Time: 16:19
     */
    public function generate_total_account(){
        $data = $this->Transfer_service->generate_total_account();
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 编辑站点总账户
     * User: 张哲
     * Date: 2018/11/29
     * Time: 09:55
     */
    public function add_total_account(){
        $args = $this->input->post();
        $this->form_validation->set_rules('site_id','站点id','required');
        $this->form_validation->set_rules('user_id','用户uid','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; //用户uid
        $data = $this->Transfer_service->add_total_account($site_id,$user_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 新增币种时增加总账户币种记录
     * User: 张哲
     * Date: 2018/11/29
     * Time: 14:13
     */
    public function add_asset_record(){
        $args = $this->input->post();
        $this->form_validation->set_rules('site_id','站点id','required');
        $this->form_validation->set_rules('asset','币种','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $asset = isset($args['asset']) ? $args['asset'] : ''; //用户uid
        $data = $this->Transfer_service->add_asset_record($site_id,$asset);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes:账户增加-列表
     * User: 张哲
     * Date: 2018/11/20
     * Time: 15:27
     */
    public function get_account_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Transfer_service->get_accout_list($start_time,$end_time,$offset,$limit,$site_id);

        $count = $this->Transfer_service->get_accout_list_count($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }



    /**
     * Notes:账户增加
     * User: 张哲
     * Date: 2018/11/20
     * Time: 15:27
     */
    public function add_account(){
        $args = $this->input->post();
        $this->form_validation->set_rules('name','账号','required');
        $this->form_validation->set_rules('site_id','站点id','required');
        $this->form_validation->set_rules('user_id','用户uid','required');
        $this->form_validation->set_rules('remark','备注','');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $name = isset($args['name']) ? $args['name'] : ''; //账号名称
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; //用户uid
        $remark = isset($args['remark']) ? $args['remark'] : ''; //站点
        $data = $this->Transfer_service->add_account($name,$site_id,$user_id, $remark);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes:账户删除
     * User: 张哲
     * Date: 2018/11/20
     * Time: 15:27
     */
    public function delete_account(){
        $args = $this->input->post();
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = isset($args['id']) ? $args['id'] : ''; //id
        $data = $this->Transfer_service->delete_accout($id);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 平台总账户资产列表
     * User: 张哲
     * Date: 2018/11/20
     * Time: 19:06
     */
    public function total_account_assets(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $offset = ($page - 1) * $limit;
        $data = $this->Transfer_service->total_account_assets($start_time,$end_time,$offset,$limit,$site_id,$page,$asset);

        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 平台总账户资产列表导出
     * User: 张哲
     * Date: 2018/11/27
     * Time: 14:58
     */
    public function total_account_assets_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $list = $this->Transfer_service->total_account_assets_csv($start_time,$end_time,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/total_account_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', 'ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '资产' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当前总数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计负债' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '已还款' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '待还款' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                $value['asset'],
                $value['balance'],
                $value['loan_total'],
                $value['repayment_total'],
                $value['wait_repayment'],
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(13,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }



    /**
     * Notes: 获取当前用户当前币种余额
     * User: 张哲
     * Date: 2018/11/21
     * Time: 15:33
     */
    public function check_balance()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('transfer_out_uid','转出用户id','required');
        $this->form_validation->set_rules('asset','币种','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $transfer_out_uid = isset($args['transfer_out_uid']) ? $args['transfer_out_uid'] : '';
        $asset = isset($args['asset']) ? $args['asset'] : '';

        $data = $this->Transfer_service->check_balance($transfer_out_uid,$asset);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 转账列表
     * User: 张哲
     * Date: 2018/11/21
     * Time: 19:56
     */
    public function transfer_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Transfer_service->transfer_list($start_time,$end_time,$offset,$limit,$asset);
        $count = $this->Transfer_service->transfer_list_count($start_time,$end_time,$asset);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 转让数据导出
     * User: 张哲
     * Date: 2018/11/21
     * Time: 20:18
     */
    public function transfer_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $list = $this->Transfer_service->transfer_csv($start_time,$end_time,$asset,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/transfer_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '转出账户uid' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '转入账户uid' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '操作人' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['asset'],
                $value['transfer_out_uid'],
                $value['transfer_in_uid'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['true_name'] ),
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(9,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }

    //13个
    //借款、还款、资产列表、资产列表导出、借款记录列表、借款记录列表导出、还款记录列表、还款记录列表导出、赠币列表、赠币列表导出、新增赠币、批量新增赠币（需研究）
    //充值提现监控
    //借款先查询账户id是否正确，正确则直接给加余额
    //还款先查询账户id是否正确，再查询数量和钱包是否一致


    /**
     * Notes: 总账户还款功能
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:06
     */
    public function repayment(){
        $args = $this->input->post();
        $this->form_validation->set_rules('user_id','用户id','required');
        $this->form_validation->set_rules('payer_id','还款人id','required');
        $this->form_validation->set_rules('asset','币种','required');
        $this->form_validation->set_rules('site_id','币种','required');
        $this->form_validation->set_rules('amount','数量','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        if($this->Transfer_service->repayment($args)===true){
            returnJson('200',lang('repayment successful'));
        }else{
            returnJson('402',lang('repayment failed'));
        }
    }


    /**
     * Notes: 还款账户地址
     * User: 张哲
     * Date: 2018/11/29
     * Time: 16:05
     */
    public function repayment_address(){
        $args = $this->input->post();
        $this->form_validation->set_rules('user_id','用户uid','required');
        $this->form_validation->set_rules('asset','币种','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; //用户uid
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $data = $this->Transfer_service->repayment_address($user_id,$asset);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 借款列表
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:29
     */
    public function loan_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Transfer_service->loan_list($start_time,$end_time,$offset,$limit,$asset,$site_id);
        $count = $this->Transfer_service->loan_list_count($start_time,$end_time,$asset,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 还款列表
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:29
     */
    public function repayment_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Transfer_service->repayment_list($start_time,$end_time,$offset,$limit,$asset,$site_id);
        $count = $this->Transfer_service->repayment_list_count($start_time,$end_time,$asset,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes:  借款列表-导出
     * User: 张哲
     * Date: 2018/11/22
     * Time: 11:44
     */
    public function loan_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $list = $this->Transfer_service->loan_csv($start_time,$end_time,$asset,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/loan_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户uid' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '管理员' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['asset'],
                $value['user_id'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['true_name'] ),
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(10,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 还款列表-导出
     * User: 张哲
     * Date: 2018/11/22
     * Time: 14:37
     */
    public function repayment_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $list = $this->Transfer_service->repayment_csv($start_time,$end_time,$asset,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/c2cbuy_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '还款ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '平台账户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '管理员' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['asset'],
                $value['payer_id'],
                $value['user_id'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['true_name'] ),
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(11,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 赠币管理列表
     * User: 张哲
     * Date: 2018/11/23
     * Time: 15:39
     */
    public function gift_coin_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $user_id = isset($args['uid']) ? $args['uid'] : ''; //用户id
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $lock = isset($args['lock']) ? $args['lock'] : ''; //赠币类型
        $admin_id = isset($args['admin_id']) ? $args['admin_id'] : ''; //管理员id
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Transfer_service->gift_coin_list($start_time,$end_time,$offset,$limit,$asset,$site_id,$user_id,$lock,$admin_id);
        $count = $this->Transfer_service->gift_coin_list_count($start_time,$end_time,$asset,$site_id,$user_id,$lock,$admin_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes:赠币管理列表导出
     * User: 张哲
     * Date: 2018/11/23
     * Time: 15:48
     */
    public function gift_coin_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $user_id = isset($args['uid']) ? $args['uid'] : ''; //用户id
        $lock = isset($args['lock']) ? $args['lock'] : ''; //赠币类型
        $admin_id = isset($args['admin_id']) ? $args['admin_id'] : ''; //管理员id
        $list = $this->Transfer_service->gift_coin_csv($asset,$site_id,$user_id,$lock,$admin_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/gift_coin_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '赠送账户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '是否锁仓' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '解锁时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '管理员' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['asset'],
                $value['user_id'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['lock'] ),
                $value['expire_time'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['true_name'] ),
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(12,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 赠币修改版
     * User: 张哲
     * Date: 2019/3/27
     * Time: 16:37
     */
//    public function batch_gift_coin(){
//        $args = $this->input->post();
//        $result = json_decode($args['arr'],true);
//        $gift =  $this->Transfer_service->save_data($result,$args['site_id']);
//        if($gift===true){
//            //1.存入一个新的表  2.从表中取数据，
//            foreach ($result as $value) {
//                $sum = $value['amount'];
//                $data = $this->Transfer_service->batch_gift_coin($value,$sum,$args['site_id']);
//
//                if($data!==true) returnJson('402','从此条数据'.$data['uid'].','.$data['asset'].','.$data['amount'].'起（包括此条），下方的数据均未调整成功！请检查此条数据合法性！');
//                usleep(2000);
//            }
//            returnJson('200',lang('operation_successful'));
//        }
//
//    }

    /**
     * Notes: 赠币实例
     * User: 张哲
     * Date: 2018/12/7
     * Time: 15:44
     */
    public function gift_sample_csv(){
        $list = $this->Transfer_service->gift_sample_csv();
        //if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/gift_coin_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '是否锁仓0 否 1 是' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '解锁时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                $value['asset'],
                $value['amount'],
                $value['lock'],
                $value['expire_time'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(12,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 总账户借款功能
     * User: 张哲
     * Date: 2018/11/22
     * Time: 10:05
     */
    public function loan(){
        $args = $this->input->post();
        $this->form_validation->set_rules('user_id','用户id','required');
        $this->form_validation->set_rules('asset','币种','required');
        $this->form_validation->set_rules('site_id','币种','required');
        $this->form_validation->set_rules('amount','数量','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        if($this->Transfer_service->loan_total($args)===true){
            returnJson('200',lang('loan successful'));
        }else{
            returnJson('402',lang('loan failed'));
        }
    }


    /**
     * Notes:借款-插入记录
     * User: 张哲
     * Date: 2019-06-10
     * Time: 18:27
     */
    public function loan1(){
        $args = $this->input->post();
        $this->form_validation->set_rules('user_id','用户id','required');
        $this->form_validation->set_rules('asset','币种','required');
        $this->form_validation->set_rules('site_id','站点','required');
        $this->form_validation->set_rules('amount','数量','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        if($this->Transfer_service->loan_total($args)===true){
            returnJson('200',lang('loan successful'));
        }else{
            returnJson('402',lang('loan failed'));
        }
    }


    /**
     * Notes: 借款审核-具体的操作
     * User: 张哲
     * Date: 2019-06-18
     * Time: 11:32
     */
    public function loan_verity(){
        $args = $this->input->post();
        $this->form_validation->set_rules('id','用户id','required');
        $this->form_validation->set_rules('type','类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        if($this->Transfer_service->loan_verity($args)===true){
            returnJson('200',lang('loan successful'));
        }else{
            returnJson('402',lang('loan failed'));
        }
    }


    /**
     * Notes: 转账操作
     * User: 张哲
     * Date: 2018/11/21
     * Time: 10:47
     */
    public function transfer_user_money()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('transfer_out_uid','转出用户id','required');
        $this->form_validation->set_rules('transfer_in_uid','转入用户id','required');
        $this->form_validation->set_rules('asset','币种','required');
        $this->form_validation->set_rules('amount','数量','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $data = $this->Transfer_service->transfer_user_money($args);
        if($data===true){
            returnJson('200',lang('submit success'));
        }else{
            returnJson('403',$data);
        }
    }

    /**
     * Notes: 转账审核
     * User: 张哲
     * Date: 2019-06-11
     * Time: 09:32
     */
    public function transfer_user_money_verity()
    {
        $args = $this->input->post();
//        if($args['lock'] == 1){
//            //锁仓
//            $this->form_validation->set_rules('asset','资产类型','required');
//            $this->form_validation->set_rules('uid','用户id','required');
//            $this->form_validation->set_rules('amount','数量','required');
//            $this->form_validation->set_rules('expire_time','冻结时间点','required');
//            if($this->form_validation->run() == FALSE){
//                returnJson('402',lang('missing_parameters'));
//            }
//            $transfer = $this->Transfer_service->transfer_user_money($args);
//            $res = $this->Zjys_user_service->lockposition_add($args);
//
//            if($transfer ===true && $res === true){
//                returnJson('200',lang('Transfer successful'));
//            }else{
//                returnJson('403',lang('Transfer failed'));
//            }
//        }else{
        $data = $this->Transfer_service->transfer_user_money_verity($args);
        if($data===true){
            returnJson('200',lang('Transfer successful'));
        }else{
            returnJson('404',$data);
        }
    }


    /**
     * Notes: 单个用户赠币
     * User: 张哲
     * Date: 2019-06-18
     * Time: 19:04
     */
    public function gift_coin(){
        $args = $this->input->post();
        $this->form_validation->set_rules('uid','用户id','required');
        $this->form_validation->set_rules('asset','币种','required');
        $this->form_validation->set_rules('site_id','站点','');
        $this->form_validation->set_rules('amount','数量','required');
        $this->form_validation->set_rules('lock','是否锁仓','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        if($this->Transfer_service->gift_coin($args)===true){
            returnJson('200',lang('gift successful'));
        }else{
            returnJson('402',lang('gift failed'));
        }
    }


    /**
     * Notes: 单个赠币-审核
     * User: 张哲
     * Date: 2019-06-11
     * Time: 09:35
     */
    public function gift_coin_verity(){
        $arg = $this->input->post();

        $this->form_validation->set_rules('id','ID','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $id = $arg['id'];
        //获取改借款记录数据
        $object = $this->db->select("platfrom_gift_coin_record.*")
            ->from('platfrom_gift_coin_record');
        $object = $this->db->where('platfrom_gift_coin_record.id =', $id);
        $gift = $object->get()->result_array();
        if(!empty($gift))
            $args = array();
        $args['id'] = $id;
        $args['type'] = $arg['type'];
        $args['uid'] = $gift[0]['user_id'];
        $args['asset'] = $gift[0]['asset'];
        $args['site_id'] = $gift[0]['site_id'];
        $args['amount'] = $gift[0]['amount'];
        $args['lock'] = $gift[0]['lock'];
        $args['expire_time'] = $gift[0]['expire_time'];
        $args['remark'] = $gift[0]['remark'];

        if($this->Transfer_service->gift_coin_verity($args)===true){
            returnJson('200',lang('gift successful'));
        }else{
            returnJson('402',lang('gift failed'));
        }
    }


    /**
     * Notes: 批量赠币获取文件
     * User: 张哲
     * Date: 2018/11/26
     * Time: 14:03
     */
    public function batch_gift_file()
    {
        $args = $this->input->post();
        $file = $_FILES['file'];
        // var_dump($args,$_FILES['file'],$file);die();
        $filename = $file['tmp_name'];
        $name = substr($file['name'],strpos($file['name'],'.')+1);
        if($name!=='csv') returnJson('402','文件格式错误');
        if (empty ($filename)) returnJson('402','csv文件缺失');
        $handle = fopen($filename, 'r');
        while ($data = fgetcsv($handle)) { //每次读取CSV里面的一行内容
            $list[] = $data;
        }
        if($list[0][0] === null) returnJson('402','没有数据');

        fclose($handle); //关闭指针

        foreach ($list as $key => $value) {
            $args['uid'] = $value[0];
            $args['asset'] = $value[1];
            $args['amount'] = $value[2];
            $args['lock'] = isset($value[3]) ? $value[3] : '';
            $args['expire_time'] = isset($value[4]) ? $value[4] : '';
            $encode = mb_detect_encoding($value[5], array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
            $args['remark'] = mb_convert_encoding($value[5], 'UTF-8',$encode);
            $result[$key] = $args;
        }
        returnJson('200',lang('operation_successful'),$result);
    }

    /**
     * Notes: 确认后扣除
     * User: 张哲
     * Date: 2018/11/30
     * Time: 10:37
     */
    public function batch_gift_coin(){
        $args = $this->input->post();
        $result = json_decode($args['arr'],true);
        //1.存入一个新的表  2.从表中取数据，
        foreach ($result as $value) {
            $sum = $value['amount'];
            $data = $this->Transfer_service->batch_gift_coin($value,$sum,$args['site_id']);

            if($data!==true) returnJson('402','从此条数据'.$data['uid'].','.$data['asset'].','.$data['amount'].'起（包括此条），下方的数据均未调整成功！请检查此条数据合法性！');
            //usleep(2000);
        }
        returnJson('200',lang('operation_successful'));
    }




    /**
     * Notes: 批量赠币审核
     * User: 张哲
     * Date: 2019-06-11
     * Time: 09:36
     */
    public function batch_gift_coin_verity(){
        $args = $this->input->post();
        $result = json_decode($args['id'],true);
        //1.存入一个新的表  2.从表中取数据，
        foreach ($result as $value) {
            $sum = $value['amount'];
            $data = $this->Transfer_service->batch_gift_coin_verity($value,$sum,$value['site_id'],$args['type']);

            if($data!==true) returnJson('402','从此条数据'.$data['uid'].','.$data['asset'].','.$data['amount'].'起（包括此条），下方的数据均未调整成功！请检查此条数据合法性！');
            //usleep(2000);
        }
        returnJson('200',lang('operation_successful'));
    }
}



