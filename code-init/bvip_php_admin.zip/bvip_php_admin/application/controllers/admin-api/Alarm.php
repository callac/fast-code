<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 账户管理
 */

class Alarm extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Alarm_service');
        $this->load->service('Rm_parameter_service');
    }




    public function rabbit_message(){

        $start_time = time();
        $end_time = $start_time-84000;
        $id = 1;
        $message =2;
        $business = 2;
        //读取交易数据
        $data = $this->Alarm_service->rabbit_message($id,$message,$business);

    }
   /*
    1.取从当前时间往前的半小时内的交易记录
    2.按交易对取数组中价格的最大值、最小值
    3.按交易对根据ID找到上一条记录的价格
    4.安交易对这段时间内该交易对的总量
   */
   /**
    * 异常交易价格警报
    * @Author   张哲
    * @DateTime 2018-10-17
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type]       [description]
    */
    public function price_alarm(){
        // $time = time();
        $time_area = date('Y-m-d',time());
        $start_time = strtotime($time_area);
        $end_time = $start_time-1800;
        //读取交易数据111
        $data = $this->Alarm_service->get_trade_statistic(1535042062,1549587132);
        //读取参数表配置
       // $data = $this->Alarm_service->get_trade_statistic(1535042062,1549587132);
        //取出数组中的一个字段组成新的数组
        // $market_array = array_column($data, 'market');
        // $price_array = array_column($data, 'price');
        // $max_price = max($price_array);
        // $min_price = min($price_array);
        // var_dump($max_price,$min_price);

    }

   /**
    * 异常交易警报
    * @Author   张哲
    * @DateTime 2018-10-18
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type]       [description]
    */
    // public function transaction_alarm(){

    //     $start_time = time();
    //     $end_time = $start_time-84000;
    //     //读取交易数据
    //     $data = $this->Alarm_service->get_transaction_alarm($end_time,$start_time);
       
    // }

     /**
    * 异常盈亏监控
    * @Author   张哲
    * @DateTime 2018-10-18
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type]       [description]
    */
    // public function profit_loss_alarm(){
    //     // $time = time();
    //     //读取交易数据
    //     $data = $this->Alarm_service->get_profit_loss();

      
    // }

    /**
    * 异常账目警报
    * @Author   张哲
    * @DateTime 2018-10-19
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type]       [description]
    */
    // public function account_alarm(){
    //     // $time = time();
    //     //读取数据
    //     $data = $this->Alarm_service->get_account_alarm();
    // }


    public function withdraws_alarm(){
        //读取数据
        $data = $this->Alarm_service->get_withdraws_alarm();
    }

    /**
     * Notes:重复充币地址
     * User: 张哲
     * Date: 2018/11/29
     * Time: 18:41
     */
    public function recharge_address_alarm(){
        //读取数据
        $data = $this->Alarm_service->recharge_address_alarm();
    }

    /**
     * 前台接口-获取交易对
     * @Author   张哲
     * @DateTime 2018-10-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
     public function get_market(){
        $args = $this->input->post(); 
        $site_id = isset($args['site_id']) ? $args['site_id'] : '';
        //读取数据
        $data = $this->Alarm_service->get_market($site_id);  
        returnJson('200',lang('operation_successful'),$data);  
    }

    /**
     * 前台接口-异常交易报警列表
     * @Author   张哲
     * @DateTime 2018-10-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
     public function get_transaction_alarm_list(){
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $symbol = isset($args['symbol']) ? $args['symbol'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Alarm_service->get_transaction_list($offset,$limit,$start_time,$end_time,$site_id,$symbol);
        $count = $this->Alarm_service->get_transaction_count($start_time,$end_time,$site_id,$symbol);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);    
    }

    /**
     * 前台接口-盈亏报警列表
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
     public function get_profit_loss_alarm_list(){
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $sort = isset($args['sort']) ? $args['sort'] : 0; 
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Alarm_service->get_profit_loss_list($offset,$limit,$start_time,$end_time,$site_id,$sort);
        $count = $this->Alarm_service->get_profit_loss_count($start_time,$end_time,$site_id,$sort);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);    
    }


    /**
     * 前台接口-异常账目报警列表
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
     public function get_account_alarm_list(){
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        //$uid = isset($args['uid']) ? $args['uid'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Alarm_service->get_account_list($offset,$limit,$start_time,$end_time,$site_id);
        $count = $this->Alarm_service->get_account_count($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);    
    }


    /**
     * 异常交易参数设置数据获取
     * @Author   张哲
     * @DateTime 2018-10-29
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
     public function get_transaction_param(){
        $args = $this->input->post(); 
       // $this->form_validation->set_rules('symbol','交易对','required');
        $this->form_validation->set_rules('site_id','站点id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
       // $symbol = isset($args['symbol']) ? $args['symbol'] : ''; //交易对
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Alarm_service->get_transaction_param($site_id);
        returnJson('200',lang('operation_successful'),$data);   
    }

    /**
     * 修改异常交易参数设置
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function modify_transaction_param(){
        $args = $this->input->post();
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $arr = $args['arr'];
        $result = json_decode($arr,true);
        $data = $this->Alarm_service->modify_transaction_param($result,$site_id);
        returnJson('200',lang('operation_successful'),$data);
    }



    /**
     * 异常账目参数设置数据获取
     * @Author   张哲
     * @DateTime 2018-10-29
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
     public function get_account_param(){
        $args = $this->input->post(); 
        $this->form_validation->set_rules('site_id','站点id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
       
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Alarm_service->get_account_param($site_id);
        returnJson('200',lang('operation_successful'),$data);   
    }

    /**
     * 异常账目报警参数
     * @Author   张哲
     * @DateTime 2018-10-22
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function modify_account_param(){
        $args = $this->input->post(); 
        $this->form_validation->set_rules('rate','百分比','required');
        $this->form_validation->set_rules('send_time','发送间隔个时间','');
       // $this->form_validation->set_rules('target_phone','目标手机','');
        $this->form_validation->set_rules('site_id','站点id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $rate = isset($args['rate']) ? $args['rate'] : ''; //百分比
        $send_time = isset($args['send_time']) ? $args['send_time'] : ''; //发送时间间隔
        //$target_phone = isset($args['target_phone']) ? $args['target_phone'] : ''; //目标手机
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Alarm_service->modify_account_param($rate,$send_time,$site_id);
        returnJson('200',lang('operation_successful'),$data);    
    }

    /**
     * 异常盈亏参数设置数据获取
     * @Author   张哲
     * @DateTime 2018-11-01
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
     public function get_profit_param(){
        $args = $this->input->post(); 
        $this->form_validation->set_rules('site_id','站点id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
       
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Alarm_service->get_profit_param($site_id);
        returnJson('200',lang('operation_successful'),$data);   
    }

    //1.去除邮箱  2.添加接受通知功能  3.每种监控的通知  4.增加新的监控信息
    /**
     * 异常盈亏报警参数
     * @Author   张哲
     * @DateTime 2018-11-01
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function modify_profit_param(){
        $args = $this->input->post(); 
        $this->form_validation->set_rules('rate','百分比','required');
        $this->form_validation->set_rules('send_time','发送间隔个时间','');
        //$this->form_validation->set_rules('target_phone','目标手机','');
        $this->form_validation->set_rules('site_id','站点id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $rate = isset($args['rate']) ? $args['rate'] : ''; //百分比
        $send_time = isset($args['send_time']) ? $args['send_time'] : ''; //发送时间间隔
       // $target_phone = isset($args['target_phone']) ? $args['target_phone'] : ''; //目标手机
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Alarm_service->modify_profit_param($rate,$send_time,$site_id);
        returnJson('200',lang('operation_successful'),$data);    
    }

   
    /**
     * 白名单展示
     * @Author   张哲
     * @DateTime 2018-11-07
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function user_white_list(){
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = isset($args['site_id']) ? $args['site_id'] : 1; //来源
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $symbol = isset($args['symbol']) ? $args['symbol'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Alarm_service->get_user_white_list($offset,$limit,$start_time,$end_time,$site_id);
        $count = $this->Alarm_service->get_user_white_count($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data); 
    }


    /**
     * 白名单增加
     * @Author   张哲
     * @DateTime 2018-11-07
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function user_white_add(){
        $args = $this->input->post(); 
        $this->form_validation->set_rules('account','账号','required');
        $this->form_validation->set_rules('site_id','站点id','');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $account = isset($args['account']) ? $args['account'] : ''; //百分比
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Alarm_service->user_white_add($account,$site_id);
        returnJson('200',lang('operation_successful'),$data); 
    }

    /**
     * 白名单删除
     * @Author   张哲
     * @DateTime 2018-11-07
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function user_white_delete(){
        $args = $this->input->post(); 
        $this->form_validation->set_rules('account','账号','required');
        $this->form_validation->set_rules('site_id','站点id','');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $account = isset($args['account']) ? $args['account'] : ''; //百分比
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Alarm_service->user_white_delete($account,$site_id);
        returnJson('200',lang('operation_successful'),$data); 
    }


    /**
     * Notes: 充值提现监控
     * User: 张哲
     * Date: 2018/11/28
     * Time: 10:28
     */
    public function withdraws_alarm_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; //用户id
        $type = isset($args['type']) ? $args['type'] : ''; //类型
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Alarm_service->withdraws_alarm_list($offset,$limit,$start_time,$end_time,$site_id,$user_id,$type);
        $count = $this->Alarm_service->withdraws_alarm_list_count($start_time,$end_time,$site_id,$user_id,$type);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 修改状态
     * User: 张哲
     * Date: 2018/11/28
     * Time: 11:06
     */
    public function deal_status(){
        $args = $this->input->post();

        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = isset($args['id']) ? $args['id'] : '';
        $data = $this->Alarm_service->deal_status($id);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 重复地址列表
     * User: 张哲
     * Date: 2018/11/29
     * Time: 19:56
     */
    public function recharge_address_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页

        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; //用户id

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Alarm_service->recharge_address_list($offset,$limit,$start_time,$end_time,$user_id);
        $count = $this->Alarm_service->recharge_address_list_count($start_time,$end_time,$user_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 修改状态
     * User: 张哲
     * Date: 2018/11/28
     * Time: 11:06
     */
    public function address_deal_status(){
        $args = $this->input->post();
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = isset($args['id']) ? $args['id'] : '';
        $data = $this->Alarm_service->address_deal_status($id);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 增加和修改预警用户表
     * User: 张哲
     * Date: 2019/3/19
     * Time: 14:41
     */
    public function add_target_roles(){
        $args = $this->input->post();
        $this->form_validation->set_rules('name','目标人','required');
        $this->form_validation->set_rules('phone','手机号','required');
        $this->form_validation->set_rules('email','邮箱','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Alarm_service->add_target_roles($args);
        if($res === false){
            returnJson('402',lang('operation_failed'));
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }


    /**
     * Notes: 删除监控账户
     * User: 张哲
     * Date: 2019/3/19
     * Time: 21:11
     */
    public function delete_target_roles(){
        $args = $this->input->post();
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Alarm_service->delete_target_roles($args['id']);
        returnJson('200',lang('operation_successful'),$res);
    }


    /**
     * Notes: 监控账户列表
     * User: 张哲
     * Date: 2019/3/19
     * Time: 21:20
     */
    public function target_people_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //姓名
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Alarm_service->target_list($offset,$limit,$name);
        $count = $this->Alarm_service->target_count($name);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * 1.预警参数配置增加修改
     * 2.大额充值列表
     * 3.大额充值可更改是否已处理状态
     * 4.提币hash监控列表
     * 5.提币hash可更改是否已处理状态
     */

    /**
     * Notes: 大额充值列表
     * User: 张哲
     * Date: 2019-04-24
     * Time: 18:19
     */
    public function large_amount_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; 


        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Alarm_service->large_amount_list($offset, $limit, $start_time, $end_time,$user_id);
        $count = $this->Alarm_service->large_amount_list_count($start_time, $end_time,$user_id);
        $data['total'] = $count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($count / $limit);
        returnJson('200', lang('operation_successful'), $data);
    }

    /**
     * Notes: 大额充值-修改处理状态
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:48
     */
    public function large_amount_deal()
    {
        $this->form_validation->set_rules('id','ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args = $this->input->post();
        $res = $this->Alarm_service->large_amount_deal($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    /**
     * Notes: 提币钱包状态监控
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:36
     */
    public function withdraws_wallet_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; //广告编号


        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Alarm_service->withdraws_wallet_list($offset, $limit, $start_time, $end_time,$user_id);
        $count = $this->Alarm_service->withdraws_wallet_list_count($start_time, $end_time,$user_id);
        $data['total'] = $count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($count / $limit);
        returnJson('200', lang('operation_successful'), $data);
    }

    /**
     * Notes: 提币钱包状态监控-修改处理状态
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:54
     */
    public function withdraws_wallet_deal()
    {
        $this->form_validation->set_rules('id','ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Alarm_service->withdraws_wallet_deal($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:56
     */
    public function large_amount_par()
    {
        $this->form_validation->set_rules('status', '状态', 'required');
        $this->form_validation->set_rules('value', '业务值', 'required');
        if ($this->form_validation->run() == FALSE) {
            returnJson('402', lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Alarm_service->large_amount_par($args);
        if ($res === false) {
            returnJson('402', lang('operation_failed'));
        } else {
            returnJson('200', lang('operation_successful'));
        }
    }

    /**
     * Notes:
     * User: 张哲
     * Date: 2019-04-25
     * Time: 09:59
     */
    public function withdraws_wallet_par()
    {
        $this->form_validation->set_rules('value', '业务值', 'required');
        if ($this->form_validation->run() == FALSE) {
            returnJson('402', lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Alarm_service->withdraws_wallet_par($args);
        if ($res === false) {
            returnJson('402', lang('operation_failed'));
        } else {
            returnJson('200', lang('operation_successful'));
        }
    }

    /**
     * Notes: 获取参数
     * User: 张哲
     * Date: 2019-04-29
     * Time: 10:16
     */
    public function get_new_par(){
//        $this->form_validation->set_rules('status', '类型', 'required');
//        if ($this->form_validation->run() == FALSE) {
//            returnJson('402', lang('missing_parameters'));
//        }
        $args = $this->input->post();
        $res = $this->Alarm_service->get_new_par($args);
        returnJson('200', lang('operation_successful'), $res);
    }

}
   