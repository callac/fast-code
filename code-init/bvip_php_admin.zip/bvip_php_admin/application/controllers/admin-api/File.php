<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class File extends Base_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('User_service');
    }

    public function upload(){
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header("Access-Control-Allow-Headers: Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
        $oss = new \App\Helpers\oss_helper();
        // var_dump($_FILES);die;
        $is_file = $_FILES;
        if(!$is_file){
            returnJson('402','请上传文件');
        }
        $file = $is_file['file'];
        // var_dump($file);
        /*if(count($file) == count($file,1)){
            $file = array($file);
        }*/
        $name = $file['name'];
        $tmp_name = $file['tmp_name'];
        $type = $file['type'];
        $url = array();

        // var_dump($name[$i]);
        // var_dump($tmp_name[$i]);
        // var_dump($type[$i]);die;

        for ($i=0;$i<count($name);$i++){
            $url['url'][] = $oss->upload($name[$i],$tmp_name[$i],$type[$i],true);
        }
        returnJson('200',lang('operation_successful'),$url);
    }

    public function signe_upload(){
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header("Access-Control-Allow-Headers: Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
        $oss = new \App\Helpers\oss_helper();
        $is_file = $_FILES;
        if(!$is_file['file']){
            returnJson('402','请上传文件');
        }
        $file = $is_file['file'];
        // var_dump($file);die;
        $name = $file['name'];
        $tmp_name = $file['tmp_name'];
        $type = $file['type'];
        $url = array();
        for ($i=0;$i<count($name);$i++){
            $str = $oss->signe_upload($name[$i],$tmp_name[$i],$type[$i],true);
            $str1 = substr($str,0,strpos($str, '?'));
            $url['url'][] = trim(strrchr($str1, '/'),'/');
        }
        returnJson('200',lang('operation_successful'),$url);
    }


    public function upload_vedio(){
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header("Access-Control-Allow-Headers: Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
        if (empty($_FILES['file'])){
            returnJson('403','获取文件失败');
        }
        $file = $_FILES['file'];
        $name = $file['name'];
        $tmp_name = $file['tmp_name'];
        $type = $file['type'];
        $oss = new \App\Helpers\oss_helper();
        
        for ($i=0;$i<count($name);$i++){
            $url['url'] = $oss->aaa1($name[$i],$tmp_name[$i])['info']['url'];
        }

        returnJson('200',lang('operation_successful'),$url);
    }



}
