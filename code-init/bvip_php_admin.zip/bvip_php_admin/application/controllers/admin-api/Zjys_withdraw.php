<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 /**
     * 资金管理-充值
     * @Author   张哲
     * @DateTime 2018-03-27
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     */

class Zjys_withdraw extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_withdraw_service');
    }


   /**
    * 充值新的写法加搜索
    * @Author   张哲
    * @DateTime 2018-04-18
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type] [description]
    */
   public function withdraw_list(){
        // var_dump($this->config->item('VIABTC_API_URL'));die;
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $status = isset($args['status']) ? $args['status'] : ''; //来源
        $asset = isset($args['asset']) ? $args['asset'] : null; //资产码
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $uid = isset($args['uid']) ? $args['uid'] : ''; //结束时间
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $wallet_status = !empty($args['wallet_status']) ? $args['wallet_status'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_withdraw_service->withdraw_list($offset,$limit,$name,$start_time,$end_time,$asset,$status,$site_id,$uid,$wallet_status);
        $count = $this->Zjys_withdraw_service->withdraw_list_count($name,$start_time,$end_time,$asset,$status,$site_id,$uid,$wallet_status);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    public function withdraw_list_printexcel(){
        // var_dump($this->config->item('VIABTC_API_URL'));die;
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 100; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $status = isset($args['status']) ? $args['status'] : ''; //来源
        $asset = isset($args['asset']) ? $args['asset'] : null; //资产码
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $uid = isset($args['uid']) ? $args['uid'] : ''; //结束时间
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $wallet_status = !empty($args['wallet_status']) ? $args['wallet_status'] : '';

        $offset = ($page - 1) * $limit;


        $list = $this->Zjys_withdraw_service->withdraw_list(0,'',$name,$start_time,$end_time,$asset,$status,$site_id,$uid,$wallet_status);
        // var_dump($list);die;
        // $count = $this->Zjys_withdraw_service->withdraw_list_count($name,$start_time,$end_time,$asset,$status,$site_id,$uid);
        if(empty($list))
        {
          $data['url'] = false;
          returnJson('200',lang('operation_successful'),$data);
        }

        $arr = array();

        foreach ($list as $key => $val){
          $arr[$key]['user_id'] = $val['user_id'];
          $arr[$key]['email'] = $val['email'];
          $arr[$key]['phone'] = $val['phone'];
          $arr[$key]['name'] = $val['name'];
          $arr[$key]['asset'] = $val['asset'];
          $arr[$key]['amount'] = $val['amount'];
          $arr[$key]['fee'] = $val['fee'];
          $arr[$key]['real_amount'] = $val['real_amount'];
          // $arr[$key]['status'] = $val['status'];

          if($val['status'] == 0){
             $val['status']='已提交';
          }
          if($val['status'] == 1){
              $val['status']='审核中';
          }
            if($val['status'] == 2){
             $val['status']='处理中';
          }
          if($val['status'] == 3){
              $val['status']='成功';
          }
          if($val['status'] == 4){
             $val['status']='失败';
          } 
          if($val['status'] == 5){
             $val['status']='取消';
          }
          $arr[$key]['status'] = $val['status'];
          // $arr[$key]['status'] = $val['status'];
          $arr[$key]['wallet_txid'] = $val['wallet_txid'];
          $arr[$key]['address'] = $val['address'];
          $arr[$key]['updated_at'] = $val['updated_at'];
          $arr[$key]['created_at'] = $val['created_at'];
          $arr[$key]['process_time'] = $val['process_time'];
          $arr[$key]['arrive_time'] = $val['arrive_time'];
          $arr[$key]['tx_id'] = $val['tx_id'];
          $arr[$key]['request_no'] = $val['request_no'];
        }
        $list = $arr;
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        
        $csvpath = APPPATH.'cache/excel/withdraw_list'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '邮箱' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手机' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '姓名' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '资产类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '实际到账' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '状态' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '钱包名称' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '地址' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'Hash' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后处理时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '提交时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '系统处理时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '钱包到账时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '请求号' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['user_id'],              
                            $value['email'],              
                            $value['phone']."\t",
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['name'] ),
                            $value['asset'],
                            $value['amount'],              
                            $value['fee'],  
                            $value['real_amount'],  
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['status'] ), 
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['wallet_txid'] ),
                            $value['address'], 
                            $value['tx_id'], 
                            $value['updated_at'], 
                            $value['created_at'], 
                            $value['process_time'], 
                            $value['arrive_time'],
                            $value['request_no'],  
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }


    //用户提现地址
    public function withdraw_address_list()
    {
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        // $status = isset($args['status']) ? $args['status'] : ''; //来源
        $asset = isset($args['asset']) ? $args['asset'] : null; //资产码
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';

        $uid = isset($args['uid']) ? $args['uid'] : ''; 

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_withdraw_service->withdraw_address_list($offset,$limit,$name,$start_time,$end_time,$asset,$site_id,$uid);
        $count = $this->Zjys_withdraw_service->withdraw_address_list_count($name,$start_time,$end_time,$asset,$site_id,$uid);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 充值详情
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function recharge_details(){        
        $data =$this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }        
        $res = $this->Zjys_withdraw_service->recharge_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }


   /**
     * 初步审核详情
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function recharge_verify_details(){        
        $data =$this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }        
        $res = $this->Zjys_withdraw_service->recharge_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }



   /**
     * 再次审核详情
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function recharge_sure_verify_details(){        
        $data =$this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }        
        $res = $this->Zjys_withdraw_service->recharge_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }


   /**
     * 充值初次审核
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @return   status状态：1通过  3是审核失败
     * 需要参数：id，status
     */
   public function recharge_verify(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }    
        $result = $this->Zjys_withdraw_service->recharge_verify($id,$status);        
        returnJson('200',lang('operation_successful'),$result);
   }


   /**
     * 充值再次审核
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   status状态：2是审核通过  3是审核失败
     * 需要参数：id，status
     */
   public function recharge_sure_verify(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }    
        $result = $this->Zjys_withdraw_service->recharge_verify($id,$status);        
        returnJson('200',lang('operation_successful'),$result);
   }


    /**
     * 充值数据导出
     * @Author   张哲
     * @DateTime 2018-04-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function print_recharge_excel(){
        $args =$this->input->post();
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点id
        $start_time = isset($args['start_time']) ? intval($args['start_time']) : ''; //注册开始时间
        $end_time = isset($args['end_time']) ? intval($args['end_time']) : ''; //注册结束时间
        $status = isset($args['status']) ? $args['status'] : 'all'; //状态
        $list = $this->Zjys_withdraw_service->recharge_list(0,'',$name,$start_time,$end_time,$site_id,$status);
        // var_dump($list);die;
        if(empty($list))
        {
          $data['url'] = false;
          returnJson('200',lang('operation_successful'),$data);
        }

        $arr = array();

        foreach ($list as $key => $val){
          $arr[$key]['user_account'] = $val['user_account'];
          $arr[$key]['truename'] = $val['truename'];
          $arr[$key]['amount'] = $val['amount'];
          $arr[$key]['pay_time'] = $val['pay_time'];
          $arr[$key]['pay_way'] = $val['pay_way'];
          $arr[$key]['bank_num'] = $val['bank_num'];
          $arr[$key]['request_id'] = $val['request_id'];
          $arr[$key]['status_type'] = $val['status_type'];
          $arr[$key]['site_name'] = $val['site_name'];
        }
        $title = array('账号','姓名', '充值金额','提交时间', '充值方式', '卡号','流水号','当前状态','充值站点');
        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * 提现数据导出
     * @Author   张哲
     * @DateTime 2018-04-19
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function print_withdraw_excel(){
        $args =$this->input->post();
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点id
        $start_time = isset($args['start_time']) ? intval($args['start_time']) : ''; //注册开始时间
        $end_time = isset($args['end_time']) ? intval($args['end_time']) : ''; //注册结束时间
        $status = isset($args['status']) ? $args['status'] : 'all'; //状态
        $list = $this->Zjys_withdraw_service->withdraw_list(0,'',$name,$start_time,$end_time,$site_id,$status);
        if(empty($list))
        {
          $data['url'] = false;
          returnJson('200',lang('operation_successful'),$data);
        }
        $arr = array();
        foreach ($list as $key => $val){
          $arr[$key]['user_account'] = $val['user_account'];
          $arr[$key]['truename'] = $val['truename'];
          $arr[$key]['bank'] = $val['bank'];
          $arr[$key]['pay_time'] = $val['pay_time'];
          $arr[$key]['serial_number'] = $val['serial_number'];
          $arr[$key]['account'] = $val['account'];
          $arr[$key]['amount'] = $val['amount'];
          $arr[$key]['fee'] = $val['fee'];
          $arr[$key]['money'] = $val['money'];
          $arr[$key]['status_type'] = $val['status_type'];
          $arr[$key]['site_name'] = $val['site_name'];
        }
        $title = array('账号','姓名','收款人开户行','提现时间', '流水号', '收款人账号','提现金额','手续费','到账金额','状态','提现站点');
        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);

    }

   /**
     * 提现详情
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function withdraw_details(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        //$security_hash_type = 5;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Zjys_withdraw_service->withdraw_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }


   /**
     * 提现初次审核详情
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function withdraw_verify_details(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        //$security_hash_type = 5;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Zjys_withdraw_service->withdraw_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }


   /**
     * 提现再次审核详情
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   [type]       [description]
     * 需要参数：id
     */
   public function withdraw_sure_verify_details(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        //$security_hash_type = 5;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Zjys_withdraw_service->withdraw_details($id);        
        returnJson('200',lang('operation_successful'),$res);
   }

   /**
     * 提现初步审核
     * @Author   张哲
     * @DateTime 2018-03-28
     * @createby SublimeText3
     * @return   status状态：1是审核通过  3是审核失败
     * 需要参数：id，status
     */
   public function withdraw_verify(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['remark'];
        $result = $this->Zjys_withdraw_service->withdraw_verify($id,$status,$remark);
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
   }

   /**
     * 提现再次审核
     * @Author   张哲
     * @DateTime 2018-05-08
     * @createby SublimeText3
     * @return   status状态：3是审核通过  4是审核失败
     * 需要参数：id，status
     */
   public function withdraw_sure_verify(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }    
        $remark = $data['remark'];
        $result = $this->Zjys_withdraw_service->withdraw_sure_verify($id,$status,$remark); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
   }


    /**
     * Notes: 将提现审核成功的手动设置成失败
     * User: 张哲
     * Date: 2019/2/14
     * Time: 13:38
     */
    public function withdraw_failure(){
        $args =$this->input->post();
        $review = $this->Zjys_withdraw_service->withdraw_failure($args);
        
        if($review['code'] == 0){
            returnJson('200',lang('operation_successful'),$review);
        }else{
            returnJson('402', $review['details']);
        }
    }

    /**
    * 资金流水搜索
    * @Author   张哲
    * @DateTime 2018-04-18
    * @createby SublimeText3
    * @version  1.0
    * @return   [return]
    * @return   [type]       [description]
    */
   public function capital_list(){
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $status = isset($args['status']) ? $args['status'] : 'all'; //状态
        $start_time = isset($args['start_time']) ? strtotime($args['start_time']) : ''; //开始时间
        $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_withdraw_service->capital_list($offset,$limit,$name,$start_time,$end_time,$site_id,$status);
        $count = $this->Zjys_withdraw_service->capital_list_count($name,$start_time,$end_time,$site_id,$status);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //资金流水
    public function print_capital_list(){
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $status = isset($args['status']) ? $args['status'] : 'all'; //状态
        $start_time = isset($args['start_time']) ? strtotime($args['start_time']) : ''; //开始时间
        $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : ''; //结束时间
        
        $list= $this->Zjys_withdraw_service->capital_list(0,'',$name,$start_time,$end_time,$site_id,$status);
        if(empty($list))
        {
          $data['url'] = false;
          returnJson('200',lang('operation_successful'),$data);
        }
        $arr = array();
        foreach ($list as $key => $val){
          $arr[$key]['user_account'] = $val['user_account'];
          $arr[$key]['truename'] = $val['truename'];
          $arr[$key]['create_time'] = $val['create_time'];
          $arr[$key]['value'] = $val['value'];
          $arr[$key]['pay_type'] = $val['pay_type'];
          $arr[$key]['status_type'] = $val['status_type'];
          $arr[$key]['site_name'] = $val['site_name'];
        }
        $title = array('账号','姓名','交易时间','交易金额', '交易类型', '当前状态','站点名称');
        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 等待审核笔数 （ajax查询接口）
     * @return [type] [description]
     */
    public function waitcheckamount()
    {
        $result = $this->Zjys_withdraw_service->waitcheckamount();
        returnJson('200',lang('operation_successful'),$result);
    }
    



}
