<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 网站配置
 * @Author   张鹏飞
 * @DateTime 2018-4-13
 * @createby SublimeText3
 * @version  1.0
 * @return   [return]
 */

class Config extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Config_service');
    }
    //---------------------参数管理------------------------------
    public function parameter_config_list(){
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Config_service->get_list($offset,$limit,$site_id);
        $count = $this->Config_service->get_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    public function config_update(){
        $args = $this->input->post();
        $this->form_validation->set_rules('varname','变量名','required');
        $this->form_validation->set_rules('value','变量值','required' );
        $this->form_validation->set_rules('remark', '描述','required');
        $this->form_validation->set_rules('site_id','站点id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Config_service->config_update($args);
        if($res !== false)returnJson('200',lang('operation_successful'));
        returnJson('402','配置参数名已存在');
    }
    public function config_delete(){
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $this->Config_service->config_delete($id);
        returnJson('200',lang('operation_successful'));
    }

    //---------------------新闻咨询/发现------------------------------
    //网站配置--新闻咨询管理&产品公告管理--列表
    public function news()
    {
        //默认新闻资讯,type=3[产品公告],type=4[产业资讯]
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id =  !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $offset = ($page-1)*$limit;
        $type = !empty($_POST['type']) ? $_POST['type'] : null;
        $news_list = $this->Config_service->news_list($type,$offset,$limit,$site_id);
        $news_count = $this->Config_service->news_count($type,$site_id);
        $data['total'] = $news_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($news_count/$limit);
        $data['list'] = $news_list;
        returnJson('200',lang('operation_successful'),$data);
    }
    //网站配置--新闻资讯管理&产品公告管理--编辑
    public function newsUpdate()
    {
        $args = $_POST;
        $this->Config_service->newsUpdate($args);
        returnJson('200',lang('operation_successful'));
    }
    //网站配置--新闻资讯管理&产品公告管理--新增
    public function newsAdd()
    {
        $args = $_POST;
        $this->Config_service->newsAdd($args);
        returnJson('200',lang('operation_successful'));
    }
    //网站配置--新闻资讯管理&产品公告管理--删除
    public function newsDelete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Config_service->newsDelete($id);
        returnJson('200',lang('operation_successful'));
    }

    //--------------------新闻资讯分类-------------------------
    public function news_class(){
        $this->Config_service->news_class();
    }

    public function news_class_noauth(){
        $this->Config_service->news_class();
    }

    public function news_class_update(){
        $this->form_validation->set_rules('name', 'bdc名称', 'required');
        $this->form_validation->set_rules('display_order', '排序', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Config_service->news_class_update();
    }
    public function news_class_delete(){
        $this->form_validation->set_rules('id', 'id', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Config_service->news_class_delete();
    }

    //---------------------BDC中心管理----------------------------
    //BDC中心管理--编辑/新增
    public function bdc_update()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('bdc_name', 'bdc名称', 'required');
        $this->form_validation->set_rules('content', '内容', 'required');
        $this->form_validation->set_rules('site_id', '内容', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Config_service->bdc_update($args);
        returnJson('200',lang('operation_successful'));
    }
    //BDC中心管理--列表
    public function bdc_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id =  !empty($_POST['site_id']) ? $_POST['site_id'] : 2;
        $offset = ($page-1)*$limit;
        $bdc_list = $this->Config_service->bdc_list($offset,$limit,$site_id);
        $bdc_count = $this->Config_service->bdc_count($site_id);
        $data['total'] = $bdc_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($bdc_count/$limit);
        $data['list'] = $bdc_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //BDC中心管理--删除
    public function bdc_delete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Config_service->bdc_delete($id);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }

    //---------------------帮助中心管理----------------------------
    //帮助中心管理--编辑/新增
    public function help_update()
    {
        $args = $this->input->post();
        // $this->form_validation->set_rules('title', 'bdc名称', 'required');
        // $this->form_validation->set_rules('content', '内容', 'required');
        $this->form_validation->set_rules('help_class_id', '类型', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Config_service->help_update($args);
        returnJson('200',lang('operation_successful'));
    }
    //帮助中心管理--列表
    public function help_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $help_class_id = !empty($_POST['type']) ? $_POST['type'] : null;
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->help_list($offset,$limit,$site_id,$help_class_id);
        $help_count = $this->Config_service->help_count($site_id,$help_class_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //帮助中心管理--删除
    public function help_delete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Config_service->help_delete($id);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }


    //基本配置（关于我们/隐私政策/注册协议）
    //帮助中心管理--编辑/新增
    public function agreement_update()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('title', '标题', 'required');
        $this->form_validation->set_rules('content', '内容', 'required');
        $this->form_validation->set_rules('unique_id', '类型_id', 'required'); //about-us\privacy-policy\user-agreement
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Config_service->agreement_update($args);
        returnJson('200',lang('operation_successful'));
    }
    //列表
    public function agreement_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->agreement_list($offset,$limit,$site_id);
        $help_count = $this->Config_service->agreement_count($site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //删除
    public function agreement_delete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Config_service->agreement_delete($id);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }





    public function friendlink_update()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('image', '图标图片', 'required');
        $this->form_validation->set_rules('url', '链接地址', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Config_service->friendlink_update($args);
        returnJson('200',lang('operation_successful'));
    }

    //列表
    public function friendlink_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->friendlink_list($offset,$limit,$site_id);
        $help_count = $this->Config_service->friendlink_count($site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //删除
    public function friendlink_delete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Config_service->friendlink_delete($id);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }




    //基本配置类型
    public function help_class(){
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = isset($_POST['site_id']) ? $_POST['site_id'] : '';
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->help_class_list($offset,$limit,$site_id);
        $help_count = $this->Config_service->help_class_count(0,'',$site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    public function help_class_noauth(){
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 100;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = isset($_POST['site_id']) ? $_POST['site_id'] : '';
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->help_class_list($offset,$limit,$site_id);
        $help_count = $this->Config_service->help_class_count(0,'',$site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }


    public function help_class_add(){
        // echo 1111;die;
        $args = $this->input->post();
        // $this->form_validation->set_rules('name', '标题', 'required');
        // $this->form_validation->set_rules('site_id', '站点', 'required');
        // $this->form_validation->set_rules('display_order', '排序', 'required');
        // $this->form_validation->set_rules('unique_id', '类型_id', 'required'); //about-us\privacy-policy\user-agreement
        // if ($this->form_validation->run() == FALSE){
        //     returnJson('402',lang('missing_parameters'));
        // }
        // $this->Config_service->agreement_update($args);
        $this->Config_service->help_class_add($args);
        returnJson('200',lang('operation_successful'));
    }

    public function help_class_delete(){
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $time = time();
        $res = $this->Config_service->help_class_delete($id,$time);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));

    }



    //---------------------版本管理---------------------------------
    //版本管理--列表
    public function version_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id =  !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $offset = ($page-1)*$limit;
        $version_list = $this->Config_service->version_list($offset,$limit,$site_id);
        $version_count = $this->Config_service->version_count($site_id);
        $data['total'] = $version_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($version_count/$limit);
        $data['list'] = $version_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //版本管理--编辑
    public function version_update()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('device_id', '设备id', 'required');
        $this->form_validation->set_rules('version_number', '版本号', 'required');
        $this->form_validation->set_rules('download_url', '下载链接', 'required');
        $this->form_validation->set_rules('site_id', '站点id', 'required');
        if ($this->form_validation->run() == false){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Config_service->version_update($args);
        returnJson('200',lang('operation_successful'));
    }
    //版本管理--删除
    public function version_delete()
    {
        $id = isset($_POST['id']) ? $_POST['id'] : false;
        $res = $this->Config_service->version_delete($id);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }


    //---------------------友情链接列表和banner列表--------------------
    //友情链接列表和banner列表
    public function banner_friend_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $type = isset($_POST['type']) ? $_POST['type'] : null;
        $site_id =  !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $offset = ($page-1)*$limit;
        $banner_friend_list = $this->Config_service->banner_friend_list($type,$offset,$limit,$site_id);
        $banner_friend_count = $this->Config_service->banner_friend_count($type,$site_id);
        $data['total'] = $banner_friend_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($banner_friend_count/$limit);
        $data['list'] = $banner_friend_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //banner新增/更新
    public function banner_update()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('title', '标题', 'required');
        // $this->form_validation->set_rules('image', '图片地址', 'required');
        // $this->form_validation->set_rules('url', '链接地址', 'required');
        //$this->form_validation->set_rules('url_type', '链接的类型', 'required');
        $this->form_validation->set_rules('endpoint', '终端类型', 'required');
        $this->form_validation->set_rules('type', '显示类型', 'required');
        // $this->form_validation->set_rules('position', '所属位置', 'required');
        $this->form_validation->set_rules('display_order', '排序顺序，0表示不显示', 'required');
        if ($this->form_validation->run() == false){
            returnJson('402',lang('missing_parameters'));
        }
        $args['position'] = 'home';
        $res = $this->Config_service->banner_update($args);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }
    //友情链接--新增/更新
    public function friend_update()
    {
        $args = $this->input->post();

        $this->form_validation->set_rules('title', '标题', 'required');
        $this->form_validation->set_rules('url', '链接地址', 'required');
        if ($this->form_validation->run() == false){
            returnJson('402',lang('missing_parameters'));
        }
        $args['position'] = 'friend';
        $res = $this->Config_service->banner_update($args);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //友情链接和banner--删除
    public function banner_friend_delete()
    {
        $id = isset($_POST['id']) ? $_POST['id'] : false;
        $res = $this->Config_service->banner_friend_delete($id);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }

    //---------------------关于我们---------------------------------
    //关于我们--列表
    public function about_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id =  !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $offset = ($page-1)*$limit;
        $about_list = $this->Config_service->about_list($offset,$limit,$site_id);
        $about_count = $this->Config_service->about_count($site_id);
        $data['total'] = $about_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($about_count/$limit);
        $data['list'] = $about_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //关于我们--编辑
    public function about_update()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('banner_title', 'banner标题', 'required');
        $this->form_validation->set_rules('banner_content', 'banner内容', 'required');
        $this->form_validation->set_rules('banner_up_title', 'banner下标题', 'required');
        $this->form_validation->set_rules('banner_up_resume', 'banner下简述', 'required');
        $this->form_validation->set_rules('map_title', '宣传标题', 'required');
        $this->form_validation->set_rules('map_des', '宣传简述', 'required');
        $this->form_validation->set_rules('slogan', '标语', 'required');
        $this->form_validation->set_rules('slogn_content', '标语描述', 'required');
        $this->form_validation->set_rules('site_id', '站点', 'required');
        if ($this->form_validation->run() == false){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Config_service->about_update($args);
        if($res === false)returnJson('402','该站点已配置');
        returnJson('200',lang('operation_successful'));
    }
    //关于我们--删除
    public function about_delete()
    {
        $site_id = isset($_POST['site_id']) ? $_POST['site_id'] : false;
        $res = $this->Config_service->about_delete($site_id);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }


    //---------------------意见反馈---------------------------------
    //意见反馈
    public function question_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id =  !empty($_POST['site_id']) ? $_POST['site_id'] : null;
        $offset = ($page-1)*$limit;
        $about_list = $this->Config_service->question_list($offset,$limit,$site_id);
        $about_count = $this->Config_service->question_count($site_id);
        $data['total'] = $about_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($about_count/$limit);
        $data['list'] = $about_list;
        returnJson("200",lang('operation_successful'),$data);
    }


    public function app_update_add()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('app_endpoint', '终端类型', 'required');
        $this->form_validation->set_rules('apk_url', '链接', 'required');
        $this->form_validation->set_rules('site_id', '站点', 'required');
        $this->form_validation->set_rules('version_id', '版本id', 'required');
        $this->form_validation->set_rules('version_major', '主版本', 'required');
        $this->form_validation->set_rules('version_minor', '次版本', 'required');
        $this->form_validation->set_rules('type', '升级类型', 'required');
        // $this->form_validation->set_rules('status', '升级状态', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $result = $this->Config_service->app_update_add($args);
        if($result){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402','添加失败');
        }
    }
    //列表
    public function app_update_list()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($_POST['site_id']) ? $_POST['site_id'] : '';
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->app_update_list($offset,$limit,$site_id);
        $help_count = $this->Config_service->app_update_count($site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //删除
    public function app_update_delete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $time = date('Y-m-d H:i:s',time());
        $res = $this->Config_service->app_update_delete($id,$time);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }

    //导航栏配置列表
    public function labelconfiglist()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($_POST['site_id']) ? $_POST['site_id'] : '';
        $type = !empty($_POST['type']) ? $_POST['type'] : null;
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->labelconfiglist($offset,$limit,$type,$site_id);
        $help_count = $this->Config_service->labelconfigcount($type,$site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    public function labelconfigadd()
    {
        $args = $this->input->post();
        // $this->form_validation->set_rules('label_name', '终端类型', 'required');
        // $this->form_validation->set_rules('api_url', '接口链接', 'required');
        $this->form_validation->set_rules('site_id', '站点', 'required');
        $this->form_validation->set_rules('order', '版本id', 'required');
        $this->form_validation->set_rules('type', '类型', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $result = $this->Config_service->labelconfigadd($args);
        if($result){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402','添加失败');
        }
    }

    public function labelconfigdelete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $time = date('Y-m-d H:i:s',time());
        $res = $this->Config_service->labelconfigdelete($id,$time);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }


    //持仓活动配置列表
    public function activityholdinglist()
    {
        $args = $this->input->post();
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $status = !empty($_POST['status']) ? $_POST['status'] : null; //
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->activityholdinglist($offset,$limit,$status,$site_id);
        $help_count = $this->Config_service->activityholdingcount($status,$site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    public function activityholdingadd()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('asset', '资产类型', 'required'); //当前站点的币资产类型
        $this->form_validation->set_rules('hold_area', '活动范围参数', 'required');
        $this->form_validation->set_rules('award_get', '奖励发放时间', 'required');
        $this->form_validation->set_rules('snapshot', '资产快照时间', 'required');
        $this->form_validation->set_rules('site_id', '站点id', 'required');
        // $this->form_validation->set_rules('status', '', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $result = $this->Config_service->activityholdingadd($args);
        if($result){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402','添加失败');
        }
    }

    public function activityholdingdelete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $time = date('Y-m-d H:i:s',time());
        $res = $this->Config_service->activityholdingdelete($id,$time);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }

    //持仓活动奖励列表
    public function activityholdingawardlist()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $status = !empty($_POST['status']) ? $_POST['status'] : null; //
        $id = !empty($_POST['id']) ? $_POST['id'] : null;
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->activityholdingawardlist($offset,$limit,$id,$status);
        $help_count = $this->Config_service->activityholdingawardcount($id,$status);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    //抽奖活动奖励列表
    public function user_lottery_logs()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $level = !empty($_POST['level']) ? $_POST['level'] : null; //
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->user_lottery_logs($offset,$limit,$site_id,$level);
        $help_count = $this->Config_service->user_lottery_logscount($site_id,$level);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    //中秋活动用户夺宝记录
    public function user_treasure_logs()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $is_win = isset($_POST['is_win']) ? $_POST['is_win'] : null;
        $user_id = !empty($_POST['user_id']) ? $_POST['user_id'] : null;
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->user_treasure_logslist($offset,$limit,$site_id,$is_win,$user_id);
        $help_count = $this->Config_service->user_treasure_logscount($site_id,$is_win,$user_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    //中秋活动场次记录
    public function treasure_sessions()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $status = isset($_POST['status']) ? $_POST['status'] : null; //
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->treasure_sessionslist($offset,$limit,$site_id,$status);
        $help_count = $this->Config_service->treasure_sessionscount($site_id,$status);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }
    //app交易接口配置
    public function apptradelist()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $user_id = !empty($_POST['user_id']) ? $_POST['user_id'] : null;
        $api_key = !empty($_POST['api_key']) ? $_POST['api_key'] : null;
        $status = !empty($_POST['status']) ? $_POST['status'] : null;
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->apptradelist($offset,$limit,$site_id,$user_id,$status,$api_key);
        $help_count = $this->Config_service->apptradecount($site_id,$user_id,$status,$api_key);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    public function appTradestatus()
    {
        $this->form_validation->set_rules('id', '', 'required');
        $this->form_validation->set_rules('status', '', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        if($this->Config_service->appTradestatus($args)){
            returnJson("200",lang('operation_successful'));
        }else{
            returnJson("402",lang('operation_failed'));
        }
    }


    /**
     * Notes: API详情
     * User: 张哲
     * Date: 2019-07-20
     * Time: 14:12
     */
    public function appTradeDetails()
    {
        $this->form_validation->set_rules('api_id', '', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $api_id= !empty($args['api_id']) ? $args['api_id'] : '';

        $help_list = $this->Config_service->appTradeDetails($api_id);
        returnJson("200",lang('operation_successful'),$help_list);
    }


    /**
     * 给用户添加api配置，一个用户只有一个api配置
     */
    public function apptradeadd()
    {
        // var_dump($this->helper);die;
        $args = $this->input->post();
        $this->form_validation->set_rules('user_id', '用户ID', 'required');
        $this->form_validation->set_rules('remark', '备注', 'required');

        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $result = $this->Config_service->apptradeadd($args);
        if($result){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402','operation_failed');
        }
    }

    public function apptradedelete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $time = date('Y-m-d H:i:s',time());
        $res = $this->Config_service->apptrade_delete($id,$time);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }

    public function mailconfigadd()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('uid', 'uids', 'required');
        $this->form_validation->set_rules('tongji_type', '统计类型', 'required');

        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $result = $this->Config_service->mail_config_add($args);
        if($result){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402','operation_failed');
        }
    }

    public function mailconfiglist()
    {
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        // $user_id = !empty($_POST['user_id']) ? $_POST['user_id'] : null; //
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->mailconfiglist($offset,$limit,$site_id);
        $help_count = $this->Config_service->mailconfigcount($site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    public function mailconfigdelete()
    {
        $id = isset($_POST['id']) ? intval($_POST['id']) : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $time = date('Y-m-d H:i:s',time());
        $res = $this->Config_service->mailconfigdelete($id,$time);
        if(!$res){
            returnJson('402',lang('operation_failed'));
        }
        returnJson('200',lang('operation_successful'));
    }

    // public function statisticmailsentrecords()
    // {
    //     // print_r(privs());die;
    //     // $priv = privs();

    //     $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
    //     $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    //     $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
    //     $offset = ($page-1)*$limit;
    //     $help_list = $this->Config_service->statisticmailsentrecords($offset,$limit,$site_id);
    //     $help_count = $this->Config_service->statisticmailsentrecordscount($site_id);
    //     $data['total'] = $help_count;
    //     $data['pageSize'] = $limit;
    //     $data['curPage'] = $page;
    //     $data['totalPage'] = ceil($help_count/$limit);
    //     $data['list'] = $help_list;
    //     returnJson("200",lang('operation_successful'),$data);
    // }
    //
    public function statisticmailsentrecords(){
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;//条数限制
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page-1)*$limit;
        $help_list = $this->Config_service->csv_logs_list($offset,$limit,$site_id);
        $help_count = $this->Config_service->csv_logs_count($site_id);
        $data['total'] = $help_count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($help_count/$limit);
        $data['list'] = $help_list;
        returnJson("200",lang('operation_successful'),$data);
    }

    public function smsconfig_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->smsconfig_list($offset,$limit,$site_id);
        $count = $this->Config_service->smsconfig_list_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //添加短信通道
    public function smsconfig_add(){
        $this->form_validation->set_rules('site_id','站点','required');
        $this->form_validation->set_rules('account', '账号','required');
        $this->form_validation->set_rules('password','密码','required');
        // $this->form_validation->set_rules('dy_template_code', '大于的模版码','required');
        $this->form_validation->set_rules('sign_name','签名','required');
        $this->form_validation->set_rules('channel','通道','required');
        $this->form_validation->set_rules('internal','是否为国内','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->smsconfig_add($args);
        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //删除币种详细介绍
    public function smsconfig_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->smsconfig_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','删除失败');
    }

    public function smsconfig_used()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->smsconfig_used($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','删除失败');
    }



    public function emailconfig_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->emailconfig_list($offset,$limit,$site_id);
        $count = $this->Config_service->emailconfig_list_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //添加短信通道
    public function emailconfig_add(){
        $this->form_validation->set_rules('site_id','站点','required');
        $this->form_validation->set_rules('account', '账号','required');
        $this->form_validation->set_rules('password','密码','required');
        $this->form_validation->set_rules('channel','通道','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->emailconfig_add($args);
        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //删除币种详细介绍
    public function emailconfig_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->emailconfig_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','删除失败');
    }

    //启用当前配置信息
    public function emailconfig_used()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->emailconfig_used($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','删除失败');
    }




    public function inviteconfig_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->inviteconfig_list($offset,$limit,$site_id);
        $count = $this->Config_service->inviteconfig_list_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //添加短信通道
    public function inviteconfig_add(){
        $this->form_validation->set_rules('site_id','站点','required');
        $this->form_validation->set_rules('image', '账号','required');
        // $this->form_validation->set_rules('','密码','required');
        // $this->form_validation->set_rules('channel','通道','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->inviteconfig_add($args);
        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //删除币种详细介绍
    public function inviteconfig_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->inviteconfig_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','删除失败');
    }
    //启用当前配置信息
    public function inviteconfig_used()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->inviteconfig_used($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','操作失败');
    }

    //ip白名单列表
    public function ip_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $type = !empty($args['type']) ? $args['type'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->ip_list($offset,$limit,$site_id,$type);
        $count = $this->Config_service->ip_list_count($site_id,$type);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //ip白名单添加和编辑
    public function ip_add(){
        $this->form_validation->set_rules('ip', 'ip','required');
        $this->form_validation->set_rules('type', 'type','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->ip_add($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //ip白名单删除
    public function ip_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->ip_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','operation_failed');
    }


    //广告位列表
    public function advert_place_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->advert_place_list($offset,$limit,$site_id);
        $count = $this->Config_service->advert_place_list_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //广告位添加和编辑
    public function advert_place_add(){
        $this->form_validation->set_rules('title', 'title','required');
        $this->form_validation->set_rules('url', 'url','required');
        $this->form_validation->set_rules('img', 'img','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->advert_place_add($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //广告位删除
    public function advert_place_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->advert_place_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','operation_failed');
    }

    //广告位上下架
    public function advert_place_updown()
    {
        $this->form_validation->set_rules('id','id','required');
        $this->form_validation->set_rules('status','status','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        if($res = $this->Config_service->advert_place_updown($args)){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402',lang('operation_failed'));
        }
    }


    //新手指南列表
    public function fingerpost_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->fingerpost_list($offset,$limit,$site_id);
        $count = $this->Config_service->fingerpost_list_count($site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //新手指南添加和编辑
    public function fingerpost_add(){
        $this->form_validation->set_rules('title', 'title','required');
        $this->form_validation->set_rules('desc', 'desc','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->fingerpost_add($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //新手指南删除
    public function fingerpost_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->fingerpost_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','operation_failed');
    }

    //新手指南上下架
    public function fingerpost_updown()
    {
        $this->form_validation->set_rules('id','id','required');
        $this->form_validation->set_rules('status','status','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        if($res = $this->Config_service->fingerpost_updown($args)){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402',lang('operation_failed'));
        }
    }


    //资讯多语言内容
    public function news_content_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $news_id = !empty($args['news_id']) ? $args['news_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->news_content_list($offset,$limit,$news_id);
        $count = $this->Config_service->news_content_list_count($news_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //ip白名单添加和编辑
    public function news_content_add(){
        $this->form_validation->set_rules('news_id', 'news_id','required');
        $this->form_validation->set_rules('title', 'title','required');
        // $this->form_validation->set_rules('resume', 'resume','required');
        $this->form_validation->set_rules('content', 'content','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->news_content_add($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //ip白名单删除
    public function news_content_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->news_content_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if(!$res) returnJson('403','operation_failed');
    }
    /**
     * 帮助多语言内容配置
     * @return [type] [description]
     */
    public function help_content_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $help_id = !empty($args['help_id']) ? $args['help_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->help_content_list($offset,$limit,$help_id);
        $count = $this->Config_service->help_content_list_count($help_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }



    public function help_content_add(){
        $this->form_validation->set_rules('help_id', 'help_id','required');
        $this->form_validation->set_rules('title', 'title','required');
        $this->form_validation->set_rules('content', 'content','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->help_content_add($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }


    public function help_content_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->help_content_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','operation_failed');
    }

    //帮助分类的多语言配置
    public function help_class_content_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $help_class_id = !empty($args['help_class_id']) ? $args['help_class_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->help_class_content_list($offset,$limit,$help_class_id);
        $count = $this->Config_service->help_class_content_list_count($help_class_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function help_class_content_add(){
        $this->form_validation->set_rules('help_class_id', 'help_class_id','required');
        $this->form_validation->set_rules('name', 'title','required');
        // $this->form_validation->set_rules('lang', 'content','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Config_service->help_class_content_add($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }


    public function help_class_content_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->help_class_content_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','operation_failed');
    }


    public function admin_whiteip_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $admin_id = !empty($args['admin_id']) ? $args['admin_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->admin_whiteip_list($offset,$limit,$admin_id);
        $count = $this->Config_service->admin_whiteip_list_count($admin_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 后台增加管理员登录IP白名单
     * @return [type] [description]
     */
    public function admin_whiteip_add()
    {
        $this->form_validation->set_rules('admin_id','admin_id','required');
        $this->form_validation->set_rules('ip','ip','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->admin_whiteip_add($args);
        if($res === false){
            returnJson('402','operation_failed');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }

    public function admin_whiteip_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Config_service->admin_whiteip_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','operation_failed');
    }


    /**
     * Notes: 获取前台文件
     * User: 张哲
     * Date: 2019-08-10
     * Time: 10:34
     */
    public function addAppFile()
    {
        $args = $this->input->post();

        $device_id = !empty($args['device_id']) ? $args['device_id'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $version_number = !empty($args['version_number']) ? $args['version_number'] : '';
        if (empty($_FILES['file'])){
            returnJson('403','获取文件失败');
        }
        $file = $_FILES['file'];
        $name = $file['name'];
        $tmp_name = $file['tmp_name'];
        $type = $file['type'];
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->aaa1($name,$tmp_name);
        $app_data = array();
        $app_data['created_at'] = date('Y-m-d H:i:s',time());
        $app_data['device_id'] = $device_id;
        $app_data['version_number'] = $version_number;
        $app_data['download_url'] =  $data['url']['info']['url'];
        $app_data['site_id'] =  $site_id;
        $app_data['name'] = $name;
        $res = $this->db->insert('b_app_version_new',$app_data);
        if(!empty($res)){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402',lang('operation_failed'));
        }
    }

    /**
     * Notes: APP列表
     * User: 张哲
     * Date: 2019-08-13
     * Time: 14:07
     */
    public function appConfigList()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $type = !empty($args['type']) ? $args['type'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->appConfigList($offset,$limit,$type);
        $count = $this->Config_service->appConfigListCount($type);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    public function appDownloadDetails()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $id = !empty($args['$id']) ? $args['$id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Config_service->appDownloadDetails($offset,$limit,$id);
        $count = $this->Config_service->appDownloadDetailsCount($id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }



}
