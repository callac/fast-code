<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */
class Zjys_trade extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_trade_service');
        $this->load->service('Zjys_statistics_service');
        $this->load->service('Sys_grpc_service');
        $this->load->service('Cancel_market_record_service');
    }

    public function print_user_assets()
    {
        $args =$this->input->post();  
        $limit = !empty($args['limit']) ? intval($args['limit']) : 2000; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $start_time = !empty($args['start_time']) ? $args['start_time']: date('Y-m-d H:i:s',0);
        $end_time = !empty($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());
        $name = isset($args['name']) ? $args['name']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $phone = isset($args['phone']) ? $args['phone']: '';

        $this->load->service('Zjys_trade_service');
        $time = $_SERVER['REQUEST_TIME_FLOAT'];
        $object = $this->db->select("users.id,users.email,users.phone,users.site_id,user_identities.name")
        ->join('user_identities','user_identities.user_id=users.id','left')
        ->from('users');
        // $object = $this->db->where('user_identities.status',2); //用户只有实名成功知乎才能看其资产
        $object =$this->db->where('user_identities.deleted_at is null');
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();

        if(empty($list)) returnJson('402','无数据可导出');
        // var_dump($list);
        foreach ($list as &$val) {
            $totalassets = get_user_assets_by_curl($val['id'],$val['site_id']);
            //var_dump($totalassets);
            $val['total_available'] = $totalassets['available'];
            $val['total_trans'] = $totalassets['total_trans'];
            $val['total_freeze'] = $totalassets['freeze'];
            $val['other_freeze'] = $totalassets['other_freeze'];
            // $res = $this->Zjys_trade_service->get_info_per_asset($val['id'],$site_id);
            // var_dump($res);
            // $title_result = array();
             //var_dump($res);
            // foreach ($res as $key => $value) {
            //     // $val[$key] = $value['available'].'|'.$value['freeze'].'|'.$value['other_freeze'];
            //     $val[$key.'a'] = $value['available'];
            //     array_unshift($title_result,$key.'可用数量');
            //     $val[$key.'b'] = $value['freeze'];
            //     array_unshift($title_result,$key.'冻结数量');
            //     $val[$key.'c'] = $value['other_freeze'];
            //     array_unshift($title_result,$key.'其他冻结');
            //     // $title_result = array_push($title_result, (string)($key.'a'));
            // }
        }
        // var_dump($list);die;
        $title = array('用户id','邮箱', '手机','姓名', '账户可用（折合）', '总资金（折合）','交易冻结（折合）','其他冻结（折合）');
        // $title = array_merge($title_base,$title_result);
        
        $csvpath = APPPATH.'cache/excel/user_asset_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = $title;

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['id'],              
                            $value['email'],  
                            $value['phone'],  
                            $value['name'],   
                            $value['total_available'],   
                            $value['total_trans'],   
                            $value['total_freeze'],   
                            $value['other_freeze'],   
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data);die;
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(20,$data['url'],date('Y-m-d H:i:s',time())); //20:用户资产列表导出
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes:
     * User: 张哲
     * Date: 2019/1/17
     * Time: 16:47
     */
    public function print_user_assets_all()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 1000; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $start_time = !empty($args['start_time']) ? $args['start_time']: date('Y-m-d H:i:s',0);
        $end_time = !empty($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());
        $name = isset($args['name']) ? $args['name']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $phone = isset($args['phone']) ? $args['phone']: '';

        $this->load->service('Zjys_trade_service');
        $time = $_SERVER['REQUEST_TIME_FLOAT'];
        $object = $this->db->select("users.id,users.email,users.phone,users.site_id,user_identities.name")
            ->join('user_identities','user_identities.user_id=users.id','left')
            ->from('users');
        // $object = $this->db->where('user_identities.status',2); //用户只有实名成功知乎才能看其资产
        $object =$this->db->where('user_identities.deleted_at is null');
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();

        if(empty($list)) returnJson('402','无数据可导出');
         //var_dump($list);
        foreach ($list as &$val) {
            $totalassets = get_user_assets_by_curl_all($val['id'],$val['site_id']);
            //var_dump($totalassets);
            $val['total_available'] = $totalassets['available'];
            $val['total_trans'] = $totalassets['total_trans'];
            $val['total_freeze'] = $totalassets['freeze'];
            $val['other_freeze'] = $totalassets['other_freeze'];
            $res = $this->Zjys_trade_service->get_info_per_asset($val['id'],$site_id);
            $title_result = array();
//var_dump($res);

            foreach ($res as $key => $value) {
                 $val[$key] = $value['available'].'|'.$value['freeze'].'|'.$value['other_freeze'];
                $val[$key.'a'] = $value['available'];
                array_unshift($title_result,$key.'可用数量');
                $val[$key.'b'] = $value['freeze'];
                array_unshift($title_result,$key.'冻结数量');
                $val[$key.'c'] = $value['other_freeze'];
                array_unshift($title_result,$key.'其他冻结');
                // $title_result = array_push($title_result, (string)($key.'a'));
            }
        }
        // var_dump($list);die;
        $title_base = array('用户id','邮箱', '手机','姓名', '账户可用（折合）', '总资金（折合）','交易冻结（折合）','其他冻结（折合）');
        $title = array_merge($title_base,$title_result);

        $csvpath = APPPATH.'cache/excel/user_asset_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = $title;

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['id'],
                $value['email'],
                $value['phone'],
                $value['name'],
                $value['total_available'],
                $value['total_trans'],
                $value['total_freeze'],
                $value['other_freeze'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data);die;
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(20,$data['url'],date('Y-m-d H:i:s',time())); //20:用户资产列表导出
        returnJson('200',lang('operation_successful'),$data);
    }

    //调整用户资金记录列表
    public function user_correctassetitem()
    {
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词（后台用户名）
        $realname = isset($args['realname']) ? $args['realname'] : ''; //关键词（用户真实姓名）
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        // $type = isset($args['type']) ? $args['type'] : null; //手机验证码 OR 邮箱验证码
        // $use_type = isset($args['use_type']) ? $args['use_type'] : null; //用途
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $uid = isset($args['uid']) ? $args['uid'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_trade_service->user_correctassetitem($offset,$limit,$name,$realname,$start_time,$end_time,$site_id,$uid);
        $count = $this->Zjys_trade_service->user_correctassetitem_count($name,$realname,$start_time,$end_time,$site_id,$uid);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);    
    }

    public function user_correctassetitem_csv()
    {
        $args = $this->input->post(); 
        // $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        // $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词（后台用户名）
        $realname = isset($args['realname']) ? $args['realname'] : ''; //关键词（用户真实姓名）
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $uid = isset($args['uid']) ? $args['uid'] : ''; //结束时间
        // $offset = ($page - 1) * $limit;
        $list= $this->Zjys_trade_service->user_correctassetitem(0,'',$name,$realname,$start_time,$end_time,$site_id,$uid);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');  
        $csvpath = APPPATH.'cache/excel/user_correctlist_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '管理员' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户姓名' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['user_name'],              
                            $value['user_id'],  
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['name'] ),
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['type'] ),
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['extra'] ),
                            // $value['time'],   
                            $value['asset_code'],   
                            $value['amount'],   
                            $value['site_name'],   
                            $value['created_time'],   
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * curl获取获取每个用户的总资产（换算成）
     * @param integer  $user_id
     * @return array
     */
    public function user_totalassets()
    {
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词（手机号或者邮箱）
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        // $type = isset($args['type']) ? $args['type'] : null; //手机验证码 OR 邮箱验证码
        // $use_type = isset($args['use_type']) ? $args['use_type'] : null; //用途
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $uid = isset($args['uid']) ? $args['uid'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_trade_service->get_list($offset,$limit,$name,$start_time,$end_time,$site_id,$uid);
        $count = $this->Zjys_trade_service->get_count($name,$start_time,$end_time,$site_id,$uid);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);    
    }

    /**
     * Notes: 用户资产-不区分站点
     * User: 张哲
     * Date: 2019/1/17
     * Time: 15:40
     */
    public function user_totalassets_all()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词（手机号或者邮箱）
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        // $type = isset($args['type']) ? $args['type'] : null; //手机验证码 OR 邮箱验证码
        // $use_type = isset($args['use_type']) ? $args['use_type'] : null; //用途
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $uid = isset($args['uid']) ? $args['uid'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_trade_service->get_list($offset,$limit,$name,$start_time,$end_time,$site_id,$uid);
        $count = $this->Zjys_trade_service->get_count($name,$start_time,$end_time,$site_id,$uid);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //用户资产详情
    public function user_assetsdetail()
    {
        $args = $this->input->post(); 
        $id = isset($args['id']) ? intval($args['id']) : 1; 
        $detail = $this->Zjys_user_model->get_info($id); //获取用户所在站点
        $site_id = $detail['site_id'];
        $this->form_validation->set_rules('id','用户id','required');

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $data = $this->Zjys_trade_service->get_info_per_asset($id,$site_id);
        $i = 0;
        foreach ($data as $key => $value) { //组合拼接数组
            if($key == $this->config->item('C2C_ASSET')){
                $price_trans = 1;
            }else{
                $price_trans = get_market_last($key.'_'.$this->config->item('C2C_ASSET'));
            }
            $arr[$i]['available'] = $value['available'];
            $arr[$i]['freeze'] = $value['freeze'];
            // $arr[$i]['c2c_freeze'] = $value['c2c_freeze'];
            // $arr[$i]['withdraw_freeze'] = $value['withdraw_freeze'];
            // $arr[$i]['lock_freeze'] = $value['lock_freeze'];
            $arr[$i]['other_freeze'] = $value['other_freeze'];
            $arr[$i]['activity_freeze'] = $value['activity_freeze'];
            // $arr[$i]['total_trans'] = $price_trans*($value['available']+$value['freeze']+$value['other_freeze']);
            $a = bcadd($value['available'],$value['freeze'],12);
            $b = bcadd($value['activity_freeze']['activity_freeze'],$value['other_freeze'],12);
            $arr[$i]['total'] = bcadd($a,$b,12);
            $arr[$i]['asset'] = $key;
            $i++;
        }

        // foreach ($arr as $key => $value) {
        //     if($value['available']==0 && $value['freeze']==0 && $value['other_freeze']==0 && $value['activity_freeze']['activity_freeze']==0)
        //         unset($arr[$key]);
        // }
        // $arr = array_values($arr);
        array_multisort(array_column($arr,'asset'),SORT_ASC,$arr);
        returnJson('200',lang('operation_successful'),$arr);
    }

    /**
     * Notes: 用户资产详情-所有
     * User: 张哲
     * Date: 2019/1/17
     * Time: 16:30
     */
    public function user_assetsdetail_all()
    {
        $args = $this->input->post();
        $id = isset($args['id']) ? intval($args['id']) : 1;
        $detail = $this->Zjys_user_model->get_info($id); //获取用户所在站点
        $site_id = $detail['site_id'];
        $this->form_validation->set_rules('id','用户id','required'); //买入或卖出

        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $data = $this->Zjys_trade_service->get_info_per_asset_all($id,$site_id);
        $i = 0;
        foreach ($data as $key => $value) { //组合拼接数组
            if($key == $this->config->item('C2C_ASSET')){
                $price_trans = 1;
            }else{
                $price_trans = get_market_last($key.'_'.$this->config->item('C2C_ASSET'));
            }
            $arr[$i]['available'] = $value['available'];
            $arr[$i]['freeze'] = $value['freeze'];
            $arr[$i]['other_freeze'] = $value['other_freeze'];
            $arr[$i]['activity_freeze'] = $value['activity_freeze'];
            $a = bcadd($value['available'],$value['freeze'],12);
            $b = bcadd($value['activity_freeze']['activity_freeze'],$value['other_freeze'],12);
            $arr[$i]['total'] = bcadd($a,$b,12);
            $arr[$i]['asset'] = $key;
            // $arr[$i]['total_trans'] = $price_trans*($value['available']+$value['freeze']+$value['other_freeze']);
            $arr[$i]['asset'] = $key;
            $i++;
        }
        returnJson('200',lang('operation_successful'),$arr);
    }

    //用户委托记录（未完成的订单）
    public function user_entrustedrecords()
    {
        // echo 555;die;
        $args = $this->input->post(); 
        $this->form_validation->set_rules('page','页码','required'); 
        $this->form_validation->set_rules('symbol','交易市场','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = isset($args['symbol']) ? $args['symbol'] : 'ZG_CNZ'; //交易对
        // $type = isset($args['type']) ? $args['type'] : ''; //委托类型
        $user_id = isset($args['id']) ? $args['id'] : ''; //用户id(必穿)
        $offset = ($page - 1) * $limit;


        $data['list']= $this->Zjys_trade_service->get_entrustedrecords_list($offset,$limit,$symbol,$user_id);
        // var_dump($data['list']);die;
        // $count =count($data['list']);
        // $count = $this->Zjys_trade_service->get_entrustedrecords_count($symbol,$user_id);
        // $data['total']=$count;
        // $data['pageSize']=$limit;
        // $data['curPage']=$page;
        // $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);

    }
    //用户成交记录（已成交的记录）
    public function user_dealrecords()
    {
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 100; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = isset($args['symbol']) ? $args['symbol'] : 'ZG_CNZ'; //交易对
        $side = isset($args['side']) ? $args['side'] : 0; //成交类型
        $user_id = isset($args['id']) ? $args['id'] : ''; //用户id
        $start_time = isset($args['start_time']) ? strtotime($args['start_time']) : 0; //用户id
        $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : time(); //用户id

        $offset = ($page - 1) * $limit;

        $data['list']= $this->Zjys_trade_service->get_dealrecords_list($offset,$limit,$symbol,$start_time,$end_time,$user_id,$side);
        // $count = $this->Zjys_trade_service->get_dealrecords_count($symbol,$user_id,$side);
        // $count =count($data['list']);
        // $data['total']=$count;
        // $data['pageSize']=$limit;
        // $data['curPage']=$page;
        // $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    public function user_assetsflow()
    {
        $args = $this->input->post(); 

        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //交易对
        $type = isset($args['type']) ? $args['type'] : ''; //成交类型
        $user_id = isset($args['id']) ? $args['id'] : ''; //用户id
        $start_time = isset($args['start_time']) ? strtotime($args['start_time']) : 0; //用户id
        $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : time(); //用户id

        $offset = ($page - 1) * $limit;

        $data['list']= $this->Zjys_trade_service->user_assetsflow($offset,$limit,$asset,$start_time,$end_time,$user_id,$type);
        returnJson('200',lang('operation_successful'),$data);
    }

    // public function print_userassetflow
    //导出用户流水
    public function user_assetsflow_csv()
    {
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //交易对
        $type = isset($args['type']) ? $args['type'] : ''; //成交类型
        $user_id = isset($args['id']) ? $args['id'] : ''; //用户id
        $start_time = !empty($args['start_time']) ? strtotime($args['start_time']) : 0; //用户id
        $end_time = !empty($args['end_time']) ? strtotime($args['end_time']) : time(); //用户id

        $offset = ($page - 1) * $limit;
        $list = $this->Zjys_trade_service->print_userassetflow($asset,$start_time,$end_time,$user_id,$type);

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');

        $csvpath = APPPATH.'cache/excel/withdraw_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '币资产类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '余额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '业务名' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '改变金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['asset'],              
                            $value['balance'],  
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['business'] ),
                            $value['change'],   
                            $value['time'],   
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($res);die;
        returnJson('200',lang('operation_successful'),$data);
    }







    // public function testredis()
    // {
        //php原生redis操作
        // $redis = new Redis();
        // $redis->connect('127.0.0.1',6379);
        // $redis->select(15);
        // $aa = array('a'=>123);
        // $bb = json_encode($aa);
        // $redis->set('key10',$bb,30);//第三个参数是存续时间，单位是秒，如果不填则为永久
        // echo $redis->get('key10');

        // CI框架的redis库（貌似不支持选择redis数据库下标）
        // $this->load->driver('cache');
        // $this->cache->redis->save('key11','xx11');//这里注意，第三个参数是时间，在自定义redis库会说明
        // echo $this->cache->redis->get('key11');
        // var_dump($this->cache->redis->cache_info());
    // }

    //解冻指定ip
    public function unfreezeip()
    {
        $args = $this->input->post();
        $ip = isset($args['ip']) ? $args['ip'] : ''; //当前页
        $this->form_validation->set_rules('ip','用户id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $ip = str_replace(' ', '.', $ip);
        $params = '*|'.$ip.'*';
        $redis = new Redis();
        //读取redis.php文件内容
        require(APPPATH.'config/redis.php');
        $redis->connect($config['host'],$config['port']);
        $redis->select(15);
        $keylist = $redis->keys($params);
        if(is_array($keylist) && empty($keylist)) returnJson('402','无此ip');

        for($i=0;$i<count($keylist);$i++){
            $redis->delete($keylist[$i]);
        }
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 调整用户资金
     */
    public function updateusermoney()
    {
        $args = $this->input->post(); 
        $this->form_validation->set_rules('uid','用户id','required'); //买入或卖出
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        if($this->Zjys_trade_service->updateusermoney($args)===true){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402','更改资金失败');
        }
    }
    //批量更改资金
    public function batch_update_money()
    {
        $file = $_FILES['file'];
        $filename = $file['tmp_name'];
        $name = substr($file['name'],strpos($file['name'],'.')+1);
        if($name!=='csv') returnJson('402','文件格式错误');
        if (empty ($filename)) returnJson('402','csv文件缺失');
        $handle = fopen($filename, 'r');
        while ($data = fgetcsv($handle)) { //每次读取CSV里面的一行内容
            $list[] = $data;
        }
        if($list[0][0] === null) returnJson('402','没有数据');
        
        // var_dump($list);die;
        fclose($handle); //关闭指针
        foreach ($list as $key => $value) {
            $args['uid'] = $value[0];
            $args['asset'] = $value[1];
            $args['amount'] = $value[2];
            $encode = mb_detect_encoding($value[3], array("ASCII",'UTF-8',"GB2312","GBK",'BIG5')); 
            $args['extra'] = mb_convert_encoding($value[3], 'UTF-8',$encode);
            $result[$key] = $args;
        }
        foreach ($result as $key => $value) {
            $data = $this->Zjys_trade_service->updateusermoney($value);
            if($data!==true) returnJson('402','从此条数据'.$data['uid'].','.$data['asset'].','.$data['amount'].'起（包括此条），下方的数据均未调整成功！请检查此条数据合法性！');
            usleep(2000);        
        }
        returnJson('200',lang('operation_successful'));
    }

    //获取不同站点不同用户，币资产
    public function get_site_totalassets()
    {
        $args =$this->input->post(); 
        // $fp = fopen("application/cache/lock/get_site_totalassets.txt", "w+");
        // echo 333;die;
        // if(flock($fp,LOCK_EX))
        // {
        $this->load->service('Zjys_trade_service');
        $time = $_SERVER['REQUEST_TIME_FLOAT'];
        $data = $this->Zjys_trade_service->get_site_totalassets($args);
            // flock($fp,LOCK_UN);
        // }
        // fclose($fp);
        returnJson('200',lang('operation_successful'),$data);
    }


     //获取不同站点不同用户，币资产
    public function in_total()
    {
        $args =$this->input->post(); 
        $start_time = isset($args['start_time']) ? $args['start_time']: 0;
        $end_time = isset($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());
        $site_id= isset($args['site_id']) ?$args['site_id'] : 1; //模版配置
        $type= isset($args['type']) ?$args['type'] : 1; //模版配置
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;

        // $fp = fopen("application/cache/lock/get_site_totalassets.txt", "w+");
        // echo 333;die;
        // if(flock($fp,LOCK_EX))
        // {
            $this->load->service('Zjys_c2corder_service');
            $data['list'] = $this->Zjys_c2corder_service->get_in_total($start_time,$end_time,$offset,$limit,$type,$site_id);

            $count = count($this->Zjys_c2corder_service->get_in_total_count($start_time,$end_time,$type,$site_id));
            // flock($fp,LOCK_UN);
        // }
        // fclose($fp);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    //获取银行卡收入（应收和实际收入）、支出的（应支和实际支出）
    public function get_type_one()
    {
        $this->form_validation->set_rules('type','类型','required'); //买入或卖出
        $this->form_validation->set_rules('site_id','类型','required'); //
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $args =$this->input->post();
        $site_id= isset($args['site_id']) ?$args['site_id'] : 1; //模版配置
        $type= isset($args['type']) ?$args['type'] : 1; //模版配置
        $stime = isset($args['start_time']) ? $args['start_time']: 0;
        $etime = isset($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());

        $this->load->service('Zjys_c2corder_service');
        $data = $this->Zjys_c2corder_service->total($type,$site_id,$stime,$etime,$offset,$limit); //应收和实收
        $data1 = $this->Zjys_c2corder_service->total_reality($type,$site_id,$stime,$etime,$offset,$limit); //应收和实收
        
        // $data = $this->Zjys_c2corder_service->totalcount($type,$site_id,$stime,$etime,$offset,$limit);
        $count = count($data);

        $result = array('all'=>$data,'real'=>$data1);

        $result['total']=$count;
        $result['pageSize']=$limit;
        $result['curPage']=$page;
        $result['totalPage']=ceil($count/$limit);

        returnJson('200',lang('operation_successful'),$result);
    }
    //每张银行卡的买入卖出应收金额、理论支出
    public function get_totalamount_per_merchantbank()
    {
        $this->form_validation->set_rules('m_bank_id','类型','required'); //银行卡号
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
       
        $m_bank_id= isset($args['m_bank_id']) ?$args['m_bank_id'] : 1;
        $type= isset($args['type']) ?$args['type'] : 1; 
        $start_time = isset($args['start_time']) ? $args['start_time']: 0;
        $end_time = isset($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());

        $this->load->service('Zjys_c2corder_service');
        $data['list'] = $this->Zjys_c2corder_service->get_totalamount_per_merchantbank($m_bank_id,$type,$start_time,$end_time,$offset,$limit);
        $count = $this->Zjys_c2corder_service->get_totalamount_per_merchantbank_count($m_bank_id,$type,$start_time,$end_time,$offset,$limit);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //每张银行卡的买入卖出实际收入、实际支出
    public function get_totalamount_per_merchantbank_reality()
    {
        $this->form_validation->set_rules('m_bank_id','类型','required'); //银行卡号
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
       
        $m_bank_id= isset($args['m_bank_id']) ?$args['m_bank_id'] : 1;
        $type= isset($args['type']) ?$args['type'] : 1; 
        $start_time = isset($args['start_time']) ? $args['start_time']: 0;
        $end_time = isset($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());

        $this->load->service('Zjys_c2corder_service');
        $data['list'] = $this->Zjys_c2corder_service->get_totalamount_per_merchantbank_reality($m_bank_id,$type,$start_time,$end_time,$offset,$limit);
        $count = $this->Zjys_c2corder_service->get_totalamount_per_merchantbank_reality_count($m_bank_id,$type,$start_time,$end_time,$offset,$limit);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    //冻结查询(冻结类型)
    public function get_c2c_freeze()
    {
        $this->form_validation->set_rules('type','类型','required'); //1:c2c冻结 2:提现冻结
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        $type= isset($args['type']) ?$args['type'] : 1; //模版配置
        $data = $this->Zjys_trade_service->get_c2c_freeze($type);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function get_trade_freeze()
    {
        $this->form_validation->set_rules('site_id','类型','required'); //1:c2c冻结 2:提现冻结
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        $site_id= isset($args['site_id']) ?$args['site_id'] : '';
        $data = $this->Zjys_trade_service->get_trade_freeze($site_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    //钱包请求日志
    public function get_wallet_logs()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $start_time = isset($args['start_time']) ? $args['start_time']: 0;
        $end_time = isset($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());

        $data['list'] = $this->Zjys_trade_service->get_wallet_logs($limit,$page,$offset,$start_time,$end_time);
        $count = $this->Zjys_trade_service->get_wallet_logs_count($limit,$page,$offset,$start_time,$end_time);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    //平台成交记录
    public function platform_deal_detail()
    {

        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;

        $uid = !empty($args['uid']) ? intval($args['uid']) : ''; 
      
        $start_time = !empty($args['start_time']) ? strtotime($args['start_time']): strtotime(date('Y-m-d',time()));
        $end_time = !empty($args['end_time']) ? strtotime($args['end_time']): time();
        $symbol = isset($args['symbol']) ? $args['symbol']: '';
        $day = isset($args['day']) ? $args['day']: '';
        if($day===''){
            $new = $this->Zjys_trade_service->platform_deal_detail($symbol,$uid,$start_time,$end_time,$offset,$limit);
            $data['list'] = array_slice($new, $offset,$limit);
            $count = count($new);
            $data['total']=$count;
            $data['pageSize']=$limit;
            $data['curPage']=$page;
            $data['totalPage']=ceil($count/$limit);
            returnJson('200',lang('operation_successful'),$data);
        }else{
            //提供每天历史数据
            $data['list'] = $this->Zjys_trade_service->platform_deal_detail_day($symbol,$uid,$day,$offset,$limit);
            $count = $this->Zjys_trade_service->platform_deal_detail_day_count($symbol,$uid,$day,$offset,$limit);
            $data['total']=$count;
            $data['pageSize']=$limit;
            $data['curPage']=$page;
            $data['totalPage']=ceil($count/$limit);
            returnJson('200',lang('operation_successful'),$data);
        }
        
    }
    //平台指定条件的成交记录导出
    public function platform_deal_detail_printcsv()
    {
        $this->form_validation->set_rules('symbol','类型','required'); 
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : '100'; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;

        $uid = !empty($args['uid']) ? intval($args['uid']) : ''; 
      
        $start_time = !empty($args['start_time']) ? strtotime($args['start_time']): strtotime(date('Y-m-d',time()));
        $end_time = !empty($args['end_time']) ? strtotime($args['end_time']): time();
        $symbol = isset($args['symbol']) ? $args['symbol']: '';
        $day = isset($args['day']) ? $args['day']: '';
        if($day===''){
            $list = $this->Zjys_trade_service->platform_deal_detail($symbol,$uid,$start_time,$end_time,$offset,$limit);
        }else{
            $list = $this->Zjys_trade_service->platform_deal_detail_day($symbol,$uid,$day,0,100000);
        }
        

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/deal_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '订单id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易市场(交易对)' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交价格' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '角色' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['user_id'],        
                            // $value['order_id'],        
                            $value['market'],        
                            $value['deal_stock'],        
                            $value['deal_money'],        
                            $value['price'],        
                            $value['deal_fee'],        
                            $value['t'],        
                            $value['side'],        
                            $value['time'],        
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);


        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($csvpath,'/application');
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data['url']);
        returnJson('200',lang('operation_successful'),$data);
    }

    //全平台委托记录(24小时)
    public function platform_order_detail()
    {
        $this->form_validation->set_rules('symbol','类型','required'); 
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();

        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;

        $uid = !empty($args['uid']) ? intval($args['uid']) : ''; 
      
        $start_time = isset($args['start_time']) ? strtotime($args['start_time']): time()-86400;
        $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : time();
        $symbol = isset($args['symbol']) ? $args['symbol'] : '';
        $side = isset($args['side']) ? $args['side'] : '';

        $data['list'] = $this->Zjys_trade_service->platform_order_detail($symbol,$uid,$start_time,$end_time,$offset,$limit,$side);

        $count = count($data['list']);
        // var_dump($count);die;
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //平台委托记录导出（24小时记录）
    public function platform_order_detail_printcsv()
    {
        $this->form_validation->set_rules('symbol','symbol','required'); 
        $this->form_validation->set_rules('side','side','required'); 
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();

        $limit = !empty($args['limit']) ? intval($args['limit']) : 1000; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;

        $uid = !empty($args['uid']) ? intval($args['uid']) : ''; 
      
        $start_time = isset($args['start_time']) ? strtotime($args['start_time']): time()-86400;
        $end_time = isset($args['end_time']) ? strtotime($args['end_time']) : time();
        $symbol = isset($args['symbol']) ? $args['symbol'] : '';
        $side = isset($args['side']) ? $args['side'] : '';
        //curl获取委托总数量
        $url       = $this->config->item('VIABTC_API_URL');
        $post_data = array(
            'id'       => 1,
            'method'   => 'order.book', //委托记录
            'params'   => array($symbol,(int)$side,(int)$offset,100),
        );
        $post_data = json_encode($post_data);
        $response = curl_common($url,$post_data,'post');
        // var_dump($response);die;
        $response = object_to_array(json_decode($response));
        
        if($response['error']===null && isset($response['result']['total']) && $response['result']['total']!=0){
            if($response['result']['total']<=100){
                $list = $response['result']['orders'];
            }else{
                $count = ceil((int)$response['result']['total']/100);
                for($i=0;$i<$count;$i++){
                    $offset = $i*100;
                    $data = array(
                        'id'       => 1,
                        'method'   => 'order.book', //委托记录
                        'params'   => array($symbol,(int)$side,(int)$offset,100),
                    );
                    $data = json_encode($data);
                    $response_data = curl_common($url,$data,'post');
                    $response_data = object_to_array(json_decode($response_data));
                    // var_dump($response_data);die;
                    if($i==0){
                        $list = array_merge(array(),$response_data['result']['orders']);
                    }else{
                        @$list = &array_merge($list,$response_data['result']['orders']);
                    }
                }
            }
            foreach ($list as &$value) {
                $value['create_time'] = get_microtime_format($value['ctime']);
                $value['mtime'] = get_microtime_format($value['mtime']);
                $value['user_id'] = $value['user'];
                if(!isset($value['source'])){
                    $value['source'] = '1';
                }
                if($value['type']==1){
                    $value['type'] = '市价';
                }else{
                    $value['type'] = '限价';
                }
                if($value['side']==1){
                    $value['side'] = 'ASK卖出';
                }else{
                    $value['side'] = 'BID买入';
                }
            }
        }else{
            $list = array();
        }
        
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/order_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', 'id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易市场(交易对)' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '委托数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '委托价格' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '委托手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交总金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'maker手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'taker手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '创建时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '来源' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '委托类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['id'],        
                            $value['user_id'],        
                            $value['market'],        
                            $value['amount'],        
                            $value['price'],        
                            $value['deal_fee'],        
                            $value['deal_stock'],        
                            $value['deal_money'],        
                            $value['maker_fee'],        
                            $value['taker_fee'],        
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['side'] ),        
                            $value['create_time'],        
                            $value['source'],        
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['type'] ),       
                            $value['mtime'],        
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($csvpath,'/application');
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data1['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data1);
    }


    //交易统计
    public function get_trade_statistic()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $start_time = isset($args['start_time']) ? $args['start_time']: '';
        $end_time = isset($args['end_time']) ? $args['end_time']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        // $end_time = isset($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());

        $data['list'] = $this->Zjys_trade_service->get_trade_statistic_total($limit,$offset,$start_time,$end_time,$site_id);
        $count = $this->Zjys_trade_service->get_trade_statistic_total_count($limit,$offset,$start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    //交易统计导出
    public function get_trade_statistic_printexcel()
    {
        $args =$this->input->post();
        $start_time = isset($args['start_time']) ? $args['start_time']: '';
        $end_time = isset($args['end_time']) ? $args['end_time']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $list = $this->Zjys_trade_service->get_trade_statistic_total('',0,$start_time,$end_time,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');        
        $csvpath = APPPATH.'cache/excel/trade_perday'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '市场' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易总量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易人次' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易笔数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'BID买入手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'ASK卖出手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '人均交易额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['symbols'],              
                            $value['trading_amount'],   
                            $value['people'],   
                            $value['trading_number'],  
                            $value['trading_amount'], 
                            $value['BID_fee'],   
                            $value['ASK_fee'],
                            $value['per_trading_amount'],   
                            $value['time_area'],   
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ), 
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);  

        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 撤销某个用户某个市场的订单（慎重撤单）
     * User: 张哲
     * Date: 2019/1/9
     * Time: 18:35
     */
    public function cancel_order_user_market(){
        //撤销单个用户 单个交易对 单个订单
        $args =$this->input->post();
        $this->form_validation->set_rules('id','id','required');
        $this->form_validation->set_rules('user','user_id','required');
        $this->form_validation->set_rules('market','market','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $user_id = $this->input->post('user');
        $market = $this->input->post('market');
        $url = $this->config->item('VIABTC_API_URL');

        $params = array(
            'id'       => 1,
            'method'   => 'order.cancel', //委托记录
            'params'   => array((int)$user_id,$market,(int)$id),
        );
        $params = json_encode($params);
        $response = curl_common($url,$params,'post');
        $res = object_to_array(json_decode($response));
        $order = $res['result'];

        if($res['error']===null){
            $ctime= date("Y-m-d H:i:s",$order['ctime']);
            $mtime= date("Y-m-d H:i:s",$order['mtime']);
            $this->Cancel_market_record_service->cancel_market($order['user'],$order['amount'],$order['market'],$ctime,$mtime,$order['source'],$order['price'],$order['type'],$order['deal_money'],$order['side'],$order['taker_fee'],$order['maker_fee'],$order['left'],$order['deal_stock'],$order['id'],1);
            returnJson(200,lang('operation_successful'));
        }else{
            $ctime= date("Y-m-d H:i:s",$order['ctime']);
            $mtime= date("Y-m-d H:i:s",$order['mtime']);
            $this->Cancel_market_record_service->cancel_market($order['user'],$order['amount'],$order['market'],$ctime,$mtime,$order['source'],$order['price'],$order['type'],$order['deal_money'],$order['side'],$order['taker_fee'],$order['maker_fee'],$order['left'],$order['deal_stock'],$order['id'],0);
            returnJson(402,lang('cancel_order_failed'),$res['error']['message']);
        }

//        if($res===true){
//
//            $this->Cancel_market_record_service->cancel_market($args,1);
//            returnJson(200,lang('operation_successful'));
//        }else{
//            $this->Cancel_market_record_service->cancel_market($args,0);
//            returnJson(402,lang('cancel_order_failed'),$res['error']['message']);
//        }
    }

    /**
     * Notes: 撤销订单列表 -在交易管理中
     * User: 张哲
     * Date: 2019/1/10
     * Time: 09:41
     */
    public function cancel_order_record_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = isset($args['symbol']) ? $args['symbol'] : ''; //币种
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $user = isset($args['user']) ? $args['user'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Cancel_market_record_service->cancel_order_record_list($start_time,$end_time,$offset,$limit,$symbol,$site_id,$user);
        $count = $this->Cancel_market_record_service->cancel_order_record_count($start_time,$end_time,$symbol,$site_id,$user);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 撤销用户订单列表-在用户资产中
     * User: 张哲
     * Date: 2019/1/11
     * Time: 14:08
     */
    public function cancel_order_record_list1(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $symbol = isset($args['symbol']) ? $args['symbol'] : ''; //币种
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $user = isset($args['user']) ? $args['user'] : ''; //用户id
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Cancel_market_record_service->cancel_order_record_list($start_time,$end_time,$offset,$limit,$symbol,$site_id,$user);
        $count = $this->Cancel_market_record_service->cancel_order_record_count($start_time,$end_time,$symbol,$site_id,$user);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 交易排名
     * @return [type] [description]
     */
    public function transaction_number()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('symbol','symbol','required');
        // $this->form_validation->set_rules('day','start_time','required');
        // $this->form_validation->set_rules('end_time','end_time','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        //时间精确到时
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $where = isset($args['where']) ? $args['where'] : ''; //排序字段
        $order = isset($args['order']) ? $args['order'] : ''; //排序字段
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; //
        $market = $args['symbol'];
        // $market = $args['symbol'];
        $limit = isset($args['limit']) ? intval($args['limit']) : 2; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $result = $this->Zjys_trade_service->transaction_number($offset,$limit,$start_time,$end_time,$market,$where,$order,$user_id);
        $data['list']= $result['list'];
        $data['total']=$result['count'];
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($result['count']/$limit);

        returnJson('200',lang('operation_successful'),$data);

    }
    /**
     * 指定用户的所有委托记录
     * @return [type] [description]
     */
    public function user_order_all()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('user_id','user_id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = isset($args['user_id']) ? $args['user_id'] : '';
        $symbol = isset($args['symbol']) ? $args['symbol'] : '';
        $limit = isset($args['limit']) ? intval($args['limit']) : 100; //
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $result = $this->Zjys_trade_service->user_order_all($user_id,$symbol,$offset,$limit);
        $data = $result;
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 指定用户的所有委托记录导出
     * @return [type] [description]
     */
    public function user_order_all_printcsv()
    {
        
    }

    //流水业务类型
    public function flow_business_type()
    {
        $result = $this->Zjys_trade_service->flow_business_type();
        returnJson('200',lang('operation_successful'),$result);
    }



}
