<?php
defined('BASEPATH') OR exit('No direct script access allowed');
set_time_limit(0);

class Export extends Base_Controller
{
    function __construct() {
        parent::__construct();
        $ci =& get_instance();
       // if($_SERVER['HTTP_HOST']!==$ci->config->item('CRON_HOST')) returnJson('403','Not found');
        $this->load->service('Zjys_tongji_service');
        $this->load->service('Zjys_trade_service');
        $this->load->service('Alarm_service');
        $this->load->service('Tool_service');
        $this->load->service('Rm_parameter_service');
        $this->load->service('Checkaccount_service');

        $this->load->model('Zjys_user_model');
        $this->load->service('Data_visualization_service');
    }




    /**
     * 用户资产导出
     */

    public function print_user_assets()
    {
        echo 1111;
        $args =$this->input->post();  
        $limit = !empty($args['limit']) ? intval($args['limit']) : 1000; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $start_time = !empty($args['start_time']) ? $args['start_time']: date('Y-m-d H:i:s',0);
        $end_time = !empty($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());
        $name = isset($args['name']) ? $args['name']: '';
        $site_id = isset($args['site_id']) ? $args['site_id']: '';
        $phone = isset($args['phone']) ? $args['phone']: '';

        $this->load->service('Zjys_trade_service');
        
        $time = $_SERVER['REQUEST_TIME_FLOAT'];
        $object = $this->db->select("users.id,users.email,users.phone,users.site_id,user_identities.name")
        ->join('user_identities','user_identities.user_id=users.id','left')
        ->from('users');
        // $object = $this->db->where('user_identities.status',2); //用户只有实名成功知乎才能看其资产
        $object =$this->db->where('user_identities.deleted_at is null');
        $object =$this->db->where('users.site_id =',146);

        
        
        if($site_id!='') $object =$this->db->where('users.site_id = ',$site_id);

        if(!empty($name)){
            if(WSTIsPhone($name)){
                $object =$this->db->where('users.phone = ',$name);
            }else{
                $object =$this->db->where('users.email = ',$name);
            }
        }

        if(!empty($uid)){
            $object =$this->db->where('users.id =',$uid);
        }

        if(!empty($start_time)){
            $object =$this->db->where('users.last_login >=',$start_time);
        }
        if(!empty($end_time)){
            $object =$this->db->where('users.last_login <=',$end_time);
        }

        $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
        if(empty($list)) returnJson('402','无数据可导出');
        // var_dump($list);
        foreach ($list as &$val) {
            $totalassets = get_user_assets_by_curl($val['id'],$val['site_id']);
            //var_dump($totalassets);
            $val['total_available'] = $totalassets['available'];
            $val['total_trans'] = $totalassets['total_trans'];
            $val['total_freeze'] = $totalassets['freeze'];
            $val['other_freeze'] = $totalassets['other_freeze'];
            // $res = $this->Zjys_trade_service->get_info_per_asset($val['id'],$site_id);
            // var_dump($res);
            // $title_result = array();
             //var_dump($res);
            // foreach ($res as $key => $value) {
            //     // $val[$key] = $value['available'].'|'.$value['freeze'].'|'.$value['other_freeze'];
            //     $val[$key.'a'] = $value['available'];
            //     array_unshift($title_result,$key.'可用数量');
            //     $val[$key.'b'] = $value['freeze'];
            //     array_unshift($title_result,$key.'冻结数量');
            //     $val[$key.'c'] = $value['other_freeze'];
            //     array_unshift($title_result,$key.'其他冻结');
            //     // $title_result = array_push($title_result, (string)($key.'a'));
            // }
        }
        // var_dump($list);die;
        $title = array('用户id','邮箱', '手机','姓名', '账户可用（折合）', '总资金（折合）','交易冻结（折合）','其他冻结（折合）');
        // $title = array_merge($title_base,$title_result);
        
        $csvpath = APPPATH.'cache/excel/user_asset_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = $title;

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['id'],              
                            $value['email'],  
                            $value['phone'],  
                            $value['name'],   
                            $value['total_available'],   
                            $value['total_trans'],   
                            $value['total_freeze'],   
                            $value['other_freeze'],   
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data);die;
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(20,$data['url'],date('Y-m-d H:i:s',time())); //20:用户资产列表导出
        returnJson('200',lang('operation_successful'),$data);
    }

}