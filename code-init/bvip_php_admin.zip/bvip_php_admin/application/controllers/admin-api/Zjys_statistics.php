<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 运营统计
 */
class Zjys_statistics extends Web_Controller
{
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_statistics_service');
    }

    /**
     * 获取列表
     * @param integer  $page     当前页，默认值为第1页
     * @param integer  $limit    条数限制，默认值为10
     * @return array
     */
    public function asset_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->asset_list($offset,$limit,$start_time,$end_time,$site_id);
        $count = $this->Zjys_statistics_service->asset_list_count($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }



    /**
     * 去重数据导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function asset_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $list = $this->Zjys_statistics_service->quchong($start_time,$end_time,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/quchong_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天注册人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计注册人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天实名人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计实名人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天被邀请注册人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计被邀请注册人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天法币交易人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计法币交易人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天币币交易人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计币币交易人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天充值人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计充值人数' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['register_amount'],
                $value['register_total'],
                $value['trunname_amount'],
                $value['trunname_total'],
                $value['invite_register_amount'],
                $value['invite_register_total'],
                $value['c2c_trade_amount'],
                $value['c2c_trade_total'],
                $value['coin_trade_amount'],
                $value['coin_trade_total'],
                $value['recharge_amount'],
                $value['recharge_total'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(8,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 注册数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function register_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])): '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->register_list($offset,$limit,$start_time,$end_time,$site_id);
        $count = $this->Zjys_statistics_service->register_list_count($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 注册数据导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function register_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $list = $this->Zjys_statistics_service->register_csv($start_time,$end_time,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/register_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天注册人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当日活跃' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天实名人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计实名人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天被邀请注册人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计被邀请注册人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '当天被邀请实名人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '累计被邀请实名人数' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['time'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['register_amount'],
                $value['active_amount'],
                $value['trunname_amount'],
                $value['trunname_total'],
                $value['invite_register_amount'],
                $value['invite_register_total'],
                $value['invite_trunname_amount'],
                $value['invite_trunname_total'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(1,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 充值数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function recharge_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->recharge_list($offset,$limit,$start_time,$end_time,$site_id,$asset);
        $count = $this->Zjys_statistics_service->recharge_list_count($start_time,$end_time,$site_id,$asset);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 充值数据导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function recharge_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $list = $this->Zjys_statistics_service->recharge_csv($start_time,$end_time,$site_id,$asset);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/recharge_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '24h充值数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '每日0点单价' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '充值人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '24h充值金额(元)' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '人均充值金额(元)' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['time'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['asset_code'],
                $value['recharge_total'],
                $value['unit_price'],
                $value['recharge_number'],
                $value['recharge_amount'],
                $value['per_recharge_amount'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(3,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }




    /**
     * 提现数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function withdraws_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $asset = isset($args['asset']) ? $args['asset'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->withdraws_list($offset,$limit,$start_time,$end_time,$site_id,$asset);
        $count = $this->Zjys_statistics_service->withdraws_list_count($start_time,$end_time,$site_id,$asset);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 提现数据导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function withdraws_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $list = $this->Zjys_statistics_service->withdraws_csv($start_time,$end_time,$site_id,$asset);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/withdraws_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '24h充值数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '每日0点单价' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '提币人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '24h提币金额(元)' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '人均提币金额(元)' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['time'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['symbols'],
                $value['withdraw_total'],
                $value['unit_price'],
                $value['withdraw_number'],
                $value['withdraw_amount'],
                $value['per_withdraw_amount'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(4,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 法币买入数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function c2cbuy_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->c2cbuy_list($offset,$limit,$start_time,$end_time,$site_id);
        $count = $this->Zjys_statistics_service->c2cbuy_list_count($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 法币买入数据导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function c2cbuy_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $list = $this->Zjys_statistics_service->c2cbuy_csv($start_time,$end_time,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/c2cbuy_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '下单总人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '下单总数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '完成单总数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易均价' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '完成率' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['time'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['orders_total_number'],
                $value['orders_total'],
                $value['orders_finish_total'],
                $value['trading_number'],
                $value['trading_amount'],
                $value['per_trading_amount'],
                $value['complete_rate'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(5,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * 法币卖出数据统计
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function c2csell_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->c2csell_list($offset,$limit,$start_time,$end_time,$site_id);
        $count = $this->Zjys_statistics_service->c2csell_list_count($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 法币卖出数据导出
     * @Author   张哲
     * @DateTime 2018-11-02
     * @createby SublimeText3
     * @version  1.0
     * @return   [return]
     * @return   [type]       [description]
     */
    public function c2csell_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $list = $this->Zjys_statistics_service->c2csell_csv($start_time,$end_time,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/c2cbuy_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '下单总人数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '下单总数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '完成单总数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易均价' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '完成率' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['time'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['orders_total_number'],
                $value['orders_total'],
                $value['orders_finish_total'],
                $value['trading_number'],
                $value['trading_amount'],
                $value['per_trading_amount'],
                $value['complete_rate'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(6,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }
    //币币交易数据列表
    public function cointrade_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $symbols = !empty($args['symbol']) ? $args['symbol'] : '';//交易对
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->cointrade_list($offset,$limit,$start_time,$end_time,$site_id,$symbols);
        $count = $this->Zjys_statistics_service->cointrade_list_count($start_time,$end_time,$site_id,$symbols);

        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //币币交易数据列表导出
    public function cointrade_list_csv()
    {
        $args =$this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $symbols = !empty($args['symbol']) ? $args['symbol'] : '';//交易对
        $list = $this->Zjys_statistics_service->cointrade_list(0,'',$start_time,$end_time,$site_id,$symbols);
        // var_dump($list);die;
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/c2cbuy_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '市场' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易总量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易人次' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易笔数' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易金额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'BID买入手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'ASK卖出手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '收盘价' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '人均交易额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['symbols'],
                $value['unit_price'],
                $value['people'],
                $value['trading_number'],
                $value['trading_amount'],
                $value['BID_fee'],
                $value['ASK_fee'],
                $value['price'],
                $value['per_trading_amount'],
                $value['time_area'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Zjys_statistics_service->csvlogs(6,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }

    //运营统计数据之币币交易
    public function trade_detail()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('market', '交易市场','required');
        $this->form_validation->set_rules('time', '时间','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $market = $args['market'];
        $time = $args['time'];
        $user_id = isset($args['user_id']) ? $args['user_id'] : '';

        $args = $this->input->post();
        $list = $this->Zjys_statistics_service->trade_detail($market,$time,$offset,$limit,$user_id);
    }


    //运营需求数据导出
    //用户成交记录
    public function deal_history()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('user_id', '用户ID必须','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $list = $this->Zjys_statistics_service->deal_history($args);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/deal_history'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '市场' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '方式（1:卖出2:买入）' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '价格' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交手续费（根据方式不同收取不同币种手续费）' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['time'],
                $value['user_id'],
                $value['market'],
                $value['side'],
                $value['price'],
                $value['amount'],
                $value['deal'],
                $value['fee'],
                $value['deal_fee'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }
    //指定条件的挂单记录
    public function order_history()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('user_id', '用户ID必须','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $list = $this->Zjys_statistics_service->order_history($args);
    }
    //指定用户，指定时间登录ip
    public function login_ip()
    {

    }

    /**
     * Notes: 持币列表
     * User: 张哲
     * Date: 2018/12/7
     * Time: 14:01
     */
    public function hold_coin_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $hold_coin_time = !empty($args['hold_coin_time']) ? $args['hold_coin_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $user_id = !empty($args['user_id']) ? $args['user_id'] : '';
        $offset = ($page - 1) * $limit;

        $data['list']= $this->Zjys_statistics_service->hold_coin_list($offset,$limit,$hold_coin_time,$end_time,$asset,$user_id);
        $count = $this->Zjys_statistics_service->hold_coin_list_count($hold_coin_time,$end_time,$asset,$user_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 0点交易对币价列表
     * User: 张哲
     * Date: 2019-05-07
     * Time: 11:19
     */
    public function symbols_price_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $symbols = !empty($args['symbols']) ? $args['symbols'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->symbols_price_list($offset,$limit,$start_time,$end_time,$symbols);
        $count = $this->Zjys_statistics_service->symbols_price_list_count($start_time,$end_time,$symbols);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes:  0点交易对币价列表-导出
     * User: 张哲
     * Date: 2019-05-07
     * Time: 13:57
     */
    public function symbols_price_csv()
    {
        $args =$this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $symbols = !empty($args['symbols']) ? $args['symbols'] : '';
        $list = $this->Zjys_statistics_service->symbols_price_csv($start_time,$end_time,$symbols);

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/symbols_price'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易对' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '价格' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                $value['symbols'],
                $value['price'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 持币导出
     * User: 张哲
     * Date: 2018/12/7
     * Time: 14:07
     */
    public function hold_coin_csv()
    {
        $args =$this->input->post();
        $hold_coin_time = !empty($args['hold_coin_time']) ? $args['hold_coin_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $user_id = !empty($args['user_id']) ? $args['user_id'] : '';
        $list = $this->Zjys_statistics_service->hold_coin_csv($hold_coin_time,$end_time,$asset,$user_id);

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/hold_coin'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                $value['asset'],
                $value['amount'],
                $value['created_at'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }




    //指定用户求出下级、下下级用户的交易额
    public function get_user_recommend_statistic1()
    {
        $args =$this->input->post();
        $args['trade_area'] = 'CNZ';
        $DB1 = $this->load->database('trade_history',true);
        for ($i=0; $i <100 ; $i++) {
            $sql = "select sum(deal) as trade_total,market,user_id from user_deal_history_".$i." where `market` like '%_".$args['trade_area']."' group by user_id";
            $object = object_to_array($DB1->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        // var_dump($new); //所有用户CNT的成交总额
        $sql2 = 'select recommend_user_id,user_id from user_recommends where status=1 and deleted_at is null';
        // $DB2 = $this->load->database('trade_history_onlyread',true);
        $DB2 = $this->load->database('default',true);
        $list = object_to_array($DB2->query($sql2)->result());

        // $object = $this->db->select("user_recommends.*")
        // ->from('user_recommends');
        // // $object = $this->db->where('user_recommends.status =',1)
        // $list = $object->get()->result_array();

        foreach ($new as &$value) {
            foreach ($list as $k => $v) {
                if($value['user_id']==$v['recommend_user_id']){
                    $value['top_user_id'] = (string)$v['user_id']; //上级id
                    continue;
                }
            }
        }

        foreach ($new as $key => $value) {
            if(!isset($value['top_user_id'])){
                $new[$key]['top_user_id'] = '0';
            }
        }
        // var_dump($new);
        foreach ($new as &$value) {
            foreach ($list as $k => $v) {
                if($value['top_user_id']==$v['recommend_user_id']){
                    $value['top_two_user_id'] = (string)$v['user_id']; //上级id
                    continue;
                }
            }
        }

        foreach ($new as $key => $value) {
            if(!isset($value['top_two_user_id'])){
                $new[$key]['top_two_user_id'] = '0';
            }
        }

        // var_dump($new);die;
        if(is_array($new) && empty($new)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/per_user_trade'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '上级id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '上上级' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', $args['trade_area'].'成交金额' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );
        fputcsv( $handle, $header );
        foreach($new as $value){
            $fields =   [
                $value['user_id'],
                $value['top_user_id'],
                $value['top_two_user_id'],
                $value['trade_total'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);


        // var_dump(123%100);die;
        // $file = $_FILES['file'];
        // $filename = $file['tmp_name'];
        // $name = substr($file['name'],strpos($file['name'],'.')+1);
        // if($name!=='csv') returnJson('402','文件格式错误');
        // if (empty ($filename)) returnJson('402','csv文件缺失');
        // $handle = fopen($filename, 'r');
        // while ($data = fgetcsv($handle)) { //每次读取CSV里面的一行内容
        //     $list[] = $data;
        // }
        // if($list[0][0] === null) returnJson('402','没有数据');
        // // var_dump($list);die;
        // fclose($handle); //关闭指针
        // foreach ($list as $key => $value) {
        //     $args['uid'] = $value[0];
        //     $result[$key] = $args;
        // }
        // var_dump($result);die;
        // $result = array(array('uid'=>9));




        foreach ($result as $key => $value) {
            //1、上级
            $res['top_uid'] = $this->Zjys_statistics_service->get_top_id($value['uid']);
            //2、上上级
            $res['top_two_uid'] = $this->Zjys_statistics_service->get_top_id($res['top_uid']);
            //3、获取下级用户id,统计交易金额
            $downids = $this->$this->Zjys_statistics_service->get_down_id($value['uid']);
            foreach ($downids as &$val) {
                // $sql = 'select deal_money'
            }

            $down_two_ids = $this->get_down_two_ids($downids);

            foreach ($down_two_ids as &$val) {

            }
            //4、获取下下级用户id,统计交易金额
            if($data!==true) returnJson('402','从此条数据'.$data['uid'].','.$data['asset'].','.$data['amount'].'起（包括此条），下方的数据均未调整成功！请检查此条数据合法性！');
            usleep(2000);
        }
    }
    public function get_user_recommend_statistic(){
        $result =$this->db->order_by('id desc')->get_where('csv_logs',array(
            'tongji_type' => ZJYS_DOWN_ACCOUNT_TYPE
        ))->row_array();
        $data['url'] = '';
        if($result){
            $data['url'] =$result['url'];
        }
        returnJson('200',lang('operation_successful'),$data);
    }

    public function get_down_two_ids($downids)
    {
        foreach ($downids as $key => $value) {
            $object = $this->Zjys_statistics_service->get_down_two_ids($value['user_id']);
            if($key==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        return $new;
    }

    public function platform_fee()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('site_id', 'site_id必须','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args['jyq'] = $this->config->item('trade_area');
        $data = $this->Zjys_statistics_service->platform_fee($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function asset_general()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('asset', 'asset','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        // var_dump($args);die;
        // $args['jyq'] = $this->config->item('trade_area');
        $data = $this->Zjys_statistics_service->asset_general($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function asset_general_form()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('asset', 'asset','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $data = $this->Zjys_statistics_service->asset_general_form($args);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 交易额
     * User: 张哲
     * Date: 2019-07-31
     * Time: 15:58
     */
    public function tradeAmount(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_statistics_service->tradeAmount($offset,$limit,$start_time,$end_time,$site_id);
        $count = $this->Zjys_statistics_service->tradeAmountCount($start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 交易区明细
     * User: 张哲
     * Date: 2019-07-31
     * Time: 15:56
     */
    public function tradeZoneDetails(){
        $args =$this->input->post();
        $time = !empty($args['time']) ? $args['time'] : '';
        $start_time = $time;
        $end_time = strtotime($start_time) + 86400 ;
        $end_time = date('Y-m-d',$end_time);
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $data= $this->Zjys_statistics_service->tradeZoneDetails($start_time,$end_time,$site_id);

        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 交易对明细
     * User: 张哲
     * Date: 2019-07-31
     * Time: 16:02
     */
    public function symbolDetails(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $time = !empty($args['time']) ? $args['time'] : '';
        $start_time = $time;
        $end_time = strtotime($start_time) + 86400 ;
        $end_time = date('Y-m-d',$end_time);
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $symbol = !empty($args['symbol']) ? $args['symbol'] : '';
        $offset = ($page - 1) * $limit;
        $data= $this->Zjys_statistics_service->symbolDetails($offset,$limit,$start_time,$end_time,$site_id,$symbol);
        $data['total']=$data['count'];
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($data['count']/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function newaddasset_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $symbol = !empty($args['asset']) ? $args['asset'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']  = $this->Zjys_statistics_service->newaddasset_list($offset,$limit,$start_time,$end_time,$symbol);
        $count = $this->Zjys_statistics_service->newaddasset_list_count($start_time,$end_time,$symbol);
        $data['total'] = $count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function newaddasset_list_total()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 5; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $start_time = !empty($args['start_time']) ? date('Y-m-d',strtotime($args['start_time'])) : '';
        $end_time = !empty($args['end_time']) ? date('Y-m-d',strtotime($args['end_time'])) : '';
        $symbol = !empty($args['asset']) ? $args['asset'] : '';
        $offset = ($page - 1) * $limit;
        $data = $this->Zjys_statistics_service->newaddasset_list_total($offset,$limit,$start_time,$end_time,$symbol);
        $data['curPage'] = $page;
        returnJson('200',lang('operation_successful'),$data);
    }

}
