<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-04-09
 * Time: 18:28
 */

class Baoquan extends Base_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->service('Baoquan_service');
    }

    /**
     * Notes: 数据列表
     * User: 张哲
     * Date: 2019-04-10
     * Time: 14:08
     */
    public function baoQuanList()
    {
        $this->form_validation->set_rules('hash','类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        $hash= isset($args['hash']) ?$args['hash'] : '';
        $page= isset($args['page']) ?$args['page'] : '0';
        $limit= isset($args['limit']) ?$args['limit'] : '10';
        $data = $this->Baoquan_service->baoQuanList($hash,$page,$limit);

        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 最新交易数据
     * User: 张哲
     * Date: 2019-04-10
     * Time: 14:08
     */
    public function TradeList()
    {
        $args =$this->input->post();
        $page= isset($args['page']) ?$args['page'] : '0';
        $limit= isset($args['limit']) ?$args['limit'] : '10';
        $data = $this->Baoquan_service->TradeList($page,$limit);

        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 区块列表
     * User: 张哲
     * Date: 2019-04-16
     * Time: 15:32
     */
    public function BlockList()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Baoquan_service->BlockList($offset, $limit);
        $count = $this->Baoquan_service->BlockCount();
        $data['total'] = $count;
        $data['pageSize'] = $limit;
        $data['curPage'] = $page;
        $data['totalPage'] = ceil($count / $limit);
        returnJson('200', lang('operation_successful'), $data);
    }


    /**
     * Notes: 下一个块和上一个块
     * User: 张哲
     * Date: 2019-04-16
     * Time: 15:53
     */
    public function NextbaoQuanList()
    {
        $this->form_validation->set_rules('block_id','类型','required');
        $this->form_validation->set_rules('status','类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        $block_id= isset($args['block_id']) ?$args['block_id'] : '';
        $status = isset($args['status']) ?$args['status'] : ''; //1 上  2 下
        $page= isset($args['page']) ?$args['page'] : '0';
        $limit= isset($args['limit']) ?$args['limit'] : '10';
        $data = $this->Baoquan_service->NextbaoQuanList($block_id,$page,$limit,$status);

        returnJson('200',lang('operation_successful'),$data);
    }
}