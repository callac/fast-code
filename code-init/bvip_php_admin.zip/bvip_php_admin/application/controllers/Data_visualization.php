<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019/1/9
 * Time: 12:42
 */

class Data_visualization extends Web_Controller{

    function __construct()
    {
        parent::__construct();
        $this->load->service('Data_visualization_service');

    }



    /**
     * Notes: 实时数据曲线图
     * User: 张哲
     * Date: 2019/1/9
     * Time: 13:04
     * @return mixed
     */
    public function real_draw(){
        $args = $this->input->post();
        //$this->form_validation->set_rules('site_id','站点','');
//        if($this->form_validation->run() == FALSE){
//            returnJson('402',lang('missing_parameters'));
//        }
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Data_visualization_service->real_draw($site_id);
        returnJson('200',lang('operation_successful'),$data);
    }



    /**
     * Notes: 实时数据
     * User: 张哲
     * Date: 2019/1/9
     * Time: 13:05
     * @return mixed
     */
    public function real_data(){
        $args = $this->input->post();
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $data = $this->Data_visualization_service->real_data($site_id);
        returnJson('200',lang('operation_successful'),$data);
    }



    /**
     * Notes: 用户总览
     * User: 张哲
     * Date: 2019/1/9
     * Time: 15:03
     */
    public  function user_data(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->user_data($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 用户总览曲线
     * User: 张哲
     * Date: 2019/1/10
     * Time: 16:39
     */
    public  function  user_data_draw(){
        $args = $this->input->post();
//        $this->form_validation->set_rules('time','时间','');
//        $this->form_validation->set_rules('type','类型','');
//        $this->form_validation->set_rules('site_id','站点','');
//        if($this->form_validation->run() == FALSE){
//            returnJson('402',lang('missing_parameters'));
//        }
        $data = $this->Data_visualization_service->user_data_draw($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 币币交易
     * User: 张哲
     * Date: 2019/1/11
     * Time: 15:31
     */
    public function  trade_data(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->trade_data($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 币币交易曲线
     * User: 张哲
     * Date: 2019/1/14
     * Time: 14:38
     */
    public function trade_data_draw(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->trade_data_draw($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 交易手续费
     * User: 张哲
     * Date: 2019/1/14
     * Time: 15:28
     */
    public function  trade_fee_data(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->trade_fee_data($args);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 交易手续费曲线图
     * User: 张哲
     * Date: 2019/1/14
     * Time: 16:02
     */
    public function  trade_fee_data_draw(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->trade_fee_data_draw($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 交易金额排名
     * User: 张哲
     * Date: 2019/1/14
     * Time: 16:25
     */
    public function  trade_money_rank(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Data_visualization_service->trade_money_rank($args,$offset,$limit);
        $count = $this->Data_visualization_service->trade_rank_count($args);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 交易订单排名
     * User: 张哲
     * Date: 2019/1/16
     * Time: 16:01
     */
    public function  trade_order_rank(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Data_visualization_service->trade_order_rank($args,$offset,$limit);
        $count = $this->Data_visualization_service->trade_rank_count($args);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 交易用户排名
     * User: 张哲
     * Date: 2019/1/16
     * Time: 16:18
     */
    public function  trade_user_rank(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Data_visualization_service->trade_user_rank($args,$offset,$limit);
        $count = $this->Data_visualization_service->trade_rank_count($args);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: c2c交易
     * User: 张哲
     * Date: 2019/1/15
     * Time: 09:25
     */
    public function  trade_c2c_data(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->trade_c2c_data($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: c2c交易曲线
     * User: 张哲
     * Date: 2019/1/15
     * Time: 10:53
     */
    public function  trade_c2c_data_draw(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->trade_c2c_data_draw($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 提币排名
     * User: 张哲
     * Date: 2019/1/15
     * Time: 11:47
     */
    public function  withdraws_coin_rank(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Data_visualization_service->withdraws_coin_rank($args,$offset,$limit);
        $count = $this->Data_visualization_service->withdraws_coin_rank_count($args);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 充币排名
     * User: 张哲
     * Date: 2019/1/15
     * Time: 16:04
     */
    public function  recharge_coin_rank(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Data_visualization_service->recharge_coin_rank($args,$offset,$limit);
        $count = $this->Data_visualization_service->recharge_coin_rank_count($args);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 币币详情数据
     * User: 张哲
     * Date: 2019/1/15
     * Time: 16:19
     */
    public function  coin_details_data(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->coin_details_data($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 币币详情交易费数据
     * User: 张哲
     * Date: 2019/1/15
     * Time: 18:56
     */
    public function  coin_details_fee_data(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->coin_details_fee_data($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes:币币详情-交易数据📈
     * User: 张哲
     * Date: 2019/1/16
     * Time: 09:59
     */
    public function  coin_details_trade_draw(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->coin_details_trade_draw($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 币币详情-手续费数据图表
     * User: 张哲
     * Date: 2019/1/16
     * Time: 10:00fee
     */
    public function  coin_details_fee_draw(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->coin_details_fee_draw($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /** 币币详情-充提币数据
     * Notes:
     * User: 张哲
     * Date: 2019/1/16
     * Time: 10:36
     */
    public function  coin_recharge_withdraws_data(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->coin_recharge_withdraws_data($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 币币详情-充提币图表
     * User: 张哲
     * Date: 2019/1/16
     * Time: 13:05
     */
    public function  coin_recharge_withdraws_draw(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->coin_recharge_withdraws_draw($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 根据币种给出交易对
     * User: 张哲
     * Date: 2019/1/17
     * Time: 10:40
     */
    public function  asset_symbols(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->asset_symbols($args);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 根据站点给出币种
     * User: 张哲
     * Date: 2019/1/18
     * Time: 11:48
     */
    public function  site_asset(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->site_asset($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 提币待审核（累计）；认证待审核（累计）；C2C买入待处理（累计）；C2C卖出待处理（累计
     * User: 张哲
     * Date: 2019/2/19
     * Time: 10:34
     */
    public function  wait_review(){
        $args = $this->input->post();
        $data = $this->Data_visualization_service->wait_review($args['site_id']);
        returnJson('200',lang('operation_successful'),$data);
    }

   /**
    * 1.当前申请提币：所有提币申请(未完成)-user_withdraws(status：0，1)
    * 2.C2C卖出：当前所有C2C卖出申请(未完成)-c2c_orders(type:2)
    * 3.当前资产总额（可用+冻结）按目前用户资产明细来-乘0点币价后相加
    * 4.入金：C2C买入-c2c_orders-历史累计已完成相加（type:1）、充值-user_recharge_logs-根据币种累加后乘0点币价，再次累加、活动(赠币、转账、活动系统)-acitivity_changes-累计活动按币种增加折算成CNT再次相加、后台资金调整-operation_money_logs-累计活动按币种增加折算成CNT再次相加、转入（OTC）-otc_transfer_histories
    * 5.出金：C2C卖出-c2c_orders、提币-user_withdraws、活动(赠币、转账、活动系统)-acitivity_changes、后台资金调整-operation_money_logs、转出（OTC）-otc_transfer_histories
    * 7.明细:业务类型（充值-user_recharge_logs、C2C买入-c2c_orders、活动-acitivity_changes、系统调整-operation_money_logs、转入-otc_transfer_histories、提币-user_withdraws、C2C卖出-c2c_orders、转出-otc_transfer_histories）
    *
    *
    * 1.获取0点各个交易对成交币价-调取market.last接口
    */


}

