<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Lock_position extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Lock_position_service');
    }
    //锁仓记录初次审核
    public function lockposition_check_first(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $check_status = isset($data['check_status']) ? $data['check_status'] : false;
        if(!$check_status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['check_remark'];//审核备注
        $result = $this->Lock_position_service->lockposition_check_first($id,$check_status,$remark); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }
    //锁仓记录再次审核
    public function lockposition_check_second(){
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $check_status = isset($data['check_status']) ? $data['check_status'] : false;
        if(!$check_status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['check_remark'];//审核备注
        $result = $this->Lock_position_service->lockposition_check_second($id,$check_status,$remark); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }

}
