<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Time_task extends Base_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    //获取不同站点不同用户，币资产
    // public function print_user_assets()
    // {
    //     $args =$this->input->post();  

        
    //     $limit = !empty($args['limit']) ? intval($args['limit']) : 10000; //偏移量
    //     $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
    //     $offset = ($page - 1) * $limit;
    //     $start_time = isset($args['start_time']) ? $args['start_time']: 0;
    //     $end_time = isset($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());
    //     $name = isset($args['name']) ? $args['name']: '';
    //     $phone = isset($args['phone']) ? $args['phone']: '';
        

    //     $redis = new Redis();
    //     $redis->connect('127.0.0.1',6379);
    //     $redis->select(15);

    //     if($redis->get('total_user_asset')!==false){
    //         $list = json_decode($redis->get('total_user_asset'));
    //         // echo 555;die;
    //         $list = object_to_array($list);
    //         // var_dump($list);
    //     }else{
    //         $args =$this->input->post();
    //         $site_id = 1;
    //         $fp = fopen("application/cache/lock/aaa.txt", "w+");
    //         if(flock($fp,LOCK_EX))
    //         {
    //             $this->load->service('Zjys_trade_service');
    //             $time = $_SERVER['REQUEST_TIME_FLOAT'];
    //             $object = $this->db->select("users.id,users.email,users.phone,user_identities.name")
    //         ->join('user_identities','user_identities.user_id=users.id','left')
    //         ->from('users');
    //         $object =$this->db->where('user_identities.status =',2); //实名过的
    //         if($site_id!=1) $object =$this->db->where('c2c_orders.site_id = ',$site_id);

    //         if(!empty($name)){
    //             if(WSTIsPhone($name)){
    //                 $object =$this->db->where('users.phone = ',$name);
    //             }else{
    //                 $object =$this->db->where('users.email = ',$name);
    //             }
    //         }

    //         if(!empty($uid)){
    //             $object =$this->db->where('users.id =',$uid);
    //         }

    //         if(!empty($start_time)){
    //             $object =$this->db->where('users.last_login >=',$start_time);
    //         }
    //         if(!empty($end_time)){
    //             $object =$this->db->where('users.last_login <=',$end_time);
    //         }
    //         $list = $object->limit($limit,$offset)->order_by('id','desc')->get()->result_array();
    //         foreach ($list as &$val) {
    //             $totalassets = get_user_assets_by_curl($val['id']);
    //             $val['total_available'] = $totalassets['available'];
    //             $val['total_trans'] = $totalassets['total_trans'];
    //             $val['total_freeze'] = $totalassets['freeze'];
    //             $val['other_freeze'] = $totalassets['other_freeze'];
    //             $res = $this->Zjys_trade_service->get_info_per_asset($val['id']);
    //             foreach ($res as $key => $value) {
    //                 // $val[$key] = $value['available'].'|'.$value['freeze'].'|'.$value['other_freeze'];
    //                 $val[$key.'a'] = $value['available'];
    //                 $val[$key.'b'] = $value['freeze'];
    //                 $val[$key.'c'] = $value['other_freeze'];
    //             }
    //         }
    //         $bb = json_encode($list);
    //         $redis->set('total_user_asset',$bb);//第三个参数是存续时间，单位是秒，如果不填则为永久
    //         flock($fp,LOCK_UN);
    //         }
    //     }

    //     $title = array('用户id','邮箱', '手机','姓名', '账户可用（折合）', '总资金（折合）','交易冻结（折合）','其他冻结（折合）','ZG可用数量','ZG冻结数量','ZG其他冻结数量','ETH可用数量','ETH冻结数量','ETH其他冻结数量','CNZ可用数量','CNZ冻结数量','CNZ其他冻结数量');
    //     $data['url'] = excel_helper::print_excel($title,$list,'asset'.$offset.'-'.$limit);
    //     $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
    //     // var_dump($data);die;
    //     returnJson('200',lang('operation_successful'),$data);
    //     fclose($fp);
    // }



    //获取不同站点不同用户，币资产
    public function get_site_totalassets()
    {
        $args =$this->input->post(); 
        $this->load->service('Zjys_trade_service');
        $time = $_SERVER['REQUEST_TIME_FLOAT'];
        $data = $this->Zjys_trade_service->get_site_totalassets($args);
        var_dump($data);die;
        returnJson('200',lang('operation_successful'),$data);
    }


    // //获取不同站点不同用户，币资产
    // public function in_total()
    // {
    //     $args =$this->input->post(); 
    //     $start_time = isset($args['start_time']) ? $args['start_time']: 0;
    //     $end_time = isset($args['end_time']) ? $args['end_time']: date('Y-m-d H:i:s',time());
    //     $site_id= isset($args['site_id']) ?$args['site_id'] : 1; //模版配置
    //     $type= isset($args['type']) ?$args['type'] : 1; //模版配置
    //     $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
    //     $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
    //     $offset = ($page - 1) * $limit;

    //     $fp = fopen("application/cache/lock/get_site_totalassets.txt", "w+");
    //     // echo 333;die;
    //     if(flock($fp,LOCK_EX))
    //     {
    //         $this->load->service('Zjys_c2corder_service');
    //         $data['list'] = $this->Zjys_c2corder_service->get_in_total($start_time,$end_time,$offset,$limit,$type,$site_id);
    //         $count = count($this->Zjys_c2corder_service->get_in_total_count($start_time,$end_time,$type,$site_id));
    //         flock($fp,LOCK_UN);
    //     }
    //     fclose($fp);
    //     $data['total']=$count;
    //     $data['pageSize']=$limit;
    //     $data['curPage']=$page;
    //     $data['totalPage']=ceil($count/$limit);
    //     returnJson('200',lang('operation_successful'),$data);
    // }

    // //获取买入，收入总和
    // public function get_type_one()
    // {
    //     $this->form_validation->set_rules('type','类型','required'); //买入或卖出
    //     $this->form_validation->set_rules('site_id','类型','required'); //
    //     if($this->form_validation->run() == FALSE){
    //         returnJson('402',lang('missing_parameters'));
    //     }
    //     $args =$this->input->post();
    //     $site_id= isset($args['site_id']) ?$args['site_id'] : 1; //模版配置
    //     $type= isset($args['type']) ?$args['type'] : 1; //模版配置
    //     $this->load->service('Zjys_c2corder_service');
    //     $data = $this->Zjys_c2corder_service->total($type,$site_id);
    //     returnJson('200',lang('operation_successful'),$data);
    //     // var_dump($total);die;
    // }




    






    //清空商品锁定信息  锁定三分钟/每分钟执行
    public function remove_product_lock(){
        $fp = fopen("application/cache/lock/remove_product_lock.txt", "w+");
        if(flock($fp,LOCK_EX))
        {
            $this->load->service('Product_lock_service');
            $this->Product_lock_service->remove_product_lock();
            flock($fp,LOCK_UN);
        }
        fclose($fp);
    }

    //测试定时任务。
    public function timetasktest(){
        // echo 11;die;
        //php原生redis操作
        $redis = new Redis();
        $redis->connect('127.0.0.1',6379);
        $redis->select(15);
        $aa = array('a'=>123);
        $bb = json_encode($aa);
        //$redis->set('key10',$bb,30);//第三个参数是存续时间，单位是秒，如果不填则为永久
        echo $redis->get('key10');
    }


    //未支付订单过期处理  等待三十分钟/每分钟执行
    public function order_overdue(){
        $fp = fopen("application/cache/lock/order_overdue.txt", "w+");
        if(flock($fp,LOCK_EX))
        {
            $this->load->service('Order_hash_service');
            $this->load->service('Order_miner_service');
            $this->load->service('User_account_service');
            $time = time()-60*30;//30分钟
            $this->Order_hash_service->order_overdue($time);
            $this->Order_miner_service->order_overdue($time);
            $this->User_account_service->order_overdue($time);
            flock($fp,LOCK_UN);
        }
        fclose($fp);
    }

    //清空账号异常登陆信息  每天凌晨执行
    public function clear_user_error()
    {
        $fp = fopen("application/cache/lock/clear_user_error.txt", "w+");
        if(flock($fp,LOCK_EX))
        {
            $this->load->model('User_login_failed_model');
            $this->User_login_failed_model->clear_user_error();
            flock($fp,LOCK_UN);
        }
        fclose($fp);

    }
    /**
     * 实名信息
     */
    public function getTruename()
    {
        $fp = fopen("application/cache/lock/true_name.txt", "w+");
        if(flock($fp,LOCK_EX))
        {
            $this->load->helper("shuxin");
            $shuxin = new shuxin_helper();
            $this->load->model('User_truename_model');
            $this->load->model('User_model');
            $res = $this->User_truename_model->get_untruename_list();
            $this->db->trans_start();

            foreach ($res as $key => $value) {
                $param = array();
                $param['real_name'] = $value['truename'];
                $param['id_number'] = $value['idcard'];
                $params = array(
                    'true_name',
                    $param
                );
                $data = $shuxin->turename_api_curl('true_name',$param);
        
                if($data){
                    switch ($data['ret_code']){
                        case 1:
                            $status = 1;
                            break;
                        case 2:
                            $status = 2;
                            break;
                        default:
                            $status = 3;
                    }

                    //更新状态
                    $this->User_truename_model->update_api_status($value['id'],$status,$data['ret_code'],$data['ret_desc'],time());
                    //更新用户表信息
                    $this->User_model->update_user_info($value['user_id'],$value['truename'],$value['idcard'],$status,1);
                }
            }
            $this->db->trans_complete();
        }
        fclose($fp);
    }

    /**
     * 银行卡信息
     */
    public function getBindCard()
    {
        $fp = fopen("application/cache/lock/bind_card.txt", "w+");
        if(flock($fp,LOCK_EX))
        {
            $this->load->helper("shuxin");
            $shuxin = new shuxin_helper();
            $this->load->model('User_bank_card_model');
            $res = $this->User_bank_card_model->get_unbankinfo_list();

            $this->db->trans_start();
            
            foreach ($res as $key => $value) {
                $param['personName'] = $value['acc_name'];
                $param['cellPhoneNumber'] = $value['mobile'];
                $param['identityNumber'] = $value['acc_id'];
                $param['cardNumber'] = $value['card_no'];

                $params = array(
                    'unionpay',
                    $param
                );
                $data = $shuxin->bankcard_api_curl('unionpay',$param);
                if($data){
                    $status = 0;
                    switch ($data['ret_code']){
                        case 1:
                            $status = 2;
                            break;
                        default:
                            $status = 3;
                    }
                    $this->User_bank_card_model->update_api_status($value['id'],$status,$data['ret_code'],$data['ret_desc'],time());
                }
            }
            $this->db->trans_complete();
        }
        fclose($fp);
    }
    
    // 测试保全
    public function baoquan()
    {
            $this->load->helper("baoquan_helper");
            $baoquan = new baoquan_helper();
            //从预生成表里查找数据
            $this->load->model('Security_bulid_hash_model');
            $this->load->model('User_model');
            $this->load->model('Order_hash_model');
            $this->load->model('Contract_hash_model');
            $this->load->model('Security_hash_model');
            $this->load->model('Order_miner_model');
            $this->load->model('Contract_miner_model');
            $this->load->model('Account_capital_racharge_model');
            $this->load->model('Account_capital_withdraw_model');
            $this->load->model('Account_btc_withdraw_model');
            
            $res = $this->Security_bulid_hash_model->get_unbuild_list();

            foreach ($res as $key => $value) {
                $user = $this->User_model->get_user_by_id($value['user_id']);

                if($value['security_status'] == 0){//云算力购买
                    //生成保全                   
                    $product = $this->Order_hash_model->get_data_by_id($value['order_hash_id']);
                    $user_info = array('name'=>$user['truename'],'phone_number'=>$user['mobile'],'idcard'=>$user['idcard']);
                    $contract_hash = $this->Contract_hash_model->get_contract_by_order_id($value['user_id'],$value['order_hash_id'],null);
                    if(!$product){
                        continue;
                    }
                    $product_name = !empty($product['product_name']) ? $product['product_name'] :'--';
                    $product_info = array(
                        'name'=>$product_name,
                        'amount'=>$product['hold_amount'],
                        'buy_time'=>date('Y-m-d H:i:s',$product['create_time']),
                        'pay_time'=>date('Y-m-d H:i:s',$product['pay_success_time']),
                        'pay_value'=>$product['pay_value'],
                        'contract_hash_id'=>@$contract_hash['contract_id'],
                        'order_number'=>$product['order_no'],
                        'start_time'=>date('Y-m-d H:i:s',$product['income_start_time']),
                        'end_time'=>date('Y-m-d H:i:s',$product['income_end_time']),
                    );
                    $arr = array('user'=>$user_info,'product'=>$product_info);
                    $baoquan_id = $baoquan->cloudHash_order_baoquan($arr);                   
                } elseif($value['security_status'] == 3){//购买矿机
                    //生成保全
                    $product = $this->Order_miner_model->get_order_miner_detail($value['user_id'],$value['order_hash_id']);                    
                    $user_info = array('name'=>$user['truename'],'phone_number'=>$user['mobile'],'idcard'=>$user['idcard']);
                    $contract_hash = $this->Contract_miner_model->get_contract_by_order_id($value['user_id'],$value['order_hash_id'],null);
                    if(!$product){
                        continue;
                    }
                    $product_info = array(
                        'product_name'=>$product['name'],
                        'amount'=>$product['buy_amount'],
                        'buy_time'=>date('Y-m-d H:i:s',$product['created_time']),
                        'pay_time'=>date('Y-m-d H:i:s',$product['pay_success_time']),
                        'pay_value'=>$product['pay_value'],
                        'contract_hash_id'=>@$contract_hash['contract_id'],
                        'order_no'=>$product['order_no'],  
                    );
                    $arr = array('user'=>$user_info,'product'=>$product_info);
                    $baoquan_id = $baoquan->hashrate_order_baoquan($arr);
                } elseif($value['security_status'] == 4){//充值
                    //生成保全
                    $user_info = array('name'=>$user['truename'],'phone_number'=>$user['mobile'],'idcard'=>$user['idcard']);                   
                    $product = $this->Account_capital_racharge_model->get_recharge_details($value['user_id'],$value['order_hash_id']);

                    if(!$product){
                        continue;
                    }
                    $product_info = array(                        
                        'amount'=>$product['amount'],                       
                        'pay_time'=>date('Y-m-d H:i:s',$product['pay_time']),
                        'success_time'=>date('Y-m-d H:i:s',$product['success_time']),
                        'request_id'=>$product['request_id'],
                    );
                    $arr = array('user'=>$user_info,'product'=>$product_info);
                    $baoquan_id = $baoquan->recharge_order_baoquan($arr);                   
                } elseif($value['security_status'] == 5){//提现
                    //生成保全                   
                    $product = $this->Account_capital_withdraw_model->get_withdraw_details($value['user_id'],$value['order_hash_id']);
                    $user_info = array('name'=>$user['truename'],'phone_number'=>$user['mobile'],'idcard'=>$user['idcard']);   

                    $product_info = array(                        
                        'amount'=>$product['amount'],  //提现金额
                        'fee'=>$product['fee'], //手续费
                        'pay_time'=>date('Y-m-d H:i:s',$product['pay_time']),//打款时间
                        'order_number'=>$product['id'],
                    );
                    $arr = array('user'=>$user_info,'product'=>$product_info);
                    $baoquan_id = $baoquan->withdrawMoney_order_baoquan($arr);                    
                } elseif($value['security_status'] == 6){//提币
                    //生成保全                   
                    $product = $this->Account_btc_withdraw_model->get_btc_withdraw_details($value['user_id'],$value['order_hash_id']);
                    $user_info = array('name'=>$user['truename'],'phone_number'=>$user['mobile'],'idcard'=>$user['idcard']);  

                    $product_info = array(                        
                        'amount'=>$product['amount'],                       
                        'fee'=>date('Y-m-d H:i:s',$product['fee']),
                        'apply_time'=>date('Y-m-d H:i:s',$product['apply_time']),
                        'pay_time'=>$product['pay_time'],
                        'btc_addr'=>$product['btc_addr'],
                        'order_no'=>$product['order_no'],
                    );
                    $arr = array('user'=>$user_info,'product'=>$product_info);
                    $baoquan_id = $baoquan->withdrawCoin_order_baoquan($arr);                    
                }
                //查看保全
                $baoquan_info = $baoquan->searchBaoquan($baoquan_id);
                if(!$baoquan_info){
                    break;
                }
                //保存保全
                $security = array(
                                'record_no'=>$baoquan_info['no'],
                                'order_hash_id'=>$value['order_hash_id'],
                                'security_data'=>json_encode($baoquan_info['factoids']),
                                'security_time'=>time(),
                                'success_time'=>time(),
                                'status'=>1,
                                'user_id'=>@$user['id'],
                                'mobile'=>@$user['mobile'],
                                'idcard'=>@$user['idcard'],
                                'model_no'=>$baoquan_info['template_id'],
                                'security_hash_type'=>$value['security_status'],
                            );
                //存入security_hash 表
                $this->Security_hash_model->add($security);

                //security_bulid_hash表状态改为已保全
                $res = $this->Security_bulid_hash_model->change_status($value['id'],1);
                
            }
            // $this->db->trans_complete();       
    }
        
    //每日快照
    public function getUserHashIncome()
    {
        //获取币种类型
        $this->load->model('Product_hash_type_model');
        $this->load->model('Order_hash_model');
        $this->load->model('User_hash_income_model');
        $this->load->model('User_hash_details_model');
        
        $product_hash_type = $this->Product_hash_type_model->get_all();

        $this->load->library('curl');
        $this->curl->init();
        //交易数据
        $home_data_output = $this->curl->get('https://www.cybtc.net/api/home'); 
        $home_data = json_decode($home_data_output,true);

        //btc_info
        $btc_data_output = $this->curl->get('https://www.cybtc.net/api/dig/data/btc/blockchain/info');  
        $btc_data = json_decode($btc_data_output,true);
        $btc_ticker_sell = $home_data['btc']['cny'];
        $btc_difficulty = $btc_data['difficulty'];
        $btc_output = $btc_data['difficulty'] > 0.1 ? 1000/($btc_data['difficulty']*7.158*0.001)*1800 : 0;

        //ltc_info
        $ltc_data_output = $this->curl->get('https://www.cybtc.net/api/calculator/cryptoid/ltc');   
        $ltc_data = json_decode($ltc_data_output,true);
        $ltc_block = $ltc_data*1000;
        $ltc_ticker_sell = $home_data['ltc']['cny'];
        $ltc_difficulty = $ltc_data;
        $ltc_output =$ltc_block > 0 ? (1/$ltc_block*14400) : 0;//   根据难度算出每T每天收益
       
        $filename = "application/cache/lock/lock_user_hash.txt";
       
        if (file_exists($filename)) {
            echo 1;
        }else{
            $fh  =  fopen ( $filename ,  'a' );
            fclose ( $fh );
            
            for ($i=1; $i <=3 ; $i++) {
                $btc_hash_total = 0;
                $ltc_hash_total = 0;
                $btc_order_hash = array();
                $ltc_order_hash = array();
             
                foreach ($product_hash_type as $key => $value) { 
                    //获取前一天符合条件的算力订单，status=8 正在运行
                    $order_hash = $this->Order_hash_model->get_order_user_hash_income(8,$value['id'],$i);

                    if (!empty($order_hash)) {
                        if($value['name'] == 'BTC'){//比特币
                            foreach ($order_hash as $k => $v) {
                                if($v['income_start_time'] <= time() && $v['income_end_time'] >= time()){//正在运行，计算总算力
                                    if($v['unit'] == 2){
                                        $btc_hash_total = $btc_hash_total + $v['hold_amount'] * $v['hash'];
                                    } elseif($v['unit'] == 1){
                                        $btc_hash_total = $btc_hash_total + $v['hold_amount'] ;
                                    }   
                                }
                            }

                            $btc_order_hash = array_merge($btc_order_hash,$order_hash); 
                           
                        } 
                        if($value['name'] =='LTC') {
                            foreach ($order_hash as $k => $v) {
                                if($v['income_start_time'] <= time() && $v['income_end_time'] >= time()){//正在运行，计算总算力
                                    if($v['unit'] == 2){
                                        $ltc_hash_total = $ltc_hash_total + $v['hold_amount'] * $v['hash'];
                                    } elseif($v['unit'] == 1){
                                        $ltc_hash_total = $ltc_hash_total + $v['hold_amount'] ;
                                    }   
                                }
                            }
                            $ltc_order_hash = array_merge($ltc_order_hash,$order_hash);
                        }
                       
                    }
                }
                $btc_reckon_amount = round($btc_output * $btc_hash_total,8);// 理论总收益
                $ltc_reckon_amount = round($ltc_output * $btc_hash_total,8);// 理论总收益
                
                $compute_time = time(); 
                $payable_time = $compute_time - 86400;

                //插入user_hash_income表
                if ($btc_hash_total > 0) {

                    $btc_hash_income_id = $this->User_hash_income_model->add($btc_hash_total,$btc_reckon_amount,$btc_difficulty,$payable_time,$compute_time,$btc_ticker_sell,1,$i);
                    //插入到user_hash_income_details表
                    foreach ($btc_order_hash as $hash_detail) {
                        if ($hash_detail['unit'] == 2) {
                            $hold_amount = $hash_detail['hold_amount'] * $hash_detail['hash'];
                        } elseif($hash_detail['unit'] == 1){
                            $hold_amount = $hash_detail['hold_amount'];
                        }
                        if($hash_detail['status'] == 10){
                            $is_overtime = 1;
                        }elseif($hash_detail['status'] == 8){
                            $is_overtime = 0;
                        }
                        if($hash_detail['income_start_time'] <= time() && $hash_detail['income_end_time'] >= time()){
                            $arr = array(
                                        'user_id'=>$hash_detail['user_id'],
                                        'order_hash_id'=>$hash_detail['id'],
                                        'hash_income_id'=>$btc_hash_income_id,
                                        'product_hash_id'=>$hash_detail['product_id'],
                                        'btc_address'=>0,
                                        'hold_amount'=>$hold_amount,
                                        'payable_time'=>$payable_time,
                                        'payable_amount'=>0,
                                        'paid_time'=>0,
                                        'paid_amount'=>0,
                                        'status'=>0,
                                        'compute_time'=>$compute_time,
                                        'product_hash_type'=>$hash_detail['product_hash_type'],
                                        'is_overtime'=>$is_overtime,
                                        'site_id'=>$hash_detail['site_id'],
                                        'income_type'=>1,
                                        );
                            $this->User_hash_details_model->insert_user_hash_details($arr);
                        }
                    }
                    
                } 
                if($ltc_hash_total > 0){
                    $ltc_hash_income_id = $this->User_hash_income_model->add($ltc_hash_total,$ltc_reckon_amount,$ltc_difficulty,$payable_time,$compute_time,$ltc_ticker_sell,3,$i);
                    //插入到user_hash_income_details表
                    foreach ($ltc_order_hash as $hash_detail) {
                        if ($hash_detail['unit'] == 2) {//按台
                            $hold_amount = $hash_detail['hold_amount'] * $hash_detail['hash'];
                        } elseif($hash_detail['unit'] == 1){//按T
                            $hold_amount = $hash_detail['hold_amount'];
                        }
                        if($hash_detail['status'] == 10){
                            $is_overtime = 1;
                        }elseif($hash_detail['status'] == 8){
                            $is_overtime = 0;
                        }
                        if($hash_detail['income_start_time'] <= time() && $hash_detail['income_end_time'] >= time()){
                            $arr = array(
                                        'user_id'=>$hash_detail['user_id'],
                                        'order_hash_id'=>$hash_detail['id'],
                                        'hash_income_id'=>$ltc_hash_income_id,
                                        'product_hash_id'=>$hash_detail['product_id'],
                                        'btc_address'=>0,
                                        'hold_amount'=>$hold_amount,
                                        'payable_time'=>$payable_time,
                                        'payable_amount'=>0,
                                        'paid_time'=>0,
                                        'paid_amount'=>0,
                                        'status'=>0,
                                        'compute_time'=>$compute_time,
                                        'product_hash_type'=>$value['id'],
                                        'is_overtime'=>$is_overtime,
                                        'site_id'=>$hash_detail['site_id'],
                                        'income_type'=>1,
                                        );
                            $this->User_hash_details_model->insert_user_hash_details($arr);
                        }
                    }
                }
             
            }
            unlink ( $filename );
            echo "成功";      
        }
    }

    //算力订单(不用实时跑)
    public function changeOrderHash()
    {
        $this->load->model('Order_hash_model');
        $res = $this->Order_hash_model->get_order_hash();
        $this->db->trans_start();        
        foreach($res as $key=>$value){           
            $order_no = 'T'.date('YmdHis',$value['create_time']+$key).substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 4);
            $this->Order_hash_model->update_order_no($value['id'],$order_no);
        }
        $this->db->trans_complete();        
        echo 'success';
    }

    //矿机订单（不用实时跑）
    public function changeOrderMiner()
    {
        $this->load->model('Order_miner_model');
        $res = $this->Order_miner_model->get_order_miner();
        $this->db->trans_start();
        
        foreach($res as $key=>$value){
            $order_no = 'M'.date('YmdHis',$value['created_time']+$key).substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 4);
           
            $this->Order_miner_model->update_order_no($value['id'],$order_no);

        }
        $this->db->trans_complete();
        
        echo 'success';
    }

    //邀请码（不用实时跑）
    public function makeInviteCode()
    {
        $this->load->model('User_model');
        $res = $this->User_model->get_user_list();
        $this->db->trans_start();
        
        foreach($res as $key=>$value){
            $invite_code = get_invite_code();
            $this->User_model->update_invite_code($value['id'],$invite_code);

        }
        $this->db->trans_complete();
        
        echo 'success';
    }

    //转让产品迁移（不用实时跑）
    public function moveProductHash()
    {
        $this->load->model('Product_hash_model');
        $this->load->model('Transfer_product_hash_model');
        
        $res = $this->Product_hash_model->get_transfer_product_hash();
        $this->db->trans_start();
        
        foreach($res as $key=>$value){
            unset($value['id']);
            
            $this->Transfer_product_hash_model->insert_into($value);
        }
        $this->db->trans_complete();
        
        echo 'success';
    }

    //还款还款 提醒+逾期加息 -每天执行一次
    public function loan_msg(){
        $this->load->service('Loan_service');
        $loan_list  = $this->Loan_service->get_loan_status();//

        //测试
        $now_time = $this->uri->segment(3);
        if(!$now_time){
            $now_time = time();
        }
        //send_msg(21,array('loan_time'=>'开始还款日'),'loan_repayment');die;
        //开始还款日
        //最后还款日前三天
        //最后还款日当天
        //逾期后首日
        //逾期后三天
        //逾期后七天

        //站内信
        //开始还款日
        //最后还款日前三天 每日
        //逾期后每日
        foreach ($loan_list as $val){
            $user_id = $val['user_id'];
            $title  = lang('payment_by_installments');//标题-分期还款
            //发送短信站内信 提醒
            if($val['status'] == 1){
                //未还款
                $start_time = $val['repayment_time'] - 86400*15; //开始还款日
                $end_finally_three_time = $val['repayment_time'] - 86400*3; //最后还款日前三天
                $end_finally_time = $val['repayment_time'] - 86400*1; //最后还款日当天
                $repayment_time = date('Y-m-d',$val['repayment_time']);
                //短信/邮箱提醒
                //开始还款日
                if($now_time >$start_time && $now_time< $start_time+86400 ){
                    $replacement = array(
                        'loan_time' => lang('start_loan_day'),
                        'product_name' => $val['product_name'],
                        'repayment_money' => $val['repayment_money'],
                        'repayment_time' => $repayment_time,
                        'url' => get_site_info()['url']
                    );//要替换的短信内容
                    send_msg($user_id,$replacement,'start_loan_day');

                    $content = lang('loan_a1').$val['product_name'].lang('loan_a2').$val['repayment_money'].lang('loan_a3').$repayment_time.lang('loan_a4');//内容
                    send_notification($user_id,$title,$content);
                }
                //最后还款日前三天
                if($now_time >$end_finally_three_time && $now_time< $end_finally_three_time+86400 ){

                    $replacement = array(
                        'loan_time' => lang('end_loan_day_three'),
                        'product_name' => $val['product_name'],
                        'url' => get_site_info()['url']
                    );//要替换的短信内容

                    send_msg($user_id,$replacement,'end_loan_day_three');
                    $content = lang('loan_b1').$val['product_name'].lang('loan_b2');//内容
                    send_notification($user_id,$title,$content);
                }
                //最后还款日当天
                if($now_time >$end_finally_time && $now_time< $end_finally_time+86400 ){
                    $replacement = array(
                        'loan_time' => lang('end_loaning_day'),
                        'product_name' => $val['product_name'],
                        'url' => get_site_info()['url']
                    );//要替换的短信内容
                    send_msg($user_id,$replacement,'end_loaning_day');
                    $content = lang('loan_c1').$val['product_name'].lang('loan_c2');//内容
                    send_notification($user_id,$title,$content);
                }

                //站内信最后还款日前三天每日提醒
                if($now_time >$end_finally_three_time && $now_time< $val['repayment_time']){
                    $content = '站内信最后还款日前三天每日提醒';//内容
                    //send_notification($user_id,$title,$content);
                }

                //还款账单逾期
                if($now_time>  $val['repayment_time']){
                    $this->Loan_service->update_loan_status($val['id'],3);//更新
                    $content = '还款账单已逾期';//内容
                    send_notification($user_id,$title,$content);
                    send_msg($user_id,array('loan_time'=>'还款账单已逾期'),'loan_repayment');
                }


            }elseif ($val['status'] == 2){
                $repayment_time = date('Y-m-d',$val['repayment_time']);
                //不可还款
               if($val['repayment_time']-15*86400 < $now_time && $now_time<$val['repayment_time'] ){
                   $this->Loan_service->update_loan_status($val['id'],1);//更新
                   $content = lang('loan_a1').$val['product_name'].lang('loan_a2').$val['repayment_money'].lang('loan_a3').$repayment_time.lang('loan_a4');//内容
                   send_notification($user_id,$title,$content);
                    $replacement = array(
                        'loan_time' => lang('start_loan_day'),
                        'product_name' => $val['product_name'],
                        'repayment_money' => $val['repayment_money'],
                        'repayment_time' => $repayment_time,
                        'url' => get_site_info()['url']
                    );//要替换的短信内容
                    send_msg($user_id,$replacement,'start_loan_day');

                   // send_msg($user_id,array('loan_time'=>'开始还款日'),'loan_repayment');
               }

            }elseif ($val['status'] == 3 ){
                //逾期
                //更新逾期账单信息

                $day = round(($now_time-$val['repayment_time'])/86400);
                $overdue_interest = round($val['repayment_money']*$val['overdue_fee']*$day,2);
                $this->Loan_service->update_overdue($val['id'],$day,$overdue_interest);

                //逾期发消息
                $overdue_time = $val['repayment_time']; //逾期后首日
                $overdue_three_time = $val['repayment_time'] + 86400*2; //逾期后三日
                $overdue_seven_time = $val['repayment_time'] + 86400*7; //逾期后七日

                //短信/邮箱提醒
                //逾期后首日
                if($now_time >$overdue_time && $now_time< $overdue_time+86400 ){
                    $replacement = array(
                        'loan_time' => lang('loan_delay'),
                        'product_name' => $val['product_name'],
                        'day'  => 1,
                        'url' => get_site_info()['url']
                    );//要替换的短信内容
                    send_msg($user_id,$replacement,'loan_repayment');
                }
                //逾期后三日
                if($now_time >$overdue_three_time && $now_time< $overdue_three_time+86400 ){

                    $replacement = array(
                        'loan_time' => lang('loan_delay'),
                        'product_name' => $val['product_name'],
                        'day'  => 3,
                        'url' => get_site_info()['url']
                    );//要替换的短信内容
                    send_msg($user_id,$replacement,'loan_repayment');

                    //send_msg($user_id,array('loan_time'=>'逾期后三日'),'loan_repayment');
                }
                //逾期后七日
                if($now_time >$overdue_seven_time && $now_time< $overdue_seven_time+86400 ){
                    $replacement = array(
                        'loan_time' => lang('loan_delay'),
                        'product_name' => $val['product_name'],
                        'day'  => 7,
                        'url' => get_site_info()['url']
                    );//要替换的短信内容
                    send_msg($user_id,$replacement,'loan_repayment');
                    //send_msg($user_id,array('loan_time'=>'逾期后七日'),'loan_repayment');
                }

                $num = round(time()-$val['repayment_time']);
                //站内信提醒-每日
                $content =lang('loan_d1').$val['product_name'].lang('loan_d2').$num.lang('loan_d3');
                send_notification($user_id,$title,$content);
                
            }else{

                //暂无
            }
        }

    }

    //云算力自动上/下架(每分钟执行)
    public function product_putaway(){
        $this->load->service('Product_hash_service');
        $this->Product_hash_service->product_putaway();
    }



    //订单状态待运行->运行  在快照后面，一天一次
    public function order_run_status(){
        $this->load->model('Order_hash_model');
        $users = $this->Order_hash_model->get_order_by_status(7);
        $this->Order_hash_model->order_run_status(7,8);
        foreach ($users as $val){
            $title = lang('product_hash');
            $time = date('Y/m/d',time());
            $next_time = date('Y/m/d',time()+86400);
            $content = lang('product_a1').$val['product_hash_name'].lang('product_a2').$time.lang('product_a3').$next_time;//内容
            send_notification($val['user_id'],$title,$content);
            $replacement = array(
                'product_name' => $val['product_hash_name'],
                'next_income_time' => $next_time,
                'url' => get_site_info()['url']
            );//要替换的短信内容
            send_msg($val['user_id'],$replacement,'product_run');
        }

    }
    //转让自动下架(每分钟执行)
    public function transfer_update_status(){
        $this->load->model('Transfer_product_model');
        $end_time = time() - 86400*3;
        //返还冻结的数量/转让产品状态改为已结清
        $trans_info = $this->Transfer_product_model->transfer_info($end_time);
        foreach ($trans_info as $val){
            $this->Transfer_product_model->transfer_update_order_status($val['sy_amount'],$val['order_id']);
            $title = lang('product_hash');
            $content = lang('transfer_b1').$val['name'].lang('transfer_b2');//内容
            send_notification($val['user_id'],$title,$content);
            $replacement = array(
                'product_name' => $val['name'],
                'url' => get_site_info()['url']
            );//要替换的短信内容
            send_msg($val['user_id'],$replacement,'transfer_down');
        }
        $this->Transfer_product_model->transfer_update_status($end_time,8);
    }

    //提示更新
    public function transfer_update_status_for_appversion(){
        $this->load->model('Meid_update_mark_model');
        $c_time = time() - 120; //2分钟
        $this->Meid_update_mark_model->transfer_update_status_for_appversion($c_time,0);
    }

    //curl 获取矿机信息
    public function get_miner_info_by_curl(){


        $mainkey = 'Te9ylktPzU0_@S09J2REZHRkg!==#r3zdg';
        $time = time();
        $arr = array(
            'timestamp'=>$time
        );
        // var_dump(http_build_query($arr));

        $key = md5($mainkey.http_build_query($arr));
        // var_dump($mainkey.http_build_query($arr));
        // 1. 初始化一个cURL会话
        $ch = curl_init();

        $post_data = array(
            'sign' => $key,
            'timestamp' => $time
        );
        // var_dump($post_data);die;
        // 设置请求为post类型
        curl_setopt($ch, CURLOPT_POST, 1);
        // 添加post数据到请求中
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        // 2. 设置请求选项, 包括具体的url
        curl_setopt($ch, CURLOPT_URL, "http://192.168.3.28/suanli_yunwei/public/pws/thirdData/DataProduct/getMachines");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        // 3. 执行一个cURL会话并且获取相关回复
        $response = curl_exec($ch);
        // 4. 释放cURL句柄,关闭一个cURL会话
        curl_close($ch);
        $response = object_to_array(json_decode($response));
        $data = $response['data'];
        // var_dump($data);
        if(isset($data) && !empty($data))
        {
            foreach ($data as $key => $value) {
                # code...
                $this->load->model('Product_miner_base_model');
                $res = $this->Product_miner_base_model->miner_is_empty($value['name'],$value['watt'],$value['hashrate']);
                if(empty($res))
                {
                    $res = $this->Product_miner_base_model->add_miner($value['name'],$value['watt'],$value['hashrate']);
                }
            }
        }
        if ($response  === FALSE) {
          echo "cURL 具体出错信息: " . curl_error($ch);
        }       
    }

    //curl 获取托管信息



}
/* End of file Register.php */
