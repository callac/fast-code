<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//set_time_limit(0);
// ini_set('display_errors', 1);
// use Sys\SysClient;
// use Sys\QueryWalletReq;
use  com\baoquan\sdk\BaoquanClient;
class Tools extends Base_Controller
{
    private $baoquanKey;
    private $baoquanPath;
    function __construct() {
        parent::__construct();
        $ci =& get_instance();
        $ci->load->service('Logs_service');

        $this->load->service('Zjys_tongji_service');
        $this->load->service('Zjys_trade_service');
        $this->load->service('Alarm_service');
        $this->load->service('Tool_service');
        $this->load->service('Rm_parameter_service');
        $this->load->service('Checkaccount_service');

        $this->load->model('Zjys_user_model');
        $this->load->service('Data_visualization_service');
        $this->load->service('Sys_grpc_service');
        $this->load->service('Transfer_service');
        $this->load->service('Zjys_recharge_service');
        $this->load->service('Baoquan_service');
        $this->load->service('InOut_money_service');
        $this->load->service('Time_task_service');

        $this->baoquanKey    = 'iE9uVo3EqY5A8bDtVAjr7L';
        $this->baoquanPath   = 'application/config/key.pem';
    }

    //测试定时任务
    public function message($to = 'world')
    {
        // echo 2222;
        // $result  = get_market_last('BTC_CNY');
        $DB1 = $this->load->database('trade_history',true);
        // var_dump($symbolList);
        for ($i=0; $i < 100; $i++) {
            $sql = "select  sum(deal_money) as totalmoney,user_id,market from order_history_".$i." where market='".$value['symbol']."' and source='web,".$v['id']."' finish_time >".$start_time." and finish_time <".$end_time." group by user_id";
        }

        $object = object_to_array($DB1->query($sql)->result());
        var_dump($object);die;




        $filePath = 'application/cache/excel/user_20181011.xlsx';
        unlink($filePath);die;
        $oss = new \App\Helpers\oss_helper();
        $res = $oss->uploadCsvFile($filePath,'.csv',true);
        return $res;

        var_dump($res);die;
        // $fp = fopen("application/cache/lock/tools.txt", "a+");
        // echo fwrite($fp, 'sssssaaaaa');
        // fclose($fp);
    }

    //交易统计定时任务
    public function get_trade_statistic()
    {
        $args = $this->input->get();
        $time = isset($args['time']) ? $args['time'] : false;
        if($time === false){//定时任务统计前一天用户
            $stime = date('Y-m-d',time()-86400);
        }else{ //手动定时任务取当前的用户
            $stime = date('Y-m-d',strtotime($time));
        }
        $this->load->service('Zjys_trade_service');
        $time_area = $stime;
        $start_time = strtotime($time_area);
        $end_time = $start_time+86400;
        $data = $this->Zjys_trade_service->get_trade_statistic($start_time,$end_time,$time_area);
    }
    //用户统计定时任务
    public function statistics_users_task()
    {
        $this->load->service('Zjys_user_service');
        $args = $this->input->get();
        $data['list'] = $this->Zjys_user_service->statistics_users_task($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    //按指定时间循环执行定时任务
    public function shiwu1()
    {
        $args = $this->input->get();
        $ctime =strtotime('2018-11-6');
        $etime =strtotime('2018-11-8');
        $url = 'http://47.111.138.2:8884/index.php/tools/recharge_logs_csv';
        $arr = get_timearea_by_day($ctime,$etime);
        for($i=0;$i<count($arr);$i++)
        {
            $params = '?time='.date('Y-m-d H:i:s',$arr[$i]);
            $get_url = $url.$params;
            $ch = curl_init();
            // 设置请求为post类型
            curl_setopt($ch, CURLOPT_POST, 0);
            // 2. 设置请求选项, 包括具体的url
            curl_setopt($ch, CURLOPT_URL, $get_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            // 3. 执行一个cURL会话并且获取相关回复
            $response = curl_exec($ch);
            curl_close($ch);
        }
    }

    public function shiwu()
    {
        // echo 1;die;
        // $args = $this->input->get();
        // $ctime =strtotime('2018-11-6');
        // $etime =strtotime('2018-11-8');
        // $url = 'http://47.111.138.2:8883/example/php/client.php';
        //     // $params = '?time='.date('Y-m-d H:i:s',$ctime);
        //     // $get_url = $url.$params;
        //     $get_url = $url;
        //     $ch = curl_init();
        //     // 设置请求为post类型
        //     curl_setopt($ch, CURLOPT_POST, 0);
        //     // 2. 设置请求选项, 包括具体的url
        //     curl_setopt($ch, CURLOPT_URL, $get_url);
        //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //     curl_setopt($ch, CURLOPT_HEADER, 0);
        //     // 3. 执行一个cURL会话并且获取相关回复
        //     $response = curl_exec($ch);
        //     curl_close($ch);
        //     var_dump($response);die;
        //
        require_once './vendor/autoload.php';
        $client = new \Sys\SysClient("localhost:8882", [
            'credentials' => \Grpc\ChannelCredentials::createInsecure()
        ]);
        // list($reply, $status) = $client->QueryPlatform(new QueryPlatformReq())->wait();
        $req = new \Sys\QueryWalletReq();
        // var_dump($req);die;
        $startTime = new \Google\Protobuf\Timestamp();
        // var_dump($startTime);die;
        $startTime->setSeconds(time() - 86400);
        $req->setStartTime($startTime);
        $endTime = new \Google\Protobuf\Timestamp();
        $endTime->setSeconds(time());
        $req->setEndTime($endTime);
        $req->setAssetCode("ETH");
        // $req->setPlatform($reply->getPlatform());
        $req->setLogType(\Sys\QueryWalletReq\Log_type::RECHARGE);
        var_dump($req);
        list($reply, $status) = $client->QueryWalletReconciliation($req)->wait();
        var_dump($status);
        var_dump($reply);die;
        $arr = json_decode($reply->getResult(), true);
        var_dump($arr);die;
    }


    // 定时任务解仓
    public function unlock_position()
    {
        $this->load->service('Zjys_user_service');
        $this->load->model('Zjys_user_withdraw_model');
        $list = $this->Zjys_user_service->lockposition_list_cron();
        // var_dump($list);die;
        if(is_array($list) && !empty($list)){
            foreach ($list as $key => $value) {

                $this->db->trans_begin();

                $created_at = date("Y-m-d H:i:s",time());
                $updated_at = date("Y-m-d H:i:s",time());
                $last_balance = $this->Zjys_user_withdraw_model->get_last_balance($value['asset'],$value['user_id']);
                //3、后台新增操作记录
                $business = $this->config->item('ADMIN_UNFREEZE_ASSET'); //operation表中的operation_type
                $description = null;
                admin_operation_logs(0,$value['user_id'],$business,$description,$created_at,$value['id']);
                $this->Zjys_user_withdraw_model->change_lockposition_status($value['id']);
                // var_dump($result);
                //4、减去用户可用资金
                $text = '通过定时任务解仓';
                $ss = array('info'=>$text);
                $res = update_user_balance_bycurl($value['user_id'],$value['asset'],$value['amount'],$value['id']*10,$ss,'unlock_position');
                // $res = $this->Sys_grpc_service->ActivityBalanceUpdate($value['user_id'],0,$value['asset'],'unlock_position',$value['id'],$value['amount'],1,$ss,$ss);
                //2、新增冻记录
                // var_dump($res);
                $balance = bcsub($last_balance['balance'],$value['amount'],12);
                if($balance<0) returnJson('402','数据异常，请检查数据正确性！');

                $detail1 = json_encode(array('id'=>$value['id']));
                $business = $this->config->item('ADMIN_UNFREEZE');//freeze表中的business
                $this->Zjys_user_withdraw_model->add_aseet_fressze($created_at,$updated_at,$value['user_id'],$value['asset'],-$value['amount'],$business,$balance,$detail1);

                $trans_status = $this->db->trans_status();

                if($res['result']['status'] !== 'success'){
                    $trans_status = false;
                }

                if ($trans_status === false) {
                    $this->db->trans_rollback();
                    continue;
                } else {
                    $this->db->trans_commit();
                }
            }
        }

    }

    //持仓定时生成预奖励表
    public function activityholding_cron()
    {
        $args = $this->input->get();
        $this->load->model('Config_model');
        $activitydetail = $this->Config_model->activityholdingdetail($args['id']);
        // var_dump($activitydetail);
        $snapshot = strtotime($activitydetail['snapshot']);
        // $userids = $this->Config_model->getuserids();
        // var_dump($userids);die;
        $DB2 = $this->load->database('trade_log',true);
        $sql = "select  sum(balance) as balance,user_id from slice_balance_".$snapshot." where asset='".$activitydetail['asset']."' group by user_id";
        // var_dump($sql);die;
        $object = object_to_array($DB2->query($sql)->result());
        // var_dump($object);die;
        foreach ($object as &$value) {
            $otherFreeze = $this->Config_model->getuserfreeze_by_asset($value['user_id'],$activitydetail['asset']);
            if(is_array($otherFreeze) && empty($otherFreeze)){
                $ofreeze = '0';
            }else{
                $ofreeze = $otherFreeze['balance'];
            }
            $value['balance'] = $value['balance']+$ofreeze;

            if($value['balance']>0)
            {
                $hold_area = explode('|', $activitydetail['hold_area']);
                for($i=0;$i<count($hold_area);$i++)
                {
                    $xhold_area = explode(',',$hold_area[$i]);
                    if($xhold_area[0] ==0 ){
                        if($xhold_area[0]>$xhold_area[1]) returnJson('402','范围取值错误');

                        if($value['balance']>$xhold_area[0] && $value['balance']<$xhold_area[1]){
                            $award_percent = $xhold_area[2];break;
                        }else{
                            continue;
                        }
                    }
                    if($xhold_area[1] ==0)
                    {
                        if($value['balance']>=$xhold_area[0]){
                            $award_percent = $xhold_area[2];break;
                        }else{
                            continue;
                        }
                    }
                    if($xhold_area[0]!=0 && $xhold_area[1]!=0)
                    {
                        if($xhold_area[0]>=$xhold_area[1]) returnJson('402','范围取值错误');
                        if($value['balance']>=$xhold_area[0] && $value['balance']<$xhold_area[1]){
                            $award_percent = $xhold_area[2];break;
                        }else{
                            continue;
                        }
                    }
                }
                $status = 2;
                $created_at = date('Y-m-d H:i:s',time());
                $updated_at = date('Y-m-d H:i:s',time());
                $this->Config_model->add_activityholding_award($activitydetail['asset'],$value['user_id'],$activitydetail['id'],$activitydetail['snapshot'],$value['balance'],$activitydetail['award_get'],$award_percent,$status,$created_at,$updated_at);
            }
        }
    }

    //持仓活动定时跑发放奖励接口
    public function activityholdingaward_cron()
    {
        $args = $this->input->get();
        $this->load->model('Config_model');
        $status = 2;
        $activityholdawardlist = $this->Config_model->getactivityholdawardlist($args['id'],$status);
        // var_dump($activityholdawardlist);
        foreach ($activityholdawardlist as $key => $value) {
            $this->db->trans_begin();
            $tmp = bcmul($value['award_percent'],'0.01',2);
            $amount = bcmul($value['snapshot_asset'],$tmp,2);
            // var_dump($amount);
            //修改状态和
            $time = date('Y-m-d H:i:s',time());
            $aa =$this->Config_model->updateactivityholdaward($value['id'],$amount,$time);
            $text = '持仓奖励';
            $ss = array('info'=>$text);
            $res = update_user_balance_bycurl($value['user_id'],$value['asset'],$amount,$value['id'],$ss,$busi='hold_award');
            $trans_status = $this->db->trans_status();

            if($res['result']['status'] != 'success')
            {
                $trans_status = false;
            }
            if ($trans_status === false) {
                $this->db->trans_rollback();
                return false;
            } else {
                $this->db->trans_commit();
            }
            usleep(2000);//2000微妙 0.0002秒
        }
        $this->Config_model->changeholdingstatus($args['id']);

    }

    //发送电子邮件
    public function sendEmailtest()
    {
        $this->load->library('email');
        $this->email->from('zjaizyyy@163.com');
        $this->email->to('804018306@qq.com');
        $this->email->subject('Email Test');
        $this->email->message('Testing the email class.');
        // $aa = $this->email->send();
        if ( ! $this->email->send())
        {
            echo $this->email->print_debugger();
        }
    }

    //运营数据统计--------------------------------------------------------------START

    //运营数据之去重数据表
    public function deduplication_data()
    {
        return 0;
        $args = $this->input->get();
        $this->Zjys_tongji_service->deduplication_data($args);
    }

    //注册一览表
    public function usertotal()
    {
        $args = $this->input->get();
        $this->Zjys_tongji_service->get_login_numbers($args);
    }

    //充值一览表定时任务
    public function recharge_logs_csv(){
        $args = $this->input->get();
        $list = $this->Zjys_tongji_service->rechargelogs($args);
    }

    //提现一览表定时任务
    public function user_withdraw_csv(){
        $args = $this->input->get();
        $list = $this->Zjys_tongji_service->withdrawlogs($args);
    }

    //法币买入卖出数据生成
    public function c2c_order_csv(){

        $args = $this->input->get();
        // var_dump($args);die;
        // var_dump($args);die;
        $list = $this->Zjys_tongji_service->c2c_order($args);
    }

    //币币交易一览表
    public function tradetotal()
    {
        return 0;
        $args = $this->input->get();
        $list = $this->Zjys_tongji_service->tradetotal($args);
    }

    //---------------------------------------------------------------------------------END

    //注册一览表
    public function get_login_numbers(){
        $args = $this->input->get();
        $list = $this->Zjys_tongji_service->get_login_numbers($args);
    }

    //用户持币一览表
    public function get_holdcoin_numbers(){
        $args = $this->input->get();
        $list = $this->Zjys_tongji_service->get_holdcoin_numbers($args);
    }

    //交易监控
    public function transaction_alarm(){

        $start_time = time();
        $end_time = $start_time-3600;
        //读取交易数据
        $data = $this->Alarm_service->get_transaction_alarm($end_time,$start_time);

    }

    //异常盈亏监控
    public function profit_loss_alarm(){
        //读取交易数据
        $args = $this->input->get();
        $data = $this->Alarm_service->get_profit_loss($args);
    }

    //账户不平记录监控
    public function account_alarm(){
        //读取数据
        $data = $this->Alarm_service->get_account_alarm();
    }


    /**
     * Notes: 异常提币监控
     * User: 张哲
     * Date: 2018/11/26
     * Time: 20:42
     */
    public function withdraws_alarm(){
        //读取数据
        $data = $this->Alarm_service->get_withdraws_alarm();
    }

    /**
     * Notes:重复充币地址
     * User: 张哲
     * Date: 2018/11/29
     * Time: 18:41
     */
    public function address_alarm(){
        $this->Alarm_service->get_address_alarm();
    }

    /**
     * Notes: 大额充提监控(7日内累计折合，获取最近1日0点价格，对7日内的充值、提币进行折合，当折合值大于设置的阈值后，进行报警)
     * User: 张哲
     * Date: 2019-04-22
     * Time: 15:48
     */
    public function large_amount_charge_alarm(){
        $data = $this->Alarm_service->large_amount_charge_alarm();
    }


    /**
     * Notes: 提币到账时间监控
     * User: 张哲
     * Date: 2019-04-24
     * Time: 16:14
     */
    public function withdraws_wallet_alarm(){
        //读取数据
        $data = $this->Alarm_service->withdraws_wallet_alarm();
    }
    //交易笔数
    public function trade_number()
    {
        $args = $this->input->get();
        $number = $this->Zjys_tongji_service->trade_number($args);
    }

    //钱包快照
    public function wallet_snapshot()
    {
        $args =$this->input->get();
        $result = $this->Checkaccount_service->checkWalletBalance($args);
    }

    //历史钱包快照
    public function wallet_snapshot_all()
    {
        $args =$this->input->get();
        $result = $this->Checkaccount_service->checkWalletBalance_all($args);
    }

    /**
     * Notes: 赠币任务
     * User: 张哲
     * Date: 2019/3/27
     * Time: 17:28
     */
    public function gift_coin(){
        $list = $this->Transfer_service->take_data();
        //读取数据
        foreach ($list as $value) {
            $sum = $value['amount'];
            $data = $this->Transfer_service->batch_gift_coin1($value,$sum,$value['site_id']);
//            if($data!==true) returnJson('402','从此条数据'.$data['uid'].','.$data['asset'].','.$data['amount'].'起（包括此条），下方的数据均未调整成功！请检查此条数据合法性！');
//            usleep(2000);
        }
    }
    /**
     * Notes: 数据可视化，实时数据
     * User: 张哲
     * Date: 2019/1/4
     * Time: 15:58
     */
    public function data_visualization_real_time()
    {
        $args =$this->input->get();
        $result = $this->Data_visualization_service->data_visualization_real_time($args);
        var_dump($result);die;
    }


    public function abc1()
    {
        $db = $this->load->database('exchange_onlyread',true);
        // $user = '(382944,11507,76049,339584,675120,326326,378964,74480,93803,13359)';
        $user = '(382944,11507,76049,339584,675120,326326,378964,74480,93803,13359)';
        // $user = '(382944)';
        $stime = strtotime('2018-9-18');
        $etime = strtotime('2018-10-18');
        $DB2 = $this->load->database('trade_history_onlyread',true);
        $sql = 'select user_id,recommend_user_id from user_recommends where deleted_at is null and user_id in '.$user;
        $result = object_to_array($db->query($sql)->result());
        $new = array();
        foreach ($result as $k => $v) {
            $table_index = $v['recommend_user_id']%100;
            $new[$k]['recommend_user_id']=$v['recommend_user_id'];
            $new[$k]['user_id']=$v['user_id'];
            $sql1='SELECT sum(deal_fee) as fee,market from order_history_'.$table_index.' WHERE finish_time>'.$stime.' and finish_time<'.$etime.' and side=2 AND user_id='.$v['recommend_user_id'].' group by market';
            $res1 = object_to_array($DB2->query($sql1)->result());
            // var_dump($res1);die;
            if(!empty($res1)){
                foreach ($res1 as $key => $value) {
                    if(isset($value['market']) && $value['market'] == 'ZG_CNZ'){
                        $new[$k]['ZG'] = $value['fee'];
                    }else{
                        $new[$k]['ZG'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'ETH_CNZ'){
                        $new[$k]['ETH'] = $value['fee'];
                    }else{
                        $new[$k]['ETH'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'OEC_CNZ'){
                        $new[$k]['OEC'] = $value['fee'];
                    }else{
                        $new[$k]['OEC'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'POK_CNZ'){
                        $new[$k]['POK'] = $value['fee'];
                    }else{
                        $new[$k]['POK'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'BTC_CNZ'){
                        $new[$k]['BTC'] = $value['fee'];
                    }else{
                        $new[$k]['BTC'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'CARX_CNZ'){
                        $new[$k]['CARX'] = $value['fee'];
                    }else{
                        $new[$k]['CARX'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'CAM_CNZ'){
                        $new[$k]['CAM'] = $value['fee'];
                    }else{
                        $new[$k]['CAM'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'RREX_CNZ'){
                        $new[$k]['RREX'] = $value['fee'];
                    }else{
                        $new[$k]['RREX'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'CTS_CNZ'){
                        $new[$k]['CTS'] = $value['fee'];
                    }else{
                        $new[$k]['CTS'] = 0;
                    }
                    if(isset($value['market']) && $value['market'] == 'PATH_CNZ'){
                        $new[$k]['PATH'] = $value['fee'];
                    }else{
                        $new[$k]['PATH'] = 0;
                    }
                }
            }else{
                $new[$k]['ZG'] = 0;
                $new[$k]['ETH'] = 0;
                $new[$k]['OEC'] = 0;
                $new[$k]['POK'] = 0;
                $new[$k]['BTC'] = 0;
                $new[$k]['CARX'] = 0;
                $new[$k]['CAM'] = 0;
                $new[$k]['RREX'] = 0;
                $new[$k]['CTS'] = 0;
                $new[$k]['PATH'] = 0;
            }


            $sql11 = 'SELECT sum(deal_fee) as total from order_history_'.$table_index.' WHERE finish_time>'.$stime.' and finish_time<'.$etime.' and side=1 AND user_id='.$v['recommend_user_id'];
            $res11 = object_to_array($DB2->query($sql11)->result());
            if($res11[0]['total']==null){
                $new[$k]['CNZ'] = 0;
            }else{
                $new[$k]['CNZ'] = $res11[0]['total'];
            }
        }
        // var_dump($new);
        $csvpath = APPPATH.'cache/excel/bbbbb.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '上级' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '下级' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'ZG' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'ETH' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'OEC' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'POK' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'BTC' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'CARX' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'CAM' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'RREX' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'CTS' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'PATH' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'CNZ' ),
        );
        fputcsv( $handle, $header );
        foreach($new as $value){
            $fields =   [
                // iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['recommend_user_id'],
                $value['user_id'],
                $value['ZG'],
                $value['ETH'],
                $value['OEC'],
                $value['POK'],
                $value['BTC'],
                $value['CARX'],
                $value['CAM'],
                $value['RREX'],
                $value['CTS'],
                $value['PATH'],
                $value['CNZ'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function abc5()
    {
        // echo 1;die;
        $this->form_validation->set_rules('symbol','类型','required'); //银行卡号
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : ''; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        // $offset = ($page - 1) * $limit;

        $uid = !empty($args['uid']) ? intval($args['uid']) : '';

        // $start_time = !empty($args['start_time']) ? strtotime($args['start_time']): time()-86400;
        $start_time = !empty($args['start_time']) ? strtotime($args['start_time']): time()-7*3600*24;
        $end_time = !empty($args['end_time']) ? strtotime($args['end_time']): time();
        $symbol = isset($args['symbol']) ? $args['symbol']: '';

        $list = $this->Tool_service->platform_deal_detail($symbol,$uid,$start_time,$end_time,0,$limit);

        // var_dump($list);die;

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/aaaaadeal_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '订单id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易市场(交易对)' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交价格' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '角色' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                $value['order_id'],
                $value['market'],
                $value['amount'],
                $value['price'],
                $value['deal_fee'],
                $value['fee'],
                $value['role'],
                $value['side'],
                $value['time'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);

        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($csvpath,'/application');
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data['url']);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function abc3()
    {
        $time = $_POST['time'];
        $list = $this->Tool_service->platform_people($time);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/user_id'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手机号' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                $value['phone'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data['url']);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function abc4()
    {
        $fp = fopen("application/cache/lock/tools.txt", "a+");
        fwrite($fp, 'sssssaaaaa');
        fwrite($fp, time());
        fwrite($fp, $_SERVER['REQUEST_TIME']);
        fclose($fp);

    }
    //
    public function abc_test()
    {
        $db = $this->load->database('trade_history_onlyread',true);
        $user = '(685930,684308,684322,684468,591964,685958,329111,684462,685258,14156,370222)';
        // $user = '(685930,684308)';
        $sql = 'select A.user_id,A.recommend_user_id,B.created_at,B.last_login from user_recommends A left join users B on A.recommend_user_id=B.id where A.deleted_at is null and A.user_id in '.$user;
        $result = object_to_array($db->query($sql)->result());
        // var_dump($result);die;
        $DB2 = $this->load->database('exchange_onlyread',true); //正式trade_history库
        foreach ($result as &$value) {
            $index = $value['recommend_user_id']%100;
            $sql1 = 'select * from order_history_'.$index.' where user_id='.$value['recommend_user_id'].' order by id desc limit 1';;
            // var_dump($sql1);
            $result1 = object_to_array($DB2->query($sql1)->result());
            if(empty($result1)){
                $value['trade_time'] = '';
            }
            else{
                $value['trade_time'] = get_microtime_format($result1[0]['finish_time']);
            }
            $sql2 = 'select created_at from user_recharge_logs where user_id='.$value['recommend_user_id'];
            $result2 = object_to_array($db->query($sql2)->result());
            if(empty($result2)){
                $value['recharge_time'] = '';
            }
            else{
                $value['recharge_time'] = $result2[0]['created_at'];
            }
        }

        if(is_array($result) && empty($result)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/toolsabc'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '上级ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '下级ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '注册时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后登陆时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后充值时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后成交时间' ),
        );

        fputcsv( $handle, $header );
        foreach($result as $value){
            $fields =   [
                $value['user_id'],
                $value['recommend_user_id'],
                $value['created_at'],
                $value['last_login'],
                $value['recharge_time'],
                $value['trade_time'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);

        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($csvpath,'/application');
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data['url']);
        returnJson('200',lang('operation_successful'),$data);
    }
    //统计下级下下级交易额
    public function user_down_account(){
        $this->load->service('Zjys_statistics_service');
        $this->Zjys_statistics_service ->get_user_recommend_statistic();
        echo 'success';
    }

    public function abc1111()
    {
        $start_time = '2018-12-01';
        $end_time = '2018-12-31';
        $db = $this->load->database('zg_exchange_onlyread',true);
        $sql = "SELECT id from users where created_at>='$start_time' and created_at<='$end_time' and identity_success_time>='$start_time' and identity_success_time<='$end_time'";
        //这个月的所有用户id
        $result = object_to_array($db->query($sql)->result());
        // var_dump($result);die;
        //取指定时间所有的成交订单
        $db_tradehistory = $this->load->database('zg_tradehistory_onlyread',true);
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        for ($i=0; $i <100 ; $i++) {

            $sql = "select user_id from order_history_".$i." where `finish_time` > '$start_time' AND `finish_time` < '$end_time' group by user_id";
            // var_dump($sql);
            $object = object_to_array($db_tradehistory->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $num = 0 ;
        foreach ($new as $key => $value) {
            foreach ($result as $kk => $vv) {
                if($value['user_id']==$vv['id'])
                    $num++;
            }
        }
        var_dump($num);
        var_dump($new);die;
    }
    //单个币种指定时间，按用户分组获取手续费
    public function abc1234567()
    {
        $start_time = '2019-04-16';
        $end_time = '2019-04-17';
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        // $db = $this->load->database('zt_exchange_onlyread',true);
        // $db_tradehistory = $this->load->database('zt_tradehistory_onlyread',true);
        $db_tradehistory = $this->load->database('trade_history',true);
        // var_dump($db_tradehistory);die;
        for ($i=0; $i <100 ; $i++) {
            //按side,user_id分组，求指定交易对的手续费。
            $sql = "select sum(deal_fee) fee,side,market from order_history_$i where finish_time >=$start_time and
    finish_time < $end_time and market like 'LTC_%' and user_id not in (1003222) group by side, market";
            // $sql = "select market,finish_time from order_history_".$i." where `finish_time` >= $start_time and `finish_time`<$end_time";
            $object = object_to_array($db_tradehistory->query($sql)->result());

            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $sum = '0';
        var_dump($new);die;
        foreach ($new as $a => $b) {
            if($b['side']==2){
                $sum = bcadd($sum, $b['fee'],12);
            }
        }
        var_dump($sum);die;
        var_dump($c);die;
        $list = $new;
        // var_dump($list);die;
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');

        $csvpath = APPPATH.'cache/excel/WJH_USDT-320-321'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '买卖' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手续费' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '1卖出2买入' ),s
            // iconv( 'UTF-8', 'GB2312//IGNORE', '1限价2市价' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '价格' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', 'taker_fee' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', 'maker_fee' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '成交数量' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '成交金额' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '成交手续费' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '成交时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                // $value['market'],

                $value['side'],
                // $value['t'],
                // $value['price'],
                // $value['amount'],
                // $value['taker_fee'],
                // $value['maker_fee'],
                // $value['deal_stock'],
                // $value['deal_money'],
                $value['deal_fee'],
                // $value['source'],
                // get_microtime_format($value['finish_time']),
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data['url']);
        returnJson('200',lang('operation_successful'),$data);
    }

    //指定交易对、时间段查成交记录
    public function abc()
    {
        $start_time = strtotime('2019-08-20 16:00:00');
        $end_time = strtotime('2019-08-28 00:00:00');
        $db_tradehistory = $this->load->database('zt_tradehistory_onlyread',true);
        for ($i=0; $i <100 ; $i++) {
            /***********************指定条件的成交记录**************************************/
            // $sql = "select * from order_history_$i where finish_time >=$start_time and
            //         finish_time < $end_time and market='KGC_USDT'";

            /******************指定排名（按用户分组，求交易量deal_stock）**********************/
            // $sql = "select sum(deal_stock) as stock,user_id from order_history_$i where finish_time >=$start_time and
            //         finish_time < $end_time and market like 'HD_%' group by user_id";
            //         
            /******************指定（按用户分组，买入交易量deal_stock_buy）**********************/
            $sql = "select sum(deal_stock) as stock,user_id from order_history_$i where finish_time >=$start_time and
                     finish_time < $end_time and market='JNTK_USDT' and side=1 group by user_id";

            $object = object_to_array($db_tradehistory->query($sql)->result());

            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }

        $list = $new;
        // array_multisort(array_column($list,'stock'),SORT_DESC,$list);  //排序

        // var_dump($list);die;

        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/JNTK_USDT_SELL'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        /***********************指定条件的成交量***************************************/
        // $header = array(
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '成交（买入+卖出）' ),
        // );

        // fputcsv( $handle, $header );
        // foreach($list as $value){
        //     $fields =   [
        //         $value['user_id'],
        //         $value['stock'],
        //     ];
        //     fputcsv( $handle, $fields );
        // }
        
        /***********************指定条件的买入成交量***************************************/
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '成交（买入/卖出）' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                $value['stock'],
            ];
            fputcsv( $handle, $fields );
        }
        
        /***********************单纯的成交记录***************************************/

        // $header = array(
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '1卖出2买入' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '1限价2市价' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '价格' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '市场' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', 'taker_fee' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', 'maker_fee' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '成交数量' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '成交金额' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '成交手续费' ),
        //     iconv( 'UTF-8', 'GB2312//IGNORE', '成交时间' ),
        // );

        // fputcsv( $handle, $header );
        // foreach($list as $value){
        //     $fields =   [
        //         $value['user_id'],
        //         $value['side'],
        //         $value['t'],
        //         $value['price'],
        //         $value['amount'],
        //         $value['market'],
        //         $value['taker_fee'],
        //         $value['maker_fee'],
        //         $value['deal_stock'],
        //         $value['deal_money'],
        //         $value['deal_fee'],
        //         get_microtime_format($value['finish_time']),
        //     ];
        //     fputcsv( $handle, $fields );
        // }
        // 
        /***********************其他***************************************/
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data['url']);
        returnJson('200',lang('operation_successful'),$data);


    }


    public function abcsdfs()
    {
        $start_time = strtotime('2019-05-16 14:00:00');
        $end_time = strtotime('2019-06-25 00:00:00');
        $db_tradehistory = $this->load->database('zt_tradehistory_onlyread',true);
        for ($i=0; $i <100 ; $i++) {
            /***********************获取otc流水**************************************/
            $sql = "select FROM_UNIXTIME(time,'%Y-%m-%d %H:%i:%s') as time,user_id,asset,business,`change`,balance from balance_history_$i where time >=$start_time and
                    time < $end_time and business in ('otc_deposit','otc_transfer_out','otc_transfer_in')";
            // echo $sql;die;
            $object = object_to_array($db_tradehistory->query($sql)->result());

            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $list = $new;
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/otc_record'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );

        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '业务类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '变动值' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '余额' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['time'],
                $value['user_id'],
                $value['asset'],
                $value['business'],
                $value['change'],
                $value['balance'],
            ];
            fputcsv( $handle, $fields );
        }
        // 
        /***********************其他***************************************/
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data['url']);
        returnJson('200',lang('operation_successful'),$data);

    }


    public function abcsss()
    {
        // $start_time = '2019-02-25';
        // $end_time = '2019-02-27';
        // $start_time = strtotime($start_time);
        // $end_time = strtotime($end_time);
        // $db = $this->load->database('zt_exchange_onlyread',true);

        $db_tradehistory = $this->load->database('zt_tradehistory_onlyread',true);
        // var_dump($db_tradehistory);die;
        for ($i=0; $i <100 ; $i++) {
            $sql = "select sum(deal_money) as deal_money from order_history_".$i." where market='WJH_USDT'";
            // var_dump($sql);
            $object = object_to_array($db_tradehistory->query($sql)->result());
            // var_dump($object);

            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }


        }


        $list = $new;
        // var_dump($list);die;
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');

        $csvpath = APPPATH.'cache/excel/WJH_USDT'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '总交易量' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['deal_money'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        // var_dump($data['url']);
        returnJson('200',lang('operation_successful'),$data);

    }


    public function abc222()
    {
        echo 2222;
        $a = '3,2,1';
        $a = explode(',',$a);//字符串变数组
        var_dump($a);die;
        $oss = new \App\Helpers\oss_helper();
        // $str = $oss->getSignedUrlForGettingObject('http://ztidcardtest1.oss-cn-hangzhou.aliyuncs.com/1546658551116858c057b34234495139b8ac53a03f8ff10.jpg?OSSAccessKeyId=LTAI2xpi1GNCvboX&Expires=1546662151&Signature=4NYu8TIT1AnUNXsHjPQ3Z60xwtI%3D');
        $str = $oss->getSignedUrlForGettingObject('1546661006637a27af145a7954b1f606587e264820493.jpg');
        var_dump($str);die;
    }

    public function abc333()
    {
        var_dump($this->db);die;
        $result = array();
        $new = array(array('site_id'=>146),array('site_id'=>1));
        $new = array(array('site_id'=>146));
        $new1 = array(array('a'=>'aaa','b'=>'bbb','c'=>1,'d'=>'ddd'),array('a'=>'a','b'=>'b','c'=>146,'d'=>'d'),array('a'=>'123','b'=>'334','c'=>146,'d'=>'233'));
        print_r($new);
        print_r($new1);
        foreach ($new as $k => $v) {
            foreach ($new1 as $kk => $vv) {
                if($v['site_id'] == $vv['c'])
                {
                    $result[] = $vv;
                }
            }
            var_dump($result);die;
        }

        $result = array('title'=>'zhesihsha','key'=>'lsdjl','content'=>'lsjdjljljljljl');
        echo json_encode($result);

        $start_time = '2019-01-02';
        $end_time = '2019-01-05';
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        $db = $this->load->database('zt_exchange_onlyread',true);

        $db_tradehistory = $this->load->database('zt_tradehistory_onlyread',true);
        // var_dump($db_tradehistory);die;
        for ($i=0; $i <100 ; $i++) {
            // $sql = "select id,market,amount,role,side from user_deal_history_".$i." where `time` >$start_time AND `time` <$end_time and market='CHST_BTC'";
            $sql = "select user_id from user_deal_history_".$i." where `time` >$start_time AND `time` <$end_time and market='CHST_BTC'";
            // var_dump($sql);die;
            $object = object_to_array($db_tradehistory->query($sql)->result());
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        $list = $new;
        // var_dump($list);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');

        $csvpath = APPPATH.'cache/excel/whouserid'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', 'id' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '市场' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', 'role' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', 'side' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                // $value['market'],
                // $value['amount'],
                // $value['role'],
                // $value['side'],
            ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
    }


    //用户注册认证统计周数据
    public function user_week_data()
    {
        $args = $this->input->get();
        $this->Zjys_tongji_service->user_week_data($args);
    }

    public function absc()
    {
        $last_time = strtotime(date('Y-m-d H:00:00',time()));
        $asset = 'ETH';
        $start_time = '2018-01-21';
        $end_time = '2019-02-22';

        $db_exchange = $this->load->database('default',true);
        $db_tradehistory = $this->load->database('trade_history',true);
        $db_tradelog = $this->load->database('trade_log',true);


        $bid_amount_result = $this->bid_amount($start_time,$end_time,$asset,$db_tradehistory);
        $ask_amount_result = $this->ask_amount($start_time,$end_time,$asset,$db_tradehistory);
        $recharge_result = $this->asset_recharge($start_time,$end_time,$asset,$db_exchange);
        $withdraw_result = $this->asset_withdraw($start_time,$end_time,$asset,$db_exchange);

        // print_r($bid_amount_result);
        // print_r($ask_amount_result);
        // print_r($recharge_result);
        // print_r($withdraw_result);die;

        $new = array();
        if(count($ask_amount_result)>0){
            foreach ($bid_amount_result as $k => $v) {
                array_push($new,$v['user_id']);
            }
        }

        if(count($ask_amount_result)>0){
            foreach ($ask_amount_result as $kk => $vv) {
                array_push($new,$vv['user_id']);
            }
        }

        if(count($recharge_result)>0){
            foreach ($recharge_result as $kk => $vv) {
                array_push($new,$vv['user_id']);
            }
        }

        if(count($withdraw_result)>0){
            foreach ($withdraw_result as $kk => $vv) {
                array_push($new,$vv['user_id']);
            }
        }

        $new = array_values(array_unique($new));

        if(count($new)==0) returnJson('403','no data return');

        $new1 = array();
        foreach ($new as $a) {
            $new1[]['user_id'] = $a;
        }


        if(count($bid_amount_result)>0){
            foreach ($new1 as $k => $v) {
                foreach ($bid_amount_result as $kk => $vv) {
                    $result1[$k]['user_id'] = $v['user_id'];
                    if($v['user_id'] == $vv['user_id']){
                        $result1[$k]['bid_amount'] = $vv['bid_amount'];
                        break;
                    }else{
                        $result1[$k]['bid_amount'] = 0;
                    }
                }
            }
        }else{
            foreach ($new1 as $key => $value) {
                $result1[$key]['user_id'] = $value['user_id'];
                $result1[$key]['bid_amount'] = 0;
            }
        }

        if(count($ask_amount_result)>0){
            foreach ($result1 as $k => $v) {
                foreach ($ask_amount_result as $kk => $vv) {
                    $result2[$k]['user_id'] = $v['user_id'];
                    $result2[$k]['bid_amount'] = $v['bid_amount'];
                    if($vv['user_id'] == $v['user_id']){
                        $result2[$k]['ask_amount'] = $vv['ask_amount'];
                        break;
                    }else{
                        $result2[$k]['ask_amount'] = 0;
                    }
                }
            }
        }else{
            foreach ($result1 as $key => $value) {
                $result2[$key]['user_id'] = $value['user_id'];
                $result2[$key]['bid_amount'] = $value['bid_amount'];
                $result2[$key]['ask_amount'] = 0;
            }
        }


        if(count($recharge_result)>0){
            foreach ($result2 as $k => $v) {
                foreach ($recharge_result as $kk => $vv) {
                    $result3[$k]['user_id'] = $v['user_id'];
                    $result3[$k]['bid_amount'] = $v['bid_amount'];
                    $result3[$k]['ask_amount'] = $v['ask_amount'];
                    if($vv['user_id'] == $v['user_id']){
                        $result3[$k]['recharge_amount'] = $vv['amount'];
                        break;
                    }else{
                        $result3[$k]['recharge_amount'] = 0;
                    }
                }
            }
        }else{
            foreach ($result2 as $key => $value) {
                $result3[$key]['user_id'] = $value['user_id'];
                $result3[$key]['bid_amount'] = $value['bid_amount'];
                $result3[$key]['ask_amount'] = $value['ask_amount'];
                $result3[$key]['recharge_amount'] = 0;
            }
        }


        if(count($withdraw_result)>0){
            foreach ($result3 as $k => $v) {
                foreach ($withdraw_result as $kk => $vv) {
                    $result4[$k]['user_id'] = $v['user_id'];
                    $result4[$k]['bid_amount'] = $v['bid_amount'];
                    $result4[$k]['ask_amount'] = $v['ask_amount'];
                    $result4[$k]['reharge_amount'] = $v['reharge_amount'];
                    if($vv['user_id'] == $v['user_id']){
                        $result4[$k]['withdraw_amount'] = $vv['amount'];
                        break;
                    }else{
                        $result4[$k]['withdraw_amount'] = 0;
                    }
                }
            }
        }else{
            foreach ($result3 as $key => $value) {
                $result4[$key]['user_id'] = $value['user_id'];
                $result4[$key]['bid_amount'] = $value['bid_amount'];
                $result4[$key]['ask_amount'] = $value['ask_amount'];
                $result4[$key]['recharge_amount'] = $value['recharge_amount'];
                $result4[$key]['withdraw_amount'] = 0;
            }
        }

        print_r($result4);die;
        returnJson('200',$result4);
    }


    function asset_recharge($start_time,$end_time,$asset,$db_exchange)
    {
        $sql = "select user_id,sum(amount) as amount from user_recharge_logs where status=1 and asset='".$asset."' and updated_at>='".$start_time."' and updated_at<'".$end_time."' group by user_id";
        $res = $db_exchange->query($sql)->result_array();
        return $res;
    }

    function asset_withdraw($start_time,$end_time,$asset,$db_exchange)
    {
        $sql = "select user_id,sum(amount) as amount from user_withdraws where wallet_status='DONE' and asset='".$asset."' and arrive_time>='".$start_time."' and arrive_time<'".$end_time."' group by user_id";
        $res = $db_exchange->query($sql)->result_array();
        return $res;
    }

    function bid_amount($start_time,$end_time,$asset,$db_tradehistory)
    {
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        for ($i=0; $i <100 ; $i++) {
            $sql = "select user_id,sum(amount) as bid_amount from user_deal_history_$i 
                where time>=$start_time and time<$end_time and side=2 and market= '".$asset."_CNT' group by user_id";
            // var_dump($sql);die;
            $object = $db_tradehistory->query($sql)->result_array();
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        return $new;
        // var_dump($new);die;
    }


    function ask_amount($start_time,$end_time,$asset,$db_tradehistory)
    {
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        for ($i=0; $i <100 ; $i++) {
            $sql = "select user_id,sum(amount) as ask_amount from user_deal_history_$i 
                where time>=$start_time and time<$end_time and side=1 and market= '".$asset."_CNT' group by user_id";
            // var_dump($sql);die;
            $object = $db_tradehistory->query($sql)->result_array();
            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        // var_dump($new);die;
        return $new;
    }

    public function asset_general_form()
    {
        $asset = 'ETH';
        $start_time = '2018-01-21';

        $end_time = '2019-02-21';

        $db_exchange = $this->load->database('default',true);
        $db_tradehistory = $this->load->database('trade_history',true);
        $db_tradelog = $this->load->database('trade_log',true);

        $trade_amount = $this->trade_amount($start_time,$end_time,$asset,$db_tradehistory);
        $recharge_form_result = $this->asset_recharge_form($start_time,$end_time,$asset,$db_exchange);
        $withdraw_form_result = $this->asset_withdraw_form($start_time,$end_time,$asset,$db_exchange);

        $result[]['trade_amount'] = $trade_amount;
        $result[]['echarge_amount'] = $recharge_form_result;
        $result[]['withdraw_amount'] = $withdraw_form_result;
        return $result;
    }

    function trade_amount($start_time,$end_time,$asset,$db_tradehistory)
    {
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        for ($i=0; $i <100 ; $i++) {
            $sql = "select sum(amount) as trade_amount from user_deal_history_$i 
                where time>=$start_time and time<$end_time and market= '".$asset."_CNT'";
            $object = $db_tradehistory->query($sql)->result_array();


            if($i==0){
                $new = array_merge(array(),$object);
            }else{
                @$new = &array_merge($new,$object);
            }
        }
        // var_dump($new);
        if(count($new)>0){
            $aa['amount'] = 0;
            foreach ($new as $key => $value) {
                $aa['amount'] += $value['trade_amount'];
            }
            return $aa['amount'];
        }else{
            return 0;
        }
    }

    function asset_recharge_form($start_time,$end_time,$asset,$db_exchange)
    {
        $sql = "select sum(amount) as amount from user_recharge_logs where status=1 and asset='".$asset."' and updated_at>='".$start_time."' and updated_at<'".$end_time."'";
        $res = $db_exchange->query($sql)->row_array();
        if($res['amount']!==NULL){
            return $res['amount'];
        }else{
            return 0;
        }
    }

    function asset_withdraw_form($start_time,$end_time,$asset,$db_exchange)
    {
        $sql = "select sum(amount) as amount from user_withdraws where wallet_status='DONE' and asset='".$asset."' and arrive_time>='".$start_time."' and arrive_time<'".$end_time."'";
        $res = $db_exchange->query($sql)->row_array();
        if($res['amount']!==NULL){
            return $res['amount'];
        }else{
            return 0;
        }
    }

    /**
     * ZG数据化1
     * [实名认证且在指定时间段内交易的用户人数]
     * @return [type] [description]
     */
    function abc1221222()
    {
        $a =  1.5;
        $b = -0.00005;
        var_dump((string)$a);
        var_dump((string)$b);
        $c = bcsub($a, $b,12);
        var_dump($c);die;
        $stime = strtotime('2019-02-01');
        $etime = strtotime('2019-03-01');

        $db1 = $this->load->database('zg_tradehistory_onlyread',true);
        $db2 = $this->load->database('zg_exchange_onlyread',true);
        $sql = "SELECT A.id,A.phone,A.email,B.`name`as real_name,B.number from users A
                LEFT JOIN user_identities B on B.user_id = A.id
                where A.created_at>'2019-02-01' and A.created_at<'2019-03-01'
                and A.user_identity_auth =1 
                and B.status=2
                GROUP BY B.user_id";
        $res = $db2->query($sql)->result_array();
        $num = 0;
        foreach ($res as $key => $value) {
            $table_index = $value['id']%100;
            // var_dump($table_index);die;
            $sql  = "SELECT user_id from order_history_$table_index WHERE finish_time>=$stime and finish_time<$etime group by user_id";
            $res = $db1->query($sql)->result_array();
            if(count($res)>0){
                $num += 1;
            }
        }
        log_message('error',"结果为$num");
    }

    function abcd()
    {
        if($_GET['time']){
            $start_time = strtotime($_GET['time']);
            $end_time = $start_time+86400;
        }else{
            $start_time = strtotime(date(Y-m-d,time()));
            $end_time = $start_time + 86400;
        }

        $db_tradelog = $this->load->database('trade_log',true); //测试环境trade_log库
        $db_tradehistory = $this->load->database('zt_tradehistory_onlyread',true);

        // $sql = "CREATE TABLE `order_history_$start_time` (
        //   `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        //   `create_time` double NOT NULL,
        //   `finish_time` double NOT NULL,
        //   `user_id` int(10) unsigned NOT NULL,
        //   `market` varchar(30) NOT NULL,
        //   `source` varchar(30) NOT NULL,
        //   `t` tinyint(3) unsigned NOT NULL,
        //   `side` tinyint(3) unsigned NOT NULL,
        //   `price` decimal(30,8) NOT NULL,
        //   `amount` decimal(30,8) NOT NULL,
        //   `taker_fee` decimal(30,4) NOT NULL,
        //   `maker_fee` decimal(30,4) NOT NULL,
        //   `deal_stock` decimal(30,8) NOT NULL,
        //   `deal_money` decimal(30,16) NOT NULL,
        //   `deal_fee` decimal(30,16) NOT NULL,
        //   PRIMARY KEY (`id`),
        //   KEY `idx_user_market` (`user_id`,`market`)
        // ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

        // $res = $db_tradelog->query($sql);

        // var_dump($res);die;


        for ($i=11; $i <100 ; $i++) {
            $created_at = $_SERVER['REQUEST_TIME'];
            $sql = "select * from order_history_$i 
                where finish_time>=$start_time and finish_time<$end_time";
            $list = $db_tradehistory->query($sql)->result_array();

            foreach ($list as $key => $res) {
                $sql = "INSERT INTO `trade_log`.`order_history_1553011200` (`create_time`, `finish_time`, `user_id`, `market`, `source`, `t`, `side`, `price`, `amount`, `taker_fee`, `maker_fee`, `deal_stock`, `deal_money`, `deal_fee`) VALUES ($created_at, $created_at, $res[user_id], '$res[market]', '$res[source]', $res[t], $res[side], $res[price], $res[amount], $res[taker_fee], $res[maker_fee], $res[deal_stock], $res[deal_money], $res[deal_fee])";

                $db_tradelog->query($sql);
            }
        }
    }

    /**
     * Notes: 保全-充提
     * User: 张哲
     * Date: 2019-04-08
     * Time: 16:43 15548104246225f41ca4f8535bc0ee660da9630d8af50b
     */
    public function baoquan_recharge(){
        $end_time = time();
        $start_time = $end_time - 300;
        $list = $this->Baoquan_service->recharge_list($start_time,$end_time);
        $counts = count($list); //文件数据条数
        if(is_array($list) && empty($list)) returnJson('402','无数据');
        $csvpath = APPPATH.'cache/excel/total_account_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', 'asset' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'amount' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'time' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'status' ),
        );
        fputcsv( $handle, $header);
        foreach($list as $value){
            $fields =   [
                $value['asset'],
                $value['amount'],
                $value['updated_at'],
                $value['status'],
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'',true);
        $hash = trim(strrchr($data['url'], '/'),'/');


        $file = file_get_contents($data['url']);
        $size =  strlen($file); //文件大小
        $size1 = strval($size);
        // $hash = substr($data['url'],-47);

        $client = new BaoquanClient();
        // 设置api地址，比如保全网的测试环境地址
        $client->setHost('https://www.baoquan.com');
        // 设置access key
        $client->setAccessKey($this->baoquanKey);
        // 设置rsa私钥文件的绝对路径
        $client->setPemPath($this->baoquanPath);

        // 调用创建保全接口，如果成功则返回保全号，如果失败则返回失败消息
        try {
            $response = $client->createAttestation([
                    // 设置保全唯一码
                    'unique_id'=>hash256(time()),
                    // 设置模板id
                    'template_id'=>'8F6znGV6PcsLvgZSXpjqEN',
                    // 设置保全所有者的身份标识
                    'identities'=>[
                        'ID'=>'42012319800127691X',
                        'MO'=>'15990185883',
                    ],
                    // 陈述对象列表
                    'factoids'=>[
                        [
                            'unique_id'=>hash256(time()+20000),
                            'type'=>'att',
                            'data'=>[
                                'name'=>'算利金控',
                                'orgCode'=>'68744527-000-01-18-6',
                                'fileName'=>'充提',
                                'fileSize'=>$size1,
                                'fileHash'=>$hash,
                            ]
                        ]
                    ],
                    // 设置陈述是否上传完成，如果设置成true，则后续不能继续追加陈述
                    'completed'=>true
                ]
            );
            echo $response['data']['no'];
        } catch (ServerException $e) {
            echo $e->getMessage();
        }
        $status = 2;
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $time = date('Y-m-d H:i:s',time());

        $this->Baoquan_service->add($hash,$response['data']['no'],$status,$start_time,$end_time,$time,$size,$counts);

    }

    /**
     * Notes: 保全-交易
     * User: 张哲
     * Date: 2019-04-09trade
     * Time: 17:06 155479511214842f41ca4f8535bc0ee660da9630d8af50b
     * @throws \com\baoquan\sdk\exception\ServerException
     */
    public function baoquan_trade(){
        $end_time = time();
        $start_time = $end_time - 300;
        $list = $this->Baoquan_service->trade_list($start_time,$end_time);
        $counts = count($list);
        //if(is_array($list) && empty($list)) returnJson('402','无数据');
        $csvpath = APPPATH.'cache/excel/baoquan_trade_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', 'asset' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'price' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'amount' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'money' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'time' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['market'],
                $value['price'],
                $value['amount'],
                $value['deal_money'],
                $value['finish_time'],
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'',true);
        $hash = trim(strrchr($data['url'], '/'),'/');
        $file = file_get_contents($data['url']);
        $size =  strlen($file); //文件大小
        $size1 = strval($size);
        // $hash = substr($data['url'],-47);

        $client = new BaoquanClient();
        // 设置api地址，比如保全网的测试环境地址
        $client->setHost('https://www.baoquan.com');
        // 设置access key
        $client->setAccessKey($this->baoquanKey);
        // 设置rsa私钥文件的绝对路径
        $client->setPemPath($this->baoquanPath);

        // 调用创建保全接口，如果成功则返回保全号，如果失败则返回失败消息
        try {
            $response = $client->createAttestation([
                    // 设置保全唯一码
                    'unique_id'=>hash256(time()),
                    // 设置模板id
                    'template_id'=>'8F6znGV6PcsLvgZSXpjqEN',
                    // 设置保全所有者的身份标识
                    'identities'=>[
                        'ID'=>'42012319800127691X',
                        'MO'=>'15990185883',
                    ],
                    // 陈述对象列表
                    'factoids'=>[
                        [
                            'unique_id'=>hash256(time()+20000),
                            'type'=>'att',
                            'data'=>[
                                'name'=>'算利金控',
                                'orgCode'=>'68744527-000-01-18-6',
                                'fileName'=>'交易',
                                'fileSize'=>$size1,
                                'fileHash'=>$hash,
                            ]
                        ]
                    ],
                    // 设置陈述是否上传完成，如果设置成true，则后续不能继续追加陈述
                    'completed'=>true
                ]
            );
            echo $response['data']['no'];
        } catch (ServerException $e) {
            echo $e->getMessage();
        }
        $status = 1;
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $time = date('Y-m-d H:i:s',time());
        //$hash = time().$hash;
        $this->Baoquan_service->add($hash,$response['data']['no'],$status,$start_time,$end_time,$time,$size,$counts);

    }

    /**
     * Notes: 保全-奖励
     * User: 张哲
     * Date: 2019-04-09
     * Time: 17:43 155481179913014f41ca4f8535bc0ee660da9630d8af50b
     * @throws \com\baoquan\sdk\exception\ServerException
     */
    public function baoquan_reward(){
        $end_time = time();
        $start_time = $end_time - 300;
//        $start_time = date('Y-m-d H:i:s',$start_time);
//        $end_time = date('Y-m-d H:i:s',$end_time);
        $list = $this->Baoquan_service->reward_list($start_time,$end_time);
        $counts = count($list);
        if(is_array($list) && empty($list)) returnJson('402','无数据');
        $csvpath = APPPATH.'cache/excel/total_account_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', 'asset' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'amount' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', 'time' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['asset'],
                $value['amount'],
                $value['created_at'],
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'',true);
        $hash = trim(strrchr($data['url'], '/'),'/');
        $file = file_get_contents($data['url']);
        $size =  strlen($file); //文件大小
        $size1 = strval($size);
        // $hash = substr($data['url'],-47);

        $client = new BaoquanClient();
        // 设置api地址，比如保全网的测试环境地址
        $client->setHost('https://www.baoquan.com');
        // 设置access key
        $client->setAccessKey($this->baoquanKey);
        // 设置rsa私钥文件的绝对路径
        $client->setPemPath($this->baoquanPath);

        // 调用创建保全接口，如果成功则返回保全号，如果失败则返回失败消息
        try {
            $response = $client->createAttestation([
                    // 设置保全唯一码
                    'unique_id'=>hash256(time()),
                    // 设置模板id
                    'template_id'=>'8F6znGV6PcsLvgZSXpjqEN',
                    // 设置保全所有者的身份标识
                    'identities'=>[
                        'ID'=>'42012319800127691X',
                        'MO'=>'15990185883',
                    ],
                    // 陈述对象列表
                    'factoids'=>[
                        [
                            'unique_id'=>hash256(time()+20000),
                            'type'=>'att',
                            'data'=>[
                                'name'=>'算利金控',
                                'orgCode'=>'68744527-000-01-18-6',
                                'fileName'=>'奖励',
                                'fileSize'=>$size1,
                                'fileHash'=>$hash,
                            ]
                        ]
                    ],
                    // 设置陈述是否上传完成，如果设置成true，则后续不能继续追加陈述
                    'completed'=>true
                ]
            );
            echo $response['data']['no'];
        } catch (ServerException $e) {
            echo $e->getMessage();
        }
        $status = 3;
        $start_time = date('Y-m-d H:i:s',$start_time);
        $end_time = date('Y-m-d H:i:s',$end_time);
        $time = date('Y-m-d H:i:s',time());
        $this->Baoquan_service->add($hash,$response['data']['no'],$status,$start_time,$end_time,$time,$size,$counts);

    }

    /**
     * Notes: 保全-活动
     * User: 张哲
     * Date: 2019-04-09
     * Time: 18:18
     * @throws \com\baoquan\sdk\exception\ServerException
     */
//    public function baoquan_activities(){
//        $end_time = time();
//        $start_time = $end_time - 300000;
//        $start_time = date('Y-m-d H:i:s',$start_time);
//        $end_time = date('Y-m-d H:i:s',$end_time);
//        $list = $this->Baoquan_service->reward_list($start_time,$end_time);
//        var_dump($list);die();
//        if(is_array($list) && empty($list)) returnJson('402','无数据');
//        $csvpath = APPPATH.'cache/excel/total_account_in_'.date('Y-m-d',time()).'.csv';
//        $handle = fopen( $csvpath, 'wb' );
//        $header = array(
//            iconv( 'UTF-8', 'GB2312//IGNORE', '资产类型' ),
//            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
//            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
//        );
//        fputcsv( $handle, $header );
//        foreach($list as $value){
//            $fields =   [
//                $value['market'],
//                $value['amount'],
//                $value['create_time'],
//            ];
//            fputcsv( $handle, $fields);
//        }
//        fclose($handle);
//        $filePath = strstr($csvpath,'application');
//        $oss = new \App\Helpers\oss_helper();
//        $data['url'] = $oss->uploadCsvFile($filePath,'',true);
//        $hash = substr($data['url'],-47);
//
//        $client = new BaoquanClient();
//        // 设置api地址，比如保全网的测试环境地址
//        $client->setHost('https://www.baoquan.com');
//        // 设置access key
//        $client->setAccessKey('bcboW9Hik2xXJ8Eu52sCYQ');
//        // 设置rsa私钥文件的绝对路径
//        $client->setPemPath($this->baoquanPath);
//
//        // 调用创建保全接口，如果成功则返回保全号，如果失败则返回失败消息
//        try {
//            $response = $client->createAttestation([
//                    // 设置保全唯一码
//                    'unique_id'=>hash256(time()),
//                    // 设置模板id
//                    'template_id'=>'8F6znGV6PcsLvgZSXpjqEN',
//                    // 设置保全所有者的身份标识
//                    'identities'=>[
//                        'ID'=>'42012319800127691X',
//                        'MO'=>'15990185883',
//                    ],
//                    // 陈述对象列表
//                    'factoids'=>[
//                        [
//                            'unique_id'=>hash256(time()+20000),
//                            'type'=>'att',
//                            'data'=>[
//                                'name'=>'算利金控',
//                                'orgCode'=>'68744527-000-01-18-6',
//                                'fileName'=>'交易',
//                                'fileSize'=>'2344',
//                                'fileHash'=>$hash,
//                            ]
//                        ]
//                    ],
//                    // 设置陈述是否上传完成，如果设置成true，则后续不能继续追加陈述
//                    'completed'=>true
//                ]
//            );
//            echo $response['data']['no'];
//        } catch (ServerException $e) {
//            echo $e->getMessage();
//        }
//        $status = 1;
//
//        $time = date('Y-m-d H:i:s',time());
//        $this->Baoquan_service->add($hash,$response['data']['no'],$status,$start_time,$end_time,$time);
//
//    }

    /**
     * Notes: 实时数据
     * User: 张哲
     * Date: 2019-04-15
     * Time: 18:28
     */
    public function real_data_time(){
        $this->Data_visualization_service->real_data_time();
        //returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 获取交易对当前成交价格
     * User: 张哲
     * Date: 2019-04-29
     * Time: 16:31
     */
    public function get_market(){
        $args =$this->input->get();
        $this->InOut_money_service->get_market_last($args);
        //returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes: 获取交易区数据
     * User: 张哲
     * Date: 2019-07-30
     * Time: 17:58
     */
    public function getTradeZoneData(){
        $args =$this->input->get();
        $this->Time_task_service->getTradeZoneData($args);
    }
    /**
     * [abc description]
     * @return [type] [description]
     */
    


}
