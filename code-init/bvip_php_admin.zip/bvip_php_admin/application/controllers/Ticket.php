<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Ticket extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Ticket_service');
    }

    //商户银行卡列表
    public function ticket_list(){
        $args = $this->input->post();
        // var_dump($args);
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; 
        $phone = isset($args['phone']) ? $args['phone'] : ''; 
        $email = isset($args['email']) ? $args['email'] : ''; 
        $site_id = !empty($args['site_id']) ? $args['site_id'] : ''; 
        $status = !empty($args['status']) ? $args['status'] : ''; 
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Ticket_service->ticket_list($offset,$limit,$user_id,$phone,$email,$site_id,$status,$start_time,$end_time);
        $count = $this->Ticket_service->ticket_list_count($user_id,$phone,$email,$site_id,$status,$start_time,$end_time);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    /**
     * 回复列表
     * @return [type] [description]
     */
    public function ticket_reply_list(){
        $args = $this->input->post();
        $data['list']= $this->Ticket_service->ticket_reply_list($args);
        returnJson('200',lang('operation_successful'),$data);
    }

    //工单回复
    public function ticket_message_reply()
    {
        $this->form_validation->set_rules('ticket_id','ticket_id','required');
        $this->form_validation->set_rules('message','message','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Ticket_service->ticket_message_reply($args);
        if($res === false){
            returnJson('402','');
        }else{
            returnJson('200','');
        }
    }

    //删除工单（弃用）
    public function ticket_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $this->Config_service->ticket_delete($id);
        returnJson('200',lang('operation_successful'));
    }

    public function ticket_close()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $this->Ticket_service->ticket_close($id);
        returnJson('200',lang('operation_successful'));
    }
}
