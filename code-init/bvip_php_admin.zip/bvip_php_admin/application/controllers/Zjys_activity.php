<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Zjys_activity extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_activity_service');
        $this->load->service('Transfer_service');

    }

    /**
     * 用户详情
     * @param integer  $user_id
     * @return array
     */
    public function get_info(){
        // echo 1;die;
        $this->form_validation->set_rules('id','ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $data =  $this->Zjys_activity_service->get_info($id);
        returnJson('200',lang('operation_successful'),$data);
    }

    
    /**
     * 获取列表
     *
     * @param integer  $page     当前页，默认值为第1页
     * @param integer  $limit    条数限制，默认值为10
     * @return array
     */
    public function activity_list(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $event = !empty($args['event']) ? $args['event'] : ''; //资产码
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null; 
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';


        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_activity_service->activity_list($offset,$limit,$event,$start_time,$end_time,$site_id);
        $count = $this->Zjys_activity_service->activity_list_count($event,$start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //新增注册认证活动
    public function add_activity(){
        $this->form_validation->set_rules('event','活动类型','required');
        $this->form_validation->set_rules('name','活动名称','required');
        $this->form_validation->set_rules('start_time', '活动开始时间','required');
        $this->form_validation->set_rules('end_time','活动结束时间','required');
        $this->form_validation->set_rules('award', '奖励','required');
        $this->form_validation->set_rules('award_asset','奖励币种','required');
        $this->form_validation->set_rules('is_lock','奖励币种','required');
        // $this->form_validation->set_rules('award_total','奖励总额','required');
        // $this->form_validation->set_rules('top_award','上级奖励','required');
        // $this->form_validation->set_rules('top_award_asset','上级奖励币种','required');
        
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        // echo 444;die;
        $args = $this->input->post();
        $res = $this->Zjys_activity_service->add_activity($args);
        if($res === false){
            returnJson('402','');
        }else{
            returnJson('200','');
        }
    }

    //新增注册认证活动
    public function delete(){
        $this->form_validation->set_rules('id','ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $data =  $this->Zjys_activity_service->delete($id);
        returnJson('200',lang('operation_successful'),$data);
    }

    //ZG国庆活动列表
    public function treasure_activity_list()
    {
        $args = $this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $finished = !empty($args['finished']) ? $args['finished'] : ''; //活动状态
        $name = !empty($args['name']) ? $args['name'] : ''; //活动状态
        $code = !empty($args['code']) ? $args['code'] : ''; //活动编号
        $init_method = !empty($args['init_method']) ? $args['init_method'] : ''; //活动编号
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;

        $data['list']= $this->Zjys_activity_service->treasure_activity_list($offset,$limit,$finished,$name,$code,$init_method,$start_time,$end_time,$site_id);
        $count = $this->Zjys_activity_service->treasure_activity_listcount($finished,$name,$code,$init_method,$start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //添加/编辑
    public function treasure_activity_add()
    {
        // var_dump($_POST);die;
        $this->form_validation->set_rules('name', '活动名称', 'required'); 
        $this->form_validation->set_rules('init_method', '活动发起方式', 'required'); 
        $this->form_validation->set_rules('total', '单场奖券投放总量', 'required'); 
        $this->form_validation->set_rules('pay_per_max', '单场单人购买奖券上限', 'required'); 
        $this->form_validation->set_rules('pay_amount', '单张奖券购买金额', 'required'); 
        $this->form_validation->set_rules('pay_asset', '币种', 'required'); 
        $this->form_validation->set_rules('award_type', '大奖类型', 'required'); 
        $this->form_validation->set_rules('award', '大奖金额/奖项名称', 'required'); 
        // $this->form_validation->set_rules('award_detail', '奖项详情', 'required'); 
        $this->form_validation->set_rules('start_time', '开始时间', 'required');
        $this->form_validation->set_rules('end_time', '结束时间', 'required');
        $this->form_validation->set_rules('day_start_time', '单日开始时间', 'required');
        $this->form_validation->set_rules('day_end_time', '单日结束时间', 'required');
        // $this->form_validation->set_rules('site_id', '站点id', 'required');

        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $args =$this->input->post();

        $res = $this->Zjys_activity_service->treasure_activity_add($args);
        if($res === false){
            returnJson('402','添加失败');
        }else{
            returnJson('200',lang('operation_successful'));
        }


    }
    //活动删除（display=0，活动中不能删除）
    public function treasure_activity_delete()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('id', '是否结束', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Zjys_activity_service->treasure_activity_delete($args);
        if($res === false){
            returnJson('402','添加失败');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //手动开启下一场活动
    public function treasure_activity_next()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('id', '活动id', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->curl_add_next_avtivity($args['id']);

        if($res === false){
            returnJson('402','操作失败');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //手动结束活动
    public function treasure_activity_end()
    {
        $args =$this->input->post();
        $this->form_validation->set_rules('finished', '是否结束', 'required');
        $this->form_validation->set_rules('id', '是否结束', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Zjys_activity_service->treasure_activity_end($args);
        if($res === false){
            returnJson('402','操作失败');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
     
    public function curl_add_next_avtivity($id)
    {
        $url = $this->config->item('ADMIN_API_URL').'/api/v1/treasure/create?id='.$id;
        $ch = curl_init();
        // 设置请求为post类型
        // curl_setopt($ch, CURLOPT_POST, 1);
        // 添加post数据到请求中
        // curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        // 2. 设置请求选项, 包括具体的url
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        // 3. 执行一个cURL会话并且获取相关回复
        $response = curl_exec($ch);
        // var_dump($response);die;
        // 4. 释放cURL句柄,关闭一个cURL会话
        curl_close($ch);
        $res = object_to_array(json_decode($response));
        if($res['code'] === 0){
            return true;
        }else{
            return false;
        }
    }


    public function treasure_session_activity_list()
    {
        $args = $this->input->post();
        $this->form_validation->set_rules('id', '活动id', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $treasures_id = $args['id'];
        // $treasures_id = 2;

        $offset = ($page - 1) * $limit;

        $data['list']= $this->Zjys_activity_service->treasure_session_activity_list($offset,$limit,$treasures_id,$site_id);
        $count = $this->Zjys_activity_service->treasure_session_activity_listcount($treasures_id,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    public function treasure_logs_activity_list()
    {
        $args = $this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $is_winning = !empty($args['is_winning']) ? $args['is_winning'] : '';
        $id = !empty($args['id']) ? $args['id'] : '';
        $award_sent = !empty($args['award_sent']) ? $args['award_sent'] : '';
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $treasures_session_logs_code = !empty($args['code']) ? $args['code'] : '';
        $offset = ($page - 1) * $limit;

        $data['list']= $this->Zjys_activity_service->treasure_logs_activity_list($offset,$limit,$is_winning,$award_sent,$start_time,$end_time,$treasures_session_logs_code,$site_id,$id);
        $count = $this->Zjys_activity_service->treasure_logs_activity_listcount($is_winning,$award_sent,$start_time,$end_time,$treasures_session_logs_code,$site_id,$id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //基础活动（注册、认证、C2C交易）奖励
    public function user_award_list(){
        $args = $this->input->post();
        $this->form_validation->set_rules('id', '活动id', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        // $type = !empty($args['type']) ? $args['type'] : '';
        $is_lock = isset($args['is_lock']) ? $args['is_lock'] : '';

        $user_id = isset($args['user_id']) ? $args['user_id'] : '';

        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';

        $activity_id = $args['id'];
        $offset = ($page - 1) * $limit;

        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';

        $data['list']= $this->Zjys_activity_service->user_award_list($offset,$limit,$start_time,$end_time,$activity_id,$is_lock,$site_id,$user_id);
        $count = $this->Zjys_activity_service->user_award_listcount($start_time,$end_time,$activity_id,$is_lock,$site_id,$user_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
    //活动奖励列表的导出
    public function user_award_list_priv(){
        $args = $this->input->post();
        $this->form_validation->set_rules('id', '活动id', 'required');
        if ($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        // $type = !empty($args['type']) ? $args['type'] : '';
        $is_lock = isset($args['is_lock']) ? $args['is_lock'] : '';

        $user_id = isset($args['user_id']) ? $args['user_id'] : '';

        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';

        $activity_id = $args['id'];
        $offset = ($page - 1) * $limit;

        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';

        $list= $this->Zjys_activity_service->user_award_list(0,'',$start_time,$end_time,$activity_id,$is_lock,$site_id,$user_id);

        
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/activity_award_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '上级用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手机号' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '邮箱' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '类型' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '时间' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['user_id'],              
                            $value['top_user_id'],  
                            // iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                            // $value['time'],   
                            $value['phone'],   
                            $value['email'],   
                            $value['asset'],   
                            $value['amount'],   
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['type_status']),   
                            iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark']),   
                            // $value['remark'], 
                            $value['created_at'] 
                        ];
            fputcsv( $handle, $fields );
        }

        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 活动单个解锁
     * User: 张哲
     * Date: 2019/2/28
     * Time: 21:54
     */
    public function activity_unlock(){
        $args = $this->input->post();
        $this->form_validation->set_rules('uid','用户id','required');
        $this->form_validation->set_rules('asset','币种','required');
        $this->form_validation->set_rules('site_id','站点','');
        $this->form_validation->set_rules('amount','数量','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        if($this->Zjys_activity_service->activity_unlock($args)===true){
            returnJson('200',lang('unlock successful'));
        }else{
            returnJson('402',lang('unlock failed'));
        }
    }

    /**
     * Notes: 获取文件
     * User: 张哲
     * Date: 2019/2/28
     * Time: 21:54
     */
    public function batch_activity_file()
    {
        $args = $this->input->post();
        $file = $_FILES['file'];
        // var_dump($args,$_FILES['file'],$file);die();
        $filename = $file['tmp_name'];
        $name = substr($file['name'],strpos($file['name'],'.')+1);
        if($name!=='csv') returnJson('402','文件格式错误');
        if (empty ($filename)) returnJson('402','csv文件缺失');
        $handle = fopen($filename, 'r');
        while ($data = fgetcsv($handle)) { //每次读取CSV里面的一行内容
            $list[] = $data;
        }
        if($list[0][0] === null) returnJson('402','没有数据');

        fclose($handle); //关闭指针

        foreach ($list as $key => $value) {
            $args['uid'] = $value[0];
            $args['asset'] = $value[1];
            $args['amount'] = $value[2];
            $args['lock'] = isset($value[3]) ? $value[3] : '';
            $args['expire_time'] = isset($value[4]) ? $value[4] : '';
            $encode = mb_detect_encoding($value[5], array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
            $args['remark'] = mb_convert_encoding($value[5], 'UTF-8',$encode);
            $result[$key] = $args;
        }
        returnJson('200',lang('operation_successful'),$result);
    }

    /**
     * Notes: 确认后扣除
     * User: 张哲
     * Date: 2019/2/28
     * Time: 21:54
     */
    public function batch_activity_unlock(){
        $args = $this->input->post();
        $result = json_decode($args['arr'],true);
        foreach ($result as $value) {
            $sum = $value['amount'];
            $data = $this->Zjys_activity_service->batch_activity_unlock($value,$sum,$args['site_id']);
            if($data!==true) returnJson('402','从此条数据'.$data['uid'].','.$data['asset'].','.$data['amount'].'起（包括此条），下方的数据均未调整成功！请检查此条数据合法性！');
            usleep(2000);
        }
        returnJson('200',lang('operation_successful'));
    }

    /**
     * Notes: 活动列表解锁扣除
     * User: 张哲
     * Date: 2019/3/1
     * Time: 12:49
     */
    public function activity_unlock_list(){
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $uid = isset($args['uid']) ? $args['uid'] : ''; //uid
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_activity_service->activity_unlock_list($start_time,$end_time,$offset,$limit,$asset,$site_id,$uid);
        $count = $this->Zjys_activity_service->activity_unlock_list_count($start_time,$end_time,$asset,$site_id,$uid);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 活动解锁列表扣除
     * User: 张哲
     * Date: 2019/3/1
     * Time: 13:00
     */
    public function activity_unlock_list_csv(){
        $args = $this->input->post();
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $asset = !empty($args['asset']) ? $args['asset'] : '';
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //站点
        $list = $this->Transfer_service->activity_unlock_csv($start_time,$end_time,$asset,$site_id);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/gift_coin_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '日期' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '赠送账户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '是否锁仓' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '解锁时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '管理员' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['created_at'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['site_name'] ),
                $value['asset'],
                $value['user_id'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['lock'] ),
                $value['expire_time'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['true_name'] ),
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(12,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * Notes: 活动解锁实例文件
     * User: 张哲
     * Date: 2019/3/8
     * Time: 15:33
     */
    public function activity_unlock_sample_csv(){
        $list = $this->Zjys_activity_service->activity_unlock_sample_csv();
        //if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/gift_coin_in_'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户ID' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '备注' ),
        );
        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [
                $value['user_id'],
                $value['asset'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(16,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }


}
