<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends SL_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->service('User_service');
    }

    public function login_action(){
        $data = $this->sign;
        $email = isset($data['email']) ? $data['email'] : false ;
        $password = isset($data['password']) ? $data['password'] : false ;
        if(!$email || !$password){
            returnJson('402',lang('missing_parameters'));
        }

        $info = $this->User_service->check_user_info($email,$password);
        $res = array();
        if($info['errorNo'] ==200){
            $token = jwt_helper::create($info['user_info']['id']);
            $res['token'] = $token;
            $this->User_service->update_user_token($info['user_info']['id'],$token);
            returnJson($info['errorNo'],$info['errorMsg'],$res);
        }
        returnJson($info['errorNo'],$info['errorMsg']);
    }

    public function login_mobile(){
        $data = $this->sign;
        $mobile = isset($data['mobile']) ? $data['mobile'] : false ;
        $password = isset($data['password']) ? $data['password'] : false ;
        if(!$mobile || !$password){
            returnJson('402',lang('missing_parameters'));
        }

        $info = $this->User_service->check_user_by_mobile($mobile,$password);
        $res = array();
        if($info['errorNo'] ==200){
            $token = jwt_helper::create($info['user_info']['id']);
            $res['token'] = $token;
            $url = get_site_info()['domain'];
            if(strtoupper($url) == 'SL.VIP'){
                $res['url'] = 'http://'.$url;
            }else{
                $res['url'] = 'http://'.$url.':8082/';
            }
            returnJson($info['errorNo'],$info['errorMsg'],$res);
        }
        returnJson($info['errorNo'],$info['errorMsg']);
    }


    /**
     * 忘记密码
     * @since 2018/1/18
     * @author zpf
     */
    public function reset_password(){
        $data = $this->sign;
        $email = isset($data['email']) ? $data['email'] : false ;
        $password = isset($data['password']) ? $data['password'] : false ;
        $code = isset($data['code']) ? $data['code'] : false ;
        if(!$email || !$password || !$code){
            returnJson(402,lang('missing_parameters'));
        }

        
        $this->User_service->re_pass($email,$password,$code);
    }

    /**
     * 忘记密码
     * @since 2018/1/18
     * @author zpf
     */
    public function reset_password_mobile(){
        $data = $this->sign;
        $mobile = isset($data['mobile']) ? $data['mobile'] : false ;
        $password = isset($data['password']) ? $data['password'] : false ;
        $code = isset($data['code']) ? $data['code'] : false ;
        if(!$mobile || !$password || !$code){
            returnJson(402,lang('missing_parameters'));
        }
        $this->User_service->re_pass_mobile($mobile,$password,$code);
    }

    /*
     *验证code-重置密码
     */
    public function check_code(){
        $code = $this->uri->segment(3, 0);
        $this->User_service->check_code($code);

        redirect(base_url().'login');
    }

    public function check_user(){
        $data = $this->sign;

        $email = isset($data['email']) ? $data['email'] : false ;
        if(!$email){
            returnJson('402',lang('missing_parameters'));
        }
        $data = $this->User_service->user_info($email);
        if($data){
            returnJson('200',lang('registered'));
        }else{
            returnJson('402',lang('unregistered'));
        }
    }

    //验证token是否过期
    public function check_jwt_token(){
        $data = $this->sign;
        $token = isset($data['token']) ? $data['token'] : false ;
        if(!$token){
            returnJson('402',lang('missing_parameters'));
        }
        $res = jwt_helper::validate($token);//解密
        if($res){
            returnJson('200',lang('token_valid'));
        }else{
            returnJson('402',lang('token_failed'));
        }
    }
}
