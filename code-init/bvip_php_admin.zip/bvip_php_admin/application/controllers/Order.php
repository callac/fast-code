<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Order extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Sys_grpc_service');
        $this->load->service('Cancel_market_record_service');

    }

    /**
     * 撤销委托订单，按单号、用户id、撤销
     * @param integer  $user_id  integer $id string $market
     * @return 
     */
    public function cancel_order_single(){
        $this->form_validation->set_rules('id','id','required');
        $this->form_validation->set_rules('user_id','user_id','required');
        $this->form_validation->set_rules('market','market','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $user_id = $this->input->post('user_id');
        $market = $this->input->post('market');
        $url = $this->config->item('VIABTC_API_URL');
        $params = array(
            'id'       => 1,
            'method'   => 'order.cancel', //取消订单
            'params'   => array((int)$user_id,$market,(int)$id),
        );
        $params = json_encode($params);
        $response = curl_common($url,$params,'post');
        $res = object_to_array(json_decode($response));
        $order = $res['result'];
        if($res['error']===null){
            $ctime= date("Y-m-d H:i:s",$order['ctime']);
            $mtime= date("Y-m-d H:i:s",$order['mtime']);
            $this->Cancel_market_record_service->cancel_market($order['user'],$order['amount'],$order['market'],$ctime,$mtime,$order['source'],$order['price'],$order['type'],$order['deal_money'],$order['side'],$order['taker_fee'],$order['maker_fee'],$order['left'],$order['deal_stock'],$order['id'],1);
            returnJson(200,lang('operation_successful'));
        }else{
            $ctime= date("Y-m-d H:i:s",$order['ctime']);
            $mtime= date("Y-m-d H:i:s",$order['mtime']);
            $this->Cancel_market_record_service->cancel_market($order['user'],$order['amount'],$order['market'],$ctime,$mtime,$order['source'],$order['price'],$order['type'],$order['deal_money'],$order['side'],$order['taker_fee'],$order['maker_fee'],$order['left'],$order['deal_stock'],$order['id'],0);
            returnJson(402,lang('cancel_order_failed'),$res['error']['message']);
        }

        $data =  $this->Zjys_activity_service->get_info($id,$user_id,$market);
        returnJson('200',lang('operation_successful'),$data);
    }

    /*
     *撤销整个市场的订单（慎重撤单）
     */
    public function cancel_order_market(){
        $this->form_validation->set_rules('market','market','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $market = $this->input->post('market');
        $offset = 0;
        $limit = 100;
        $url = $this->config->item('VIABTC_API_URL');
        //买单
        $params = array(
            'id'       => 1,
            'method'   => 'order.book', //委托记录
            'params'   => array($market,2,$offset,$limit),
        );
        $params = json_encode($params);
        $response = curl_common($url,$params,'post');
        $order_arr = object_to_array(json_decode($response));
        $variable = $order_arr['result']['orders'];

        //卖单
        $params1 = array(
            'id'       => 1,
            'method'   => 'order.book', //委托记录
            'params'   => array($market,1,$offset,$limit),
        );
        $params1 = json_encode($params1);
        $response1 = curl_common($url,$params1,'post');
        //$res1 = object_to_array(json_decode($response1));
        $order_arr1 = object_to_array(json_decode($response1));
        $variable1 = $order_arr1['result']['orders'];
        $res1 = array_merge($variable,$variable1);


        $res = $this->Sys_grpc_service->cancel_order_market($market);

        if($res===true){
            if(!empty($res1))
                foreach ($res1 as &$value) {
                    $ctime= date("Y-m-d H:i:s",$value['ctime']);
                    $mtime= date("Y-m-d H:i:s",$value['mtime']);
                    $this->Cancel_market_record_service->cancel_market($value['user'],$value['amount'],$value['market'],$ctime,$mtime,$value['source'],$value['price'],$value['type'],$value['deal_money'],$value['side'],$value['taker_fee'],$value['maker_fee'],$value['left'],$value['deal_stock'],$value['id'],1);
                }

            returnJson(200,lang('operation_successful'));
        }else{
            if(!empty($res1))
                foreach ($res1 as &$value) {
                    $ctime= date("Y-m-d H:i:s",$value['ctime']);
                    $mtime= date("Y-m-d H:i:s",$value['mtime']);
                    $this->Cancel_market_record_service->cancel_market($value['user'],$value['amount'],$value['market'],$ctime,$mtime,$value['source'],$value['price'],$value['type'],$value['deal_money'],$value['side'],$value['taker_fee'],$value['maker_fee'],$value['left'],$value['deal_stock'],$value['id'],1);
                }
            returnJson(402,lang('cancel_order_failed'),$res['error']['message']);
        }
    }


    /*
     *撤销某个用户某个市场的订单（慎重撤单）
     */
    public function cancel_order_user_market(){
        $this->form_validation->set_rules('market','market','required');
        $this->form_validation->set_rules('user_id','market','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $market = $this->input->post('market');
        $offset = 0;
        $limit = 100;
        $url = $this->config->item('VIABTC_API_URL');
        $params = array(
            'id'       => 0,
            'method'   => 'order.pending', //委托记录
            'params'   => array((int)$user_id,$market,$offset,$limit),
        );
        $params = json_encode($params);
        $response = curl_common($url,$params,'post');
        $order_arr = object_to_array(json_decode($response));

        if($order_arr['result']['total'] = 0){
            returnJson(402,lang('cancel_order_failed'));
        }else{
            //撤销订单
            $res = $this->Sys_grpc_service->cancel_order_user_market($user_id,$market);
        }

        if($res===true){
            $variable = $order_arr['result']['records'];

                foreach ($variable as &$value) {
                    $ctime= date("Y-m-d H:i:s",$value['ctime']);
                    $mtime= date("Y-m-d H:i:s",$value['mtime']);
                    $this->Cancel_market_record_service->cancel_market($value['user'],$value['amount'],$value['market'],$ctime,$mtime,$value['source'],$value['price'],$value['type'],$value['deal_money'],$value['side'],$value['taker_fee'],$value['maker_fee'],$value['left'],$value['deal_stock'],$value['id'],1);
                }
                returnJson(200,lang('operation_successful'));

        }else{
            $variable = $order_arr['result']['records'];
            if(!empty($variable))
                foreach ($variable as &$value) {
                    $ctime= date("Y-m-d H:i:s",$value['ctime']);
                    $mtime= date("Y-m-d H:i:s",$value['mtime']);
                    $this->Cancel_market_record_service->cancel_market($value['user'],$value['amount'],$value['market'],$ctime,$mtime,$value['source'],$value['price'],$value['type'],$value['deal_money'],$value['side'],$value['taker_fee'],$value['maker_fee'],$value['left'],$value['deal_stock'],$value['id'],0);
                }
            returnJson(402,lang('cancel_order_failed'),$res['error']['message']);
        }
    }


    //查询钱包资产余额
    public function QueryWalletBalance()
    {
        $this->form_validation->set_rules('asset','资产类型','required');
        // $this->form_validation->set_rules('date','资产类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $asset = $this->input->post('asset');
        $time = time();
        $result = $this->Sys_grpc_service->QueryWalletBalance($asset,$time);
    }

}
