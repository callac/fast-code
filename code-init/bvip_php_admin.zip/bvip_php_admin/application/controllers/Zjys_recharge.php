<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Zjys_recharge extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_recharge_service');
    }

    public function recharge_list(){
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $asset = isset($args['asset']) ? $args['asset'] : null; //资产码
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $status = isset($args['status']) ? $args['status'] : ''; //来源
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = isset($args['uid']) ? $args['uid'] : '';
        $offset = ($page - 1) * $limit;

        $data['list']= $this->Zjys_recharge_service->recharge_list($offset,$limit,$name,$start_time,$end_time,$asset,$site_id,$uid,$status);
        $count = $this->Zjys_recharge_service->recharge_list_count($name,$start_time,$end_time,$asset,$site_id,$uid,$status);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * Notes:充值审核
     * User: 张哲
     * Date: 2018/12/19
     * Time: 19:27
     */
    public function recharge_review(){
        //1.修改状态  2.增加余额
        $args =$this->input->post();
        $review = $this->Zjys_recharge_service->recharge_review($args);
        if($review == true){
            returnJson('200',lang('operation_successful'),$review);
        }else{
            returnJson('402',lang('recharge failure'),$review);
        }
    }

    public function recharge_list_printexcel(){
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $asset = isset($args['asset']) ? $args['asset'] : null; //资产码
        $status = isset($args['status']) ? $args['status'] : ''; //来源
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间

        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = isset($args['uid']) ? $args['uid'] : '';
        $offset = ($page - 1) * $limit;

        $list = $this->Zjys_recharge_service->recharge_list(0,'',$name,$start_time,$end_time,$asset,$site_id,$uid,$status);
        // var_dump($list);die;
        if(empty($list))
        {
          $data['url'] = false;
          returnJson('200',lang('operation_successful'),$data);
        }

        $arr = array();

        foreach ($list as $key => $val){
          $arr[$key]['user_id'] = $val['user_id'];
          $arr[$key]['email'] = $val['email'];
          $arr[$key]['phone'] = $val['phone'];
          $arr[$key]['name'] = $val['name'];
          $arr[$key]['asset'] = $val['asset'];
          $arr[$key]['amount'] = $val['amount'];
          $arr[$key]['confirmation'] = $val['confirmation'];
          $arr[$key]['tx_hash'] = $val['tx_hash'];
          $arr[$key]['updated_at'] = $val['updated_at'];
          $arr[$key]['status'] = $val['status'];
          // $arr[$key]['qbname'] = $val['qbname'];
          // $arr[$key]['updated_at'] = $val['updated_at'];
        }
        $title = array('用户id','邮箱', '手机','姓名', '资产类型', '数量','确认次数','哈希值','时间','状态1到账2审核中3失败');
        $data['url'] = excel_helper::print_excel($title,$arr,'user');
        // $data['url'] = $_SERVER['HTTP_HOST'].strstr($data['url'],'/application');
        $filePath = strstr($data['url'],'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.xlsx',true);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function recharge_address_list(){
        $args =$this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $name = isset($args['name']) ? $args['name'] : ''; //关键词
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $asset = isset($args['asset']) ? $args['asset'] : null; //资产码
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $uid = isset($args['uid']) ? $args['uid'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $address = !empty($args['address']) ? $args['address'] : '';

        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_recharge_service->recharge_address_list($offset,$limit,$name,$start_time,$end_time,$asset,$site_id,$uid,$address);
        $count = $this->Zjys_recharge_service->recharge_address_list_count($name,$start_time,$end_time,$asset,$site_id,$uid,$address);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }
}
