<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 可视化数据
 */
class Visual_data extends Web_Controller {

    public function __construct() {
        parent::__construct();
        // $this->load->service('Site_service');
    }

    /**
     * 获取机器人用户列表
     * @param integer  $page     当前页，默认值为第1页
     * @param integer  $limit    条数限制，默认值为10
     * @return array
     */
    public function robot_user_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10000; //偏移值
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_name = !empty($args['name']) ? $args['name'] : null;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Site_service->get_list($offset,$limit,$site_name,$site_id);
        $count = count($data['list']);

        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function get_list_noauth(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移值
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $site_name = !empty($args['name']) ? $args['name'] : null;
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Site_service->get_list($offset,$limit,$site_name,$site_id);
        $count = $this->Site_service->get_count($site_name);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 新增
     *
     * @param integer  $a    参数1
     * @param integer  $b    参数1
     * @return $code
     */
    public function add(){
        $this->form_validation->set_rules('name','站点名称','required');
        $this->form_validation->set_rules('title','站点标题','required');
        $this->form_validation->set_rules('domain','站点域名','required');
        $this->form_validation->set_rules('domain_user', '联系人','required');
        $this->form_validation->set_rules('domain_userphone', '联系方式','required');
        $this->form_validation->set_rules('language','默认语言','required');
        $this->form_validation->set_rules('asset_type','资产类型','required');
        $this->form_validation->set_rules('symbol_type','交易对类型','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res =$this->Site_service->add_site($args);
        if($res)returnJson('200','success');
        returnJson('402','username isset');

    }


    /**
     * 获取子站信息
     * @return $list
     */
    public function get_site_base(){
        $list = array();
        $this->load->model('Site_base_model');
        $site_language = $this->Site_base_model->get_info_by_type(1); //语言
        $site_currency = $this->Site_base_model->get_info_by_type(2); //货币类型
        $list['pay_type'] = Site_service::$pay_type;

        $language = array();
        foreach ($site_language as $val){
            $language[$val['name']] = $val['value'];
        }
        $list['language'] = $language;
        $currency = array();
        foreach ($site_currency as $val){
            $currency[$val['name']] = $val['value'];
        }
        $list['currency_type'] = $currency;
        $list['account_type'] = Site_service::$account_type;

        // $list['asset'] = Zjys_assets_service->$account_type;

        $privilages = $this->Site_service->get_site_role();
        // var_dump($privilages);die;
        foreach ($privilages as $key=>$val){
            $list[$key] = $val;
        }

        returnJson('200','success',$list);
    }

    /**
     * 获取配置信息列表
     * @return $list
     */
    public function site_base_list(){
        $this->load->model('Site_base_model');
        $site_language = $this->Site_base_model->get_info_by_type(null); //语言
        returnJson('200','success',$site_language);
    }

    /**
     * 获取站点信息列表
     * @return $list
     */
    public function site_info(){
        $site_list = $this->Site_service->site_all();
        returnJson('200','success',$site_list);
    }

    /**
     * 编辑
     * @param int  $id
     * @return $list
     */
    public function update(){
        $this->form_validation->set_rules('name','站点名称','required');
        $this->form_validation->set_rules('title','站点标题','required');
        $this->form_validation->set_rules('domain','站点域名','required');
        $this->form_validation->set_rules('domain_user', '联系人','required');
        $this->form_validation->set_rules('domain_userphone', '联系方式','required');
        $this->form_validation->set_rules('language','默认语言','required');
        // $this->form_validation->set_rules('style','模板','required');
        $this->form_validation->set_rules('asset_type','资产类型','required');
        $this->form_validation->set_rules('symbol_type','交易对类型','required');
        $this->form_validation->set_rules('id','站点ID','required');
        //$this->form_validation->set_rules('domain','域名信息','required');
        /*if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }*/
        $args = $this->input->post();
        $res =$this->Site_service->update($args);
        if($res)returnJson('200','success');
        returnJson('402','username isset');
    }

    public function site_close(){
        $this->form_validation->set_rules('id','站点id','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $type = $this->input->post('type');
        $res = $this->Site_model->site_close($id,$type);
        if($res)  returnJson('200','success');
        returnJson('402','error');
    }

    //domain新增
    public function domain_add(){
        $this->form_validation->set_rules('domain_url','域名url','required');
        $this->form_validation->set_rules('domain_name','域名name','required');
        $this->form_validation->set_rules('site_id','站点id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $domain_url = $this->input->post('domain_url');
        $domain_name = $this->input->post('domain_name');
        $site_id = $this->input->post('site_id');
        $res = $this->Site_service->domain_add($domain_url,$domain_name,$site_id);
        if($res)returnJson('200','success');
        returnJson('402','error');
    }
    //domain编辑
    public function domain_update(){
        $this->form_validation->set_rules('domain_url','域名url','required');
        $this->form_validation->set_rules('domain_name','域名name','required');
        $this->form_validation->set_rules('id','域名ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }

        $domain_url = $this->input->post('domain_url');
        $domain_name = $this->input->post('domain_name');
        $id = $this->input->post('id');
        $res = $this->Site_service->domain_update($id,$domain_url,$domain_name);
        if($res)returnJson('200','success');
        returnJson('402','error');
    }
    //domain删除
    public function domain_delete(){
        $this->form_validation->set_rules('id','域名ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $domain_id = $this->input->post('id');
        $res = $this->Site_service->domain_delete($domain_id);
        if($res)returnJson('200','success');
        returnJson('402','error');
    }

    //删除站点
    public function site_delete(){
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $this->Site_service->site_delete();
    }

    /**
     * ajax实时返回所有站点数据
     */
    public function ajaxsearch()
    {
        $this->form_validation->set_rules('name','站点名称','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $result = $this->Site_service->ajaxsearch();
        returnJson('200','success',$result);

    }
}
