<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class Zjys_assets extends Web_Controller 
{


    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_assets_service');
        $this->load->service('Sys_grpc_service');
        $this->load->service('Zjys_withdraw_service');
    }

    /**
     * 用户详情
     * @param integer  $user_id
     */
    public function get_info(){
        $this->form_validation->set_rules('user_id','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $data =  $this->Zjys_assets_service->get_info($user_id);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 获取列表
     *
     * @param integer  $page     当前页，默认值为第1页
     * @param integer  $limit    条数限制，默认值为10
     * @return array
     */
    public function asset_list(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $asset_code = !empty($args['asset_code']) ? $args['asset_code'] : ''; //资产码
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null; 
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_assets_service->asset_list($offset,$limit,$asset_code,$start_time,$end_time,$site_id);
        $count = $this->Zjys_assets_service->asset_list_count($asset_code,$start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function asset_list_noauth(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $asset_code = !empty($args['asset_code']) ? $args['asset_code'] : ''; //资产码
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null; 
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_assets_service->asset_list($offset,$limit,$asset_code,$start_time,$end_time,$site_id);
        $count = $this->Zjys_assets_service->asset_list_count($asset_code,$start_time,$end_time,$site_id);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    public function system_asset_list(){
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $asset_code = !empty($args['asset_code']) ? $args['asset_code'] : ''; //资产码
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null; 
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_assets_service->system_asset_list($offset,$limit,$asset_code,$start_time,$end_time);
        $count = $this->Zjys_assets_service->system_asset_list_count($asset_code,$start_time,$end_time);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * 总站的币种列表
     * @return object 
     */
    public function asset_list_totalsite(){
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 5000; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $asset_code = !empty($args['asset_code']) ? $args['asset_code'] : ''; //资产码
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        // $site_id = 1;
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_assets_service->asset_list_totalsite($offset,$limit,$asset_code,$start_time,$end_time,$site_id);
        // $count = $this->Zjys_assets_service->asset_list_count($asset_code,$start_time,$end_time,$site_id);
        $count = count($data['list']);

        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    /**
     * 新增/编辑币资产类型
     */
    public function add_asset(){
        $this->form_validation->set_rules('asset_code','资产码','required');
        $this->form_validation->set_rules('asset_name','资产名称','required');
        $this->form_validation->set_rules('recharge_status', '交易状态','required');
        $this->form_validation->set_rules('withdraw_status','提现状态','required');
        $this->form_validation->set_rules('trade_status', '交易状态','required');
        $this->form_validation->set_rules('withdraw_fee','提现费率','required');
        $this->form_validation->set_rules('recharge_verify','是否审核充值','required');
        // $this->form_validation->set_rules('withdraw_min','提现最小额度','required');
        // $this->form_validation->set_rules('withdraw_max','提现最大额度','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_assets_service->add_asset($args);
        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }

    public function system_asset_add(){
        $this->form_validation->set_rules('asset_code','资产码','required');
        $this->form_validation->set_rules('asset_name','资产名称','required');
        $this->form_validation->set_rules('recharge_status', '交易状态','required');
        $this->form_validation->set_rules('withdraw_status','提现状态','required');
        $this->form_validation->set_rules('trade_status', '交易状态','required');
        $this->form_validation->set_rules('withdraw_fee','提现费率','required');
        $this->form_validation->set_rules('recharge_verify','是否审核充值','required');
        $this->form_validation->set_rules('regex','地址正则','required');
        // $this->form_validation->set_rules('withdraw_min','提现最小额度','required');
        // $this->form_validation->set_rules('withdraw_max','提现最大额度','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_assets_service->system_asset_add($args);
        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //币种详细介绍
    public function asset_intro_list()
    {
        $args =$this->input->post();
        $limit = !empty($args['limit']) ? intval($args['limit']) : 5000; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $asset_code = !empty($args['asset_code']) ? $args['asset_code'] : ''; //资产码
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_assets_service->asset_intro_list($offset,$limit,$asset_code);
        $count = $this->Zjys_assets_service->asset_intro_list_count($asset_code);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    //添加币种详细介绍
    public function asset_intro_add(){
        $this->form_validation->set_rules('asset_code','资产码','required');
        $this->form_validation->set_rules('icon','','required');
        $this->form_validation->set_rules('desc', '简介','required');
        $this->form_validation->set_rules('full_name','全名','required');
        // $this->form_validation->set_rules('official_website', '官网','required');
        // $this->form_validation->set_rules('white_paper','白皮书','required');
        // $this->form_validation->set_rules('block_query','区块查询地址','required');
        // $this->form_validation->set_rules('founding_team','创建机构','required');
        // $this->form_validation->set_rules('recommend_organization','推荐机构','required');
        // $this->form_validation->set_rules('release_time','发行时间','required');
        // $this->form_validation->set_rules('release_total','发行总量','required');
        // $this->form_validation->set_rules('circulation_total','流通总量','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Zjys_assets_service->asset_intro_add($args);
        if($res === false){
            returnJson('402','数据异常');
        }else{
            returnJson('200',lang('operation_successful'));
        }
    }
    //删除币种详细介绍
    public function asset_intro_delete()
    {
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $res = $this->Zjys_assets_service->asset_intro_delete($args);
        if($res) returnJson('200',lang('operation_successful'));
        if($res) returnJson('403','删除失败');
        
    }
    /**
     * 重新向grpc服务发起提币请求
     * @return [bool] [description]
     */
    public function resend_withdraw()
    {
        $this->form_validation->set_rules('WithdrawId','WithdrawId','required');
        $this->form_validation->set_rules('remark','remark','required');
        if($this->form_validation->run() == FALSE)  returnJson('402',lang('missing_parameters'));
        $args = $this->input->post();
        $id = $args['WithdrawId'];
        $description = $args['remark'];

        $withdraw_info = $this->db->query("select user_id from user_withdraws where id=$id")->row_array(); 
        if(!$withdraw_info) returnJson('402','数据异常');
        $res = $this->Sys_grpc_service->ResendWithdraw($id);
        //写入管理员操作日志
        $business = $this->config->item('RESEND_WITHDRAW');
        $created_at = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
        $user_id = 5; //提币的那个用户ID
        admin_operation_logs($this->user_id,$withdraw_info['user_id'],$business,$description,$created_at,$id);
        if($res===true) 
            returnJson('200',lang('operation_successful'));
        else 
            returnJson('403',$res);
    }

}
