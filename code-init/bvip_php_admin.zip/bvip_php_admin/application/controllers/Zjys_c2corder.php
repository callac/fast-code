<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户管理
 */

class zjys_c2corder extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Zjys_c2corder_service');
        $this->load->service('Config_service');
        $this->load->service('Transfer_service');
    }

    /**
     * 用户详情
     * @param integer  $user_id
     * @return array
     */
    public function get_info(){
        $this->form_validation->set_rules('user_id','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $data =  $this->Zjys_c2corder_service->get_info($user_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    /**
     * 获取法币的买入卖出列表
     *
     * @param integer  $page     当前页，默认值为第1页
     * @param integer  $limit    条数限制，默认值为10
     * @return array
     */
    public function inout(){
        $this->form_validation->set_rules('type','类型','required'); //买入或卖出
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $type = !empty($args['type']) ? $args['type'] : ''; //类型：买入1 卖出2
        $order_no = !empty($args['order_no']) ? $args['order_no'] : ''; //订单号
        $name = !empty($args['name']) ? $args['name'] : ''; //姓名（非模糊）
        $useraccount = !empty($args['useraccount']) ? $args['useraccount'] : ''; //账户（非模糊）手机号和邮箱
        $status = !empty($args['status']) ? $args['status'] : ''; //状态：未成交1 已支付2 已成功3 已取消4 处理中6
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null; 
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $start_time_update = !empty($args['start_time_update']) ? $args['start_time_update'] : '';
        $end_time_update = !empty($args['end_time_update']) ? $args['end_time_update'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';
        $merchanta_card_number = !empty($args['merchanta_card_number']) ? $args['merchanta_card_number'] : '';
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Zjys_c2corder_service->inout($offset,$limit,$type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchanta_card_number,$start_time_update,$end_time_update);
        $count = $this->Zjys_c2corder_service->inout_count($type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchanta_card_number,$start_time_update,$end_time_update);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }


    public function inout_printexcel(){
        // TODO:
        // $E_T = microtime(TRUE);
        // $aaaa = $E_T-$B_T;
        // var_dump($aaaa);die;
        $this->form_validation->set_rules('type','类型','required'); //买入或卖出
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        // var_dump($args);die;
        $limit = !empty($args['limit']) ? intval($args['limit']) : 100; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $type = !empty($args['type']) ? $args['type'] : ''; //类型：买入1 卖出2
        $order_no = !empty($args['order_no']) ? $args['order_no'] : ''; //订单号
        $name = !empty($args['name']) ? $args['name'] : ''; //姓名（非模糊）
        $useraccount = !empty($args['useraccount']) ? $args['useraccount'] : ''; //账户（非模糊）手机号和邮箱
        $status = !empty($args['status']) ? $args['status'] : ''; //状态：未成交1 已支付2 已成功3 已取消4
        // $user_identity_auth = !empty($args['user_identity_auth']) ? $args['user_identity_auth'] : null; 
        $start_time = !empty($args['start_time']) ? $args['start_time'] : '';
        $end_time = !empty($args['end_time']) ? $args['end_time'] : '';
        $start_time_update = !empty($args['start_time_update']) ? $args['start_time_update'] : '';
        $end_time_update = !empty($args['end_time_update']) ? $args['end_time_update'] : '';
        $site_id = !empty($args['site_id']) ? $args['site_id'] : '';
        $uid = !empty($args['uid']) ? $args['uid'] : '';
        $merchanta_card_number = !empty($args['merchanta_card_number']) ? $args['merchanta_card_number'] : '';
        $offset = ($page - 1) * $limit;
        // var_dump($BEGIN_TIME);
        $list= $this->Zjys_c2corder_service->inout(0,'',$type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid,$merchanta_card_number,$start_time_update,$end_time_update);
        
                // $count = $this->Zjys_c2corder_service->inout_count($type,$order_no,$name,$useraccount,$status,$start_time,$end_time,$site_id,$uid);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');
        $csvpath = APPPATH.'cache/excel/c2c_inout_'.date('Y-m-d',time()).'.csv';
        // var_dump($list);die;
        if($type==1){
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '订单号' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '姓名' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户卡号' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '平台卡号' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '买入价格' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '买入数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '转账备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '状态' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '创建时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后操作时间' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '审核人' ),
        );
        fputcsv( $handle, $header );

        foreach($list as $value){
            $fields =   [
                $value['uid'],
                $value['order_no']."\t",
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['real_name'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['card_number'] ),
                // $value['card_number'],
                $value['merchanta_card_number']."\t",
                // iconv( 'UTF-8', 'GB2312//IGNORE', $value['merchanta_card_number'].' ' ),
                $value['price'],
                $value['amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['status_type'] ),
                $value['created_at'],
                $value['updated_at'],
                // iconv( 'UTF-8', 'GB2312//IGNORE', $value['check_detail'] ),
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(15,$data['url'],date('Y-m-d H:i:s',time()));


        returnJson('200',lang('operation_successful'),$data);
    }else{
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '订单号' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '姓名' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户卡号' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '平台卡号' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '卖出价格' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '卖出数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '实际到账' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '手续费' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '交易总额' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '转账备注' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '状态' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '创建时间' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '最后操作时间' ),
            // iconv( 'UTF-8', 'GB2312//IGNORE', '审核人' ),
        );
        fputcsv( $handle, $header );

        foreach($list as $value){
            $fields =   [
                $value['uid'],
                $value['order_no']."\t",
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['real_name'] ),
                // $value['real_name'],
                $value['user_card_number']."\t",
                $value['merchanta_card_number']."\t",
                // iconv( 'UTF-8', 'GB2312//IGNORE', $value['merchanta_card_number'].' ' ),
                $value['price'],
                $value['amount'],
                $value['real_amount'],
                $value['fee'],
                $value['total_amount'],
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['remark'] ),
                iconv( 'UTF-8', 'GB2312//IGNORE', $value['status_type'] ),
                $value['created_at'],
                $value['updated_at'],
                // iconv( 'UTF-8', 'GB2312//IGNORE', $value['check_detail'] ),
            ];
            fputcsv( $handle, $fields);
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        if($data['url']!==null) $this->Transfer_service->csvlogs(16,$data['url'],date('Y-m-d H:i:s',time()));
        returnJson('200',lang('operation_successful'),$data);
    }
        
}


    //审核
    public function c2c_verify()
    {
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['remark'];
        $caiwu_id = !empty($data['caiwu_id']) ? $data['caiwu_id'] : '';
        
        $result = $this->Zjys_c2corder_service->c2c_verify($id,$status,$remark,$caiwu_id); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }


    //审核
    public function c2c_verify_first()
    {
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $status = isset($data['status']) ? $data['status'] : false;
        if(!$status){
            returnJson('402',lang('missing_parameters'));
        }
        $remark = $data['remark'];
        $caiwu_id = !empty($data['caiwu_id']) ? $data['caiwu_id'] : '';
        
        $result = $this->Zjys_c2corder_service->c2c_verify_first($id,$status,$remark,$caiwu_id); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }







    //后台手动解冻币资产
    public function admin_unfreeze_asset()
    {
        $this->form_validation->set_rules('uid','状态','required');
        $this->form_validation->set_rules('asset','状态','required');
        $this->form_validation->set_rules('amount','状态','required');
        // $this->form_validation->set_rules('asset','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args =$this->input->post();
        $uid = !empty($args['uid']) ? $args['uid'] : 1;
        $asset = !empty($args['asset']) ? $args['asset'] : 2;
        $amount = !empty($args['amount']) ? trim($args['amount']) : 0;
        $remark = !empty($args['remark']) ? $args['remark'] : '';
        $result = $this->Zjys_c2corder_service->admin_unfreeze_asset($uid,$asset,$amount,$remark);

        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }










    //新增币资产种类
    public function add_asset(){
        $this->form_validation->set_rules('asset_code','资产码','required');
        $this->form_validation->set_rules('asset_name','资产名称','required');
        $this->form_validation->set_rules('recharge_status', '交易状态','required');
        $this->form_validation->set_rules('withdraw_status','提现状态','required');
        $this->form_validation->set_rules('trade_status', '交易状态','required');
        $this->form_validation->set_rules('withdraw_fee','提现费率','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        // echo 444;die;
        $args = $this->input->post();
        $res = $this->Zjys_c2corder_service->add_asset($args);
        if($res === false){
            returnJson('402','');
        }else{
            returnJson('200','');
        }
    }
    //编辑币种类
    public function edit_asset(){
        $this->form_validation->set_rules('name','产品名','required');
        $this->form_validation->set_rules('product_hash_type','算力类型','required');
        $this->form_validation->set_rules('unit', '单位','required');
        $this->form_validation->set_rules('amount','总量','required');
        $this->form_validation->set_rules('one_amount_value', '单价','required');
        $this->form_validation->set_rules('buy_min_amount','起投数量','required');
        $this->form_validation->set_rules('powerRate','电费','required');
        $this->form_validation->set_rules('maintenance','维护费','required');
        $this->form_validation->set_rules('income_start_time','起息时间','required');
        $this->form_validation->set_rules('income_end_time','结息时间','required');
        $this->form_validation->set_rules('sell_start_time','起售时间','required');
        $this->form_validation->set_rules('sell_end_time','停止销售时间','required');
        $this->form_validation->set_rules('is_top','是否首页展示','required');
        $this->form_validation->set_rules('status','产品状态','required');
        //$this->form_validation->set_rules('is_loan','是否分期','required');
        $this->form_validation->set_rules('description','描述','required');
        $this->form_validation->set_rules('site_id','站点id','required');
      
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $args = $this->input->post();
        $res = $this->Product_hash_service->add($args);
        if($res === false){
            returnJson('402','');
        }else{
            returnJson('200','');
        }

    }

    /**
     * 禁止登陆/允许登陆
     * @param integer  $user_id     用户ID
     * @param integer  $type        状态
     * @return array
     */
    public function forbid_login(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_c2corder_service->update_forbid_login($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 禁止交易/允许交易
     * @param integer  $user_id     用户ID
     * @param integer  $type        状态
     * @return array
     */
    public function forbid_withdraw(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_c2corder_service->update_forbid_withdraw($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }

    /**
     * 禁止提现/允许提现
     * @param integer  $user_id     用户ID
     * @param integer  $type        状态
     * @return array
     */
    public function forbid_trade(){
        $this->form_validation->set_rules('user_id','用户ID','required');
        $this->form_validation->set_rules('type','状态','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $user_id = $this->input->post('user_id');
        $type = $this->input->post('type');
        $this->Zjys_c2corder_service->update_forbid_trade($user_id,$type);
        returnJson('200',lang('operation_successful'));
    }


    public function params_config_c2c(){
        $args = $this->input->post();
        $page= isset($args['page']) ? intval($args['page']) : 1; //当前页
        $limit = isset($args['limit']) ? intval($args['limit']) : 10;//偏移量
        $site_id =  !empty($args['site_id']) ? intval($args['site_id']) : '';
        $offset = ($page - 1) * $limit;
        $data['list'] = $this->Config_service->c2c_param_config_list($offset,$limit,$site_id);
        // var_dump($data['list']);die;

        $count = $this->Config_service->c2c_param_config_list_count($site_id);


        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
       // var_dump($count,  $data['totalPage']);die;
        returnJson('200',lang('operation_successful'),$data);
    }
    public function c2c_config_update(){
        $args = $this->input->post();
        // $this->form_validation->set_rules('varname','变量名','required');
        $this->form_validation->set_rules('value','变量值','required' );
        // $this->form_validation->set_rules('remark', '描述','required');
        // $this->form_validation->set_rules('site_id','站点id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $res = $this->Config_service->c2c_config_update($args);
        // var_dump($this->db->last_query());die;
        
        if($res !== false){
            //清redis
            $key = 'options';
            $redis = new Redis();
            require(APPPATH.'config/redis.php');
            $redis->connect($config['host'],$config['port']);
            $redis->select(15);
            $result = $redis->delete($key);
            if($result){
                returnJson('200',lang('operation_successful'));
            }
        }
        returnJson('200',lang('operation_successful'));
        // returnJson('402','配置参数名已存在');
    }
    public function c2c_config_delete(){
        $this->form_validation->set_rules('id','id','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $id = $this->input->post('id');
        $this->Config_service->c2c_config_delete($id);
        returnJson('200',lang('operation_successful'));
    }





}
