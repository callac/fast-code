<?php
defined('BASEPATH') OR exit('No direct script access allowed');
set_time_limit(0);
class Zg_activity extends Web_Controller
{
    function __construct() {
        parent::__construct();
        $this->load->service('Zg_activity_service');
    }

    public function insert_new_year_activity(){
        $this->form_validation->set_rules('activity_name','活动名','required');
        $this->form_validation->set_rules('start_time','开始时间','required');
        $this->form_validation->set_rules('end_time','结束时间','required');
        $this->form_validation->set_rules('site_id','站点ID','required');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $activity_name = $this->input->post('activity_name');
        $start_time = $this->input->post('start_time');
        $end_time = $this->input->post('end_time');
        $site_id = $this->input->post('site_id');
        $data = $this->Zg_activity_service->insertNewYearActivity($activity_name,$start_time,$end_time,$site_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function year_activity_list(){
        $pool_type = $this->input->post('pool_type');
        $user_id = $this->input->post('user_id');
        $start_time = $this->input->post('start_time');
        $end_time = $this->input->post('end_time');
        $type = $this->input->post('type');
        $activity_id = $this->input->post('activity_id');
        $page = empty( $this->input->post('page')) ? 1 :  $this->input->post('page');
        $limit =empty( $this->input->post('limit')) ? 10 :  $this->input->post('limit');
        $data = $this->Zg_activity_service->year_activity_list($pool_type,$user_id,$start_time,$end_time,$type,$page,$limit,$activity_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function year_activity_pool_log(){
        $page = empty( $this->input->post('page')) ? 1 :  $this->input->post('page');
        $limit =empty( $this->input->post('limit')) ? 10 :  $this->input->post('limit');
        $data = $this->Zg_activity_service->year_activity_pool_log($page,$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function year_state(){
        $data = $this->Zg_activity_service->year_state();
        returnJson('200',lang('operation_successful'),$data);
    }

    public function year_activity_monitoring(){
        $activity_id = $this->input->post('activity_id');
        $data = $this->Zg_activity_service->year_activity_monitoring($activity_id);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function change_pool_balance(){
        $this->form_validation->set_rules('pool_type','奖池类型','required');
        $this->form_validation->set_rules('balance','奖池金额','required|numeric');
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        $activity_id = $this->input->post('activity_id');
        $pool_type = $this->input->post('pool_type');
        $balance = $this->input->post('balance');
        $res = $this->Zg_activity_service->change_pool_balance($activity_id,$pool_type,$balance);
        if($res){
            returnJson('200',lang('operation_successful'),$res);
        }
        returnJson('402','操作失败');

    }



}
