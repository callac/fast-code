<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 调账管理
 */
class Update_money extends Web_Controller {
    function __construct() {
        parent::__construct();
        $this->load->service('Update_money_service');
    }
    //锁仓记录初次审核
    public function updatemoney_apply_list(){
        $args = $this->input->post(); 
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $uid = isset($args['user_id']) ? $args['user_id'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->Update_money_service->updatemoney_apply_list($offset,$limit,$start_time,$end_time,$site_id,$uid);
        $count = $this->Update_money_service->updatemoney_apply_list_count($start_time,$end_time,$site_id,$uid);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);   
    }

    //调账申请
    public function updatemoney_apply()
    {
        $args = $this->input->post(); 
        $this->form_validation->set_rules('user_id','用户id','required'); 
        $this->form_validation->set_rules('asset','币种','required'); 
        $this->form_validation->set_rules('amount','数量','required'); 
        $this->form_validation->set_rules('remark','申请调账备注','required'); 
        if($this->form_validation->run() == FALSE){
            returnJson('402',lang('missing_parameters'));
        }
        // $site_id = isset($args['site_id']) ? $args['site_id'] : ''; //来源
        if($this->Update_money_service->updatemoney_apply($args)){
            returnJson('200',lang('operation_successful'));
        }else{
            returnJson('402','更改资金失败');
        }
    }

    //批量调账申请
    public function batch_updatemoney_apply()
    {
        if(!$this->input->post('arr')){
            $file = $_FILES['file'];
            $filename = $file['tmp_name'];
            $name = substr($file['name'],strpos($file['name'],'.')+1);
            if($name!=='csv') returnJson('402','文件格式错误');
            if (empty ($filename)) returnJson('402','csv文件缺失');
            $handle = fopen($filename, 'r');
            while ($data = fgetcsv($handle)) { //每次读取CSV里面的一行内容
                $list[] = $data;
            }
            if($list[0][0] === null) returnJson('402','没有数据');
            
            // var_dump($list);die;
            fclose($handle); //关闭指针
            foreach ($list as $key => $value) {
                $args['user_id'] = $value[0];
                $args['asset'] = $value[1];
                $args['amount'] = $value[2];
                $encode = mb_detect_encoding($value[3], array("ASCII",'UTF-8',"GB2312","GBK",'BIG5')); 
                $args['remark'] = mb_convert_encoding($value[3], 'UTF-8',$encode);
                $result[$key] = $args;
            }
            returnJson('200',lang('operation_successful'),$result);
        }else{
            $args = $this->input->post();
            $result = json_decode($args['arr'],true);
            foreach ($result as $value) {
                $this->Update_money_service->updatemoney_apply($value);
            }
            returnJson('200',lang('operation_successful'));
        }
    }

    //调账审核
    public function update_money_check()
    {
        $data = $this->input->post(); 
        $id = isset($data['id']) ? $data['id'] : false;
        if(!$id){
            returnJson('402',lang('missing_parameters'));
        }
        $check_status = isset($data['check_status']) ? $data['check_status'] : false;
        if(!$check_status){
            returnJson('402',lang('missing_parameters'));
        }
        $check_remark = $data['check_remark'];//审核备注
        $result = $this->Update_money_service->update_money_check($id,$check_status,$check_remark); 
        if($result === false)  returnJson('402','数据异常');       
        returnJson('200',lang('operation_successful'),$result);
    }

    //批量调账审核
    public function batch_updatemoney_check()
    {
        $ids = $this->input->post('arr');
        $check_status = $this->input->post('check_status');
        $result = $this->db->query("select id,remark,user_id,asset_code from operation_money_apply where id in ($ids)")->result_array();
        $newarray = [];
        foreach ($result as &$value) {
            $value['check_status'] = $check_status;
            array_push($newarray,$value['user_id'].$value['asset_code']) ;
        }
        $new = array_unique($newarray);
        if(count($new) < count($newarray)) returnJson('402','用户ID、币种必须唯一');

        //判断所有需要调整的是否符合需求，判定金额是否合规
        foreach ($result as &$value) {
            if($value['check_status']==1)
                $check_remark = '批量审核成功';
            else
                $check_remark = '批量审核失败';
            // $this->test_batch_enough_money($value['id'],$value['check_status'],$check_remark);
        }
        $result1 = $result;
        foreach ($result1 as &$value) {
            $this->Update_money_service->update_money_check($value['id'],$value['check_status'],$check_remark); 
        }
        returnJson('200','执行成功！');
    }

    //批量调账检测（主要是调账为负值时，检测账户有足够余额）
    public function test_batch_enough_money($id,$check_status,$check_remark)
    {
        $this->Update_money_service->test_batch_enough_money($id,$check_status,$check_remark);
    }


}
