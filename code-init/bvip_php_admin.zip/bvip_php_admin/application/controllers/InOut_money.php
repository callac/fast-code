<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 张哲
 * Date: 2019-04-29
 * Time: 17:24
 */

class InOut_money extends Web_Controller{

    function __construct()
    {
        parent::__construct();
        $this->load->service('InOut_money_service');
    }

    /**
     * Notes: 获取
     * User: 张哲
     * Date: 2019-04-29
     * Time: 18:00
     */
    public function InOutMoneyQuery(){
        $args = $this->input->post();
        $user_id = isset($args['user_id']) ? $args['user_id'] : ''; //用户id
        $asset = isset($args['asset']) ? $args['asset'] : ''; //币种
        $type = isset($args['type']) ? $args['type'] : ''; //类型
        $limit = !empty($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = !empty($args['page']) ? intval($args['page']) : 1; //当前页
        $offset = ($page - 1) * $limit;
        $data = $this->InOut_money_service->InOutMoneyQuery($offset,$limit,$user_id,$asset,$type);
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($data['count']/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

//    public function asset_price(){
//        $args = $this->input->post();
//
//        $data = $this->InOut_money_service->asset_price($args['asset']);
//
//        returnJson('200',lang('operation_successful'),$data);
//    }
//    
    /**
     * OTC转账记录
     * @return [type] [description]
     */
    public function otc_transfer_list()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //
        $type = isset($args['type']) ? $args['type'] : ''; //类型
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $data['list']= $this->InOut_money_service->otc_transfer_list($start_time,$end_time,$offset,$limit,$asset,$type);
        $count = $this->InOut_money_service->otc_transfer_list_count($start_time,$end_time,$asset,$type);
        $data['total']=$count;
        $data['pageSize']=$limit;
        $data['curPage']=$page;
        $data['totalPage']=ceil($count/$limit);
        returnJson('200',lang('operation_successful'),$data);
    }

    public function otc_transfer_list_csv()
    {
        $args = $this->input->post();
        $limit = isset($args['limit']) ? intval($args['limit']) : 10; //偏移量
        $page = isset($args['page']) ? intval($args['page']) : 1; //当前页
        $asset = isset($args['asset']) ? $args['asset'] : ''; //
        $type = isset($args['type']) ? $args['type'] : ''; //类型
        $start_time = isset($args['start_time']) ? $args['start_time'] : ''; //开始时间
        $end_time = isset($args['end_time']) ? $args['end_time'] : ''; //结束时间
        $offset = ($page - 1) * $limit;
        $list = $this->InOut_money_service->otc_transfer_list($start_time,$end_time,$offset,$limit,$asset,$type);
        if(is_array($list) && empty($list)) returnJson('402','当前条件下无数据可导出');  
        $csvpath = APPPATH.'cache/excel/otc_transfer'.date('Y-m-d',time()).'.csv';
        $handle = fopen( $csvpath, 'wb' );
        $header = array(
            iconv( 'UTF-8', 'GB2312//IGNORE', '用户id' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '币种' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '数量' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '类型（1:转入2:转出）' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '状态（1:成功0:失败）' ),
            iconv( 'UTF-8', 'GB2312//IGNORE', '站点ID' ),
        );

        fputcsv( $handle, $header );
        foreach($list as $value){
            $fields =   [           
                            $value['user_id'],  
                            $value['asset'],   
                            $value['change'],   
                            $value['type'],   
                            $value['status'],   
                            $value['site_id'],   
                        ];
            fputcsv( $handle, $fields );
        }
        fclose($handle);
        $filePath = strstr($csvpath,'application');
        $oss = new \App\Helpers\oss_helper();
        $data['url'] = $oss->uploadCsvFile($filePath,'.csv',true);
        returnJson('200',lang('operation_successful'),$data);
    }

}
