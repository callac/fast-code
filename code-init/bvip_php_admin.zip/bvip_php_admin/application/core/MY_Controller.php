<?php



/**
 * Class Base_Controller 基类
 */
class Base_Controller extends CI_Controller
{
    /**
     * @var int 访问者的端
     */
    public $endpoint;
    /**
     * @var string 访问者的ip
     */
    public $ip_address;

    /**
     * @var string 客户端
     */
    public $string_user_agent;

    /**
     * @var string wap的url
     */
    public $wap_url;

    /**
     * @var string o2o域名
     */
    public $o2o_url;
    /**
     * @var string 网站名称
     */
    public $site_name;

    /**
     * @var string 网站标识
     */
    public $site_code;


    /**
     * @var string 网站域名
     */
    public $site_domain;

    /**
     * @var string 折扣劵名称
     */
    public $coupon_name;

    /**
     * @var string 模板名称
     */
    public $template_dir = "";

    /**
     * 配置
     * @var array
     */
    public $config_array = array();

    public $_site_info;
    public $_site_id;

    /**
     * 构造
     */
    public function __construct()
    {

        parent::__construct();
        header("Access-Control-Allow-Origin: * "); 
        header('Access-Control-Max-Age: 3600');
        // date_default_timezone_set('PRC');
        date_default_timezone_set("Etc/GMT-8");

        //url
        $this->load->helper('url');
        $this->load->helper("common");
        $this->load->library('form_validation');
        $this->load->model('Base_model');
        $this->load->service("User_service");
        $this->config->load('xlink', TRUE);

        $xlink = $this->config->item('xlink');
        if ($xlink['enable'] === TRUE) {
            $this->load->helper('xlink_tcp');
        } else {
            $this->load->database();
            $this->load->helper('xlink_db');
        }
        // if(empty($language)){
        //     $language = 'simplified-chinese';
        // }
        // $this->config->set_item('language', $language);
        // $this->_language = $language;
        // var_dump($this->config->item('language'));die;
        // $this->config->set_item('itema','asdf');
        // var_dump($this->config->item('itema'));die;
        $this->lang->load('info_lang','zh-hans'); //继承baseController时的方法默认中文简体
    }

    public function get_site_info()
    {
        $url = $_SERVER["HTTP_HOST"];   //获取完整的来路URL
        $str  = str_replace("http://","",$url);  //去掉http://
        $strdomain = explode(":",$str);               // 以“/”分开成数组
        $domain    = $strdomain[0];              //取第一个“/”以前的字符
        $this->load->service('Site_service');
        $site_info = $this->Site_service->get_site_info($domain);
        
        if(empty($site_info)){
           returnJson('101',lang('unopen_site'));            
        }
        if ($site_info['is_close']) {
           returnJson('101',lang('close_site'));
        }
        return $site_info;
       
    }

    /*简化service操作
	 * @param $method service方法名
	 * @param $param 调用参数
	 * @param $back_origin 是否原样返回数据,默认在处理成功并且返回码正确只返回data下的数据
	 * */
    public function load_service($name, $method, $param = array(), $back_origin = false)
    {
        $name = $name . '_service';
        if (!property_exists($this, $name)) {
            $this->load->service($name);
        }

        if (!method_exists($this->$name, $method)) {
            $e = new Exception();
            log_message("error", "can't get method " . $method . " from " . $name . ";stack:" . $e->getTraceAsString());
            throw $e;
        }

        try {
            $ret = call_user_func_array(array($this->$name, $method), $param);

            if ($back_origin) return $ret;

            if ($ret && $ret['error'] == SERVICE_SUCCESS) {
                return $ret['data'];
            }
            return array();
        } catch (Exception $e) {
            error_log("Exption:" . $e->getMessage() . ",stack:" . $e->getTraceAsString());
        }
        return array(array(), SERVICE_SUCCESS);
    }


    /**
     * 强制ajax请求
     * @param string $redirect_code
     */
    protected function force_ajax($redirect_code)
    {
        if (!$this->input->is_ajax_request()) {
            redirect(site_url($redirect_code));
        }
    }


}
class SysConst
{
    private static $_ip = "";
    private static $_agent = "";
    private static $_endpoint = -1;
    private static $_msg_id = "";
    private static $_request_unique = "";

    /**
     * 获取消息id
     * @return string
     */
    public static function get_msg_id()
    {
        if ("" == self::$_msg_id) {
            self::$_msg_id = md5(uniqid(rand(), true));
        }
        return self::$_msg_id;
    }

    /**
     * 设置消息id
     * @param string $msg_id
     */
    public static function set_msg_id($msg_id)
    {
        self::$_msg_id = $msg_id;
    }

    /**
     * 获取唯一请求号
     * @return string
     */
    public static function get_request_unique()
    {
        if ("" == self::$_request_unique) {
            self::$_request_unique = md5(uniqid("req_", true));
        }
        return self::$_request_unique;
    }

    /**
     * @param string $request_unique
     */
    public static function set_request_unique($request_unique)
    {
        self::$_request_unique = $request_unique;
    }

    /**
     * 获取端类型 todo 暂时修改以适应test
     * @return string
     */
    public static function get_endpoint()
    {
        if (ENVIRONMENT === 'testing') {
            self::$_endpoint = -1;
        } else {
            if (self::$_endpoint == -1) {
                self::$_endpoint = get_instance()->endpoint;
            }
        }
        return self::$_endpoint;
    }

    /**
     * 设置端类型
     * @param int $endpoint
     */
    public static function set_endpoint($endpoint)
    {
        if (!in_array($endpoint, array(
            EventConst::ENDPOINT_WEB,
            EventConst::ENDPOINT_WAP,
            EventConst::ENDPOINT_APP
        ))
        ) {
            $endpoint = EventConst::ENDPOINT_WEB;
        }
        self::$_endpoint = $endpoint;
    }

    /**
     * 获取ip地址
     * @return string
     */
    public static function get_ip()
    {
        if (self::$_ip == "") {
            self::$_ip = get_instance()->input->ip_address();
        }
        return self::$_ip;
    }

    /**
     * 设置ip地址
     * @param string $ip
     */
    public static function set_ip($ip)
    {
        self::$_ip = $ip;
    }

    /**
     * 获取浏览器头部
     * @return string
     */
    public static function get_agent()
    {
        if (self::$_agent == "") {
            self::$_agent = trim(get_instance()->input->user_agent());
        }
        return self::$_agent;
    } 

    /**
     * 设置浏览器头部
     * @param string $agent
     */
    public static function set_agent($agent)
    {
        self::$_agent = $agent;
    }


}


/**
 * /算力前台接口-需要jwt验证的接口
 */
class Web_Controller extends Base_Controller
{

    public $sign = array();

    /**
     * 构造
     */
    public function __construct()
    {
        // ob_start();
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header("Access-Control-Allow-Headers: Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
        parent::__construct();
        define("IS_POST", count($_POST) > 0 ? true : false);
        $method = strtolower($this->router->method);

        if ($method != 'login' && $method != 'sms' && $method != 'verity_login') {
            $CI =& get_instance();
            $CI->load->model('Roles_model');
            $CI->load->service('Admin_service');
            $CI->load->service('Logs_service');
            $method = strtolower($CI->router->method);
            if ($method == 'login') return;
            if ($method == 'verity_login') return;
            if ($method == 'sms') return;
            if (!empty($authorization = $CI->input->get_request_header("Authorization", true))) {
                $autharray = explode(" ", trim($authorization));
                if ($autharray[0] != 'Bearer') {
                    returnJson("403", 'Bearer缺失');
                }
                $decoded = jwt_helper::decode($autharray[1]);//解密
                if (!$decoded) {
                    returnJson("403", '无效token2');
                }

                $decoded_array = (array)$decoded;

                // var_dump($decoded_array);die;
                $explode = explode('|', $decoded_array['userId']);

                $this->user_id = $explode[0];

                // var_dump($this->user_id);

                $this->user_info = $CI->Admin_service->admin_details($this->user_id);
                // var_dump($this->user_info);die;
                if ($this->user_info['admin_language_switch'] != null) {
                    $this->config->set_item('language', $this->user_info['admin_language_switch']); //根据管理员来获取语言
                    $this->lang->load('info_lang', $this->user_info['admin_language_switch']);
                } else {
                    $this->lang->load('info_lang', 'zh-hans'); //默认中文
                }
                // var_dump($this->config->item('language'));die;
                if (!$this->user_info) {//检查用户是否存在
                    returnJson("403", '用户不存在');
                }
//
//                    if($this->user_info['user_name'] !== 'zz'){
//
//                        $api_token = $this->user_info['token'];
//                        if($api_token != $autharray[1] || $api_token == '0'){
//                            returnJson('2000',lang('Your login has expired, please log in again'));
//                        }

                        $time = time();
                        $log_time = $this->user_info['token_time'];
                        $token_time = $time - $log_time;
                        if($token_time > 43200){
                            returnJson('2000',lang('Your login has expired, please log in again'));
                        }
                    //}

            } else {
                returnJson("403", 'token信息缺失');
            }
        }
    }

    
}
