<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * bool 类型
 */
const SERVICE_PARAM_BOOL = 0;
/**
 * int 类型
 */
const SERVICE_PARAM_INT = 1;
/**
 * float 类型
 */
const SERVICE_PARAM_FLOAT = 2;
/**
 * double 类型
 */
const SERVICE_PARAM_DOUBLE = 3;
/**
 * string 类型
 */
const SERVICE_PARAM_STRING = 4;
/**
 * array 类型
 */
const SERVICE_PARAM_ARRAY = 5;
/**
 * object 类型
 */
const SERVICE_PARAM_OBJECT = 6;

/**
 * callable
 */
const SERVICE_PARAM_CALLABLE = 7;

/**
 * mixed
 */
const SERVICE_PARAM_MIXED = 8;

const LOCAL_HOST_IP = "127.0.0.1";

/**
 * 常用状态类数字
 */
const INT_STATUS_YES = 1;
const INT_STATUS_NO = 0;

const STRING_STATUS_YES = 'Y';
const STRING_STATUS_NO = 'N';

/**
 * 端类型字符串
 */
const ENDPOINT_WEB_STRING = 'web';
const ENDPOINT_WAP_STRING = 'wap';
const ENDPOINT_APP_STRING = 'app';
const ENDPOINT_PC_STRING = 'pc';

/**
 * 操作系统类型
 */
const OS_TYPE_PC = 'normal';
const OS_TYPE_ANDROID = "android";
const OS_TYPE_IOS = 'ios';
const OS_TYPE_WP = 'wp';

/**
 * 默认参数
 */
const SERVICE_PARAM_INT_TYPE_ALL = -1;
const SERVICE_PARAM_STRING_TYPE_ALL = "";

/**
 * http status code
 */
const HTTP_STATUS_CODE_OK = 200;
const HTTP_STATUS_CODE_IP_LOCK = 401;//ip被锁定
const HTTP_STATUS_CODE_IP_SPAM_TOO_MUCH = 402;//spam请求次数过多
const HTTP_STATUS_CODE_IP_VALID_CODE_ERROR_TOO_MUCH = 403;//验证码失败次数太多
const HTTP_STATUS_CODE_INTERNAL_ERROR = 500;//通用内部错误

/**
 * 正常返回接口
 */
const SERVICE_SUCCESS = 0;

/**
 * 无效参数
 */
const SERVICE_ERROR_PARAM_INVALID = -1;

/**
 * 常规错误代码
 */
const ERROR_SERVICE_IS_UNREACHABLE = 100; //服务不可到达
const ERROR_SERVICE_NOT_AUTHORIZE = 101;//服务未授权
const ERROR_SERVICE_FREQUENCY_LIMITED = 102;//服务被限流
const ERROR_SERVICE_DEGRADE = 103;//服务降级
const ERROR_SERVICE_DISABLE = 104;//服务被关闭

/**
 * 错误信息代码，因为业务交叉逻辑性，可能部分接口返回的错误代码会出现多个service的，故此所有的错误代码集中处理，代码的号码从10000开始编码
 * 其中万位以及以上为域号码
 * 1 用户域
 * 2 用户账号域
 * 3 产品域
 * 4 订单域
 * 5 商城域
 * 6 网点域
 * 7 支付域
 * 8 APP域
 * 9 安全域
 * 10 工具域
 */

/**
 * 1 用户域
 */
const ERROR_USER_NAME_EXIST_ALREADY = 10000;//用户名已经存在
const ERROR_USER_MOBILE_EXIST_ALREADY = 10001;//手机号码已经存在
const ERROR_USER_INVALID_USERNAME_PASSWORD = 10002;//用户名密码错误
const ERROR_USER_LOCKED = 10003;//账户被锁定
const ERROR_USER_WRONG_TIME_EXCEED = 10004;//用户错误次数超出
const ERROR_USER_INVALID_PASSWORD = 10005;//密码无效，验证密码使用
const ERROR_USER_NOT_EXITS = 10006;//账户不存在
const ERROR_USER_UPDATE_MOBILE_SAME = 10007;//更新时输入了同样的手机号码
const ERROR_USER_ID_CARD_EXITS_ALREADY = 10008;//已经存在了身份证号码
const ERROR_USER_MOBILE_DISABLE = 10009;//已经存在了身份证号码

/**
 * 2 用户账号域
 */


/**
 * 3 产品域
 */
const ERROR_PRODUCT_NOT_EXISTS = 30000;//产品不存在
const ERROR_STATUS_NOT_RIGHT = 30001;//产品状态不正确
const ERROR_BUY_UNPAID_ORDER = 30002;//还有未支付的购买记录
const ERROR_USER_NO_AUTHORIZE = 30003;//订单用户不匹配
const ERROR_STATUS_INVALID = 30004;//订单状态无效
const BUY_ERROR_CANT_BUY_OWNED = 30005;//不能购买自己发布的产品
const BUY_ERROR_NOT_BIND_3PAYMENT = 30006;//未绑定三方支付

/**
 * 4 订单域
 */


/**
 * 5 商城域
 */


/**
 * 6 网点域
 */
const ERROR_OUTLET_NOT_EXIST = 60000; //网点不存在
const ERROR_JOIN_REQUEST_ADD_ALREADY = 60001;//加盟请求已经申请


/**
 * 7 支付域
 */


/**
 * 8 APP域
 */


/**
 * 9 安全域
 */
const ERROR_SECURITY_IP_NEED_SAFETY = 90000; //ip地址需要安全检查
const ERROR_SECURITY_IP_LOCK = 90001;//ip地址被锁定


/**
 * 10 工具域
 */
const ERROR_TOOL_IP_NOT_EXIST = 100000;//ip地址库中无对应记录
const ERROR_TOOL_MOBILE_LOCATION_NOT_EXIST = 100001;//手机号码查询地址无记录

/**
 * 11 浙金券
 */
const ERROR_GIFT_SAME_BATCH_HAVE_ALREADY = 110000;//已经持有同批次的浙金券了
const ERROR_GIFT_CODE_INVALID = 110001;//输入的浙金券代码无效

/**
 * @property CI_DB_forge $dbforge
 * @property CI_Benchmark $benchmark
 * @property CI_Calendar $calendar
 * @property CI_Cart $cart
 * @property CI_Config $config
 * @property CI_Controller $controller
 * @property CI_Email $email
 * @property CI_Encrypt $encrypt
 * @property CI_Exceptions $exceptions
 * @property CI_Form_validation $form_validation
 * @property CI_Ftp $ftp
 * @property CI_Image_lib $image_lib
 * @property CI_Input $input
 * @property CI_Lang $lang
 * @property MY_Loader $load
 * @property CI_Log $log
 * @property CI_Model $model
 * @property CI_Output $output
 * @property CI_Pagination $pagination
 * @property CI_Parser $parser
 * @property CI_Profiler $profiler
 * @property CI_Router $router
 * @property CI_Session $session
 * @property CI_Table $table
 * @property CI_Trackback $trackback
 * @property CI_Typography $typography
 * @property CI_Unit_test $unit_test
 * @property CI_Upload $upload
 * @property CI_URI $uri
 * @property CI_User_agent $user_agent
 * @property CI_Xmlrpc $xmlrpc
 * @property CI_Xmlrpcs $xmlrpcs
 * @property CI_Zip $zip
 * @property CI_Javascript $javascript
 * @property CI_Utf8 $utf8
 * @property CI_Security $security
 * @property CI_Driver_Library $driver
 * @property CI_Cache $cache
 * @property Cache_service $Cache_service
 * @property Product_model $Product_model
 * @property User_model $User_model
 * @property User_favor_model $User_favor_model
 * @property Area_model $Area_model
 * @property User_product_model $User_product_model
 * @property Product_tag_model $Product_tag_model
 * @property Market_model $Market_model
 * @property Require_tag_model $Require_tag_model
 * @property Tags_model $Tags_model
 * @property User_valid_model $User_valid_model
 * @property Sms_limit_model $Sms_limit_model
 * @property Sms_tpl_model $Sms_tpl_model
 * @property MessageQueue $messagequeue
 * @property Account_model $Account_model
 * @property User_event_model $User_event_model
 */
class MY_Service
{

    /**
     * @var int 版本信息
     */
    protected $_ver;

    //以下参数都可以通过this->实现，增加是为了rpc默认参数中处理此类信息
    /**
     * @var string
     */
    protected $_ip;

    /**
     * @var null|string
     */
    protected $_agent;

    /**
     * @var int 端类型
     */
    protected $_endpoint;

    /**
     * @var string app版本字符串
     */
    protected $_app_ver;

    /**
     * @var string 消息id
     */
    protected $_msg_id;

    /**
     * @var array 临时缓存
     */
    protected $_cache;

    /**
     * Constructor
     *
     * @access public
     */
    public function __construct()
    {
        $this->_ver = "1";
        $this->refresh_env();
    }

    public function refresh_env()
    {
        $this->_endpoint = SysConst::get_endpoint();
        $this->_ip = SysConst::get_ip();
        $this->_agent = SysConst::get_agent();
        $this->_msg_id = SysConst::get_msg_id();
    }

    /**
     * 服务版本信息
     * @return string
     */
    public function version()
    {
        return $this->_ver;
    }

    /**
     * __get
     *
     * Allows services to access CI's loaded classes using the same
     * syntax as controllers.
     *
     * @param    string
     * @access private
     */
    function __get($key)
    {
        $CI = &get_instance();
        return $CI->$key;
    }

    /**
     * 检查参数
     * @param array $param
     * @param array $rule
     * @return array
     * @throws Exception
     */
    protected function _check_param($param, $rule)
    {
        if (!is_array($param) || count($param) != count($rule)) {
            $this->_core_log($this->_call_trace());
            throw new Exception("param invalid");
        }
        $param = array_values($param);
        foreach ($rule as $k => $v) {
            if (SERVICE_PARAM_BOOL == $v) {
                $param[$k] = (bool)$param[$k];
            } elseif (SERVICE_PARAM_INT == $v) {
                //这里int将来可能会溢出
                $param[$k] = (int)$param[$k];
            } elseif (SERVICE_PARAM_FLOAT == $v) {
                $param[$k] = floatval($param[$k]);
            } elseif (SERVICE_PARAM_DOUBLE == $v) {
                $param[$k] = doubleval($param[$k]);
            } elseif (SERVICE_PARAM_STRING == $v) {
                $param[$k] = (string)($param[$k]);
            } elseif (SERVICE_PARAM_ARRAY == $v) {
                if (!is_array($param[$k])) {
                    $this->_core_log($this->_call_trace());
                    throw new Exception("param invalid");
                }
            } elseif (SERVICE_PARAM_OBJECT == $v) {
                if (!is_object($param[$k])) {
                    $this->_core_log($this->_call_trace());
                    throw new Exception("param invalid");
                }
            } elseif (SERVICE_PARAM_CALLABLE == $v) {
                if (!is_callable($param[$k])) {
                    $this->_core_log($this->_call_trace());
                    throw new Exception("param invalid");
                }
            }
        }
        return $param;
    }

    /**
     * 纪录日志
     * @param string $msg
     */
    protected function _core_log($msg)
    {
        write_log($msg, "service_core");
    }

    /**
     * 调用trace
     * @return string
     */
    private function _call_trace()
    {
        $e = new Exception();
        $trace = explode("\n", $e->getTraceAsString());
        //翻转数据
        $trace = array_reverse($trace);
        array_shift($trace); // remove {main}
        array_pop($trace); // remove call to this method
        $length = count($trace);
        $result = array();
        for ($i = 0; $i < $length; $i++) {
            $result[] = ($i + 1) . ')' . substr($trace[$i], strpos($trace[$i], ' '));
        }
        return "\t" . implode("\n\t", $result);
    }

    /**
     * 输出返回内容,所有的返回请调用return $this->output($data,$error);
     * @param $data
     * @param int $error
     * @return array
     */
    protected function output($data, $error = 0)
    {
        return array("error" => $error, "data" => $data);
    }

    /**
     * 获取string格式的端类型描述
     * @param int $endpoint
     * @return string
     */
    protected function _get_string_endpoint($endpoint)
    {
        $ret = ENDPOINT_WEB_STRING;
        if ($endpoint == EventConst::ENDPOINT_WAP) {
            $ret = ENDPOINT_WAP_STRING;
        } else if ($endpoint == EventConst::ENDPOINT_APP) {
            $ret = ENDPOINT_APP_STRING;
        }
        return $ret;
    }

    /**
     * 是否是有效的端操作系统
     * @param string $type
     * @return string
     */
    protected function _valid_os_type($type)
    {
        if ($this->_endpoint == EventConst::ENDPOINT_WEB) {
            return OS_TYPE_PC;
        }
        return in_array($type, array(OS_TYPE_ANDROID, OS_TYPE_IOS, OS_TYPE_WP)) ? $type : OS_TYPE_ANDROID;
    }

    /**
     * 呼叫服务
     * @param $class
     * @param $method
     * @param $param
     * @return mixed
     */
    public function _call($class, $method, $param)
    {
        $data = array(
            "ip" => $this->_ip,
            "endpoint" => $this->_endpoint,
            "agent" => $this->_agent
        );
        return $this->zjclient->call($class, $method, $param, $this->_ver, $data);
    }

}
// END Service Class

/* End of file Service.php */
/* Location: ./application/core/MY_Service.php */
