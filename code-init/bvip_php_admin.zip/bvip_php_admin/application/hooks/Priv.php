<?php
class Priv
{
    private $CI;

    private $overall_priv = array(
        '0001','0008','0011','1001','1006','2001','2006','3002','3012','3008','3019','5002','6001','6006','6007','6009'
        ,'7002','7001','8001','8004','8006','9001','9016','9027','9024','9005','9008','9012','9019'
        ,'10003','11001','12001','13001','13004','14001','0003','2012','2013','2014','3007','3009','3023','100007','20123'
    );
    function Acl()
    {
    $this->CI = & get_instance();
    }

    function filter()
    {
        $CI =& get_instance();
        $CI->load->model('Roles_model');
        $CI->load->service('Admin_service');
        $CI->load->service('Baoquan_service');
        $CI->load->service('Logs_service');
        $class = strtolower($CI->router->class);
        $method = strtolower($CI->router->method);

        if($method == 'login')return;
        if($method == 'sms')return;
        if($method == 'verity_login')return;
        if($method == 'tradelist')return;
        if($method == 'blocklist')return;
        if($method == 'nextbaoquanlist')return;
        if($method == 'baoquanlist')return;

        if(!empty($authorization = $CI->input->get_request_header("Authorization", true))){
            $autharray = explode(" ", trim($authorization));
            if($autharray[0] != 'Bearer'){
                returnJson("403",'Bearer缺失');
            }

                $decoded = jwt_helper::decode($autharray[1]);//解密
                if(!$decoded){
                    returnJson("403",'无效token');
                }
                $decoded_array =(array)$decoded;
                $explode = explode('|', $decoded_array['userId']);
                
                $user_id = $explode[0];
                    $ip = $explode[1];


                $user_info =$CI->Admin_service->admin_details($user_id);
                //验证后台管理员白名单
                // $adminwhiteipList = $CI->Admin_service->admin_white_list($user_id);
                // $adminwhiteipList = explode(',', $adminwhiteipList['ip']);
                // if(! in_array($ip, $adminwhiteipList)) returnJson('403','该ip禁止登录');
                if($user_info['ip'] != $ip)
                    returnJson('2000','您的管理员账号登录IP发生变更，如非本人操作，请重新登录！');
                if(!$user_info){//检查用户是否存在
                    returnJson("403",'用户不存在');
                }
                $site_id = $user_info['site_id'];
        }else{

            $user_id = 0;
            $site_id = 0;
        }

        //获取权限列表
        $list = $CI->Roles_model->get_admin_roles_by_user($user_id);
        $privilages = array();
        foreach ($list as $val){
            $privilages[] = @$CI->Roles_model->roles_details($val['role_id'])['privilages'];
        }
        $arr = array();
        foreach ($privilages as $val){
            $a = explode(',',$val);
            $arr = array_unique(array_merge($arr,$a));
        }
        $priv_url = '/'.$class.'/'.$method;
        $flag = false;
        foreach (privs() as $k => $v) {        if(strtolower($priv_url) == strtolower($v['mod_do_url'])){
                if($v['permission'] == 1){
                    if(in_array($k,$arr)){

                        if(@$_POST['site_id'] == '' && in_array($k,$this->overall_priv)){
                            $_POST['site_id'] = '';
                        }
                        $CI->Logs_service->add_logs($user_id,$k,$v['name'],time(),$CI->input->ip_address(),$site_id);
                        $flag = true;
                        break;
                    }else{
                        $flag = false;
                        break;
                    }
                }else{
                    //permission ==0 的 方法都不计入操作日志记录
                    // $CI->Logs_service->add_logs($user_id,$k,$v['name'],time(),$CI->input->ip_address(),$site_id);
                    $flag = true;
                    break;
                }

            }
        }
        // var_dump($flag);die;
        if(!$flag){
            returnJson('403',lang('not_authority'));
        }
    }
}