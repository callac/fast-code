<?php
// GENERATED CODE -- DO NOT EDIT!

namespace Sys;

/**
 */
class SysClient extends \Grpc\BaseStub {

    /**
     * @param string $hostname hostname
     * @param array $opts channel options
     * @param \Grpc\Channel $channel (optional) re-use channel object
     */
    public function __construct($hostname, $opts, $channel = null) {
        parent::__construct($hostname, $opts, $channel);
    }

    /**
     * 查询钱包对账接口
     * @param \Sys\QueryWalletReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function QueryWalletReconciliation(\Sys\QueryWalletReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/QueryWalletReconciliation',
        $argument,
        ['\Sys\QueryWalletResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 查询钱包资产余额
     * @param \Sys\QueryWalletBalanceReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function QueryWalletBalance(\Sys\QueryWalletBalanceReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/QueryWalletBalance',
        $argument,
        ['\Sys\QueryWalletBalanceResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 注册钱包用户
     * @param \Google\Protobuf\GPBEmpty $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateWalletUser(\Google\Protobuf\GPBEmpty $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/CreateWalletUser',
        $argument,
        ['\Sys\CreateWalletUserResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 获取钱包地址
     * @param \Sys\CreateWalletAddressReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateWalletAddress(\Sys\CreateWalletAddressReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/CreateWalletAddress',
        $argument,
        ['\Sys\CreateWalletAddressResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 取消市场订单
     * @param \Sys\CancelMarketOrdersReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CancelMarketOrders(\Sys\CancelMarketOrdersReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/CancelMarketOrders',
        $argument,
        ['\Sys\CancelMarketOrdersResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 取消用户订单
     * @param \Sys\CancelUserOrdersReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CancelUserOrders(\Sys\CancelUserOrdersReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/CancelUserOrders',
        $argument,
        ['\Sys\CancelUserOrdersResp', 'decode'],
        $metadata, $options);
    }

    /**
     * c2cCancel
     * @param \Google\Protobuf\GPBEmpty $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CancelC2COrders(\Google\Protobuf\GPBEmpty $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/CancelC2COrders',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * otcCancel
     * @param \Google\Protobuf\GPBEmpty $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CancelOTCOrders(\Google\Protobuf\GPBEmpty $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/CancelOTCOrders',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 创建用户接口
     * @param \Sys\BatchCreateUsersReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function BatchCreateUsers(\Sys\BatchCreateUsersReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/BatchCreateUsers',
        $argument,
        ['\Sys\BatchCreateUsersResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 审核充值
     * @param \Sys\VerifyRechargeReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function VerifyRecharge(\Sys\VerifyRechargeReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/VerifyRecharge',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 活动更新资金
     * @param \Sys\ActivityBalanceUpdateReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function ActivityBalanceUpdate(\Sys\ActivityBalanceUpdateReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/ActivityBalanceUpdate',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 查询锁仓资金总量
     * @param \Sys\LockBalanceQueryReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function LockBalanceQuery(\Sys\LockBalanceQueryReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/LockBalanceQuery',
        $argument,
        ['\Sys\LockBalanceQueryResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 锁仓更新资金
     * @param \Sys\LockBalanceUpdateReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function LockBalanceUpdate(\Sys\LockBalanceUpdateReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/LockBalanceUpdate',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 发送推送
     * @param \Sys\PushMessageToSingleReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function PushMessageToSingle(\Sys\PushMessageToSingleReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/PushMessageToSingle',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 发送群推
     * @param \Sys\PushMessageToListReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function PushMessageToList(\Sys\PushMessageToListReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/PushMessageToList',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 将提现审核成功的手动设置成失败
     * @param \Sys\SetWithdrawStatusToFailReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function SetWithdrawStatusToFail(\Sys\SetWithdrawStatusToFailReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/SetWithdrawStatusToFail',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 添加异常情况记录
     * @param \Sys\AddExceptionLogReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function AddExceptionLog(\Sys\AddExceptionLogReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/AddExceptionLog',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 发送校验消息
     * @param \Sys\AdminSendVerifyMessageReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function AdminSendVerifyMessage(\Sys\AdminSendVerifyMessageReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/AdminSendVerifyMessage',
        $argument,
        ['\Sys\AdminSendVerifyMessageResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 重发提币信息
     * @param \Sys\ResendWithdrawReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function ResendWithdraw(\Sys\ResendWithdrawReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/ResendWithdraw',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 充值补录校验
     * @param \Sys\RechargeFillVerifyReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function RechargeFillVerify(\Sys\RechargeFillVerifyReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/RechargeFillVerify',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 检验币种地址合法性
     * @param \Sys\CheckCoinAddrReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CheckCoinAddr(\Sys\CheckCoinAddrReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/CheckCoinAddr',
        $argument,
        ['\Sys\CheckCoinAddrResp', 'decode'],
        $metadata, $options);
    }

    /**
     * 充值补录
     * @param \Sys\RechargeSupplementReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function RechargeSupplement(\Sys\RechargeSupplementReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/RechargeSupplement',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

    /**
     * 充值补录校验
     * @param \Sys\RechargeSupplementCheckReq $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function RechargeSupplementCheck(\Sys\RechargeSupplementCheckReq $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/sys.Sys/RechargeSupplementCheck',
        $argument,
        ['\Google\Protobuf\GPBEmpty', 'decode'],
        $metadata, $options);
    }

}
