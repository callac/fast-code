# bvip_php_amdin
## 定时任务规范

### 使用工具
Linux 系统的 crontab 工具
### 请求方式
curl 模拟浏览器请求
### 请求格式
1. curl "http//localhost:port/index.php/action/method"
2. curl "http//localhost:port/index.php/action/method?time='yyyy-mm-dd'"
`例如：time='2019-04-15'表示在 2019-04-05<=time<2019=04-16 这一区间内`

### 具体定时任务内容
- 去重数据
- 注册数据
- 充值数据
- C2C买入
- C2C卖出
- 币币交易
- 持币统计